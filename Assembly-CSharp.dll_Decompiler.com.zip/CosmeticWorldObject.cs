using System;
using System.Collections.Generic;
using Photon.Pun;
using UnityEngine;

public class CosmeticWorldObject : MonoBehaviour
{
	public enum BlinkType
	{
		None,
		HealthHigh,
		HealthMedium,
		HealthLow,
		Extraction,
		Healed,
		Exploding
	}

	[Serializable]
	public class BlinkClass
	{
		public BlinkType type;

		[Space]
		public bool soundPlayOnce;

		public Sound sound;

		[Space]
		public int blinkCount;

		[Space]
		public float blinkIntervalOn;

		public float blinkIntervalOff;
	}

	internal PhysGrabObject physGrabObject;

	private NotValuableObject notValuableObject;

	private PhotonView photonView;

	internal Vector3 spawnPosition;

	private RoomVolumeCheck roomVolumeCheck;

	internal ValuableVolumeDebugDisplay valuableVolumeDebugDisplay;

	private ValuableDiscoverCustom discoverCustom;

	public SemiFunc.Rarity rarity;

	internal bool inExtraction;

	public CosmeticWorldObjectHealth health;

	public Gradient healthGradient;

	private int materialColorProperty = Shader.PropertyToID("_Color");

	private int materialEmissionProperty = Shader.PropertyToID("_EmissionColor");

	public SpringFloat healthAmountSpring;

	private float healthAmountTarget;

	public AnimationCurve healthFlashCurve;

	private float healthFlashLerp;

	private float healTimer;

	private PhysGrabObjectGrabArea grabArea;

	private bool healButtonState;

	public MeshRenderer blinkRenderer;

	public AnimationCurve blinkCurve;

	private Color blinkMaterialColor;

	private float blinkMaterialColorLerp;

	public List<BlinkClass> blinkSetups;

	private Material blinkMaterial;

	private Color blinkMaterialDefault;

	private BlinkType blinkType;

	private BlinkClass blinkClass;

	private bool blinking;

	private bool blinkState;

	private int blinkCount;

	private float blinkTimer;

	private bool exploding;

	private float explodingTime;

	private float explodingTimer;

	[Space]
	public SpringQuaternion ringRotationSpring;

	private Quaternion ringRotationTarget = Quaternion.identity;

	private Quaternion ringRotationTargetSpring = Quaternion.identity;

	private float ringRotationTargetCooldown;

	public SpringFloat buttonSpring;

	public Sound soundRingMove;

	public Sound soundButtonPress;

	public Sound soundButtonRelease;

	[Space]
	public Sound soundExplodingStart;

	public Sound soundExplodingLoop;

	public List<ParticleSystem> particlesExploding;

	private bool tutorialActive;

	private ParticleScriptExplosion particleScriptExplosion;

	private void Awake()
	{
		//IL_001e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0023: Unknown result type (might be due to invalid IL or missing references)
		//IL_003b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0040: Unknown result type (might be due to invalid IL or missing references)
		blinkMaterial = ((Renderer)blinkRenderer).material;
		blinkMaterialDefault = blinkMaterial.GetColor(materialEmissionProperty);
		photonView = ((Component)this).GetComponent<PhotonView>();
		spawnPosition = ((Component)this).transform.position;
		physGrabObject = ((Component)this).GetComponent<PhysGrabObject>();
		notValuableObject = ((Component)this).GetComponent<NotValuableObject>();
		valuableVolumeDebugDisplay = ((Component)this).GetComponent<ValuableVolumeDebugDisplay>();
		roomVolumeCheck = ((Component)this).GetComponent<RoomVolumeCheck>();
		grabArea = ((Component)this).GetComponent<PhysGrabObjectGrabArea>();
		discoverCustom = ((Component)this).GetComponent<ValuableDiscoverCustom>();
		particleScriptExplosion = ((Component)this).GetComponent<ParticleScriptExplosion>();
	}

	private void Start()
	{
		if (!LevelGenerator.Instance.Generated)
		{
			ValuableDirector.instance.cosmeticWorldObjectSpawnAmount++;
		}
		RoundDirector.instance.cosmeticWorldObjects.Add(this);
		if (TutorialDirector.instance.TutorialSettingCheck(DataDirector.Setting.TutorialCosmeticWorldObject1, 1))
		{
			tutorialActive = true;
		}
	}

	private void Update()
	{
		BlinkLogic();
		ExtractionEnterLogic();
		ExplodingLogic();
		HealthLogic();
		TutorialLogic();
	}

	private void HealthLogic()
	{
		//IL_0109: Unknown result type (might be due to invalid IL or missing references)
		//IL_0115: Unknown result type (might be due to invalid IL or missing references)
		//IL_0120: Unknown result type (might be due to invalid IL or missing references)
		//IL_0125: Unknown result type (might be due to invalid IL or missing references)
		//IL_0137: Unknown result type (might be due to invalid IL or missing references)
		//IL_014e: Unknown result type (might be due to invalid IL or missing references)
		//IL_016b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0180: Unknown result type (might be due to invalid IL or missing references)
		//IL_018a: Unknown result type (might be due to invalid IL or missing references)
		//IL_019f: Unknown result type (might be due to invalid IL or missing references)
		//IL_01a4: Unknown result type (might be due to invalid IL or missing references)
		//IL_023f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0245: Unknown result type (might be due to invalid IL or missing references)
		//IL_01ca: Unknown result type (might be due to invalid IL or missing references)
		//IL_01cf: Unknown result type (might be due to invalid IL or missing references)
		//IL_01e5: Unknown result type (might be due to invalid IL or missing references)
		//IL_01ea: Unknown result type (might be due to invalid IL or missing references)
		//IL_0200: Unknown result type (might be due to invalid IL or missing references)
		//IL_020f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0224: Unknown result type (might be due to invalid IL or missing references)
		//IL_0329: Unknown result type (might be due to invalid IL or missing references)
		//IL_032e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0332: Unknown result type (might be due to invalid IL or missing references)
		//IL_0255: Unknown result type (might be due to invalid IL or missing references)
		//IL_025c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0262: Unknown result type (might be due to invalid IL or missing references)
		//IL_026c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0271: Unknown result type (might be due to invalid IL or missing references)
		//IL_0277: Unknown result type (might be due to invalid IL or missing references)
		//IL_027d: Unknown result type (might be due to invalid IL or missing references)
		//IL_00af: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b5: Unknown result type (might be due to invalid IL or missing references)
		//IL_0365: Unknown result type (might be due to invalid IL or missing references)
		//IL_036f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0374: Unknown result type (might be due to invalid IL or missing references)
		//IL_0381: Unknown result type (might be due to invalid IL or missing references)
		//IL_0386: Unknown result type (might be due to invalid IL or missing references)
		//IL_0349: Unknown result type (might be due to invalid IL or missing references)
		//IL_034e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0354: Unknown result type (might be due to invalid IL or missing references)
		//IL_0359: Unknown result type (might be due to invalid IL or missing references)
		//IL_029b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0290: Unknown result type (might be due to invalid IL or missing references)
		//IL_0295: Unknown result type (might be due to invalid IL or missing references)
		//IL_039a: Unknown result type (might be due to invalid IL or missing references)
		//IL_02e0: Unknown result type (might be due to invalid IL or missing references)
		//IL_069e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0605: Unknown result type (might be due to invalid IL or missing references)
		//IL_063b: Unknown result type (might be due to invalid IL or missing references)
		//IL_065a: Unknown result type (might be due to invalid IL or missing references)
		//IL_05dc: Unknown result type (might be due to invalid IL or missing references)
		//IL_0543: Unknown result type (might be due to invalid IL or missing references)
		//IL_0579: Unknown result type (might be due to invalid IL or missing references)
		//IL_0598: Unknown result type (might be due to invalid IL or missing references)
		//IL_04ce: Unknown result type (might be due to invalid IL or missing references)
		float num = (float)notValuableObject.healthCurrent / (float)notValuableObject.healthMax;
		if (num != healthAmountTarget && SemiFunc.IsMasterClientOrSingleplayer())
		{
			if (num < healthAmountTarget)
			{
				if ((double)num > 0.66)
				{
					BlinkStart(BlinkType.HealthHigh);
				}
				else if ((double)num > 0.33)
				{
					BlinkStart(BlinkType.HealthMedium);
				}
				else
				{
					BlinkStart(BlinkType.HealthLow);
				}
			}
			else if (num > healthAmountTarget)
			{
				BlinkStart(BlinkType.Healed, _forced: true);
			}
			if (SemiFunc.IsMultiplayer())
			{
				photonView.RPC("HealthUpdateRPC", (RpcTarget)0, new object[1] { num });
			}
			else
			{
				HealthUpdateRPC(num);
			}
		}
		float num2 = SemiFunc.SpringFloatGet(healthAmountSpring, healthAmountTarget);
		if (healthFlashLerp < 1f)
		{
			healthFlashLerp += 3f * Time.deltaTime;
			healthFlashLerp = Mathf.Clamp01(healthFlashLerp);
		}
		Color val = Color.Lerp(Color.white, healthGradient.Evaluate(num2), healthFlashLerp);
		health.healthMaterial.SetColor(materialColorProperty, val);
		health.healthMaterial.SetColor(materialEmissionProperty, val);
		health.healthTransform.localScale = new Vector3(num2, health.healthTransform.localScale.y, health.healthTransform.localScale.z);
		float num3 = Vector3.Dot(health.forwardTransform.forward, Vector3.up);
		if (num3 < 0.75f && num3 > -0.75f)
		{
			health.rotationHelperTransform.rotation = Quaternion.LookRotation(Vector3.up);
			ringRotationTarget = health.rotationHelperTransform.localRotation;
			ringRotationTarget.eulerAngles = new Vector3(0f, ringRotationTarget.eulerAngles.y, 0f);
			health.rotationHelperTransform.localRotation = Quaternion.identity;
		}
		if (ringRotationTargetCooldown <= 0f)
		{
			if (ringRotationTargetSpring != ringRotationTarget)
			{
				Quaternion val2 = ringRotationTargetSpring;
				ringRotationTargetSpring = Quaternion.RotateTowards(ringRotationTargetSpring, ringRotationTarget, 45f);
				if (Quaternion.Angle(ringRotationTargetSpring, ringRotationTarget) < 10f)
				{
					ringRotationTargetSpring = ringRotationTarget;
				}
				float num4 = Quaternion.Angle(val2, ringRotationTargetSpring);
				if (num4 >= 10f)
				{
					soundRingMove.Pitch = 2f - Mathf.Clamp01(num4 / 45f) * 1.5f;
					soundRingMove.Play(physGrabObject.centerPoint);
				}
			}
			ringRotationTargetCooldown = 0.2f;
		}
		else
		{
			ringRotationTargetCooldown -= Time.deltaTime;
		}
		Quaternion normalized = ringRotationSpring.lastRotation.normalized;
		if (float.IsNaN(normalized.eulerAngles.x))
		{
			ringRotationSpring.lastRotation = Quaternion.identity;
			ringRotationTargetSpring = Quaternion.identity;
		}
		Quaternion val3 = SemiFunc.SpringQuaternionGet(ringRotationSpring, ringRotationTargetSpring);
		if (health.ringTransform.localRotation != val3)
		{
			health.ringTransform.localRotation = val3;
		}
		foreach (PhysGrabber listOfAllGrabber in grabArea.listOfAllGrabbers)
		{
			listOfAllGrabber.OverrideGrabPoint(grabArea.grabAreas[0].grabAreaTransform);
			listOfAllGrabber.OverrideColorToGreen();
		}
		if (SemiFunc.IsMasterClientOrSingleplayer())
		{
			if (grabArea.listOfAllGrabbers.Count > 0)
			{
				healTimer += Time.deltaTime;
				if (healTimer >= 1f)
				{
					foreach (PhysGrabber listOfAllGrabber2 in grabArea.listOfAllGrabbers)
					{
						PlayerAvatar playerAvatar = listOfAllGrabber2.playerAvatar;
						if (notValuableObject.healthCurrent != notValuableObject.healthMax && playerAvatar.playerHealth.health > 10)
						{
							notValuableObject.healthCurrent += 20;
							notValuableObject.healthCurrent = Mathf.Clamp(notValuableObject.healthCurrent, 0, notValuableObject.healthMax);
							playerAvatar.playerHealth.HurtOther(10, Vector3.zero, savingGrace: false, -1, hurtByHeal: true);
						}
					}
					healTimer = 0f;
				}
			}
			else
			{
				healTimer = 0f;
			}
		}
		if (grabArea.listOfAllGrabbers.Count > 0)
		{
			if (!healButtonState)
			{
				healButtonState = true;
				soundButtonPress.Play(physGrabObject.centerPoint);
				health.grabIconMaterial.SetColor(materialEmissionProperty, health.grabIconColorActive);
				health.grabIconMaterial.mainTextureOffset = new Vector2(0.5f, 0f);
				buttonSpring.springVelocity = -15f;
			}
			health.buttonTransform.localScale = new Vector3(1f, 1f, SemiFunc.SpringFloatGet(buttonSpring, 0.5f));
		}
		else
		{
			if (healButtonState)
			{
				healButtonState = false;
				soundButtonRelease.Play(physGrabObject.centerPoint);
				health.grabIconMaterial.SetColor(materialEmissionProperty, health.grabIconColorInactive);
				health.grabIconMaterial.mainTextureOffset = new Vector2(0f, 0f);
				buttonSpring.springVelocity = 20f;
			}
			health.buttonTransform.localScale = new Vector3(1f, 1f, SemiFunc.SpringFloatGet(buttonSpring, 1f));
		}
	}

	[PunRPC]
	private void HealthUpdateRPC(float _healthAmount, PhotonMessageInfo _info = default(PhotonMessageInfo))
	{
		//IL_0000: Unknown result type (might be due to invalid IL or missing references)
		if (SemiFunc.MasterOnlyRPC(_info))
		{
			healthAmountTarget = _healthAmount;
			healthFlashLerp = 0f;
		}
	}

	private void BlinkLogic()
	{
		//IL_01af: Unknown result type (might be due to invalid IL or missing references)
		//IL_01b5: Unknown result type (might be due to invalid IL or missing references)
		//IL_01cb: Unknown result type (might be due to invalid IL or missing references)
		//IL_01d0: Unknown result type (might be due to invalid IL or missing references)
		//IL_0187: Unknown result type (might be due to invalid IL or missing references)
		//IL_018c: Unknown result type (might be due to invalid IL or missing references)
		//IL_01a2: Unknown result type (might be due to invalid IL or missing references)
		//IL_01a7: Unknown result type (might be due to invalid IL or missing references)
		//IL_01e2: Unknown result type (might be due to invalid IL or missing references)
		//IL_0124: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f2: Unknown result type (might be due to invalid IL or missing references)
		if (blinking)
		{
			blinkTimer -= Time.deltaTime;
			if (blinkTimer <= 0f)
			{
				if (blinkState)
				{
					blinkTimer = blinkClass.blinkIntervalOn;
					if (blinkClass.type != BlinkType.Exploding)
					{
						blinkCount++;
					}
					if (blinkCount >= blinkClass.blinkCount)
					{
						blinking = false;
					}
					blinkState = false;
				}
				else
				{
					blinkTimer = blinkClass.blinkIntervalOff;
					if (!blinkClass.soundPlayOnce || blinkCount == 0)
					{
						if (blinkClass.type == BlinkType.Exploding)
						{
							blinkClass.sound.Pitch = 1f + explodingTime * 0.25f;
							blinkClass.sound.Play(physGrabObject.centerPoint);
						}
						else
						{
							blinkClass.sound.Play(physGrabObject.centerPoint);
						}
					}
					blinkState = true;
				}
				blinkMaterialColorLerp = 0f;
			}
		}
		if (blinkMaterialColorLerp < 1f)
		{
			blinkMaterialColorLerp += 15f * Time.deltaTime;
			if (blinkState)
			{
				blinkMaterialColor = Color.Lerp(blinkMaterialDefault, Color.black, blinkCurve.Evaluate(blinkMaterialColorLerp));
			}
			else
			{
				blinkMaterialColor = Color.Lerp(Color.black, blinkMaterialDefault, blinkCurve.Evaluate(blinkMaterialColorLerp));
			}
			blinkMaterial.SetColor(materialEmissionProperty, blinkMaterialColor);
		}
	}

	private void BlinkStart(BlinkType _type, bool _forced = false)
	{
		//IL_0049: Unknown result type (might be due to invalid IL or missing references)
		//IL_004f: Unknown result type (might be due to invalid IL or missing references)
		if (SemiFunc.IsMasterClientOrSingleplayer() && (_forced || !blinking || _type > blinkType))
		{
			if (SemiFunc.IsMultiplayer())
			{
				photonView.RPC("BlinkStartRPC", (RpcTarget)0, new object[1] { _type });
			}
			else
			{
				BlinkStartRPC(_type);
			}
		}
	}

	[PunRPC]
	private void BlinkStartRPC(BlinkType _type, PhotonMessageInfo _info = default(PhotonMessageInfo))
	{
		//IL_0000: Unknown result type (might be due to invalid IL or missing references)
		if (SemiFunc.MasterOnlyRPC(_info))
		{
			blinkType = _type;
			blinkClass = blinkSetups.Find((BlinkClass x) => x.type == blinkType);
			blinking = true;
			blinkState = false;
			blinkCount = 0;
			blinkTimer = 0f;
		}
	}

	private void ExtractionEnterLogic()
	{
		if (inExtraction != roomVolumeCheck.inExtractionPoint)
		{
			inExtraction = roomVolumeCheck.inExtractionPoint;
			if (inExtraction)
			{
				BlinkStart(BlinkType.Extraction);
			}
		}
	}

	public void Extract()
	{
		//IL_0022: Unknown result type (might be due to invalid IL or missing references)
		//IL_0028: Unknown result type (might be due to invalid IL or missing references)
		if (SemiFunc.IsMultiplayer())
		{
			photonView.RPC("ExtractRPC", (RpcTarget)0, Array.Empty<object>());
		}
		else
		{
			ExtractRPC();
		}
		physGrabObject.DestroyPhysGrabObject();
	}

	[PunRPC]
	private void ExtractRPC(PhotonMessageInfo _info = default(PhotonMessageInfo))
	{
		//IL_0000: Unknown result type (might be due to invalid IL or missing references)
		if (!SemiFunc.MasterOnlyRPC(_info) || !inExtraction)
		{
			return;
		}
		int count = RoundDirector.instance.cosmeticWorldObjectsExtracted.Count;
		int num = ValuableDirector.instance.CosmeticWorldObjectLevelLoopsClampedGet();
		if (ValuableDirector.instance.cosmeticWorldObjectDebug == ValuableDirector.CosmeticWorldObjectDebug.Normal && count > num)
		{
			if (!Debug.isDebugBuild)
			{
				return;
			}
			Debug.LogError((object)$"Attempted to extract more cosmetic boxes than expected. This will not work in release versions! [Extracted: {count}, Expected: {num}]");
		}
		CosmeticWorldObjectUI.instance.Add(rarity);
		RoundDirector.instance.CosmeticWorldObjectExtracted(rarity);
	}

	private void ExplodingLogic()
	{
		//IL_004d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0053: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b2: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b8: Unknown result type (might be due to invalid IL or missing references)
		if (SemiFunc.IsMasterClientOrSingleplayer())
		{
			if (!exploding && notValuableObject.healthCurrent <= 0)
			{
				if (SemiFunc.IsMultiplayer())
				{
					photonView.RPC("ExplodingSetRPC", (RpcTarget)0, new object[1] { true });
				}
				else
				{
					ExplodingSetRPC(_exploding: true);
				}
				BlinkStart(BlinkType.Exploding, _forced: true);
				explodingTimer = 4f;
			}
			if (exploding)
			{
				if (notValuableObject.healthCurrent > 1)
				{
					if (SemiFunc.IsMultiplayer())
					{
						photonView.RPC("ExplodingSetRPC", (RpcTarget)0, new object[1] { false });
					}
					else
					{
						ExplodingSetRPC(_exploding: false);
					}
				}
				else
				{
					notValuableObject.healthCurrent = 1;
					explodingTimer -= Time.deltaTime;
					if (explodingTimer <= 0f)
					{
						physGrabObject.impactDetector.DestroyObject();
					}
				}
			}
		}
		explodingTime += Time.deltaTime;
		soundExplodingLoop.PlayLoop(exploding, 5f, 5f, 0.75f + explodingTime * 0.1f);
	}

	[PunRPC]
	private void ExplodingSetRPC(bool _exploding, PhotonMessageInfo _info = default(PhotonMessageInfo))
	{
		//IL_0000: Unknown result type (might be due to invalid IL or missing references)
		//IL_002f: Unknown result type (might be due to invalid IL or missing references)
		if (!SemiFunc.MasterOnlyRPC(_info))
		{
			return;
		}
		exploding = _exploding;
		explodingTime = 0f;
		if (exploding)
		{
			soundExplodingStart.Play(physGrabObject.centerPoint);
			if (SemiFunc.Photosensitivity())
			{
				return;
			}
			{
				foreach (ParticleSystem item in particlesExploding)
				{
					item.Play();
				}
				return;
			}
		}
		foreach (ParticleSystem item2 in particlesExploding)
		{
			item2.Stop();
		}
	}

	private void TutorialLogic()
	{
		//IL_002a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0052: Unknown result type (might be due to invalid IL or missing references)
		//IL_005d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0062: Unknown result type (might be due to invalid IL or missing references)
		//IL_0067: Unknown result type (might be due to invalid IL or missing references)
		//IL_007d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0084: Unknown result type (might be due to invalid IL or missing references)
		if (!tutorialActive || !SemiFunc.PerSecond(5f, (Object)(object)this) || !discoverCustom.discovered || !SemiFunc.OnScreen(physGrabObject.centerPoint, 0.2f, 0.2f))
		{
			return;
		}
		Vector3 val = ((Component)SemiFunc.PlayerGetLocal().localCamera).transform.position - physGrabObject.centerPoint;
		RaycastHit val2 = default;
		if (!(val.magnitude > 8f) && !Physics.Raycast(physGrabObject.centerPoint, val.normalized, ref val2, val.magnitude, LayerMask.GetMask(new string[1] { "Default" })))
		{
			if (TutorialDirector.instance.TutorialSettingCheck(DataDirector.Setting.TutorialCosmeticWorldObject1, 1))
			{
				TutorialDirector.instance.ActivateTip("CosmeticWorldObject1", 0f, _interrupt: false, 7f, _scaleDown: false);
				TutorialDirector.instance.ScheduleTip("CosmeticWorldObject2", 7f, _interrupt: false, 7f, _scaleDown: false);
			}
			tutorialActive = false;
		}
	}

	public void OnBreakDestroy()
	{
		//IL_002a: Unknown result type (might be due to invalid IL or missing references)
		//IL_005c: Unknown result type (might be due to invalid IL or missing references)
		//IL_008e: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c0: Unknown result type (might be due to invalid IL or missing references)
		switch (rarity)
		{
		case SemiFunc.Rarity.Common:
			particleScriptExplosion.Spawn(physGrabObject.centerPoint, 0.3f, 10, 30);
			break;
		case SemiFunc.Rarity.Uncommon:
			particleScriptExplosion.Spawn(physGrabObject.centerPoint, 0.5f, 20, 50);
			break;
		case SemiFunc.Rarity.Rare:
			particleScriptExplosion.Spawn(physGrabObject.centerPoint, 0.75f, 30, 75);
			break;
		case SemiFunc.Rarity.UltraRare:
			particleScriptExplosion.Spawn(physGrabObject.centerPoint, 1f, 40, 100);
			break;
		}
	}

	public CosmeticWorldObject()
	{
		//IL_0021: Unknown result type (might be due to invalid IL or missing references)
		//IL_0026: Unknown result type (might be due to invalid IL or missing references)
		//IL_002c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0031: Unknown result type (might be due to invalid IL or missing references)
	}
}
