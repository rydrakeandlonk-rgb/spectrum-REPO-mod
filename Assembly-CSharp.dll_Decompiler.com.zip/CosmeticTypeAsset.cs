using System.Collections.Generic;
using UnityEngine;

[CreateAssetMenu(fileName = "Cosmetic Type - _____", menuName = "Cosmetics/Cosmetic Type", order = 1)]
public class CosmeticTypeAsset : ScriptableObject
{
	public SemiFunc.CosmeticType type;

	public string typeName = "";

	public LocalizedAsset localizedName;

	[Space]
	public bool meshSwitch;

	public bool canEquipMultiple;

	[Space]
	[Range(0f, 1f)]
	public float equipLerpStart = 0.2f;

	[Space]
	public Sprite defaultIcon;

	public List<CosmeticCustomCondition.Type> customTypeList;

	[Space]
	public List<SemiFunc.CosmeticType> disabledTypeList;

	public List<CosmeticCustomCondition.Type> disabledCustomTypeList;

	private IEnumerable<CosmeticCustomCondition.Type> GetCosmeticCustomConditionTypes()
	{
		return CosmeticCustomCondition.GetTypes();
	}

	private IEnumerable<SemiFunc.CosmeticType> GetCosmeticTypes()
	{
		return SemiFunc.CosmeticGetTypes();
	}
}
