using UnityEngine;

public class MenuSelectionBoxColor : MonoBehaviour
{
	public Color colorIdle = new Color(0.08f, 0.2f, 0.4f, 0.75f);

	public Color colorMoving = new Color(0.2f, 0.5f, 1f, 1f);

	public MenuSelectionBoxColor()
	{
		//IL_0015: Unknown result type (might be due to invalid IL or missing references)
		//IL_001a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0034: Unknown result type (might be due to invalid IL or missing references)
		//IL_0039: Unknown result type (might be due to invalid IL or missing references)
	}
}
