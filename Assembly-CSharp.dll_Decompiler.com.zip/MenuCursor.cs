using UnityEngine;

public class MenuCursor : MonoBehaviour
{
	private float showTimer;

	private float hideTimer;

	private GameObject mesh;

	public static MenuCursor instance;

	private float overridePosTimer;

	[RuntimeInitializeOnLoadMethod(/*Could not decode attribute arguments.*/)]
	private static void RuntimeInitializeOnLoad()
	{
		instance = null;
	}

	private void Start()
	{
		//IL_001d: Unknown result type (might be due to invalid IL or missing references)
		mesh = ((Component)((Component)this).transform.GetChild(0)).gameObject;
		((Component)this).transform.localScale = Vector3.zero;
		mesh.SetActive(false);
		instance = this;
	}

	public void OverridePosition(Vector3 _position)
	{
		//IL_0006: Unknown result type (might be due to invalid IL or missing references)
		//IL_000c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0017: Unknown result type (might be due to invalid IL or missing references)
		((Component)this).transform.localPosition = new Vector3(_position.x, _position.y, 0f);
		overridePosTimer = 0.1f;
	}

	private void Update()
	{
		//IL_003d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0044: Unknown result type (might be due to invalid IL or missing references)
		//IL_0049: Unknown result type (might be due to invalid IL or missing references)
		//IL_0050: Unknown result type (might be due to invalid IL or missing references)
		//IL_0056: Unknown result type (might be due to invalid IL or missing references)
		//IL_0061: Unknown result type (might be due to invalid IL or missing references)
		//IL_00fc: Unknown result type (might be due to invalid IL or missing references)
		//IL_0101: Unknown result type (might be due to invalid IL or missing references)
		//IL_0111: Unknown result type (might be due to invalid IL or missing references)
		//IL_0121: Unknown result type (might be due to invalid IL or missing references)
		//IL_0126: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b1: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b6: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c6: Unknown result type (might be due to invalid IL or missing references)
		if (hideTimer > 0f)
		{
			hideTimer = Mathf.Max(0f, hideTimer - Time.unscaledDeltaTime);
			Hide();
			return;
		}
		if (overridePosTimer <= 0f)
		{
			if ((int)Cursor.lockState == 0)
			{
				Vector2 val = SemiFunc.UIMousePosToUIPos();
				((Component)this).transform.localPosition = new Vector3(val.x, val.y, 0f);
			}
		}
		else
		{
			overridePosTimer -= Time.deltaTime;
		}
		if (showTimer > 0f)
		{
			if (!mesh.activeSelf)
			{
				mesh.SetActive(true);
			}
			((Component)this).transform.localScale = Vector3.Lerp(((Component)this).transform.localScale, Vector3.one, Time.deltaTime * 30f);
			showTimer -= Time.deltaTime;
		}
		else if (mesh.activeSelf)
		{
			((Component)this).transform.localScale = Vector3.Lerp(((Component)this).transform.localScale, Vector3.zero, Time.deltaTime * 30f);
			Vector3 localScale = ((Component)this).transform.localScale;
			if (localScale.magnitude < 0.1f && mesh.activeSelf)
			{
				mesh.SetActive(false);
			}
		}
	}

	public void Show()
	{
		showTimer = 0.01f;
	}

	public void OverrideHide(float time = 0.1f)
	{
		hideTimer = Mathf.Max(hideTimer, time);
		Hide();
	}

	public void OverrideHideReset()
	{
		hideTimer = 0f;
	}

	private void Hide()
	{
		//IL_0011: Unknown result type (might be due to invalid IL or missing references)
		showTimer = 0f;
		((Component)this).transform.localScale = Vector3.zero;
		if (Object.op_Implicit((Object)(object)mesh))
		{
			mesh.SetActive(false);
		}
	}
}
