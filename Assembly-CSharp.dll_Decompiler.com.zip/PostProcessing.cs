using System.Collections;
using UnityEngine;
using UnityEngine.Rendering.PostProcessing;

public class PostProcessing : MonoBehaviour
{
	public static PostProcessing Instance;

	private bool setupDone;

	public PostProcessVolume volume;

	internal Grain grain;

	private float grainDisableTimer;

	internal Bloom bloom;

	private float bloomDisableTimer;

	private float bloomIntensity;

	private float bloomThreshold;

	internal ColorGrading colorGrading;

	private float colorGradingSaturation;

	private float colorGradingContrast;

	internal Vignette vignette;

	private Color vignetteColor;

	private float vignetteIntensity;

	private float vignetteSmoothness;

	internal MotionBlur motionBlur;

	internal LensDistortion lensDistortion;

	private float lensDistortionIntensity;

	internal ChromaticAberration chromaticAberration;

	public AnimationCurve introCurve;

	public float introSpeed;

	private float introLerp;

	private float motionBlurDefault;

	private float bloomDefault;

	private float grainIntensityDefault;

	private float grainSizeDefault;

	[Space]
	private bool lensDistortionOverrideActive;

	private float lensDistortionOverrideLerp;

	private float lensDistortionOverrideTimer;

	private float lensDistortionOverrideSpeedIn;

	private float lensDistortionOverrideSpeedOut;

	private float lensDistortionOverrideIntensity;

	private GameObject lensDistortionOverrideObject;

	private bool vignetteOverrideActive;

	private float vignetteOverrideLerp;

	private float vignetteOverrideTimer;

	private float vignetteOverrideSpeedIn;

	private float vignetteOverrideSpeedOut;

	private Color vignetteOverrideColor;

	private float vignetteOverrideIntensity;

	private float vignetteOverrideSmoothness;

	private GameObject vignetteOverrideObject;

	private int vignetteOverridePriority = 999;

	private bool saturationOverrideActive;

	private float saturationOverrideLerp;

	private float saturationOverrideTimer;

	private float saturationOverrideSpeedIn;

	private float saturationOverrideSpeedOut;

	private float saturationOverrideAmount;

	private GameObject saturationOverrideObject;

	private int saturationOverridePriority = 999;

	private bool contrastOverrideActive;

	private float contrastOverrideLerp;

	private float contrastOverrideTimer;

	private float contrastOverrideSpeedIn;

	private float contrastOverrideSpeedOut;

	private float contrastOverrideAmount;

	private GameObject contrastOverrideObject;

	private int contrastOverridePriority = 999;

	private bool grainIntensityOverrideActive;

	private float grainIntensityOverrideLerp;

	private float grainIntensityOverrideTimer;

	private float grainIntensityOverrideSpeedIn;

	private float grainIntensityOverrideSpeedOut;

	private float grainIntensityOverrideAmount;

	private GameObject grainIntensityOverrideObject;

	private bool bloomOverrideActive;

	private float bloomOverrideLerp;

	private float bloomOverrideTimer;

	private float bloomOverrideSpeedIn;

	private float bloomOverrideSpeedOut;

	private float bloomOverrideIntensity;

	private float bloomOverrideThreshold;

	private GameObject bloomOverrideObject;

	private int bloomOverridePriority = 999;

	[RuntimeInitializeOnLoadMethod(/*Could not decode attribute arguments.*/)]
	private static void RuntimeInitializeOnLoad()
	{
		Instance = null;
	}

	private void Awake()
	{
		Instance = this;
		volume.profile.TryGetSettings<Grain>(ref grain);
		grainSizeDefault = ((ParameterOverride<float>)(object)grain.size).value;
		grainIntensityDefault = ((ParameterOverride<float>)(object)grain.intensity).value;
		((ParameterOverride<float>)(object)grain.intensity).value = 1f;
		volume.profile.TryGetSettings<MotionBlur>(ref motionBlur);
		motionBlurDefault = ((ParameterOverride<float>)(object)motionBlur.shutterAngle).value;
		volume.profile.TryGetSettings<LensDistortion>(ref lensDistortion);
		volume.profile.TryGetSettings<Bloom>(ref bloom);
		volume.profile.TryGetSettings<ColorGrading>(ref colorGrading);
		volume.profile.TryGetSettings<Vignette>(ref vignette);
		volume.profile.TryGetSettings<ChromaticAberration>(ref chromaticAberration);
	}

	private void Update()
	{
		//IL_00c3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c8: Unknown result type (might be due to invalid IL or missing references)
		//IL_01e2: Unknown result type (might be due to invalid IL or missing references)
		//IL_01e3: Unknown result type (might be due to invalid IL or missing references)
		//IL_0166: Unknown result type (might be due to invalid IL or missing references)
		//IL_0168: Unknown result type (might be due to invalid IL or missing references)
		//IL_0173: Unknown result type (might be due to invalid IL or missing references)
		//IL_0178: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ef: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f1: Unknown result type (might be due to invalid IL or missing references)
		//IL_00fc: Unknown result type (might be due to invalid IL or missing references)
		//IL_0101: Unknown result type (might be due to invalid IL or missing references)
		if (!setupDone)
		{
			return;
		}
		float num = lensDistortionIntensity;
		if (lensDistortionOverrideActive)
		{
			num = Mathf.Lerp(num, lensDistortionOverrideIntensity, lensDistortionOverrideLerp);
			if (lensDistortionOverrideTimer > 0f)
			{
				lensDistortionOverrideLerp += lensDistortionOverrideSpeedIn * Time.deltaTime;
				lensDistortionOverrideLerp = Mathf.Clamp01(lensDistortionOverrideLerp);
				lensDistortionOverrideTimer -= Time.deltaTime;
			}
			else
			{
				lensDistortionOverrideLerp -= lensDistortionOverrideSpeedOut * Time.deltaTime;
				if (lensDistortionOverrideLerp <= 0f)
				{
					lensDistortionOverrideActive = false;
					lensDistortionOverrideLerp = 0f;
				}
			}
		}
		((ParameterOverride<float>)(object)lensDistortion.intensity).value = num;
		Color val = vignetteColor;
		float num2 = vignetteIntensity;
		float num3 = vignetteSmoothness;
		if (vignetteOverrideActive)
		{
			if (vignetteOverrideTimer > 0f)
			{
				val = Color.Lerp(val, vignetteOverrideColor, vignetteOverrideLerp);
				num2 = Mathf.Lerp(num2, vignetteOverrideIntensity, vignetteOverrideLerp);
				num3 = Mathf.Lerp(num3, vignetteOverrideSmoothness, vignetteOverrideLerp);
				vignetteOverrideLerp += vignetteOverrideSpeedIn * Time.deltaTime;
				vignetteOverrideLerp = Mathf.Clamp01(vignetteOverrideLerp);
				vignetteOverrideTimer -= Time.deltaTime;
			}
			else
			{
				val = Color.Lerp(val, vignetteOverrideColor, vignetteOverrideLerp);
				num2 = Mathf.Lerp(num2, vignetteOverrideIntensity, vignetteOverrideLerp);
				num3 = Mathf.Lerp(num3, vignetteOverrideSmoothness, vignetteOverrideLerp);
				vignetteOverrideLerp -= vignetteOverrideSpeedOut * Time.deltaTime;
				if (vignetteOverrideLerp <= 0f)
				{
					vignetteOverrideActive = false;
					vignetteOverrideLerp = 0f;
				}
			}
		}
		((ParameterOverride<Color>)(object)vignette.color).value = val;
		((ParameterOverride<float>)(object)vignette.intensity).value = num2;
		((ParameterOverride<float>)(object)vignette.smoothness).value = num3;
		if (saturationOverrideActive)
		{
			if (saturationOverrideTimer > 0f)
			{
				((ParameterOverride<float>)(object)colorGrading.saturation).value = Mathf.Lerp(colorGradingSaturation, saturationOverrideAmount, saturationOverrideLerp);
				saturationOverrideLerp += saturationOverrideSpeedIn * Time.deltaTime;
				saturationOverrideLerp = Mathf.Clamp01(saturationOverrideLerp);
				saturationOverrideTimer -= Time.deltaTime;
			}
			else
			{
				((ParameterOverride<float>)(object)colorGrading.saturation).value = Mathf.Lerp(colorGradingSaturation, saturationOverrideAmount, saturationOverrideLerp);
				saturationOverrideLerp -= saturationOverrideSpeedOut * Time.deltaTime;
				if (saturationOverrideLerp <= 0f)
				{
					((ParameterOverride<float>)(object)colorGrading.saturation).value = colorGradingSaturation;
					saturationOverrideActive = false;
					saturationOverrideLerp = 0f;
				}
			}
		}
		if (contrastOverrideActive)
		{
			if (contrastOverrideTimer > 0f)
			{
				((ParameterOverride<float>)(object)colorGrading.contrast).value = Mathf.Lerp(colorGradingContrast, contrastOverrideAmount, contrastOverrideLerp);
				contrastOverrideLerp += contrastOverrideSpeedIn * Time.deltaTime;
				contrastOverrideLerp = Mathf.Clamp01(contrastOverrideLerp);
				contrastOverrideTimer -= Time.deltaTime;
			}
			else
			{
				((ParameterOverride<float>)(object)colorGrading.contrast).value = Mathf.Lerp(colorGradingContrast, contrastOverrideAmount, contrastOverrideLerp);
				contrastOverrideLerp -= contrastOverrideSpeedOut * Time.deltaTime;
				if (contrastOverrideLerp <= 0f)
				{
					((ParameterOverride<float>)(object)colorGrading.contrast).value = colorGradingContrast;
					contrastOverrideActive = false;
					contrastOverrideLerp = 0f;
				}
			}
		}
		float num4 = bloomIntensity;
		float num5 = bloomThreshold;
		if (bloomOverrideActive)
		{
			if (!((PostProcessEffectSettings)bloom).active)
			{
				((PostProcessEffectSettings)bloom).active = true;
			}
			num4 = Mathf.Lerp(num4, bloomOverrideIntensity, bloomOverrideLerp);
			num5 = Mathf.Lerp(num5, bloomOverrideThreshold, bloomOverrideLerp);
			if (bloomOverrideTimer > 0f)
			{
				bloomOverrideLerp += bloomOverrideSpeedIn * Time.deltaTime;
				bloomOverrideLerp = Mathf.Clamp01(bloomOverrideLerp);
				bloomOverrideTimer -= Time.deltaTime;
			}
			else
			{
				bloomOverrideLerp -= bloomOverrideSpeedOut * Time.deltaTime;
				if (bloomOverrideLerp <= 0f)
				{
					if (DataDirector.instance.SettingValueFetch(DataDirector.Setting.Bloom) == 0)
					{
						((PostProcessEffectSettings)bloom).active = false;
					}
					bloomOverrideActive = false;
					bloomOverrideLerp = 0f;
				}
			}
		}
		((ParameterOverride<float>)(object)bloom.intensity).value = num4;
		((ParameterOverride<float>)(object)bloom.threshold).value = num5;
		if (bloomDisableTimer > 0f)
		{
			bloomDisableTimer -= Time.deltaTime;
			if (bloomDisableTimer <= 0f && DataDirector.instance.SettingValueFetch(DataDirector.Setting.Bloom) == 1)
			{
				((PostProcessEffectSettings)bloom).active = true;
			}
		}
		if (grainIntensityOverrideActive)
		{
			if (grainIntensityOverrideTimer > 0f)
			{
				((ParameterOverride<float>)(object)grain.intensity).value = Mathf.Lerp(grainIntensityDefault, grainIntensityOverrideAmount, grainIntensityOverrideLerp);
				grainIntensityOverrideLerp += grainIntensityOverrideSpeedIn * Time.deltaTime;
				grainIntensityOverrideLerp = Mathf.Clamp01(grainIntensityOverrideLerp);
				grainIntensityOverrideTimer -= Time.deltaTime;
			}
			else
			{
				((ParameterOverride<float>)(object)grain.intensity).value = Mathf.Lerp(grainIntensityDefault, grainIntensityOverrideAmount, grainIntensityOverrideLerp);
				grainIntensityOverrideLerp -= grainIntensityOverrideSpeedOut * Time.deltaTime;
				if (grainIntensityOverrideLerp <= 0f)
				{
					((ParameterOverride<float>)(object)grain.intensity).value = grainIntensityDefault;
					grainIntensityOverrideActive = false;
					grainIntensityOverrideLerp = 0f;
				}
			}
		}
		if (grainDisableTimer > 0f)
		{
			grainDisableTimer -= Time.deltaTime;
			if (grainDisableTimer <= 0f && DataDirector.instance.SettingValueFetch(DataDirector.Setting.Grain) == 1)
			{
				((PostProcessEffectSettings)grain).active = true;
			}
		}
	}

	public void SpectateSet()
	{
		((ParameterOverride<float>)(object)motionBlur.shutterAngle).value = 1f;
	}

	public void SpectateReset()
	{
		((ParameterOverride<float>)(object)motionBlur.shutterAngle).value = motionBlurDefault;
	}

	public void Setup()
	{
		//IL_0034: Unknown result type (might be due to invalid IL or missing references)
		//IL_0039: Unknown result type (might be due to invalid IL or missing references)
		//IL_011e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0123: Unknown result type (might be due to invalid IL or missing references)
		//IL_0134: Unknown result type (might be due to invalid IL or missing references)
		//IL_0139: Unknown result type (might be due to invalid IL or missing references)
		((ParameterOverride<float>)(object)colorGrading.temperature).value = LevelGenerator.Instance.Level.ColorTemperature;
		((ParameterOverride<Color>)(object)colorGrading.colorFilter).value = LevelGenerator.Instance.Level.ColorFilter;
		colorGradingSaturation = ((ParameterOverride<float>)(object)colorGrading.saturation).value;
		colorGradingContrast = ((ParameterOverride<float>)(object)colorGrading.contrast).value;
		((ParameterOverride<float>)(object)bloom.intensity).value = LevelGenerator.Instance.Level.BloomIntensity;
		bloomIntensity = ((ParameterOverride<float>)(object)bloom.intensity).value;
		((ParameterOverride<float>)(object)bloom.threshold).value = LevelGenerator.Instance.Level.BloomThreshold;
		bloomThreshold = ((ParameterOverride<float>)(object)bloom.threshold).value;
		((ParameterOverride<float>)(object)lensDistortion.intensity).value = LevelGenerator.Instance.Level.LensDistortionIntensity;
		lensDistortionIntensity = ((ParameterOverride<float>)(object)lensDistortion.intensity).value;
		((ParameterOverride<Color>)(object)vignette.color).value = LevelGenerator.Instance.Level.VignetteColor;
		vignetteColor = ((ParameterOverride<Color>)(object)vignette.color).value;
		((ParameterOverride<float>)(object)vignette.intensity).value = LevelGenerator.Instance.Level.VignetteIntensity;
		vignetteIntensity = ((ParameterOverride<float>)(object)vignette.intensity).value;
		((ParameterOverride<float>)(object)vignette.smoothness).value = LevelGenerator.Instance.Level.VignetteSmoothness;
		vignetteSmoothness = ((ParameterOverride<float>)(object)vignette.smoothness).value;
		((MonoBehaviour)this).StartCoroutine(Intro());
		setupDone = true;
	}

	private IEnumerator Intro()
	{
		while (GameDirector.instance.currentState < GameDirector.gameState.Main)
		{
			yield return (object)new WaitForSeconds(0.1f);
		}
		while (introLerp < 1f)
		{
			((ParameterOverride<float>)(object)grain.intensity).value = Mathf.Lerp(0.8f, grainIntensityDefault, introCurve.Evaluate(introLerp));
			((ParameterOverride<float>)(object)grain.size).value = Mathf.Lerp(1.5f, grainSizeDefault, introCurve.Evaluate(introLerp));
			introLerp += introSpeed * Time.deltaTime;
			yield return null;
		}
	}

	public void LensDistortionOverride(float _intensity, float _speedIn, float _speedOut, float _time, GameObject _obj)
	{
		if (!lensDistortionOverrideActive || !((Object)(object)_obj != (Object)(object)lensDistortionOverrideObject))
		{
			lensDistortionOverrideActive = true;
			lensDistortionOverrideObject = _obj;
			lensDistortionOverrideTimer = _time;
			lensDistortionOverrideSpeedIn = _speedIn;
			lensDistortionOverrideSpeedOut = _speedOut;
			lensDistortionOverrideIntensity = _intensity;
		}
	}

	public void VignetteOverride(Color _color, float _intensity, float _smoothness, float _speedIn, float _speedOut, float _time, GameObject _obj, int _priority = 999)
	{
		//IL_0065: Unknown result type (might be due to invalid IL or missing references)
		//IL_0066: Unknown result type (might be due to invalid IL or missing references)
		if (!vignetteOverrideActive || (_priority <= vignetteOverridePriority && (_priority != vignetteOverridePriority || !((Object)(object)_obj != (Object)(object)vignetteOverrideObject))))
		{
			_smoothness = Mathf.Clamp01(_smoothness);
			vignetteOverrideActive = true;
			vignetteOverrideObject = _obj;
			vignetteOverridePriority = _priority;
			vignetteOverrideTimer = _time;
			vignetteOverrideSpeedIn = _speedIn;
			vignetteOverrideSpeedOut = _speedOut;
			vignetteOverrideColor = _color;
			vignetteOverrideIntensity = _intensity;
			vignetteOverrideSmoothness = _smoothness;
		}
	}

	public void BloomOverride(float _intensity, float _threshold, float _speedIn, float _speedOut, float _time, GameObject _obj, int _priority = 999)
	{
		if (!bloomOverrideActive || (_priority <= bloomOverridePriority && (_priority != bloomOverridePriority || !((Object)(object)_obj != (Object)(object)bloomOverrideObject))))
		{
			_threshold = Mathf.Clamp01(_threshold);
			bloomOverrideActive = true;
			bloomOverrideObject = _obj;
			bloomOverridePriority = _priority;
			bloomOverrideTimer = _time;
			bloomOverrideSpeedIn = _speedIn;
			bloomOverrideSpeedOut = _speedOut;
			bloomOverrideIntensity = _intensity;
			bloomOverrideThreshold = _threshold;
		}
	}

	public void SaturationOverride(float _amount, float _speedIn, float _speedOut, float _time, GameObject _obj, int _priority = 999)
	{
		if (!saturationOverrideActive || (_priority <= saturationOverridePriority && (_priority != saturationOverridePriority || !((Object)(object)_obj != (Object)(object)saturationOverrideObject))))
		{
			saturationOverrideActive = true;
			saturationOverrideObject = _obj;
			saturationOverridePriority = _priority;
			saturationOverrideTimer = _time;
			saturationOverrideSpeedIn = _speedIn;
			saturationOverrideSpeedOut = _speedOut;
			saturationOverrideAmount = _amount;
		}
	}

	public void ContrastOverride(float _amount, float _speedIn, float _speedOut, float _time, GameObject _obj, int _priority = 999)
	{
		if (!contrastOverrideActive || (_priority <= contrastOverridePriority && (_priority != contrastOverridePriority || !((Object)(object)_obj != (Object)(object)contrastOverrideObject))))
		{
			contrastOverrideActive = true;
			contrastOverrideObject = _obj;
			contrastOverridePriority = _priority;
			contrastOverrideTimer = _time;
			contrastOverrideSpeedIn = _speedIn;
			contrastOverrideSpeedOut = _speedOut;
			contrastOverrideAmount = _amount;
		}
	}

	public void ResolutionOverride(float _resolutionMultiplier = 0.2f, float _time = 0.2f)
	{
		RenderTextureMain.instance.ChangeResolution(RenderTextureMain.instance.textureWidthOriginal * _resolutionMultiplier, RenderTextureMain.instance.textureHeightOriginal * _resolutionMultiplier, _time);
	}

	public void GrainIntensityOverride(float _amount, float _speedIn, float _speedOut, float _time, GameObject _obj)
	{
		if (!grainIntensityOverrideActive || !((Object)(object)_obj != (Object)(object)grainIntensityOverrideObject))
		{
			grainIntensityOverrideActive = true;
			grainIntensityOverrideObject = _obj;
			grainIntensityOverrideTimer = _time;
			grainIntensityOverrideSpeedIn = _speedIn;
			grainIntensityOverrideSpeedOut = _speedOut;
			grainIntensityOverrideAmount = _amount;
		}
	}

	public void BloomDisable(float _time)
	{
		bloomDisableTimer = _time;
		((PostProcessEffectSettings)bloom).active = false;
	}

	public void GrainDisable(float _time)
	{
		grainDisableTimer = _time;
		((PostProcessEffectSettings)grain).active = false;
	}
}
