using Photon.Pun;
using UnityEngine;

public class ExtractionHalloweenPumpkin : MonoBehaviour, IPunInstantiateMagicCallback
{
	public int defaultValue = 250;

	internal float spawnUpVelocity;

	private Rigidbody rb;

	private void Awake()
	{
		rb = ((Component)this).GetComponent<Rigidbody>();
		ValueSet(defaultValue);
	}

	private void FixedUpdate()
	{
		//IL_0035: Unknown result type (might be due to invalid IL or missing references)
		//IL_0040: Unknown result type (might be due to invalid IL or missing references)
		if (!(spawnUpVelocity <= 0f))
		{
			if (!SemiFunc.IsMasterClientOrSingleplayer())
			{
				spawnUpVelocity = 0f;
			}
			else if (!rb.isKinematic)
			{
				rb.AddForce(Vector3.up * spawnUpVelocity, (ForceMode)2);
				spawnUpVelocity = 0f;
			}
		}
	}

	public void OnPhotonInstantiate(PhotonMessageInfo _info)
	{
		//IL_0091: Unknown result type (might be due to invalid IL or missing references)
		object[] instantiationData = ((Component)this).GetComponent<PhotonView>().InstantiationData;
		if (instantiationData == null || instantiationData.Length != 6 || !(instantiationData[3] is int value))
		{
			return;
		}
		ValueSet(value);
		if (instantiationData[4] is int num && instantiationData[5] is double acceptedTime)
		{
			PhotonView val = PhotonView.Find(num);
			ExtractionHalloweenTower extractionHalloweenTower = (Object.op_Implicit((Object)(object)val) ? ((Component)val).GetComponent<ExtractionHalloweenTower>() : null);
			if (Object.op_Implicit((Object)(object)extractionHalloweenTower))
			{
				extractionHalloweenTower.RewardPumpkinReceived(((Component)this).GetComponent<ValuableObject>(), value, acceptedTime, _info);
			}
		}
	}

	internal void ValueSet(int _value)
	{
		ValuableObject component = ((Component)this).GetComponent<ValuableObject>();
		component.dollarValueOverride = Mathf.Max(1, _value);
		component.halloweenTowerRewarded = true;
	}
}
