using System.Collections.Generic;
using System.Linq;
using UnityEngine;
using UnityEngine.UI;

public class MenuElementCosmeticButtonPopup : MonoBehaviour
{
	public GameObject mainBgObj;

	public GameObject dropdownObj;

	public MenuButton toggleButton;

	private bool toggleButtonHovered;

	public SemiUI toggleSemiUI;

	internal List<MenuButton> dropdownButtons = new List<MenuButton>();

	private List<MenuButton> orderedDropdownButtons = new List<MenuButton>();

	private MenuButton hoveredDropdownButton;

	internal Selectable selectOnDownWhenClosed;

	private float toggleLerp = 1f;

	public AnimationCurve dropdownIntroCurve;

	public AnimationCurve dropdownOutroCurve;

	public AnimationCurve dropdownScaleIntroCurve;

	public AnimationCurve dropdownScaleOutroCurve;

	public AnimationCurve mainBgIntroCurve;

	public AnimationCurve mainBgOutroCurve;

	internal bool dropdownActive = true;

	private float dropdownPositionY;

	private float dropdownScaleY;

	[Space]
	public Sound soundIntro;

	public Sound soundOutro;

	private void Awake()
	{
		MenuButton[] componentsInChildren = dropdownObj.GetComponentsInChildren<MenuButton>(true);
		foreach (MenuButton item in componentsInChildren)
		{
			dropdownButtons.Add(item);
		}
	}

	private void Start()
	{
		SetupDropdownNavigation();
	}

	private void SetupDropdownNavigation()
	{
		//IL_006f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0074: Unknown result type (might be due to invalid IL or missing references)
		//IL_00bd: Unknown result type (might be due to invalid IL or missing references)
		//IL_0122: Unknown result type (might be due to invalid IL or missing references)
		//IL_0127: Unknown result type (might be due to invalid IL or missing references)
		//IL_0136: Unknown result type (might be due to invalid IL or missing references)
		orderedDropdownButtons = dropdownButtons.Where((MenuButton b) => Object.op_Implicit((Object)(object)b) && Object.op_Implicit((Object)(object)b.menuSelectableElement)).OrderBy((MenuButton b) =>
		{
			//IL_000b: Unknown result type (might be due to invalid IL or missing references)
			return ((Transform)b.menuSelectableElement.rectTransform).position.x;
		}).ToList();
		for (int num = 0; num < orderedDropdownButtons.Count; num++)
		{
			MenuSelectableElement menuSelectableElement = orderedDropdownButtons[num].menuSelectableElement;
			Navigation navigation = ((Selectable)menuSelectableElement).navigation;
			if (num > 0)
			{
				navigation.selectOnLeft = (Selectable)(object)orderedDropdownButtons[num - 1].menuSelectableElement;
			}
			if (num < orderedDropdownButtons.Count - 1)
			{
				navigation.selectOnRight = (Selectable)(object)orderedDropdownButtons[num + 1].menuSelectableElement;
			}
			((Selectable)menuSelectableElement).navigation = navigation;
		}
		MenuSelectableElement menuSelectableElement2 = (Object.op_Implicit((Object)(object)toggleButton) ? toggleButton.menuSelectableElement : null);
		if (!Object.op_Implicit((Object)(object)menuSelectableElement2) || orderedDropdownButtons.Count == 0)
		{
			return;
		}
		foreach (MenuButton orderedDropdownButton in orderedDropdownButtons)
		{
			Navigation navigation2 = ((Selectable)orderedDropdownButton.menuSelectableElement).navigation;
			navigation2.selectOnUp = (Selectable)(object)menuSelectableElement2;
			((Selectable)orderedDropdownButton.menuSelectableElement).navigation = navigation2;
		}
		ToggleDownNavigationUpdate();
	}

	private void ToggleDownNavigationUpdate()
	{
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0064: Unknown result type (might be due to invalid IL or missing references)
		//IL_006e: Unknown result type (might be due to invalid IL or missing references)
		MenuSelectableElement menuSelectableElement = (Object.op_Implicit((Object)(object)toggleButton) ? toggleButton.menuSelectableElement : null);
		if (Object.op_Implicit((Object)(object)menuSelectableElement))
		{
			Selectable val = (Selectable)(object)((dropdownActive && orderedDropdownButtons.Count > 0) ? orderedDropdownButtons[0].menuSelectableElement : ((MenuSelectableElement)(object)selectOnDownWhenClosed));
			if (Object.op_Implicit((Object)(object)val))
			{
				Navigation navigation = ((Selectable)menuSelectableElement).navigation;
				navigation.selectOnDown = val;
				((Selectable)menuSelectableElement).navigation = navigation;
			}
		}
	}

	private void Update()
	{
		//IL_026f: Unknown result type (might be due to invalid IL or missing references)
		//IL_027e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0294: Unknown result type (might be due to invalid IL or missing references)
		//IL_0299: Unknown result type (might be due to invalid IL or missing references)
		//IL_02b9: Unknown result type (might be due to invalid IL or missing references)
		//IL_02c8: Unknown result type (might be due to invalid IL or missing references)
		//IL_02d8: Unknown result type (might be due to invalid IL or missing references)
		//IL_02e7: Unknown result type (might be due to invalid IL or missing references)
		//IL_02fd: Unknown result type (might be due to invalid IL or missing references)
		//IL_0302: Unknown result type (might be due to invalid IL or missing references)
		//IL_0322: Unknown result type (might be due to invalid IL or missing references)
		//IL_0332: Unknown result type (might be due to invalid IL or missing references)
		//IL_0342: Unknown result type (might be due to invalid IL or missing references)
		//IL_0351: Unknown result type (might be due to invalid IL or missing references)
		//IL_0367: Unknown result type (might be due to invalid IL or missing references)
		//IL_036c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0125: Unknown result type (might be due to invalid IL or missing references)
		//IL_0134: Unknown result type (might be due to invalid IL or missing references)
		//IL_014a: Unknown result type (might be due to invalid IL or missing references)
		//IL_014f: Unknown result type (might be due to invalid IL or missing references)
		//IL_016f: Unknown result type (might be due to invalid IL or missing references)
		//IL_017e: Unknown result type (might be due to invalid IL or missing references)
		//IL_018e: Unknown result type (might be due to invalid IL or missing references)
		//IL_019d: Unknown result type (might be due to invalid IL or missing references)
		//IL_01b3: Unknown result type (might be due to invalid IL or missing references)
		//IL_01b8: Unknown result type (might be due to invalid IL or missing references)
		//IL_01d8: Unknown result type (might be due to invalid IL or missing references)
		//IL_01e8: Unknown result type (might be due to invalid IL or missing references)
		//IL_01f8: Unknown result type (might be due to invalid IL or missing references)
		//IL_0207: Unknown result type (might be due to invalid IL or missing references)
		//IL_021d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0222: Unknown result type (might be due to invalid IL or missing references)
		if (toggleButton.hovering != toggleButtonHovered)
		{
			toggleButtonHovered = toggleButton.hovering;
			if (toggleButtonHovered)
			{
				toggleSemiUI.SemiUISpringShakeY(5f, 2f, 0.25f);
			}
		}
		if (dropdownActive && (SemiFunc.InputMode() == InputModes.Gamepad || MenuManager.instance.isKeyboardNavigating) && MenuManager.instance.currentMenuPageIndex == MenuPageIndex.Cosmetics)
		{
			string _selectedMenuID = MenuManager.instance.lastHoverMenuID;
			if (!string.IsNullOrEmpty(_selectedMenuID) && toggleButton.MenuID != _selectedMenuID && !dropdownButtons.Any((MenuButton x) => Object.op_Implicit((Object)(object)x) && x.MenuID == _selectedMenuID))
			{
				SetState(_state: false);
			}
		}
		if (toggleLerp < 1f)
		{
			if (dropdownActive)
			{
				toggleLerp += 1.5f * Time.deltaTime;
				toggleLerp = Mathf.Clamp01(toggleLerp);
				mainBgObj.transform.localScale = Vector2.op_Implicit(Vector2.LerpUnclamped(new Vector2(0.7f, 0.7f), new Vector2(1f, 1f), mainBgIntroCurve.Evaluate(toggleLerp)));
				dropdownObj.transform.localPosition = Vector2.op_Implicit(Vector2.LerpUnclamped(new Vector2(dropdownObj.transform.localPosition.x, 20f), new Vector2(dropdownObj.transform.localPosition.x, -20f), dropdownIntroCurve.Evaluate(toggleLerp)));
				dropdownObj.transform.localScale = Vector2.op_Implicit(Vector2.LerpUnclamped(new Vector2(dropdownObj.transform.localScale.x, dropdownScaleY), new Vector2(dropdownObj.transform.localScale.x, 1f), dropdownScaleIntroCurve.Evaluate(toggleLerp)));
			}
			else
			{
				toggleLerp += 10f * Time.deltaTime;
				toggleLerp = Mathf.Clamp01(toggleLerp);
				mainBgObj.transform.localScale = Vector2.op_Implicit(Vector2.LerpUnclamped(new Vector2(1f, 1f), new Vector2(0.7f, 0.7f), mainBgOutroCurve.Evaluate(toggleLerp)));
				dropdownObj.transform.localPosition = Vector2.op_Implicit(Vector2.LerpUnclamped(new Vector2(dropdownObj.transform.localPosition.x, -20f), new Vector2(dropdownObj.transform.localPosition.x, -15f), dropdownOutroCurve.Evaluate(toggleLerp)));
				dropdownObj.transform.localScale = Vector2.op_Implicit(Vector2.LerpUnclamped(new Vector2(dropdownObj.transform.localScale.x, dropdownScaleY), new Vector2(dropdownObj.transform.localScale.x, 0f), dropdownScaleOutroCurve.Evaluate(toggleLerp)));
				if (toggleLerp >= 1f)
				{
					dropdownObj.SetActive(false);
				}
			}
		}
		foreach (MenuButton dropdownButton in dropdownButtons)
		{
			if (Object.op_Implicit((Object)(object)dropdownButton))
			{
				if (dropdownButton.hovering && (Object)(object)dropdownButton != (Object)(object)hoveredDropdownButton)
				{
					hoveredDropdownButton = dropdownButton;
					((Component)dropdownButton).GetComponentInChildren<SemiUI>().SemiUISpringShakeY(5f, 2f, 0.25f);
				}
				else if (!dropdownButton.hovering && (Object)(object)dropdownButton == (Object)(object)hoveredDropdownButton)
				{
					hoveredDropdownButton = null;
				}
			}
		}
	}

	public void SetState(bool _state, bool _skipAnim = false)
	{
		//IL_001d: Unknown result type (might be due to invalid IL or missing references)
		//IL_007a: Unknown result type (might be due to invalid IL or missing references)
		//IL_004e: Unknown result type (might be due to invalid IL or missing references)
		if (dropdownActive == _state)
		{
			return;
		}
		dropdownActive = _state;
		dropdownScaleY = dropdownObj.transform.localScale.y;
		ToggleDownNavigationUpdate();
		if (!_skipAnim)
		{
			toggleLerp = 0f;
			if (_state)
			{
				soundIntro.Play(MenuManager.instance.soundPosition);
			}
			else
			{
				soundOutro.Play(MenuManager.instance.soundPosition);
			}
		}
		else
		{
			toggleLerp = 0.95f;
		}
		if (_state | _skipAnim)
		{
			dropdownObj.SetActive(_state);
		}
		if (_state && !_skipAnim && (SemiFunc.InputMode() == InputModes.Gamepad || MenuManager.instance.isKeyboardNavigating) && orderedDropdownButtons.Count > 0)
		{
			MenuSelectableElement menuSelectableElement = orderedDropdownButtons[0].menuSelectableElement;
			if (Object.op_Implicit((Object)(object)menuSelectableElement))
			{
				MenuManager.instance.lastHoverMenuID = menuSelectableElement.menuID;
			}
		}
	}
}
