using System.Collections;
using UnityEngine;

public class ShopKeycard : MonoBehaviour
{
	public static ShopKeycard instance;

	private PhysGrabObject physGrabObject;

	[RuntimeInitializeOnLoadMethod(/*Could not decode attribute arguments.*/)]
	private static void Init()
	{
		instance = null;
	}

	private void Start()
	{
		if (Object.op_Implicit((Object)(object)instance))
		{
			Object.Destroy((Object)(object)((Component)this).gameObject);
			return;
		}
		instance = this;
		((MonoBehaviour)this).StartCoroutine(LateStart());
	}

	private IEnumerator LateStart()
	{
		while (!LevelGenerator.Instance.Generated)
		{
			yield return (object)new WaitForSeconds(0.1f);
		}
		if (!Object.op_Implicit((Object)(object)ShopKeycardDoor.instance))
		{
			Object.Destroy((Object)(object)((Component)this).gameObject);
			yield break;
		}
		physGrabObject = ((Component)this).GetComponent<PhysGrabObject>();
		if (SemiFunc.IsMasterClientOrSingleplayer())
		{
			RelocateToRandomVolume();
		}
		DestroyAllVolumes();
	}

	private void RelocateToRandomVolume()
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002f: Unknown result type (might be due to invalid IL or missing references)
		ShopKeycardVolume[] componentsInChildren = ((Component)this).GetComponentsInChildren<ShopKeycardVolume>();
		if (componentsInChildren.Length != 0)
		{
			ShopKeycardVolume shopKeycardVolume = componentsInChildren[Random.Range(0, componentsInChildren.Length)];
			physGrabObject.Teleport(((Component)shopKeycardVolume).transform.position, ((Component)shopKeycardVolume).transform.rotation);
		}
	}

	private void DestroyAllVolumes()
	{
		ShopKeycardVolume[] componentsInChildren = ((Component)this).GetComponentsInChildren<ShopKeycardVolume>();
		for (int i = 0; i < componentsInChildren.Length; i++)
		{
			Object.Destroy((Object)(object)((Component)componentsInChildren[i]).gameObject);
		}
	}
}
