using System;
using System.Collections.Generic;
using Photon.Pun;
using UnityEngine;

public class PhysGrabCart : MonoBehaviour
{
	public enum State
	{
		Locked,
		Dragged,
		Handled
	}

	public bool isSmallCart;

	public GameObject smallCartHurtCollider;

	internal State currentState;

	internal State previousState = State.Handled;

	public Transform thrustEffect;

	private Renderer thrustEffectRenderer;

	private Vector3 thrustEffectOriginalScale;

	public ValueScreen valueScreen;

	public Transform handlePoint;

	private PhysGrabObject physGrabObject;

	internal Rigidbody rb;

	public float stabilizationForce = 100f;

	private Vector3 hitPoint;

	private PhotonView photonView;

	internal bool cartActive;

	private bool cartActivePrevious;

	public GameObject buttonObject;

	private List<Collider> capsuleColliders = new List<Collider>();

	private List<Collider> cartInside = new List<Collider>();

	public PhysicsMaterial physMaterialSlippery;

	public PhysicsMaterial physMaterialSticky;

	public PhysicsMaterial physMaterialALilSlippery;

	public PhysicsMaterial physMaterialNormal;

	private Vector3 velocityRef;

	internal bool cartBeingPulled;

	private float playerInteractionTimer;

	private PhysGrabObjectGrabArea physGrabObjectGrabArea;

	private MeshRenderer cartMesh;

	public MeshRenderer[] grabMesh;

	private List<Material> grabMaterial = new List<Material>();

	[Space]
	public PhysGrabInCart physGrabInCart;

	internal Transform inCart;

	internal Vector3 actualVelocity;

	internal Vector3 actualVelocityLastPosition;

	private Vector3 lastPosition;

	internal List<PhysGrabObject> itemsInCart = new List<PhysGrabObject>();

	internal int itemsInCartCount;

	internal int haulCurrent;

	private float objectInCartCheckTimer = 0.5f;

	[Space]
	public Sound soundLocked;

	public Sound soundDragged;

	public Sound soundHandled;

	[Space]
	public LocalizedAsset localizedCartModeStrong;

	public LocalizedAsset localizedCartModeWeak;

	private string cardModeStrongText;

	private string cartModeWeakText;

	private float autoTurnOffTimer;

	private float draggedTimer;

	public Transform cartGrabPoint;

	private ItemEquippable itemEquippable;

	private void Awake()
	{
		//IL_0052: Unknown result type (might be due to invalid IL or missing references)
		//IL_0057: Unknown result type (might be due to invalid IL or missing references)
		//IL_0073: Unknown result type (might be due to invalid IL or missing references)
		//IL_0079: Expected Obj, but got Unknown
		itemEquippable = ((Component)this).GetComponent<ItemEquippable>();
		physGrabObject = ((Component)this).GetComponent<PhysGrabObject>();
		rb = ((Component)this).GetComponent<Rigidbody>();
		inCart = ((Component)this).transform.Find("In Cart");
		thrustEffectRenderer = ((Component)thrustEffect).GetComponent<Renderer>();
		thrustEffectOriginalScale = thrustEffect.localScale;
		foreach (Transform item in ((Component)this).transform)
		{
			Transform val = item;
			Transform val2 = val.Find("Semi Box Collider");
			if (((Object)val).name.Contains("Inside"))
			{
				cartInside.Add(((Component)val2).GetComponent<Collider>());
			}
			if (Object.op_Implicit((Object)(object)val2) && (((Component)((Component)val2).GetComponent<Collider>()).gameObject.layer == LayerMask.NameToLayer("PhysGrabObject") || ((Component)((Component)val2).GetComponent<Collider>()).gameObject.layer == LayerMask.NameToLayer("Default")))
			{
				((Component)((Component)val2).GetComponent<Collider>()).gameObject.layer = LayerMask.NameToLayer("PhysGrabObjectCart");
			}
			if (((Object)val).name.Contains("Cart Mesh"))
			{
				cartMesh = ((Component)val).GetComponent<MeshRenderer>();
			}
			if (((Object)val).name.Contains("Cart Wall Collider"))
			{
				((Component)val2).GetComponent<Collider>().material = SemiFunc.PhysicMaterialPhysGrabObject();
			}
			if (((Object)val).name.Contains("Capsule"))
			{
				capsuleColliders.Add(((Component)val).GetComponent<Collider>());
			}
		}
		photonView = ((Component)this).GetComponent<PhotonView>();
		physGrabObjectGrabArea = ((Component)this).GetComponent<PhysGrabObjectGrabArea>();
		MeshRenderer[] array = grabMesh;
		foreach (MeshRenderer val3 in array)
		{
			grabMaterial.Add(((Renderer)val3).material);
		}
	}

	private void Start()
	{
		rb.mass = 8f;
		LocalizationManager.instance.AddLocalizationChangedCallback(RefreshLocalizations);
		RefreshLocalizations();
	}

	private void OnDestroy()
	{
		LocalizationManager.instance.RemoveLocalizationChangedCallback(RefreshLocalizations);
	}

	private void RefreshLocalizations()
	{
		cardModeStrongText = localizedCartModeStrong?.GetLocalizedString() ?? "Mode: Strong";
		cartModeWeakText = localizedCartModeWeak?.GetLocalizedString() ?? "Mode: Weak";
	}

	private void ObjectsInCart()
	{
		//IL_0006: Unknown result type (might be due to invalid IL or missing references)
		//IL_003e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0049: Unknown result type (might be due to invalid IL or missing references)
		//IL_0053: Unknown result type (might be due to invalid IL or missing references)
		//IL_005e: Unknown result type (might be due to invalid IL or missing references)
		if (SemiFunc.PlayerNearestDistance(((Component)this).transform.position) > 12f)
		{
			return;
		}
		if (objectInCartCheckTimer > 0f)
		{
			objectInCartCheckTimer -= Time.deltaTime;
			return;
		}
		Collider[] array = Physics.OverlapBox(inCart.position, inCart.localScale / 2f, inCart.rotation);
		itemsInCart.Clear();
		itemsInCartCount = 0;
		haulCurrent = 0;
		Collider[] array2 = array;
		foreach (Collider val in array2)
		{
			if (((Component)val).gameObject.layer != LayerMask.NameToLayer("PhysGrabObject"))
			{
				continue;
			}
			PhysGrabObject componentInParent = ((Component)val).GetComponentInParent<PhysGrabObject>();
			if (Object.op_Implicit((Object)(object)componentInParent) && !itemsInCart.Contains(componentInParent))
			{
				itemsInCart.Add(componentInParent);
				ValuableObject componentInParent2 = ((Component)val).GetComponentInParent<ValuableObject>();
				if (Object.op_Implicit((Object)(object)componentInParent2))
				{
					haulCurrent += (int)componentInParent2.dollarValueCurrent;
				}
				itemsInCartCount++;
			}
		}
		objectInCartCheckTimer = 0.5f;
		valueScreen.UpdateValue(haulCurrent);
	}

	private void StateMessages()
	{
		//IL_002f: Unknown result type (might be due to invalid IL or missing references)
		//IL_003f: Unknown result type (might be due to invalid IL or missing references)
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_006f: Unknown result type (might be due to invalid IL or missing references)
		if (!SemiFunc.RunIsShop() && physGrabObject.grabbedLocal)
		{
			if (currentState == State.Handled)
			{
				Color color = new Color(0.2f, 0.8f, 0.1f);
				ItemInfoExtraUI.instance.ItemInfoText(cardModeStrongText, color);
			}
			if (currentState == State.Dragged)
			{
				Color color2 = new Color(1f, 0.46f, 0f);
				ItemInfoExtraUI.instance.ItemInfoText(cartModeWeakText, color2);
			}
		}
	}

	private void SmallCartLogic()
	{
		if (!isSmallCart || !SemiFunc.IsMasterClientOrSingleplayer())
		{
			return;
		}
		if (itemEquippable.isEquipping)
		{
			if (!smallCartHurtCollider.activeSelf)
			{
				smallCartHurtCollider.SetActive(true);
			}
		}
		else if (!smallCartHurtCollider.activeSelf)
		{
			smallCartHurtCollider.SetActive(false);
		}
		if (currentState == State.Locked)
		{
			CartMassOverride(8f);
			physGrabObject.OverrideMaterial(physMaterialSticky);
		}
	}

	private void Update()
	{
		//IL_008c: Unknown result type (might be due to invalid IL or missing references)
		//IL_00eb: Unknown result type (might be due to invalid IL or missing references)
		if (Object.op_Implicit((Object)(object)itemEquippable) && itemEquippable.isUnequipping)
		{
			return;
		}
		if (physGrabObject.grabbed)
		{
			foreach (PhysGrabber item in physGrabObject.playerGrabbing)
			{
				item.OverrideDisableGrabLookAt(0.2f);
			}
		}
		ObjectsInCart();
		StateMessages();
		thrustEffectRenderer.material.mainTextureOffset = new Vector2(Time.time * 0.05f, 0f);
		thrustEffect.localScale = new Vector3(thrustEffectOriginalScale.x + Mathf.Sin(Time.time * 5f) * 0.02f, thrustEffectOriginalScale.y + Mathf.Sin(Time.time * 5f) * 0.02f, thrustEffectOriginalScale.z);
		if (SemiFunc.IsMasterClientOrSingleplayer())
		{
			AutoTurnOff();
			StateLogic();
			if (playerInteractionTimer > 0f)
			{
				playerInteractionTimer -= Time.deltaTime;
			}
		}
	}

	private void FixedUpdate()
	{
		//IL_01a0: Unknown result type (might be due to invalid IL or missing references)
		//IL_01a6: Unknown result type (might be due to invalid IL or missing references)
		//IL_01ab: Unknown result type (might be due to invalid IL or missing references)
		//IL_01b5: Unknown result type (might be due to invalid IL or missing references)
		//IL_01ba: Unknown result type (might be due to invalid IL or missing references)
		//IL_01c6: Unknown result type (might be due to invalid IL or missing references)
		//IL_01cb: Unknown result type (might be due to invalid IL or missing references)
		//IL_0138: Unknown result type (might be due to invalid IL or missing references)
		//IL_013d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0140: Unknown result type (might be due to invalid IL or missing references)
		//IL_0145: Unknown result type (might be due to invalid IL or missing references)
		//IL_0164: Unknown result type (might be due to invalid IL or missing references)
		//IL_0165: Unknown result type (might be due to invalid IL or missing references)
		//IL_0180: Unknown result type (might be due to invalid IL or missing references)
		//IL_018f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0077: Unknown result type (might be due to invalid IL or missing references)
		//IL_007c: Unknown result type (might be due to invalid IL or missing references)
		//IL_007f: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c2: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c7: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ca: Unknown result type (might be due to invalid IL or missing references)
		//IL_00cf: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ee: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ef: Unknown result type (might be due to invalid IL or missing references)
		//IL_010a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0119: Unknown result type (might be due to invalid IL or missing references)
		//IL_009b: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a0: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a3: Unknown result type (might be due to invalid IL or missing references)
		if (Object.op_Implicit((Object)(object)physGrabObjectGrabArea) && physGrabObjectGrabArea.listOfAllGrabbers.Count > 0)
		{
			CartSteer();
		}
		else
		{
			cartBeingPulled = false;
		}
		if (!LevelGenerator.Instance.Generated || (GameManager.instance.gameMode == 1 && !PhotonNetwork.IsMasterClient))
		{
			return;
		}
		Quaternion rotation;
		if (rb.IsSleeping())
		{
			if (!rb.isKinematic)
			{
				rotation = ((Component)this).transform.rotation;
				if (!(Mathf.Abs(rotation.eulerAngles.x) > 0.05f))
				{
					rotation = ((Component)this).transform.rotation;
					if (!(Mathf.Abs(rotation.eulerAngles.z) > 0.05f))
					{
						goto IL_0199;
					}
				}
				rotation = ((Component)this).transform.rotation;
				Vector3 eulerAngles = rotation.eulerAngles;
				eulerAngles.x = 0f;
				eulerAngles.z = 0f;
				rb.MoveRotation(Quaternion.Euler(eulerAngles));
				rb.angularVelocity = new Vector3(0f, rb.angularVelocity.y, 0f);
			}
		}
		else if (!rb.isKinematic)
		{
			rotation = ((Component)this).transform.rotation;
			Vector3 eulerAngles2 = rotation.eulerAngles;
			eulerAngles2.x = 0f;
			eulerAngles2.z = 0f;
			rb.MoveRotation(Quaternion.Euler(eulerAngles2));
			rb.angularVelocity = new Vector3(0f, rb.angularVelocity.y, 0f);
		}
		goto IL_0199;
		IL_0199:
		actualVelocity = (((Component)this).transform.position - actualVelocityLastPosition) / Time.fixedDeltaTime;
		actualVelocityLastPosition = ((Component)this).transform.position;
	}

	private void AutoTurnOff()
	{
		if (physGrabObject.playerGrabbing.Count <= 0)
		{
			cartActive = false;
		}
	}

	private void CartMassOverride(float mass)
	{
		physGrabObject.OverrideMass(mass);
	}

	private void CartSteer()
	{
		//IL_00b6: Unknown result type (might be due to invalid IL or missing references)
		//IL_00bb: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c5: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ca: Unknown result type (might be due to invalid IL or missing references)
		//IL_00cf: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f8: Unknown result type (might be due to invalid IL or missing references)
		//IL_00fa: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ff: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f0: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f5: Unknown result type (might be due to invalid IL or missing references)
		//IL_01bb: Unknown result type (might be due to invalid IL or missing references)
		//IL_01c0: Unknown result type (might be due to invalid IL or missing references)
		//IL_01d9: Unknown result type (might be due to invalid IL or missing references)
		//IL_01e1: Unknown result type (might be due to invalid IL or missing references)
		//IL_01d2: Unknown result type (might be due to invalid IL or missing references)
		//IL_01d7: Unknown result type (might be due to invalid IL or missing references)
		//IL_0231: Unknown result type (might be due to invalid IL or missing references)
		//IL_023d: Unknown result type (might be due to invalid IL or missing references)
		//IL_026f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0274: Unknown result type (might be due to invalid IL or missing references)
		//IL_0279: Unknown result type (might be due to invalid IL or missing references)
		//IL_027e: Unknown result type (might be due to invalid IL or missing references)
		//IL_028c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0291: Unknown result type (might be due to invalid IL or missing references)
		//IL_0295: Unknown result type (might be due to invalid IL or missing references)
		//IL_029a: Unknown result type (might be due to invalid IL or missing references)
		//IL_029f: Unknown result type (might be due to invalid IL or missing references)
		//IL_02a7: Unknown result type (might be due to invalid IL or missing references)
		//IL_02ac: Unknown result type (might be due to invalid IL or missing references)
		//IL_02b3: Unknown result type (might be due to invalid IL or missing references)
		//IL_02ce: Unknown result type (might be due to invalid IL or missing references)
		//IL_02d6: Unknown result type (might be due to invalid IL or missing references)
		//IL_02db: Unknown result type (might be due to invalid IL or missing references)
		//IL_02e0: Unknown result type (might be due to invalid IL or missing references)
		//IL_02e4: Unknown result type (might be due to invalid IL or missing references)
		//IL_02ee: Unknown result type (might be due to invalid IL or missing references)
		//IL_02f5: Unknown result type (might be due to invalid IL or missing references)
		//IL_02fa: Unknown result type (might be due to invalid IL or missing references)
		//IL_02fc: Unknown result type (might be due to invalid IL or missing references)
		//IL_0303: Unknown result type (might be due to invalid IL or missing references)
		//IL_0308: Unknown result type (might be due to invalid IL or missing references)
		//IL_030c: Unknown result type (might be due to invalid IL or missing references)
		//IL_031c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0321: Unknown result type (might be due to invalid IL or missing references)
		//IL_032b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0339: Unknown result type (might be due to invalid IL or missing references)
		//IL_0347: Unknown result type (might be due to invalid IL or missing references)
		//IL_0351: Unknown result type (might be due to invalid IL or missing references)
		//IL_035f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0369: Unknown result type (might be due to invalid IL or missing references)
		//IL_037a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0385: Unknown result type (might be due to invalid IL or missing references)
		//IL_038a: Unknown result type (might be due to invalid IL or missing references)
		//IL_038f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0394: Unknown result type (might be due to invalid IL or missing references)
		//IL_0399: Unknown result type (might be due to invalid IL or missing references)
		//IL_03a2: Unknown result type (might be due to invalid IL or missing references)
		//IL_03b7: Unknown result type (might be due to invalid IL or missing references)
		//IL_03bc: Unknown result type (might be due to invalid IL or missing references)
		//IL_03c5: Unknown result type (might be due to invalid IL or missing references)
		//IL_03ca: Unknown result type (might be due to invalid IL or missing references)
		//IL_03ce: Unknown result type (might be due to invalid IL or missing references)
		//IL_03dd: Unknown result type (might be due to invalid IL or missing references)
		//IL_03e2: Unknown result type (might be due to invalid IL or missing references)
		//IL_03e4: Unknown result type (might be due to invalid IL or missing references)
		//IL_03e6: Unknown result type (might be due to invalid IL or missing references)
		//IL_03e8: Unknown result type (might be due to invalid IL or missing references)
		//IL_03ed: Unknown result type (might be due to invalid IL or missing references)
		//IL_03f2: Unknown result type (might be due to invalid IL or missing references)
		//IL_0453: Unknown result type (might be due to invalid IL or missing references)
		//IL_0458: Unknown result type (might be due to invalid IL or missing references)
		//IL_045f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0464: Unknown result type (might be due to invalid IL or missing references)
		//IL_0466: Unknown result type (might be due to invalid IL or missing references)
		//IL_046d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0472: Unknown result type (might be due to invalid IL or missing references)
		//IL_0478: Unknown result type (might be due to invalid IL or missing references)
		//IL_047d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0481: Unknown result type (might be due to invalid IL or missing references)
		//IL_048f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0499: Unknown result type (might be due to invalid IL or missing references)
		if (isSmallCart && itemEquippable.isUnequipping)
		{
			return;
		}
		List<PhysGrabber> listOfAllGrabbers = physGrabObjectGrabArea.listOfAllGrabbers;
		foreach (PhysGrabber item in listOfAllGrabbers)
		{
			if (Object.op_Implicit((Object)(object)item))
			{
				if (item.isLocal)
				{
					TutorialDirector.instance.playerUsedCart = true;
				}
				item.OverrideGrabPoint(cartGrabPoint);
			}
		}
		if (!SemiFunc.IsMasterClientOrSingleplayer())
		{
			return;
		}
		BoxCollider component = ((Component)inCart).GetComponent<BoxCollider>();
		float num7 = default;
		Vector3 val10 = default;
		foreach (PhysGrabber item2 in listOfAllGrabbers)
		{
			if (!Object.op_Implicit((Object)(object)item2))
			{
				continue;
			}
			Vector3 val = ((Component)item2.playerAvatar).transform.position + Vector3.up * 0.25f;
			if (item2.playerAvatar.isTumbling)
			{
				val = item2.playerAvatar.tumble.physGrabObject.centerPoint;
			}
			if (!(Vector3.Distance(((Collider)component).ClosestPoint(val), val) < 0.01f))
			{
				Rigidbody component2 = ((Component)this).GetComponent<Rigidbody>();
				CartMassOverride(4f);
				if ((Object)(object)item2 == (Object)(object)PhysGrabber.instance)
				{
					SemiFunc.PhysGrabberLocalChangeAlpha(0.1f);
				}
				if (!cartActive && item2.initialPressTimer > 0f)
				{
					cartActive = true;
				}
				if (!cartActive || (Object)(object)item2 != (Object)(object)listOfAllGrabbers[0])
				{
					break;
				}
				cartBeingPulled = true;
				item2.OverridePhysGrabForcesDisable(0.1f);
				float num = 2f;
				float num2 = 2.5f;
				if (isSmallCart)
				{
					num = 1.5f;
					num2 = 2f;
				}
				Vector3 val2 = PlayerController.instance.rb.linearVelocity;
				if (!item2.isLocal)
				{
					val2 = item2.playerAvatar.rbVelocityRaw;
				}
				bool flag = Vector3.Dot(val2, ((Component)this).transform.forward) > 0f;
				float num3 = 5f;
				if (item2.playerAvatar.isSprinting)
				{
					num3 = 7f;
				}
				if (item2.playerAvatar.isSprinting & flag)
				{
					num = 3f;
					num2 = 4f;
				}
				float num4 = Mathf.Clamp(Vector3.Dot(component2.linearVelocity, ((Component)item2).transform.forward) / num3, 0f, 1f);
				float num5 = Mathf.Lerp(num, num2, num4);
				Vector3 val3 = ((Component)item2).transform.rotation * Vector3.back;
				Vector3 val4 = ((Component)item2.playerAvatar).transform.position - val3 * num5;
				float num6 = Mathf.Clamp(Vector3.Distance(((Component)this).transform.position, val4 / 1f), 0f, 1f);
				Vector3 val5 = val4 - ((Component)this).transform.position;
				Vector3 val6 = val5.normalized * 5f * num6;
				val6 = Vector3.ClampMagnitude(val6, 5f);
				float y = component2.linearVelocity.y;
				component2.linearVelocity = Vector3.MoveTowards(component2.linearVelocity, val6, num6 * 2f);
				component2.linearVelocity = new Vector3(component2.linearVelocity.x, y, component2.linearVelocity.z);
				component2.linearVelocity = Vector3.ClampMagnitude(component2.linearVelocity, 5f);
				Quaternion val7 = Quaternion.LookRotation(((Component)item2).transform.position - ((Component)this).transform.position, Vector3.up);
				val7 = Quaternion.Euler(0f, val7.eulerAngles.y + 180f, 0f);
				Quaternion rotation = component2.rotation;
				Quaternion val8 = Quaternion.Euler(0f, rotation.eulerAngles.y, 0f);
				Quaternion val9 = val7 * Quaternion.Inverse(val8);
				val9.ToAngleAxis(ref num7, ref val10);
				if (num7 > 180f)
				{
					num7 -= 360f;
				}
				float num8 = Mathf.Clamp(Mathf.Abs(num7) / 180f, 0.2f, 1f) * 20f;
				num8 = Mathf.Clamp(num8, 0f, 4f);
				Vector3 val11 = MathF.PI / 180f * num7 * val10.normalized * num8;
				val11 = Vector3.ClampMagnitude(val11, 4f);
				component2.angularVelocity = Vector3.MoveTowards(component2.angularVelocity, val11, num8);
				component2.angularVelocity = Vector3.ClampMagnitude(component2.angularVelocity, 4f);
			}
		}
	}

	private void StateLogic()
	{
		if (LevelGenerator.Instance.Generated)
		{
			if (cartActive != cartActivePrevious)
			{
				cartActivePrevious = cartActive;
			}
			if (physGrabObject.playerGrabbing.Count > 0)
			{
				draggedTimer += Time.deltaTime;
			}
			else
			{
				draggedTimer = 0f;
			}
			if (cartActive)
			{
				currentState = State.Handled;
			}
			else if (draggedTimer > 0.25f)
			{
				currentState = State.Dragged;
			}
			else
			{
				currentState = State.Locked;
			}
			if (currentState != previousState)
			{
				previousState = currentState;
				StateSwitch(currentState);
			}
		}
	}

	private void StateSwitch(State _state)
	{
		//IL_002c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0032: Unknown result type (might be due to invalid IL or missing references)
		if (SemiFunc.IsMultiplayer())
		{
			photonView.RPC("StateSwitchRPC", (RpcTarget)0, new object[1] { _state });
		}
		else
		{
			StateSwitchRPC(_state);
		}
	}

	[PunRPC]
	private void StateSwitchRPC(State _state, PhotonMessageInfo _info = default(PhotonMessageInfo))
	{
		//IL_0000: Unknown result type (might be due to invalid IL or missing references)
		//IL_0027: Unknown result type (might be due to invalid IL or missing references)
		//IL_0056: Unknown result type (might be due to invalid IL or missing references)
		//IL_025b: Unknown result type (might be due to invalid IL or missing references)
		//IL_028a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0141: Unknown result type (might be due to invalid IL or missing references)
		//IL_017c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0186: Unknown result type (might be due to invalid IL or missing references)
		//IL_0075: Unknown result type (might be due to invalid IL or missing references)
		//IL_007a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0081: Unknown result type (might be due to invalid IL or missing references)
		//IL_0091: Unknown result type (might be due to invalid IL or missing references)
		//IL_02b5: Unknown result type (might be due to invalid IL or missing references)
		//IL_01a7: Unknown result type (might be due to invalid IL or missing references)
		//IL_01b7: Unknown result type (might be due to invalid IL or missing references)
		//IL_02d0: Unknown result type (might be due to invalid IL or missing references)
		if (!SemiFunc.MasterOnlyRPC(_info))
		{
			return;
		}
		currentState = _state;
		if (currentState == State.Locked)
		{
			soundLocked.Play(((Component)this).transform.position);
			((Renderer)cartMesh).material.SetColor("_EmissionColor", Color.red);
			foreach (Material item in grabMaterial)
			{
				Color red = Color.red;
				item.SetColor("_EmissionColor", red);
				item.mainTextureOffset = new Vector2(0f, 0f);
			}
			foreach (Collider capsuleCollider in capsuleColliders)
			{
				capsuleCollider.material = physMaterialNormal;
			}
			{
				foreach (Collider item2 in cartInside)
				{
					item2.material = physMaterialNormal;
				}
				return;
			}
		}
		if (currentState == State.Dragged)
		{
			soundDragged.Play(((Component)this).transform.position);
			Material material = ((Renderer)cartMesh).material;
			Color val = new Color(1f, 0.46f, 0f);
			material.SetColor("_EmissionColor", val);
			foreach (Material item3 in grabMaterial)
			{
				item3.SetColor("_EmissionColor", val);
				item3.mainTextureOffset = new Vector2(0f, 0f);
			}
			foreach (Collider capsuleCollider2 in capsuleColliders)
			{
				capsuleCollider2.material = physMaterialALilSlippery;
			}
			{
				foreach (Collider item4 in cartInside)
				{
					item4.material = physMaterialALilSlippery;
				}
				return;
			}
		}
		soundHandled.Play(((Component)this).transform.position);
		((Renderer)cartMesh).material.SetColor("_EmissionColor", Color.green);
		int num = 0;
		foreach (Material item5 in grabMaterial)
		{
			item5.SetColor("_EmissionColor", Color.green);
			if (num == 1)
			{
				item5.mainTextureOffset = new Vector2(0.5f, 0f);
			}
			num++;
		}
		foreach (Collider capsuleCollider3 in capsuleColliders)
		{
			capsuleCollider3.material = physMaterialSlippery;
		}
		foreach (Collider item6 in cartInside)
		{
			item6.material = SemiFunc.PhysicMaterialPhysGrabObject();
		}
	}
}
