using System.Collections.Generic;
using System.Linq;
using UnityEngine;
using UnityEngine.UI;

public class MenuPageColor : MonoBehaviour
{
	public enum ColorPageType
	{
		All,
		Cosmetics,
		Body
	}

	public GameObject colorButtonPrefab;

	public RectTransform colorButtonHolder;

	public MenuColorSelected menuColorSelected;

	public MenuButtonColor hoveredColorButton;

	internal MenuPage menuPage;

	public ColorPageType pageMode;

	public int colorKey = -1;

	private PlayerExpression playerExpression;

	internal float colorHoverCooldown;

	private void Start()
	{
		//IL_00c2: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c7: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d1: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d6: Unknown result type (might be due to invalid IL or missing references)
		//IL_00db: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ea: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ef: Unknown result type (might be due to invalid IL or missing references)
		//IL_00fe: Unknown result type (might be due to invalid IL or missing references)
		//IL_0103: Unknown result type (might be due to invalid IL or missing references)
		//IL_010d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0112: Unknown result type (might be due to invalid IL or missing references)
		//IL_0117: Unknown result type (might be due to invalid IL or missing references)
		//IL_0132: Unknown result type (might be due to invalid IL or missing references)
		//IL_014f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0180: Unknown result type (might be due to invalid IL or missing references)
		//IL_0185: Unknown result type (might be due to invalid IL or missing references)
		menuPage = ((Component)this).GetComponent<MenuPage>();
		List<SemiColor> list = MetaManager.instance.colors.OrderBy((SemiColor x) => MetaManager.instance.colorsUIOrder.IndexOf(x)).ToList();
		int num = 0;
		int num2 = 0;
		List<MenuSelectableElement> list2 = new List<MenuSelectableElement>();
		List<Vector2Int> list3 = new List<Vector2Int>();
		int num3 = SelectedColorIDGet();
		MenuSelectableElement menuSelectableElement = null;
		int num4 = 0;
		int num5 = 0;
		for (int num6 = 0; num6 < list.Count; num6++)
		{
			GameObject val = Object.Instantiate<GameObject>(colorButtonPrefab, (Transform)(object)colorButtonHolder);
			MenuButtonColor component = val.GetComponent<MenuButtonColor>();
			component.colorID = MetaManager.instance.colors.IndexOf(list[num6]);
			component.color = list[num6];
			MenuButton component2 = val.GetComponent<MenuButton>();
			component2.colorNormal = list[num6].color + Color.black * 0.5f;
			component2.colorHover = list[num6].color;
			component2.colorClick = list[num6].color + Color.white * 0.95f;
			RectTransform component3 = val.GetComponent<RectTransform>();
			((Transform)component3).SetSiblingIndex(0);
			component3.anchoredPosition = new Vector2((float)num, (float)(224 + num2));
			list2.Add(component2.menuSelectableElement);
			list3.Add(new Vector2Int(num4, num5));
			if (component.colorID == num3)
			{
				menuSelectableElement = component2.menuSelectableElement;
			}
			num += 38;
			num4++;
			float num7 = num;
			Rect rect = colorButtonHolder.rect;
			if (num7 > rect.width)
			{
				num = 0;
				num2 -= 30;
				num4 = 0;
				num5++;
			}
		}
		Object.Destroy((Object)(object)colorButtonPrefab);
		SetupGridNavigation(list2, list3);
		if (!Object.op_Implicit((Object)(object)menuSelectableElement))
		{
			menuSelectableElement = list2.FirstOrDefault((MenuSelectableElement x) => Object.op_Implicit((Object)(object)x));
		}
		if (Object.op_Implicit((Object)(object)menuSelectableElement))
		{
			MenuManager.instance.lastHoverMenuID = menuSelectableElement.menuID;
		}
		MenuPageCosmetics component4 = ((Component)menuPage.pageUnderThisPage).GetComponent<MenuPageCosmetics>();
		if (Object.op_Implicit((Object)(object)component4) && Object.op_Implicit((Object)(object)component4.menuPage) && Object.op_Implicit((Object)(object)component4.menuPage.playerAvatarMenu) && Object.op_Implicit((Object)(object)component4.menuPage.playerAvatarMenu.playerVisuals))
		{
			playerExpression = component4.menuPage.playerAvatarMenu.playerExpression;
			if (colorKey == 13)
			{
				component4.SetGrabberActive(_state: true);
			}
		}
		if (Object.op_Implicit((Object)(object)component4) && Object.op_Implicit((Object)(object)component4.menuScrollBox))
		{
			component4.menuScrollBox.scrollKeybindsDisabled = true;
		}
	}

	public int SelectedColorIDGet()
	{
		if (colorKey != -1)
		{
			return MetaManager.instance.colorsEquipped[colorKey];
		}
		List<SemiFunc.CosmeticType> list = new List<SemiFunc.CosmeticType>();
		if (pageMode == ColorPageType.Cosmetics)
		{
			list = (from x in MetaManager.instance.cosmeticTypeAssets
				where x.meshSwitch
				select x.type).ToList();
		}
		else if (pageMode == ColorPageType.Body)
		{
			list = (from x in MetaManager.instance.cosmeticTypeAssets
				where !x.meshSwitch
				select x.type).ToList();
		}
		int num = -1;
		for (int num2 = 0; num2 < MetaManager.instance.colorsEquipped.Length; num2++)
		{
			if (!list.Contains((SemiFunc.CosmeticType)num2))
			{
				int num3 = MetaManager.instance.colorsEquipped[num2];
				if (num == -1)
				{
					num = num3;
				}
				else if (num != num3)
				{
					return -1;
				}
			}
		}
		return num;
	}

	private void SetupGridNavigation(List<MenuSelectableElement> elements, List<Vector2Int> positions)
	{
		//IL_0027: Unknown result type (might be due to invalid IL or missing references)
		//IL_00de: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e9: Unknown result type (might be due to invalid IL or missing references)
		//IL_0174: Unknown result type (might be due to invalid IL or missing references)
		//IL_0205: Unknown result type (might be due to invalid IL or missing references)
		//IL_0234: Unknown result type (might be due to invalid IL or missing references)
		Dictionary<Vector2Int, MenuSelectableElement> grid = new Dictionary<Vector2Int, MenuSelectableElement>();
		for (int i = 0; i < elements.Count; i++)
		{
			if ((Object)(object)elements[i] != (Object)null)
			{
				grid[positions[i]] = elements[i];
			}
		}
		MenuButton menuButton = null;
		for (int j = 0; j < ((Component)this).transform.childCount; j++)
		{
			Transform child = ((Component)this).transform.GetChild(j);
			if (!((Object)(object)child == (Object)(object)((Component)colorButtonHolder).transform) && !((Object)(object)((Component)child).gameObject == (Object)(object)colorButtonPrefab))
			{
				menuButton = ((Component)child).GetComponent<MenuButton>();
				if ((Object)(object)menuButton != (Object)null)
				{
					break;
				}
			}
		}
		MenuSelectableElement menuSelectableElement = (((Object)(object)menuButton != (Object)null) ? menuButton.menuSelectableElement : null);
		Navigation navigation;
		for (int k = 0; k < elements.Count; k++)
		{
			MenuSelectableElement menuSelectableElement2 = elements[k];
			if (!((Object)(object)menuSelectableElement2 == (Object)null))
			{
				Vector2Int val = positions[k];
				navigation = default;
				navigation.mode = (Mode)4;
				navigation.selectOnUp = (Selectable)(object)Lookup(val.x, val.y - 1);
				navigation.selectOnDown = (Selectable)(object)(Lookup(val.x, val.y + 1) ?? menuSelectableElement);
				navigation.selectOnLeft = (Selectable)(object)Lookup(val.x - 1, val.y);
				navigation.selectOnRight = (Selectable)(object)Lookup(val.x + 1, val.y);
				((Selectable)menuSelectableElement2).navigation = navigation;
			}
		}
		if ((Object)(object)menuSelectableElement != (Object)null && positions.Count > 0)
		{
			int r = positions.Max((Vector2Int p) => p.y);
			MenuSelectableElement selectOnUp = Lookup(0, r) ?? elements.LastOrDefault((MenuSelectableElement e) => (Object)(object)e != (Object)null);
			navigation = default;
			navigation.mode = (Mode)4;
			navigation.selectOnUp = (Selectable)(object)selectOnUp;
			navigation.selectOnDown = null;
			navigation.selectOnLeft = null;
			navigation.selectOnRight = null;
			((Selectable)menuSelectableElement).navigation = navigation;
		}
		MenuSelectableElement Lookup(int c, int num)
		{
			//IL_0008: Unknown result type (might be due to invalid IL or missing references)
			if (!grid.TryGetValue(new Vector2Int(c, num), out var value))
			{
				return null;
			}
			return value;
		}
	}

	private void Update()
	{
		if (colorHoverCooldown > 0f)
		{
			colorHoverCooldown -= Time.deltaTime;
		}
		if (Object.op_Implicit((Object)(object)playerExpression) && (colorKey == 15 || colorKey == 14))
		{
			playerExpression.OverrideExpressionSet(3, 100f);
		}
		if (SemiFunc.InputDown(InputKey.Back) && MenuManager.instance.currentMenuPageIndex == MenuPageIndex.Color)
		{
			ConfirmButton();
		}
	}

	private void OnDestroy()
	{
		if (!Object.op_Implicit((Object)(object)menuPage.pageUnderThisPage) || menuPage.pageUnderThisPage.menuPageIndex != MenuPageIndex.Cosmetics)
		{
			return;
		}
		MetaManager.instance.colorsPreviewEnabled = false;
		MenuPageCosmetics component = ((Component)menuPage.pageUnderThisPage).GetComponent<MenuPageCosmetics>();
		if (!Object.op_Implicit((Object)(object)component))
		{
			return;
		}
		component.HideAvatarControls(_state: false);
		if (Object.op_Implicit((Object)(object)component.menuPage) && Object.op_Implicit((Object)(object)component.menuPage.playerAvatarMenu) && Object.op_Implicit((Object)(object)component.menuPage.playerAvatarMenu.playerVisuals))
		{
			component.menuPage.playerAvatarMenu.playerCosmetics.SetupColors(_synced: false);
			if (colorKey == 13)
			{
				component.SetGrabberActive(component.selectedSubCategory == SemiFunc.CosmeticType.GrabberMesh);
			}
		}
		if (Object.op_Implicit((Object)(object)component.menuScrollBox))
		{
			component.menuScrollBox.scrollKeybindsDisabled = false;
		}
	}

	public void SetColor(int colorID, RectTransform buttonTransform)
	{
		//IL_002a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0030: Unknown result type (might be due to invalid IL or missing references)
		//IL_0035: Unknown result type (might be due to invalid IL or missing references)
		//IL_0044: Unknown result type (might be due to invalid IL or missing references)
		//IL_0049: Unknown result type (might be due to invalid IL or missing references)
		//IL_005c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0061: Unknown result type (might be due to invalid IL or missing references)
		//IL_0066: Unknown result type (might be due to invalid IL or missing references)
		//IL_007d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0082: Unknown result type (might be due to invalid IL or missing references)
		MenuManager.instance.MenuEffectClick(MenuManager.MenuClickEffectType.Confirm);
		((Component)menuColorSelected).gameObject.SetActive(true);
		Vector3 position = ((Transform)buttonTransform).position;
		Rect rect = buttonTransform.rect;
		float num = rect.width / 2f;
		rect = buttonTransform.rect;
		Vector3 position2 = position + new Vector3(num, rect.height / 2f, 0f);
		menuColorSelected.SetColor(MetaManager.instance.colors[colorID].color, position2);
	}

	public void ConfirmButton()
	{
		MenuManager.instance.PageReactivatePageUnderThisPage(menuPage);
		MenuManager.instance.MenuEffectPopUpClose();
		menuPage.PageStateSet(MenuPage.PageState.Closing);
	}
}
