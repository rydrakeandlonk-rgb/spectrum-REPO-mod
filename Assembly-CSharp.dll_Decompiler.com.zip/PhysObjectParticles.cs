using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PhysObjectParticles : MonoBehaviour
{
	public Gradient gradient;

	public ParticleSystem particleSystemBits;

	public ParticleSystem particleSystemBitsSmall;

	public ParticleSystem particleSystemSmoke;

	internal bool particleSystemSmokeDisable;

	private Particle[] particles;

	private bool particlesSpawned;

	internal float multiplier = 1f;

	public List<Transform> colliderTransforms = new List<Transform>();

	public List<Collider> colliderColliders = new List<Collider>();

	public void DestroyParticles()
	{
		//IL_0001: Unknown result type (might be due to invalid IL or missing references)
		//IL_0006: Unknown result type (might be due to invalid IL or missing references)
		DestroyParticles(Vector3.zero, Vector3.one);
	}

	public void DestroyParticles(Vector3 objectVelocity, Vector3 objectScale, bool freezeFrame = true)
	{
		//IL_0021: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d1: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d6: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d7: Unknown result type (might be due to invalid IL or missing references)
		//IL_00dc: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ea: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f2: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0071: Unknown result type (might be due to invalid IL or missing references)
		//IL_0076: Unknown result type (might be due to invalid IL or missing references)
		//IL_0117: Unknown result type (might be due to invalid IL or missing references)
		//IL_0120: Unknown result type (might be due to invalid IL or missing references)
		//IL_0129: Unknown result type (might be due to invalid IL or missing references)
		//IL_0092: Unknown result type (might be due to invalid IL or missing references)
		//IL_0089: Unknown result type (might be due to invalid IL or missing references)
		//IL_008b: Unknown result type (might be due to invalid IL or missing references)
		//IL_009f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0201: Unknown result type (might be due to invalid IL or missing references)
		//IL_0202: Unknown result type (might be due to invalid IL or missing references)
		//IL_0207: Unknown result type (might be due to invalid IL or missing references)
		//IL_0211: Unknown result type (might be due to invalid IL or missing references)
		//IL_021b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0225: Unknown result type (might be due to invalid IL or missing references)
		//IL_0288: Unknown result type (might be due to invalid IL or missing references)
		//IL_0289: Unknown result type (might be due to invalid IL or missing references)
		DestroySetup();
		float[] array = new float[colliderTransforms.Count];
		float num = 0f;
		bool flag = false;
		Bounds val = default;
		for (int i = 0; i < colliderTransforms.Count; i++)
		{
			Transform val2 = colliderTransforms[i];
			if (!Object.op_Implicit((Object)(object)val2))
			{
				continue;
			}
			Collider component = ((Component)val2).GetComponent<Collider>();
			colliderColliders.Add(component);
			if (!Object.op_Implicit((Object)(object)component))
			{
				continue;
			}
			Bounds bounds = component.bounds;
			Vector3 size = bounds.size;
			if (!(size.sqrMagnitude <= 0f))
			{
				if (!flag)
				{
					val = bounds;
					flag = true;
				}
				else
				{
					val.Encapsulate(bounds);
				}
				array[i] = GetColliderVolume(val2, objectScale);
				num += array[i];
			}
		}
		float num2 = 0.001f;
		if (flag)
		{
			Vector3 val3 = Vector3.Scale(val.size, objectScale);
			num2 = Mathf.Max(0.001f, val3.x * val3.y * val3.z);
		}
		if (num <= 0f)
		{
			num = 1f;
		}
		float num3 = Mathf.Max(new float[3] { objectScale.x, objectScale.y, objectScale.z });
		float num4 = ((num3 > 1f) ? num3 : 1f);
		float num5 = 1f + Mathf.Min(num2 * 1.5f, 3f);
		int num6 = (int)(Mathf.Clamp(10f + Mathf.Sqrt(num2) * 150f, 10f, 100f) * num4 * num4 * multiplier);
		for (int j = 0; j < colliderTransforms.Count; j++)
		{
			Transform val4 = colliderTransforms[j];
			if (Object.op_Implicit((Object)(object)val4) && j < colliderColliders.Count && Object.op_Implicit((Object)(object)colliderColliders[j]))
			{
				float num7 = array[j] / num;
				int bitCount = Mathf.Max(3, Mathf.RoundToInt((float)num6 * num7));
				Vector3 emissionScale = GetEmissionScale(val4, objectScale);
				float num8 = Mathf.Max(new float[3] { emissionScale.x, emissionScale.y, emissionScale.z });
				float num9 = ((num3 > 1f) ? num3 : 1f);
				float num10 = ((num3 > 1f) ? (1.25f * num3) : 1.25f);
				float num11 = Mathf.Clamp(num8 * 0.3f * num9 * num5, 0.32f, num10);
				SpawnParticles(bitCount, num11 * multiplier, val4, objectScale, objectVelocity, colliderColliders[j]);
			}
		}
		if (freezeFrame)
		{
			SetSimulationSpeed(0.05f);
			((MonoBehaviour)this).StartCoroutine(UnfreezeParticles(0.15f));
		}
	}

	public void DestroyParticles(Vector3 _position, Vector3 _size, Quaternion _rotation)
	{
		//IL_000b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0011: Unknown result type (might be due to invalid IL or missing references)
		//IL_0018: Unknown result type (might be due to invalid IL or missing references)
		//IL_004f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0055: Unknown result type (might be due to invalid IL or missing references)
		//IL_005b: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a4: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a6: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a7: Unknown result type (might be due to invalid IL or missing references)
		DestroySetup();
		float num = Mathf.Max(0.001f, _size.x * _size.y * _size.z);
		int bitCount = (int)(Mathf.Clamp(10f + Mathf.Sqrt(num) * 150f, 10f, 100f) * multiplier);
		float num2 = Mathf.Clamp(Mathf.Max(_size.x, Mathf.Max(_size.y, _size.z)) * 0.3f * (1f + Mathf.Min(num * 1.5f, 3f)), 0.32f, 1.25f);
		SpawnParticles(bitCount, num2 * multiplier, _position, _size, (ParticleSystemShapeType)5, _rotation, Vector3.zero);
	}

	private void DestroySetup()
	{
		//IL_001f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_0027: Unknown result type (might be due to invalid IL or missing references)
		//IL_002c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0040: Unknown result type (might be due to invalid IL or missing references)
		//IL_0047: Unknown result type (might be due to invalid IL or missing references)
		//IL_0053: Unknown result type (might be due to invalid IL or missing references)
		//IL_0058: Unknown result type (might be due to invalid IL or missing references)
		//IL_005b: Unknown result type (might be due to invalid IL or missing references)
		if (!SemiFunc.RunIsTutorial())
		{
			((MonoBehaviour)this).StartCoroutine(DestroyParticlesAfterTime(4f));
		}
		CollisionModule collision = particleSystemBits.collision;
		MinMaxCurve bounce = collision.bounce;
		float constant = bounce.constant;
		MinMaxCurve bounce2 = (collision.bounce = new MinMaxCurve(constant * 0.7f, constant));
		CollisionModule collision2 = particleSystemBitsSmall.collision;
		collision2.bounce = bounce2;
	}

	private void SetSimulationSpeed(float _speed)
	{
		//IL_0006: Unknown result type (might be due to invalid IL or missing references)
		//IL_000b: Unknown result type (might be due to invalid IL or missing references)
		//IL_001a: Unknown result type (might be due to invalid IL or missing references)
		//IL_001f: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0033: Unknown result type (might be due to invalid IL or missing references)
		MainModule main = particleSystemBits.main;
		main.simulationSpeed = _speed;
		MainModule main2 = particleSystemBitsSmall.main;
		main2.simulationSpeed = _speed;
		MainModule main3 = particleSystemSmoke.main;
		main3.simulationSpeed = _speed;
	}

	private IEnumerator UnfreezeParticles(float _delay)
	{
		yield return (object)new WaitForSecondsRealtime(_delay);
		if (Object.op_Implicit((Object)(object)particleSystemBits) && Object.op_Implicit((Object)(object)particleSystemBitsSmall) && Object.op_Implicit((Object)(object)particleSystemSmoke))
		{
			SetSimulationSpeed(1f);
		}
	}

	private float GetColliderVolume(Transform _colliderTransform, Vector3 _objectScale)
	{
		//IL_0010: Unknown result type (might be due to invalid IL or missing references)
		//IL_0016: Unknown result type (might be due to invalid IL or missing references)
		//IL_001b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0020: Unknown result type (might be due to invalid IL or missing references)
		//IL_0021: Unknown result type (might be due to invalid IL or missing references)
		//IL_0026: Unknown result type (might be due to invalid IL or missing references)
		//IL_0028: Unknown result type (might be due to invalid IL or missing references)
		//IL_002f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0037: Unknown result type (might be due to invalid IL or missing references)
		//IL_0058: Unknown result type (might be due to invalid IL or missing references)
		//IL_0066: Unknown result type (might be due to invalid IL or missing references)
		//IL_0074: Unknown result type (might be due to invalid IL or missing references)
		//IL_008e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0097: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a0: Unknown result type (might be due to invalid IL or missing references)
		//IL_01ce: Unknown result type (might be due to invalid IL or missing references)
		//IL_01d3: Unknown result type (might be due to invalid IL or missing references)
		//IL_01d4: Unknown result type (might be due to invalid IL or missing references)
		//IL_01d9: Unknown result type (might be due to invalid IL or missing references)
		//IL_01da: Unknown result type (might be due to invalid IL or missing references)
		//IL_01e0: Unknown result type (might be due to invalid IL or missing references)
		//IL_01e7: Unknown result type (might be due to invalid IL or missing references)
		//IL_00de: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ed: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f4: Unknown result type (might be due to invalid IL or missing references)
		//IL_0102: Unknown result type (might be due to invalid IL or missing references)
		//IL_0136: Unknown result type (might be due to invalid IL or missing references)
		//IL_013d: Unknown result type (might be due to invalid IL or missing references)
		//IL_014b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0116: Unknown result type (might be due to invalid IL or missing references)
		//IL_011d: Unknown result type (might be due to invalid IL or missing references)
		//IL_012b: Unknown result type (might be due to invalid IL or missing references)
		//IL_015c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0165: Unknown result type (might be due to invalid IL or missing references)
		//IL_016e: Unknown result type (might be due to invalid IL or missing references)
		BoxCollider component = ((Component)_colliderTransform).GetComponent<BoxCollider>();
		if (Object.op_Implicit((Object)(object)component))
		{
			Vector3 val = Vector3.Scale(Vector3.Scale(component.size, _colliderTransform.localScale), _objectScale);
			return val.x * val.y * val.z;
		}
		SphereCollider component2 = ((Component)_colliderTransform).GetComponent<SphereCollider>();
		if (Object.op_Implicit((Object)(object)component2))
		{
			float num = Mathf.Max(new float[3]
			{
				_colliderTransform.localScale.x,
				_colliderTransform.localScale.y,
				_colliderTransform.localScale.z
			});
			float num2 = Mathf.Max(new float[3] { _objectScale.x, _objectScale.y, _objectScale.z });
			float num3 = component2.radius * num * num2;
			return 4.1887903f * num3 * num3 * num3;
		}
		CapsuleCollider component3 = ((Component)_colliderTransform).GetComponent<CapsuleCollider>();
		if (Object.op_Implicit((Object)(object)component3))
		{
			Vector3 localScale = _colliderTransform.localScale;
			float num4;
			float num5;
			if (component3.direction == 0)
			{
				num4 = Mathf.Max(localScale.y, localScale.z);
				num5 = localScale.x;
			}
			else if (component3.direction == 2)
			{
				num4 = Mathf.Max(localScale.x, localScale.y);
				num5 = localScale.z;
			}
			else
			{
				num4 = Mathf.Max(localScale.x, localScale.z);
				num5 = localScale.y;
			}
			float num6 = Mathf.Max(new float[3] { _objectScale.x, _objectScale.y, _objectScale.z });
			float num7 = component3.radius * num4 * num6;
			float num8 = component3.height * num5 * num6;
			float num9 = Mathf.Max(0f, num8 - 2f * num7);
			return MathF.PI * num7 * num7 * num9 + 4.1887903f * num7 * num7 * num7;
		}
		Vector3 val2 = Vector3.Scale(_colliderTransform.localScale, _objectScale);
		return val2.x * val2.y * val2.z;
	}

	private Vector3 GetEmissionScale(Transform _colliderTransform, Vector3 _objectScale)
	{
		//IL_0010: Unknown result type (might be due to invalid IL or missing references)
		//IL_0016: Unknown result type (might be due to invalid IL or missing references)
		//IL_001b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0020: Unknown result type (might be due to invalid IL or missing references)
		//IL_0021: Unknown result type (might be due to invalid IL or missing references)
		//IL_003f: Unknown result type (might be due to invalid IL or missing references)
		//IL_004d: Unknown result type (might be due to invalid IL or missing references)
		//IL_005b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0074: Unknown result type (might be due to invalid IL or missing references)
		//IL_007d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0086: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a7: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ae: Unknown result type (might be due to invalid IL or missing references)
		//IL_01cd: Unknown result type (might be due to invalid IL or missing references)
		//IL_01d2: Unknown result type (might be due to invalid IL or missing references)
		//IL_01d3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c7: Unknown result type (might be due to invalid IL or missing references)
		//IL_00cc: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d6: Unknown result type (might be due to invalid IL or missing references)
		//IL_00dd: Unknown result type (might be due to invalid IL or missing references)
		//IL_00eb: Unknown result type (might be due to invalid IL or missing references)
		//IL_011f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0126: Unknown result type (might be due to invalid IL or missing references)
		//IL_0134: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ff: Unknown result type (might be due to invalid IL or missing references)
		//IL_0106: Unknown result type (might be due to invalid IL or missing references)
		//IL_0114: Unknown result type (might be due to invalid IL or missing references)
		//IL_0145: Unknown result type (might be due to invalid IL or missing references)
		//IL_014e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0157: Unknown result type (might be due to invalid IL or missing references)
		//IL_018b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0192: Unknown result type (might be due to invalid IL or missing references)
		//IL_0197: Unknown result type (might be due to invalid IL or missing references)
		//IL_01c9: Unknown result type (might be due to invalid IL or missing references)
		BoxCollider component = ((Component)_colliderTransform).GetComponent<BoxCollider>();
		if (Object.op_Implicit((Object)(object)component))
		{
			return Vector3.Scale(Vector3.Scale(component.size, _colliderTransform.localScale), _objectScale);
		}
		SphereCollider component2 = ((Component)_colliderTransform).GetComponent<SphereCollider>();
		if (Object.op_Implicit((Object)(object)component2))
		{
			float num = Mathf.Max(new float[3]
			{
				_colliderTransform.localScale.x,
				_colliderTransform.localScale.y,
				_colliderTransform.localScale.z
			});
			float num2 = Mathf.Max(new float[3] { _objectScale.x, _objectScale.y, _objectScale.z });
			float num3 = component2.radius * 2f * num * num2;
			return Vector3.one * num3;
		}
		CapsuleCollider component3 = ((Component)_colliderTransform).GetComponent<CapsuleCollider>();
		if (Object.op_Implicit((Object)(object)component3))
		{
			Vector3 localScale = _colliderTransform.localScale;
			float num4;
			float num5;
			if (component3.direction == 0)
			{
				num4 = Mathf.Max(localScale.y, localScale.z);
				num5 = localScale.x;
			}
			else if (component3.direction == 2)
			{
				num4 = Mathf.Max(localScale.x, localScale.y);
				num5 = localScale.z;
			}
			else
			{
				num4 = Mathf.Max(localScale.x, localScale.z);
				num5 = localScale.y;
			}
			float num6 = Mathf.Max(new float[3] { _objectScale.x, _objectScale.y, _objectScale.z });
			float num7 = component3.radius * num4 * num6;
			float num8 = component3.height * num5 * num6;
			float num9 = num7 * 2f;
			Vector3 result = Vector3.one * num9;
			if (component3.direction == 0)
			{
				result.x = num8;
			}
			else if (component3.direction == 2)
			{
				result.z = num8;
			}
			else
			{
				result.y = num8;
			}
			return result;
		}
		return Vector3.Scale(_colliderTransform.localScale, _objectScale);
	}

	private ParticleSystemShapeType GetShapeType(Transform _colliderTransform)
	{
		if (!Object.op_Implicit((Object)(object)((Component)_colliderTransform).GetComponent<SphereCollider>()))
		{
			return (ParticleSystemShapeType)5;
		}
		return (ParticleSystemShapeType)0;
	}

	private Vector3 GetRelativeRotation(Transform _particleSystemTransform, Quaternion _rotation)
	{
		//IL_0001: Unknown result type (might be due to invalid IL or missing references)
		//IL_0006: Unknown result type (might be due to invalid IL or missing references)
		//IL_000b: Unknown result type (might be due to invalid IL or missing references)
		//IL_000c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0011: Unknown result type (might be due to invalid IL or missing references)
		//IL_0014: Unknown result type (might be due to invalid IL or missing references)
		Quaternion val = Quaternion.Inverse(_particleSystemTransform.rotation) * _rotation;
		return val.eulerAngles;
	}

	private IEnumerator DestroyParticlesAfterTime(float time)
	{
		yield return (object)new WaitForSeconds(time);
		Object.Destroy((Object)(object)((Component)this).gameObject);
	}

	public void ImpactSmoke(int amount, Vector3 position, float size)
	{
		//IL_0018: Unknown result type (might be due to invalid IL or missing references)
		//IL_0019: Unknown result type (might be due to invalid IL or missing references)
		//IL_001e: Unknown result type (might be due to invalid IL or missing references)
		//IL_002a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0036: Unknown result type (might be due to invalid IL or missing references)
		//IL_003b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0042: Unknown result type (might be due to invalid IL or missing references)
		//IL_0047: Unknown result type (might be due to invalid IL or missing references)
		//IL_0061: Unknown result type (might be due to invalid IL or missing references)
		//IL_008c: Unknown result type (might be due to invalid IL or missing references)
		size = Mathf.Clamp(size, 0.7f, 1.5f);
		Vector3 localPosition = ((Component)this).transform.InverseTransformPoint(position);
		((Component)particleSystemSmoke).transform.localPosition = localPosition;
		MainModule main = particleSystemSmoke.main;
		ShapeModule shape = particleSystemSmoke.shape;
		float startSizeMultiplier = main.startSizeMultiplier;
		shape.scale = new Vector3(0.2f, 0.2f, 0.2f);
		float num = Mathf.Clamp(size / 4f, 0f, 2f);
		main.startSpeed = new MinMaxCurve(0f, num);
		main.startSizeXMultiplier *= size;
		main.startSizeYMultiplier *= size;
		main.startSizeZMultiplier *= size;
		particleSystemSmoke.Emit(amount);
		main.startSizeXMultiplier = startSizeMultiplier;
		main.startSizeYMultiplier = startSizeMultiplier;
		main.startSizeZMultiplier = startSizeMultiplier;
	}

	private void SpawnParticles(int bitCount, float size, Transform colliderTransform, Vector3 objectScale, Vector3 objectVelocity, Collider _collider)
	{
		//IL_000e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0013: Unknown result type (might be due to invalid IL or missing references)
		//IL_0016: Unknown result type (might be due to invalid IL or missing references)
		//IL_001d: Unknown result type (might be due to invalid IL or missing references)
		//IL_001f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0026: Unknown result type (might be due to invalid IL or missing references)
		//IL_002c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0031: Unknown result type (might be due to invalid IL or missing references)
		if (Object.op_Implicit((Object)(object)colliderTransform))
		{
			Bounds bounds = _collider.bounds;
			SpawnParticles(bitCount, size, bounds.center, GetEmissionScale(colliderTransform, objectScale), GetShapeType(colliderTransform), colliderTransform.rotation, objectVelocity);
		}
	}

	private void SpawnParticles(int _bitCount, float _size, Vector3 _position, Vector3 _emissionScale, ParticleSystemShapeType _shapeType, Quaternion _rotation, Vector3 _velocity)
	{
		//IL_001d: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Unknown result type (might be due to invalid IL or missing references)
		//IL_003f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0045: Unknown result type (might be due to invalid IL or missing references)
		//IL_0048: Invalid comparison between Unknown and I4
		//IL_0050: Unknown result type (might be due to invalid IL or missing references)
		//IL_0055: Unknown result type (might be due to invalid IL or missing references)
		//IL_005c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0061: Unknown result type (might be due to invalid IL or missing references)
		//IL_0064: Unknown result type (might be due to invalid IL or missing references)
		//IL_008d: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c6: Unknown result type (might be due to invalid IL or missing references)
		//IL_00db: Unknown result type (might be due to invalid IL or missing references)
		//IL_00dd: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ed: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f2: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f9: Unknown result type (might be due to invalid IL or missing references)
		//IL_00fe: Unknown result type (might be due to invalid IL or missing references)
		//IL_0101: Unknown result type (might be due to invalid IL or missing references)
		//IL_012a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0163: Unknown result type (might be due to invalid IL or missing references)
		//IL_0178: Unknown result type (might be due to invalid IL or missing references)
		//IL_017a: Unknown result type (might be due to invalid IL or missing references)
		//IL_018a: Unknown result type (might be due to invalid IL or missing references)
		//IL_018f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0196: Unknown result type (might be due to invalid IL or missing references)
		//IL_019b: Unknown result type (might be due to invalid IL or missing references)
		//IL_01a6: Unknown result type (might be due to invalid IL or missing references)
		//IL_01ce: Unknown result type (might be due to invalid IL or missing references)
		//IL_024b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0257: Unknown result type (might be due to invalid IL or missing references)
		//IL_026c: Unknown result type (might be due to invalid IL or missing references)
		//IL_026e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0323: Unknown result type (might be due to invalid IL or missing references)
		//IL_0328: Unknown result type (might be due to invalid IL or missing references)
		//IL_035c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0361: Unknown result type (might be due to invalid IL or missing references)
		//IL_0395: Unknown result type (might be due to invalid IL or missing references)
		//IL_039a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0306: Unknown result type (might be due to invalid IL or missing references)
		//IL_0316: Unknown result type (might be due to invalid IL or missing references)
		_size = Mathf.Clamp(_size, 0.1f, 10f);
		((Component)particleSystemBits).transform.position = _position;
		((Component)particleSystemBitsSmall).transform.position = _position;
		((Component)particleSystemSmoke).transform.position = _position;
		bool flag = (int)_shapeType == 0;
		ShapeModule shape = particleSystemBits.shape;
		MainModule main = particleSystemBits.main;
		shape.shapeType = _shapeType;
		if (flag)
		{
			shape.radiusThickness = 0.1f;
		}
		else
		{
			shape.boxThickness = new Vector3(0.1f, 0.1f, 0.1f);
		}
		main.startSizeXMultiplier *= _size;
		main.startSizeYMultiplier *= _size;
		main.startSizeZMultiplier *= _size;
		shape.scale = _emissionScale;
		shape.rotation = GetRelativeRotation(((Component)particleSystemBits).transform, _rotation);
		shape = particleSystemBitsSmall.shape;
		main = particleSystemBitsSmall.main;
		shape.shapeType = _shapeType;
		if (flag)
		{
			shape.radiusThickness = 0.1f;
		}
		else
		{
			shape.boxThickness = new Vector3(0.1f, 0.1f, 0.1f);
		}
		main.startSizeXMultiplier *= _size;
		main.startSizeYMultiplier *= _size;
		main.startSizeZMultiplier *= _size;
		shape.scale = _emissionScale;
		shape.rotation = GetRelativeRotation(((Component)particleSystemBitsSmall).transform, _rotation);
		shape = particleSystemSmoke.shape;
		main = particleSystemSmoke.main;
		float startSizeMultiplier = main.startSizeMultiplier;
		shape.shapeType = _shapeType;
		if (flag)
		{
			shape.radiusThickness = 0.3f;
		}
		else
		{
			shape.boxThickness = new Vector3(0.3f, 0.3f, 0.3f);
		}
		main.startSizeXMultiplier *= Mathf.Clamp(_size, 0.4f, 1.5f);
		main.startSizeYMultiplier *= Mathf.Clamp(_size, 0.4f, 1.5f);
		main.startSizeZMultiplier *= Mathf.Clamp(_size, 0.4f, 1.5f);
		float num = Mathf.Clamp(_size, 0.4f, 2f);
		main.startSpeed = new MinMaxCurve(0f, num);
		shape.scale = _emissionScale;
		shape.rotation = GetRelativeRotation(((Component)particleSystemSmoke).transform, _rotation);
		int particleCount = particleSystemBits.particleCount;
		int particleCount2 = particleSystemBitsSmall.particleCount;
		particleSystemBits.Emit(_bitCount);
		particleSystemBitsSmall.Emit(_bitCount / 3);
		if (!particleSystemSmokeDisable)
		{
			particleSystemSmoke.Emit(_bitCount);
		}
		particlesSpawned = true;
		RandomizeSize(particleSystemBits, particleCount, 0.3f, _size);
		RandomizeSize(particleSystemBitsSmall, particleCount2, 0.3f, _size);
		if (_velocity.sqrMagnitude > 0.01f)
		{
			ApplyVelocity(particleSystemBits, particleCount, _velocity);
			ApplyVelocity(particleSystemBitsSmall, particleCount2, _velocity);
		}
		main = particleSystemBits.main;
		main.startSizeXMultiplier /= _size;
		main.startSizeYMultiplier /= _size;
		main.startSizeZMultiplier /= _size;
		main = particleSystemBitsSmall.main;
		main.startSizeXMultiplier /= _size;
		main.startSizeYMultiplier /= _size;
		main.startSizeZMultiplier /= _size;
		main = particleSystemSmoke.main;
		main.startSizeXMultiplier = startSizeMultiplier;
		main.startSizeYMultiplier = startSizeMultiplier;
		main.startSizeZMultiplier = startSizeMultiplier;
	}

	private void RandomizeSize(ParticleSystem _particleSystem, int _previousCount, float _variance, float _baseSize)
	{
		//IL_0081: Unknown result type (might be due to invalid IL or missing references)
		//IL_0097: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a9: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ae: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b5: Unknown result type (might be due to invalid IL or missing references)
		//IL_00bf: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c4: Unknown result type (might be due to invalid IL or missing references)
		int particleCount = _particleSystem.particleCount;
		if (particleCount > _previousCount)
		{
			Particle[] array = new Particle[particleCount];
			_particleSystem.GetParticles(array);
			for (int i = _previousCount; i < particleCount; i++)
			{
				float num = Random.Range(1f - _variance, 1f + _variance);
				float num2 = Mathf.Clamp(array[i].startSize * num, 0.01f, 5f);
				array[i].startSize = num2;
				float num3 = Mathf.Clamp01(num2 / Mathf.Max(_baseSize, 0.01f));
				ref Particle reference = ref array[i];
				reference.velocity *= Mathf.Lerp(1f, 0.15f, num3);
				ref Particle reference2 = ref array[i];
				reference2.velocity += Vector3.down * num3 * 3f;
				array[i].startLifetime = Mathf.Max(0.1f, array[i].startLifetime * Mathf.Lerp(1f, 0.4f, num3));
			}
			_particleSystem.SetParticles(array, particleCount);
		}
	}

	private void ApplyVelocity(ParticleSystem _particleSystem, int _previousCount, Vector3 _velocity)
	{
		//IL_0033: Unknown result type (might be due to invalid IL or missing references)
		//IL_0038: Unknown result type (might be due to invalid IL or missing references)
		//IL_0039: Unknown result type (might be due to invalid IL or missing references)
		int particleCount = _particleSystem.particleCount;
		if (particleCount <= _previousCount)
		{
			return;
		}
		Particle[] array = new Particle[particleCount];
		_particleSystem.GetParticles(array);
		for (int i = _previousCount; i < particleCount; i++)
		{
			if (Random.value > 0.3f)
			{
				ref Particle reference = ref array[i];
				reference.velocity += _velocity;
			}
		}
		_particleSystem.SetParticles(array, particleCount);
	}

	private void LateUpdate()
	{
		//IL_000f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0014: Unknown result type (might be due to invalid IL or missing references)
		//IL_0061: Unknown result type (might be due to invalid IL or missing references)
		//IL_0066: Unknown result type (might be due to invalid IL or missing references)
		//IL_0074: Unknown result type (might be due to invalid IL or missing references)
		//IL_0076: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a0: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a5: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f4: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f9: Unknown result type (might be due to invalid IL or missing references)
		//IL_0108: Unknown result type (might be due to invalid IL or missing references)
		//IL_010a: Unknown result type (might be due to invalid IL or missing references)
		if (particlesSpawned)
		{
			MainModule main = particleSystemBits.main;
			int maxParticles = main.maxParticles;
			if (particles == null || particles.Length < maxParticles)
			{
				particles = new Particle[maxParticles];
			}
			int num = particleSystemBits.GetParticles(particles);
			for (int i = 0; i < num; i++)
			{
				float num2 = (float)i / (float)num;
				Color val = gradient.Evaluate(num2);
				particles[i].startColor = Color32.op_Implicit(val);
			}
			particleSystemBits.SetParticles(particles, num);
			main = particleSystemBitsSmall.main;
			maxParticles = main.maxParticles;
			if (particles == null || particles.Length < maxParticles)
			{
				particles = new Particle[maxParticles];
			}
			num = particleSystemBitsSmall.GetParticles(particles);
			for (int j = 0; j < num; j++)
			{
				float num3 = (float)j / (float)num;
				Color val2 = gradient.Evaluate(num3);
				particles[j].startColor = Color32.op_Implicit(val2);
			}
			particleSystemBitsSmall.SetParticles(particles, num);
			particlesSpawned = false;
		}
	}
}
