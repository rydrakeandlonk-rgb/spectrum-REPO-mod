using UnityEngine;

[CreateAssetMenu(menuName = "Other/Debug Valuable Meshes")]
public class DebugValuableMeshes : ScriptableObject
{
	public Mesh tiny;

	public Mesh small;

	public Mesh medium;

	public Mesh big;

	public Mesh wide;

	public Mesh tall;

	public Mesh veryTall;
}
