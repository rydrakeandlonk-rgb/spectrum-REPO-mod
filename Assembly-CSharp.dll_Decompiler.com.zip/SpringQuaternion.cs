using System;
using UnityEngine;

[Serializable]
public class SpringQuaternion
{
	public float damping = 0.5f;

	public float speed = 10f;

	[Space]
	public bool clamp;

	public float maxAngle = 20f;

	public bool clampAdvanced;

	public bool clampX;

	public float minAngleX;

	public float maxAngleX;

	public bool clampY;

	public float minAngleY;

	public float maxAngleY;

	public bool clampZ;

	public float minAngleZ;

	public float maxAngleZ;

	[Range(0f, 1f)]
	public float bounce = 0.5f;

	internal Quaternion lastRotation;

	internal Vector3 springVelocity = Vector3.zero;

	internal bool setup;

	public SpringQuaternion()
	{
		//IL_002d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0032: Unknown result type (might be due to invalid IL or missing references)
	}
}
