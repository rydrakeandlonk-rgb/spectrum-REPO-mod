using Photon.Pun;
using UnityEngine;
using UnityEngine.AI;

[RequireComponent(typeof(NavMeshAgent))]
public class EnemyNavMeshAgent : MonoBehaviour
{
	internal NavMeshAgent Agent;

	internal Vector3 AgentVelocity;

	public bool updateRotation;

	private float StopTimer;

	private float DisableTimer;

	internal float DefaultSpeed;

	internal float DefaultAcceleration;

	private float OverrideTimer;

	private float SetPathTimer;

	private NavMeshPath calculatedPath;

	private NavMeshPath invalidPath;

	private bool navMeshReadyPending;

	private void Awake()
	{
		Agent = ((Component)this).GetComponent<NavMeshAgent>();
		if (!updateRotation)
		{
			Agent.updateRotation = false;
		}
		if (GameManager.instance.gameMode == 0 || PhotonNetwork.IsMasterClient)
		{
			((Behaviour)Agent).enabled = true;
		}
		else
		{
			((Behaviour)Agent).enabled = false;
		}
		DefaultSpeed = Agent.speed;
		DefaultAcceleration = Agent.acceleration;
	}

	private void OnEnable()
	{
		if (!NavMeshReadyWait())
		{
			NavMeshValidate();
		}
	}

	private bool NavMeshReadyWait()
	{
		if (LevelGenerator.Instance.NavMeshReady)
		{
			return false;
		}
		navMeshReadyPending = true;
		((Behaviour)Agent).enabled = false;
		return true;
	}

	private void NavMeshValidate()
	{
		//IL_002c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0072: Unknown result type (might be due to invalid IL or missing references)
		//IL_00cc: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d1: Unknown result type (might be due to invalid IL or missing references)
		navMeshReadyPending = false;
		NavMeshHit val = default;
		if (Debug.isDebugBuild && !Agent.isOnNavMesh && !NavMesh.SamplePosition(((Component)Agent).transform.position, ref val, 10f, -1))
		{
			string text = "Enemy: Not on navmesh: ";
			string text2 = text;
			EnemyParent componentInParent = ((Component)this).GetComponentInParent<EnemyParent>();
			text = text2 + "\n     Enemy Name: " + ((componentInParent != null) ? ((Object)componentInParent).name : null);
			if (SemiFunc.GetModuleAtPosition(((Component)Agent).transform.position, out var module, out var localPosition))
			{
				text = text + "\n     Module Name: " + ((Object)module).name;
				text = text + "\n     Local Position: " + ((object)localPosition/*cast due to constrained. prefix*/).ToString();
			}
			else
			{
				text += "\n     Module Name: N/A";
				text = text + "\n     Position: " + ((object)((Component)Agent).transform.position/*cast due to constrained. prefix*/).ToString();
			}
			Debug.LogError((object)(text + "\n"), (Object)(object)((Component)this).gameObject);
		}
	}

	private void Update()
	{
		//IL_001e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0023: Unknown result type (might be due to invalid IL or missing references)
		if (NavMeshReadyWait())
		{
			return;
		}
		if (navMeshReadyPending)
		{
			NavMeshValidate();
		}
		AgentVelocity = Agent.velocity;
		if (SetPathTimer > 0f)
		{
			SetPathTimer -= Time.deltaTime;
		}
		if (DisableTimer > 0f)
		{
			((Behaviour)Agent).enabled = false;
			DisableTimer -= Time.deltaTime;
			return;
		}
		if (!((Behaviour)Agent).enabled)
		{
			((Behaviour)Agent).enabled = true;
		}
		if (StopTimer > 0f)
		{
			if (((Behaviour)Agent).enabled && Agent.isOnNavMesh)
			{
				Agent.isStopped = true;
			}
			StopTimer -= Time.deltaTime;
		}
		else if (((Behaviour)Agent).enabled && Agent.isOnNavMesh && Agent.isStopped)
		{
			Agent.isStopped = false;
		}
		if (OverrideTimer > 0f)
		{
			OverrideTimer -= Time.deltaTime;
			if (OverrideTimer <= 0f)
			{
				Agent.speed = DefaultSpeed;
				Agent.acceleration = DefaultAcceleration;
			}
		}
	}

	public void OverrideAgent(float speed, float acceleration, float time)
	{
		Agent.speed = speed;
		Agent.acceleration = acceleration;
		OverrideTimer = time;
	}

	public void UpdateAgent(float speed, float acceleration)
	{
		Agent.speed = speed;
		Agent.acceleration = acceleration;
	}

	public void AgentMove(Vector3 position)
	{
		//IL_000f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0014: Unknown result type (might be due to invalid IL or missing references)
		//IL_001b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0020: Unknown result type (might be due to invalid IL or missing references)
		//IL_0022: Unknown result type (might be due to invalid IL or missing references)
		//IL_0032: Unknown result type (might be due to invalid IL or missing references)
		//IL_003a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0046: Unknown result type (might be due to invalid IL or missing references)
		if (!NavMeshReadyWait())
		{
			Vector3 velocity = Agent.velocity;
			Vector3 destination = Agent.destination;
			if (OnNavmesh(position))
			{
				Warp(position);
				SetDestination(destination);
				Agent.velocity = velocity;
			}
		}
	}

	public bool Move(Vector3 _delta)
	{
		//IL_0022: Unknown result type (might be due to invalid IL or missing references)
		if (!((Behaviour)Agent).enabled || !Agent.isOnNavMesh)
		{
			return false;
		}
		Agent.Move(_delta);
		return true;
	}

	public bool OnNavmesh(Vector3 position, float range = 5f, bool _checkPit = false)
	{
		//IL_0000: Unknown result type (might be due to invalid IL or missing references)
		//IL_0011: Unknown result type (might be due to invalid IL or missing references)
		//IL_0016: Unknown result type (might be due to invalid IL or missing references)
		NavMeshHit val = default;
		if (NavMesh.SamplePosition(position, ref val, range, -1))
		{
			if (!_checkPit)
			{
				return true;
			}
			if (Physics.Raycast(val.position, Vector3.down, 5f, LayerMask.GetMask(new string[1] { "Default" })))
			{
				return true;
			}
		}
		return false;
	}

	public void Warp(Vector3 position, bool _force = false)
	{
		//IL_0012: Unknown result type (might be due to invalid IL or missing references)
		//IL_0017: Unknown result type (might be due to invalid IL or missing references)
		//IL_003f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0054: Unknown result type (might be due to invalid IL or missing references)
		if (NavMeshReadyWait() || (!_force && Vector3.Distance(((Component)this).transform.position, position) < 1f))
		{
			return;
		}
		if (DisableTimer > 0f)
		{
			((Behaviour)Agent).enabled = true;
		}
		if (OnNavmesh(position))
		{
			Agent.Warp(position);
			if (DisableTimer > 0f)
			{
				((Behaviour)Agent).enabled = false;
			}
		}
	}

	public void ResetPath()
	{
		if (((Behaviour)Agent).enabled && Agent.isOnNavMesh && HasPath())
		{
			Agent.ResetPath();
		}
	}

	public bool CanReach(Vector3 _target, float _range)
	{
		//IL_001f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		if (!((Behaviour)Agent).enabled)
		{
			return true;
		}
		if (!Agent.hasPath)
		{
			return true;
		}
		if (Vector3.Distance(GetPoint(), _target) > _range)
		{
			return false;
		}
		return true;
	}

	public void SetDestination(Vector3 position)
	{
		//IL_0039: Unknown result type (might be due to invalid IL or missing references)
		if (((Behaviour)Agent).enabled && Agent.isOnNavMesh)
		{
			if (!Agent.hasPath)
			{
				SetPathTimer = 0.1f;
			}
			Agent.SetDestination(position);
		}
	}

	public void Stop(float time)
	{
		if (((Behaviour)Agent).enabled && Agent.isOnNavMesh)
		{
			StopTimer = time;
			if (StopTimer == 0f)
			{
				Agent.isStopped = false;
			}
			else
			{
				Agent.isStopped = true;
			}
		}
	}

	public bool IsStopped()
	{
		if (StopTimer > 0f)
		{
			return true;
		}
		return false;
	}

	public void Disable(float time)
	{
		((Behaviour)Agent).enabled = false;
		DisableTimer = time;
	}

	public void Enable()
	{
		if (!NavMeshReadyWait() && DisableTimer > 0f)
		{
			((Behaviour)Agent).enabled = true;
			DisableTimer = 0f;
		}
	}

	public bool IsDisabled()
	{
		if (DisableTimer > 0f)
		{
			return true;
		}
		return false;
	}

	public Vector3 GetPoint()
	{
		//IL_0028: Unknown result type (might be due to invalid IL or missing references)
		//IL_0013: Unknown result type (might be due to invalid IL or missing references)
		if (Agent.hasPath)
		{
			return Agent.pathEndPosition;
		}
		return new Vector3(-1000f, 1000f, 1000f);
	}

	public Vector3 GetDestination()
	{
		//IL_001f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0013: Unknown result type (might be due to invalid IL or missing references)
		if (Agent.hasPath)
		{
			return Agent.destination;
		}
		return ((Component)this).transform.position;
	}

	public bool HasPath()
	{
		if (SetPathTimer > 0f || Agent.hasPath)
		{
			return true;
		}
		return false;
	}

	public NavMeshPath CalculatePath(Vector3 position)
	{
		//IL_0040: Unknown result type (might be due to invalid IL or missing references)
		//IL_0030: Unknown result type (might be due to invalid IL or missing references)
		//IL_003a: Expected Obj, but got Unknown
		//IL_0016: Unknown result type (might be due to invalid IL or missing references)
		//IL_0020: Expected Obj, but got Unknown
		if (!((Behaviour)Agent).enabled)
		{
			if (invalidPath == null)
			{
				invalidPath = new NavMeshPath();
			}
			return invalidPath;
		}
		if (calculatedPath == null)
		{
			calculatedPath = new NavMeshPath();
		}
		Agent.CalculatePath(position, calculatedPath);
		return calculatedPath;
	}
}
