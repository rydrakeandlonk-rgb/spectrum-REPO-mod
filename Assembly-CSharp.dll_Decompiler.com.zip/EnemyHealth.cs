using System;
using System.Collections.Generic;
using Photon.Pun;
using UnityEngine;
using UnityEngine.Events;

public class EnemyHealth : MonoBehaviour
{
	private PhotonView photonView;

	private Enemy enemy;

	private float damageResistance;

	private float overrideDamageResistanceTimer;

	public int health = 100;

	internal int healthCurrent;

	private bool deadImpulse;

	internal bool dead;

	private float deadImpulseTimer;

	public float deathFreezeTime = 0.1f;

	public bool impactHurt;

	public int impactLightDamage;

	public int impactMediumDamage;

	public int impactHeavyDamage;

	public bool objectHurt;

	public float objectHurtMultiplier = 1f;

	public bool objectHurtStun = true;

	internal float objectHurtStunTime = 2f;

	public Transform meshParent;

	internal List<MeshRenderer> renderers;

	private List<Material> sharedMaterials = new List<Material>();

	internal List<Material> instancedMaterials = new List<Material>();

	public bool spawnValuable = true;

	public int spawnValuableMax = 3;

	internal int spawnValuableCurrent;

	private Color hurtColor = Color.red;

	private Color healColor = new Color(0f, 1f, 0.25f);

	internal Vector3 hurtDirection;

	private bool hurtEffect;

	internal AnimationCurve hurtCurve;

	internal float hurtLerp;

	public UnityEvent onHurt;

	private bool onHurtImpulse;

	public UnityEvent onDeathStart;

	public UnityEvent onDeath;

	public UnityEvent onObjectHurt;

	internal PlayerAvatar onObjectHurtPlayer;

	internal PhysGrabObject onObjectHurtPhysObject;

	internal int materialHurtColor;

	internal int materialHurtAmount;

	internal float nonStunHurtTimer;

	internal float objectHurtDisableTimer;

	internal float deathPitCooldown;

	internal event Action onDeathVisuals;

	private void Awake()
	{
		//IL_017c: Unknown result type (might be due to invalid IL or missing references)
		enemy = ((Component)this).GetComponent<Enemy>();
		photonView = ((Component)this).GetComponent<PhotonView>();
		healthCurrent = health;
		hurtCurve = AssetManager.instance.animationCurveImpact;
		renderers = new List<MeshRenderer>();
		if (Object.op_Implicit((Object)(object)meshParent))
		{
			renderers.AddRange(((Component)meshParent).GetComponentsInChildren<MeshRenderer>(true));
		}
		foreach (MeshRenderer renderer in renderers)
		{
			if (!Object.op_Implicit((Object)(object)((Renderer)renderer).sharedMaterial))
			{
				continue;
			}
			Material val = null;
			foreach (Material sharedMaterial in sharedMaterials)
			{
				if (((Object)((Renderer)renderer).sharedMaterial).name == ((Object)sharedMaterial).name)
				{
					val = sharedMaterial;
					((Renderer)renderer).sharedMaterial = instancedMaterials[sharedMaterials.IndexOf(sharedMaterial)];
				}
			}
			if (!Object.op_Implicit((Object)(object)val))
			{
				val = ((Renderer)renderer).sharedMaterial;
				sharedMaterials.Add(val);
				instancedMaterials.Add(((Renderer)renderer).material);
			}
		}
		materialHurtColor = Shader.PropertyToID("_ColorOverlay");
		materialHurtAmount = Shader.PropertyToID("_ColorOverlayAmount");
		foreach (Material instancedMaterial in instancedMaterials)
		{
			instancedMaterial.SetColor(materialHurtColor, hurtColor);
		}
	}

	private void Update()
	{
		//IL_0146: Unknown result type (might be due to invalid IL or missing references)
		//IL_014c: Unknown result type (might be due to invalid IL or missing references)
		if (overrideDamageResistanceTimer <= 0f)
		{
			damageResistance = 0f;
		}
		if (overrideDamageResistanceTimer > 0f)
		{
			overrideDamageResistanceTimer -= Time.deltaTime;
		}
		if (hurtEffect)
		{
			hurtLerp += 2.5f * Time.deltaTime;
			hurtLerp = Mathf.Clamp01(hurtLerp);
			foreach (Material instancedMaterial in instancedMaterials)
			{
				instancedMaterial.SetFloat(materialHurtAmount, hurtCurve.Evaluate(hurtLerp));
			}
			if (hurtLerp > 1f)
			{
				hurtEffect = false;
				foreach (Material instancedMaterial2 in instancedMaterials)
				{
					instancedMaterial2.SetFloat(materialHurtAmount, 0f);
				}
			}
		}
		if ((!GameManager.Multiplayer() || PhotonNetwork.IsMasterClient) && deadImpulse)
		{
			deadImpulseTimer -= Time.deltaTime;
			if (deadImpulseTimer <= 0f)
			{
				if (!GameManager.Multiplayer())
				{
					DeathImpulseRPC();
				}
				else
				{
					photonView.RPC("DeathImpulseRPC", (RpcTarget)0, Array.Empty<object>());
				}
			}
		}
		if (nonStunHurtTimer > 0f)
		{
			nonStunHurtTimer -= Time.deltaTime;
		}
		if (objectHurtDisableTimer > 0f)
		{
			objectHurtDisableTimer -= Time.deltaTime;
		}
		if (deathPitCooldown > 0f)
		{
			deathPitCooldown -= Time.deltaTime;
		}
		if (onHurtImpulse)
		{
			onHurt.Invoke();
			onHurtImpulse = false;
		}
	}

	public void OnSpawn()
	{
		if (hurtEffect)
		{
			hurtLerp = 1f;
			hurtEffect = false;
			foreach (Material instancedMaterial in instancedMaterials)
			{
				instancedMaterial.SetFloat(materialHurtAmount, 0f);
			}
		}
		healthCurrent = health;
		dead = false;
	}

	public void LightImpact()
	{
		//IL_0048: Unknown result type (might be due to invalid IL or missing references)
		//IL_004d: Unknown result type (might be due to invalid IL or missing references)
		if (impactHurt && (enemy.IsStunned() || !(nonStunHurtTimer <= 0f)) && impactLightDamage > 0)
		{
			Hurt(impactLightDamage, -enemy.Rigidbody.impactDetector.previousPreviousVelocityRaw.normalized);
		}
	}

	public void MediumImpact()
	{
		//IL_0048: Unknown result type (might be due to invalid IL or missing references)
		//IL_004d: Unknown result type (might be due to invalid IL or missing references)
		if (impactHurt && (enemy.IsStunned() || !(nonStunHurtTimer <= 0f)) && impactMediumDamage > 0)
		{
			Hurt(impactMediumDamage, -enemy.Rigidbody.impactDetector.previousPreviousVelocityRaw.normalized);
		}
	}

	public void HeavyImpact()
	{
		//IL_0048: Unknown result type (might be due to invalid IL or missing references)
		//IL_004d: Unknown result type (might be due to invalid IL or missing references)
		if (impactHurt && (enemy.IsStunned() || !(nonStunHurtTimer <= 0f)) && impactHeavyDamage > 0)
		{
			Hurt(impactHeavyDamage, -enemy.Rigidbody.impactDetector.previousPreviousVelocityRaw.normalized);
		}
	}

	public void Hurt(int _damage, Vector3 _hurtDirection)
	{
		//IL_0050: Unknown result type (might be due to invalid IL or missing references)
		//IL_008d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0060: Unknown result type (might be due to invalid IL or missing references)
		//IL_0063: Unknown result type (might be due to invalid IL or missing references)
		//IL_0069: Unknown result type (might be due to invalid IL or missing references)
		if (!dead && !deadImpulse && SemiFunc.IsMasterClientOrSingleplayer())
		{
			healthCurrent -= (int)((float)_damage * (1f - Mathf.Min(damageResistance, 1f)));
			if (healthCurrent <= 0)
			{
				healthCurrent = 0;
				Death(_hurtDirection);
			}
			else if (!GameManager.Multiplayer())
			{
				HurtRPC(_damage, _hurtDirection);
			}
			else
			{
				photonView.RPC("HurtRPC", (RpcTarget)0, new object[2] { _damage, _hurtDirection });
			}
		}
	}

	[PunRPC]
	public void HurtRPC(int _damage, Vector3 _hurtDirection, PhotonMessageInfo _info = default(PhotonMessageInfo))
	{
		//IL_0000: Unknown result type (might be due to invalid IL or missing references)
		//IL_000a: Unknown result type (might be due to invalid IL or missing references)
		//IL_000b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0011: Unknown result type (might be due to invalid IL or missing references)
		//IL_0016: Unknown result type (might be due to invalid IL or missing references)
		//IL_002f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0023: Unknown result type (might be due to invalid IL or missing references)
		//IL_0028: Unknown result type (might be due to invalid IL or missing references)
		if (SemiFunc.MasterOnlyRPC(_info))
		{
			hurtDirection = _hurtDirection;
			if (hurtDirection == Vector3.zero)
			{
				hurtDirection = Random.insideUnitSphere;
			}
			MaterialColorFlash(hurtColor);
			onHurtImpulse = true;
		}
	}

	public void Heal(int _amount)
	{
		//IL_0046: Unknown result type (might be due to invalid IL or missing references)
		//IL_004c: Unknown result type (might be due to invalid IL or missing references)
		if (dead || deadImpulse || !SemiFunc.IsMasterClientOrSingleplayer() || _amount <= 0)
		{
			return;
		}
		int num = healthCurrent;
		healthCurrent += _amount;
		if (healthCurrent != num)
		{
			if (!GameManager.Multiplayer())
			{
				HealRPC();
			}
			else
			{
				photonView.RPC("HealRPC", (RpcTarget)0, Array.Empty<object>());
			}
		}
	}

	[PunRPC]
	public void HealRPC(PhotonMessageInfo _info = default(PhotonMessageInfo))
	{
		//IL_0000: Unknown result type (might be due to invalid IL or missing references)
		//IL_000b: Unknown result type (might be due to invalid IL or missing references)
		if (SemiFunc.MasterOnlyRPC(_info))
		{
			MaterialColorFlash(healColor);
		}
	}

	private void Death(Vector3 _deathDirection)
	{
		//IL_002c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0008: Unknown result type (might be due to invalid IL or missing references)
		//IL_000b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0011: Unknown result type (might be due to invalid IL or missing references)
		if (!GameManager.Multiplayer())
		{
			DeathRPC(_deathDirection);
			return;
		}
		photonView.RPC("DeathRPC", (RpcTarget)0, new object[1] { _deathDirection });
	}

	[PunRPC]
	public void DeathRPC(Vector3 _deathDirection, PhotonMessageInfo _info = default(PhotonMessageInfo))
	{
		//IL_0000: Unknown result type (might be due to invalid IL or missing references)
		//IL_000a: Unknown result type (might be due to invalid IL or missing references)
		//IL_000b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0041: Unknown result type (might be due to invalid IL or missing references)
		if (SemiFunc.MasterOnlyRPC(_info))
		{
			hurtDirection = _deathDirection;
			deadImpulseTimer = deathFreezeTime;
			enemy.Freeze(deathFreezeTime);
			onDeathStart.Invoke();
			deadImpulse = true;
			MaterialColorFlash(hurtColor);
		}
	}

	[PunRPC]
	public void DeathImpulseRPC(PhotonMessageInfo _info = default(PhotonMessageInfo))
	{
		//IL_0000: Unknown result type (might be due to invalid IL or missing references)
		//IL_0018: Unknown result type (might be due to invalid IL or missing references)
		//IL_001d: Unknown result type (might be due to invalid IL or missing references)
		//IL_002a: Unknown result type (might be due to invalid IL or missing references)
		//IL_002f: Unknown result type (might be due to invalid IL or missing references)
		if (SemiFunc.MasterOnlyRPC(_info))
		{
			deadImpulse = false;
			dead = true;
			if (hurtDirection == Vector3.zero)
			{
				hurtDirection = Random.insideUnitSphere;
			}
			onDeathVisuals?.Invoke();
			onDeath.Invoke();
		}
	}

	public void ObjectHurtDisable(float _time)
	{
		objectHurtDisableTimer = _time;
	}

	public void NonStunHurtOverride(float _time)
	{
		nonStunHurtTimer = _time;
	}

	public void DeathPitCooldown()
	{
		deathPitCooldown = 1f;
	}

	public void OverrideDamageResistance(float _resistance, float _time)
	{
		damageResistance = _resistance;
		overrideDamageResistanceTimer = _time;
	}

	private void MaterialColorFlash(Color color)
	{
		//IL_002e: Unknown result type (might be due to invalid IL or missing references)
		hurtEffect = true;
		hurtLerp = 0f;
		foreach (Material instancedMaterial in instancedMaterials)
		{
			instancedMaterial.SetColor(materialHurtColor, color);
			instancedMaterial.SetFloat(materialHurtAmount, 0f);
		}
	}

	public EnemyHealth()
	{
		//IL_0055: Unknown result type (might be due to invalid IL or missing references)
		//IL_005a: Unknown result type (might be due to invalid IL or missing references)
		//IL_006f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0074: Unknown result type (might be due to invalid IL or missing references)
	}
}
