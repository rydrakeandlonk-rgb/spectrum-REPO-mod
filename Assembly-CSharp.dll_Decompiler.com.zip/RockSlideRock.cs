using System;
using System.Collections.Generic;
using Photon.Pun;
using UnityEngine;
using UnityEngine.Events;
using UnityEngine.SceneManagement;

public class RockSlideRock : MonoBehaviour
{
	[Serializable]
	public struct SizePhysAttribute
	{
		[Tooltip("rock uses this preset once its size multiplier reaches at least this much")]
		public float minSizeMultiplier;

		public PhysAttribute preset;
	}

	public GameObject hurtColliderObject;

	public HurtCollider hurtCollider;

	[Tooltip("visual-only mesh child. gets scaled in on spawn and out on despawn so the rock never just pops in or out")]
	public Transform meshTransform;

	[Tooltip("dust/debris kicked up while the rock is moving fast. emits on the same speed gate as the slide loop and stops emitting when it slows down")]
	public ParticleSystem slideParticles;

	public Vector2 sizeRange = new Vector2(0.6f, 1.2f);

	[Tooltip("ordered light->heavy. rock picks the heaviest preset whose min size it reaches. medium++ should sit at 1x size")]
	public SizePhysAttribute[] sizePresets;

	public float impactPitchSmall = 1.3f;

	public float impactPitchBig = 0.75f;

	public float loopPitchSmall = 1.3f;

	public float loopPitchBig = 0.75f;

	[Tooltip("each rock picks a random launch kick in this range, so they don't all leave the slope at the exact same speed")]
	public Vector2 launchForce = new Vector2(6f, 10f);

	public float launchTorque = 12f;

	public float continuousForce = 14f;

	public float continuousTorque = 8f;

	public Vector2 pushDuration = new Vector2(4f, 6f);

	public float lifetime = 12f;

	[Tooltip("a rock farther than this from every player's eye is assumed unseen. keep it generous so a rock that's plainly visible across the desert never gets culled")]
	public float despawnSeeDistance = 60f;

	[Tooltip("freshly spawned rocks can't be despawned for this long, so they never vanish the instant they land")]
	public float despawnGracePeriod = 10f;

	[Tooltip("how long the mesh takes to grow in when the rock spawns")]
	public float meshScaleInTime = 0.25f;

	[Tooltip("how long the mesh takes to shrink away before the rock actually despawns")]
	public float meshScaleOutTime = 0.25f;

	[Tooltip("rock is harmless below the low end, full power at the high end, scales between")]
	public Vector2 speedRange = new Vector2(4f, 18f);

	[Tooltip("slide loop and dust particles only kick in at this speed. keep it above the speedRange low end so they don't play while the rock is just creeping along")]
	public float effectSpeed = 10f;

	[Tooltip("rock can't be broken by impacts for this long after it launches, so it never shatters the instant it slams into terrain on the way down")]
	public float spawnInvincibleTime = 2f;

	[Tooltip("rock has to be going at least this fast for a slam to shatter it, so it never breaks while gently rolling")]
	public float breakSpeed = 8f;

	[Tooltip("how much velocity it has to suddenly lose (or reverse) in a single physics step to count as a slam. a hard wall hit drops it to zero, a bounce-back reverses it, both clear this. higher = only really violent stops break it")]
	public float breakVelocityChange = 14f;

	[Tooltip("vertical slams need this many times more velocity change to break it than sideways ones. 2 = a straight-down landing has to hit twice as hard as a horizontal wall smack")]
	public float breakVerticalMultiplier = 2f;

	[Tooltip("once it's been alive this long, the rock shatters the moment its hurt collider touches anything, so it doesn't keep bouncing around hurting people forever")]
	public float hurtColliderBreakTime = 5f;

	public float hurtColliderOffset = 0.5f;

	public Vector2Int playerDamage = new Vector2Int(10, 50);

	public float playerTumbleTime = 2f;

	public Vector2Int enemyDamage = new Vector2Int(20, 120);

	public float enemyStunTime = 5f;

	public Vector2 launchPower = new Vector2(5f, 45f);

	public Sound launchSound;

	public Sound rockSlideLoop;

	private PhotonView photonView;

	private PhysGrabObject physGrabObject;

	private Rigidbody rb;

	private FakeVelocities fakeVelocities;

	private PhysGrabObjectImpactDetector impactDetector;

	private Collider seeCheckCollider;

	private static readonly List<RockSlideRock> activeRocks = new List<RockSlideRock>();

	private Vector3 moveDirection;

	private Vector3 torqueAxis;

	private float launchForceCurrent;

	private float pushTimer;

	private float lifeTimer;

	private float hurtColliderBreakTimer;

	private float despawnGraceTimer;

	private bool launched;

	private bool launchImpulsePending;

	internal float speed;

	private Vector3 travelDirection;

	private Vector3 previousVelocity;

	private float previousSpeed;

	private float spawnInvincibleTimer;

	private PhysAttribute physAttributeCurrent;

	private Vector3 meshBaseScale;

	private float meshIntroTimer;

	private bool despawning;

	private float despawnOutroTimer;

	private Vector3 baseScale;

	private float sizeMultiplier = 1f;

	private float loopPitchMultiplier = 1f;

	private float impactPitchCurrent = 1f;

	private void Awake()
	{
		//IL_006e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0073: Unknown result type (might be due to invalid IL or missing references)
		//IL_007f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0084: Unknown result type (might be due to invalid IL or missing references)
		//IL_008f: Unknown result type (might be due to invalid IL or missing references)
		//IL_009a: Unknown result type (might be due to invalid IL or missing references)
		//IL_009f: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ff: Unknown result type (might be due to invalid IL or missing references)
		//IL_0109: Expected Obj, but got Unknown
		physGrabObject = ((Component)this).GetComponent<PhysGrabObject>();
		rb = ((Component)this).GetComponent<Rigidbody>();
		fakeVelocities = ((Component)this).GetComponent<FakeVelocities>();
		impactDetector = ((Component)this).GetComponent<PhysGrabObjectImpactDetector>();
		photonView = ((Component)this).GetComponent<PhotonView>();
		Collider[] componentsInChildren = ((Component)this).GetComponentsInChildren<Collider>(true);
		foreach (Collider val in componentsInChildren)
		{
			if (!val.isTrigger)
			{
				seeCheckCollider = val;
				break;
			}
		}
		baseScale = ((Component)this).transform.localScale;
		meshBaseScale = meshTransform.localScale;
		meshTransform.localScale = Vector3.zero;
		travelDirection = Vector3.down;
		lifeTimer = lifetime;
		hurtColliderBreakTimer = hurtColliderBreakTime;
		despawnGraceTimer = despawnGracePeriod;
		HurtColliderSetup();
		RegisterRock();
		if (Object.op_Implicit((Object)(object)hurtColliderObject))
		{
			hurtColliderObject.SetActive(false);
		}
		impactDetector.onDestroy.AddListener((UnityAction)SlideParticlesDetach);
	}

	private void OnDestroy()
	{
		//IL_000c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0011: Unknown result type (might be due to invalid IL or missing references)
		UnregisterRock();
		Scene scene = ((Component)this).gameObject.scene;
		if (scene.isLoaded)
		{
			SlideParticlesDetach();
		}
	}

	private void Update()
	{
		OverrideMassLogic();
		OverrideImpactPitchLogic();
		SpeedTick();
		SpawnInvincibleTick();
		IndestructibleTick();
		LoopSoundLogic();
		SlideParticlesLogic();
		HurtColliderActivationLogic();
		LifetimeTick();
		DespawnLogic();
		DespawnTick();
		DespawnGraceTick();
		MeshScaleLogic();
	}

	private void FixedUpdate()
	{
		LaunchImpulseFixed();
		ContinuousPushFixed();
		BreakOnHardStopFixed();
		BreakOnHeavyImpactAfterLifetimeFixed();
	}

	private void LateUpdate()
	{
		HurtColliderFollow();
	}

	public void Launch(Vector3 _direction, float _sizeMultiplier)
	{
		//IL_0032: Unknown result type (might be due to invalid IL or missing references)
		//IL_0036: Unknown result type (might be due to invalid IL or missing references)
		//IL_003c: Unknown result type (might be due to invalid IL or missing references)
		//IL_001b: Unknown result type (might be due to invalid IL or missing references)
		if (SemiFunc.IsMultiplayer())
		{
			photonView.RPC("LaunchRPC", (RpcTarget)0, new object[2] { _direction, _sizeMultiplier });
		}
		else
		{
			LaunchRPC(_direction, _sizeMultiplier);
		}
	}

	[PunRPC]
	private void LaunchRPC(Vector3 _direction, float _sizeMultiplier, PhotonMessageInfo _info = default(PhotonMessageInfo))
	{
		//IL_0000: Unknown result type (might be due to invalid IL or missing references)
		//IL_0013: Unknown result type (might be due to invalid IL or missing references)
		//IL_0018: Unknown result type (might be due to invalid IL or missing references)
		//IL_001f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0030: Unknown result type (might be due to invalid IL or missing references)
		//IL_0035: Unknown result type (might be due to invalid IL or missing references)
		//IL_003a: Unknown result type (might be due to invalid IL or missing references)
		//IL_003d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0042: Unknown result type (might be due to invalid IL or missing references)
		//IL_0048: Unknown result type (might be due to invalid IL or missing references)
		//IL_004d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0060: Unknown result type (might be due to invalid IL or missing references)
		//IL_0065: Unknown result type (might be due to invalid IL or missing references)
		if (SemiFunc.MasterOnlyRPC(_info))
		{
			ApplySize(_sizeMultiplier);
			moveDirection = _direction.normalized;
			travelDirection = moveDirection;
			Vector3 val = Vector3.Cross(Vector3.up, moveDirection);
			torqueAxis = val.normalized;
			if (torqueAxis == Vector3.zero)
			{
				torqueAxis = ((Component)this).transform.right;
			}
			launched = true;
			launchImpulsePending = true;
			launchForceCurrent = Random.Range(launchForce.x, launchForce.y);
			pushTimer = Random.Range(pushDuration.x, pushDuration.y);
			spawnInvincibleTimer = spawnInvincibleTime;
			MeshIntroStart();
			launchSound.Play(((Component)this).transform);
		}
	}

	private void ApplySize(float _sizeMultiplier)
	{
		//IL_0029: Unknown result type (might be due to invalid IL or missing references)
		//IL_0034: Unknown result type (might be due to invalid IL or missing references)
		sizeMultiplier = Mathf.Clamp(_sizeMultiplier, sizeRange.x, sizeRange.y);
		((Component)this).transform.localScale = baseScale * sizeMultiplier;
		ApplyPhysAttributePreset(sizeMultiplier);
		float num = Mathf.InverseLerp(sizeRange.x, sizeRange.y, sizeMultiplier);
		loopPitchMultiplier = Mathf.Lerp(loopPitchSmall, loopPitchBig, num);
		impactPitchCurrent = Mathf.Lerp(impactPitchSmall, impactPitchBig, num);
	}

	private void ApplyPhysAttributePreset(float _size)
	{
		physAttributeCurrent = PhysAttributeForSize(_size);
	}

	private void OverrideMassLogic()
	{
		if (Object.op_Implicit((Object)(object)physAttributeCurrent) && SemiFunc.IsMasterClientOrSingleplayer())
		{
			physGrabObject.OverrideMass(physAttributeCurrent.mass);
		}
	}

	private PhysAttribute PhysAttributeForSize(float _size)
	{
		PhysAttribute physAttribute = null;
		float num = float.NegativeInfinity;
		PhysAttribute physAttribute2 = null;
		float num2 = float.PositiveInfinity;
		SizePhysAttribute[] array = sizePresets;
		for (int i = 0; i < array.Length; i++)
		{
			SizePhysAttribute sizePhysAttribute = array[i];
			if (Object.op_Implicit((Object)(object)sizePhysAttribute.preset))
			{
				if (sizePhysAttribute.minSizeMultiplier <= _size && sizePhysAttribute.minSizeMultiplier > num)
				{
					num = sizePhysAttribute.minSizeMultiplier;
					physAttribute = sizePhysAttribute.preset;
				}
				if (sizePhysAttribute.minSizeMultiplier < num2)
				{
					num2 = sizePhysAttribute.minSizeMultiplier;
					physAttribute2 = sizePhysAttribute.preset;
				}
			}
		}
		if (!Object.op_Implicit((Object)(object)physAttribute))
		{
			physAttribute = physAttribute2;
		}
		return physAttribute;
	}

	private bool ReadyForPhysics()
	{
		if (rb.isKinematic)
		{
			return false;
		}
		if (Object.op_Implicit((Object)(object)physGrabObject) && !physGrabObject.spawned)
		{
			return false;
		}
		return true;
	}

	private void LaunchImpulseFixed()
	{
		//IL_0021: Unknown result type (might be due to invalid IL or missing references)
		//IL_002c: Unknown result type (might be due to invalid IL or missing references)
		//IL_003c: Unknown result type (might be due to invalid IL or missing references)
		//IL_004e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0059: Unknown result type (might be due to invalid IL or missing references)
		//IL_0069: Unknown result type (might be due to invalid IL or missing references)
		if (SemiFunc.IsMasterClientOrSingleplayer() && launchImpulsePending && ReadyForPhysics())
		{
			rb.AddForce(moveDirection * launchForceCurrent * rb.mass, (ForceMode)1);
			rb.AddTorque(torqueAxis * launchTorque * rb.mass, (ForceMode)1);
			launchImpulsePending = false;
		}
	}

	private void ContinuousPushFixed()
	{
		//IL_0037: Unknown result type (might be due to invalid IL or missing references)
		//IL_0042: Unknown result type (might be due to invalid IL or missing references)
		//IL_0054: Unknown result type (might be due to invalid IL or missing references)
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		if (SemiFunc.IsMasterClientOrSingleplayer() && launched && !launchImpulsePending && ReadyForPhysics() && pushTimer > 0f)
		{
			rb.AddForce(moveDirection * continuousForce, (ForceMode)5);
			rb.AddTorque(torqueAxis * continuousTorque, (ForceMode)5);
			pushTimer -= Time.fixedDeltaTime;
		}
	}

	private void SpawnInvincibleTick()
	{
		if (!(spawnInvincibleTimer <= 0f))
		{
			if (SemiFunc.IsMasterClientOrSingleplayer())
			{
				physGrabObject.OverrideIndestructible();
			}
			spawnInvincibleTimer -= Time.deltaTime;
		}
	}

	private void IndestructibleTick()
	{
		if (SemiFunc.IsMasterClientOrSingleplayer() && Object.op_Implicit((Object)(object)physGrabObject) && launched && (pushTimer > 0f || speed >= speedRange.x))
		{
			physGrabObject.OverrideIndestructible();
		}
	}

	private void SpeedTick()
	{
		//IL_0020: Unknown result type (might be due to invalid IL or missing references)
		//IL_0013: Unknown result type (might be due to invalid IL or missing references)
		//IL_0025: Unknown result type (might be due to invalid IL or missing references)
		//IL_0042: Unknown result type (might be due to invalid IL or missing references)
		//IL_0049: Unknown result type (might be due to invalid IL or missing references)
		//IL_0059: Unknown result type (might be due to invalid IL or missing references)
		//IL_005e: Unknown result type (might be due to invalid IL or missing references)
		Vector3 val = (Object.op_Implicit((Object)(object)fakeVelocities) ? fakeVelocities.velocity : rb.linearVelocity);
		speed = val.magnitude;
		if (speed > 0.1f)
		{
			travelDirection = Vector3.Slerp(travelDirection, val.normalized, 10f * Time.deltaTime);
		}
	}

	private void BreakOnHardStopFixed()
	{
		//IL_0037: Unknown result type (might be due to invalid IL or missing references)
		//IL_003c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0089: Unknown result type (might be due to invalid IL or missing references)
		//IL_008a: Unknown result type (might be due to invalid IL or missing references)
		//IL_004c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0051: Unknown result type (might be due to invalid IL or missing references)
		//IL_0052: Unknown result type (might be due to invalid IL or missing references)
		//IL_0057: Unknown result type (might be due to invalid IL or missing references)
		if (!SemiFunc.IsMasterClientOrSingleplayer() || !launched || launchImpulsePending || spawnInvincibleTimer > 0f || !ReadyForPhysics())
		{
			return;
		}
		Vector3 linearVelocity = rb.linearVelocity;
		if (previousSpeed >= breakSpeed)
		{
			Vector3 val = previousVelocity - linearVelocity;
			val.y /= Mathf.Max(breakVerticalMultiplier, 0.01f);
			if (val.magnitude >= breakVelocityChange)
			{
				BreakRock();
			}
		}
		previousVelocity = linearVelocity;
		previousSpeed = linearVelocity.magnitude;
	}

	private void BreakOnHeavyImpactAfterLifetimeFixed()
	{
		if (SemiFunc.IsMasterClientOrSingleplayer() && launched && !launchImpulsePending && !(lifeTimer > 0f) && ReadyForPhysics() && physGrabObject.impactHeavyTimer > 0f)
		{
			BreakRock();
		}
	}

	private void OnHurtColliderHit()
	{
		if (physGrabObject.grabbed)
		{
			BreakRock();
		}
		else if (hurtColliderBreakTimer <= 0f)
		{
			BreakRock();
		}
	}

	private void BreakRock()
	{
		if (!physGrabObject.dead)
		{
			launched = false;
			HurtColliderDetach();
			impactDetector.DestroyObject();
		}
	}

	private void MeshIntroStart()
	{
		meshIntroTimer = meshScaleInTime;
	}

	private void MeshScaleLogic()
	{
		//IL_0062: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		float num = 1f;
		if (meshIntroTimer > 0f)
		{
			meshIntroTimer -= Time.deltaTime;
			num = MeshScaleEase(1f - meshIntroTimer / meshScaleInTime);
		}
		if (despawning)
		{
			num = MeshScaleEase(despawnOutroTimer / meshScaleOutTime);
		}
		meshTransform.localScale = meshBaseScale * num;
	}

	private float MeshScaleEase(float _t)
	{
		return Mathf.SmoothStep(0f, 1f, Mathf.Clamp01(_t));
	}

	private void SlideParticlesLogic()
	{
		if (!Object.op_Implicit((Object)(object)slideParticles))
		{
			return;
		}
		if (speed >= effectSpeed)
		{
			if (!slideParticles.isEmitting)
			{
				slideParticles.Play(true);
			}
		}
		else if (slideParticles.isEmitting)
		{
			slideParticles.Stop(true, (ParticleSystemStopBehavior)1);
		}
	}

	private void SlideParticlesDetach()
	{
		//IL_002a: Unknown result type (might be due to invalid IL or missing references)
		//IL_002f: Unknown result type (might be due to invalid IL or missing references)
		if (Object.op_Implicit((Object)(object)slideParticles))
		{
			ParticleSystem val = slideParticles;
			slideParticles = null;
			((Component)val).transform.SetParent((Transform)null, true);
			MainModule main = val.main;
			main.stopAction = (ParticleSystemStopAction)2;
			if (val.IsAlive(true))
			{
				val.Stop(true, (ParticleSystemStopBehavior)1);
			}
			else
			{
				Object.Destroy((Object)(object)((Component)val).gameObject);
			}
		}
	}

	private void LoopSoundLogic()
	{
		if (rockSlideLoop.Sounds.Length != 0)
		{
			bool playing = speed >= effectSpeed;
			rockSlideLoop.PlayLoop(playing, 2f, 2f, loopPitchMultiplier);
		}
	}

	private void OverrideImpactPitchLogic()
	{
		impactDetector.OverrideImpactAudioPitch(impactPitchCurrent);
	}

	private void HurtColliderSetup()
	{
		//IL_0036: Unknown result type (might be due to invalid IL or missing references)
		//IL_0040: Expected Obj, but got Unknown
		if (Object.op_Implicit((Object)(object)hurtCollider))
		{
			hurtCollider.ignoreObjects.Add(physGrabObject);
			hurtCollider.onImpactAny.AddListener((UnityAction)OnHurtColliderHit);
			hurtCollider.playerLogic = true;
			hurtCollider.playerKill = false;
			hurtCollider.playerTumbleTime = playerTumbleTime;
			hurtCollider.enemyLogic = true;
			hurtCollider.enemyKill = false;
			hurtCollider.enemyStun = true;
			hurtCollider.enemyStunTime = enemyStunTime;
			hurtCollider.enemyStunType = EnemyType.VeryHeavy;
			hurtCollider.enemyImpact = HurtCollider.BreakImpact.Heavy;
			hurtCollider.physLogic = true;
			hurtCollider.physDestroy = false;
			hurtCollider.physReleaseGrab = true;
			hurtCollider.physImpact = HurtCollider.BreakImpact.Heavy;
		}
	}

	private void RegisterRock()
	{
		foreach (RockSlideRock activeRock in activeRocks)
		{
			if (Object.op_Implicit((Object)(object)activeRock))
			{
				if (Object.op_Implicit((Object)(object)activeRock.hurtCollider))
				{
					activeRock.hurtCollider.ignoreObjects.Add(physGrabObject);
				}
				if (Object.op_Implicit((Object)(object)hurtCollider))
				{
					hurtCollider.ignoreObjects.Add(activeRock.physGrabObject);
				}
			}
		}
		activeRocks.Add(this);
	}

	private void UnregisterRock()
	{
		activeRocks.Remove(this);
		foreach (RockSlideRock activeRock in activeRocks)
		{
			if (Object.op_Implicit((Object)(object)activeRock) && Object.op_Implicit((Object)(object)activeRock.hurtCollider))
			{
				activeRock.hurtCollider.ignoreObjects.Remove(physGrabObject);
			}
		}
	}

	private void HurtColliderActivationLogic()
	{
		if (!Object.op_Implicit((Object)(object)hurtColliderObject))
		{
			return;
		}
		if (speed >= speedRange.x)
		{
			HurtColliderValues();
			if (!hurtColliderObject.activeSelf)
			{
				hurtColliderObject.SetActive(true);
			}
		}
		else if (hurtColliderObject.activeSelf)
		{
			hurtColliderObject.SetActive(false);
		}
	}

	private void HurtColliderValues()
	{
		if (Object.op_Implicit((Object)(object)hurtCollider))
		{
			float num = Mathf.InverseLerp(speedRange.x, speedRange.y, speed);
			float num2 = Mathf.Lerp(launchPower.x, launchPower.y, num);
			hurtCollider.playerDamage = Mathf.RoundToInt(Mathf.Lerp((float)playerDamage.x, (float)playerDamage.y, num));
			hurtCollider.playerTumbleForce = num2;
			hurtCollider.playerTumbleTorque = num2;
			hurtCollider.enemyDamage = Mathf.RoundToInt(Mathf.Lerp((float)enemyDamage.x, (float)enemyDamage.y, num));
			hurtCollider.enemyHitForce = num2;
			hurtCollider.enemyHitTorque = num2;
			hurtCollider.physHitForce = num2;
			hurtCollider.physHitTorque = num2;
		}
	}

	private void HurtColliderDetach()
	{
		//IL_0037: Unknown result type (might be due to invalid IL or missing references)
		//IL_003c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0058: Unknown result type (might be due to invalid IL or missing references)
		//IL_006a: Unknown result type (might be due to invalid IL or missing references)
		//IL_006f: Unknown result type (might be due to invalid IL or missing references)
		if (Object.op_Implicit((Object)(object)hurtColliderObject))
		{
			HurtColliderValues();
			HurtColliderDamageOff();
			hurtColliderObject.transform.SetParent((Transform)null, true);
			Vector3 localScale = hurtColliderObject.transform.localScale;
			localScale.z *= 3f;
			hurtColliderObject.transform.localScale = localScale;
			hurtColliderObject.transform.rotation = Quaternion.LookRotation(travelDirection);
			hurtColliderObject.SetActive(true);
			Object.Destroy((Object)(object)hurtColliderObject, 0.25f);
		}
	}

	private void HurtColliderDamageOff()
	{
		if (Object.op_Implicit((Object)(object)hurtCollider))
		{
			hurtCollider.playerDamage = 0;
			hurtCollider.enemyDamage = 0;
			hurtCollider.enemyStun = false;
			hurtCollider.enemyImpact = HurtCollider.BreakImpact.None;
			hurtCollider.physImpact = HurtCollider.BreakImpact.None;
		}
	}

	private void HurtColliderFollow()
	{
		//IL_003c: Unknown result type (might be due to invalid IL or missing references)
		//IL_002f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0041: Unknown result type (might be due to invalid IL or missing references)
		//IL_004d: Unknown result type (might be due to invalid IL or missing references)
		//IL_004f: Unknown result type (might be due to invalid IL or missing references)
		//IL_005a: Unknown result type (might be due to invalid IL or missing references)
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0075: Unknown result type (might be due to invalid IL or missing references)
		//IL_007a: Unknown result type (might be due to invalid IL or missing references)
		if (Object.op_Implicit((Object)(object)hurtColliderObject) && hurtColliderObject.activeSelf)
		{
			Vector3 val = (Object.op_Implicit((Object)(object)rb) ? rb.worldCenterOfMass : ((Component)this).transform.position);
			hurtColliderObject.transform.position = val + travelDirection * hurtColliderOffset;
			hurtColliderObject.transform.rotation = Quaternion.LookRotation(travelDirection);
		}
	}

	private void LifetimeTick()
	{
		if (SemiFunc.IsMasterClientOrSingleplayer())
		{
			if (lifeTimer > 0f)
			{
				lifeTimer -= Time.deltaTime;
			}
			if (hurtColliderBreakTimer > 0f)
			{
				hurtColliderBreakTimer -= Time.deltaTime;
			}
		}
	}

	private void DespawnLogic()
	{
		if (!despawning && SemiFunc.IsMasterClientOrSingleplayer() && launched && !(despawnGraceTimer > 0f) && !(pushTimer > 0f) && SemiFunc.PerSecond(2f, (Object)(object)this) && (lifeTimer <= 0f || rb.IsSleeping()) && !PlayerCanSee())
		{
			RequestDespawn();
		}
	}

	private void RequestDespawn()
	{
		DespawnStart();
		if (SemiFunc.IsMultiplayer())
		{
			photonView.RPC("DespawnRPC", (RpcTarget)1, Array.Empty<object>());
		}
	}

	[PunRPC]
	private void DespawnRPC(PhotonMessageInfo _info = default(PhotonMessageInfo))
	{
		//IL_0000: Unknown result type (might be due to invalid IL or missing references)
		if (SemiFunc.MasterOnlyRPC(_info))
		{
			DespawnStart();
		}
	}

	private void DespawnStart()
	{
		if (!despawning)
		{
			despawning = true;
			despawnOutroTimer = meshScaleOutTime;
		}
	}

	private void DespawnTick()
	{
		if (!despawning)
		{
			return;
		}
		if (despawnOutroTimer <= 0f)
		{
			if (SemiFunc.IsMasterClientOrSingleplayer())
			{
				Despawn();
			}
		}
		else
		{
			despawnOutroTimer -= Time.deltaTime;
		}
	}

	private void DespawnGraceTick()
	{
		if (despawnGraceTimer > 0f)
		{
			despawnGraceTimer -= Time.deltaTime;
		}
	}

	private bool PlayerCanSee()
	{
		//IL_0020: Unknown result type (might be due to invalid IL or missing references)
		//IL_0013: Unknown result type (might be due to invalid IL or missing references)
		//IL_0025: Unknown result type (might be due to invalid IL or missing references)
		//IL_0071: Unknown result type (might be due to invalid IL or missing references)
		//IL_0076: Unknown result type (might be due to invalid IL or missing references)
		//IL_0079: Unknown result type (might be due to invalid IL or missing references)
		//IL_007b: Unknown result type (might be due to invalid IL or missing references)
		//IL_008c: Unknown result type (might be due to invalid IL or missing references)
		//IL_008e: Unknown result type (might be due to invalid IL or missing references)
		//IL_008f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0095: Unknown result type (might be due to invalid IL or missing references)
		//IL_009a: Unknown result type (might be due to invalid IL or missing references)
		//IL_00af: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b1: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b2: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b8: Unknown result type (might be due to invalid IL or missing references)
		//IL_00bd: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d2: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d4: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d5: Unknown result type (might be due to invalid IL or missing references)
		//IL_00db: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e0: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f2: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f4: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f5: Unknown result type (might be due to invalid IL or missing references)
		//IL_00fb: Unknown result type (might be due to invalid IL or missing references)
		//IL_0100: Unknown result type (might be due to invalid IL or missing references)
		//IL_0112: Unknown result type (might be due to invalid IL or missing references)
		//IL_0114: Unknown result type (might be due to invalid IL or missing references)
		//IL_0115: Unknown result type (might be due to invalid IL or missing references)
		//IL_011b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0120: Unknown result type (might be due to invalid IL or missing references)
		//IL_0132: Unknown result type (might be due to invalid IL or missing references)
		//IL_0134: Unknown result type (might be due to invalid IL or missing references)
		//IL_0135: Unknown result type (might be due to invalid IL or missing references)
		//IL_013b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0140: Unknown result type (might be due to invalid IL or missing references)
		Vector3 val = (Object.op_Implicit((Object)(object)rb) ? rb.worldCenterOfMass : ((Component)this).transform.position);
		float num = SeeCheckRadius();
		foreach (PlayerAvatar item in SemiFunc.PlayerGetList())
		{
			if (Object.op_Implicit((Object)(object)item) && !item.isDisabled && !item.spectating)
			{
				Vector3 position = item.PlayerVisionTarget.VisionTransform.position;
				if (EyeSeesPoint(position, val))
				{
					return true;
				}
				if (EyeSeesPoint(position, val + Vector3.up * num))
				{
					return true;
				}
				if (EyeSeesPoint(position, val - Vector3.up * num))
				{
					return true;
				}
				if (EyeSeesPoint(position, val + Vector3.right * num))
				{
					return true;
				}
				if (EyeSeesPoint(position, val - Vector3.right * num))
				{
					return true;
				}
				if (EyeSeesPoint(position, val + Vector3.forward * num))
				{
					return true;
				}
				if (EyeSeesPoint(position, val - Vector3.forward * num))
				{
					return true;
				}
			}
		}
		return false;
	}

	private bool EyeSeesPoint(Vector3 _eye, Vector3 _point)
	{
		//IL_0000: Unknown result type (might be due to invalid IL or missing references)
		//IL_0001: Unknown result type (might be due to invalid IL or missing references)
		//IL_0002: Unknown result type (might be due to invalid IL or missing references)
		//IL_0007: Unknown result type (might be due to invalid IL or missing references)
		//IL_0025: Unknown result type (might be due to invalid IL or missing references)
		//IL_0026: Unknown result type (might be due to invalid IL or missing references)
		//IL_0028: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Unknown result type (might be due to invalid IL or missing references)
		Vector3 val = _point - _eye;
		float magnitude = val.magnitude;
		if (magnitude > despawnSeeDistance)
		{
			return false;
		}
		if (magnitude < 0.01f)
		{
			return true;
		}
		return !Physics.Raycast(_eye, val / magnitude, magnitude, LayerMask.op_Implicit(SemiFunc.LayerMaskGetVisionObstruct()), (QueryTriggerInteraction)1);
	}

	private float SeeCheckRadius()
	{
		//IL_002f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0034: Unknown result type (might be due to invalid IL or missing references)
		//IL_0013: Unknown result type (might be due to invalid IL or missing references)
		//IL_0018: Unknown result type (might be due to invalid IL or missing references)
		//IL_001b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0020: Unknown result type (might be due to invalid IL or missing references)
		Vector3 val;
		if (Object.op_Implicit((Object)(object)seeCheckCollider))
		{
			Bounds bounds = seeCheckCollider.bounds;
			val = bounds.extents;
			return val.magnitude;
		}
		val = ((Component)this).transform.localScale;
		return val.magnitude * 0.5f;
	}

	private void Despawn()
	{
		if (SemiFunc.IsMultiplayer())
		{
			PhotonNetwork.Destroy(((Component)this).gameObject);
		}
		else
		{
			Object.Destroy((Object)(object)((Component)this).gameObject);
		}
	}

	public RockSlideRock()
	{
		//IL_000b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0010: Unknown result type (might be due to invalid IL or missing references)
		//IL_004c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0051: Unknown result type (might be due to invalid IL or missing references)
		//IL_0082: Unknown result type (might be due to invalid IL or missing references)
		//IL_0087: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ce: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d3: Unknown result type (might be due to invalid IL or missing references)
		//IL_012a: Unknown result type (might be due to invalid IL or missing references)
		//IL_012f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0144: Unknown result type (might be due to invalid IL or missing references)
		//IL_0149: Unknown result type (might be due to invalid IL or missing references)
		//IL_0164: Unknown result type (might be due to invalid IL or missing references)
		//IL_0169: Unknown result type (might be due to invalid IL or missing references)
	}
}
