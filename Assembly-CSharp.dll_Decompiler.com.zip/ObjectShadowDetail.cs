using UnityEngine;
using UnityEngine.Rendering;

public class ObjectShadowDetail : MonoBehaviour
{
	private Renderer[] renderers;

	private ShadowCastingMode[] originalShadowCastingModes;

	private bool registered;

	private void Awake()
	{
		//IL_0032: Unknown result type (might be due to invalid IL or missing references)
		//IL_0038: Expected I4, but got Unknown
		renderers = ((Component)this).GetComponents<Renderer>();
		originalShadowCastingModes = new ShadowCastingMode[renderers.Length];
		for (int i = 0; i < renderers.Length; i++)
		{
			originalShadowCastingModes[i] = (ShadowCastingMode)(int)renderers[i].shadowCastingMode;
		}
	}

	private void Start()
	{
		if (Object.op_Implicit((Object)(object)LightManager.instance))
		{
			LightManager.instance.ObjectShadowDetailAdd(this);
			registered = true;
		}
	}

	private void OnDestroy()
	{
		if (registered && Object.op_Implicit((Object)(object)LightManager.instance))
		{
			LightManager.instance.ObjectShadowDetailRemove(this);
		}
	}

	public void SetShadowsOff(bool _shadowsOff)
	{
		for (int i = 0; i < renderers.Length; i++)
		{
			Renderer val = renderers[i];
			if (Object.op_Implicit((Object)(object)val) && !(val is ParticleSystemRenderer))
			{
				val.shadowCastingMode = (ShadowCastingMode)((!_shadowsOff) ? ((int)originalShadowCastingModes[i]) : 0);
			}
		}
	}
}
