using UnityEngine;

public class PhysGrabObjectBoxCollider : MonoBehaviour
{
	public bool drawGizmos = true;

	[Range(0.2f, 1f)]
	public float gizmoTransparency = 1f;

	public bool unEquipCollider;

	private void Start()
	{
		if (unEquipCollider)
		{
			BoxCollider component = ((Component)this).GetComponent<BoxCollider>();
			if (Object.op_Implicit((Object)(object)component))
			{
				((Collider)component).enabled = false;
			}
		}
	}

	private void OnDrawGizmos()
	{
		//IL_0037: Unknown result type (might be due to invalid IL or missing references)
		//IL_0059: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a8: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b8: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ba: Unknown result type (might be due to invalid IL or missing references)
		//IL_00bf: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ca: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d5: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e0: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e5: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ea: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ec: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f8: Unknown result type (might be due to invalid IL or missing references)
		//IL_00fd: Unknown result type (might be due to invalid IL or missing references)
		//IL_0102: Unknown result type (might be due to invalid IL or missing references)
		//IL_010c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0111: Unknown result type (might be due to invalid IL or missing references)
		//IL_0118: Unknown result type (might be due to invalid IL or missing references)
		//IL_011e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0123: Unknown result type (might be due to invalid IL or missing references)
		//IL_012a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0081: Unknown result type (might be due to invalid IL or missing references)
		//IL_0086: Unknown result type (might be due to invalid IL or missing references)
		//IL_0087: Unknown result type (might be due to invalid IL or missing references)
		//IL_0088: Unknown result type (might be due to invalid IL or missing references)
		if (!drawGizmos)
		{
			return;
		}
		BoxCollider component = ((Component)this).GetComponent<BoxCollider>();
		if (!((Object)(object)component == (Object)null))
		{
			Color color = new Color(0f, 1f, 0f, 1f * gizmoTransparency);
			Color color2 = new Color(0f, 1f, 0f, 0.2f * gizmoTransparency);
			if (unEquipCollider)
			{
				color2 = (color = new Color(0f, 0.5f, 0f, 1f * gizmoTransparency));
				color2.a = 0.2f * gizmoTransparency;
			}
			Vector3 val = ((Component)this).transform.TransformPoint(component.center);
			Vector3 lossyScale = ((Component)this).transform.lossyScale;
			Vector3 val2 = Vector3.Scale(component.size, new Vector3(Mathf.Abs(lossyScale.x), Mathf.Abs(lossyScale.y), Mathf.Abs(lossyScale.z)));
			Gizmos.color = color;
			Gizmos.matrix = Matrix4x4.TRS(val, ((Component)this).transform.rotation, Vector3.one);
			Gizmos.DrawWireCube(Vector3.zero, val2);
			Gizmos.color = color2;
			Gizmos.DrawCube(Vector3.zero, val2);
			Gizmos.matrix = Matrix4x4.identity;
		}
	}
}
