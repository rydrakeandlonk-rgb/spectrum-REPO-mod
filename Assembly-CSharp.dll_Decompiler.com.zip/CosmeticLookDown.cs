using UnityEngine;

public class CosmeticLookDown : MonoBehaviour
{
	public Transform directionTransform;

	public Transform targetTransform;

	[Space]
	public float lerpSpeed = 30f;

	internal float lookDownAmount;

	private void Update()
	{
		//IL_0007: Unknown result type (might be due to invalid IL or missing references)
		//IL_000c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0021: Unknown result type (might be due to invalid IL or missing references)
		//IL_0026: Unknown result type (might be due to invalid IL or missing references)
		//IL_0078: Unknown result type (might be due to invalid IL or missing references)
		//IL_003a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0050: Unknown result type (might be due to invalid IL or missing references)
		//IL_0055: Unknown result type (might be due to invalid IL or missing references)
		//IL_0066: Unknown result type (might be due to invalid IL or missing references)
		//IL_0088: Unknown result type (might be due to invalid IL or missing references)
		//IL_008f: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a0: Unknown result type (might be due to invalid IL or missing references)
		lookDownAmount = Vector3.Dot(directionTransform.forward, Vector3.down);
		Quaternion localRotation = targetTransform.localRotation;
		if (lookDownAmount > 0f)
		{
			targetTransform.up = Vector3.up;
			targetTransform.localRotation = SemiFunc.ClampTwist(targetTransform.localRotation, Vector3.up, 0f, 0f, out var _);
		}
		else
		{
			targetTransform.localEulerAngles = Vector3.zero;
		}
		targetTransform.localRotation = Quaternion.Lerp(localRotation, targetTransform.localRotation, lerpSpeed * Time.deltaTime);
	}
}
