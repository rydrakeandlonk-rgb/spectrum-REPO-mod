using System;
using UnityEngine;

public class SemiLine : MonoBehaviour
{
	internal Transform lineTarget;

	private LineRenderer lineRenderer;

	private bool outro;

	public float curveHeight = 1f;

	public float lineWidth = 0.2f;

	public float lineWobbleSpeed = 30f;

	public float lineWobbleAmount = 0.02f;

	public int linePoints = 20;

	public float textureScrollSpeed = 2f;

	private float activeTimer;

	private bool activeStart;

	private void Start()
	{
		lineRenderer = ((Component)this).GetComponent<LineRenderer>();
		lineRenderer.widthMultiplier = 0f;
		((Renderer)lineRenderer).enabled = false;
	}

	public void LineActive(Transform _lineTarget)
	{
		if (!Object.op_Implicit((Object)(object)lineTarget))
		{
			activeStart = true;
		}
		lineTarget = _lineTarget;
		activeTimer = 0.2f;
	}

	private void Update()
	{
		//IL_0092: Unknown result type (might be due to invalid IL or missing references)
		//IL_0097: Unknown result type (might be due to invalid IL or missing references)
		//IL_009e: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d8: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d9: Unknown result type (might be due to invalid IL or missing references)
		//IL_00dc: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e1: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00fe: Unknown result type (might be due to invalid IL or missing references)
		//IL_0103: Unknown result type (might be due to invalid IL or missing references)
		//IL_0108: Unknown result type (might be due to invalid IL or missing references)
		//IL_0130: Unknown result type (might be due to invalid IL or missing references)
		//IL_0135: Unknown result type (might be due to invalid IL or missing references)
		//IL_014e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0159: Unknown result type (might be due to invalid IL or missing references)
		//IL_0160: Unknown result type (might be due to invalid IL or missing references)
		//IL_0165: Unknown result type (might be due to invalid IL or missing references)
		//IL_016a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0177: Unknown result type (might be due to invalid IL or missing references)
		//IL_017c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0195: Unknown result type (might be due to invalid IL or missing references)
		//IL_01a0: Unknown result type (might be due to invalid IL or missing references)
		//IL_01a7: Unknown result type (might be due to invalid IL or missing references)
		//IL_01ac: Unknown result type (might be due to invalid IL or missing references)
		//IL_01b1: Unknown result type (might be due to invalid IL or missing references)
		//IL_01e1: Unknown result type (might be due to invalid IL or missing references)
		if (activeTimer <= 0f)
		{
			lineTarget = null;
			outro = true;
		}
		if (activeTimer > 0f)
		{
			if (activeStart)
			{
				lineRenderer.widthMultiplier = 0f;
				((Renderer)lineRenderer).enabled = true;
				activeStart = false;
				outro = false;
			}
			activeTimer -= Time.deltaTime;
		}
		if (Object.op_Implicit((Object)(object)lineTarget) && ((Renderer)lineRenderer).enabled)
		{
			Vector3 position = ((Component)this).transform.position;
			Vector3 position2 = lineTarget.position;
			Vector3[] array = new Vector3[linePoints];
			lineRenderer.positionCount = linePoints;
			for (int i = 0; i < linePoints; i++)
			{
				float num = (float)i / (float)(linePoints - 1);
				array[i] = Vector3.Lerp(position, position2, num) + Vector3.up * Mathf.Sin(num * MathF.PI) * curveHeight;
				float num2 = 1f - Mathf.Abs(num - 0.5f) * 2f;
				ref Vector3 reference = ref array[i];
				reference += Vector3.right * Mathf.Sin(Time.time * lineWobbleSpeed + (float)i) * lineWobbleAmount * num2;
				ref Vector3 reference2 = ref array[i];
				reference2 += Vector3.forward * Mathf.Cos(Time.time * lineWobbleSpeed + (float)i) * lineWobbleAmount * num2;
			}
			((Renderer)lineRenderer).material.mainTextureOffset = new Vector2(Time.time * 2f, 0f);
			lineRenderer.positionCount = linePoints;
			lineRenderer.SetPositions(array);
		}
		if (!((Renderer)lineRenderer).enabled)
		{
			return;
		}
		if (!outro)
		{
			if (lineRenderer.widthMultiplier < lineWidth - 0.005f)
			{
				lineRenderer.widthMultiplier = Mathf.Lerp(lineRenderer.widthMultiplier, lineWidth, Time.deltaTime * textureScrollSpeed);
			}
			else
			{
				lineRenderer.widthMultiplier = lineWidth;
			}
		}
		else if (lineRenderer.widthMultiplier > 0.005f)
		{
			lineRenderer.widthMultiplier = Mathf.Lerp(lineRenderer.widthMultiplier, 0f, Time.deltaTime * textureScrollSpeed);
		}
		else
		{
			lineRenderer.widthMultiplier = 0f;
			((Renderer)lineRenderer).enabled = false;
		}
	}
}
