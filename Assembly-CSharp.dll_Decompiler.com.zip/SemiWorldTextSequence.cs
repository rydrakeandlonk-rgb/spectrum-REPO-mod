using System;
using System.Collections.Generic;
using Photon.Pun;
using Photon.Realtime;
using UnityEngine;

[DisallowMultipleComponent]
[RequireComponent(typeof(PhotonView))]
public class SemiWorldTextSequence : MonoBehaviourPunCallbacks
{
	[Serializable]
	public class Line
	{
		internal SemiWorldText target;

		internal int trackIndex;

		public LocalizedAsset localizedText;

		[TextArea(2, 4)]
		public string temporaryText;

		[Min(0f)]
		public float start;

		[Min(0f)]
		public float end = 1f;

		internal int sourceIndex;

		private bool LocalizationMissing => !LocalizationReady(this);

		public string DisplayName
		{
			get
			{
				string text = (Object.op_Implicit((Object)(object)localizedText) ? ((Object)localizedText).name : temporaryText);
				if (string.IsNullOrWhiteSpace(text))
				{
					text = "new line";
				}
				text = text.Replace('\n', ' ').Replace('\r', ' ');
				if (text.Length > 48)
				{
					text = text.Substring(0, 45) + "...";
				}
				return $"{start:0.##} - {end:0.##}s | {text}";
			}
		}
	}

	[Serializable]
	public class Track
	{
		public SemiWorldText target;

		public List<Line> lines = new List<Line>();

		public string DisplayName
		{
			get
			{
				if (!Object.op_Implicit((Object)(object)target))
				{
					return "assign a world text";
				}
				return ((Object)target).name;
			}
		}
	}

	private enum State
	{
		Stopped,
		Playing
	}

	public List<Track> tracks = new List<Track>();

	private State currentState;

	private readonly List<Line> playbackLines = new List<Line>();

	private readonly List<Line> activeLines = new List<Line>();

	private readonly Dictionary<SemiWorldText, Line> pendingLines = new Dictionary<SemiWorldText, Line>();

	private int nextLineIndex;

	private float startOffset;

	private double localStartTime;

	private int networkStartTimestamp;

	public bool IsPlaying => currentState == State.Playing;

	public float PlaybackTime
	{
		get
		{
			if (currentState != State.Playing)
			{
				return 0f;
			}
			return TimeGet();
		}
	}

	private void Update()
	{
		if (currentState == State.Playing)
		{
			StatePlaying();
		}
	}

	public override void OnDisable()
	{
		((MonoBehaviourPunCallbacks)this).OnDisable();
		PlaybackStop();
	}

	public override void OnPlayerEnteredRoom(Player _newPlayer)
	{
		((MonoBehaviourPunCallbacks)this).OnPlayerEnteredRoom(_newPlayer);
		if (PhotonNetwork.IsMasterClient && IsPlaying)
		{
			((MonoBehaviourPun)this).photonView.RPC("StartSequenceRPC", _newPlayer, new object[1] { TimeGet() });
		}
	}

	private void StatePlaying()
	{
		float time = TimeGet();
		LinesExpire(time);
		LinesStart(time);
		if (nextLineIndex >= playbackLines.Count && activeLines.Count == 0)
		{
			PlaybackStop();
		}
	}

	public void StartSequence(float _startTime = 0f)
	{
		//IL_0045: Unknown result type (might be due to invalid IL or missing references)
		//IL_004b: Unknown result type (might be due to invalid IL or missing references)
		if (((Behaviour)this).isActiveAndEnabled && TimeValid(_startTime) && CanSend())
		{
			if (SemiFunc.IsMultiplayer())
			{
				((MonoBehaviourPun)this).photonView.RPC("StartSequenceRPC", (RpcTarget)5, new object[1] { _startTime });
			}
			else
			{
				StartSequenceRPC(_startTime);
			}
		}
	}

	internal bool StartSequenceFromCommand()
	{
		if (!((Behaviour)this).isActiveAndEnabled)
		{
			return false;
		}
		if (SemiFunc.IsMultiplayer())
		{
			if (((MonoBehaviourPun)this).photonView.ViewID == 0)
			{
				return false;
			}
			if (!PhotonNetwork.IsMasterClient && !((MonoBehaviourPun)this).photonView.IsMine)
			{
				if (!Debug.isDebugBuild)
				{
					return false;
				}
				((MonoBehaviourPun)this).photonView.RPC("DebugStartSequenceRequestRPC", (RpcTarget)2, Array.Empty<object>());
				return true;
			}
		}
		StartSequence();
		return true;
	}

	public void StopSequence()
	{
		//IL_002a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0030: Unknown result type (might be due to invalid IL or missing references)
		if (CanSend())
		{
			if (SemiFunc.IsMultiplayer())
			{
				((MonoBehaviourPun)this).photonView.RPC("StopSequenceRPC", (RpcTarget)5, Array.Empty<object>());
			}
			else
			{
				StopSequenceRPC();
			}
		}
	}

	private bool CanSend()
	{
		if (!SemiFunc.IsMultiplayer())
		{
			return true;
		}
		if (!PhotonNetwork.IsMasterClient && !((MonoBehaviourPun)this).photonView.IsMine)
		{
			return false;
		}
		if (((MonoBehaviourPun)this).photonView.ViewID != 0)
		{
			return true;
		}
		Debug.LogError((object)"SemiWorldTextSequence needs a registered PhotonView before it can play in multiplayer", (Object)(object)this);
		return false;
	}

	private static bool TimeValid(float _time)
	{
		if (_time >= 0f && !float.IsNaN(_time))
		{
			return !float.IsInfinity(_time);
		}
		return false;
	}

	private float TimeGet()
	{
		if (SemiFunc.IsMultiplayer())
		{
			float num = (float)(PhotonNetwork.ServerTimestamp - networkStartTimestamp) * 0.001f;
			return startOffset + Mathf.Max(0f, num);
		}
		return startOffset + (float)(Time.timeAsDouble - localStartTime);
	}

	private void PlaybackPrepare()
	{
		if (tracks == null)
		{
			return;
		}
		for (int i = 0; i < tracks.Count; i++)
		{
			TrackPrepare(tracks[i], i);
		}
		playbackLines.Sort((Line _first, Line _second) =>
		{
			int num = _first.start.CompareTo(_second.start);
			if (num != 0)
			{
				return num;
			}
			num = _first.trackIndex.CompareTo(_second.trackIndex);
			return (num == 0) ? _first.sourceIndex.CompareTo(_second.sourceIndex) : num;
		});
	}

	private void TrackPrepare(Track _track, int _trackIndex)
	{
		if (_track == null || !Object.op_Implicit((Object)(object)_track.target))
		{
			Debug.LogWarning((object)$"SemiWorldTextSequence '{((Object)this).name}' track {_trackIndex + 1} needs a target... skipping it", (Object)(object)this);
		}
		else
		{
			if (_track.lines == null)
			{
				return;
			}
			for (int i = 0; i < _track.lines.Count; i++)
			{
				Line line = _track.lines[i];
				if (line == null || !TimeValid(line.start) || !TimeValid(line.end) || line.end <= line.start)
				{
					Debug.LogWarning((object)$"SemiWorldTextSequence '{((Object)this).name}' track {_trackIndex + 1} line {i + 1} needs an end after its start.. skipping it", (Object)(object)this);
					continue;
				}
				if (!LocalizationReady(line))
				{
					Debug.LogWarning((object)$"SemiWorldTextSequence '{((Object)this).name}' track {_trackIndex + 1} line {i + 1} has no localization set up yet... using temporary text", (Object)(object)this);
				}
				playbackLines.Add(new Line
				{
					target = _track.target,
					localizedText = line.localizedText,
					temporaryText = line.temporaryText,
					start = line.start,
					end = line.end,
					trackIndex = _trackIndex,
					sourceIndex = i
				});
			}
		}
	}

	private static bool LocalizationReady(Line _line)
	{
		if (Object.op_Implicit((Object)(object)_line.localizedText))
		{
			return _line.localizedText.IsValid();
		}
		return false;
	}

	private string TextGet(Line _line)
	{
		if (!LocalizationReady(_line))
		{
			return _line.temporaryText;
		}
		string localizedString = _line.localizedText.GetLocalizedString();
		if (!string.IsNullOrEmpty(localizedString))
		{
			return localizedString;
		}
		Debug.LogWarning((object)$"SemiWorldTextSequence '{((Object)this).name}' track {_line.trackIndex + 1} line {_line.sourceIndex + 1} returned no localized text.... using temporary text", (Object)(object)this);
		return _line.temporaryText;
	}

	private void LinesStart(float _time)
	{
		pendingLines.Clear();
		while (nextLineIndex < playbackLines.Count && playbackLines[nextLineIndex].start <= _time)
		{
			Line line = playbackLines[nextLineIndex++];
			if (Object.op_Implicit((Object)(object)line.target))
			{
				pendingLines[line.target] = line;
			}
		}
		foreach (KeyValuePair<SemiWorldText, Line> pendingLine in pendingLines)
		{
			Line value = pendingLine.Value;
			LineClear(value.target);
			if (!(value.end <= _time) && ((Behaviour)value.target).isActiveAndEnabled)
			{
				string text = TextGet(value);
				if (!string.IsNullOrEmpty(text))
				{
					value.target.ShowSequenceText(this, text, value.end - _time);
					activeLines.Add(value);
				}
			}
		}
	}

	private void LinesExpire(float _time)
	{
		for (int num = activeLines.Count - 1; num >= 0; num--)
		{
			Line line = activeLines[num];
			if (!Object.op_Implicit((Object)(object)line.target) || !(line.end > _time))
			{
				if (Object.op_Implicit((Object)(object)line.target))
				{
					line.target.HideSequenceText(this);
				}
				activeLines.RemoveAt(num);
			}
		}
	}

	private void LineClear(SemiWorldText _target)
	{
		for (int num = activeLines.Count - 1; num >= 0; num--)
		{
			if (!((Object)(object)activeLines[num].target != (Object)(object)_target))
			{
				_target.HideSequenceText(this);
				activeLines.RemoveAt(num);
			}
		}
	}

	private void PlaybackStop()
	{
		foreach (Line activeLine in activeLines)
		{
			if (Object.op_Implicit((Object)(object)activeLine.target))
			{
				activeLine.target.HideSequenceText(this);
			}
		}
		activeLines.Clear();
		playbackLines.Clear();
		pendingLines.Clear();
		nextLineIndex = 0;
		currentState = State.Stopped;
	}

	[PunRPC]
	private void DebugStartSequenceRequestRPC(PhotonMessageInfo _info = default(PhotonMessageInfo))
	{
		//IL_000f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		if (PhotonNetwork.IsMasterClient && Debug.isDebugBuild && _info.Sender != null && Object.op_Implicit((Object)(object)GameDirector.instance) && Object.op_Implicit((Object)(object)SemiFunc.PlayerAvatarGetFromPhotonPlayer(_info.Sender)))
		{
			StartSequence();
		}
	}

	[PunRPC]
	private void StartSequenceRPC(float _startTime, PhotonMessageInfo _info = default(PhotonMessageInfo))
	{
		//IL_0000: Unknown result type (might be due to invalid IL or missing references)
		if (SemiFunc.MasterAndOwnerOnlyRPC(_info, ((MonoBehaviourPun)this).photonView) && ((Behaviour)this).isActiveAndEnabled && TimeValid(_startTime))
		{
			PlaybackStop();
			PlaybackPrepare();
			startOffset = _startTime;
			localStartTime = Time.timeAsDouble;
			networkStartTimestamp = _info.SentServerTimestamp;
			currentState = State.Playing;
			StatePlaying();
		}
	}

	[PunRPC]
	private void StopSequenceRPC(PhotonMessageInfo _info = default(PhotonMessageInfo))
	{
		//IL_0000: Unknown result type (might be due to invalid IL or missing references)
		if (SemiFunc.MasterAndOwnerOnlyRPC(_info, ((MonoBehaviourPun)this).photonView))
		{
			PlaybackStop();
		}
	}
}
