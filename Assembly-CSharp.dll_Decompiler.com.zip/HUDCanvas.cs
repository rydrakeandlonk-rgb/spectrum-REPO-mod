using UnityEngine;

public class HUDCanvas : MonoBehaviour
{
	public static HUDCanvas instance;

	internal RectTransform rect;

	[RuntimeInitializeOnLoadMethod(/*Could not decode attribute arguments.*/)]
	private static void RuntimeInitializeOnLoad()
	{
		instance = null;
	}

	private void Awake()
	{
		instance = this;
		rect = ((Component)this).GetComponent<RectTransform>();
	}
}
