using System.Collections.Generic;
using UnityEngine;

public class Fireplace : MonoBehaviour
{
	public bool isLit;

	public bool isCornerFireplace;

	public Vector3 offsetOverride = new Vector3(0f, 0f, 0f);

	public GameObject fire;

	public List<GameObject> fireEffects;

	public GameObject[] emissiveMesh;

	private List<Material> emissiveMaterials = new List<Material>();

	private Vector3 fireOffset = new Vector3(0f, 0.028f, 0.249f);

	private void Awake()
	{
		//IL_00f6: Unknown result type (might be due to invalid IL or missing references)
		//IL_0101: Unknown result type (might be due to invalid IL or missing references)
		//IL_0123: Unknown result type (might be due to invalid IL or missing references)
		//IL_017a: Unknown result type (might be due to invalid IL or missing references)
		//IL_017f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0145: Unknown result type (might be due to invalid IL or missing references)
		//IL_014a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0156: Unknown result type (might be due to invalid IL or missing references)
		//IL_016a: Unknown result type (might be due to invalid IL or missing references)
		//IL_016f: Unknown result type (might be due to invalid IL or missing references)
		//IL_019e: Unknown result type (might be due to invalid IL or missing references)
		//IL_018d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0192: Unknown result type (might be due to invalid IL or missing references)
		if (!isLit)
		{
			return;
		}
		if (fireEffects.Count > 0)
		{
			foreach (GameObject fireEffect in fireEffects)
			{
				fireEffect.gameObject.SetActive(true);
			}
		}
		if (emissiveMesh.Length != 0)
		{
			GameObject[] array = emissiveMesh;
			for (int i = 0; i < array.Length; i++)
			{
				Renderer component = array[i].GetComponent<Renderer>();
				if (Object.op_Implicit((Object)(object)component) && Object.op_Implicit((Object)(object)component.material))
				{
					emissiveMaterials.Add(component.material);
				}
			}
		}
		if (emissiveMaterials.Count > 0)
		{
			foreach (Material emissiveMaterial in emissiveMaterials)
			{
				emissiveMaterial.EnableKeyword("_EMISSION");
			}
		}
		GameObject val = Object.Instantiate<GameObject>(fire, ((Component)this).transform.position, ((Component)this).transform.rotation);
		val.transform.parent = ((Component)this).transform;
		val.transform.localRotation = Quaternion.identity;
		if (isCornerFireplace)
		{
			fireOffset = new Vector3(0.824f, 0.028f, 0.824f);
			Transform transform = val.transform;
			transform.localRotation *= Quaternion.Euler(0f, 45f, 0f);
		}
		if (offsetOverride != Vector3.zero)
		{
			fireOffset = offsetOverride;
		}
		val.transform.localPosition = fireOffset;
	}

	public Fireplace()
	{
		//IL_0010: Unknown result type (might be due to invalid IL or missing references)
		//IL_0015: Unknown result type (might be due to invalid IL or missing references)
		//IL_0035: Unknown result type (might be due to invalid IL or missing references)
		//IL_003a: Unknown result type (might be due to invalid IL or missing references)
	}
}
