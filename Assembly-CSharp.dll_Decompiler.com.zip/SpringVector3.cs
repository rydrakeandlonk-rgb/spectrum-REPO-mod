using System;
using UnityEngine;

[Serializable]
public class SpringVector3
{
	public float damping = 0.5f;

	public float speed = 10f;

	[Space]
	public bool clamp;

	public float maxDistance = 1f;

	internal Vector3 lastPosition;

	internal Vector3 springVelocity = Vector3.zero;

	public SpringVector3()
	{
		//IL_0022: Unknown result type (might be due to invalid IL or missing references)
		//IL_0027: Unknown result type (might be due to invalid IL or missing references)
	}
}
