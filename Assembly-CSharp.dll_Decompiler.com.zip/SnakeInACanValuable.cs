using System;
using System.Collections.Generic;
using Photon.Pun;
using UnityEngine;

public class SnakeInACanValuable : MonoBehaviour
{
	public Transform spring1Transform;

	public Transform spring1Target;

	public Transform spring2Transform;

	public Transform spring2Target;

	public Transform spring3Transform;

	public Transform spring3Target;

	public Transform spring4Transform;

	public Transform spring4Target;

	public SpringQuaternion spring1;

	public SpringQuaternion spring2;

	public SpringQuaternion spring3;

	public SpringQuaternion spring4;

	public GameObject snake;

	public GameObject snakeColliders;

	[Header("Hurt Collider")]
	public GameObject hurtCollider;

	private float hurtColliderDuration = 0.2f;

	private float hurtColliderTimer;

	[Header("Face Player")]
	public Vector3 faceRotationX = new Vector3(0f, -180f, 0f);

	public Vector3 faceRotationY = Vector3.zero;

	public Vector3 faceRotationZ = Vector3.zero;

	public float torqueStrength = 2f;

	public Animator anim;

	public List<Transform> collisionCheckers = new List<Transform>();

	public Transform lidHinge;

	public float lidOpenAngle = 125f;

	public float lidAnimationSpeed = 20f;

	[Header("Screenshake")]
	public float shakeStrength = 3f;

	public float shakeDuration = 0.1f;

	public float shakeDistanceMin = 3f;

	public float shakeDistanceMax = 10f;

	private PhysGrabObject physGrabObject;

	private PhotonView photonView;

	private bool snakeOut;

	private float lidTargetZ;

	private float lidCurrentZ;

	public Sound snakeOutSound;

	public Sound snakeInSound;

	public Sound snakeLidSoundOpen;

	public Sound snakeLidSoundClose;

	private void Start()
	{
		physGrabObject = ((Component)this).GetComponent<PhysGrabObject>();
		photonView = ((Component)this).GetComponent<PhotonView>();
	}

	private void Update()
	{
		//IL_0087: Unknown result type (might be due to invalid IL or missing references)
		//IL_0091: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ad: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b7: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00dd: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f9: Unknown result type (might be due to invalid IL or missing references)
		//IL_0103: Unknown result type (might be due to invalid IL or missing references)
		//IL_017e: Unknown result type (might be due to invalid IL or missing references)
		if (SemiFunc.IsMasterClientOrSingleplayer())
		{
			if (physGrabObject.grabbed && !snakeOut)
			{
				if (SemiFunc.PerSecond(1f, (Object)(object)this) && Random.Range(0f, 3f) < 0.1f && CollisionFree())
				{
					SnakeOut();
				}
			}
			else if (!physGrabObject.grabbed && snakeOut)
			{
				SnakeIn();
			}
		}
		if (snakeOut)
		{
			spring1Transform.rotation = SemiFunc.SpringQuaternionGet(spring1, spring1Target.rotation);
			spring2Transform.rotation = SemiFunc.SpringQuaternionGet(spring2, spring2Target.rotation);
			spring3Transform.rotation = SemiFunc.SpringQuaternionGet(spring3, spring3Target.rotation);
			spring4Transform.rotation = SemiFunc.SpringQuaternionGet(spring4, spring4Target.rotation);
		}
		if (hurtColliderTimer > 0f)
		{
			hurtColliderTimer -= Time.deltaTime;
			if (hurtColliderTimer <= 0f)
			{
				hurtCollider.SetActive(false);
			}
		}
		lidCurrentZ = Mathf.LerpAngle(lidCurrentZ, lidTargetZ, Time.deltaTime * lidAnimationSpeed);
		lidHinge.localRotation = Quaternion.Euler(0f, 0f, lidCurrentZ);
	}

	private void FixedUpdate()
	{
	}

	private bool CollisionFree()
	{
		//IL_001d: Unknown result type (might be due to invalid IL or missing references)
		for (int i = 0; i < collisionCheckers.Count; i++)
		{
			if (IsColliding(collisionCheckers[i], collisionCheckers[i].position))
			{
				return false;
			}
		}
		return true;
	}

	private Collider[] GetCollidingColliders(Transform _collisionChecker, Vector3 _pos)
	{
		//IL_0000: Unknown result type (might be due to invalid IL or missing references)
		//IL_0002: Unknown result type (might be due to invalid IL or missing references)
		//IL_000c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0012: Unknown result type (might be due to invalid IL or missing references)
		//IL_0017: Unknown result type (might be due to invalid IL or missing references)
		return Physics.OverlapBox(_pos, _collisionChecker.lossyScale / 2f, _collisionChecker.rotation, LayerMask.op_Implicit(SemiFunc.LayerMaskGetVisionObstruct()));
	}

	private bool IsColliding(Transform _collisionChecker, Vector3 _pos)
	{
		//IL_0002: Unknown result type (might be due to invalid IL or missing references)
		Collider[] collidingColliders = GetCollidingColliders(_collisionChecker, _pos);
		for (int i = 0; i < collidingColliders.Length; i++)
		{
			if (!((Component)collidingColliders[i]).transform.IsChildOf(((Component)this).transform))
			{
				return true;
			}
		}
		return false;
	}

	private void SnakeOut()
	{
		//IL_0021: Unknown result type (might be due to invalid IL or missing references)
		//IL_0027: Unknown result type (might be due to invalid IL or missing references)
		if (SemiFunc.IsMultiplayer())
		{
			photonView.RPC("SnakeOutRPC", (RpcTarget)0, Array.Empty<object>());
		}
		else
		{
			SnakeOutRPC();
		}
	}

	private void SnakeIn()
	{
		//IL_0021: Unknown result type (might be due to invalid IL or missing references)
		//IL_0027: Unknown result type (might be due to invalid IL or missing references)
		if (SemiFunc.IsMultiplayer())
		{
			photonView.RPC("SnakeInRPC", (RpcTarget)0, Array.Empty<object>());
		}
		else
		{
			SnakeInRPC();
		}
	}

	[PunRPC]
	private void SnakeOutRPC(PhotonMessageInfo _info = default(PhotonMessageInfo))
	{
		//IL_0000: Unknown result type (might be due to invalid IL or missing references)
		//IL_0058: Unknown result type (might be due to invalid IL or missing references)
		//IL_0083: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a8: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d0: Unknown result type (might be due to invalid IL or missing references)
		if (SemiFunc.MasterOnlyRPC(_info))
		{
			snake.SetActive(true);
			snakeColliders.SetActive(true);
			snakeOut = true;
			lidTargetZ = lidOpenAngle;
			hurtCollider.SetActive(true);
			hurtColliderTimer = hurtColliderDuration;
			snakeOutSound.Play(((Component)this).transform.position);
			snakeLidSoundOpen.Play(((Component)this).transform.position);
			SemiFunc.CameraShakeImpactDistance(((Component)this).transform.position, shakeStrength, shakeDuration, shakeDistanceMin, shakeDistanceMax);
			SemiFunc.CameraShakeDistance(((Component)this).transform.position, shakeStrength, shakeDuration, shakeDistanceMin, shakeDistanceMax);
		}
	}

	[PunRPC]
	private void SnakeInRPC(PhotonMessageInfo _info = default(PhotonMessageInfo))
	{
		//IL_0000: Unknown result type (might be due to invalid IL or missing references)
		//IL_0015: Unknown result type (might be due to invalid IL or missing references)
		//IL_0040: Unknown result type (might be due to invalid IL or missing references)
		if (SemiFunc.MasterOnlyRPC(_info))
		{
			snakeInSound.Play(((Component)this).transform.position);
			snakeLidSoundOpen.Play(((Component)this).transform.position);
			anim.Play("snakeGoInAnim");
			snakeColliders.SetActive(false);
			hurtCollider.SetActive(false);
			hurtColliderTimer = 0f;
			snakeOut = false;
		}
	}

	public void DoneAnimatingGoingIn()
	{
		snake.SetActive(false);
		lidTargetZ = 0f;
	}

	public SnakeInACanValuable()
	{
		//IL_001b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0020: Unknown result type (might be due to invalid IL or missing references)
		//IL_0026: Unknown result type (might be due to invalid IL or missing references)
		//IL_002b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0031: Unknown result type (might be due to invalid IL or missing references)
		//IL_0036: Unknown result type (might be due to invalid IL or missing references)
	}
}
