using UnityEngine;

public class PlayerAvatarOverchargeVisuals : MonoBehaviour
{
	private Light overchargeLight;

	private ParticleSystem overchargeParticles;

	private PhysGrabber physGrabber;

	private Transform physGrabBeamOrigin;

	private PlayerAvatar playerAvatar;

	public Sound soundOverchargeLoop;

	public AnimationCurve overchargeIntensityCurve;

	private void Start()
	{
		physGrabber = ((Component)this).GetComponent<PhysGrabber>();
		overchargeLight = ((Component)this).GetComponentInChildren<Light>();
		overchargeParticles = ((Component)this).GetComponentInChildren<ParticleSystem>();
		PhysGrabBeam componentInParent = ((Component)this).GetComponentInParent<PhysGrabBeam>();
		physGrabber = ((Component)componentInParent.playerAvatar).GetComponent<PhysGrabber>();
		if (!physGrabber.isLocal)
		{
			physGrabBeamOrigin = componentInParent.PhysGrabPointOriginClient;
		}
		else
		{
			physGrabBeamOrigin = componentInParent.PhysGrabPointOrigin;
		}
		playerAvatar = componentInParent.playerAvatar;
		((Component)this).transform.parent = ((Component)playerAvatar).transform.parent;
	}

	private void Update()
	{
		//IL_000c: Unknown result type (might be due to invalid IL or missing references)
		//IL_002a: Unknown result type (might be due to invalid IL or missing references)
		//IL_003f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0049: Unknown result type (might be due to invalid IL or missing references)
		//IL_004e: Unknown result type (might be due to invalid IL or missing references)
		//IL_007b: Unknown result type (might be due to invalid IL or missing references)
		//IL_018d: Unknown result type (might be due to invalid IL or missing references)
		//IL_019f: Unknown result type (might be due to invalid IL or missing references)
		((Component)this).transform.position = physGrabBeamOrigin.position;
		if (physGrabber.isLocal)
		{
			Transform transform = ((Component)this).transform;
			transform.position += playerAvatar.localCamera.GetOverrideTransform().forward * 0.5f;
		}
		if (playerAvatar.isTumbling)
		{
			((Component)this).transform.position = ((Component)playerAvatar.playerAvatarVisuals).transform.position;
		}
		float num = (float)(int)physGrabber.physGrabBeamOverCharge / 2f;
		num /= 100f;
		if (playerAvatar.isDisabled)
		{
			num = 0f;
		}
		bool playing = num > 0f;
		float num2 = overchargeIntensityCurve.Evaluate(num);
		soundOverchargeLoop.LoopVolumeCurrent = 0.5f * num2;
		soundOverchargeLoop.PlayLoop(playing, 0.5f, 0.5f, 1f + 2f * num2);
		if (num > 0f)
		{
			if (!((Behaviour)overchargeLight).enabled)
			{
				overchargeParticles.Play();
				((Behaviour)overchargeLight).enabled = true;
			}
			float num3 = num * Mathf.Sin(Time.time * (10f + 20f * num2));
			overchargeLight.intensity = 8f * num2 + num3;
			overchargeParticles.emissionRate = num2 * 50f;
			((Component)overchargeParticles).transform.localScale = new Vector3(1f, 1f, 1f) * (0.1f + 0.8f * num2);
		}
		else if (((Behaviour)overchargeLight).enabled)
		{
			overchargeParticles.Stop();
			((Behaviour)overchargeLight).enabled = false;
		}
	}
}
