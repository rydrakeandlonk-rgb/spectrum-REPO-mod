using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Platforms;
using TMPro;
using UnityEngine;
using UnityEngine.InputSystem;
using UnityEngine.UI;

public class DebugConsoleUI : MonoBehaviour
{
	public enum State
	{
		Inactive,
		Active
	}

	public Color cursorColor = new Color(1f, 0.55f, 0f, 1f);

	public Color selectionColor = new Color(0f, 1f, 1f, 0.3f);

	public TextMeshProUGUI chatText;

	public TextMeshProUGUI suggestionsText;

	public TextMeshProUGUI responseText;

	public TextMeshProUGUI scrollIndicator;

	public GameObject enableObject;

	internal static DebugConsoleUI instance;

	private readonly Dictionary<string, int> multiTokenCommands = new Dictionary<string, int>
	{
		{ "cosmetic", 2 },
		{ "spawn", 2 },
		{ "upgrade", 2 }
	};

	private State currentState;

	private string commandText = "";

	private int cursorIndex;

	private int selectionAnchor;

	private int displayStart;

	private int displayEnd;

	private List<string> cmdSuggestions = new List<string>();

	private int cmdSuggestionIndex;

	private int suggestionDisplayStart;

	private int historyIndex;

	private string historyDraft = "";

	private KeyCode repeatKey;

	private float repeatTimer;

	private int gamepadNavigateDirection;

	private float gamepadNavigateTimer;

	private float cursorBlinkResetTimer;

	private int prevCursorBlinkPhase = -1;

	private bool mouseSelecting;

	private RectTransform flairTransform;

	private Vector2 flairPosition;

	private Vector3 flairScale;

	private Color flairTextColor;

	private Color flairFlashColor;

	private float flairFlashTimer;

	private float flairScaleTimer;

	private float flairScaleTime;

	private float flairScaleAmount;

	private float flairScaleFrequency;

	private float flairShakeXTimer;

	private float flairShakeXTime;

	private float flairShakeXAmount;

	private float flairShakeXFrequency;

	private float flairShakeYTimer;

	private float flairShakeYTime;

	private float flairShakeYAmount;

	private float flairShakeYFrequency;

	private GamepadTextInput gamepadTextInput;

	internal bool chatActive => currentState == State.Active;

	[RuntimeInitializeOnLoadMethod(/*Could not decode attribute arguments.*/)]
	private static void RuntimeInitializeOnLoad()
	{
		instance = null;
	}

	private void Awake()
	{
		//IL_003b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0040: Unknown result type (might be due to invalid IL or missing references)
		//IL_004c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0051: Unknown result type (might be due to invalid IL or missing references)
		//IL_006a: Unknown result type (might be due to invalid IL or missing references)
		//IL_006f: Unknown result type (might be due to invalid IL or missing references)
		instance = this;
		flairTransform = (Object.op_Implicit((Object)(object)enableObject) ? enableObject.GetComponent<RectTransform>() : null);
		if (Object.op_Implicit((Object)(object)flairTransform))
		{
			flairPosition = flairTransform.anchoredPosition;
			flairScale = ((Transform)flairTransform).localScale;
		}
		if (Object.op_Implicit((Object)(object)chatText))
		{
			flairTextColor = ((Graphic)chatText).color;
		}
		gamepadTextInput = new GamepadTextInput(GamepadTextInputSubmitted);
	}

	private void OnDisable()
	{
		gamepadTextInput.Close();
		FlairReset();
	}

	private void Update()
	{
		StateMachine();
		FlairTick();
	}

	private void StateMachine()
	{
		switch (currentState)
		{
		case State.Inactive:
			StateInactive();
			break;
		case State.Active:
			StateActive();
			break;
		}
	}

	private void StateInactive()
	{
		if ((SemiFunc.DebugTester() || PlatformManager.instance.developerFlags.debug_console) && SemiFunc.NoTextInputsActive() && SemiFunc.InputDown(InputKey.DebugConsole) && (GameDirector.instance.currentState == GameDirector.gameState.Main || GameDirector.instance.currentState == GameDirector.gameState.Death))
		{
			StateSet(State.Active);
		}
	}

	private void StateActive()
	{
		if (GameDirector.instance.currentState != GameDirector.gameState.Main && GameDirector.instance.currentState != GameDirector.gameState.Death)
		{
			StateSet(State.Inactive);
			return;
		}
		gamepadTextInput.Update();
		if (!gamepadTextInput.IsOpen && Gamepad.current != null && Gamepad.current.buttonWest.wasPressedThisFrame)
		{
			GamepadTextInputShow();
		}
		if (Input.GetKeyDown((KeyCode)27) || SemiFunc.InputDown(InputKey.DebugConsole) || SemiFunc.InputDown(InputKey.Back))
		{
			DenyEffect();
			StateSet(State.Inactive);
			return;
		}
		SemiFunc.InputDisableMovement();
		KeyRepeatTick();
		if (Input.GetKeyDown((KeyCode)13) || Input.GetKeyDown((KeyCode)271) || GamepadSubmitPressed())
		{
			CommandExecute();
		}
		else if (!ShortcutInput())
		{
			HistoryAndSuggestionInput();
			NavigationInput();
			DeleteInput();
			MouseInput();
			TypedInput();
			CursorBlinkTick();
		}
	}

	private void StateSet(State state)
	{
		//IL_002e: Unknown result type (might be due to invalid IL or missing references)
		if (currentState != state)
		{
			currentState = state;
			switch (currentState)
			{
			case State.Inactive:
				enableObject.SetActive(false);
				repeatKey = (KeyCode)0;
				gamepadNavigateDirection = 0;
				mouseSelecting = false;
				gamepadTextInput.Close();
				FlairReset();
				break;
			case State.Active:
				commandText = "";
				cursorIndex = 0;
				selectionAnchor = 0;
				historyIndex = (Object.op_Implicit((Object)(object)DebugCommandHandler.instance) ? DebugCommandHandler.instance.cmdHistory.Count : 0);
				historyDraft = "";
				enableObject.SetActive(true);
				CommandDisplayRefresh();
				FlairScaleImpulse(0.05f, 5f, 0.2f);
				FlairShakeYImpulse(2f, 5f, 0.2f);
				MenuManager.instance?.MenuEffectClick(MenuManager.MenuClickEffectType.Action, null, 1f, 1f, soundOnly: true);
				break;
			}
		}
	}

	private void GamepadTextInputShow()
	{
		gamepadTextInput.Show(Object.op_Implicit((Object)(object)chatText) ? ((TMP_Text)chatText).rectTransform : null, "Command", 256, commandText);
	}

	private void GamepadTextInputSubmitted(string _text)
	{
		if (currentState == State.Active)
		{
			commandText = _text;
			cursorIndex = commandText.Length;
			selectionAnchor = cursorIndex;
			CommandExecute();
		}
	}

	private void CommandExecute()
	{
		//IL_000d: Unknown result type (might be due to invalid IL or missing references)
		StateSet(State.Inactive);
		SetResponseText("", Color.white);
		bool num = Object.op_Implicit((Object)(object)DebugCommandHandler.instance) && DebugCommandHandler.instance.Execute(commandText, isDebugConsole: true);
		commandText = "";
		cursorIndex = 0;
		selectionAnchor = 0;
		historyIndex = (Object.op_Implicit((Object)(object)DebugCommandHandler.instance) ? DebugCommandHandler.instance.cmdHistory.Count : 0);
		historyDraft = "";
		CommandDisplayRefresh();
		if (!num)
		{
			DenyEffect();
		}
		else
		{
			FlairScaleImpulse(0.05f, 5f, 0.2f);
		}
	}

	private bool ShortcutInput()
	{
		//IL_00aa: Unknown result type (might be due to invalid IL or missing references)
		bool flag = ControlPressed();
		bool flag2 = ShiftPressed();
		if (flag && Input.GetKeyDown((KeyCode)97))
		{
			selectionAnchor = 0;
			cursorIndex = commandText.Length;
			CursorChanged();
			return true;
		}
		if ((flag && Input.GetKeyDown((KeyCode)99)) || (flag && Input.GetKeyDown((KeyCode)277)))
		{
			SelectionCopy();
			return true;
		}
		if ((flag && Input.GetKeyDown((KeyCode)120)) || (flag2 && Input.GetKeyDown((KeyCode)127)))
		{
			if (SelectionCopy())
			{
				SelectionDelete(playEffect: true);
			}
			return true;
		}
		if ((flag && Input.GetKeyDown((KeyCode)118)) || (flag2 && Input.GetKeyDown((KeyCode)277)))
		{
			TextInsert(GUIUtility.systemCopyBuffer, Color.cyan);
			return true;
		}
		if (flag && Input.GetKeyDown((KeyCode)108))
		{
			if (commandText.Length > 0)
			{
				selectionAnchor = 0;
				cursorIndex = commandText.Length;
				SelectionDelete(playEffect: true);
			}
			return true;
		}
		if (flag && Input.GetKeyDown((KeyCode)117))
		{
			if (cursorIndex > 0)
			{
				selectionAnchor = 0;
				SelectionDelete(playEffect: true);
			}
			return true;
		}
		if (flag && Input.GetKeyDown((KeyCode)107))
		{
			if (cursorIndex < commandText.Length)
			{
				selectionAnchor = commandText.Length;
				SelectionDelete(playEffect: true);
			}
			return true;
		}
		if (flag && Input.GetKeyDown((KeyCode)119))
		{
			if (SelectionDelete(playEffect: false))
			{
				DeleteEffect();
			}
			else
			{
				selectionAnchor = PreviousWordIndex(cursorIndex);
				SelectionDelete(playEffect: true);
			}
			return true;
		}
		return false;
	}

	private void HistoryAndSuggestionInput()
	{
		bool flag = ControlPressed();
		float axis = Input.GetAxis("Mouse ScrollWheel");
		if (Input.GetMouseButtonDown(2) && HistoryLatestRecall())
		{
			return;
		}
		if (flag && RepeatPressed((KeyCode)273))
		{
			HistoryMove(-1);
		}
		else if (flag && RepeatPressed((KeyCode)274))
		{
			HistoryMove(1);
		}
		else if (!flag && RepeatPressed((KeyCode)273))
		{
			SuggestionMove(-1);
		}
		else if (!flag && RepeatPressed((KeyCode)274))
		{
			SuggestionMove(1);
		}
		if (Input.GetKeyDown((KeyCode)280))
		{
			SuggestionMove(-1);
		}
		if (Input.GetKeyDown((KeyCode)281))
		{
			SuggestionMove(1);
		}
		if (axis > 0f)
		{
			SuggestionMove(-1);
		}
		if (axis < 0f)
		{
			SuggestionMove(1);
		}
		int num = RepeatedGamepadNavigateDirection();
		if (num > 0)
		{
			SuggestionMove(-1);
		}
		else if (num < 0)
		{
			SuggestionMove(1);
		}
		if (Input.GetKeyDown((KeyCode)9) || GamepadTabPressed())
		{
			if (ShiftPressed())
			{
				SuggestionMove(-1, playEffect: false);
			}
			SuggestionApply();
		}
	}

	private bool HistoryLatestRecall()
	{
		if (!Object.op_Implicit((Object)(object)DebugCommandHandler.instance) || DebugCommandHandler.instance.cmdHistory.Count == 0)
		{
			return false;
		}
		List<string> cmdHistory = DebugCommandHandler.instance.cmdHistory;
		historyDraft = commandText;
		historyIndex = cmdHistory.Count - 1;
		commandText = cmdHistory[cmdHistory.Count - 1].TrimEnd();
		cursorIndex = commandText.Length;
		selectionAnchor = cursorIndex;
		cmdSuggestionIndex = 0;
		SuggestionsRefresh();
		CursorBlinkReset();
		RenderInput();
		NavigationEffect();
		return true;
	}

	private void NavigationInput()
	{
		bool flag = ControlPressed();
		bool selecting = ShiftPressed();
		if (RepeatPressed((KeyCode)276))
		{
			int target = (flag ? PreviousWordIndex(cursorIndex) : (cursorIndex - 1));
			CursorMove(target, selecting, -1);
		}
		else if (RepeatPressed((KeyCode)275))
		{
			int target2 = (flag ? NextWordIndex(cursorIndex) : (cursorIndex + 1));
			CursorMove(target2, selecting, 1);
		}
		if (Input.GetKeyDown((KeyCode)278))
		{
			CursorMove(0, selecting, -1);
		}
		if (Input.GetKeyDown((KeyCode)279))
		{
			CursorMove(commandText.Length, selecting, 1);
		}
	}

	private void DeleteInput()
	{
		if (RepeatPressed((KeyCode)8))
		{
			if (SelectionDelete(playEffect: false))
			{
				DeleteEffect();
			}
			else if (cursorIndex > 0)
			{
				selectionAnchor = (ControlPressed() ? PreviousWordIndex(cursorIndex) : (cursorIndex - 1));
				SelectionDelete(playEffect: true);
			}
		}
		else if (RepeatPressed((KeyCode)127))
		{
			if (SelectionDelete(playEffect: false))
			{
				DeleteEffect();
			}
			else if (cursorIndex < commandText.Length)
			{
				selectionAnchor = (ControlPressed() ? NextWordIndex(cursorIndex) : (cursorIndex + 1));
				SelectionDelete(playEffect: true);
			}
		}
	}

	private void MouseInput()
	{
		//IL_0023: Unknown result type (might be due to invalid IL or missing references)
		//IL_0028: Unknown result type (might be due to invalid IL or missing references)
		if (Input.GetMouseButtonDown(0))
		{
			if (SuggestionMouseSelect())
			{
				mouseSelecting = false;
				return;
			}
			if (!RectTransformUtility.RectangleContainsScreenPoint(((TMP_Text)chatText).rectTransform, Vector2.op_Implicit(Input.mousePosition), UICameraGet()))
			{
				mouseSelecting = false;
				return;
			}
			int num = MouseCommandIndex();
			if (!ShiftPressed())
			{
				selectionAnchor = num;
			}
			cursorIndex = num;
			mouseSelecting = true;
			CursorChanged();
		}
		else if (mouseSelecting && Input.GetMouseButton(0))
		{
			int num2 = MouseCommandIndex();
			if (cursorIndex != num2)
			{
				cursorIndex = num2;
				CursorChanged(playEffect: false);
			}
		}
		if (Input.GetMouseButtonUp(0))
		{
			mouseSelecting = false;
		}
	}

	private void TypedInput()
	{
		//IL_003f: Unknown result type (might be due to invalid IL or missing references)
		string text = new string(Input.inputString.Where((char _character) => !char.IsControl(_character)).ToArray());
		if (text.Length != 0)
		{
			TextInsert(text, Color.yellow);
		}
	}

	private void TextInsert(string text, Color color)
	{
		//IL_00d9: Unknown result type (might be due to invalid IL or missing references)
		if (string.IsNullOrEmpty(text))
		{
			return;
		}
		StringBuilder stringBuilder = new StringBuilder(text.Length);
		foreach (char c in text)
		{
			if (c == '\t' || c == '\r' || c == '\n')
			{
				stringBuilder.Append(' ');
			}
			else if (!char.IsControl(c))
			{
				stringBuilder.Append(c);
			}
		}
		string text2 = stringBuilder.ToString();
		if (text2.Length != 0)
		{
			int num = Math.Min(cursorIndex, selectionAnchor);
			int num2 = Math.Max(cursorIndex, selectionAnchor);
			commandText = commandText.Remove(num, num2 - num).Insert(num, text2);
			cursorIndex = num + text2.Length;
			selectionAnchor = cursorIndex;
			InputChanged();
			TypeEffect(color);
		}
	}

	private bool SelectionDelete(bool playEffect)
	{
		if (cursorIndex == selectionAnchor)
		{
			return false;
		}
		int num = Math.Min(cursorIndex, selectionAnchor);
		int num2 = Math.Max(cursorIndex, selectionAnchor);
		commandText = commandText.Remove(num, num2 - num);
		cursorIndex = num;
		selectionAnchor = cursorIndex;
		InputChanged();
		if (playEffect)
		{
			DeleteEffect();
		}
		return true;
	}

	private bool SelectionCopy()
	{
		if (cursorIndex == selectionAnchor)
		{
			return false;
		}
		int num = Math.Min(cursorIndex, selectionAnchor);
		int num2 = Math.Max(cursorIndex, selectionAnchor);
		GUIUtility.systemCopyBuffer = commandText.Substring(num, num2 - num);
		NavigationEffect();
		return true;
	}

	private void CursorMove(int target, bool selecting, int direction)
	{
		int num = Mathf.Clamp(target, 0, commandText.Length);
		if (!selecting && cursorIndex != selectionAnchor)
		{
			num = ((direction < 0) ? Math.Min(cursorIndex, selectionAnchor) : Math.Max(cursorIndex, selectionAnchor));
		}
		if (cursorIndex != num || (!selecting && selectionAnchor != num))
		{
			cursorIndex = num;
			if (!selecting)
			{
				selectionAnchor = cursorIndex;
			}
			CursorChanged();
		}
	}

	private void CursorChanged(bool playEffect = true)
	{
		cmdSuggestionIndex = 0;
		SuggestionsRefresh();
		CursorBlinkReset();
		RenderInput();
		if (playEffect)
		{
			NavigationEffect();
		}
	}

	private void InputChanged()
	{
		historyIndex = (Object.op_Implicit((Object)(object)DebugCommandHandler.instance) ? DebugCommandHandler.instance.cmdHistory.Count : 0);
		historyDraft = commandText;
		cmdSuggestionIndex = 0;
		SuggestionsRefresh();
		CursorBlinkReset();
		RenderInput();
	}

	private void HistoryMove(int direction)
	{
		if (!Object.op_Implicit((Object)(object)DebugCommandHandler.instance) || DebugCommandHandler.instance.cmdHistory.Count == 0)
		{
			return;
		}
		List<string> cmdHistory = DebugCommandHandler.instance.cmdHistory;
		if (historyIndex < 0 || historyIndex > cmdHistory.Count)
		{
			historyIndex = cmdHistory.Count;
		}
		if (direction < 0)
		{
			if (historyIndex == cmdHistory.Count)
			{
				historyDraft = commandText;
			}
			historyIndex = Mathf.Max(0, historyIndex - 1);
			commandText = cmdHistory[historyIndex];
		}
		else
		{
			if (historyIndex >= cmdHistory.Count)
			{
				return;
			}
			historyIndex++;
			commandText = ((historyIndex == cmdHistory.Count) ? historyDraft : cmdHistory[historyIndex]);
		}
		cursorIndex = commandText.Length;
		selectionAnchor = cursorIndex;
		cmdSuggestionIndex = 0;
		SuggestionsRefresh();
		CursorBlinkReset();
		RenderInput();
		NavigationEffect();
	}

	private void SuggestionMove(int direction, bool playEffect = true)
	{
		if (cmdSuggestions.Count != 0)
		{
			cmdSuggestionIndex = (cmdSuggestionIndex + direction + cmdSuggestions.Count) % cmdSuggestions.Count;
			UpdateCommandSuggestionsDisplay(commandText.Substring(0, cursorIndex));
			if (playEffect)
			{
				NavigationEffect();
			}
		}
	}

	private void SuggestionApply()
	{
		if (cmdSuggestions.Count == 0)
		{
			return;
		}
		string text = cmdSuggestions[Mathf.Clamp(cmdSuggestionIndex, 0, cmdSuggestions.Count - 1)];
		bool flag = Object.op_Implicit((Object)(object)DebugCommandHandler.instance) && DebugCommandHandler.instance.cmdHistory.Contains(text);
		string text2 = commandText.Substring(0, cursorIndex);
		string[] array = text2.Split(' ', StringSplitOptions.RemoveEmptyEntries);
		bool flag2 = array.Length == 0 || (array.Length == 1 && !text2.EndsWith(" "));
		if ((text2.Length == 0) | flag2)
		{
			commandText = text + (flag ? "" : " ");
		}
		else
		{
			string key = array[0].TrimStart('/');
			int count = 1;
			if (multiTokenCommands.TryGetValue(key, out var value) && array.Length >= value && (text2.EndsWith(" ") || array.Length > value))
			{
				count = value;
			}
			string text3 = string.Join(" ", array.Take(count));
			commandText = text3 + " " + text + " ";
		}
		cursorIndex = commandText.Length;
		selectionAnchor = cursorIndex;
		InputChanged();
		NavigationEffect();
	}

	private void SuggestionsRefresh()
	{
		if (!Object.op_Implicit((Object)(object)DebugCommandHandler.instance))
		{
			cmdSuggestions.Clear();
			((TMP_Text)suggestionsText).text = "";
			((TMP_Text)scrollIndicator).text = "";
		}
		else
		{
			string partial = commandText.Substring(0, cursorIndex);
			cmdSuggestions = DebugCommandHandler.instance.GetSuggestions(partial, isDebugConsole: true);
			cmdSuggestionIndex = Mathf.Clamp(cmdSuggestionIndex, 0, Math.Max(0, cmdSuggestions.Count - 1));
			UpdateCommandSuggestionsDisplay(partial);
		}
	}

	private void UpdateCommandSuggestionsDisplay(string partial)
	{
		List<string> list = ((partial.Split(' ').Length > 1 || (!(partial != "") && DebugCommandHandler.instance.cmdHistory.Count != 0)) ? cmdSuggestions.ToList() : cmdSuggestions.Select((string _suggestion) => (!DebugCommandHandler.instance._commands.TryGetValue(_suggestion.TrimStart('/'), out var value2)) ? _suggestion : (_suggestion + " - " + value2.Description)).ToList());
		suggestionDisplayStart = Math.Clamp(cmdSuggestionIndex - 5, 0, Math.Max(0, list.Count - 10));
		int num = Math.Min(suggestionDisplayStart + 10, list.Count);
		StringBuilder stringBuilder = new StringBuilder();
		for (int num2 = suggestionDisplayStart; num2 < num; num2++)
		{
			if (stringBuilder.Length > 0)
			{
				stringBuilder.Append('\n');
			}
			string value = RichTextPlain(list[num2]);
			if (num2 == cmdSuggestionIndex)
			{
				stringBuilder.Append("<color=#00FFFF><b>> ");
				stringBuilder.Append(value);
				stringBuilder.Append("</b></color>");
			}
			else
			{
				stringBuilder.Append("  ");
				stringBuilder.Append(value);
			}
		}
		((TMP_Text)suggestionsText).text = stringBuilder.ToString();
		bool flag = suggestionDisplayStart > 0;
		bool flag2 = num < list.Count;
		if (flag & flag2)
		{
			((TMP_Text)scrollIndicator).text = "↕";
		}
		else if (flag)
		{
			((TMP_Text)scrollIndicator).text = "↑";
		}
		else if (flag2)
		{
			((TMP_Text)scrollIndicator).text = "↓";
		}
		else
		{
			((TMP_Text)scrollIndicator).text = "";
		}
	}

	private void CommandDisplayRefresh()
	{
		cmdSuggestionIndex = 0;
		SuggestionsRefresh();
		CursorBlinkReset();
		RenderInput();
	}

	private void CursorBlinkTick()
	{
		if (cursorBlinkResetTimer > 0f)
		{
			cursorBlinkResetTimer -= Time.unscaledDeltaTime;
		}
		int num = ((cursorBlinkResetTimer > 0f || Mathf.Sin(Time.unscaledTime * 10f) > 0f) ? 1 : 0);
		if (num != prevCursorBlinkPhase)
		{
			prevCursorBlinkPhase = num;
			RenderInput();
		}
	}

	private void CursorBlinkReset()
	{
		cursorBlinkResetTimer = 0.45f;
		prevCursorBlinkPhase = -1;
	}

	private void RenderInput()
	{
		//IL_008b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0127: Unknown result type (might be due to invalid IL or missing references)
		if (!Object.op_Implicit((Object)(object)chatText))
		{
			return;
		}
		DisplayWindowGet(out displayStart, out displayEnd);
		int num = Math.Min(cursorIndex, selectionAnchor);
		int num2 = Math.Max(cursorIndex, selectionAnchor);
		StringBuilder stringBuilder = new StringBuilder();
		if (displayStart > 0)
		{
			stringBuilder.Append("<color=#FF8D00>...</color>");
		}
		int num3 = displayStart;
		while (num3 <= displayEnd)
		{
			if (num3 == cursorIndex)
			{
				if (prevCursorBlinkPhase == 1)
				{
					stringBuilder.Append("<color=#");
					stringBuilder.Append(ColorUtility.ToHtmlStringRGBA(cursorColor));
					stringBuilder.Append(">|</color>");
				}
				else
				{
					stringBuilder.Append("<color=#00000000>|</color>");
				}
			}
			if (num3 == displayEnd)
			{
				break;
			}
			bool num4 = num3 >= num && num3 < num2;
			int num5 = displayEnd;
			if (num4)
			{
				num5 = Math.Min(num5, num2);
			}
			else if (num3 < num)
			{
				num5 = Math.Min(num5, num);
			}
			if (cursorIndex > num3 && cursorIndex < num5)
			{
				num5 = cursorIndex;
			}
			if (num5 <= num3)
			{
				num5 = num3 + 1;
			}
			if (num4)
			{
				stringBuilder.Append("<mark=#");
				stringBuilder.Append(ColorUtility.ToHtmlStringRGBA(selectionColor));
				stringBuilder.Append(">");
			}
			stringBuilder.Append(RichTextPlain(commandText.Substring(num3, num5 - num3)));
			if (num4)
			{
				stringBuilder.Append("</mark>");
			}
			num3 = num5;
		}
		if (displayEnd < commandText.Length)
		{
			stringBuilder.Append("<color=#FF8D00>...</color>");
		}
		((TMP_Text)chatText).text = stringBuilder.ToString();
	}

	private void DisplayWindowGet(out int start, out int end)
	{
		//IL_001b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0020: Unknown result type (might be due to invalid IL or missing references)
		start = 0;
		end = commandText.Length;
		Rect rect = ((TMP_Text)chatText).rectTransform.rect;
		float num = rect.width - 4f;
		if (num <= 0f || TextWidth(commandText + "|") <= num)
		{
			return;
		}
		float num2 = num * 0.72f;
		while (start < cursorIndex && TextWidth("..." + commandText.Substring(start, cursorIndex - start) + "|") > num2)
		{
			start++;
		}
		end = cursorIndex;
		while (end < commandText.Length && TextWidth(((start > 0) ? "..." : "") + commandText.Substring(start, end - start + 1) + "|") <= num)
		{
			end++;
		}
		if (end < commandText.Length)
		{
			while (end > cursorIndex && TextWidth(((start > 0) ? "..." : "") + commandText.Substring(start, end - start) + "|...") > num)
			{
				end--;
			}
		}
	}

	private float TextWidth(string text)
	{
		//IL_000d: Unknown result type (might be due to invalid IL or missing references)
		return ((TMP_Text)chatText).GetPreferredValues(RichTextPlain(text)).x;
	}

	private string RichTextPlain(string text)
	{
		if (string.IsNullOrEmpty(text))
		{
			return "";
		}
		StringBuilder stringBuilder = new StringBuilder(text.Length + 20);
		stringBuilder.Append("<noparse>");
		for (int i = 0; i < text.Length; i++)
		{
			if (i + 10 <= text.Length && string.Compare(text, i, "</noparse>", 0, 10, StringComparison.OrdinalIgnoreCase) == 0)
			{
				stringBuilder.Append("</no\u200bparse>");
				i += 9;
			}
			else
			{
				stringBuilder.Append(text[i]);
			}
		}
		stringBuilder.Append("</noparse>");
		return stringBuilder.ToString();
	}

	private int PreviousWordIndex(int index)
	{
		int num = Mathf.Clamp(index, 0, commandText.Length);
		while (num > 0 && char.IsWhiteSpace(commandText[num - 1]))
		{
			num--;
		}
		while (num > 0 && !char.IsWhiteSpace(commandText[num - 1]))
		{
			num--;
		}
		return num;
	}

	private int NextWordIndex(int index)
	{
		int i;
		for (i = Mathf.Clamp(index, 0, commandText.Length); i < commandText.Length && !char.IsWhiteSpace(commandText[i]); i++)
		{
		}
		for (; i < commandText.Length && char.IsWhiteSpace(commandText[i]); i++)
		{
		}
		return i;
	}

	private void KeyRepeatTick()
	{
		//IL_0001: Unknown result type (might be due to invalid IL or missing references)
		//IL_0009: Unknown result type (might be due to invalid IL or missing references)
		//IL_0017: Unknown result type (might be due to invalid IL or missing references)
		if ((int)repeatKey != 0 && !Input.GetKey(repeatKey))
		{
			repeatKey = (KeyCode)0;
		}
	}

	private bool RepeatPressed(KeyCode key)
	{
		//IL_0000: Unknown result type (might be due to invalid IL or missing references)
		//IL_001d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0022: Unknown result type (might be due to invalid IL or missing references)
		//IL_0009: Unknown result type (might be due to invalid IL or missing references)
		//IL_000a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0025: Unknown result type (might be due to invalid IL or missing references)
		if (Input.GetKeyDown(key))
		{
			repeatKey = key;
			repeatTimer = 0.4f;
			return true;
		}
		if (repeatKey != key || !Input.GetKey(key))
		{
			return false;
		}
		repeatTimer -= Time.unscaledDeltaTime;
		if (repeatTimer > 0f)
		{
			return false;
		}
		repeatTimer = 0.09f;
		return true;
	}

	private bool GamepadSubmitPressed()
	{
		if (!gamepadTextInput.IsOpen && Gamepad.current != null)
		{
			return Gamepad.current.buttonSouth.wasPressedThisFrame;
		}
		return false;
	}

	private bool GamepadTabPressed()
	{
		if (!gamepadTextInput.IsOpen && Gamepad.current != null)
		{
			return Gamepad.current.buttonNorth.wasPressedThisFrame;
		}
		return false;
	}

	private int RepeatedGamepadNavigateDirection()
	{
		//IL_0025: Unknown result type (might be due to invalid IL or missing references)
		Gamepad current = Gamepad.current;
		if (current == null || gamepadTextInput.IsOpen)
		{
			gamepadNavigateDirection = 0;
			return 0;
		}
		float num = ((InputControl<Vector2>)(object)current.leftStick).ReadValue().y;
		if (current.dpad.up.isPressed)
		{
			num = 1f;
		}
		else if (current.dpad.down.isPressed)
		{
			num = -1f;
		}
		int num2 = ((num > 0.5f) ? 1 : ((num < -0.5f) ? (-1) : 0));
		if (num2 == 0)
		{
			gamepadNavigateDirection = 0;
			return 0;
		}
		if (num2 != gamepadNavigateDirection)
		{
			gamepadNavigateDirection = num2;
			gamepadNavigateTimer = 0.4f;
			return num2;
		}
		gamepadNavigateTimer -= Time.unscaledDeltaTime;
		if (gamepadNavigateTimer > 0f)
		{
			return 0;
		}
		gamepadNavigateTimer = 0.09f;
		return num2;
	}

	private int MouseCommandIndex()
	{
		//IL_0026: Unknown result type (might be due to invalid IL or missing references)
		//IL_0049: Unknown result type (might be due to invalid IL or missing references)
		//IL_004e: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0072: Unknown result type (might be due to invalid IL or missing references)
		//IL_0073: Unknown result type (might be due to invalid IL or missing references)
		//IL_0079: Unknown result type (might be due to invalid IL or missing references)
		//IL_007a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0084: Unknown result type (might be due to invalid IL or missing references)
		//IL_0085: Unknown result type (might be due to invalid IL or missing references)
		if (((TMP_Text)chatText).textInfo.characterCount == 0)
		{
			return cursorIndex;
		}
		Camera val = UICameraGet();
		int num = TMP_TextUtilities.FindNearestCharacter((TMP_Text)(object)chatText, Input.mousePosition, val, true);
		if (num < 0)
		{
			return cursorIndex;
		}
		Vector2 val2 = default;
		RectTransformUtility.ScreenPointToLocalPointInRectangle(((TMP_Text)chatText).rectTransform, Vector2.op_Implicit(Input.mousePosition), val, ref val2);
		TMP_CharacterInfo val3 = ((TMP_Text)chatText).textInfo.characterInfo[num];
		int num2 = ((val2.x > (val3.bottomLeft.x + val3.topRight.x) * 0.5f) ? 1 : 0);
		int num3 = num + num2;
		if (displayStart > 0)
		{
			num3--;
		}
		int num4 = cursorIndex - displayStart;
		if (num3 > num4)
		{
			num3--;
		}
		return Mathf.Clamp(displayStart + num3, displayStart, displayEnd);
	}

	private bool SuggestionMouseSelect()
	{
		//IL_001a: Unknown result type (might be due to invalid IL or missing references)
		//IL_001f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0040: Unknown result type (might be due to invalid IL or missing references)
		if (cmdSuggestions.Count == 0)
		{
			return false;
		}
		if (!RectTransformUtility.RectangleContainsScreenPoint(((TMP_Text)suggestionsText).rectTransform, Vector2.op_Implicit(Input.mousePosition), UICameraGet()))
		{
			return false;
		}
		Camera val = UICameraGet();
		int num = TMP_TextUtilities.FindNearestCharacter((TMP_Text)(object)suggestionsText, Input.mousePosition, val, true);
		if (num < 0)
		{
			return true;
		}
		int lineNumber = ((TMP_Text)suggestionsText).textInfo.characterInfo[num].lineNumber;
		int num2 = suggestionDisplayStart + lineNumber;
		if (num2 < 0 || num2 >= cmdSuggestions.Count)
		{
			return true;
		}
		cmdSuggestionIndex = num2;
		UpdateCommandSuggestionsDisplay(commandText.Substring(0, cursorIndex));
		NavigationEffect();
		return true;
	}

	private Camera UICameraGet()
	{
		//IL_0015: Unknown result type (might be due to invalid IL or missing references)
		Canvas canvas = ((Graphic)chatText).canvas;
		if (!Object.op_Implicit((Object)(object)canvas) || (int)canvas.renderMode == 0)
		{
			return null;
		}
		return canvas.worldCamera;
	}

	private bool ControlPressed()
	{
		if (!Input.GetKey((KeyCode)306))
		{
			return Input.GetKey((KeyCode)305);
		}
		return true;
	}

	private bool ShiftPressed()
	{
		if (!Input.GetKey((KeyCode)304))
		{
			return Input.GetKey((KeyCode)303);
		}
		return true;
	}

	private void FlairTick()
	{
		//IL_0085: Unknown result type (might be due to invalid IL or missing references)
		//IL_0091: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a2: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a9: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ae: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d4: Unknown result type (might be due to invalid IL or missing references)
		//IL_00cc: Unknown result type (might be due to invalid IL or missing references)
		if (Object.op_Implicit((Object)(object)flairTransform) && Object.op_Implicit((Object)(object)chatText))
		{
			float unscaledDeltaTime = Time.unscaledDeltaTime;
			float num = FlairSpringOffset(flairScaleTimer, flairScaleTime, flairScaleAmount, flairScaleFrequency);
			float num2 = FlairSpringOffset(flairShakeXTimer, flairShakeXTime, flairShakeXAmount, flairShakeXFrequency);
			float num3 = FlairSpringOffset(flairShakeYTimer, flairShakeYTime, flairShakeYAmount, flairShakeYFrequency);
			((Transform)flairTransform).localScale = flairScale * (1f + num);
			flairTransform.anchoredPosition = flairPosition + new Vector2(num2, num3);
			((Graphic)chatText).color = ((flairFlashTimer > 0f) ? flairFlashColor : flairTextColor);
			flairFlashTimer = Mathf.Max(0f, flairFlashTimer - unscaledDeltaTime);
			flairScaleTimer = Mathf.Max(0f, flairScaleTimer - unscaledDeltaTime);
			flairShakeXTimer = Mathf.Max(0f, flairShakeXTimer - unscaledDeltaTime);
			flairShakeYTimer = Mathf.Max(0f, flairShakeYTimer - unscaledDeltaTime);
		}
	}

	private float FlairSpringOffset(float timer, float time, float amount, float frequency)
	{
		if (timer <= 0f || time <= 0f)
		{
			return 0f;
		}
		float num = 1f - timer / time;
		float num2 = frequency * (1f - num);
		return amount * Mathf.Sin(num2 * num * MathF.PI * 2f) * (1f - num);
	}

	private void FlairFlash(Color color, float time)
	{
		//IL_0001: Unknown result type (might be due to invalid IL or missing references)
		//IL_0002: Unknown result type (might be due to invalid IL or missing references)
		flairFlashColor = color;
		flairFlashTimer = time;
	}

	private void FlairScaleImpulse(float amount, float frequency, float time)
	{
		flairScaleAmount = amount;
		flairScaleFrequency = frequency;
		flairScaleTime = time;
		flairScaleTimer = time;
	}

	private void FlairShakeXImpulse(float amount, float frequency, float time)
	{
		flairShakeXAmount = amount;
		flairShakeXFrequency = frequency;
		flairShakeXTime = time;
		flairShakeXTimer = time;
	}

	private void FlairShakeYImpulse(float amount, float frequency, float time)
	{
		flairShakeYAmount = amount;
		flairShakeYFrequency = frequency;
		flairShakeYTime = time;
		flairShakeYTimer = time;
	}

	private void FlairReset()
	{
		//IL_0040: Unknown result type (might be due to invalid IL or missing references)
		//IL_0051: Unknown result type (might be due to invalid IL or missing references)
		//IL_006f: Unknown result type (might be due to invalid IL or missing references)
		flairFlashTimer = 0f;
		flairScaleTimer = 0f;
		flairShakeXTimer = 0f;
		flairShakeYTimer = 0f;
		if (Object.op_Implicit((Object)(object)flairTransform))
		{
			flairTransform.anchoredPosition = flairPosition;
			((Transform)flairTransform).localScale = flairScale;
		}
		if (Object.op_Implicit((Object)(object)chatText))
		{
			((Graphic)chatText).color = flairTextColor;
		}
	}

	private void TypeEffect(Color color)
	{
		//IL_0001: Unknown result type (might be due to invalid IL or missing references)
		FlairFlash(color, 0.2f);
		FlairShakeYImpulse(2f, 5f, 0.2f);
		MenuManager.instance?.MenuEffectClick(MenuManager.MenuClickEffectType.Tick, null, 2f, 0.2f, soundOnly: true);
	}

	private void DeleteEffect()
	{
		//IL_0001: Unknown result type (might be due to invalid IL or missing references)
		FlairFlash(Color.red, 0.2f);
		FlairShakeXImpulse(5f, 5f, 0.2f);
		MenuManager.instance?.MenuEffectClick(MenuManager.MenuClickEffectType.Dud, null, 2f, 1f, soundOnly: true);
	}

	private void NavigationEffect()
	{
		//IL_0001: Unknown result type (might be due to invalid IL or missing references)
		FlairFlash(Color.cyan, 0.2f);
		FlairShakeYImpulse(2f, 5f, 0.2f);
		MenuManager.instance?.MenuEffectClick(MenuManager.MenuClickEffectType.Tick, null, 1f, 0.2f, soundOnly: true);
	}

	private void DenyEffect()
	{
		//IL_0001: Unknown result type (might be due to invalid IL or missing references)
		FlairFlash(Color.red, 0.2f);
		FlairShakeXImpulse(10f, 10f, 0.3f);
		FlairScaleImpulse(0.05f, 5f, 0.2f);
		MenuManager.instance?.MenuEffectClick(MenuManager.MenuClickEffectType.Deny, null, 1f, 1f, soundOnly: true);
	}

	internal void SetResponseText(string text, Color color, float duration = 2f)
	{
		//IL_003b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0046: Unknown result type (might be due to invalid IL or missing references)
		//IL_0062: Unknown result type (might be due to invalid IL or missing references)
		float num = ((Object.op_Implicit((Object)(object)DebugTesterUI.instance) && DebugTesterUI.instance.Active) ? 40f : 5f);
		((TMP_Text)responseText).rectTransform.anchoredPosition = new Vector2(((TMP_Text)responseText).rectTransform.anchoredPosition.x, num);
		((TMP_Text)responseText).text = text;
		((Graphic)responseText).color = color;
		if (!string.IsNullOrWhiteSpace(text))
		{
			((MonoBehaviour)this).StartCoroutine(ClearResponseText(text, duration));
		}
	}

	private IEnumerator ClearResponseText(string text, float duration)
	{
		yield return (object)new WaitForSeconds(duration);
		if (((TMP_Text)responseText).text == text)
		{
			((TMP_Text)responseText).text = "";
		}
	}

	public void ShowDebugMenu(bool state)
	{
		StateSet(state ? State.Active : State.Inactive);
	}

	public DebugConsoleUI()
	{
		//IL_0015: Unknown result type (might be due to invalid IL or missing references)
		//IL_001a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0034: Unknown result type (might be due to invalid IL or missing references)
		//IL_0039: Unknown result type (might be due to invalid IL or missing references)
	}
}
