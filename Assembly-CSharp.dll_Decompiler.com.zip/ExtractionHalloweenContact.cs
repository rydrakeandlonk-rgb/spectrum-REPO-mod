using System.Collections.Generic;
using UnityEngine;

public class ExtractionHalloweenContact : MonoBehaviour
{
	internal struct Support
	{
		internal Collider collider;

		internal Collider ownCollider;

		internal Vector3 point;

		internal Vector3 localPoint;

		internal Vector3 ownLocalPoint;

		internal bool player;
	}

	internal uint interactionVersion;

	private float lastInteractionTime = float.NegativeInfinity;

	private const float contactGraceTime = 0.2f;

	private readonly Dictionary<(Collider own, Collider other), float> contactExitTimes = new Dictionary<(Collider, Collider), float>();

	private readonly List<(Collider own, Collider other)> expiredContacts = new List<(Collider, Collider)>();

	internal readonly Dictionary<(Collider own, Collider other), Support> contacts = new Dictionary<(Collider, Collider), Support>();

	internal readonly Dictionary<(Collider own, Collider other), Support> supports = new Dictionary<(Collider, Collider), Support>();

	internal readonly Dictionary<(Collider own, Collider other), Support> blockedAbove = new Dictionary<(Collider, Collider), Support>();

	internal ValuableObject valuable;

	internal PhysGrabObject physGrabObject;

	internal Collider[] colliders;

	private void Awake()
	{
		valuable = ((Component)this).GetComponent<ValuableObject>();
		physGrabObject = ((Component)this).GetComponent<PhysGrabObject>();
		colliders = ((Component)this).GetComponentsInChildren<Collider>();
	}

	private void OnCollisionEnter(Collision _collision)
	{
		SupportUpdate(_collision);
	}

	private void OnCollisionStay(Collision _collision)
	{
		SupportUpdate(_collision);
	}

	private void OnCollisionExit(Collision _collision)
	{
		ContactEnd((own: _collision.thisCollider, other: _collision.collider));
	}

	private void ContactEnd((Collider own, Collider other) _pair)
	{
		if (contacts.ContainsKey(_pair) && !contactExitTimes.ContainsKey(_pair))
		{
			contactExitTimes[_pair] = Time.time;
		}
		blockedAbove.Remove(_pair);
	}

	private void Update()
	{
		ExpiredContactsClear();
	}

	private void ExpiredContactsClear()
	{
		if (contactExitTimes.Count == 0)
		{
			return;
		}
		expiredContacts.Clear();
		foreach (KeyValuePair<(Collider, Collider), float> contactExitTime in contactExitTimes)
		{
			if (Time.time - contactExitTime.Value >= 0.2f)
			{
				expiredContacts.Add(contactExitTime.Key);
			}
		}
		foreach (var expiredContact in expiredContacts)
		{
			contacts.Remove(expiredContact);
			supports.Remove(expiredContact);
			contactExitTimes.Remove(expiredContact);
		}
	}

	private void OnDisable()
	{
		interactionVersion++;
		contacts.Clear();
		supports.Clear();
		blockedAbove.Clear();
		contactExitTimes.Clear();
		expiredContacts.Clear();
	}

	internal void InteractionRegister()
	{
		if (SemiFunc.GameEventIsHalloween() && SemiFunc.RunIsLevel())
		{
			interactionVersion++;
			lastInteractionTime = Time.time;
		}
	}

	private void SupportUpdate(Collision _collision)
	{
		//IL_00d0: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d5: Unknown result type (might be due to invalid IL or missing references)
		//IL_00fc: Unknown result type (might be due to invalid IL or missing references)
		//IL_0101: Unknown result type (might be due to invalid IL or missing references)
		//IL_0115: Unknown result type (might be due to invalid IL or missing references)
		//IL_011a: Unknown result type (might be due to invalid IL or missing references)
		//IL_011f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0133: Unknown result type (might be due to invalid IL or missing references)
		//IL_0138: Unknown result type (might be due to invalid IL or missing references)
		//IL_013d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0166: Unknown result type (might be due to invalid IL or missing references)
		//IL_016b: Unknown result type (might be due to invalid IL or missing references)
		if (!SemiFunc.GameEventIsHalloween() || !SemiFunc.RunIsLevel())
		{
			return;
		}
		(Collider, Collider) tuple = (_collision.thisCollider, _collision.collider);
		if (_collision.contactCount == 0)
		{
			ContactEnd(tuple);
			return;
		}
		contactExitTimes.Remove(tuple);
		supports.Remove(tuple);
		blockedAbove.Remove(tuple);
		if (!contacts.TryGetValue(tuple, out var value))
		{
			value.player = Object.op_Implicit((Object)(object)((Component)_collision.collider).GetComponentInParent<PlayerController>()) || Object.op_Implicit((Object)(object)((Component)_collision.collider).GetComponentInParent<PlayerAvatar>()) || Object.op_Implicit((Object)(object)((Component)_collision.collider).GetComponentInParent<PlayerTumble>()) || Object.op_Implicit((Object)(object)((Component)_collision.collider).GetComponentInParent<PlayerPhysPusher>());
		}
		if (value.player)
		{
			InteractionRegister();
		}
		for (int i = 0; i < _collision.contactCount; i++)
		{
			ContactPoint contact = _collision.GetContact(i);
			Support value2 = new Support
			{
				collider = _collision.collider,
				ownCollider = _collision.thisCollider,
				point = contact.point,
				localPoint = ((Component)_collision.collider).transform.InverseTransformPoint(contact.point),
				ownLocalPoint = ((Component)_collision.thisCollider).transform.InverseTransformPoint(contact.point),
				player = value.player
			};
			if (i == 0)
			{
				contacts[tuple] = value2;
			}
			float num = Vector3.Dot(contact.normal, Vector3.up);
			if (num >= 0.45f)
			{
				supports[tuple] = value2;
			}
			else if (num <= -0.45f && Object.op_Implicit((Object)(object)((Component)_collision.collider).GetComponentInParent<PhysGrabObject>()) && !Object.op_Implicit((Object)(object)((Component)_collision.collider).GetComponentInParent<ValuableObject>()))
			{
				blockedAbove[tuple] = value2;
			}
		}
	}

	internal bool SupportIsCurrent(Support _support)
	{
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0072: Unknown result type (might be due to invalid IL or missing references)
		//IL_007f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0084: Unknown result type (might be due to invalid IL or missing references)
		//IL_0089: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d1: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d2: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d8: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b8: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b9: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ba: Unknown result type (might be due to invalid IL or missing references)
		//IL_00bf: Unknown result type (might be due to invalid IL or missing references)
		if (!Object.op_Implicit((Object)(object)_support.collider) || !_support.collider.enabled || !((Component)_support.collider).gameObject.activeInHierarchy)
		{
			return false;
		}
		if (!Object.op_Implicit((Object)(object)_support.ownCollider) || !_support.ownCollider.enabled || !((Component)_support.ownCollider).gameObject.activeInHierarchy)
		{
			return false;
		}
		Vector3 val = ((Component)_support.collider).transform.TransformPoint(_support.localPoint);
		Vector3 val2 = ((Component)_support.ownCollider).transform.TransformPoint(_support.ownLocalPoint);
		Vector3 val3;
		if (contactExitTimes.TryGetValue((_support.ownCollider, _support.collider), out var value))
		{
			if (Time.time - value < 0.2f)
			{
				val3 = val - val2;
				return val3.sqrMagnitude < 0.0144f;
			}
			return false;
		}
		val3 = val - val2;
		return val3.sqrMagnitude < 0.0016f;
	}

	internal bool IsSettled()
	{
		if (Object.op_Implicit((Object)(object)physGrabObject.rb) && Time.time - lastInteractionTime >= 0.25f && !physGrabObject.grabbed)
		{
			return physGrabObject.playerGrabbing.Count == 0;
		}
		return false;
	}
}
