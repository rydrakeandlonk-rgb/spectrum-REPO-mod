using System.Collections.Generic;
using UnityEngine;

public class EnemyValuable : MonoBehaviour
{
	private PhysGrabObjectImpactDetector impactDetector;

	private float indestructibleTimer = 5f;

	public MeshRenderer outerMeshRenderer;

	public PumpkinAppearance halloweenPumpkin;

	private Material outerMaterial;

	private int fresnelPowerIndex;

	private int fresnelColorIndex;

	[Space]
	private float fresnelPowerDefault;

	public float fresnelPowerIndestructible;

	[Space]
	private Color fresnelColorDefault;

	public Color fresnelColorIndestructible;

	[Space]
	public AnimationCurve indestructibleCurve;

	private float indestructibleLerp;

	[Space]
	public Transform innerTransform;

	public Transform speckSmallTransform;

	public Transform speckBigTransform;

	[Space]
	public List<ParticleSystem> particleSystems;

	public GameObject enemyValuableExplosion;

	private bool hasExplosion;

	private void Start()
	{
		//IL_008e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0093: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a5: Unknown result type (might be due to invalid IL or missing references)
		HalloweenVisualsSetup();
		impactDetector = ((Component)this).GetComponentInChildren<PhysGrabObjectImpactDetector>();
		impactDetector.indestructibleSpawnTimer = 0.1f;
		outerMaterial = ((Renderer)outerMeshRenderer).material;
		fresnelPowerIndex = Shader.PropertyToID("_FresnelPower");
		fresnelColorIndex = Shader.PropertyToID("_FresnelColor");
		fresnelPowerDefault = outerMaterial.GetFloat(fresnelPowerIndex);
		outerMaterial.SetFloat(fresnelPowerIndex, fresnelPowerIndestructible);
		fresnelColorDefault = outerMaterial.GetColor(fresnelColorIndex);
		outerMaterial.SetColor(fresnelColorIndex, fresnelColorIndestructible);
		if (SemiFunc.MoonLevel() >= 4)
		{
			hasExplosion = true;
		}
	}

	private void HalloweenVisualsSetup()
	{
		//IL_003b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0040: Unknown result type (might be due to invalid IL or missing references)
		//IL_0057: Unknown result type (might be due to invalid IL or missing references)
		//IL_005c: Unknown result type (might be due to invalid IL or missing references)
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0066: Unknown result type (might be due to invalid IL or missing references)
		//IL_0072: Unknown result type (might be due to invalid IL or missing references)
		//IL_0087: Unknown result type (might be due to invalid IL or missing references)
		//IL_0092: Unknown result type (might be due to invalid IL or missing references)
		//IL_0099: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a9: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ae: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b1: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b6: Unknown result type (might be due to invalid IL or missing references)
		//IL_00bb: Unknown result type (might be due to invalid IL or missing references)
		if (Object.op_Implicit((Object)(object)halloweenPumpkin))
		{
			bool flag = SemiFunc.GameEventIsHalloween();
			((Component)halloweenPumpkin).gameObject.SetActive(flag);
			if (flag)
			{
				halloweenPumpkin.VariantSet(0);
				Bounds bounds = ((Renderer)outerMeshRenderer).bounds;
				Transform transform = ((Component)halloweenPumpkin).transform;
				Bounds bounds2 = ((Renderer)halloweenPumpkin.meshRenderer).bounds;
				transform.localScale *= bounds.size.x / Mathf.Max(bounds2.size.x, 0.001f);
				Vector3 position = transform.position;
				Vector3 center = bounds.center;
				Bounds bounds3 = ((Renderer)halloweenPumpkin.meshRenderer).bounds;
				transform.position = position + (center - bounds3.center);
				((Renderer)outerMeshRenderer).enabled = false;
				outerMeshRenderer = halloweenPumpkin.meshRenderer;
			}
		}
	}

	private void Update()
	{
		//IL_00de: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e8: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f2: Unknown result type (might be due to invalid IL or missing references)
		//IL_0108: Unknown result type (might be due to invalid IL or missing references)
		//IL_0112: Unknown result type (might be due to invalid IL or missing references)
		//IL_011c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0132: Unknown result type (might be due to invalid IL or missing references)
		//IL_0137: Unknown result type (might be due to invalid IL or missing references)
		//IL_0141: Unknown result type (might be due to invalid IL or missing references)
		//IL_014b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0086: Unknown result type (might be due to invalid IL or missing references)
		//IL_008c: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a2: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a7: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b4: Unknown result type (might be due to invalid IL or missing references)
		if (indestructibleTimer > 0f)
		{
			indestructibleTimer -= Time.deltaTime;
			if (indestructibleTimer <= 0f)
			{
				impactDetector.destroyDisable = false;
			}
		}
		else if (indestructibleLerp < 1f)
		{
			float num = Mathf.Lerp(fresnelPowerIndestructible, fresnelPowerDefault, indestructibleCurve.Evaluate(indestructibleLerp));
			outerMaterial.SetFloat(fresnelPowerIndex, num);
			Color val = Color.Lerp(fresnelColorIndestructible, fresnelColorDefault, indestructibleCurve.Evaluate(indestructibleLerp));
			outerMaterial.SetColor(fresnelColorIndex, val);
			indestructibleLerp += 2f * Time.deltaTime;
		}
		innerTransform.Rotate(((Component)this).transform.up * 60f * Time.deltaTime);
		speckSmallTransform.Rotate(((Component)this).transform.up * 100f * Time.deltaTime);
		speckBigTransform.Rotate(-((Component)this).transform.up * 20f * Time.deltaTime);
	}

	public void Destroy()
	{
		impactDetector.DestroyObject();
	}

	public void DestroyImpulse()
	{
		//IL_0052: Unknown result type (might be due to invalid IL or missing references)
		//IL_0057: Unknown result type (might be due to invalid IL or missing references)
		if (hasExplosion)
		{
			enemyValuableExplosion.transform.parent = null;
			enemyValuableExplosion.SetActive(true);
		}
		foreach (ParticleSystem particleSystem in particleSystems)
		{
			((Component)particleSystem).gameObject.SetActive(true);
			((Component)particleSystem).transform.parent = null;
			MainModule main = particleSystem.main;
			main.stopAction = (ParticleSystemStopAction)2;
		}
	}
}
