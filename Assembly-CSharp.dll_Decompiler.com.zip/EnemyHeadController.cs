using System.Collections.Generic;
using System.Linq;
using Photon.Pun;
using UnityEngine;

public class EnemyHeadController : MonoBehaviourPunCallbacks, IPunObservable
{
	private Quaternion RotationTarget;

	private float RotationDistance;

	private Enemy Enemy;

	public EnemyHeadVisual Visual;

	public EnemyHeadAnimationSystem AnimationSystem;

	[Space]
	public Transform LookAtTransform;

	public Transform AnimationTransform;

	public Transform HairParent;

	private List<EnemyHeadHair> Hairs;

	[Space]
	public List<GameObject> DeathParticles;

	public Sound DeathSound;

	private void Awake()
	{
		Enemy = ((Component)this).GetComponentInParent<Enemy>();
		Hairs = ((Component)HairParent).GetComponentsInChildren<EnemyHeadHair>().ToList();
	}

	private void Update()
	{
		//IL_004b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0056: Unknown result type (might be due to invalid IL or missing references)
		//IL_0078: Unknown result type (might be due to invalid IL or missing references)
		//IL_012f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0135: Unknown result type (might be due to invalid IL or missing references)
		//IL_0142: Unknown result type (might be due to invalid IL or missing references)
		//IL_0216: Unknown result type (might be due to invalid IL or missing references)
		//IL_018d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0192: Unknown result type (might be due to invalid IL or missing references)
		//IL_00da: Unknown result type (might be due to invalid IL or missing references)
		//IL_01e1: Unknown result type (might be due to invalid IL or missing references)
		//IL_01ae: Unknown result type (might be due to invalid IL or missing references)
		//IL_01b3: Unknown result type (might be due to invalid IL or missing references)
		//IL_01b5: Unknown result type (might be due to invalid IL or missing references)
		//IL_01ca: Unknown result type (might be due to invalid IL or missing references)
		//IL_01cf: Unknown result type (might be due to invalid IL or missing references)
		//IL_01d4: Unknown result type (might be due to invalid IL or missing references)
		//IL_01d9: Unknown result type (might be due to invalid IL or missing references)
		//IL_037f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0384: Unknown result type (might be due to invalid IL or missing references)
		//IL_0339: Unknown result type (might be due to invalid IL or missing references)
		//IL_0354: Unknown result type (might be due to invalid IL or missing references)
		//IL_0363: Unknown result type (might be due to invalid IL or missing references)
		//IL_0260: Unknown result type (might be due to invalid IL or missing references)
		//IL_0265: Unknown result type (might be due to invalid IL or missing references)
		//IL_0269: Unknown result type (might be due to invalid IL or missing references)
		//IL_026e: Unknown result type (might be due to invalid IL or missing references)
		//IL_03aa: Unknown result type (might be due to invalid IL or missing references)
		//IL_03af: Unknown result type (might be due to invalid IL or missing references)
		//IL_03b3: Unknown result type (might be due to invalid IL or missing references)
		//IL_03b8: Unknown result type (might be due to invalid IL or missing references)
		//IL_03d3: Unknown result type (might be due to invalid IL or missing references)
		//IL_03e2: Unknown result type (might be due to invalid IL or missing references)
		//IL_030a: Unknown result type (might be due to invalid IL or missing references)
		//IL_028e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0293: Unknown result type (might be due to invalid IL or missing references)
		//IL_0297: Unknown result type (might be due to invalid IL or missing references)
		//IL_029c: Unknown result type (might be due to invalid IL or missing references)
		//IL_02a1: Unknown result type (might be due to invalid IL or missing references)
		//IL_02be: Unknown result type (might be due to invalid IL or missing references)
		//IL_02d4: Unknown result type (might be due to invalid IL or missing references)
		//IL_02d9: Unknown result type (might be due to invalid IL or missing references)
		//IL_02e0: Unknown result type (might be due to invalid IL or missing references)
		if (Enemy.CurrentState == EnemyState.Chase || Enemy.CurrentState == EnemyState.ChaseSlow || Enemy.CurrentState == EnemyState.LookUnder)
		{
			foreach (PlayerAvatar player in GameDirector.instance.PlayerList)
			{
				if (Vector3.Distance(((Component)this).transform.position, ((Component)player).transform.position) < 8f)
				{
					SemiFunc.PlayerEyesOverride(player, Enemy.Vision.VisionTransform.position, 0.1f, ((Component)this).gameObject);
				}
			}
		}
		if (Enemy.TeleportedTimer > 0f)
		{
			foreach (EnemyHeadHair hair in Hairs)
			{
				((Component)hair).transform.position = hair.Target.position;
			}
		}
		if (!Enemy.MasterClient)
		{
			float num = 1f / (float)PhotonNetwork.SerializationRate;
			float num2 = RotationDistance / num;
			LookAtTransform.rotation = Quaternion.RotateTowards(LookAtTransform.rotation, RotationTarget, num2 * Time.deltaTime);
			return;
		}
		Vector3 val2;
		if (Object.op_Implicit((Object)(object)Enemy.AttackStuckPhysObject) && Object.op_Implicit((Object)(object)Enemy.AttackStuckPhysObject.TargetObject))
		{
			PhysGrabObject targetObject = Enemy.AttackStuckPhysObject.TargetObject;
			Vector3 val = targetObject.centerPoint;
			if (Object.op_Implicit((Object)(object)targetObject.roomVolumeCheck))
			{
				val = ((Component)targetObject.roomVolumeCheck).transform.position;
				val += ((Component)targetObject.roomVolumeCheck).transform.TransformDirection(targetObject.roomVolumeCheck.CheckPosition);
			}
			LookAtTransform.LookAt(val);
		}
		else if (Enemy.CurrentState == EnemyState.ChaseBegin)
		{
			LookAtTransform.LookAt(Enemy.TargetPlayerAvatar.PlayerVisionTarget.VisionTransform.position);
		}
		else if (Enemy.CurrentState == EnemyState.Chase && Enemy.StateChase.VisionTimer > 0f)
		{
			val2 = Enemy.NavMeshAgent.Agent.velocity;
			val2 = val2.normalized;
			if (val2.magnitude > 0.1f)
			{
				val2 = Enemy.NavMeshAgent.Agent.velocity;
				Quaternion val3 = Quaternion.LookRotation(val2.normalized);
				LookAtTransform.LookAt(Enemy.TargetPlayerAvatar.PlayerVisionTarget.VisionTransform.position);
				LookAtTransform.rotation = Quaternion.Lerp(LookAtTransform.rotation, val3, 0.25f);
			}
			else
			{
				LookAtTransform.LookAt(Enemy.TargetPlayerAvatar.PlayerVisionTarget.VisionTransform.position);
			}
		}
		else if (Enemy.CurrentState == EnemyState.LookUnder)
		{
			LookAtTransform.LookAt(Enemy.StateChase.SawPlayerHidePosition);
			LookAtTransform.localEulerAngles = new Vector3(0f, LookAtTransform.localEulerAngles.y, 0f);
		}
		else
		{
			val2 = Enemy.NavMeshAgent.Agent.velocity;
			if (val2.magnitude > 0.1f)
			{
				Transform lookAtTransform = LookAtTransform;
				val2 = Enemy.NavMeshAgent.Agent.velocity;
				lookAtTransform.rotation = Quaternion.LookRotation(val2.normalized);
				LookAtTransform.localEulerAngles = new Vector3(0f, LookAtTransform.localEulerAngles.y, 0f);
			}
		}
		if (Enemy.CurrentState == EnemyState.Despawn)
		{
			Enemy.Rigidbody.DisableFollowPosition(0.1f, 1f);
			Enemy.Rigidbody.DisableFollowRotation(0.1f, 1f);
		}
	}

	public void VisionTriggered()
	{
		if (Enemy.DisableChaseTimer > 0f || Enemy.CurrentState == EnemyState.Chase || Enemy.CurrentState == EnemyState.LookUnder)
		{
			return;
		}
		if (Enemy.CurrentState == EnemyState.ChaseSlow)
		{
			Enemy.CurrentState = EnemyState.Chase;
		}
		else if (Enemy.Vision.onVisionTriggeredCulled && !Enemy.Vision.onVisionTriggeredNear)
		{
			if (Enemy.CurrentState != EnemyState.Sneak)
			{
				if (Random.Range(0f, 100f) <= 30f)
				{
					Enemy.CurrentState = EnemyState.ChaseBegin;
				}
				else
				{
					Enemy.CurrentState = EnemyState.Sneak;
				}
			}
		}
		else if (Enemy.Vision.onVisionTriggeredDistance >= 7f)
		{
			Enemy.CurrentState = EnemyState.Chase;
			Enemy.StateChase.ChaseCanReach = true;
		}
		else
		{
			Enemy.CurrentState = EnemyState.ChaseBegin;
		}
		Enemy.TargetPlayerViewID = Enemy.Vision.onVisionTriggeredPlayer.photonView.ViewID;
		Enemy.TargetPlayerAvatar = Enemy.Vision.onVisionTriggeredPlayer;
	}

	public void OnSpawn()
	{
		if (SemiFunc.IsMasterClientOrSingleplayer())
		{
			SemiFunc.EnemySpawn(Enemy);
		}
		Visual.Spawn();
		if (((Behaviour)AnimationSystem).isActiveAndEnabled)
		{
			AnimationSystem.OnSpawn();
		}
	}

	public void OnHurt()
	{
		//IL_001b: Unknown result type (might be due to invalid IL or missing references)
		AnimationSystem.Hurt.Play(((Component)Enemy.Rigidbody).transform.position);
	}

	public void OnDeath()
	{
		//IL_0067: Unknown result type (might be due to invalid IL or missing references)
		//IL_0095: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b0: Unknown result type (might be due to invalid IL or missing references)
		if (SemiFunc.IsMasterClientOrSingleplayer())
		{
			Enemy.CurrentState = EnemyState.Despawn;
		}
		foreach (GameObject deathParticle in DeathParticles)
		{
			deathParticle.SetActive(true);
		}
		GameDirector.instance.CameraShake.ShakeDistance(5f, 3f, 8f, ((Component)this).transform.position, 0.5f);
		GameDirector.instance.CameraImpact.ShakeDistance(5f, 3f, 8f, ((Component)this).transform.position, 0.1f);
		DeathSound.Play(((Component)this).transform.position);
		Enemy.EnemyParent.Despawn();
	}

	public void OnStunnedEnd()
	{
		Enemy.CurrentState = EnemyState.Roaming;
	}

	public void OnPhotonSerializeView(PhotonStream stream, PhotonMessageInfo info)
	{
		//IL_0000: Unknown result type (might be due to invalid IL or missing references)
		//IL_002f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0034: Unknown result type (might be due to invalid IL or missing references)
		//IL_0040: Unknown result type (might be due to invalid IL or missing references)
		//IL_0046: Unknown result type (might be due to invalid IL or missing references)
		//IL_0018: Unknown result type (might be due to invalid IL or missing references)
		if (SemiFunc.MasterOnlyRPC(info))
		{
			if (stream.IsWriting)
			{
				stream.SendNext((object)LookAtTransform.rotation);
				return;
			}
			RotationTarget = (Quaternion)stream.ReceiveNext();
			RotationDistance = Quaternion.Angle(((Component)this).transform.rotation, RotationTarget);
		}
	}
}
