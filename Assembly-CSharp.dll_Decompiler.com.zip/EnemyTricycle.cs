using System.Collections.Generic;
using Photon.Pun;
using UnityEngine;
using UnityEngine.AI;

public class EnemyTricycle : MonoBehaviour
{
	public enum State
	{
		Spawn,
		Idle,
		Roam,
		RoamAggro,
		Investigate,
		BellRing,
		BellRing2,
		BellRing3,
		StateBeforeAttack,
		AttackTell,
		AttackTellShort,
		Attack,
		AttackShort,
		AttackDive,
		AttackOutro,
		BackToNavmesh,
		Leave,
		Stun,
		TeleportOut,
		TeleportIn,
		Despawn
	}

	public State currentState;

	public float stateTimer;

	public float stateTimerMax;

	private bool stateStart;

	private float stateTicker;

	internal Enemy enemy;

	internal PhotonView photonView;

	public EnemyTricycleVisuals visuals;

	public Transform teleportTransform;

	public List<Transform> bikeRiderTransforms;

	private EnemyPitCheck enemyPitCheck;

	public Sound audioBell;

	public Sound audioBellGlobal;

	public Sound audioFinalBellBuildup;

	public Sound audioIdle;

	public Sound audioMove;

	public Sound audioAttack;

	public Sound audioAttackLoop;

	public Sound audioAttackOutro;

	public Sound audioDeath;

	public Sound audioDeathBikeCrash;

	public Sound audioWheelRattle;

	public Sound audioWheelSqueak;

	public Sound audioTeleportOut;

	public Sound audioTeleportIn;

	public Sound audioRiderGlitchIn;

	public Sound audioRiderGlitchOut;

	public Sound audioRiderStunnedLoop;

	public Sound[] audioIdleBreaker;

	public Sound audioTell;

	public Sound audioTellGlobal;

	public Sound audioHurt;

	public Sound audioHitPlayer;

	public AnimationCurve animationCurveTeleportOut;

	public AnimationCurve animationCurveTeleportIn;

	public ParticleSystem particlesDeath;

	public ParticleSystem particlesTeleportOut;

	public ParticleSystem particlesTeleportIn;

	public ParticleSystem particlesRiderGlitchIn;

	public ParticleSystem particlesRiderGlitchOut;

	public GameObject[] handMeshes;

	private bool handMeshesActive;

	public GameObject[] handMeshesAttached;

	private bool handMeshesAttachedActive = true;

	public GameObject[] footMeshes;

	private bool footMeshesActive;

	public GameObject[] footMeshesAttached;

	private bool footMeshesAttachedActive = true;

	public Transform hurtColliderTransform;

	private HurtCollider hurtCollider;

	public Transform followTargetTransform;

	private float followTargetRotationOverrideTimer;

	private Quaternion followTargetRotationOverride;

	internal PlayerAvatar playerTarget;

	private Vector3 agentDestination;

	private Vector3 agentDirection;

	private int bellRingCount;

	private float bellRingDelay;

	private float bellRingResetTimer;

	private bool bellHasRung;

	private int bellRingCurrentRing;

	private int bellRingMaxRings;

	private float bellRingSeparation;

	private Vector3 blockedPosition;

	private float blockedTimer;

	private bool shouldRetryDestination;

	private float closeToPlayerTime;

	private PlayerAvatar nearbyPlayer;

	public Rigidbody rb;

	private float lastSeenPlayerTimer;

	private float attackCooldown;

	private float attackTimer;

	private float attackTimerMax;

	private Vector3 backToNavmeshPosition;

	private Vector3 previousPosition;

	private Vector3 currentVelocity;

	private Quaternion previousRotation;

	private float currentAngularVelocity;

	private float previousSampleTime;

	private float flyingOverPitTimer;

	private bool isFlyingOverPit;

	private float flyingOverPitYPosition;

	private float smoothedSpeed;

	private bool rattlePlayingState;

	private bool squeakPlayingState;

	private float moveSoundCooldown;

	private float previousVelocityMagnitude;

	private float previousAngularVelocity;

	private float riderGlitchTimer;

	private float riderFlickerTimer;

	private float riderHideDelayTimer;

	private bool riderGlitchParticlesPlayed;

	private bool riderGlitchOutParticlesPlayed;

	private float riderGlitchOutHideDelay;

	private float riderGlitchInShowDelay;

	private float activateRiderStunnedVisualsTimer;

	private float activeStunnedVisualsCooldown;

	private float handsLetGoTimer;

	private float feetLetGoTimer;

	private float attackVisualsTimer;

	private float hitShakeTimer;

	private float idleBreakerTimer = -1f;

	private float idleBreakerTimerMax;

	private float idleBreakerActiveTimer;

	private int idleBreakerIndex;

	public List<AudioSource> talkingAudioSources;

	private float[] audioSourceSpectrum = new float[1024];

	public Transform jawTransform;

	private Quaternion jawStartRotation;

	private Quaternion jawTargetRotation;

	private SpringQuaternion jawSpring;

	private float talkVolume;

	private bool isBlockedByPlayer;

	private PlayerAvatar isBlockedByPlayerAvatar;

	private float isBlockedByPlayerCheckLast;

	private void Awake()
	{
		//IL_003c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0041: Unknown result type (might be due to invalid IL or missing references)
		//IL_004d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0052: Unknown result type (might be due to invalid IL or missing references)
		enemy = ((Component)this).GetComponent<Enemy>();
		photonView = ((Component)this).GetComponent<PhotonView>();
		enemyPitCheck = ((Component)this).GetComponent<EnemyPitCheck>();
		hurtCollider = ((Component)hurtColliderTransform).GetComponent<HurtCollider>();
		previousPosition = rb.position;
		previousRotation = rb.rotation;
		previousSampleTime = Time.time;
		InitializeJawAnimation();
	}

	private void Update()
	{
		if (hitShakeTimer > 0f)
		{
			hitShakeTimer = Mathf.Max(0f, hitShakeTimer - Time.deltaTime);
		}
		PitCheckLogic();
		UpdateVelocity();
		BlockedDetectionLogic();
		PlayLoopSoundLogic();
		SendVisualImpulses();
		UpdateRiderGlitch();
		UpdateFollowTargetRotation();
		CodeAnimatedTalk();
		audioRiderStunnedLoop.PlayLoop(activateRiderStunnedVisualsTimer > 0f, 5f, 5f);
		if (attackVisualsTimer <= 0f && ((Component)hurtColliderTransform).gameObject.activeSelf)
		{
			((Component)hurtColliderTransform).gameObject.SetActive(false);
		}
		if (attackVisualsTimer > 0f)
		{
			attackVisualsTimer -= Time.deltaTime;
			HandsLetGo();
			visuals.botSystemSpringPoseAnimator.SetPoseByName("attack");
			ActivateRiderGlitch();
			if (!((Component)hurtColliderTransform).gameObject.activeSelf)
			{
				((Component)hurtColliderTransform).gameObject.SetActive(true);
			}
		}
		if (idleBreakerActiveTimer > 0f)
		{
			idleBreakerActiveTimer -= Time.deltaTime;
			ActivateRiderGlitch();
			visuals.botSystemSpringPoseAnimator.SetPoseByName("idle breaker");
		}
		if (LevelGenerator.Instance.Generated)
		{
			if (stateTimer <= stateTimerMax)
			{
				stateTimer += Time.deltaTime;
			}
			UpdateTimers();
			UpdateBackToNavmeshPosition();
			UpdateAgentDirection();
			if (enemy.IsStunned())
			{
				SetState(State.Stun);
			}
			else if (enemy.CurrentState == EnemyState.Despawn && currentState != State.TeleportOut)
			{
				SetState(State.Despawn);
			}
			StateMachine();
		}
	}

	private void FixedUpdate()
	{
		if (currentState == State.Attack)
		{
			FixedUpdateAttack();
		}
		if (currentState == State.AttackShort)
		{
			FixedUpdateAttack();
		}
		if (currentState == State.AttackDive)
		{
			FixedUpdateAttackDive();
		}
	}

	private void StateMachine()
	{
		switch (currentState)
		{
		case State.Spawn:
			StateSpawn();
			break;
		case State.Idle:
			StateIdle();
			break;
		case State.Roam:
			StateRoam();
			break;
		case State.RoamAggro:
			StateRoamAggro();
			break;
		case State.Investigate:
			StateInvestigate();
			break;
		case State.BellRing:
			StateBellRing();
			break;
		case State.BellRing2:
			StateBellRing2();
			break;
		case State.BellRing3:
			StateBellRing3();
			break;
		case State.StateBeforeAttack:
			StateStateBeforeAttack();
			break;
		case State.AttackTell:
			StateAttackTell();
			break;
		case State.AttackTellShort:
			StateAttackTellShort();
			break;
		case State.Attack:
			StateAttack();
			break;
		case State.AttackShort:
			StateAttackShort();
			break;
		case State.AttackDive:
			StateAttackDive();
			break;
		case State.AttackOutro:
			StateAttackOutro();
			break;
		case State.BackToNavmesh:
			StateBackToNavmesh();
			break;
		case State.Leave:
			StateLeave();
			break;
		case State.Stun:
			StateStun();
			break;
		case State.TeleportOut:
			StateTeleportOut();
			break;
		case State.TeleportIn:
			StateTeleportIn();
			break;
		case State.Despawn:
			StateDespawn();
			break;
		}
	}

	private void StateSpawn()
	{
		//IL_0039: Unknown result type (might be due to invalid IL or missing references)
		//IL_005a: Unknown result type (might be due to invalid IL or missing references)
		if (stateStart)
		{
			stateTimerMax = 0.1f;
			stateTimer = 0f;
			enemy.NavMeshAgent.Warp(((Component)enemy.Rigidbody).transform.position);
			enemy.NavMeshAgent.ResetPath();
			teleportTransform.localScale = Vector3.zero;
			stateStart = false;
			bellRingCount = 0;
			bellRingResetTimer = 0f;
		}
		enemy.StateStunned.OverrideDisable(0.5f);
		if (stateTimer >= stateTimerMax)
		{
			SetState(State.TeleportIn);
		}
	}

	private void StateIdle()
	{
		//IL_0011: Unknown result type (might be due to invalid IL or missing references)
		//IL_0021: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_00bd: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c2: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c8: Unknown result type (might be due to invalid IL or missing references)
		//IL_00cc: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d2: Unknown result type (might be due to invalid IL or missing references)
		if (stateStart)
		{
			teleportTransform.localRotation = Quaternion.identity;
			teleportTransform.localScale = Vector3.one;
			if (SemiFunc.IsMasterClientOrSingleplayer())
			{
				stateTimerMax = Random.Range(4f, 8f);
			}
			stateTimer = 0f;
			enemy.NavMeshAgent.Warp(((Component)enemy.Rigidbody).transform.position);
			enemy.NavMeshAgent.ResetPath();
			stateStart = false;
		}
		CanDoIdleBreakers();
		if (SemiFunc.EnemySpawnIdlePause())
		{
			return;
		}
		if (stateTimer >= stateTimerMax && SemiFunc.IsMasterClientOrSingleplayer())
		{
			Vector3 position = enemy.CenterTransform.position;
			List<PlayerAvatar> list = SemiFunc.PlayerGetAllPlayerAvatarWithinRange(25f, position);
			if (list != null && list.Count > 0)
			{
				SetState(State.RoamAggro);
			}
			else
			{
				SetState(State.Roam);
			}
		}
		if (SemiFunc.IsMasterClientOrSingleplayer() && SemiFunc.EnemyForceLeave(enemy))
		{
			SetState(State.Leave);
		}
	}

	private void StateRoam()
	{
		//IL_00ad: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c7: Unknown result type (might be due to invalid IL or missing references)
		//IL_00cc: Unknown result type (might be due to invalid IL or missing references)
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_0034: Unknown result type (might be due to invalid IL or missing references)
		//IL_00eb: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f0: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f5: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ff: Unknown result type (might be due to invalid IL or missing references)
		//IL_010e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0119: Unknown result type (might be due to invalid IL or missing references)
		//IL_0156: Unknown result type (might be due to invalid IL or missing references)
		//IL_0166: Unknown result type (might be due to invalid IL or missing references)
		if (stateStart)
		{
			stateTimerMax = 999f;
			stateTimer = 0f;
			teleportTransform.localRotation = Quaternion.identity;
			teleportTransform.localScale = Vector3.one;
			if (SemiFunc.IsMasterClientOrSingleplayer() && !SemiFunc.EnemyRoamPoint(enemy, out agentDestination))
			{
				SetState(State.Idle);
				return;
			}
			enemy.Rigidbody.notMovingTimer = 0f;
			stateStart = false;
		}
		CanDoIdleBreakers();
		enemy.Rigidbody.OverrideFollowPosition(0.2f, 5f, 30f);
		enemy.NavMeshAgent.SetDestination(agentDestination);
		Vector3 normalized = enemy.NavMeshAgent.AgentVelocity.normalized;
		if (normalized.magnitude > 0.1f)
		{
			Quaternion targetRotation = Quaternion.LookRotation(enemy.NavMeshAgent.AgentVelocity.normalized);
			targetRotation.eulerAngles = new Vector3(0f, targetRotation.eulerAngles.y, 0f);
			FollowTargetRotateTowards(targetRotation, 180f);
		}
		if (!SemiFunc.IsMasterClientOrSingleplayer())
		{
			return;
		}
		if (enemy.Rigidbody.notMovingTimer > 5f)
		{
			SetState(State.Despawn);
			return;
		}
		if (Vector3.Distance(enemy.CenterTransform.position, enemy.NavMeshAgent.GetPoint()) < 1f)
		{
			SetState(State.Idle);
		}
		else if (HandleBlocked() || StuckCheck())
		{
			return;
		}
		if (SemiFunc.EnemyForceLeave(enemy))
		{
			SetState(State.Leave);
		}
	}

	private void StateRoamAggro()
	{
		//IL_0237: Unknown result type (might be due to invalid IL or missing references)
		//IL_0251: Unknown result type (might be due to invalid IL or missing references)
		//IL_0256: Unknown result type (might be due to invalid IL or missing references)
		//IL_0027: Unknown result type (might be due to invalid IL or missing references)
		//IL_0037: Unknown result type (might be due to invalid IL or missing references)
		//IL_0276: Unknown result type (might be due to invalid IL or missing references)
		//IL_027b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0280: Unknown result type (might be due to invalid IL or missing references)
		//IL_028b: Unknown result type (might be due to invalid IL or missing references)
		//IL_029a: Unknown result type (might be due to invalid IL or missing references)
		//IL_02a5: Unknown result type (might be due to invalid IL or missing references)
		//IL_0061: Unknown result type (might be due to invalid IL or missing references)
		//IL_0066: Unknown result type (might be due to invalid IL or missing references)
		//IL_006e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0072: Unknown result type (might be due to invalid IL or missing references)
		//IL_0078: Unknown result type (might be due to invalid IL or missing references)
		//IL_02e3: Unknown result type (might be due to invalid IL or missing references)
		//IL_02f3: Unknown result type (might be due to invalid IL or missing references)
		//IL_009a: Unknown result type (might be due to invalid IL or missing references)
		//IL_009f: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00bb: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c0: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c5: Unknown result type (might be due to invalid IL or missing references)
		//IL_00df: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e7: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ec: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ed: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ee: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ef: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f4: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f8: Unknown result type (might be due to invalid IL or missing references)
		//IL_00fd: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ff: Unknown result type (might be due to invalid IL or missing references)
		//IL_0140: Unknown result type (might be due to invalid IL or missing references)
		//IL_0145: Unknown result type (might be due to invalid IL or missing references)
		//IL_0159: Unknown result type (might be due to invalid IL or missing references)
		//IL_015e: Unknown result type (might be due to invalid IL or missing references)
		//IL_015f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0164: Unknown result type (might be due to invalid IL or missing references)
		//IL_0168: Unknown result type (might be due to invalid IL or missing references)
		//IL_016d: Unknown result type (might be due to invalid IL or missing references)
		//IL_016f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0171: Unknown result type (might be due to invalid IL or missing references)
		//IL_01c5: Unknown result type (might be due to invalid IL or missing references)
		//IL_01ca: Unknown result type (might be due to invalid IL or missing references)
		Vector3 val2;
		if (stateStart)
		{
			stateTimerMax = 999f;
			stateTimer = 0f;
			teleportTransform.localRotation = Quaternion.identity;
			teleportTransform.localScale = Vector3.one;
			if (SemiFunc.IsMasterClientOrSingleplayer())
			{
				if (!shouldRetryDestination)
				{
					Vector3 position = enemy.CenterTransform.position;
					bool flag = false;
					List<PlayerAvatar> list = SemiFunc.PlayerGetAllPlayerAvatarWithinRange(25f, position);
					if (list == null || list.Count == 0)
					{
						stateStart = false;
						SetState(State.Roam);
						return;
					}
					Vector3 val = Vector3.zero;
					foreach (PlayerAvatar item in list)
					{
						val += ((Component)item).transform.position;
					}
					val /= (float)list.Count;
					val2 = val - position;
					Vector3 normalized = val2.normalized;
					List<LevelPoint> list2 = SemiFunc.LevelPointGetWithinDistance(val, 0f, 25f);
					if (list2.Count > 0)
					{
						List<LevelPoint> list3 = new List<LevelPoint>();
						foreach (LevelPoint item2 in list2)
						{
							if (!(Vector3.Distance(((Component)item2).transform.position, val) > 15f))
							{
								val2 = ((Component)item2).transform.position - position;
								Vector3 normalized2 = val2.normalized;
								if (Vector3.Dot(normalized, normalized2) > 0.3f)
								{
									list3.Add(item2);
								}
							}
						}
						if (list3.Count > 0)
						{
							agentDestination = ((Component)list3[Random.Range(0, list3.Count)]).transform.position;
							flag = true;
						}
					}
					if (!flag)
					{
						stateStart = false;
						SetState(State.Roam);
						return;
					}
				}
				shouldRetryDestination = false;
			}
			enemy.Rigidbody.notMovingTimer = 0f;
			stateStart = false;
		}
		CanDoIdleBreakers();
		enemy.Rigidbody.OverrideFollowPosition(0.2f, 5f, 30f);
		enemy.NavMeshAgent.SetDestination(agentDestination);
		val2 = enemy.NavMeshAgent.AgentVelocity.normalized;
		if (val2.magnitude > 0.1f)
		{
			Quaternion targetRotation = Quaternion.LookRotation(enemy.NavMeshAgent.AgentVelocity.normalized);
			targetRotation.eulerAngles = new Vector3(0f, targetRotation.eulerAngles.y, 0f);
			FollowTargetRotateTowards(targetRotation, 180f);
		}
		if (SemiFunc.IsMasterClientOrSingleplayer())
		{
			if (enemy.Rigidbody.notMovingTimer > 5f)
			{
				SetState(State.Despawn);
			}
			else if (Vector3.Distance(enemy.CenterTransform.position, enemy.NavMeshAgent.GetPoint()) < 1f)
			{
				SetState(State.Idle);
			}
			else if (!HandleBlocked())
			{
				StuckCheck();
			}
		}
	}

	private void StateInvestigate()
	{
		//IL_0085: Unknown result type (might be due to invalid IL or missing references)
		//IL_009f: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a4: Unknown result type (might be due to invalid IL or missing references)
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_0034: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c8: Unknown result type (might be due to invalid IL or missing references)
		//IL_00cd: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d7: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e6: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f1: Unknown result type (might be due to invalid IL or missing references)
		//IL_0136: Unknown result type (might be due to invalid IL or missing references)
		//IL_0146: Unknown result type (might be due to invalid IL or missing references)
		//IL_0167: Unknown result type (might be due to invalid IL or missing references)
		//IL_016d: Unknown result type (might be due to invalid IL or missing references)
		if (stateStart)
		{
			stateTimerMax = 999f;
			stateTimer = 0f;
			teleportTransform.localRotation = Quaternion.identity;
			teleportTransform.localScale = Vector3.one;
			enemy.Rigidbody.notMovingTimer = 0f;
			stateStart = false;
		}
		enemy.Rigidbody.OverrideFollowPosition(0.2f, 5f, 30f);
		enemy.NavMeshAgent.SetDestination(agentDestination);
		Vector3 normalized = enemy.NavMeshAgent.AgentVelocity.normalized;
		if (normalized.magnitude > 0.1f)
		{
			Quaternion targetRotation = Quaternion.LookRotation(enemy.NavMeshAgent.AgentVelocity.normalized);
			targetRotation.eulerAngles = new Vector3(0f, targetRotation.eulerAngles.y, 0f);
			FollowTargetRotateTowards(targetRotation, 180f);
		}
		if (!SemiFunc.IsMasterClientOrSingleplayer())
		{
			return;
		}
		if (enemy.Rigidbody.notMovingTimer > 5f)
		{
			SetState(State.Despawn);
			return;
		}
		if (Vector3.Distance(((Component)enemy.Rigidbody).transform.position, enemy.NavMeshAgent.GetPoint()) < 1f || Vector3.Distance(((Component)enemy.Rigidbody).transform.position, agentDestination) < 1f)
		{
			FindNextWaypointFromInvestigation();
		}
		else if (HandleBlocked() || StuckCheck())
		{
			return;
		}
		if (SemiFunc.EnemyForceLeave(enemy))
		{
			SetState(State.Leave);
		}
	}

	private void StateBellRing()
	{
		//IL_00af: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b4: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b9: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d2: Unknown result type (might be due to invalid IL or missing references)
		//IL_00dd: Unknown result type (might be due to invalid IL or missing references)
		//IL_0035: Unknown result type (might be due to invalid IL or missing references)
		//IL_0045: Unknown result type (might be due to invalid IL or missing references)
		//IL_006a: Unknown result type (might be due to invalid IL or missing references)
		if (stateStart)
		{
			bellRingCount++;
			stateTimerMax = 2.5f;
			stateTimer = 0f;
			teleportTransform.localRotation = Quaternion.identity;
			teleportTransform.localScale = Vector3.one;
			enemy.NavMeshAgent.Warp(((Component)enemy.Rigidbody).transform.position);
			enemy.NavMeshAgent.ResetPath();
			bellRingDelay = Random.Range(0.8f, 1.5f);
			bellHasRung = false;
			stateStart = false;
		}
		CanDoIdleBreakers();
		Quaternion targetRotation = Quaternion.LookRotation(agentDirection);
		targetRotation.eulerAngles = new Vector3(0f, targetRotation.eulerAngles.y, 0f);
		FollowTargetRotateTowards(targetRotation, 180f);
		if (stateTimer >= bellRingDelay && !bellHasRung)
		{
			DoBellRing();
			bellHasRung = true;
		}
		if (stateTimer >= stateTimerMax)
		{
			if (IsPlayerBlockingNavmeshPath())
			{
				SetState(State.BellRing2);
				return;
			}
			shouldRetryDestination = true;
			SetState(State.Roam);
		}
	}

	private void StateBellRing2()
	{
		//IL_00d8: Unknown result type (might be due to invalid IL or missing references)
		//IL_00dd: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e2: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ec: Unknown result type (might be due to invalid IL or missing references)
		//IL_00fb: Unknown result type (might be due to invalid IL or missing references)
		//IL_0106: Unknown result type (might be due to invalid IL or missing references)
		//IL_0080: Unknown result type (might be due to invalid IL or missing references)
		//IL_0090: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b5: Unknown result type (might be due to invalid IL or missing references)
		if (stateStart)
		{
			bellRingCount++;
			bellRingMaxRings = 2;
			bellRingSeparation = 0.25f;
			bellRingCurrentRing = 0;
			bellRingDelay = Random.Range(0.8f, 1.5f);
			bellHasRung = false;
			stateTimerMax = bellRingDelay + (float)bellRingMaxRings * bellRingSeparation + 0.5f;
			stateTimer = 0f;
			teleportTransform.localRotation = Quaternion.identity;
			teleportTransform.localScale = Vector3.one;
			enemy.NavMeshAgent.Warp(((Component)enemy.Rigidbody).transform.position);
			enemy.NavMeshAgent.ResetPath();
			stateStart = false;
		}
		Quaternion targetRotation = Quaternion.LookRotation(agentDirection);
		targetRotation.eulerAngles = new Vector3(0f, targetRotation.eulerAngles.y, 0f);
		FollowTargetRotateTowards(targetRotation, 180f);
		CanDoIdleBreakers();
		if (stateTimer >= bellRingDelay && bellRingCurrentRing < bellRingMaxRings)
		{
			float num = bellRingDelay + (float)bellRingCurrentRing * bellRingSeparation;
			if (stateTimer >= num && !bellHasRung)
			{
				DoBellRing();
				bellRingCurrentRing++;
				bellHasRung = true;
			}
			if (bellHasRung && stateTimer >= num + 0.05f)
			{
				bellHasRung = false;
			}
		}
		if (stateTimer >= stateTimerMax)
		{
			if (IsPlayerBlockingNavmeshPath())
			{
				SetState(State.BellRing3);
				return;
			}
			shouldRetryDestination = true;
			SetState(State.Roam);
		}
	}

	private void StateBellRing3()
	{
		//IL_0109: Unknown result type (might be due to invalid IL or missing references)
		//IL_010e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0113: Unknown result type (might be due to invalid IL or missing references)
		//IL_011d: Unknown result type (might be due to invalid IL or missing references)
		//IL_012c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0137: Unknown result type (might be due to invalid IL or missing references)
		//IL_0080: Unknown result type (might be due to invalid IL or missing references)
		//IL_0090: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b5: Unknown result type (might be due to invalid IL or missing references)
		if (stateStart)
		{
			bellRingCount++;
			bellRingMaxRings = 3;
			bellRingSeparation = 0.2f;
			bellRingCurrentRing = 0;
			bellRingDelay = Random.Range(0.8f, 1.5f);
			bellHasRung = false;
			stateTimerMax = bellRingDelay + (float)bellRingMaxRings * bellRingSeparation + 1f;
			stateTimer = 0f;
			teleportTransform.localRotation = Quaternion.identity;
			teleportTransform.localScale = Vector3.one;
			enemy.NavMeshAgent.Warp(((Component)enemy.Rigidbody).transform.position);
			enemy.NavMeshAgent.ResetPath();
			audioFinalBellBuildup.Play(enemy.CenterTransform);
			stateStart = false;
		}
		CanDoIdleBreakers();
		Quaternion targetRotation = Quaternion.LookRotation(agentDirection);
		targetRotation.eulerAngles = new Vector3(0f, targetRotation.eulerAngles.y, 0f);
		FollowTargetRotateTowards(targetRotation, 180f);
		if (stateTimer >= bellRingDelay)
		{
			float num = bellRingDelay + (float)bellRingCurrentRing * bellRingSeparation;
			if (stateTimer >= num && !bellHasRung)
			{
				DoBellRing();
				bellRingCurrentRing++;
				bellHasRung = true;
			}
			if (bellHasRung && stateTimer >= num + 0.05f)
			{
				bellHasRung = false;
			}
		}
		if (stateTimer >= stateTimerMax)
		{
			if (SemiFunc.IsMasterClientOrSingleplayer())
			{
				bellRingCount = 0;
				bellRingResetTimer = 0f;
			}
			SetState(State.StateBeforeAttack);
		}
	}

	private void StateStateBeforeAttack()
	{
		//IL_0032: Unknown result type (might be due to invalid IL or missing references)
		//IL_0042: Unknown result type (might be due to invalid IL or missing references)
		//IL_0067: Unknown result type (might be due to invalid IL or missing references)
		//IL_012b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0144: Unknown result type (might be due to invalid IL or missing references)
		//IL_00bb: Unknown result type (might be due to invalid IL or missing references)
		//IL_00cb: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d0: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d5: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e1: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e6: Unknown result type (might be due to invalid IL or missing references)
		if (stateStart)
		{
			attackTimer = 0f;
			stateTimerMax = 0f;
			stateTimer = 0f;
			teleportTransform.localRotation = Quaternion.identity;
			teleportTransform.localScale = Vector3.one;
			enemy.NavMeshAgent.Warp(((Component)enemy.Rigidbody).transform.position);
			enemy.NavMeshAgent.ResetPath();
			IdleBreakerStop();
			stateStart = false;
			bool flag = true;
			if (Object.op_Implicit((Object)(object)isBlockedByPlayerAvatar) && !isBlockedByPlayerAvatar.isDisabled)
			{
				Vector3 val = isBlockedByPlayerAvatar.PlayerVisionTarget.VisionTransform.position - enemy.CenterTransform.position;
				if (!Physics.Raycast(enemy.CenterTransform.position, val, val.magnitude, LayerMask.GetMask(new string[1] { "Default" }), (QueryTriggerInteraction)1))
				{
					playerTarget = isBlockedByPlayerAvatar;
					flag = false;
				}
			}
			if (flag)
			{
				playerTarget = SemiFunc.PlayerGetNearestPlayerAvatarWithinRange(10f, enemy.CenterTransform.position, doRaycastCheck: true, LayerMask.op_Implicit(LayerMask.GetMask(new string[1] { "Default" })));
			}
		}
		if (Object.op_Implicit((Object)(object)playerTarget) && !playerTarget.isDisabled)
		{
			lastSeenPlayerTimer = 10f;
			attackTimer = 0f;
			attackTimerMax = 5f;
			SetState(State.AttackTell);
		}
		else if (lastSeenPlayerTimer <= 0f)
		{
			attackTimer = 0f;
			attackTimerMax = Random.Range(1f, 2f);
			SetState(State.AttackTellShort);
		}
		else
		{
			SetState(State.AttackTell);
		}
	}

	private void StateAttackTell()
	{
		//IL_0027: Unknown result type (might be due to invalid IL or missing references)
		//IL_0037: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b2: Unknown result type (might be due to invalid IL or missing references)
		if (stateStart)
		{
			stateTimerMax = 0.5f;
			stateTimer = 0f;
			teleportTransform.localRotation = Quaternion.identity;
			teleportTransform.localScale = Vector3.one;
			audioTell.Play(enemy.CenterTransform);
			audioTellGlobal.Play(enemy.CenterTransform);
			enemy.NavMeshAgent.Warp(((Component)enemy.Rigidbody).transform.position);
			enemy.NavMeshAgent.ResetPath();
			stateStart = false;
		}
		ActivateAttackVisuals();
		HandsLetGo();
		RotationFollowTargetOrVelocity();
		if (stateTimer >= stateTimerMax)
		{
			SetState(State.Attack);
		}
	}

	private void StateAttackTellShort()
	{
		//IL_0027: Unknown result type (might be due to invalid IL or missing references)
		//IL_0037: Unknown result type (might be due to invalid IL or missing references)
		//IL_0087: Unknown result type (might be due to invalid IL or missing references)
		if (stateStart)
		{
			stateTimerMax = 0.5f;
			stateTimer = 0f;
			teleportTransform.localRotation = Quaternion.identity;
			teleportTransform.localScale = Vector3.one;
			audioAttack.Play(enemy.CenterTransform);
			enemy.NavMeshAgent.Warp(((Component)enemy.Rigidbody).transform.position);
			enemy.NavMeshAgent.ResetPath();
			stateStart = false;
		}
		ActivateAttackVisuals();
		HandsLetGo();
		RotationFollowTargetOrVelocity();
		if (stateTimer >= stateTimerMax)
		{
			SetState(State.AttackShort);
		}
	}

	private void StateAttack()
	{
		//IL_0031: Unknown result type (might be due to invalid IL or missing references)
		//IL_0041: Unknown result type (might be due to invalid IL or missing references)
		//IL_0066: Unknown result type (might be due to invalid IL or missing references)
		//IL_018e: Unknown result type (might be due to invalid IL or missing references)
		//IL_019e: Unknown result type (might be due to invalid IL or missing references)
		//IL_01a9: Unknown result type (might be due to invalid IL or missing references)
		//IL_01ae: Unknown result type (might be due to invalid IL or missing references)
		//IL_01b3: Unknown result type (might be due to invalid IL or missing references)
		//IL_01b6: Unknown result type (might be due to invalid IL or missing references)
		if (stateStart)
		{
			stateTimerMax = Random.Range(0.5f, 2f);
			stateTimer = 0f;
			teleportTransform.localRotation = Quaternion.identity;
			teleportTransform.localScale = Vector3.one;
			enemy.NavMeshAgent.Warp(((Component)enemy.Rigidbody).transform.position);
			enemy.NavMeshAgent.ResetPath();
			audioAttack.Play(enemy.CenterTransform);
			visuals.ImpulseAttackImpact();
			stateStart = false;
		}
		RotationFollowTargetOrVelocity();
		attackTimer += Time.deltaTime;
		enemy.OverrideType(EnemyType.Heavy, 0.2f);
		ActivateAttackVisuals();
		HandsLetGo();
		enemy.Rigidbody.DeactivateCustomGravity(0.2f);
		enemy.Rigidbody.physGrabObject.OverrideZeroGravity(0.2f);
		visuals.ImpulseBodyShake(2f, 15f);
		visuals.ImpulseWheelShake(1.5f, 18f);
		if (attackTimer >= attackTimerMax)
		{
			SetState(State.AttackOutro);
		}
		else if (stateTimer >= stateTimerMax && Object.op_Implicit((Object)(object)playerTarget))
		{
			Vector3 forward = ((Component)enemy.Rigidbody).transform.forward;
			Vector3 val = ((Component)playerTarget).transform.position - rb.position;
			if (Vector3.Dot(forward, val.normalized) > 0.5f)
			{
				SetState(State.AttackDive);
			}
		}
	}

	private void StateAttackShort()
	{
		//IL_0027: Unknown result type (might be due to invalid IL or missing references)
		//IL_0037: Unknown result type (might be due to invalid IL or missing references)
		//IL_005c: Unknown result type (might be due to invalid IL or missing references)
		if (stateStart)
		{
			stateTimerMax = 3f;
			stateTimer = 0f;
			teleportTransform.localRotation = Quaternion.identity;
			teleportTransform.localScale = Vector3.one;
			enemy.NavMeshAgent.Warp(((Component)enemy.Rigidbody).transform.position);
			enemy.NavMeshAgent.ResetPath();
			audioAttack.Play(enemy.CenterTransform);
			visuals.ImpulseAttackImpact();
			stateStart = false;
		}
		enemy.OverrideType(EnemyType.Heavy, 0.2f);
		ActivateAttackVisuals();
		HandsLetGo();
		RotationFollowTargetOrVelocity();
		enemy.Rigidbody.DeactivateCustomGravity(0.2f);
		enemy.Rigidbody.physGrabObject.OverrideZeroGravity(0.2f);
		visuals.ImpulseBodyShake(2f, 15f);
		visuals.ImpulseWheelShake(1.5f, 18f);
		if (stateTimer >= stateTimerMax)
		{
			SetState(State.AttackOutro);
		}
	}

	private void StateAttackDive()
	{
		//IL_0031: Unknown result type (might be due to invalid IL or missing references)
		//IL_0041: Unknown result type (might be due to invalid IL or missing references)
		//IL_00db: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f4: Unknown result type (might be due to invalid IL or missing references)
		//IL_0077: Unknown result type (might be due to invalid IL or missing references)
		//IL_0087: Unknown result type (might be due to invalid IL or missing references)
		//IL_008c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0091: Unknown result type (might be due to invalid IL or missing references)
		//IL_009d: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a2: Unknown result type (might be due to invalid IL or missing references)
		//IL_024d: Unknown result type (might be due to invalid IL or missing references)
		//IL_025d: Unknown result type (might be due to invalid IL or missing references)
		//IL_016c: Unknown result type (might be due to invalid IL or missing references)
		if (stateStart)
		{
			stateTimerMax = Random.Range(1f, 3f);
			stateTimer = 0f;
			teleportTransform.localRotation = Quaternion.identity;
			teleportTransform.localScale = Vector3.one;
			bool flag = true;
			if (Object.op_Implicit((Object)(object)playerTarget) && !playerTarget.isDisabled)
			{
				Vector3 val = playerTarget.PlayerVisionTarget.VisionTransform.position - enemy.CenterTransform.position;
				if (!Physics.Raycast(enemy.CenterTransform.position, val, val.magnitude, LayerMask.GetMask(new string[1] { "Default" }), (QueryTriggerInteraction)1))
				{
					flag = false;
				}
			}
			if (flag)
			{
				playerTarget = SemiFunc.PlayerGetNearestPlayerAvatarWithinRange(10f, enemy.CenterTransform.position, doRaycastCheck: true, LayerMask.op_Implicit(LayerMask.GetMask(new string[1] { "Default" })));
			}
			if (!Object.op_Implicit((Object)(object)playerTarget) || playerTarget.isDisabled)
			{
				SetState(State.Attack);
				return;
			}
			audioAttack.Play(enemy.CenterTransform);
			enemy.NavMeshAgent.Warp(((Component)enemy.Rigidbody).transform.position);
			enemy.NavMeshAgent.ResetPath();
			stateStart = false;
		}
		RotationFollowTargetOrVelocity();
		attackTimer += Time.deltaTime;
		ActivateAttackVisuals();
		HandsLetGo();
		enemy.OverrideType(EnemyType.Heavy, 0.2f);
		enemy.Rigidbody.DeactivateCustomGravity(0.2f);
		enemy.Rigidbody.physGrabObject.OverrideZeroGravity(0.2f);
		visuals.ImpulseBodyShake(2f, 15f);
		visuals.ImpulseWheelShake(1.5f, 18f);
		if (SemiFunc.IsMasterClientOrSingleplayer())
		{
			if (!Object.op_Implicit((Object)(object)playerTarget) || playerTarget.isDisabled)
			{
				SetState(State.Attack);
			}
			else if (Vector3.Distance(rb.position, ((Component)playerTarget).transform.position) < 2f || stateTimer >= stateTimerMax)
			{
				stateTimerMax = Random.Range(0.5f, 2f);
				stateTimer = 0f;
				SetState(State.Attack);
			}
		}
	}

	private void FixedUpdateAttackDive()
	{
		//IL_002e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0039: Unknown result type (might be due to invalid IL or missing references)
		//IL_003e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0043: Unknown result type (might be due to invalid IL or missing references)
		//IL_0046: Unknown result type (might be due to invalid IL or missing references)
		//IL_0050: Unknown result type (might be due to invalid IL or missing references)
		//IL_0055: Unknown result type (might be due to invalid IL or missing references)
		//IL_005c: Unknown result type (might be due to invalid IL or missing references)
		if (SemiFunc.IsMasterClientOrSingleplayer() && Object.op_Implicit((Object)(object)playerTarget) && !playerTarget.isDisabled)
		{
			Vector3 val = ((Component)playerTarget).transform.position - rb.position;
			Vector3 val2 = val.normalized * 50f;
			rb.AddForce(val2, (ForceMode)1);
		}
	}

	private void FixedUpdateAttack()
	{
		//IL_013b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0140: Unknown result type (might be due to invalid IL or missing references)
		//IL_0149: Unknown result type (might be due to invalid IL or missing references)
		//IL_014e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0150: Unknown result type (might be due to invalid IL or missing references)
		//IL_015a: Unknown result type (might be due to invalid IL or missing references)
		//IL_015f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0167: Unknown result type (might be due to invalid IL or missing references)
		//IL_0033: Unknown result type (might be due to invalid IL or missing references)
		//IL_003e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0043: Unknown result type (might be due to invalid IL or missing references)
		//IL_0048: Unknown result type (might be due to invalid IL or missing references)
		//IL_004b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0099: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a8: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a9: Unknown result type (might be due to invalid IL or missing references)
		//IL_00aa: Unknown result type (might be due to invalid IL or missing references)
		//IL_00af: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b2: Unknown result type (might be due to invalid IL or missing references)
		//IL_00bc: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c1: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c8: Unknown result type (might be due to invalid IL or missing references)
		if (SemiFunc.IsMasterClientOrSingleplayer())
		{
			if (Object.op_Implicit((Object)(object)playerTarget) && !playerTarget.isDisabled)
			{
				Vector3 val = ((Component)playerTarget).transform.position - rb.position;
				Vector3 normalized = val.normalized;
				float num = Mathf.PerlinNoise(Time.time * 1.5f, 0f) * 2f - 1f;
				float num2 = Mathf.PerlinNoise(0f, Time.time * 1.5f) * 2f - 1f;
				Vector3 val2 = new Vector3(num, 0f, num2) * 0.2f;
				val = normalized + val2;
				Vector3 val3 = val.normalized * 300f;
				rb.AddForce(val3, (ForceMode)0);
			}
			else
			{
				float num3 = Mathf.PerlinNoise(Time.time * 1.5f, 0f) * 2f - 1f;
				float num4 = Mathf.PerlinNoise(0f, Time.time * 1.5f) * 2f - 1f;
				float num5 = 45f;
				float num6 = num3 * num5;
				float num7 = num4 * num5;
				float num8 = num6 * 0.4f;
				float num9 = num7 * 0.4f;
				Vector3 forward = followTargetTransform.forward;
				Vector3 val4 = Quaternion.Euler(num8, num9, 0f) * forward * 300f;
				rb.AddForce(val4, (ForceMode)0);
			}
		}
	}

	private void StateAttackOutro()
	{
		//IL_0047: Unknown result type (might be due to invalid IL or missing references)
		if (stateStart)
		{
			stateTimerMax = 1f;
			stateTimer = 0f;
			attackTimer = 0f;
			enemy.NavMeshAgent.Warp(((Component)enemy.Rigidbody).transform.position);
			enemy.NavMeshAgent.ResetPath();
			audioAttackOutro.Play(enemy.CenterTransform);
			stateStart = false;
		}
		HandsLetGo();
		if (stateTimer >= stateTimerMax)
		{
			attackCooldown = 5f;
			SetState(State.BackToNavmesh);
		}
	}

	private void StateBackToNavmesh()
	{
		//IL_005c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0071: Unknown result type (might be due to invalid IL or missing references)
		//IL_0076: Unknown result type (might be due to invalid IL or missing references)
		//IL_007b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0039: Unknown result type (might be due to invalid IL or missing references)
		//IL_008a: Unknown result type (might be due to invalid IL or missing references)
		//IL_008b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0090: Unknown result type (might be due to invalid IL or missing references)
		//IL_009a: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a9: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b4: Unknown result type (might be due to invalid IL or missing references)
		//IL_0109: Unknown result type (might be due to invalid IL or missing references)
		//IL_010f: Unknown result type (might be due to invalid IL or missing references)
		//IL_011f: Unknown result type (might be due to invalid IL or missing references)
		//IL_012f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0144: Unknown result type (might be due to invalid IL or missing references)
		//IL_016b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0192: Unknown result type (might be due to invalid IL or missing references)
		if (stateStart)
		{
			stateTimerMax = 3f;
			stateTimer = 0f;
			enemy.NavMeshAgent.Warp(((Component)enemy.Rigidbody).transform.position);
			enemy.NavMeshAgent.ResetPath();
			stateStart = false;
		}
		Vector3 val = backToNavmeshPosition - ((Component)enemy.Rigidbody).transform.position;
		if (val.magnitude > 0.1f)
		{
			Quaternion targetRotation = Quaternion.LookRotation(val);
			targetRotation.eulerAngles = new Vector3(0f, targetRotation.eulerAngles.y, 0f);
			FollowTargetRotateTowards(targetRotation, 180f);
		}
		if (SemiFunc.IsMasterClientOrSingleplayer())
		{
			enemy.NavMeshAgent.Disable(0.1f);
			enemy.Rigidbody.OverrideFollowPosition(0.2f, 5f, 30f);
			((Component)this).transform.position = Vector3.MoveTowards(((Component)this).transform.position, backToNavmeshPosition, 3f * Time.deltaTime);
			if (Vector3.Distance(((Component)this).transform.position, ((Component)enemy.Rigidbody).transform.position) > 2f)
			{
				((Component)this).transform.position = ((Component)enemy.Rigidbody).transform.position;
			}
			NavMeshHit val2 = default;
			if (SemiFunc.PerSecond(15f, (Object)(object)this) && NavMesh.SamplePosition(((Component)enemy.Rigidbody).transform.position, ref val2, 0.5f, -1))
			{
				SetState(State.Idle);
			}
			else if (enemy.Rigidbody.notMovingTimer > 3f && stateTimer >= stateTimerMax)
			{
				SetState(State.Despawn);
			}
		}
	}

	public void StateLeave()
	{
		//IL_009d: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b7: Unknown result type (might be due to invalid IL or missing references)
		//IL_00bc: Unknown result type (might be due to invalid IL or missing references)
		//IL_0124: Unknown result type (might be due to invalid IL or missing references)
		//IL_0134: Unknown result type (might be due to invalid IL or missing references)
		//IL_00db: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e0: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e5: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ef: Unknown result type (might be due to invalid IL or missing references)
		//IL_00fe: Unknown result type (might be due to invalid IL or missing references)
		//IL_0109: Unknown result type (might be due to invalid IL or missing references)
		//IL_0155: Unknown result type (might be due to invalid IL or missing references)
		//IL_015b: Unknown result type (might be due to invalid IL or missing references)
		if (stateStart)
		{
			stateTimerMax = 999f;
			stateTimer = 0f;
			if (!SemiFunc.EnemyLeavePoint(enemy, out agentDestination))
			{
				SetState(State.Roam);
				return;
			}
			SemiFunc.EnemyLeaveStart(enemy);
			enemy.Rigidbody.notMovingTimer = 0f;
			bellRingCount = 0;
			bellRingResetTimer = 0f;
			stateStart = false;
		}
		enemy.Rigidbody.OverrideFollowPosition(0.2f, 5f, 30f);
		enemy.NavMeshAgent.SetDestination(agentDestination);
		Vector3 normalized = enemy.NavMeshAgent.AgentVelocity.normalized;
		if (normalized.magnitude > 0.1f)
		{
			Quaternion targetRotation = Quaternion.LookRotation(enemy.NavMeshAgent.AgentVelocity.normalized);
			targetRotation.eulerAngles = new Vector3(0f, targetRotation.eulerAngles.y, 0f);
			FollowTargetRotateTowards(targetRotation, 180f);
		}
		if (Vector3.Distance(((Component)enemy.Rigidbody).transform.position, enemy.NavMeshAgent.GetPoint()) <= 1f || Vector3.Distance(((Component)enemy.Rigidbody).transform.position, agentDestination) <= 1f)
		{
			SetState(State.Idle);
		}
	}

	private void StateStun()
	{
		//IL_0039: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c7: Unknown result type (might be due to invalid IL or missing references)
		//IL_00cd: Unknown result type (might be due to invalid IL or missing references)
		if (stateStart)
		{
			stateTimerMax = 0f;
			stateTimer = 0f;
			enemy.NavMeshAgent.Warp(((Component)enemy.Rigidbody).transform.position);
			enemy.NavMeshAgent.ResetPath();
			IdleBreakerStop();
			stateStart = false;
		}
		if (SemiFunc.IsMasterClientOrSingleplayer() && activeStunnedVisualsCooldown <= 0f)
		{
			float num = Random.Range(0.35f, 2f);
			activeStunnedVisualsCooldown = Random.Range(0.2f, 8f);
			if (SemiFunc.IsMultiplayer())
			{
				photonView.RPC("ActivateRiderStunnedVisualsRPC", (RpcTarget)0, new object[1] { num });
			}
			else
			{
				ActivateRiderStunnedVisualsRPC(num);
			}
		}
		if (!enemy.IsStunned())
		{
			SetState(State.BackToNavmesh);
		}
	}

	private void StateTeleportOut()
	{
		//IL_00de: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e4: Unknown result type (might be due to invalid IL or missing references)
		//IL_010b: Unknown result type (might be due to invalid IL or missing references)
		//IL_003c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0129: Unknown result type (might be due to invalid IL or missing references)
		//IL_0139: Unknown result type (might be due to invalid IL or missing references)
		if (stateStart)
		{
			stateTimerMax = 1f;
			stateTimer = 0f;
			enemy.NavMeshAgent.Warp(((Component)enemy.Rigidbody).transform.position);
			enemy.NavMeshAgent.ResetPath();
			particlesTeleportOut.Play(true);
			audioTeleportOut.Play(enemy.CenterTransform);
			stateStart = false;
		}
		enemy.StateStunned.OverrideDisable(0.5f);
		ActivateRiderGlitch();
		float num = stateTimer / stateTimerMax;
		float num2 = num * num * num;
		float num3 = 1f - animationCurveTeleportOut.Evaluate(num);
		teleportTransform.localScale = Vector3.one * num3;
		float num4 = 1440f * num2;
		teleportTransform.localRotation = Quaternion.Euler(num4 * 0.5f, num4, num4 * 0.3f);
		if (stateTimer >= stateTimerMax)
		{
			teleportTransform.localRotation = Quaternion.identity;
			teleportTransform.localScale = Vector3.zero;
			if (SemiFunc.IsMasterClientOrSingleplayer())
			{
				enemy.EnemyParent.Despawn();
			}
		}
	}

	private void StateTeleportIn()
	{
		//IL_015a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0160: Unknown result type (might be due to invalid IL or missing references)
		//IL_0187: Unknown result type (might be due to invalid IL or missing references)
		//IL_003c: Unknown result type (might be due to invalid IL or missing references)
		//IL_005d: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c2: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f5: Unknown result type (might be due to invalid IL or missing references)
		//IL_01a5: Unknown result type (might be due to invalid IL or missing references)
		//IL_01b5: Unknown result type (might be due to invalid IL or missing references)
		if (stateStart)
		{
			stateTimerMax = 1f;
			stateTimer = 0f;
			enemy.NavMeshAgent.Warp(((Component)enemy.Rigidbody).transform.position);
			enemy.NavMeshAgent.ResetPath();
			teleportTransform.localScale = Vector3.zero;
			particlesTeleportIn.Play(true);
			audioTeleportIn.Play(enemy.CenterTransform);
			GameDirector.instance.CameraShake.ShakeDistance(1.5f, 2f, 6f, enemy.CenterTransform.position, 0.15f);
			GameDirector.instance.CameraImpact.ShakeDistance(3f, 2f, 6f, enemy.CenterTransform.position, 0.08f);
			stateStart = false;
		}
		enemy.StateStunned.OverrideDisable(0.5f);
		ActivateRiderGlitch();
		float num = stateTimer / stateTimerMax;
		float num2 = num * num * num;
		float num3 = 1f - animationCurveTeleportIn.Evaluate(1f - num);
		teleportTransform.localScale = Vector3.one * num3;
		float num4 = 1440f * num2;
		teleportTransform.localRotation = Quaternion.Euler(num4 * 0.5f, num4, num4 * 0.3f);
		if (stateTimer >= stateTimerMax)
		{
			teleportTransform.localRotation = Quaternion.identity;
			teleportTransform.localScale = Vector3.one;
			SetState(State.Idle);
		}
	}

	private void AnimatedDespawn()
	{
		//IL_0006: Unknown result type (might be due to invalid IL or missing references)
		if (teleportTransform.localScale.x > 0.1f)
		{
			SetState(State.TeleportOut);
		}
		else if (SemiFunc.IsMasterClientOrSingleplayer())
		{
			enemy.EnemyParent.Despawn();
		}
	}

	private void StateDespawn()
	{
		if (stateStart)
		{
			AnimatedDespawn();
		}
		else if (SemiFunc.IsMasterClientOrSingleplayer())
		{
			enemy.EnemyParent.Despawn();
		}
	}

	public void OnSpawn()
	{
		hitShakeTimer = 0f;
		if (SemiFunc.IsMasterClientOrSingleplayer() && SemiFunc.EnemySpawn(enemy))
		{
			SetState(State.Spawn);
		}
	}

	public void OnInvestigate()
	{
		//IL_0031: Unknown result type (might be due to invalid IL or missing references)
		//IL_0041: Unknown result type (might be due to invalid IL or missing references)
		//IL_005e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0063: Unknown result type (might be due to invalid IL or missing references)
		if (SemiFunc.IsMasterClientOrSingleplayer() && (currentState == State.Idle || currentState == State.Roam || currentState == State.RoamAggro || currentState == State.Investigate) && Vector3.Distance(((Component)this).transform.position, enemy.StateInvestigate.onInvestigateTriggeredPosition) >= 5f)
		{
			agentDestination = enemy.StateInvestigate.onInvestigateTriggeredPosition;
			SetState(State.Investigate);
		}
	}

	public void OnHurt()
	{
		audioHurt.Play(enemy.CenterTransform);
		if (SemiFunc.IsMasterClientOrSingleplayer())
		{
			GotoBellState(_increaseFirst: true);
		}
	}

	public void OnGrabbed()
	{
		//IL_001d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0028: Unknown result type (might be due to invalid IL or missing references)
		//IL_002d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0032: Unknown result type (might be due to invalid IL or missing references)
		//IL_0035: Unknown result type (might be due to invalid IL or missing references)
		//IL_003a: Unknown result type (might be due to invalid IL or missing references)
		if (SemiFunc.IsMasterClientOrSingleplayer())
		{
			Vector3 val = ((Component)enemy.Rigidbody.onGrabbedPlayerAvatar).transform.position - ((Component)this).transform.position;
			agentDirection = val.normalized;
			GotoBellState(_increaseFirst: true);
		}
	}

	public void OnDeath()
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_0057: Unknown result type (might be due to invalid IL or missing references)
		GameDirector.instance.CameraShake.ShakeDistance(4f, 3f, 10f, enemy.CenterTransform.position, 0.5f);
		GameDirector.instance.CameraImpact.ShakeDistance(5f, 3f, 10f, enemy.CenterTransform.position, 0.05f);
		particlesDeath.Play(true);
		audioDeath.Play(enemy.CenterTransform);
		audioDeathBikeCrash.Play(enemy.CenterTransform);
		visuals.ImpulseImpact(15f);
		if (SemiFunc.IsMasterClientOrSingleplayer())
		{
			enemy.EnemyParent.Despawn();
		}
	}

	public void OnHitPlayer()
	{
		//IL_002f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0034: Unknown result type (might be due to invalid IL or missing references)
		//IL_007c: Unknown result type (might be due to invalid IL or missing references)
		//IL_007f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0085: Unknown result type (might be due to invalid IL or missing references)
		//IL_0063: Unknown result type (might be due to invalid IL or missing references)
		PlayerAvatar onImpactPlayerAvatar = hurtCollider.onImpactPlayerAvatar;
		if (Object.op_Implicit((Object)(object)onImpactPlayerAvatar) && (!SemiFunc.IsMultiplayer() || onImpactPlayerAvatar.photonView.IsMine))
		{
			Vector3 position = ((Component)onImpactPlayerAvatar).transform.position;
			if (SemiFunc.IsMultiplayer())
			{
				photonView.RPC("OnHitPlayerRPC", (RpcTarget)0, new object[2]
				{
					onImpactPlayerAvatar.photonView.ViewID,
					position
				});
			}
			else
			{
				OnHitPlayerRPC(onImpactPlayerAvatar.photonView.ViewID, position);
			}
		}
	}

	private void SetState(State newState)
	{
		//IL_003d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0043: Unknown result type (might be due to invalid IL or missing references)
		if (newState != currentState && SemiFunc.IsMasterClientOrSingleplayer())
		{
			if (SemiFunc.IsMultiplayer())
			{
				photonView.RPC("SetStateRPC", (RpcTarget)0, new object[1] { (int)newState });
			}
			else
			{
				SetStateRPC((int)newState);
			}
		}
	}

	private void GotoBellState(bool _increaseFirst = false)
	{
		if (currentState != State.Attack && currentState != State.AttackShort && currentState != State.AttackTell && currentState != State.AttackTellShort && currentState != State.StateBeforeAttack && currentState != State.Despawn && currentState != State.BellRing && currentState != State.BellRing2 && currentState != State.BellRing3 && currentState != State.Stun)
		{
			if (_increaseFirst)
			{
				bellRingCount++;
			}
			if (bellRingCount == 0)
			{
				SetState(State.BellRing);
			}
			else if (bellRingCount == 1)
			{
				SetState(State.BellRing2);
			}
			else
			{
				SetState(State.BellRing3);
			}
		}
	}

	private bool HandleBlocked()
	{
		bool result = false;
		if (IsPlayerBlockingNavmeshPath())
		{
			lastSeenPlayerTimer = 10f;
			GotoBellState();
			result = true;
		}
		return result;
	}

	private bool StuckCheck()
	{
		return false;
	}

	private bool IsPlayerBlockingNavmeshPath()
	{
		//IL_0035: Unknown result type (might be due to invalid IL or missing references)
		//IL_003a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0052: Unknown result type (might be due to invalid IL or missing references)
		//IL_0058: Unknown result type (might be due to invalid IL or missing references)
		//IL_0086: Unknown result type (might be due to invalid IL or missing references)
		//IL_008b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0101: Unknown result type (might be due to invalid IL or missing references)
		if (Time.time - isBlockedByPlayerCheckLast > 0.2f)
		{
			isBlockedByPlayer = false;
			isBlockedByPlayerAvatar = null;
			isBlockedByPlayerCheckLast = Time.time;
			Vector3 normalized = agentDirection.normalized;
			float num = 3f;
			float num2 = 0.5f;
			RaycastHit[] array = Physics.SphereCastAll(enemy.CenterTransform.position, num2, normalized, num, LayerMask.GetMask(new string[2] { "Player", "PhysGrabObject" }));
			for (int i = 0; i < array.Length; i++)
			{
				RaycastHit val = array[i];
				PlayerController componentInParent = ((Component)val.collider).GetComponentInParent<PlayerController>();
				PlayerAvatar playerAvatar;
				if (Object.op_Implicit((Object)(object)componentInParent))
				{
					playerAvatar = componentInParent.playerAvatarScript;
				}
				else
				{
					playerAvatar = ((Component)val.collider).GetComponentInParent<PlayerAvatar>();
					if (!Object.op_Implicit((Object)(object)playerAvatar))
					{
						PlayerTumble componentInParent2 = ((Component)val.collider).GetComponentInParent<PlayerTumble>();
						if (Object.op_Implicit((Object)(object)componentInParent2))
						{
							playerAvatar = componentInParent2.playerAvatar;
						}
					}
				}
				if (Object.op_Implicit((Object)(object)playerAvatar) && enemy.NavMeshAgent.OnNavmesh(((Component)playerAvatar).transform.position, 1f, _checkPit: true))
				{
					isBlockedByPlayerAvatar = playerAvatar;
					isBlockedByPlayer = true;
				}
			}
		}
		return isBlockedByPlayer;
	}

	private void BlockedDetectionLogic()
	{
		if (!SemiFunc.IsMasterClientOrSingleplayer() || currentState != State.Roam)
		{
			return;
		}
		if (enemy.NavMeshAgent.AgentVelocity.magnitude < 0.1f)
		{
			blockedTimer += Time.deltaTime;
			if (blockedTimer > 1f)
			{
				HandleBlocked();
			}
		}
		else
		{
			blockedTimer = 0f;
		}
	}

	private void PlayBellSound()
	{
		audioBell.Play(enemy.CenterTransform);
	}

	private void DoBellRing()
	{
		PlayBellSound();
		if (SemiFunc.IsMasterClientOrSingleplayer())
		{
			bellRingResetTimer = 10f;
		}
		if (bellRingCount >= 3)
		{
			audioBellGlobal.Play(enemy.CenterTransform);
		}
		visuals.ImpulseBellRing();
	}

	private void FindNextWaypointFromInvestigation()
	{
		//IL_0001: Unknown result type (might be due to invalid IL or missing references)
		//IL_0011: Unknown result type (might be due to invalid IL or missing references)
		//IL_0016: Unknown result type (might be due to invalid IL or missing references)
		//IL_001b: Unknown result type (might be due to invalid IL or missing references)
		//IL_001e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0023: Unknown result type (might be due to invalid IL or missing references)
		//IL_0026: Unknown result type (might be due to invalid IL or missing references)
		//IL_002b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0064: Unknown result type (might be due to invalid IL or missing references)
		//IL_0069: Unknown result type (might be due to invalid IL or missing references)
		//IL_006f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0074: Unknown result type (might be due to invalid IL or missing references)
		//IL_0051: Unknown result type (might be due to invalid IL or missing references)
		//IL_0056: Unknown result type (might be due to invalid IL or missing references)
		//IL_008a: Unknown result type (might be due to invalid IL or missing references)
		//IL_008f: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b6: Unknown result type (might be due to invalid IL or missing references)
		//IL_00bb: Unknown result type (might be due to invalid IL or missing references)
		Vector3 val = agentDestination - enemy.CenterTransform.position;
		Vector3 normalized = val.normalized;
		LevelPoint levelPoint = FindLevelPointInCone(agentDestination, normalized, 65f, 15f, 35f);
		NavMeshHit val2 = default;
		if ((Object)(object)levelPoint != (Object)null)
		{
			agentDestination = ((Component)levelPoint).transform.position;
			SetState(State.Roam);
		}
		else if (NavMesh.SamplePosition(agentDestination + normalized * 8f, ref val2, 10f, -1) && Physics.Raycast(val2.position, Vector3.down, 5f, LayerMask.GetMask(new string[1] { "Default" })))
		{
			agentDestination = val2.position;
			SetState(State.Roam);
		}
	}

	private LevelPoint FindLevelPointInCone(Vector3 fromPosition, Vector3 forwardDirection, float coneAngle, float minDistance, float maxDistance)
	{
		//IL_0023: Unknown result type (might be due to invalid IL or missing references)
		//IL_0028: Unknown result type (might be due to invalid IL or missing references)
		//IL_0029: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0032: Unknown result type (might be due to invalid IL or missing references)
		//IL_0037: Unknown result type (might be due to invalid IL or missing references)
		//IL_0039: Unknown result type (might be due to invalid IL or missing references)
		//IL_0040: Unknown result type (might be due to invalid IL or missing references)
		//IL_0058: Unknown result type (might be due to invalid IL or missing references)
		//IL_0059: Unknown result type (might be due to invalid IL or missing references)
		LevelPoint result = null;
		float num = float.MaxValue;
		foreach (LevelPoint item in SemiFunc.LevelPointsGetAll())
		{
			Vector3 val = ((Component)item).transform.position - fromPosition;
			Vector3 normalized = val.normalized;
			float num2 = Vector3.Distance(fromPosition, ((Component)item).transform.position);
			if (!(num2 < minDistance) && !(num2 > maxDistance) && Vector3.Angle(forwardDirection, normalized) <= coneAngle * 0.5f && num2 < num)
			{
				num = num2;
				result = item;
			}
		}
		return result;
	}

	private void UpdateTimers()
	{
		if (lastSeenPlayerTimer > 0f)
		{
			lastSeenPlayerTimer -= Time.deltaTime;
		}
		if (attackCooldown > 0f && currentState != State.Attack && currentState != State.AttackOutro)
		{
			attackCooldown -= Time.deltaTime;
		}
		if (flyingOverPitTimer <= 0f)
		{
			isFlyingOverPit = false;
		}
		if (flyingOverPitTimer > 0f)
		{
			flyingOverPitTimer -= Time.deltaTime;
		}
		if (activateRiderStunnedVisualsTimer > 0f)
		{
			activateRiderStunnedVisualsTimer -= Time.deltaTime;
		}
		if (activeStunnedVisualsCooldown > 0f)
		{
			activeStunnedVisualsCooldown -= Time.deltaTime;
		}
		if (handsLetGoTimer > 0f)
		{
			handsLetGoTimer -= Time.deltaTime;
			if (!handMeshesActive)
			{
				GameObject[] array = handMeshes;
				for (int i = 0; i < array.Length; i++)
				{
					array[i].SetActive(true);
				}
				handMeshesActive = true;
			}
			if (handMeshesAttachedActive)
			{
				GameObject[] array = handMeshesAttached;
				for (int i = 0; i < array.Length; i++)
				{
					array[i].SetActive(false);
				}
				handMeshesAttachedActive = false;
			}
		}
		else
		{
			if (handMeshesActive)
			{
				GameObject[] array = handMeshes;
				for (int i = 0; i < array.Length; i++)
				{
					array[i].SetActive(false);
				}
				handMeshesActive = false;
			}
			if (riderGlitchTimer > 0f && !handMeshesAttachedActive)
			{
				GameObject[] array = handMeshesAttached;
				for (int i = 0; i < array.Length; i++)
				{
					array[i].SetActive(true);
				}
				handMeshesAttachedActive = true;
			}
		}
		if (feetLetGoTimer > 0f)
		{
			feetLetGoTimer -= Time.deltaTime;
			if (!footMeshesActive)
			{
				GameObject[] array = footMeshes;
				for (int i = 0; i < array.Length; i++)
				{
					array[i].SetActive(true);
				}
				footMeshesActive = true;
			}
			if (footMeshesAttachedActive)
			{
				GameObject[] array = footMeshesAttached;
				for (int i = 0; i < array.Length; i++)
				{
					array[i].SetActive(false);
				}
				footMeshesAttachedActive = false;
			}
		}
		else
		{
			if (footMeshesActive)
			{
				GameObject[] array = footMeshes;
				for (int i = 0; i < array.Length; i++)
				{
					array[i].SetActive(false);
				}
				footMeshesActive = false;
			}
			if (riderGlitchTimer > 0f && !footMeshesAttachedActive)
			{
				GameObject[] array = footMeshesAttached;
				for (int i = 0; i < array.Length; i++)
				{
					array[i].SetActive(true);
				}
				footMeshesAttachedActive = true;
			}
		}
		if (!SemiFunc.IsMasterClientOrSingleplayer())
		{
			return;
		}
		if (currentState == State.AttackTell || currentState == State.AttackTellShort || currentState == State.Attack || currentState == State.AttackShort || currentState == State.AttackDive || currentState == State.AttackOutro)
		{
			bellRingResetTimer = 0f;
			bellRingCount = 0;
		}
		if (bellRingResetTimer > 0f)
		{
			bellRingResetTimer -= Time.deltaTime;
			if (bellRingResetTimer <= 0f)
			{
				bellRingCount = 0;
			}
		}
	}

	private void UpdateBackToNavmeshPosition()
	{
		//IL_0028: Unknown result type (might be due to invalid IL or missing references)
		//IL_004b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0050: Unknown result type (might be due to invalid IL or missing references)
		if (SemiFunc.PerSecond(15f, (Object)(object)this) && enemy.NavMeshAgent.OnNavmesh(((Component)enemy.Rigidbody).transform.position, 0.5f, _checkPit: true))
		{
			backToNavmeshPosition = ((Component)enemy.Rigidbody).transform.position;
		}
	}

	private void UpdateAgentDirection()
	{
		//IL_002d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0032: Unknown result type (might be due to invalid IL or missing references)
		if (enemy.NavMeshAgent.AgentVelocity.magnitude > 0.1f)
		{
			agentDirection = enemy.NavMeshAgent.AgentVelocity.normalized;
		}
	}

	private void PlayLoopSoundLogic()
	{
		if (currentState == State.AttackTell)
		{
			_ = 1;
		}
		else
			_ = currentState == State.AttackTellShort;
		float num = Mathf.Clamp01(stateTimer / 0.5f);
		Mathf.Lerp(0.8f, 1.5f, num);
		bool playing = currentState == State.Attack || currentState == State.AttackShort;
		audioAttackLoop.PlayLoop(playing, 1f, 1f);
		float num2 = currentVelocity.magnitude * 10f;
		smoothedSpeed = Mathf.Lerp(smoothedSpeed, num2, Time.deltaTime * 5f);
		float num3 = Mathf.Clamp01(smoothedSpeed / 5f);
		float pitchMultiplier = Mathf.Lerp(1f, 1.6f, num3);
		if (rattlePlayingState)
		{
			if (num2 < 1f)
			{
				rattlePlayingState = false;
			}
		}
		else if (num2 > 1.2f)
		{
			rattlePlayingState = true;
		}
		audioWheelRattle.PlayLoop(rattlePlayingState, 2f, 1f, pitchMultiplier);
		float num4 = Mathf.Clamp01(smoothedSpeed);
		float pitchMultiplier2 = Mathf.Lerp(0.9f, 1.5f, num4);
		if (squeakPlayingState)
		{
			if (num2 < 0.1f)
			{
				squeakPlayingState = false;
			}
		}
		else if (num2 > 0.2f)
		{
			squeakPlayingState = true;
		}
		audioWheelSqueak.PlayLoop(squeakPlayingState, 2f, 1f, pitchMultiplier2);
		if (SemiFunc.PerSecond(5f, (Object)(object)this))
		{
			float num5 = currentVelocity.magnitude * 3f;
			float num6 = Mathf.Abs(num5 - previousVelocityMagnitude);
			float num7 = Mathf.Abs(currentAngularVelocity - previousAngularVelocity);
			if ((num6 > 0.15f || num7 > 5f) && moveSoundCooldown <= 0f)
			{
				audioMove.Play(enemy.CenterTransform);
				moveSoundCooldown = 0.3f;
			}
			previousVelocityMagnitude = num5;
			previousAngularVelocity = currentAngularVelocity;
		}
		if (moveSoundCooldown > 0f)
		{
			moveSoundCooldown -= Time.deltaTime;
		}
	}

	private void UpdateVelocity()
	{
		//IL_004a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0050: Unknown result type (might be due to invalid IL or missing references)
		//IL_0055: Unknown result type (might be due to invalid IL or missing references)
		//IL_005b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0060: Unknown result type (might be due to invalid IL or missing references)
		//IL_0071: Unknown result type (might be due to invalid IL or missing references)
		//IL_0076: Unknown result type (might be due to invalid IL or missing references)
		//IL_0081: Unknown result type (might be due to invalid IL or missing references)
		//IL_0096: Unknown result type (might be due to invalid IL or missing references)
		//IL_009b: Unknown result type (might be due to invalid IL or missing references)
		//IL_009e: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c8: Unknown result type (might be due to invalid IL or missing references)
		//IL_00cd: Unknown result type (might be due to invalid IL or missing references)
		if (SemiFunc.PerSecond(30f, (Object)(object)this))
		{
			float num = Time.time - previousSampleTime;
			previousSampleTime = Time.time;
			float num2 = 1f;
			if (num > 0f)
			{
				num2 = 1f / 30f / num;
			}
			currentVelocity = (((Component)visuals).transform.position - previousPosition) * num2;
			previousPosition = ((Component)visuals).transform.position;
			float y = previousRotation.eulerAngles.y;
			Quaternion rotation = ((Component)visuals).transform.rotation;
			float num3 = Mathf.DeltaAngle(y, rotation.eulerAngles.y);
			currentAngularVelocity = Mathf.Abs(num3) * num2;
			previousRotation = ((Component)visuals).transform.rotation;
		}
	}

	private void SendVisualImpulses()
	{
		float num = currentVelocity.magnitude * 100f;
		float num2 = num + currentAngularVelocity;
		float speed = num2 * 100f;
		visuals.ImpulseWheelRotation(speed);
		float num3 = Mathf.Lerp(5f, 25f, Mathf.Clamp01(num2 / 5f));
		float num4 = num / 2f;
		float num5 = currentAngularVelocity / 30f;
		float num6 = num4 + num5;
		if (num6 > 0.01f)
		{
			visuals.ImpulseWheelShake(num6 * 2f, num3);
			visuals.ImpulseBodyShake(num6 * 1f, num3 * 0.7f);
			visuals.ImpulseHandlebarShake(num6 * 1f, num3 * 0.8f);
		}
	}

	private void PitCheckLogic()
	{
		//IL_002a: Unknown result type (might be due to invalid IL or missing references)
		//IL_000e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0018: Unknown result type (might be due to invalid IL or missing references)
		if (isFlyingOverPit)
		{
			followTargetTransform.localPosition = Vector3.up * 0.5f;
		}
		else
		{
			followTargetTransform.localPosition = Vector3.zero;
		}
		if (!enemy.IsStunned())
		{
			enemyPitCheck.CheckPit();
			if (enemyPitCheck.isOverPit)
			{
				enemy.Rigidbody.DeactivateCustomGravity(0.2f);
				enemy.Rigidbody.physGrabObject.OverrideZeroGravity(0.2f);
				enemy.Rigidbody.OverrideFollowPositionGravityDisable(0.2f);
				SetFlyingOverPitTimer(0.1f);
			}
		}
	}

	public void SetFlyingOverPitTimer(float duration)
	{
		//IL_0026: Unknown result type (might be due to invalid IL or missing references)
		ActivateRiderGlitch();
		flyingOverPitTimer = duration;
		isFlyingOverPit = true;
		flyingOverPitYPosition = ((Component)enemy.Rigidbody).transform.position.y;
	}

	private void ActivateRiderGlitch(bool _letGoOfBike = false)
	{
		if (riderGlitchTimer <= 0f)
		{
			riderGlitchTimer = 0.1f;
			riderGlitchParticlesPlayed = false;
			riderGlitchOutParticlesPlayed = false;
			riderGlitchInShowDelay = 0.1f;
		}
		else
		{
			riderGlitchTimer = 0.1f;
		}
	}

	private void GlitchInEffects()
	{
		particlesRiderGlitchIn.Play(true);
		audioRiderGlitchIn.Play(enemy.CenterTransform);
		visuals.botSystemSpringPoseAnimator.SetRandomForceOnAllBones(100f, 300f);
		visuals.botSystemSpringPoseAnimator.SetTempSpeedAndDampingOnAllBones(65f, 0.3f, 0.4f);
	}

	private void GlitchOutEffects()
	{
		particlesRiderGlitchOut.Play(true);
		audioRiderGlitchOut.Play(enemy.CenterTransform);
		visuals.botSystemSpringPoseAnimator.SetRandomForceOnAllBones(100f, 300f);
		visuals.botSystemSpringPoseAnimator.SetTempSpeedAndDampingOnAllBones(65f, 0.3f, 0.4f);
	}

	private void SetFollowTargetRotation(Quaternion rotation)
	{
		//IL_0001: Unknown result type (might be due to invalid IL or missing references)
		//IL_0002: Unknown result type (might be due to invalid IL or missing references)
		followTargetRotationOverride = rotation;
		followTargetRotationOverrideTimer = 0.1f;
	}

	private void UpdateFollowTargetRotation()
	{
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0064: Unknown result type (might be due to invalid IL or missing references)
		//IL_006a: Unknown result type (might be due to invalid IL or missing references)
		//IL_006f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0074: Unknown result type (might be due to invalid IL or missing references)
		//IL_007b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0020: Unknown result type (might be due to invalid IL or missing references)
		if (followTargetRotationOverrideTimer <= 0f && followTargetRotationOverrideTimer != -123f)
		{
			followTargetTransform.localRotation = Quaternion.identity;
			followTargetRotationOverrideTimer = -123f;
		}
		if (followTargetRotationOverrideTimer > 0f)
		{
			followTargetRotationOverrideTimer -= Time.deltaTime;
			Quaternion localRotation = Quaternion.Inverse(followTargetTransform.parent.rotation) * followTargetRotationOverride;
			followTargetTransform.localRotation = localRotation;
		}
	}

	private void UpdateRiderGlitch()
	{
		if (riderGlitchTimer > 0f)
		{
			riderGlitchOutParticlesPlayed = false;
			riderGlitchTimer -= Time.deltaTime;
			if (riderGlitchTimer <= 0f && !riderGlitchOutParticlesPlayed)
			{
				GlitchOutEffects();
				riderGlitchOutParticlesPlayed = true;
				riderGlitchOutHideDelay = 0.2f;
			}
		}
		if (riderGlitchOutHideDelay > 0f)
		{
			riderGlitchOutHideDelay -= Time.deltaTime;
			if (riderGlitchOutHideDelay <= 0f)
			{
				foreach (Transform bikeRiderTransform in bikeRiderTransforms)
				{
					if (Object.op_Implicit((Object)(object)bikeRiderTransform) && ((Component)bikeRiderTransform).gameObject.activeSelf)
					{
						((Component)bikeRiderTransform).gameObject.SetActive(false);
					}
				}
				riderFlickerTimer = 0f;
				riderHideDelayTimer = 0f;
			}
		}
		if (riderGlitchTimer <= 0f && riderGlitchOutHideDelay <= 0f)
		{
			foreach (Transform bikeRiderTransform2 in bikeRiderTransforms)
			{
				if (Object.op_Implicit((Object)(object)bikeRiderTransform2) && ((Component)bikeRiderTransform2).gameObject.activeSelf)
				{
					((Component)bikeRiderTransform2).gameObject.SetActive(false);
				}
			}
			riderFlickerTimer = 0f;
			riderHideDelayTimer = 0f;
		}
		if (riderGlitchInShowDelay > 0f)
		{
			riderGlitchInShowDelay -= Time.deltaTime;
			if (riderGlitchInShowDelay <= 0f)
			{
				if (!riderGlitchParticlesPlayed)
				{
					GlitchInEffects();
					riderGlitchParticlesPlayed = true;
				}
				foreach (Transform bikeRiderTransform3 in bikeRiderTransforms)
				{
					if (Object.op_Implicit((Object)(object)bikeRiderTransform3))
					{
						((Component)bikeRiderTransform3).gameObject.SetActive(true);
					}
				}
			}
		}
		if (riderGlitchTimer > 0f && riderGlitchInShowDelay <= 0f)
		{
			if (riderHideDelayTimer > 0f)
			{
				riderHideDelayTimer -= Time.deltaTime;
				if (riderHideDelayTimer <= 0f)
				{
					foreach (Transform bikeRiderTransform4 in bikeRiderTransforms)
					{
						if (Object.op_Implicit((Object)(object)bikeRiderTransform4))
						{
							((Component)bikeRiderTransform4).gameObject.SetActive(false);
						}
					}
					riderFlickerTimer = 0f;
				}
			}
			if (riderFlickerTimer > 0f)
			{
				riderFlickerTimer -= Time.deltaTime;
				if (riderFlickerTimer <= 0f && riderHideDelayTimer <= 0f)
				{
					bool flag = false;
					foreach (Transform bikeRiderTransform5 in bikeRiderTransforms)
					{
						if (Object.op_Implicit((Object)(object)bikeRiderTransform5) && ((Component)bikeRiderTransform5).gameObject.activeSelf)
						{
							flag = true;
							break;
						}
					}
					if (flag)
					{
						riderHideDelayTimer = 0.1f;
					}
				}
			}
			if (riderFlickerTimer <= 0f && riderHideDelayTimer <= 0f)
			{
				bool flag2 = false;
				foreach (Transform bikeRiderTransform6 in bikeRiderTransforms)
				{
					if (Object.op_Implicit((Object)(object)bikeRiderTransform6) && !((Component)bikeRiderTransform6).gameObject.activeSelf)
					{
						flag2 = true;
						break;
					}
				}
				if (flag2)
				{
					foreach (Transform bikeRiderTransform7 in bikeRiderTransforms)
					{
						if (Object.op_Implicit((Object)(object)bikeRiderTransform7))
						{
							((Component)bikeRiderTransform7).gameObject.SetActive(true);
						}
					}
					riderFlickerTimer = Random.Range(0.1f, 0.5f);
				}
			}
		}
		if (activateRiderStunnedVisualsTimer > 0f)
		{
			visuals.botSystemSpringPoseAnimator.SetPoseByName("stunned");
			ActivateRiderGlitch(_letGoOfBike: true);
		}
	}

	public void HandsLetGo()
	{
		handsLetGoTimer = 0.1f;
		visuals.HandsLetGo(0.1f);
	}

	public void FeetLetGo()
	{
		feetLetGoTimer = 0.1f;
		visuals.FeetLetGo(0.1f);
	}

	public void ActivateAttackVisuals()
	{
		attackVisualsTimer = 0.1f;
	}

	private void CanDoIdleBreakers()
	{
		//IL_00aa: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b0: Unknown result type (might be due to invalid IL or missing references)
		if (!SemiFunc.IsMasterClientOrSingleplayer())
		{
			return;
		}
		idleBreakerTimer += Time.deltaTime;
		if (idleBreakerTimer <= 0f)
		{
			idleBreakerTimer = 0f;
			idleBreakerTimerMax = Random.Range(1f, 20f);
		}
		else if (idleBreakerTimer >= idleBreakerTimerMax)
		{
			idleBreakerTimer = 0f;
			idleBreakerTimerMax = Random.Range(1f, 20f);
			int num = Random.Range(0, 6);
			if (SemiFunc.IsMultiplayer())
			{
				photonView.RPC("IdleBreakerRPC", (RpcTarget)0, new object[1] { num });
			}
			else
			{
				IdleBreakerRPC(num);
			}
		}
	}

	private void IdleBreakerStop()
	{
		idleBreakerActiveTimer = 0f;
		if (audioIdleBreaker.Length > idleBreakerIndex && idleBreakerIndex >= 0)
		{
			audioIdleBreaker[idleBreakerIndex].Stop();
		}
	}

	private void RotationFollowTargetOrVelocity()
	{
		//IL_0000: Unknown result type (might be due to invalid IL or missing references)
		//IL_0005: Unknown result type (might be due to invalid IL or missing references)
		//IL_0051: Unknown result type (might be due to invalid IL or missing references)
		//IL_0056: Unknown result type (might be due to invalid IL or missing references)
		//IL_0059: Unknown result type (might be due to invalid IL or missing references)
		//IL_005e: Unknown result type (might be due to invalid IL or missing references)
		//IL_002b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0036: Unknown result type (might be due to invalid IL or missing references)
		//IL_003b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0040: Unknown result type (might be due to invalid IL or missing references)
		//IL_0043: Unknown result type (might be due to invalid IL or missing references)
		//IL_0048: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_006e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0073: Unknown result type (might be due to invalid IL or missing references)
		//IL_0075: Unknown result type (might be due to invalid IL or missing references)
		Vector3 val = Vector3.zero;
		Vector3 val2;
		if (Object.op_Implicit((Object)(object)playerTarget) && !playerTarget.isDisabled)
		{
			val2 = ((Component)playerTarget).transform.position - rb.position;
			val = val2.normalized;
		}
		else
		{
			val2 = rb.linearVelocity;
			val = val2.normalized;
		}
		if (val.sqrMagnitude > float.Epsilon)
		{
			Quaternion targetRotation = Quaternion.LookRotation(val);
			FollowTargetRotateTowards(targetRotation, 360f);
		}
	}

	private void FollowTargetRotateTowards(Quaternion _targetRotation, float _degreesPerSecond)
	{
		//IL_000c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0011: Unknown result type (might be due to invalid IL or missing references)
		//IL_0019: Unknown result type (might be due to invalid IL or missing references)
		followTargetTransform.rotation = Quaternion.RotateTowards(followTargetTransform.rotation, _targetRotation, _degreesPerSecond * Time.deltaTime);
	}

	private void InitializeJawAnimation()
	{
		//IL_0007: Unknown result type (might be due to invalid IL or missing references)
		//IL_000c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0013: Unknown result type (might be due to invalid IL or missing references)
		//IL_0018: Unknown result type (might be due to invalid IL or missing references)
		jawStartRotation = jawTransform.localRotation;
		jawTargetRotation = jawStartRotation;
		jawSpring = new SpringQuaternion();
		jawSpring.damping = 0.6f;
		jawSpring.speed = 30f;
	}

	private void CodeAnimatedTalk()
	{
		//IL_00a7: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b7: Unknown result type (might be due to invalid IL or missing references)
		//IL_00bc: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c1: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00dd: Unknown result type (might be due to invalid IL or missing references)
		//IL_0080: Unknown result type (might be due to invalid IL or missing references)
		//IL_0085: Unknown result type (might be due to invalid IL or missing references)
		//IL_008f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0094: Unknown result type (might be due to invalid IL or missing references)
		//IL_0099: Unknown result type (might be due to invalid IL or missing references)
		if (SemiFunc.PerSecond(30f, (Object)(object)this))
		{
			float num = 0f;
			foreach (AudioSource talkingAudioSource in talkingAudioSources)
			{
				talkingAudioSource.GetSpectrumData(audioSourceSpectrum, 0, (FFTWindow)2);
				float num2 = audioSourceSpectrum[0] * 100000f;
				num += num2;
			}
			if (num > 46f)
			{
				num = 46f;
			}
			talkVolume = num;
			SpringQuaternion springQuaternion = jawSpring;
			springQuaternion.springVelocity += Random.insideUnitSphere * 0.5f;
		}
		float num3 = talkVolume;
		jawTargetRotation = jawStartRotation * Quaternion.Euler(num3, 0f, 0f);
		jawTransform.localRotation = SemiFunc.SpringQuaternionGet(jawSpring, jawTargetRotation);
		if (talkVolume > 0f)
		{
			talkVolume = Mathf.Lerp(talkVolume, 0f, Time.deltaTime * 5f);
		}
	}

	[PunRPC]
	private void SetStateRPC(int newStateInt, PhotonMessageInfo info = default(PhotonMessageInfo))
	{
		//IL_0000: Unknown result type (might be due to invalid IL or missing references)
		if (SemiFunc.MasterOnlyRPC(info))
		{
			stateStart = true;
			currentState = (State)newStateInt;
		}
	}

	[PunRPC]
	private void ActivateRiderStunnedVisualsRPC(float duration, PhotonMessageInfo _info = default(PhotonMessageInfo))
	{
		//IL_0000: Unknown result type (might be due to invalid IL or missing references)
		if (SemiFunc.MasterOnlyRPC(_info))
		{
			activateRiderStunnedVisualsTimer = duration;
		}
	}

	[PunRPC]
	private void IdleBreakerRPC(int index, PhotonMessageInfo _info = default(PhotonMessageInfo))
	{
		//IL_0000: Unknown result type (might be due to invalid IL or missing references)
		if (SemiFunc.MasterOnlyRPC(_info))
		{
			idleBreakerIndex = index;
			if (audioIdleBreaker.Length > index && index >= 0)
			{
				Sound sound = audioIdleBreaker[index];
				sound.Play(enemy.CenterTransform);
				idleBreakerActiveTimer = sound.Source.clip.length - 0.5f;
			}
		}
	}

	[PunRPC]
	private void OnHitPlayerRPC(int _playerViewID, Vector3 _position, PhotonMessageInfo _info = default(PhotonMessageInfo))
	{
		//IL_000f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0057: Unknown result type (might be due to invalid IL or missing references)
		//IL_007b: Unknown result type (might be due to invalid IL or missing references)
		PlayerAvatar playerAvatar = SemiFunc.PlayerAvatarGetFromPhotonID(_playerViewID);
		if (Object.op_Implicit((Object)(object)playerAvatar) && SemiFunc.OwnerOnlyRPC(_info, playerAvatar.photonView))
		{
			if (!playerAvatar.isLocal && hitShakeTimer <= 0f)
			{
				hitShakeTimer = 1f;
				GameDirector.instance.CameraShake.ShakeDistance(2f, 2f, 8f, _position, 0.15f);
				GameDirector.instance.CameraImpact.ShakeDistance(4f, 2f, 8f, _position, 0.08f);
			}
			audioHitPlayer.Play(((Component)rb).transform);
		}
	}
}
