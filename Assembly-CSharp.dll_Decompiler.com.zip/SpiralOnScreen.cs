using UnityEngine;

public class SpiralOnScreen : MonoBehaviour
{
	private float activeTimer;

	public Transform spiral;

	public SpriteRenderer spiralSpriteRenderer;

	public float rotationSpeed = 1f;

	public float fadeInSpeed = 1f;

	public float fadeOutSpeed = 1f;

	private void Start()
	{
		MakeTransparent();
	}

	private void Update()
	{
		//IL_0058: Unknown result type (might be due to invalid IL or missing references)
		if (activeTimer > 0f)
		{
			activeTimer -= Time.deltaTime;
			FadeIn();
			spiral.Rotate(0f, 0f, rotationSpeed * Time.deltaTime);
			return;
		}
		FadeOut();
		if (((Renderer)spiralSpriteRenderer).material.color.a <= 0f)
		{
			Object.Destroy((Object)(object)((Component)this).gameObject);
		}
	}

	public void Active()
	{
		activeTimer = 0.05f;
	}

	private void FadeIn()
	{
		//IL_000b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0010: Unknown result type (might be due to invalid IL or missing references)
		//IL_0013: Unknown result type (might be due to invalid IL or missing references)
		//IL_003f: Unknown result type (might be due to invalid IL or missing references)
		Color color = ((Renderer)spiralSpriteRenderer).material.color;
		color.a = Mathf.MoveTowards(color.a, 1f, Time.deltaTime * fadeInSpeed);
		((Renderer)spiralSpriteRenderer).material.color = color;
	}

	private void FadeOut()
	{
		//IL_000b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0010: Unknown result type (might be due to invalid IL or missing references)
		//IL_0013: Unknown result type (might be due to invalid IL or missing references)
		//IL_003f: Unknown result type (might be due to invalid IL or missing references)
		Color color = ((Renderer)spiralSpriteRenderer).material.color;
		color.a = Mathf.MoveTowards(color.a, 0f, Time.deltaTime * fadeOutSpeed);
		((Renderer)spiralSpriteRenderer).material.color = color;
	}

	private void MakeTransparent()
	{
		//IL_000b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0010: Unknown result type (might be due to invalid IL or missing references)
		//IL_0028: Unknown result type (might be due to invalid IL or missing references)
		Color color = ((Renderer)spiralSpriteRenderer).material.color;
		color.a = 0f;
		((Renderer)spiralSpriteRenderer).material.color = color;
	}
}
