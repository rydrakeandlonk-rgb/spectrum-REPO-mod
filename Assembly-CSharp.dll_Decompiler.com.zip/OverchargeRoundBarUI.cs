using UnityEngine;
using UnityEngine.UI;

public class OverchargeRoundBarUI : MonoBehaviour
{
	public Image roundBar;

	public Image roundBarBG;

	public Image overchargeWarningIcon;

	public GameObject roundBarObject;

	internal float roundBarFillAmount;

	private SpringFloat roundBarScale;

	private float scaleTarget;

	private float warningTimer;

	private float flashColorTime;

	private float flashColorTimer;

	private Color flashColor;

	private Color originalColor;

	public Sound soundOverchargeWarning;

	private float showTimer;

	private bool show;

	private CanvasGroup canvasGroup;

	public AnimationCurve ringFillCurve;

	public AnimationCurve colorVibranceCurve;

	private void Start()
	{
		//IL_0032: Unknown result type (might be due to invalid IL or missing references)
		//IL_0037: Unknown result type (might be due to invalid IL or missing references)
		roundBarScale = new SpringFloat();
		roundBarScale.speed = 40f;
		roundBarScale.damping = 0.5f;
		originalColor = ((Graphic)roundBar).color;
		((Behaviour)overchargeWarningIcon).enabled = false;
		canvasGroup = ((Component)this).GetComponent<CanvasGroup>();
	}

	private void Show()
	{
		showTimer = 0.2f;
	}

	private void Update()
	{
		//IL_012c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0243: Unknown result type (might be due to invalid IL or missing references)
		//IL_0179: Unknown result type (might be due to invalid IL or missing references)
		//IL_0344: Unknown result type (might be due to invalid IL or missing references)
		//IL_0359: Unknown result type (might be due to invalid IL or missing references)
		//IL_0379: Unknown result type (might be due to invalid IL or missing references)
		if (showTimer <= 0f && show)
		{
			show = false;
		}
		if (showTimer > 0f)
		{
			show = true;
			showTimer -= Time.deltaTime;
		}
		if (show)
		{
			scaleTarget = 1f + colorVibranceCurve.Evaluate(PhysGrabber.instance.physGrabBeamOverChargeFloat) * 0.25f;
			if (!((Behaviour)roundBar).enabled)
			{
				roundBarScale.springVelocity = 50f;
				roundBarScale.speed = 40f;
				roundBarScale.damping = 0.5f;
				((Behaviour)roundBar).enabled = true;
				((Behaviour)roundBarBG).enabled = true;
			}
		}
		else if (scaleTarget != 0f)
		{
			roundBarScale.speed = 50f;
			roundBarScale.damping = 0.9f;
			roundBarScale.springVelocity = 50f;
			scaleTarget = 0f;
		}
		if (!show && roundBarObject.transform.localScale.x <= 0f && ((Behaviour)roundBar).enabled)
		{
			((Behaviour)roundBar).enabled = false;
			((Behaviour)roundBarBG).enabled = false;
			((Behaviour)overchargeWarningIcon).enabled = false;
			roundBarObject.transform.localScale = Vector3.zero;
			roundBarScale.springVelocity = 0f;
			roundBarScale.lastPosition = 0f;
		}
		FlashColorLogic();
		float num = Mathf.Ceil(PhysGrabber.instance.physGrabBeamOverChargeFloat * 100f);
		if (num > 0f && GameDirector.instance.currentState == GameDirector.gameState.Main)
		{
			Show();
		}
		roundBarFillAmount = ringFillCurve.Evaluate(num / 100f);
		roundBar.fillAmount = Mathf.Lerp(roundBar.fillAmount, roundBarFillAmount, Time.deltaTime * 5f);
		float num2 = SemiFunc.SpringFloatGet(roundBarScale, scaleTarget);
		roundBarObject.transform.localScale = new Vector3(num2, num2, num2);
		if (PhysGrabber.instance.grabbed && Object.op_Implicit((Object)(object)PhysGrabber.instance.grabbedPhysGrabObject) && PhysGrabber.instance.grabbedPhysGrabObject.isEnemy)
		{
			if (num > 70f)
			{
				warningTimer += Time.deltaTime * 2f;
			}
			if (num > 80f)
			{
				warningTimer += Time.deltaTime * 2f;
			}
			if (num > 90f)
			{
				warningTimer += Time.deltaTime * 2f;
			}
			if (num > 95f)
			{
				warningTimer += Time.deltaTime * 2f;
			}
		}
		else if (num > 80f)
		{
			warningTimer += Time.deltaTime * 2f;
		}
		if (warningTimer > 1f)
		{
			Color color = new Color(1f, 0.6f, 0f);
			soundOverchargeWarning.Play(((Component)PlayerAvatar.instance).transform.position);
			FlashColor(color, 0.2f);
			roundBarScale.springVelocity = 100f;
			warningTimer = 0f;
		}
		if (Object.op_Implicit((Object)(object)WorldSpaceUIParent.instance))
		{
			canvasGroup.alpha = WorldSpaceUIParent.instance.canvasGroup.alpha;
		}
	}

	private void FlashColor(Color color, float time)
	{
		//IL_0001: Unknown result type (might be due to invalid IL or missing references)
		//IL_0002: Unknown result type (might be due to invalid IL or missing references)
		flashColor = color;
		flashColorTime = time;
		flashColorTimer = time;
	}

	private void FlashColorLogic()
	{
		//IL_0022: Unknown result type (might be due to invalid IL or missing references)
		//IL_0028: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d1: Unknown result type (might be due to invalid IL or missing references)
		//IL_0063: Unknown result type (might be due to invalid IL or missing references)
		//IL_0069: Unknown result type (might be due to invalid IL or missing references)
		//IL_003b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0041: Unknown result type (might be due to invalid IL or missing references)
		//IL_0053: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e9: Unknown result type (might be due to invalid IL or missing references)
		//IL_0114: Unknown result type (might be due to invalid IL or missing references)
		//IL_012e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0133: Unknown result type (might be due to invalid IL or missing references)
		//IL_013a: Unknown result type (might be due to invalid IL or missing references)
		//IL_013f: Unknown result type (might be due to invalid IL or missing references)
		//IL_007c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0082: Unknown result type (might be due to invalid IL or missing references)
		//IL_0094: Unknown result type (might be due to invalid IL or missing references)
		//IL_014d: Unknown result type (might be due to invalid IL or missing references)
		if (flashColorTimer > 0f)
		{
			((Behaviour)overchargeWarningIcon).enabled = true;
			if (((Graphic)roundBar).color != originalColor)
			{
				((Graphic)roundBar).color = Color.Lerp(flashColor, originalColor, flashColorTimer / flashColorTime);
			}
			if (((Graphic)overchargeWarningIcon).color != originalColor)
			{
				((Graphic)overchargeWarningIcon).color = Color.Lerp(flashColor, originalColor, flashColorTimer / flashColorTime);
			}
			flashColorTimer -= Time.deltaTime;
			return;
		}
		if (((Behaviour)overchargeWarningIcon).enabled)
		{
			((Behaviour)overchargeWarningIcon).enabled = false;
			((Graphic)overchargeWarningIcon).color = originalColor;
		}
		if (((Behaviour)overchargeWarningIcon).enabled)
		{
			Color val = Color.Lerp(originalColor, new Color(originalColor.r, originalColor.g, originalColor.b, 1f), colorVibranceCurve.Evaluate(PhysGrabber.instance.physGrabBeamOverChargeFloat));
			if (((Graphic)roundBar).color != val)
			{
				((Graphic)roundBar).color = val;
			}
		}
	}
}
