using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class LevelMaterialSwitch : MonoBehaviour
{
	[Serializable]
	public class Switch
	{
		public Level level;

		public Material material;
	}

	public List<Switch> switches;

	private void Awake()
	{
		((MonoBehaviour)this).StartCoroutine(Setup());
	}

	private IEnumerator Setup()
	{
		while (!LevelGenerator.Instance.Generated)
		{
			yield return null;
		}
		MeshRenderer componentInChildren = ((Component)this).GetComponentInChildren<MeshRenderer>();
		foreach (Switch @switch in switches)
		{
			if (SemiFunc.IsCurrentLevel(RunManager.instance.levelCurrent, @switch.level))
			{
				((Renderer)componentInChildren).material = @switch.material;
				break;
			}
		}
	}
}
