using System;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.AI;

public class NavMeshValidator
{
	private sealed class VertexSearch
	{
		private static readonly IComparer<Vector3>[] comparers = new IComparer<Vector3>[3]
		{
			Comparer<Vector3>.Create((Vector3 _a, Vector3 _b) =>
			{
				//IL_0007: Unknown result type (might be due to invalid IL or missing references)
				return _a.x.CompareTo(_b.x);
			}),
			Comparer<Vector3>.Create((Vector3 _a, Vector3 _b) =>
			{
				//IL_0007: Unknown result type (might be due to invalid IL or missing references)
				return _a.y.CompareTo(_b.y);
			}),
			Comparer<Vector3>.Create((Vector3 _a, Vector3 _b) =>
			{
				//IL_0007: Unknown result type (might be due to invalid IL or missing references)
				return _a.z.CompareTo(_b.z);
			})
		};

		private readonly Vector3[] points;

		private readonly bool linear;

		public VertexSearch(List<Vector3> _points)
		{
			//IL_001f: Unknown result type (might be due to invalid IL or missing references)
			points = _points.ToArray();
			Vector3[] array = points;
			for (int i = 0; i < array.Length; i++)
			{
				if (!Finite(array[i]))
				{
					linear = true;
					break;
				}
			}
			if (!linear)
			{
				Build(0, points.Length, 0);
			}
		}

		private static bool Finite(Vector3 _point)
		{
			//IL_0000: Unknown result type (might be due to invalid IL or missing references)
			//IL_000d: Unknown result type (might be due to invalid IL or missing references)
			//IL_001a: Unknown result type (might be due to invalid IL or missing references)
			//IL_0027: Unknown result type (might be due to invalid IL or missing references)
			//IL_0034: Unknown result type (might be due to invalid IL or missing references)
			//IL_0041: Unknown result type (might be due to invalid IL or missing references)
			if (!float.IsNaN(_point.x) && !float.IsInfinity(_point.x) && !float.IsNaN(_point.y) && !float.IsInfinity(_point.y) && !float.IsNaN(_point.z))
			{
				return !float.IsInfinity(_point.z);
			}
			return false;
		}

		private void Build(int _start, int _count, int _axis)
		{
			if (_count > 1)
			{
				Array.Sort(points, _start, _count, comparers[_axis]);
				int num = _count / 2;
				int num2 = _start + num;
				int axis = (_axis + 1) % 3;
				Build(_start, num, axis);
				Build(num2 + 1, _count - num - 1, axis);
			}
		}

		public float DistanceSquared(Vector3 _point, float _best)
		{
			//IL_0008: Unknown result type (might be due to invalid IL or missing references)
			//IL_0048: Unknown result type (might be due to invalid IL or missing references)
			//IL_001d: Unknown result type (might be due to invalid IL or missing references)
			//IL_0022: Unknown result type (might be due to invalid IL or missing references)
			//IL_0023: Unknown result type (might be due to invalid IL or missing references)
			//IL_0024: Unknown result type (might be due to invalid IL or missing references)
			//IL_0025: Unknown result type (might be due to invalid IL or missing references)
			//IL_002a: Unknown result type (might be due to invalid IL or missing references)
			if (linear || !Finite(_point))
			{
				Vector3[] array = points;
				foreach (Vector3 val in array)
				{
					Vector3 val2 = _point - val;
					float sqrMagnitude = val2.sqrMagnitude;
					if (sqrMagnitude < _best)
					{
						_best = sqrMagnitude;
					}
				}
				return _best;
			}
			Search(_point, 0, points.Length, 0, ref _best);
			return _best;
		}

		private void Search(Vector3 _point, int _start, int _count, int _axis, ref float _best)
		{
			//IL_000c: Unknown result type (might be due to invalid IL or missing references)
			//IL_0014: Unknown result type (might be due to invalid IL or missing references)
			//IL_0019: Unknown result type (might be due to invalid IL or missing references)
			//IL_001e: Unknown result type (might be due to invalid IL or missing references)
			//IL_008c: Unknown result type (might be due to invalid IL or missing references)
			//IL_0065: Unknown result type (might be due to invalid IL or missing references)
			//IL_00a5: Unknown result type (might be due to invalid IL or missing references)
			//IL_007c: Unknown result type (might be due to invalid IL or missing references)
			if (_count == 0)
			{
				return;
			}
			int num = _count / 2;
			int num2 = _start + num;
			Vector3 val = _point - points[num2];
			float sqrMagnitude = val.sqrMagnitude;
			if (sqrMagnitude < _best)
			{
				_best = sqrMagnitude;
			}
			if (_best <= 0f)
			{
				return;
			}
			float num3 = val[_axis];
			int axis = (_axis + 1) % 3;
			int start = num2 + 1;
			int count = _count - num - 1;
			if (num3 <= 0f)
			{
				Search(_point, _start, num, axis, ref _best);
				if (num3 * num3 <= _best)
				{
					Search(_point, start, count, axis, ref _best);
				}
			}
			else
			{
				Search(_point, start, count, axis, ref _best);
				if (num3 * num3 <= _best)
				{
					Search(_point, _start, num, axis, ref _best);
				}
			}
		}
	}

	internal static void SafetyCheck()
	{
		//IL_0000: Unknown result type (might be due to invalid IL or missing references)
		//IL_0005: Unknown result type (might be due to invalid IL or missing references)
		//IL_0006: Unknown result type (might be due to invalid IL or missing references)
		//IL_002d: Unknown result type (might be due to invalid IL or missing references)
		//IL_003a: Unknown result type (might be due to invalid IL or missing references)
		//IL_003d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0042: Unknown result type (might be due to invalid IL or missing references)
		//IL_0044: Unknown result type (might be due to invalid IL or missing references)
		//IL_0057: Unknown result type (might be due to invalid IL or missing references)
		//IL_005c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0088: Unknown result type (might be due to invalid IL or missing references)
		//IL_008c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0091: Unknown result type (might be due to invalid IL or missing references)
		//IL_0093: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ad: Unknown result type (might be due to invalid IL or missing references)
		//IL_00af: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a6: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ab: Unknown result type (might be due to invalid IL or missing references)
		//IL_010b: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d4: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d6: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e2: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e5: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f5: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ee: Unknown result type (might be due to invalid IL or missing references)
		NavMeshTriangulation tri = NavMesh.CalculateTriangulation();
		List<List<int>> list = FindIslands(tri);
		if (list == null || list.Count <= 1)
		{
			return;
		}
		List<int> mainIsland = GetMainIsland(list);
		if (mainIsland == null || mainIsland.Count == 0)
		{
			return;
		}
		VertexSearch mainSearch = new VertexSearch(GetTriangleVertices(tri, mainIsland));
		Vector3 val = GetBestReportPoint(tri, mainIsland, mainSearch);
		NavMeshHit val2 = default;
		if (NavMesh.SamplePosition(val, ref val2, 2f, -1))
		{
			val = val2.position;
		}
		NavMeshHit val4 = default;
		foreach (List<int> item in list)
		{
			if (item == mainIsland || item.Count == 0)
			{
				continue;
			}
			Vector3 val3 = GetBestReportPoint(tri, item, mainSearch);
			if (NavMesh.SamplePosition(val3, ref val4, 0.25f, -1))
			{
				val3 = val4.position;
			}
			bool flag = IsPathConnected(val, val3, -1);
			if (!flag)
			{
				GameObject val5 = null;
				if (Application.isEditor)
				{
					val5 = Object.Instantiate<GameObject>(AssetManager.instance.debugNavMeshError, val3, Quaternion.identity);
					DrawBoundsWire(ComputeIslandBounds(tri, item), flag ? Color.green : Color.red, 120f);
				}
				string text = "Navmesh: Unattached region: ";
				if (SemiFunc.GetModuleAtPosition(val3, out var module, out var localPosition))
				{
					text = text + "\n     Module Name: " + ((Object)module).name;
					text = text + "\n     Local Position: " + ((object)localPosition/*cast due to constrained. prefix*/).ToString();
				}
				else
				{
					text += "\n     Module Name: N/A";
					text = text + "\n     Position: " + ((object)val3/*cast due to constrained. prefix*/).ToString();
				}
				Debug.LogError((object)(text + "\n"), (Object)(object)val5);
			}
		}
	}

	private static Vector3 GetBestReportPoint(NavMeshTriangulation _tri, List<int> _island, VertexSearch _mainSearch)
	{
		//IL_0008: Unknown result type (might be due to invalid IL or missing references)
		//IL_0026: Unknown result type (might be due to invalid IL or missing references)
		//IL_002c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0037: Unknown result type (might be due to invalid IL or missing references)
		//IL_003c: Unknown result type (might be due to invalid IL or missing references)
		//IL_003f: Unknown result type (might be due to invalid IL or missing references)
		//IL_009b: Unknown result type (might be due to invalid IL or missing references)
		//IL_008d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0095: Unknown result type (might be due to invalid IL or missing references)
		//IL_0051: Unknown result type (might be due to invalid IL or missing references)
		//IL_0053: Unknown result type (might be due to invalid IL or missing references)
		//IL_005c: Unknown result type (might be due to invalid IL or missing references)
		//IL_005d: Unknown result type (might be due to invalid IL or missing references)
		//IL_009d: Unknown result type (might be due to invalid IL or missing references)
		float num = float.PositiveInfinity;
		Vector3 result = default;
		foreach (int item in _island)
		{
			int num2 = item * 3;
			for (int i = 0; i < 3; i++)
			{
				Vector3 val = _tri.vertices[_tri.indices[num2 + i]];
				float num3 = _mainSearch.DistanceSquared(val, num);
				if (!(num3 >= num))
				{
					num = num3;
					result = val;
					if (num <= 0f)
					{
						return result;
					}
				}
			}
		}
		if (!(num < float.PositiveInfinity))
		{
			return GetTriangleCentroid(_tri, _island[0]);
		}
		return result;
	}

	private static List<Vector3> GetTriangleVertices(NavMeshTriangulation _tri, List<int> _triangles)
	{
		//IL_002c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0044: Unknown result type (might be due to invalid IL or missing references)
		//IL_004c: Unknown result type (might be due to invalid IL or missing references)
		List<Vector3> list = new List<Vector3>(_triangles.Count * 3);
		HashSet<int> hashSet = new HashSet<int>();
		foreach (int _triangle in _triangles)
		{
			int num = _triangle * 3;
			for (int i = 0; i < 3; i++)
			{
				int num2 = _tri.indices[num + i];
				if (hashSet.Add(num2))
				{
					list.Add(_tri.vertices[num2]);
				}
			}
		}
		return list;
	}

	private static Vector3 GetTriangleCentroid(NavMeshTriangulation tri, int triIndex)
	{
		//IL_0004: Unknown result type (might be due to invalid IL or missing references)
		//IL_000a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0012: Unknown result type (might be due to invalid IL or missing references)
		//IL_0017: Unknown result type (might be due to invalid IL or missing references)
		//IL_001d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0027: Unknown result type (might be due to invalid IL or missing references)
		//IL_002c: Unknown result type (might be due to invalid IL or missing references)
		//IL_002d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0033: Unknown result type (might be due to invalid IL or missing references)
		//IL_003d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0042: Unknown result type (might be due to invalid IL or missing references)
		//IL_0043: Unknown result type (might be due to invalid IL or missing references)
		//IL_0044: Unknown result type (might be due to invalid IL or missing references)
		//IL_0049: Unknown result type (might be due to invalid IL or missing references)
		//IL_004a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0054: Unknown result type (might be due to invalid IL or missing references)
		int num = triIndex * 3;
		Vector3 val = tri.vertices[tri.indices[num]];
		Vector3 val2 = tri.vertices[tri.indices[num + 1]];
		Vector3 val3 = tri.vertices[tri.indices[num + 2]];
		return (val + val2 + val3) / 3f;
	}

	private static List<int> GetMainIsland(List<List<int>> islands)
	{
		List<int> list = null;
		for (int i = 0; i < islands.Count; i++)
		{
			List<int> list2 = islands[i];
			if (list == null || list2.Count > list.Count)
			{
				list = list2;
			}
		}
		return list;
	}

	private static List<List<int>> FindIslands(NavMeshTriangulation tri)
	{
		//IL_0000: Unknown result type (might be due to invalid IL or missing references)
		//IL_0012: Unknown result type (might be due to invalid IL or missing references)
		//IL_001e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0085: Unknown result type (might be due to invalid IL or missing references)
		//IL_0095: Unknown result type (might be due to invalid IL or missing references)
		int[] array = BuildWeldedVertexMap(tri.vertices, 0.05f);
		Dictionary<(int, int), List<int>> dictionary = BuildEdgeToTriangles(array, tri.indices);
		int num = tri.indices.Length / 3;
		HashSet<int> hashSet = new HashSet<int>();
		List<List<int>> list = new List<List<int>>();
		for (int i = 0; i < num; i++)
		{
			if (!hashSet.Add(i))
			{
				continue;
			}
			List<int> list2 = new List<int>();
			Stack<int> stack = new Stack<int>();
			stack.Push(i);
			while (stack.Count > 0)
			{
				int num2 = stack.Pop();
				list2.Add(num2);
				int num3 = num2 * 3;
				for (int j = 0; j < 3; j++)
				{
					int num4 = array[tri.indices[num3 + j]];
					int num5 = array[tri.indices[num3 + (j + 1) % 3]];
					if (num4 > num5)
					{
						int num6 = num4;
						num4 = num5;
						num5 = num6;
					}
					if (!dictionary.TryGetValue((num4, num5), out var value))
					{
						continue;
					}
					for (int k = 0; k < value.Count; k++)
					{
						int item = value[k];
						if (hashSet.Add(item))
						{
							stack.Push(item);
						}
					}
				}
			}
			list.Add(list2);
		}
		return list;
	}

	private static int[] BuildWeldedVertexMap(Vector3[] vertices, float epsilon)
	{
		//IL_0017: Unknown result type (might be due to invalid IL or missing references)
		//IL_001c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0020: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Unknown result type (might be due to invalid IL or missing references)
		//IL_003c: Unknown result type (might be due to invalid IL or missing references)
		Dictionary<(int, int, int), int> dictionary = new Dictionary<(int, int, int), int>();
		int[] array = new int[vertices.Length];
		int num = 0;
		for (int i = 0; i < vertices.Length; i++)
		{
			Vector3 val = vertices[i];
			(int, int, int) key = (Mathf.RoundToInt(val.x / epsilon), Mathf.RoundToInt(val.y / epsilon), Mathf.RoundToInt(val.z / epsilon));
			if (!dictionary.TryGetValue(key, out var value))
			{
				value = (dictionary[key] = num++);
			}
			array[i] = value;
		}
		return array;
	}

	private static Dictionary<(int, int), List<int>> BuildEdgeToTriangles(int[] vertexMap, int[] indices)
	{
		Dictionary<(int, int), List<int>> dictionary = new Dictionary<(int, int), List<int>>();
		for (int i = 0; i < indices.Length; i += 3)
		{
			int item = i / 3;
			for (int j = 0; j < 3; j++)
			{
				int num = vertexMap[indices[i + j]];
				int num2 = vertexMap[indices[i + (j + 1) % 3]];
				if (num > num2)
				{
					int num3 = num;
					num = num2;
					num2 = num3;
				}
				if (!dictionary.TryGetValue((num, num2), out var value))
				{
					value = new List<int>();
					dictionary[(num, num2)] = value;
				}
				value.Add(item);
			}
		}
		return dictionary;
	}

	private static bool IsPathConnected(Vector3 a, Vector3 b, int areaMask)
	{
		//IL_0000: Unknown result type (might be due to invalid IL or missing references)
		//IL_0012: Unknown result type (might be due to invalid IL or missing references)
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002a: Expected Obj, but got Unknown
		//IL_002c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0033: Unknown result type (might be due to invalid IL or missing references)
		//IL_0042: Unknown result type (might be due to invalid IL or missing references)
		//IL_0048: Invalid comparison between Unknown and I4
		NavMeshHit val = default;
		if (!NavMesh.SamplePosition(a, ref val, 2f, areaMask))
		{
			return false;
		}
		NavMeshHit val2 = default;
		if (!NavMesh.SamplePosition(b, ref val2, 2f, areaMask))
		{
			return false;
		}
		NavMeshPath val3 = new NavMeshPath();
		if (NavMesh.CalculatePath(val.position, val2.position, areaMask, val3))
		{
			return (int)val3.status == 0;
		}
		return false;
	}

	private static Bounds ComputeIslandBounds(NavMeshTriangulation tri, List<int> islandTris)
	{
		//IL_0004: Unknown result type (might be due to invalid IL or missing references)
		//IL_0009: Unknown result type (might be due to invalid IL or missing references)
		//IL_000e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0074: Unknown result type (might be due to invalid IL or missing references)
		//IL_0026: Unknown result type (might be due to invalid IL or missing references)
		//IL_002c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0037: Unknown result type (might be due to invalid IL or missing references)
		//IL_003c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0055: Unknown result type (might be due to invalid IL or missing references)
		//IL_0043: Unknown result type (might be due to invalid IL or missing references)
		//IL_0045: Unknown result type (might be due to invalid IL or missing references)
		//IL_004a: Unknown result type (might be due to invalid IL or missing references)
		bool flag = false;
		Bounds result = new Bounds(Vector3.zero, Vector3.zero);
		for (int i = 0; i < islandTris.Count; i++)
		{
			int num = islandTris[i] * 3;
			for (int j = 0; j < 3; j++)
			{
				Vector3 val = tri.vertices[tri.indices[num + j]];
				if (!flag)
				{
					result = new Bounds(val, Vector3.zero);
					flag = true;
				}
				else
				{
					result.Encapsulate(val);
				}
			}
		}
		return result;
	}

	private static void DrawBoundsWire(Bounds b, Color color, float duration)
	{
		//IL_0002: Unknown result type (might be due to invalid IL or missing references)
		//IL_0009: Unknown result type (might be due to invalid IL or missing references)
		//IL_000e: Unknown result type (might be due to invalid IL or missing references)
		//IL_000f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0010: Unknown result type (might be due to invalid IL or missing references)
		//IL_0017: Unknown result type (might be due to invalid IL or missing references)
		//IL_001e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0025: Unknown result type (might be due to invalid IL or missing references)
		//IL_002a: Unknown result type (might be due to invalid IL or missing references)
		//IL_002f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0030: Unknown result type (might be due to invalid IL or missing references)
		//IL_0031: Unknown result type (might be due to invalid IL or missing references)
		//IL_0038: Unknown result type (might be due to invalid IL or missing references)
		//IL_003f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0045: Unknown result type (might be due to invalid IL or missing references)
		//IL_004a: Unknown result type (might be due to invalid IL or missing references)
		//IL_004f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0050: Unknown result type (might be due to invalid IL or missing references)
		//IL_0051: Unknown result type (might be due to invalid IL or missing references)
		//IL_0058: Unknown result type (might be due to invalid IL or missing references)
		//IL_005e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0065: Unknown result type (might be due to invalid IL or missing references)
		//IL_006a: Unknown result type (might be due to invalid IL or missing references)
		//IL_006f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0070: Unknown result type (might be due to invalid IL or missing references)
		//IL_0071: Unknown result type (might be due to invalid IL or missing references)
		//IL_0078: Unknown result type (might be due to invalid IL or missing references)
		//IL_007e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0084: Unknown result type (might be due to invalid IL or missing references)
		//IL_0089: Unknown result type (might be due to invalid IL or missing references)
		//IL_008e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0090: Unknown result type (might be due to invalid IL or missing references)
		//IL_0091: Unknown result type (might be due to invalid IL or missing references)
		//IL_0097: Unknown result type (might be due to invalid IL or missing references)
		//IL_009e: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a5: Unknown result type (might be due to invalid IL or missing references)
		//IL_00aa: Unknown result type (might be due to invalid IL or missing references)
		//IL_00af: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b1: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b2: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b8: Unknown result type (might be due to invalid IL or missing references)
		//IL_00bf: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c5: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ca: Unknown result type (might be due to invalid IL or missing references)
		//IL_00cf: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d1: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d2: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d8: Unknown result type (might be due to invalid IL or missing references)
		//IL_00de: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e5: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ea: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ef: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f1: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f7: Unknown result type (might be due to invalid IL or missing references)
		//IL_00fd: Unknown result type (might be due to invalid IL or missing references)
		//IL_0103: Unknown result type (might be due to invalid IL or missing references)
		//IL_0108: Unknown result type (might be due to invalid IL or missing references)
		//IL_010d: Unknown result type (might be due to invalid IL or missing references)
		//IL_010e: Unknown result type (might be due to invalid IL or missing references)
		//IL_010f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0116: Unknown result type (might be due to invalid IL or missing references)
		//IL_0117: Unknown result type (might be due to invalid IL or missing references)
		//IL_0118: Unknown result type (might be due to invalid IL or missing references)
		//IL_011f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0120: Unknown result type (might be due to invalid IL or missing references)
		//IL_0122: Unknown result type (might be due to invalid IL or missing references)
		//IL_0129: Unknown result type (might be due to invalid IL or missing references)
		//IL_012a: Unknown result type (might be due to invalid IL or missing references)
		//IL_012c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0133: Unknown result type (might be due to invalid IL or missing references)
		//IL_0134: Unknown result type (might be due to invalid IL or missing references)
		//IL_0136: Unknown result type (might be due to invalid IL or missing references)
		//IL_013d: Unknown result type (might be due to invalid IL or missing references)
		//IL_013f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0146: Unknown result type (might be due to invalid IL or missing references)
		//IL_0147: Unknown result type (might be due to invalid IL or missing references)
		//IL_0149: Unknown result type (might be due to invalid IL or missing references)
		//IL_0150: Unknown result type (might be due to invalid IL or missing references)
		//IL_0151: Unknown result type (might be due to invalid IL or missing references)
		//IL_0153: Unknown result type (might be due to invalid IL or missing references)
		//IL_015a: Unknown result type (might be due to invalid IL or missing references)
		//IL_015b: Unknown result type (might be due to invalid IL or missing references)
		//IL_015d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0164: Unknown result type (might be due to invalid IL or missing references)
		//IL_0165: Unknown result type (might be due to invalid IL or missing references)
		//IL_0167: Unknown result type (might be due to invalid IL or missing references)
		//IL_016e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0170: Unknown result type (might be due to invalid IL or missing references)
		//IL_0172: Unknown result type (might be due to invalid IL or missing references)
		//IL_0179: Unknown result type (might be due to invalid IL or missing references)
		//IL_017b: Unknown result type (might be due to invalid IL or missing references)
		//IL_017d: Unknown result type (might be due to invalid IL or missing references)
		Vector3 center = b.center;
		Vector3 extents = b.extents;
		Vector3 val = center + new Vector3(0f - extents.x, 0f - extents.y, 0f - extents.z);
		Vector3 val2 = center + new Vector3(0f - extents.x, 0f - extents.y, extents.z);
		Vector3 val3 = center + new Vector3(0f - extents.x, extents.y, 0f - extents.z);
		Vector3 val4 = center + new Vector3(0f - extents.x, extents.y, extents.z);
		Vector3 val5 = center + new Vector3(extents.x, 0f - extents.y, 0f - extents.z);
		Vector3 val6 = center + new Vector3(extents.x, 0f - extents.y, extents.z);
		Vector3 val7 = center + new Vector3(extents.x, extents.y, 0f - extents.z);
		Vector3 val8 = center + new Vector3(extents.x, extents.y, extents.z);
		Debug.DrawLine(val, val2, color, duration);
		Debug.DrawLine(val, val3, color, duration);
		Debug.DrawLine(val, val5, color, duration);
		Debug.DrawLine(val8, val6, color, duration);
		Debug.DrawLine(val8, val7, color, duration);
		Debug.DrawLine(val8, val4, color, duration);
		Debug.DrawLine(val2, val4, color, duration);
		Debug.DrawLine(val2, val6, color, duration);
		Debug.DrawLine(val3, val4, color, duration);
		Debug.DrawLine(val3, val7, color, duration);
		Debug.DrawLine(val5, val6, color, duration);
		Debug.DrawLine(val5, val7, color, duration);
	}
}
