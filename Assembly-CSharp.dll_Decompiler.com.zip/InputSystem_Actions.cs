using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.InputSystem;
using UnityEngine.InputSystem.Utilities;

public class InputSystem_Actions : IInputActionCollection2, IInputActionCollection, IEnumerable<InputAction>, IEnumerable, IDisposable
{
	public struct PlayerActions(InputSystem_Actions wrapper)
	{
		private InputSystem_Actions m_Wrapper = wrapper;

		public InputAction Movement => m_Wrapper.m_Player_Movement;

		public InputAction MouseDelta => m_Wrapper.m_Player_MouseDelta;

		public InputAction Grab => m_Wrapper.m_Player_Grab;

		public InputAction Jump => m_Wrapper.m_Player_Jump;

		public InputAction Crouch => m_Wrapper.m_Player_Crouch;

		public InputAction Tumble => m_Wrapper.m_Player_Tumble;

		public InputAction Sprint => m_Wrapper.m_Player_Sprint;

		public InputAction Use => m_Wrapper.m_Player_Use;

		public InputAction Map => m_Wrapper.m_Player_Map;

		public InputAction Push => m_Wrapper.m_Player_Push;

		public InputAction Pull => m_Wrapper.m_Player_Pull;

		public InputAction Inventory1 => m_Wrapper.m_Player_Inventory1;

		public InputAction Inventory2 => m_Wrapper.m_Player_Inventory2;

		public InputAction Inventory3 => m_Wrapper.m_Player_Inventory3;

		public InputAction SpectateNext => m_Wrapper.m_Player_SpectateNext;

		public InputAction SpectatePrevious => m_Wrapper.m_Player_SpectatePrevious;

		public InputAction Rotate => m_Wrapper.m_Player_Rotate;

		public InputAction PushPull => m_Wrapper.m_Player_PushPull;

		public bool enabled => Get().enabled;

		public InputActionMap Get()
		{
			return m_Wrapper.m_Player;
		}

		public void Enable()
		{
			Get().Enable();
		}

		public void Disable()
		{
			Get().Disable();
		}

		public static implicit operator InputActionMap(PlayerActions set)
		{
			return set.Get();
		}

		public void AddCallbacks(IPlayerActions instance)
		{
			if (instance != null && !m_Wrapper.m_PlayerActionsCallbackInterfaces.Contains(instance))
			{
				m_Wrapper.m_PlayerActionsCallbackInterfaces.Add(instance);
				Movement.started += instance.OnMovement;
				Movement.performed += instance.OnMovement;
				Movement.canceled += instance.OnMovement;
				MouseDelta.started += instance.OnMouseDelta;
				MouseDelta.performed += instance.OnMouseDelta;
				MouseDelta.canceled += instance.OnMouseDelta;
				Grab.started += instance.OnGrab;
				Grab.performed += instance.OnGrab;
				Grab.canceled += instance.OnGrab;
				Jump.started += instance.OnJump;
				Jump.performed += instance.OnJump;
				Jump.canceled += instance.OnJump;
				Crouch.started += instance.OnCrouch;
				Crouch.performed += instance.OnCrouch;
				Crouch.canceled += instance.OnCrouch;
				Tumble.started += instance.OnTumble;
				Tumble.performed += instance.OnTumble;
				Tumble.canceled += instance.OnTumble;
				Sprint.started += instance.OnSprint;
				Sprint.performed += instance.OnSprint;
				Sprint.canceled += instance.OnSprint;
				Use.started += instance.OnUse;
				Use.performed += instance.OnUse;
				Use.canceled += instance.OnUse;
				Map.started += instance.OnMap;
				Map.performed += instance.OnMap;
				Map.canceled += instance.OnMap;
				Push.started += instance.OnPush;
				Push.performed += instance.OnPush;
				Push.canceled += instance.OnPush;
				Pull.started += instance.OnPull;
				Pull.performed += instance.OnPull;
				Pull.canceled += instance.OnPull;
				Inventory1.started += instance.OnInventory1;
				Inventory1.performed += instance.OnInventory1;
				Inventory1.canceled += instance.OnInventory1;
				Inventory2.started += instance.OnInventory2;
				Inventory2.performed += instance.OnInventory2;
				Inventory2.canceled += instance.OnInventory2;
				Inventory3.started += instance.OnInventory3;
				Inventory3.performed += instance.OnInventory3;
				Inventory3.canceled += instance.OnInventory3;
				SpectateNext.started += instance.OnSpectateNext;
				SpectateNext.performed += instance.OnSpectateNext;
				SpectateNext.canceled += instance.OnSpectateNext;
				SpectatePrevious.started += instance.OnSpectatePrevious;
				SpectatePrevious.performed += instance.OnSpectatePrevious;
				SpectatePrevious.canceled += instance.OnSpectatePrevious;
				Rotate.started += instance.OnRotate;
				Rotate.performed += instance.OnRotate;
				Rotate.canceled += instance.OnRotate;
				PushPull.started += instance.OnPushPull;
				PushPull.performed += instance.OnPushPull;
				PushPull.canceled += instance.OnPushPull;
			}
		}

		private void UnregisterCallbacks(IPlayerActions instance)
		{
			Movement.started -= instance.OnMovement;
			Movement.performed -= instance.OnMovement;
			Movement.canceled -= instance.OnMovement;
			MouseDelta.started -= instance.OnMouseDelta;
			MouseDelta.performed -= instance.OnMouseDelta;
			MouseDelta.canceled -= instance.OnMouseDelta;
			Grab.started -= instance.OnGrab;
			Grab.performed -= instance.OnGrab;
			Grab.canceled -= instance.OnGrab;
			Jump.started -= instance.OnJump;
			Jump.performed -= instance.OnJump;
			Jump.canceled -= instance.OnJump;
			Crouch.started -= instance.OnCrouch;
			Crouch.performed -= instance.OnCrouch;
			Crouch.canceled -= instance.OnCrouch;
			Tumble.started -= instance.OnTumble;
			Tumble.performed -= instance.OnTumble;
			Tumble.canceled -= instance.OnTumble;
			Sprint.started -= instance.OnSprint;
			Sprint.performed -= instance.OnSprint;
			Sprint.canceled -= instance.OnSprint;
			Use.started -= instance.OnUse;
			Use.performed -= instance.OnUse;
			Use.canceled -= instance.OnUse;
			Map.started -= instance.OnMap;
			Map.performed -= instance.OnMap;
			Map.canceled -= instance.OnMap;
			Push.started -= instance.OnPush;
			Push.performed -= instance.OnPush;
			Push.canceled -= instance.OnPush;
			Pull.started -= instance.OnPull;
			Pull.performed -= instance.OnPull;
			Pull.canceled -= instance.OnPull;
			Inventory1.started -= instance.OnInventory1;
			Inventory1.performed -= instance.OnInventory1;
			Inventory1.canceled -= instance.OnInventory1;
			Inventory2.started -= instance.OnInventory2;
			Inventory2.performed -= instance.OnInventory2;
			Inventory2.canceled -= instance.OnInventory2;
			Inventory3.started -= instance.OnInventory3;
			Inventory3.performed -= instance.OnInventory3;
			Inventory3.canceled -= instance.OnInventory3;
			SpectateNext.started -= instance.OnSpectateNext;
			SpectateNext.performed -= instance.OnSpectateNext;
			SpectateNext.canceled -= instance.OnSpectateNext;
			SpectatePrevious.started -= instance.OnSpectatePrevious;
			SpectatePrevious.performed -= instance.OnSpectatePrevious;
			SpectatePrevious.canceled -= instance.OnSpectatePrevious;
			Rotate.started -= instance.OnRotate;
			Rotate.performed -= instance.OnRotate;
			Rotate.canceled -= instance.OnRotate;
			PushPull.started -= instance.OnPushPull;
			PushPull.performed -= instance.OnPushPull;
			PushPull.canceled -= instance.OnPushPull;
		}

		public void RemoveCallbacks(IPlayerActions instance)
		{
			if (m_Wrapper.m_PlayerActionsCallbackInterfaces.Remove(instance))
			{
				UnregisterCallbacks(instance);
			}
		}

		public void SetCallbacks(IPlayerActions instance)
		{
			foreach (IPlayerActions playerActionsCallbackInterface in m_Wrapper.m_PlayerActionsCallbackInterfaces)
			{
				UnregisterCallbacks(playerActionsCallbackInterface);
			}
			m_Wrapper.m_PlayerActionsCallbackInterfaces.Clear();
			AddCallbacks(instance);
		}
	}

	public struct UIActions(InputSystem_Actions wrapper)
	{
		private InputSystem_Actions m_Wrapper = wrapper;

		public InputAction Navigate => m_Wrapper.m_UI_Navigate;

		public InputAction Click => m_Wrapper.m_UI_Click;

		public InputAction TabLeft => m_Wrapper.m_UI_TabLeft;

		public InputAction TabRight => m_Wrapper.m_UI_TabRight;

		public bool enabled => Get().enabled;

		public InputActionMap Get()
		{
			return m_Wrapper.m_UI;
		}

		public void Enable()
		{
			Get().Enable();
		}

		public void Disable()
		{
			Get().Disable();
		}

		public static implicit operator InputActionMap(UIActions set)
		{
			return set.Get();
		}

		public void AddCallbacks(IUIActions instance)
		{
			if (instance != null && !m_Wrapper.m_UIActionsCallbackInterfaces.Contains(instance))
			{
				m_Wrapper.m_UIActionsCallbackInterfaces.Add(instance);
				Navigate.started += instance.OnNavigate;
				Navigate.performed += instance.OnNavigate;
				Navigate.canceled += instance.OnNavigate;
				Click.started += instance.OnClick;
				Click.performed += instance.OnClick;
				Click.canceled += instance.OnClick;
				TabLeft.started += instance.OnTabLeft;
				TabLeft.performed += instance.OnTabLeft;
				TabLeft.canceled += instance.OnTabLeft;
				TabRight.started += instance.OnTabRight;
				TabRight.performed += instance.OnTabRight;
				TabRight.canceled += instance.OnTabRight;
			}
		}

		private void UnregisterCallbacks(IUIActions instance)
		{
			Navigate.started -= instance.OnNavigate;
			Navigate.performed -= instance.OnNavigate;
			Navigate.canceled -= instance.OnNavigate;
			Click.started -= instance.OnClick;
			Click.performed -= instance.OnClick;
			Click.canceled -= instance.OnClick;
			TabLeft.started -= instance.OnTabLeft;
			TabLeft.performed -= instance.OnTabLeft;
			TabLeft.canceled -= instance.OnTabLeft;
			TabRight.started -= instance.OnTabRight;
			TabRight.performed -= instance.OnTabRight;
			TabRight.canceled -= instance.OnTabRight;
		}

		public void RemoveCallbacks(IUIActions instance)
		{
			if (m_Wrapper.m_UIActionsCallbackInterfaces.Remove(instance))
			{
				UnregisterCallbacks(instance);
			}
		}

		public void SetCallbacks(IUIActions instance)
		{
			foreach (IUIActions uIActionsCallbackInterface in m_Wrapper.m_UIActionsCallbackInterfaces)
			{
				UnregisterCallbacks(uIActionsCallbackInterface);
			}
			m_Wrapper.m_UIActionsCallbackInterfaces.Clear();
			AddCallbacks(instance);
		}
	}

	public struct ApplicationActions(InputSystem_Actions wrapper)
	{
		private InputSystem_Actions m_Wrapper = wrapper;

		public InputAction BackEditor => m_Wrapper.m_Application_BackEditor;

		public InputAction Menu => m_Wrapper.m_Application_Menu;

		public InputAction Back => m_Wrapper.m_Application_Back;

		public InputAction DebugConsole => m_Wrapper.m_Application_DebugConsole;

		public InputAction Chat => m_Wrapper.m_Application_Chat;

		public InputAction ChatConfirm => m_Wrapper.m_Application_ChatConfirm;

		public InputAction ChatDelete => m_Wrapper.m_Application_ChatDelete;

		public InputAction PushToTalk => m_Wrapper.m_Application_PushToTalk;

		public InputAction ToggleMute => m_Wrapper.m_Application_ToggleMute;

		public bool enabled => Get().enabled;

		public InputActionMap Get()
		{
			return m_Wrapper.m_Application;
		}

		public void Enable()
		{
			Get().Enable();
		}

		public void Disable()
		{
			Get().Disable();
		}

		public static implicit operator InputActionMap(ApplicationActions set)
		{
			return set.Get();
		}

		public void AddCallbacks(IApplicationActions instance)
		{
			if (instance != null && !m_Wrapper.m_ApplicationActionsCallbackInterfaces.Contains(instance))
			{
				m_Wrapper.m_ApplicationActionsCallbackInterfaces.Add(instance);
				BackEditor.started += instance.OnBackEditor;
				BackEditor.performed += instance.OnBackEditor;
				BackEditor.canceled += instance.OnBackEditor;
				Menu.started += instance.OnMenu;
				Menu.performed += instance.OnMenu;
				Menu.canceled += instance.OnMenu;
				Back.started += instance.OnBack;
				Back.performed += instance.OnBack;
				Back.canceled += instance.OnBack;
				DebugConsole.started += instance.OnDebugConsole;
				DebugConsole.performed += instance.OnDebugConsole;
				DebugConsole.canceled += instance.OnDebugConsole;
				Chat.started += instance.OnChat;
				Chat.performed += instance.OnChat;
				Chat.canceled += instance.OnChat;
				ChatConfirm.started += instance.OnChatConfirm;
				ChatConfirm.performed += instance.OnChatConfirm;
				ChatConfirm.canceled += instance.OnChatConfirm;
				ChatDelete.started += instance.OnChatDelete;
				ChatDelete.performed += instance.OnChatDelete;
				ChatDelete.canceled += instance.OnChatDelete;
				PushToTalk.started += instance.OnPushToTalk;
				PushToTalk.performed += instance.OnPushToTalk;
				PushToTalk.canceled += instance.OnPushToTalk;
				ToggleMute.started += instance.OnToggleMute;
				ToggleMute.performed += instance.OnToggleMute;
				ToggleMute.canceled += instance.OnToggleMute;
			}
		}

		private void UnregisterCallbacks(IApplicationActions instance)
		{
			BackEditor.started -= instance.OnBackEditor;
			BackEditor.performed -= instance.OnBackEditor;
			BackEditor.canceled -= instance.OnBackEditor;
			Menu.started -= instance.OnMenu;
			Menu.performed -= instance.OnMenu;
			Menu.canceled -= instance.OnMenu;
			Back.started -= instance.OnBack;
			Back.performed -= instance.OnBack;
			Back.canceled -= instance.OnBack;
			DebugConsole.started -= instance.OnDebugConsole;
			DebugConsole.performed -= instance.OnDebugConsole;
			DebugConsole.canceled -= instance.OnDebugConsole;
			Chat.started -= instance.OnChat;
			Chat.performed -= instance.OnChat;
			Chat.canceled -= instance.OnChat;
			ChatConfirm.started -= instance.OnChatConfirm;
			ChatConfirm.performed -= instance.OnChatConfirm;
			ChatConfirm.canceled -= instance.OnChatConfirm;
			ChatDelete.started -= instance.OnChatDelete;
			ChatDelete.performed -= instance.OnChatDelete;
			ChatDelete.canceled -= instance.OnChatDelete;
			PushToTalk.started -= instance.OnPushToTalk;
			PushToTalk.performed -= instance.OnPushToTalk;
			PushToTalk.canceled -= instance.OnPushToTalk;
			ToggleMute.started -= instance.OnToggleMute;
			ToggleMute.performed -= instance.OnToggleMute;
			ToggleMute.canceled -= instance.OnToggleMute;
		}

		public void RemoveCallbacks(IApplicationActions instance)
		{
			if (m_Wrapper.m_ApplicationActionsCallbackInterfaces.Remove(instance))
			{
				UnregisterCallbacks(instance);
			}
		}

		public void SetCallbacks(IApplicationActions instance)
		{
			foreach (IApplicationActions applicationActionsCallbackInterface in m_Wrapper.m_ApplicationActionsCallbackInterfaces)
			{
				UnregisterCallbacks(applicationActionsCallbackInterface);
			}
			m_Wrapper.m_ApplicationActionsCallbackInterfaces.Clear();
			AddCallbacks(instance);
		}
	}

	public interface IPlayerActions
	{
		void OnMovement(CallbackContext context);

		void OnMouseDelta(CallbackContext context);

		void OnGrab(CallbackContext context);

		void OnJump(CallbackContext context);

		void OnCrouch(CallbackContext context);

		void OnTumble(CallbackContext context);

		void OnSprint(CallbackContext context);

		void OnUse(CallbackContext context);

		void OnMap(CallbackContext context);

		void OnPush(CallbackContext context);

		void OnPull(CallbackContext context);

		void OnInventory1(CallbackContext context);

		void OnInventory2(CallbackContext context);

		void OnInventory3(CallbackContext context);

		void OnSpectateNext(CallbackContext context);

		void OnSpectatePrevious(CallbackContext context);

		void OnRotate(CallbackContext context);

		void OnPushPull(CallbackContext context);
	}

	public interface IUIActions
	{
		void OnNavigate(CallbackContext context);

		void OnClick(CallbackContext context);

		void OnTabLeft(CallbackContext context);

		void OnTabRight(CallbackContext context);
	}

	public interface IApplicationActions
	{
		void OnBackEditor(CallbackContext context);

		void OnMenu(CallbackContext context);

		void OnBack(CallbackContext context);

		void OnDebugConsole(CallbackContext context);

		void OnChat(CallbackContext context);

		void OnChatConfirm(CallbackContext context);

		void OnChatDelete(CallbackContext context);

		void OnPushToTalk(CallbackContext context);

		void OnToggleMute(CallbackContext context);
	}

	private readonly InputActionMap m_Player;

	private List<IPlayerActions> m_PlayerActionsCallbackInterfaces = new List<IPlayerActions>();

	private readonly InputAction m_Player_Movement;

	private readonly InputAction m_Player_MouseDelta;

	private readonly InputAction m_Player_Grab;

	private readonly InputAction m_Player_Jump;

	private readonly InputAction m_Player_Crouch;

	private readonly InputAction m_Player_Tumble;

	private readonly InputAction m_Player_Sprint;

	private readonly InputAction m_Player_Use;

	private readonly InputAction m_Player_Map;

	private readonly InputAction m_Player_Push;

	private readonly InputAction m_Player_Pull;

	private readonly InputAction m_Player_Inventory1;

	private readonly InputAction m_Player_Inventory2;

	private readonly InputAction m_Player_Inventory3;

	private readonly InputAction m_Player_SpectateNext;

	private readonly InputAction m_Player_SpectatePrevious;

	private readonly InputAction m_Player_Rotate;

	private readonly InputAction m_Player_PushPull;

	private readonly InputActionMap m_UI;

	private List<IUIActions> m_UIActionsCallbackInterfaces = new List<IUIActions>();

	private readonly InputAction m_UI_Navigate;

	private readonly InputAction m_UI_Click;

	private readonly InputAction m_UI_TabLeft;

	private readonly InputAction m_UI_TabRight;

	private readonly InputActionMap m_Application;

	private List<IApplicationActions> m_ApplicationActionsCallbackInterfaces = new List<IApplicationActions>();

	private readonly InputAction m_Application_BackEditor;

	private readonly InputAction m_Application_Menu;

	private readonly InputAction m_Application_Back;

	private readonly InputAction m_Application_DebugConsole;

	private readonly InputAction m_Application_Chat;

	private readonly InputAction m_Application_ChatConfirm;

	private readonly InputAction m_Application_ChatDelete;

	private readonly InputAction m_Application_PushToTalk;

	private readonly InputAction m_Application_ToggleMute;

	private int m_KeyboardMouseSchemeIndex = -1;

	private int m_GamepadSchemeIndex = -1;

	private int m_TouchSchemeIndex = -1;

	private int m_JoystickSchemeIndex = -1;

	private int m_XRSchemeIndex = -1;

	public InputActionAsset asset { get; }

	public Nullable bindingMask
	{
		get
		{
			return asset.bindingMask;
		}
		set
		{
			asset.bindingMask = value;
		}
	}

	public Nullable devices
	{
		get
		{
			return asset.devices;
		}
		set
		{
			asset.devices = value;
		}
	}

	public ReadOnlyArray<InputControlScheme> controlSchemes
	{
		get
		{
			//IL_0006: Unknown result type (might be due to invalid IL or missing references)
			return asset.controlSchemes;
		}
	}

	public IEnumerable<InputBinding> bindings => asset.bindings;

	public PlayerActions Player => new PlayerActions(this);

	public UIActions UI => new UIActions(this);

	public ApplicationActions Application => new ApplicationActions(this);

	public InputControlScheme KeyboardMouseScheme
	{
		get
		{
			//IL_0025: Unknown result type (might be due to invalid IL or missing references)
			//IL_002a: Unknown result type (might be due to invalid IL or missing references)
			//IL_0033: Unknown result type (might be due to invalid IL or missing references)
			if (m_KeyboardMouseSchemeIndex == -1)
			{
				m_KeyboardMouseSchemeIndex = asset.FindControlSchemeIndex("Keyboard&Mouse");
			}
			return asset.controlSchemes[m_KeyboardMouseSchemeIndex];
		}
	}

	public InputControlScheme GamepadScheme
	{
		get
		{
			//IL_0025: Unknown result type (might be due to invalid IL or missing references)
			//IL_002a: Unknown result type (might be due to invalid IL or missing references)
			//IL_0033: Unknown result type (might be due to invalid IL or missing references)
			if (m_GamepadSchemeIndex == -1)
			{
				m_GamepadSchemeIndex = asset.FindControlSchemeIndex("Gamepad");
			}
			return asset.controlSchemes[m_GamepadSchemeIndex];
		}
	}

	public InputControlScheme TouchScheme
	{
		get
		{
			//IL_0025: Unknown result type (might be due to invalid IL or missing references)
			//IL_002a: Unknown result type (might be due to invalid IL or missing references)
			//IL_0033: Unknown result type (might be due to invalid IL or missing references)
			if (m_TouchSchemeIndex == -1)
			{
				m_TouchSchemeIndex = asset.FindControlSchemeIndex("Touch");
			}
			return asset.controlSchemes[m_TouchSchemeIndex];
		}
	}

	public InputControlScheme JoystickScheme
	{
		get
		{
			//IL_0025: Unknown result type (might be due to invalid IL or missing references)
			//IL_002a: Unknown result type (might be due to invalid IL or missing references)
			//IL_0033: Unknown result type (might be due to invalid IL or missing references)
			if (m_JoystickSchemeIndex == -1)
			{
				m_JoystickSchemeIndex = asset.FindControlSchemeIndex("Joystick");
			}
			return asset.controlSchemes[m_JoystickSchemeIndex];
		}
	}

	public InputControlScheme XRScheme
	{
		get
		{
			//IL_0025: Unknown result type (might be due to invalid IL or missing references)
			//IL_002a: Unknown result type (might be due to invalid IL or missing references)
			//IL_0033: Unknown result type (might be due to invalid IL or missing references)
			if (m_XRSchemeIndex == -1)
			{
				m_XRSchemeIndex = asset.FindControlSchemeIndex("XR");
			}
			return asset.controlSchemes[m_XRSchemeIndex];
		}
	}

	public InputSystem_Actions()
	{
		asset = InputActionAsset.FromJson("{\r\n    \"version\": 1,\r\n    \"name\": \"InputSystem_Actions\",\r\n    \"maps\": [\r\n        {\r\n            \"name\": \"Player\",\r\n            \"id\": \"df70fa95-8a34-4494-b137-73ab6b9c7d37\",\r\n            \"actions\": [\r\n                {\r\n                    \"name\": \"Movement\",\r\n                    \"type\": \"Value\",\r\n                    \"id\": \"351f2ccd-1f9f-44bf-9bec-d62ac5c5f408\",\r\n                    \"expectedControlType\": \"Vector2\",\r\n                    \"processors\": \"\",\r\n                    \"interactions\": \"\",\r\n                    \"initialStateCheck\": true,\r\n                    \"priority\": 0\r\n                },\r\n                {\r\n                    \"name\": \"MouseDelta\",\r\n                    \"type\": \"Value\",\r\n                    \"id\": \"6b444451-8a00-4d00-a97e-f47457f736a8\",\r\n                    \"expectedControlType\": \"Vector2\",\r\n                    \"processors\": \"\",\r\n                    \"interactions\": \"\",\r\n                    \"initialStateCheck\": true,\r\n                    \"priority\": 0\r\n                },\r\n                {\r\n                    \"name\": \"Grab\",\r\n                    \"type\": \"Value\",\r\n                    \"id\": \"824b0006-f341-4fd5-a34a-b5f5f3c45773\",\r\n                    \"expectedControlType\": \"\",\r\n                    \"processors\": \"\",\r\n                    \"interactions\": \"\",\r\n                    \"initialStateCheck\": true,\r\n                    \"priority\": 0\r\n                },\r\n                {\r\n                    \"name\": \"Jump\",\r\n                    \"type\": \"Value\",\r\n                    \"id\": \"f1ba0d36-48eb-4cd5-b651-1c94a6531f70\",\r\n                    \"expectedControlType\": \"\",\r\n                    \"processors\": \"\",\r\n                    \"interactions\": \"\",\r\n                    \"initialStateCheck\": true,\r\n                    \"priority\": 0\r\n                },\r\n                {\r\n                    \"name\": \"Crouch\",\r\n                    \"type\": \"Value\",\r\n                    \"id\": \"27c5f898-bc57-4ee1-8800-db469aca5fe3\",\r\n                    \"expectedControlType\": \"\",\r\n                    \"processors\": \"\",\r\n                    \"interactions\": \"\",\r\n                    \"initialStateCheck\": true,\r\n                    \"priority\": 0\r\n                },\r\n                {\r\n                    \"name\": \"Tumble\",\r\n                    \"type\": \"Value\",\r\n                    \"id\": \"423c09b5-b568-4a42-bd23-11ae77d033a9\",\r\n                    \"expectedControlType\": \"\",\r\n                    \"processors\": \"\",\r\n                    \"interactions\": \"\",\r\n                    \"initialStateCheck\": true,\r\n                    \"priority\": 0\r\n                },\r\n                {\r\n                    \"name\": \"Sprint\",\r\n                    \"type\": \"Value\",\r\n                    \"id\": \"641cd816-40e6-41b4-8c3d-04687c349290\",\r\n                    \"expectedControlType\": \"\",\r\n                    \"processors\": \"\",\r\n                    \"interactions\": \"\",\r\n                    \"initialStateCheck\": true,\r\n                    \"priority\": 0\r\n                },\r\n                {\r\n                    \"name\": \"Use\",\r\n                    \"type\": \"Value\",\r\n                    \"id\": \"852140f2-7766-474d-8707-702459ba45f3\",\r\n                    \"expectedControlType\": \"\",\r\n                    \"processors\": \"\",\r\n                    \"interactions\": \"\",\r\n                    \"initialStateCheck\": true,\r\n                    \"priority\": 0\r\n                },\r\n                {\r\n                    \"name\": \"Map\",\r\n                    \"type\": \"Value\",\r\n                    \"id\": \"89d60f52-2aa9-4874-8fad-8ce00c7b7041\",\r\n                    \"expectedControlType\": \"\",\r\n                    \"processors\": \"\",\r\n                    \"interactions\": \"\",\r\n                    \"initialStateCheck\": true,\r\n                    \"priority\": 0\r\n                },\r\n                {\r\n                    \"name\": \"Push\",\r\n                    \"type\": \"Value\",\r\n                    \"id\": \"99a647a4-e053-4edb-84e1-052362ecac69\",\r\n                    \"expectedControlType\": \"\",\r\n                    \"processors\": \"\",\r\n                    \"interactions\": \"\",\r\n                    \"initialStateCheck\": true,\r\n                    \"priority\": 0\r\n                },\r\n                {\r\n                    \"name\": \"Pull\",\r\n                    \"type\": \"Value\",\r\n                    \"id\": \"50f7f4fc-64d6-4283-b7e9-bdce86dea5a0\",\r\n                    \"expectedControlType\": \"\",\r\n                    \"processors\": \"\",\r\n                    \"interactions\": \"\",\r\n                    \"initialStateCheck\": true,\r\n                    \"priority\": 0\r\n                },\r\n                {\r\n                    \"name\": \"Inventory1\",\r\n                    \"type\": \"Value\",\r\n                    \"id\": \"cb1d3cfb-2f35-4787-bd55-9915ba223df4\",\r\n                    \"expectedControlType\": \"\",\r\n                    \"processors\": \"\",\r\n                    \"interactions\": \"\",\r\n                    \"initialStateCheck\": true,\r\n                    \"priority\": 0\r\n                },\r\n                {\r\n                    \"name\": \"Inventory2\",\r\n                    \"type\": \"Value\",\r\n                    \"id\": \"1a85d258-e3bc-4621-b15a-875cee269caa\",\r\n                    \"expectedControlType\": \"\",\r\n                    \"processors\": \"\",\r\n                    \"interactions\": \"\",\r\n                    \"initialStateCheck\": true,\r\n                    \"priority\": 0\r\n                },\r\n                {\r\n                    \"name\": \"Inventory3\",\r\n                    \"type\": \"Value\",\r\n                    \"id\": \"84abe856-80a8-497b-8c43-7e8d199a1286\",\r\n                    \"expectedControlType\": \"\",\r\n                    \"processors\": \"\",\r\n                    \"interactions\": \"\",\r\n                    \"initialStateCheck\": true,\r\n                    \"priority\": 0\r\n                },\r\n                {\r\n                    \"name\": \"SpectateNext\",\r\n                    \"type\": \"Value\",\r\n                    \"id\": \"af1aa91c-a4d7-4ad9-9053-a8d43514f940\",\r\n                    \"expectedControlType\": \"\",\r\n                    \"processors\": \"\",\r\n                    \"interactions\": \"\",\r\n                    \"initialStateCheck\": true,\r\n                    \"priority\": 0\r\n                },\r\n                {\r\n                    \"name\": \"SpectatePrevious\",\r\n                    \"type\": \"Value\",\r\n                    \"id\": \"257b170f-e36b-44de-9606-2edb4c2ff6ec\",\r\n                    \"expectedControlType\": \"\",\r\n                    \"processors\": \"\",\r\n                    \"interactions\": \"\",\r\n                    \"initialStateCheck\": true,\r\n                    \"priority\": 0\r\n                },\r\n                {\r\n                    \"name\": \"Rotate\",\r\n                    \"type\": \"Value\",\r\n                    \"id\": \"da38f63f-f08f-45b6-8192-c2092b973985\",\r\n                    \"expectedControlType\": \"\",\r\n                    \"processors\": \"\",\r\n                    \"interactions\": \"\",\r\n                    \"initialStateCheck\": true,\r\n                    \"priority\": 0\r\n                },\r\n                {\r\n                    \"name\": \"PushPull\",\r\n                    \"type\": \"Button\",\r\n                    \"id\": \"d044071b-b32b-4812-8821-bbb02121cb4f\",\r\n                    \"expectedControlType\": \"\",\r\n                    \"processors\": \"\",\r\n                    \"interactions\": \"\",\r\n                    \"initialStateCheck\": false,\r\n                    \"priority\": 0\r\n                }\r\n            ],\r\n            \"bindings\": [\r\n                {\r\n                    \"name\": \"WASD\",\r\n                    \"id\": \"00ca640b-d935-4593-8157-c05846ea39b3\",\r\n                    \"path\": \"Dpad\",\r\n                    \"interactions\": \"\",\r\n                    \"processors\": \"\",\r\n                    \"groups\": \"\",\r\n                    \"action\": \"Movement\",\r\n                    \"isComposite\": true,\r\n                    \"isPartOfComposite\": false\r\n                },\r\n                {\r\n                    \"name\": \"up\",\r\n                    \"id\": \"e2062cb9-1b15-46a2-838c-2f8d72a0bdd9\",\r\n                    \"path\": \"<Keyboard>/w\",\r\n                    \"interactions\": \"\",\r\n                    \"processors\": \"\",\r\n                    \"groups\": \";Keyboard&Mouse\",\r\n                    \"action\": \"Movement\",\r\n                    \"isComposite\": false,\r\n                    \"isPartOfComposite\": true\r\n                },\r\n                {\r\n                    \"name\": \"down\",\r\n                    \"id\": \"320bffee-a40b-4347-ac70-c210eb8bc73a\",\r\n                    \"path\": \"<Keyboard>/s\",\r\n                    \"interactions\": \"\",\r\n                    \"processors\": \"\",\r\n                    \"groups\": \";Keyboard&Mouse\",\r\n                    \"action\": \"Movement\",\r\n                    \"isComposite\": false,\r\n                    \"isPartOfComposite\": true\r\n                },\r\n                {\r\n                    \"name\": \"left\",\r\n                    \"id\": \"d2581a9b-1d11-4566-b27d-b92aff5fabbc\",\r\n                    \"path\": \"<Keyboard>/a\",\r\n                    \"interactions\": \"\",\r\n                    \"processors\": \"\",\r\n                    \"groups\": \";Keyboard&Mouse\",\r\n                    \"action\": \"Movement\",\r\n                    \"isComposite\": false,\r\n                    \"isPartOfComposite\": true\r\n                },\r\n                {\r\n                    \"name\": \"right\",\r\n                    \"id\": \"fcfe95b8-67b9-4526-84b5-5d0bc98d6400\",\r\n                    \"path\": \"<Keyboard>/d\",\r\n                    \"interactions\": \"\",\r\n                    \"processors\": \"\",\r\n                    \"groups\": \";Keyboard&Mouse\",\r\n                    \"action\": \"Movement\",\r\n                    \"isComposite\": false,\r\n                    \"isPartOfComposite\": true\r\n                },\r\n                {\r\n                    \"name\": \"\",\r\n                    \"id\": \"978bfe49-cc26-4a3d-ab7b-7d7a29327403\",\r\n                    \"path\": \"<Gamepad>/leftStick\",\r\n                    \"interactions\": \"\",\r\n                    \"processors\": \"\",\r\n                    \"groups\": \";Gamepad\",\r\n                    \"action\": \"Movement\",\r\n                    \"isComposite\": false,\r\n                    \"isPartOfComposite\": false\r\n                },\r\n                {\r\n                    \"name\": \"\",\r\n                    \"id\": \"8c8e490b-c610-4785-884f-f04217b23ca4\",\r\n                    \"path\": \"<Pointer>/delta\",\r\n                    \"interactions\": \"\",\r\n                    \"processors\": \"\",\r\n                    \"groups\": \";Keyboard&Mouse;Touch\",\r\n                    \"action\": \"MouseDelta\",\r\n                    \"isComposite\": false,\r\n                    \"isPartOfComposite\": false\r\n                },\r\n                {\r\n                    \"name\": \"\",\r\n                    \"id\": \"c1f7a91b-d0fd-4a62-997e-7fb9b69bf235\",\r\n                    \"path\": \"<Gamepad>/rightStick\",\r\n                    \"interactions\": \"\",\r\n                    \"processors\": \"ScaleVector2(x=10,y=10)\",\r\n                    \"groups\": \";Gamepad\",\r\n                    \"action\": \"MouseDelta\",\r\n                    \"isComposite\": false,\r\n                    \"isPartOfComposite\": false\r\n                },\r\n                {\r\n                    \"name\": \"\",\r\n                    \"id\": \"f2e9ba44-c423-42a7-ad56-f20975884794\",\r\n                    \"path\": \"<Keyboard>/leftShift\",\r\n                    \"interactions\": \"\",\r\n                    \"processors\": \"\",\r\n                    \"groups\": \"Keyboard&Mouse\",\r\n                    \"action\": \"Sprint\",\r\n                    \"isComposite\": false,\r\n                    \"isPartOfComposite\": false\r\n                },\r\n                {\r\n                    \"name\": \"\",\r\n                    \"id\": \"8cbb2f4b-a784-49cc-8d5e-c010b8c7f4e6\",\r\n                    \"path\": \"<Gamepad>/leftStickPress\",\r\n                    \"interactions\": \"\",\r\n                    \"processors\": \"\",\r\n                    \"groups\": \"Gamepad\",\r\n                    \"action\": \"Sprint\",\r\n                    \"isComposite\": false,\r\n                    \"isPartOfComposite\": false\r\n                },\r\n                {\r\n                    \"name\": \"\",\r\n                    \"id\": \"eb40bb66-4559-4dfa-9a2f-820438abb426\",\r\n                    \"path\": \"<Keyboard>/space\",\r\n                    \"interactions\": \"\",\r\n                    \"processors\": \"\",\r\n                    \"groups\": \"Keyboard&Mouse\",\r\n                    \"action\": \"Jump\",\r\n                    \"isComposite\": false,\r\n                    \"isPartOfComposite\": false\r\n                },\r\n                {\r\n                    \"name\": \"\",\r\n                    \"id\": \"daba33a1-ad0c-4742-a909-43ad1cdfbeb6\",\r\n                    \"path\": \"<Gamepad>/buttonSouth\",\r\n                    \"interactions\": \"\",\r\n                    \"processors\": \"\",\r\n                    \"groups\": \"Gamepad\",\r\n                    \"action\": \"Jump\",\r\n                    \"isComposite\": false,\r\n                    \"isPartOfComposite\": false\r\n                },\r\n                {\r\n                    \"name\": \"\",\r\n                    \"id\": \"1c04ea5f-b012-41d1-a6f7-02e963b52893\",\r\n                    \"path\": \"<Keyboard>/e\",\r\n                    \"interactions\": \"\",\r\n                    \"processors\": \"\",\r\n                    \"groups\": \"Keyboard&Mouse\",\r\n                    \"action\": \"Use\",\r\n                    \"isComposite\": false,\r\n                    \"isPartOfComposite\": false\r\n                },\r\n                {\r\n                    \"name\": \"\",\r\n                    \"id\": \"b3f66d0b-7751-423f-908b-a11c5bd95930\",\r\n                    \"path\": \"<Gamepad>/buttonWest\",\r\n                    \"interactions\": \"\",\r\n                    \"processors\": \"\",\r\n                    \"groups\": \"Gamepad\",\r\n                    \"action\": \"Use\",\r\n                    \"isComposite\": false,\r\n                    \"isPartOfComposite\": false\r\n                },\r\n                {\r\n                    \"name\": \"\",\r\n                    \"id\": \"36e52cba-0905-478e-a818-f4bfcb9f3b9a\",\r\n                    \"path\": \"<Keyboard>/ctrl\",\r\n                    \"interactions\": \"\",\r\n                    \"processors\": \"\",\r\n                    \"groups\": \"Keyboard&Mouse\",\r\n                    \"action\": \"Crouch\",\r\n                    \"isComposite\": false,\r\n                    \"isPartOfComposite\": false\r\n                },\r\n                {\r\n                    \"name\": \"\",\r\n                    \"id\": \"4f4649ac-64a8-4a73-af11-b3faef356a4d\",\r\n                    \"path\": \"<Gamepad>/rightStickPress\",\r\n                    \"interactions\": \"\",\r\n                    \"processors\": \"\",\r\n                    \"groups\": \"Gamepad\",\r\n                    \"action\": \"Crouch\",\r\n                    \"isComposite\": false,\r\n                    \"isPartOfComposite\": false\r\n                },\r\n                {\r\n                    \"name\": \"\",\r\n                    \"id\": \"6de035dc-cc4e-445a-9cf7-1305a3fab413\",\r\n                    \"path\": \"<Keyboard>/tab\",\r\n                    \"interactions\": \"\",\r\n                    \"processors\": \"\",\r\n                    \"groups\": \";Keyboard&Mouse\",\r\n                    \"action\": \"Map\",\r\n                    \"isComposite\": false,\r\n                    \"isPartOfComposite\": false\r\n                },\r\n                {\r\n                    \"name\": \"\",\r\n                    \"id\": \"b572f9af-bd9f-4c01-8371-5fc72763794d\",\r\n                    \"path\": \"<Gamepad>/buttonEast\",\r\n                    \"interactions\": \"\",\r\n                    \"processors\": \"\",\r\n                    \"groups\": \";Gamepad\",\r\n                    \"action\": \"Map\",\r\n                    \"isComposite\": false,\r\n                    \"isPartOfComposite\": false\r\n                },\r\n                {\r\n                    \"name\": \"\",\r\n                    \"id\": \"71f6f688-3594-4367-81d1-71cd87840720\",\r\n                    \"path\": \"<Mouse>/leftButton\",\r\n                    \"interactions\": \"\",\r\n                    \"processors\": \"\",\r\n                    \"groups\": \";Keyboard&Mouse\",\r\n                    \"action\": \"Grab\",\r\n                    \"isComposite\": false,\r\n                    \"isPartOfComposite\": false\r\n                },\r\n                {\r\n                    \"name\": \"\",\r\n                    \"id\": \"4cc9a05f-e9fa-4125-aa07-c81a5c72b0aa\",\r\n                    \"path\": \"<Gamepad>/rightTrigger\",\r\n                    \"interactions\": \"\",\r\n                    \"processors\": \"\",\r\n                    \"groups\": \";Gamepad\",\r\n                    \"action\": \"Grab\",\r\n                    \"isComposite\": false,\r\n                    \"isPartOfComposite\": false\r\n                },\r\n                {\r\n                    \"name\": \"\",\r\n                    \"id\": \"9ef4906c-09b4-406b-8f3f-99946116c728\",\r\n                    \"path\": \"<Keyboard>/q\",\r\n                    \"interactions\": \"\",\r\n                    \"processors\": \"\",\r\n                    \"groups\": \";Keyboard&Mouse\",\r\n                    \"action\": \"Tumble\",\r\n                    \"isComposite\": false,\r\n                    \"isPartOfComposite\": false\r\n                },\r\n                {\r\n                    \"name\": \"\",\r\n                    \"id\": \"637588ac-c596-4245-a2bc-0b02a5feee9d\",\r\n                    \"path\": \"<Gamepad>/rightShoulder\",\r\n                    \"interactions\": \"\",\r\n                    \"processors\": \"\",\r\n                    \"groups\": \";Gamepad\",\r\n                    \"action\": \"Tumble\",\r\n                    \"isComposite\": false,\r\n                    \"isPartOfComposite\": false\r\n                },\r\n                {\r\n                    \"name\": \"\",\r\n                    \"id\": \"551ce108-1b9c-47d6-9e31-409ba6b62f63\",\r\n                    \"path\": \"<Mouse>/scroll/y\",\r\n                    \"interactions\": \"\",\r\n                    \"processors\": \"\",\r\n                    \"groups\": \";Keyboard&Mouse\",\r\n                    \"action\": \"Push\",\r\n                    \"isComposite\": false,\r\n                    \"isPartOfComposite\": false\r\n                },\r\n                {\r\n                    \"name\": \"\",\r\n                    \"id\": \"3e1b7c52-8a4d-4f0e-9b6a-2d5c8e71a904\",\r\n                    \"path\": \"\",\r\n                    \"interactions\": \"\",\r\n                    \"processors\": \"\",\r\n                    \"groups\": \";Gamepad\",\r\n                    \"action\": \"Push\",\r\n                    \"isComposite\": false,\r\n                    \"isPartOfComposite\": false\r\n                },\r\n                {\r\n                    \"name\": \"\",\r\n                    \"id\": \"c4f35678-c049-4fe9-aae4-976533840dd6\",\r\n                    \"path\": \"<Mouse>/scroll/y\",\r\n                    \"interactions\": \"\",\r\n                    \"processors\": \"\",\r\n                    \"groups\": \";Keyboard&Mouse\",\r\n                    \"action\": \"Pull\",\r\n                    \"isComposite\": false,\r\n                    \"isPartOfComposite\": false\r\n                },\r\n                {\r\n                    \"name\": \"\",\r\n                    \"id\": \"9f2a6d18-4c3b-4e7a-a5d1-7b8e0c3f6a25\",\r\n                    \"path\": \"\",\r\n                    \"interactions\": \"\",\r\n                    \"processors\": \"\",\r\n                    \"groups\": \";Gamepad\",\r\n                    \"action\": \"Pull\",\r\n                    \"isComposite\": false,\r\n                    \"isPartOfComposite\": false\r\n                },\r\n                {\r\n                    \"name\": \"\",\r\n                    \"id\": \"84e4e1ff-1540-434a-b68f-e2451fa34d7b\",\r\n                    \"path\": \"<Keyboard>/1\",\r\n                    \"interactions\": \"\",\r\n                    \"processors\": \"\",\r\n                    \"groups\": \";Keyboard&Mouse\",\r\n                    \"action\": \"Inventory1\",\r\n                    \"isComposite\": false,\r\n                    \"isPartOfComposite\": false\r\n                },\r\n                {\r\n                    \"name\": \"\",\r\n                    \"id\": \"93674ac8-5aa0-41e2-bd2e-98acad406ffd\",\r\n                    \"path\": \"<Gamepad>/dpad/left\",\r\n                    \"interactions\": \"\",\r\n                    \"processors\": \"\",\r\n                    \"groups\": \";Gamepad\",\r\n                    \"action\": \"Inventory1\",\r\n                    \"isComposite\": false,\r\n                    \"isPartOfComposite\": false\r\n                },\r\n                {\r\n                    \"name\": \"\",\r\n                    \"id\": \"8a519dc8-2813-4a98-bcd6-3b3220f840fd\",\r\n                    \"path\": \"<Keyboard>/2\",\r\n                    \"interactions\": \"\",\r\n                    \"processors\": \"\",\r\n                    \"groups\": \";Keyboard&Mouse\",\r\n                    \"action\": \"Inventory2\",\r\n                    \"isComposite\": false,\r\n                    \"isPartOfComposite\": false\r\n                },\r\n                {\r\n                    \"name\": \"\",\r\n                    \"id\": \"228f5a1f-7989-4e44-a162-6af108206450\",\r\n                    \"path\": \"<Gamepad>/dpad/up\",\r\n                    \"interactions\": \"\",\r\n                    \"processors\": \"\",\r\n                    \"groups\": \";Gamepad\",\r\n                    \"action\": \"Inventory2\",\r\n                    \"isComposite\": false,\r\n                    \"isPartOfComposite\": false\r\n                },\r\n                {\r\n                    \"name\": \"\",\r\n                    \"id\": \"0dd2476a-c0ae-409d-a54b-f031c690d237\",\r\n                    \"path\": \"<Keyboard>/3\",\r\n                    \"interactions\": \"\",\r\n                    \"processors\": \"\",\r\n                    \"groups\": \";Keyboard&Mouse\",\r\n                    \"action\": \"Inventory3\",\r\n                    \"isComposite\": false,\r\n                    \"isPartOfComposite\": false\r\n                },\r\n                {\r\n                    \"name\": \"\",\r\n                    \"id\": \"290000c3-d5e0-4f75-8174-62c1ae133cb9\",\r\n                    \"path\": \"<Gamepad>/dpad/right\",\r\n                    \"interactions\": \"\",\r\n                    \"processors\": \"\",\r\n                    \"groups\": \";Gamepad\",\r\n                    \"action\": \"Inventory3\",\r\n                    \"isComposite\": false,\r\n                    \"isPartOfComposite\": false\r\n                },\r\n                {\r\n                    \"name\": \"\",\r\n                    \"id\": \"6058cf05-b32a-4a45-8949-1c29647f345c\",\r\n                    \"path\": \"<Mouse>/rightButton\",\r\n                    \"interactions\": \"\",\r\n                    \"processors\": \"\",\r\n                    \"groups\": \";Keyboard&Mouse\",\r\n                    \"action\": \"SpectateNext\",\r\n                    \"isComposite\": false,\r\n                    \"isPartOfComposite\": false\r\n                },\r\n                {\r\n                    \"name\": \"\",\r\n                    \"id\": \"bde508fc-7a62-4117-8f96-dcd30bf9f11e\",\r\n                    \"path\": \"<Gamepad>/rightShoulder\",\r\n                    \"interactions\": \"\",\r\n                    \"processors\": \"\",\r\n                    \"groups\": \";Gamepad\",\r\n                    \"action\": \"SpectateNext\",\r\n                    \"isComposite\": false,\r\n                    \"isPartOfComposite\": false\r\n                },\r\n                {\r\n                    \"name\": \"\",\r\n                    \"id\": \"e332c677-c10e-4d5b-8a69-91c4d0bf6576\",\r\n                    \"path\": \"<Mouse>/leftButton\",\r\n                    \"interactions\": \"\",\r\n                    \"processors\": \"\",\r\n                    \"groups\": \";Keyboard&Mouse\",\r\n                    \"action\": \"SpectatePrevious\",\r\n                    \"isComposite\": false,\r\n                    \"isPartOfComposite\": false\r\n                },\r\n                {\r\n                    \"name\": \"\",\r\n                    \"id\": \"bff5aea2-324e-4e3f-a2ac-12782e5df287\",\r\n                    \"path\": \"<Gamepad>/leftShoulder\",\r\n                    \"interactions\": \"\",\r\n                    \"processors\": \"\",\r\n                    \"groups\": \";Gamepad\",\r\n                    \"action\": \"SpectatePrevious\",\r\n                    \"isComposite\": false,\r\n                    \"isPartOfComposite\": false\r\n                },\r\n                {\r\n                    \"name\": \"\",\r\n                    \"id\": \"852a9791-429e-4ad1-a7a6-9017a01391c0\",\r\n                    \"path\": \"<Mouse>/rightButton\",\r\n                    \"interactions\": \"\",\r\n                    \"processors\": \"\",\r\n                    \"groups\": \";Keyboard&Mouse\",\r\n                    \"action\": \"Rotate\",\r\n                    \"isComposite\": false,\r\n                    \"isPartOfComposite\": false\r\n                },\r\n                {\r\n                    \"name\": \"\",\r\n                    \"id\": \"dd9e02f9-1bb5-43c0-85c7-d0873b46033c\",\r\n                    \"path\": \"<Gamepad>/leftShoulder\",\r\n                    \"interactions\": \"\",\r\n                    \"processors\": \"\",\r\n                    \"groups\": \";Gamepad\",\r\n                    \"action\": \"Rotate\",\r\n                    \"isComposite\": false,\r\n                    \"isPartOfComposite\": false\r\n                },\r\n                {\r\n                    \"name\": \"\",\r\n                    \"id\": \"dd4b34fa-a20b-4c77-bfe0-284813baeef1\",\r\n                    \"path\": \"<Gamepad>/leftTrigger\",\r\n                    \"interactions\": \"\",\r\n                    \"processors\": \"\",\r\n                    \"groups\": \";Gamepad\",\r\n                    \"action\": \"PushPull\",\r\n                    \"isComposite\": false,\r\n                    \"isPartOfComposite\": false\r\n                }\r\n            ]\r\n        },\r\n        {\r\n            \"name\": \"UI\",\r\n            \"id\": \"272f6d14-89ba-496f-b7ff-215263d3219f\",\r\n            \"actions\": [\r\n                {\r\n                    \"name\": \"Navigate\",\r\n                    \"type\": \"PassThrough\",\r\n                    \"id\": \"c95b2375-e6d9-4b88-9c4c-c5e76515df4b\",\r\n                    \"expectedControlType\": \"Vector2\",\r\n                    \"processors\": \"\",\r\n                    \"interactions\": \"\",\r\n                    \"initialStateCheck\": false,\r\n                    \"priority\": 0\r\n                },\r\n                {\r\n                    \"name\": \"Click\",\r\n                    \"type\": \"PassThrough\",\r\n                    \"id\": \"3c7022bf-7922-4f7c-a998-c437916075ad\",\r\n                    \"expectedControlType\": \"Button\",\r\n                    \"processors\": \"\",\r\n                    \"interactions\": \"\",\r\n                    \"initialStateCheck\": true,\r\n                    \"priority\": 0\r\n                },\r\n                {\r\n                    \"name\": \"TabLeft\",\r\n                    \"type\": \"Button\",\r\n                    \"id\": \"6a1f4b2c-3d5e-4a6b-8c9d-0e1f2a3b4c5d\",\r\n                    \"expectedControlType\": \"Button\",\r\n                    \"processors\": \"\",\r\n                    \"interactions\": \"\",\r\n                    \"initialStateCheck\": false,\r\n                    \"priority\": 0\r\n                },\r\n                {\r\n                    \"name\": \"TabRight\",\r\n                    \"type\": \"Button\",\r\n                    \"id\": \"7b2f5c3d-4e6f-4b7c-9d0e-1f2a3b4c5d6e\",\r\n                    \"expectedControlType\": \"Button\",\r\n                    \"processors\": \"\",\r\n                    \"interactions\": \"\",\r\n                    \"initialStateCheck\": false,\r\n                    \"priority\": 0\r\n                }\r\n            ],\r\n            \"bindings\": [\r\n                {\r\n                    \"name\": \"Gamepad\",\r\n                    \"id\": \"809f371f-c5e2-4e7a-83a1-d867598f40dd\",\r\n                    \"path\": \"2DVector(mode=2)\",\r\n                    \"interactions\": \"\",\r\n                    \"processors\": \"\",\r\n                    \"groups\": \"\",\r\n                    \"action\": \"Navigate\",\r\n                    \"isComposite\": true,\r\n                    \"isPartOfComposite\": false\r\n                },\r\n                {\r\n                    \"name\": \"up\",\r\n                    \"id\": \"14a5d6e8-4aaf-4119-a9ef-34b8c2c548bf\",\r\n                    \"path\": \"<Gamepad>/leftStick/up\",\r\n                    \"interactions\": \"\",\r\n                    \"processors\": \"\",\r\n                    \"groups\": \";Gamepad\",\r\n                    \"action\": \"Navigate\",\r\n                    \"isComposite\": false,\r\n                    \"isPartOfComposite\": true\r\n                },\r\n                {\r\n                    \"name\": \"down\",\r\n                    \"id\": \"2db08d65-c5fb-421b-983f-c71163608d67\",\r\n                    \"path\": \"<Gamepad>/leftStick/down\",\r\n                    \"interactions\": \"\",\r\n                    \"processors\": \"\",\r\n                    \"groups\": \";Gamepad\",\r\n                    \"action\": \"Navigate\",\r\n                    \"isComposite\": false,\r\n                    \"isPartOfComposite\": true\r\n                },\r\n                {\r\n                    \"name\": \"left\",\r\n                    \"id\": \"8ba04515-75aa-45de-966d-393d9bbd1c14\",\r\n                    \"path\": \"<Gamepad>/leftStick/left\",\r\n                    \"interactions\": \"\",\r\n                    \"processors\": \"\",\r\n                    \"groups\": \";Gamepad\",\r\n                    \"action\": \"Navigate\",\r\n                    \"isComposite\": false,\r\n                    \"isPartOfComposite\": true\r\n                },\r\n                {\r\n                    \"name\": \"right\",\r\n                    \"id\": \"fcd248ae-a788-4676-a12e-f4d81205600b\",\r\n                    \"path\": \"<Gamepad>/leftStick/right\",\r\n                    \"interactions\": \"\",\r\n                    \"processors\": \"\",\r\n                    \"groups\": \";Gamepad\",\r\n                    \"action\": \"Navigate\",\r\n                    \"isComposite\": false,\r\n                    \"isPartOfComposite\": true\r\n                },\r\n                {\r\n                    \"name\": \"\",\r\n                    \"id\": \"fb8277d4-c5cd-4663-9dc7-ee3f0b506d90\",\r\n                    \"path\": \"<Gamepad>/dpad\",\r\n                    \"interactions\": \"\",\r\n                    \"processors\": \"\",\r\n                    \"groups\": \";Gamepad\",\r\n                    \"action\": \"Navigate\",\r\n                    \"isComposite\": false,\r\n                    \"isPartOfComposite\": false\r\n                },\r\n                {\r\n                    \"name\": \"Joystick\",\r\n                    \"id\": \"e25d9774-381c-4a61-b47c-7b6b299ad9f9\",\r\n                    \"path\": \"2DVector\",\r\n                    \"interactions\": \"\",\r\n                    \"processors\": \"\",\r\n                    \"groups\": \"\",\r\n                    \"action\": \"Navigate\",\r\n                    \"isComposite\": true,\r\n                    \"isPartOfComposite\": false\r\n                },\r\n                {\r\n                    \"name\": \"up\",\r\n                    \"id\": \"3db53b26-6601-41be-9887-63ac74e79d19\",\r\n                    \"path\": \"<Joystick>/stick/up\",\r\n                    \"interactions\": \"\",\r\n                    \"processors\": \"\",\r\n                    \"groups\": \"Joystick\",\r\n                    \"action\": \"Navigate\",\r\n                    \"isComposite\": false,\r\n                    \"isPartOfComposite\": true\r\n                },\r\n                {\r\n                    \"name\": \"down\",\r\n                    \"id\": \"0cb3e13e-3d90-4178-8ae6-d9c5501d653f\",\r\n                    \"path\": \"<Joystick>/stick/down\",\r\n                    \"interactions\": \"\",\r\n                    \"processors\": \"\",\r\n                    \"groups\": \"Joystick\",\r\n                    \"action\": \"Navigate\",\r\n                    \"isComposite\": false,\r\n                    \"isPartOfComposite\": true\r\n                },\r\n                {\r\n                    \"name\": \"left\",\r\n                    \"id\": \"0392d399-f6dd-4c82-8062-c1e9c0d34835\",\r\n                    \"path\": \"<Joystick>/stick/left\",\r\n                    \"interactions\": \"\",\r\n                    \"processors\": \"\",\r\n                    \"groups\": \"Joystick\",\r\n                    \"action\": \"Navigate\",\r\n                    \"isComposite\": false,\r\n                    \"isPartOfComposite\": true\r\n                },\r\n                {\r\n                    \"name\": \"right\",\r\n                    \"id\": \"942a66d9-d42f-43d6-8d70-ecb4ba5363bc\",\r\n                    \"path\": \"<Joystick>/stick/right\",\r\n                    \"interactions\": \"\",\r\n                    \"processors\": \"\",\r\n                    \"groups\": \"Joystick\",\r\n                    \"action\": \"Navigate\",\r\n                    \"isComposite\": false,\r\n                    \"isPartOfComposite\": true\r\n                },\r\n                {\r\n                    \"name\": \"Keyboard\",\r\n                    \"id\": \"ff527021-f211-4c02-933e-5976594c46ed\",\r\n                    \"path\": \"2DVector\",\r\n                    \"interactions\": \"\",\r\n                    \"processors\": \"\",\r\n                    \"groups\": \"\",\r\n                    \"action\": \"Navigate\",\r\n                    \"isComposite\": true,\r\n                    \"isPartOfComposite\": false\r\n                },\r\n                {\r\n                    \"name\": \"up\",\r\n                    \"id\": \"563fbfdd-0f09-408d-aa75-8642c4f08ef0\",\r\n                    \"path\": \"<Keyboard>/w\",\r\n                    \"interactions\": \"\",\r\n                    \"processors\": \"\",\r\n                    \"groups\": \"Keyboard&Mouse\",\r\n                    \"action\": \"Navigate\",\r\n                    \"isComposite\": false,\r\n                    \"isPartOfComposite\": true\r\n                },\r\n                {\r\n                    \"name\": \"up\",\r\n                    \"id\": \"eb480147-c587-4a33-85ed-eb0ab9942c43\",\r\n                    \"path\": \"<Keyboard>/upArrow\",\r\n                    \"interactions\": \"\",\r\n                    \"processors\": \"\",\r\n                    \"groups\": \"Keyboard&Mouse\",\r\n                    \"action\": \"Navigate\",\r\n                    \"isComposite\": false,\r\n                    \"isPartOfComposite\": true\r\n                },\r\n                {\r\n                    \"name\": \"down\",\r\n                    \"id\": \"2bf42165-60bc-42ca-8072-8c13ab40239b\",\r\n                    \"path\": \"<Keyboard>/s\",\r\n                    \"interactions\": \"\",\r\n                    \"processors\": \"\",\r\n                    \"groups\": \"Keyboard&Mouse\",\r\n                    \"action\": \"Navigate\",\r\n                    \"isComposite\": false,\r\n                    \"isPartOfComposite\": true\r\n                },\r\n                {\r\n                    \"name\": \"down\",\r\n                    \"id\": \"85d264ad-e0a0-4565-b7ff-1a37edde51ac\",\r\n                    \"path\": \"<Keyboard>/downArrow\",\r\n                    \"interactions\": \"\",\r\n                    \"processors\": \"\",\r\n                    \"groups\": \"Keyboard&Mouse\",\r\n                    \"action\": \"Navigate\",\r\n                    \"isComposite\": false,\r\n                    \"isPartOfComposite\": true\r\n                },\r\n                {\r\n                    \"name\": \"left\",\r\n                    \"id\": \"74214943-c580-44e4-98eb-ad7eebe17902\",\r\n                    \"path\": \"<Keyboard>/a\",\r\n                    \"interactions\": \"\",\r\n                    \"processors\": \"\",\r\n                    \"groups\": \"Keyboard&Mouse\",\r\n                    \"action\": \"Navigate\",\r\n                    \"isComposite\": false,\r\n                    \"isPartOfComposite\": true\r\n                },\r\n                {\r\n                    \"name\": \"left\",\r\n                    \"id\": \"cea9b045-a000-445b-95b8-0c171af70a3b\",\r\n                    \"path\": \"<Keyboard>/leftArrow\",\r\n                    \"interactions\": \"\",\r\n                    \"processors\": \"\",\r\n                    \"groups\": \"Keyboard&Mouse\",\r\n                    \"action\": \"Navigate\",\r\n                    \"isComposite\": false,\r\n                    \"isPartOfComposite\": true\r\n                },\r\n                {\r\n                    \"name\": \"right\",\r\n                    \"id\": \"8607c725-d935-4808-84b1-8354e29bab63\",\r\n                    \"path\": \"<Keyboard>/d\",\r\n                    \"interactions\": \"\",\r\n                    \"processors\": \"\",\r\n                    \"groups\": \"Keyboard&Mouse\",\r\n                    \"action\": \"Navigate\",\r\n                    \"isComposite\": false,\r\n                    \"isPartOfComposite\": true\r\n                },\r\n                {\r\n                    \"name\": \"right\",\r\n                    \"id\": \"4cda81dc-9edd-4e03-9d7c-a71a14345d0b\",\r\n                    \"path\": \"<Keyboard>/rightArrow\",\r\n                    \"interactions\": \"\",\r\n                    \"processors\": \"\",\r\n                    \"groups\": \"Keyboard&Mouse\",\r\n                    \"action\": \"Navigate\",\r\n                    \"isComposite\": false,\r\n                    \"isPartOfComposite\": true\r\n                },\r\n                {\r\n                    \"name\": \"\",\r\n                    \"id\": \"4faf7dc9-b979-4210-aa8c-e808e1ef89f5\",\r\n                    \"path\": \"<Mouse>/leftButton\",\r\n                    \"interactions\": \"\",\r\n                    \"processors\": \"\",\r\n                    \"groups\": \";Keyboard&Mouse\",\r\n                    \"action\": \"Click\",\r\n                    \"isComposite\": false,\r\n                    \"isPartOfComposite\": false\r\n                },\r\n                {\r\n                    \"name\": \"\",\r\n                    \"id\": \"d1cb8637-30cf-4ba8-bb43-8736f9c27a1d\",\r\n                    \"path\": \"<Keyboard>/enter\",\r\n                    \"interactions\": \"\",\r\n                    \"processors\": \"\",\r\n                    \"groups\": \";Keyboard&Mouse\",\r\n                    \"action\": \"Click\",\r\n                    \"isComposite\": false,\r\n                    \"isPartOfComposite\": false\r\n                },\r\n                {\r\n                    \"name\": \"\",\r\n                    \"id\": \"e35f1e0c-914f-4187-8256-c8e997a8a0a0\",\r\n                    \"path\": \"<Keyboard>/space\",\r\n                    \"interactions\": \"\",\r\n                    \"processors\": \"\",\r\n                    \"groups\": \";Keyboard&Mouse\",\r\n                    \"action\": \"Click\",\r\n                    \"isComposite\": false,\r\n                    \"isPartOfComposite\": false\r\n                },\r\n                {\r\n                    \"name\": \"\",\r\n                    \"id\": \"47c2a644-3ebc-4dae-a106-589b7ca75b59\",\r\n                    \"path\": \"<Touchscreen>/touch*/press\",\r\n                    \"interactions\": \"\",\r\n                    \"processors\": \"\",\r\n                    \"groups\": \"Touch\",\r\n                    \"action\": \"Click\",\r\n                    \"isComposite\": false,\r\n                    \"isPartOfComposite\": false\r\n                },\r\n                {\r\n                    \"name\": \"\",\r\n                    \"id\": \"19d6da60-2209-4b3d-ac19-8fe67720cbcb\",\r\n                    \"path\": \"<Gamepad>/buttonSouth\",\r\n                    \"interactions\": \"\",\r\n                    \"processors\": \"\",\r\n                    \"groups\": \";Gamepad\",\r\n                    \"action\": \"Click\",\r\n                    \"isComposite\": false,\r\n                    \"isPartOfComposite\": false\r\n                },\r\n                {\r\n                    \"name\": \"\",\r\n                    \"id\": \"8c3f6d4e-5f7a-4c8d-ae1f-2b3c4d5e6f7a\",\r\n                    \"path\": \"<Gamepad>/leftShoulder\",\r\n                    \"interactions\": \"\",\r\n                    \"processors\": \"\",\r\n                    \"groups\": \";Gamepad\",\r\n                    \"action\": \"TabLeft\",\r\n                    \"isComposite\": false,\r\n                    \"isPartOfComposite\": false\r\n                },\r\n                {\r\n                    \"name\": \"\",\r\n                    \"id\": \"6f1d2a3b-4c5d-4e6f-8a9b-0c1d2e3f4a5b\",\r\n                    \"path\": \"<Mouse>/backButton\",\r\n                    \"interactions\": \"\",\r\n                    \"processors\": \"\",\r\n                    \"groups\": \";Keyboard&Mouse\",\r\n                    \"action\": \"TabLeft\",\r\n                    \"isComposite\": false,\r\n                    \"isPartOfComposite\": false\r\n                },\r\n                {\r\n                    \"name\": \"\",\r\n                    \"id\": \"9d4f7e5f-6a8b-4d9e-bf2a-3c4d5e6f7a8b\",\r\n                    \"path\": \"<Gamepad>/rightShoulder\",\r\n                    \"interactions\": \"\",\r\n                    \"processors\": \"\",\r\n                    \"groups\": \";Gamepad\",\r\n                    \"action\": \"TabRight\",\r\n                    \"isComposite\": false,\r\n                    \"isPartOfComposite\": false\r\n                },\r\n                {\r\n                    \"name\": \"\",\r\n                    \"id\": \"7a2e3b4c-5d6e-4f7a-9b0c-1d2e3f4a5b6c\",\r\n                    \"path\": \"<Mouse>/forwardButton\",\r\n                    \"interactions\": \"\",\r\n                    \"processors\": \"\",\r\n                    \"groups\": \";Keyboard&Mouse\",\r\n                    \"action\": \"TabRight\",\r\n                    \"isComposite\": false,\r\n                    \"isPartOfComposite\": false\r\n                }\r\n            ]\r\n        },\r\n        {\r\n            \"name\": \"Application\",\r\n            \"id\": \"fb843102-5e56-4363-a11a-c1f5be56c954\",\r\n            \"actions\": [\r\n                {\r\n                    \"name\": \"BackEditor\",\r\n                    \"type\": \"Value\",\r\n                    \"id\": \"e24e0d61-4a2b-42a5-abfd-7e59b2e668e8\",\r\n                    \"expectedControlType\": \"\",\r\n                    \"processors\": \"\",\r\n                    \"interactions\": \"\",\r\n                    \"initialStateCheck\": true,\r\n                    \"priority\": 0\r\n                },\r\n                {\r\n                    \"name\": \"Menu\",\r\n                    \"type\": \"Value\",\r\n                    \"id\": \"5cb058c2-fca9-408d-b804-275f9c755362\",\r\n                    \"expectedControlType\": \"\",\r\n                    \"processors\": \"\",\r\n                    \"interactions\": \"\",\r\n                    \"initialStateCheck\": true,\r\n                    \"priority\": 0\r\n                },\r\n                {\r\n                    \"name\": \"Back\",\r\n                    \"type\": \"Value\",\r\n                    \"id\": \"39e5ee64-6f7a-4bd5-91f9-9d76f2879abb\",\r\n                    \"expectedControlType\": \"\",\r\n                    \"processors\": \"\",\r\n                    \"interactions\": \"\",\r\n                    \"initialStateCheck\": true,\r\n                    \"priority\": 0\r\n                },\r\n                {\r\n                    \"name\": \"DebugConsole\",\r\n                    \"type\": \"Button\",\r\n                    \"id\": \"3f6a1c2e-8b4d-4e7a-9c15-2d8e0b7f4a61\",\r\n                    \"expectedControlType\": \"\",\r\n                    \"processors\": \"\",\r\n                    \"interactions\": \"\",\r\n                    \"initialStateCheck\": false,\r\n                    \"priority\": 0\r\n                },\r\n                {\r\n                    \"name\": \"Chat\",\r\n                    \"type\": \"Button\",\r\n                    \"id\": \"c9a8c52f-fae9-4ea8-9cc2-df9d8f50f9d7\",\r\n                    \"expectedControlType\": \"\",\r\n                    \"processors\": \"\",\r\n                    \"interactions\": \"\",\r\n                    \"initialStateCheck\": false,\r\n                    \"priority\": 0\r\n                },\r\n                {\r\n                    \"name\": \"ChatConfirm\",\r\n                    \"type\": \"Button\",\r\n                    \"id\": \"152ac677-b399-4b07-8866-6a9863aa3548\",\r\n                    \"expectedControlType\": \"\",\r\n                    \"processors\": \"\",\r\n                    \"interactions\": \"\",\r\n                    \"initialStateCheck\": false,\r\n                    \"priority\": 0\r\n                },\r\n                {\r\n                    \"name\": \"ChatDelete\",\r\n                    \"type\": \"Button\",\r\n                    \"id\": \"d175e511-a3ec-42a1-8eac-b8f741512222\",\r\n                    \"expectedControlType\": \"\",\r\n                    \"processors\": \"\",\r\n                    \"interactions\": \"\",\r\n                    \"initialStateCheck\": false,\r\n                    \"priority\": 0\r\n                },\r\n                {\r\n                    \"name\": \"PushToTalk\",\r\n                    \"type\": \"Button\",\r\n                    \"id\": \"9ce3b21c-cfad-4d7e-86ea-91d69649eff8\",\r\n                    \"expectedControlType\": \"\",\r\n                    \"processors\": \"\",\r\n                    \"interactions\": \"\",\r\n                    \"initialStateCheck\": false,\r\n                    \"priority\": 0\r\n                },\r\n                {\r\n                    \"name\": \"ToggleMute\",\r\n                    \"type\": \"Button\",\r\n                    \"id\": \"3a702338-8f0b-4cd4-8470-7f1a4dbd4b03\",\r\n                    \"expectedControlType\": \"\",\r\n                    \"processors\": \"\",\r\n                    \"interactions\": \"\",\r\n                    \"initialStateCheck\": false,\r\n                    \"priority\": 0\r\n                }\r\n            ],\r\n            \"bindings\": [\r\n                {\r\n                    \"name\": \"\",\r\n                    \"id\": \"58f6e29c-9239-415e-b8d4-81d157568b51\",\r\n                    \"path\": \"<Keyboard>/f1\",\r\n                    \"interactions\": \"\",\r\n                    \"processors\": \"\",\r\n                    \"groups\": \";Keyboard&Mouse\",\r\n                    \"action\": \"BackEditor\",\r\n                    \"isComposite\": false,\r\n                    \"isPartOfComposite\": false\r\n                },\r\n                {\r\n                    \"name\": \"\",\r\n                    \"id\": \"8db532af-25b1-49e0-bd9b-9c4f8c5f54a1\",\r\n                    \"path\": \"<Gamepad>/start\",\r\n                    \"interactions\": \"\",\r\n                    \"processors\": \"\",\r\n                    \"groups\": \";Gamepad\",\r\n                    \"action\": \"BackEditor\",\r\n                    \"isComposite\": false,\r\n                    \"isPartOfComposite\": false\r\n                },\r\n                {\r\n                    \"name\": \"\",\r\n                    \"id\": \"c9de084a-4369-4c14-a576-0b0c11b7e67d\",\r\n                    \"path\": \"<Gamepad>/{Menu}\",\r\n                    \"interactions\": \"\",\r\n                    \"processors\": \"\",\r\n                    \"groups\": \";Gamepad\",\r\n                    \"action\": \"BackEditor\",\r\n                    \"isComposite\": false,\r\n                    \"isPartOfComposite\": false\r\n                },\r\n                {\r\n                    \"name\": \"\",\r\n                    \"id\": \"af68648e-8e38-41c5-8045-06530284528c\",\r\n                    \"path\": \"<Gamepad>/buttonEast\",\r\n                    \"interactions\": \"\",\r\n                    \"processors\": \"\",\r\n                    \"groups\": \";Gamepad\",\r\n                    \"action\": \"BackEditor\",\r\n                    \"isComposite\": false,\r\n                    \"isPartOfComposite\": false\r\n                },\r\n                {\r\n                    \"name\": \"\",\r\n                    \"id\": \"75adeac8-e592-4e25-a493-2db4475c949b\",\r\n                    \"path\": \"<Keyboard>/escape\",\r\n                    \"interactions\": \"\",\r\n                    \"processors\": \"\",\r\n                    \"groups\": \";Keyboard&Mouse\",\r\n                    \"action\": \"Menu\",\r\n                    \"isComposite\": false,\r\n                    \"isPartOfComposite\": false\r\n                },\r\n                {\r\n                    \"name\": \"\",\r\n                    \"id\": \"b43a12e6-ed58-418e-a891-f5515c9dc42f\",\r\n                    \"path\": \"<Gamepad>/start\",\r\n                    \"interactions\": \"\",\r\n                    \"processors\": \"\",\r\n                    \"groups\": \";Gamepad\",\r\n                    \"action\": \"Menu\",\r\n                    \"isComposite\": false,\r\n                    \"isPartOfComposite\": false\r\n                },\r\n                {\r\n                    \"name\": \"\",\r\n                    \"id\": \"95b67cbf-fac2-4abb-b314-abbe96b2f395\",\r\n                    \"path\": \"<Gamepad>/{Menu}\",\r\n                    \"interactions\": \"\",\r\n                    \"processors\": \"\",\r\n                    \"groups\": \";Gamepad\",\r\n                    \"action\": \"Menu\",\r\n                    \"isComposite\": false,\r\n                    \"isPartOfComposite\": false\r\n                },\r\n                {\r\n                    \"name\": \"\",\r\n                    \"id\": \"686e65be-28e1-4b71-b04a-7cb3563f804f\",\r\n                    \"path\": \"<Keyboard>/escape\",\r\n                    \"interactions\": \"\",\r\n                    \"processors\": \"\",\r\n                    \"groups\": \";Keyboard&Mouse\",\r\n                    \"action\": \"Back\",\r\n                    \"isComposite\": false,\r\n                    \"isPartOfComposite\": false\r\n                },\r\n                {\r\n                    \"name\": \"\",\r\n                    \"id\": \"8ded699f-d715-4a22-bdd9-2d89f751e792\",\r\n                    \"path\": \"<Gamepad>/buttonEast\",\r\n                    \"interactions\": \"\",\r\n                    \"processors\": \"\",\r\n                    \"groups\": \";Gamepad\",\r\n                    \"action\": \"Back\",\r\n                    \"isComposite\": false,\r\n                    \"isPartOfComposite\": false\r\n                },\r\n                {\r\n                    \"name\": \"\",\r\n                    \"id\": \"1b296236-8cc3-45df-9912-46d8ff78bf7a\",\r\n                    \"path\": \"<Gamepad>/start\",\r\n                    \"interactions\": \"\",\r\n                    \"processors\": \"\",\r\n                    \"groups\": \";Gamepad\",\r\n                    \"action\": \"Back\",\r\n                    \"isComposite\": false,\r\n                    \"isPartOfComposite\": false\r\n                },\r\n                {\r\n                    \"name\": \"\",\r\n                    \"id\": \"7a4c88a1-792d-4519-b6c0-a92ef21557e2\",\r\n                    \"path\": \"<Gamepad>/{Menu}\",\r\n                    \"interactions\": \"\",\r\n                    \"processors\": \"\",\r\n                    \"groups\": \";Gamepad\",\r\n                    \"action\": \"Back\",\r\n                    \"isComposite\": false,\r\n                    \"isPartOfComposite\": false\r\n                },\r\n                {\r\n                    \"name\": \"\",\r\n                    \"id\": \"ddd75347-7e32-4dac-adac-e8720b4a580e\",\r\n                    \"path\": \"<Gamepad>/buttonEast\",\r\n                    \"interactions\": \"\",\r\n                    \"processors\": \"\",\r\n                    \"groups\": \";Gamepad\",\r\n                    \"action\": \"Back\",\r\n                    \"isComposite\": false,\r\n                    \"isPartOfComposite\": false\r\n                },\r\n                {\r\n                    \"name\": \"\",\r\n                    \"id\": \"9b2e7d41-5c3a-4f88-a6e0-71d4c8b3e2f5\",\r\n                    \"path\": \"<Keyboard>/backquote\",\r\n                    \"interactions\": \"\",\r\n                    \"processors\": \"\",\r\n                    \"groups\": \";Keyboard&Mouse\",\r\n                    \"action\": \"DebugConsole\",\r\n                    \"isComposite\": false,\r\n                    \"isPartOfComposite\": false\r\n                },\r\n                {\r\n                    \"name\": \"\",\r\n                    \"id\": \"c4d8a3f6-2e1b-4a97-b5c0-8f3e6d2a1b74\",\r\n                    \"path\": \"<Gamepad>/select\",\r\n                    \"interactions\": \"\",\r\n                    \"processors\": \"\",\r\n                    \"groups\": \";Gamepad\",\r\n                    \"action\": \"DebugConsole\",\r\n                    \"isComposite\": false,\r\n                    \"isPartOfComposite\": false\r\n                },\r\n                {\r\n                    \"name\": \"\",\r\n                    \"id\": \"fb4e74eb-20ce-4975-8c04-d5182243e9aa\",\r\n                    \"path\": \"<Keyboard>/t\",\r\n                    \"interactions\": \"\",\r\n                    \"processors\": \"\",\r\n                    \"groups\": \";Keyboard&Mouse\",\r\n                    \"action\": \"Chat\",\r\n                    \"isComposite\": false,\r\n                    \"isPartOfComposite\": false\r\n                },\r\n                {\r\n                    \"name\": \"\",\r\n                    \"id\": \"3cf9867c-901a-4401-abbc-57f3e26f736f\",\r\n                    \"path\": \"\",\r\n                    \"interactions\": \"\",\r\n                    \"processors\": \"\",\r\n                    \"groups\": \";Gamepad\",\r\n                    \"action\": \"Chat\",\r\n                    \"isComposite\": false,\r\n                    \"isPartOfComposite\": false\r\n                },\r\n                {\r\n                    \"name\": \"\",\r\n                    \"id\": \"1ab2c4e4-146a-4a86-9985-0d40286cbaf9\",\r\n                    \"path\": \"<Keyboard>/enter\",\r\n                    \"interactions\": \"\",\r\n                    \"processors\": \"\",\r\n                    \"groups\": \";Keyboard&Mouse\",\r\n                    \"action\": \"ChatConfirm\",\r\n                    \"isComposite\": false,\r\n                    \"isPartOfComposite\": false\r\n                },\r\n                {\r\n                    \"name\": \"\",\r\n                    \"id\": \"9d88ee20-be48-452c-8ed5-ccc8f9c48162\",\r\n                    \"path\": \"<Gamepad>/buttonSouth\",\r\n                    \"interactions\": \"\",\r\n                    \"processors\": \"\",\r\n                    \"groups\": \";Gamepad\",\r\n                    \"action\": \"ChatConfirm\",\r\n                    \"isComposite\": false,\r\n                    \"isPartOfComposite\": false\r\n                },\r\n                {\r\n                    \"name\": \"\",\r\n                    \"id\": \"7a719474-043f-4769-b500-0462dd2a47fc\",\r\n                    \"path\": \"<Keyboard>/backspace\",\r\n                    \"interactions\": \"\",\r\n                    \"processors\": \"\",\r\n                    \"groups\": \";Keyboard&Mouse\",\r\n                    \"action\": \"ChatDelete\",\r\n                    \"isComposite\": false,\r\n                    \"isPartOfComposite\": false\r\n                },\r\n                {\r\n                    \"name\": \"\",\r\n                    \"id\": \"e2af7c50-3af5-4b39-abd9-ef6a08e3e055\",\r\n                    \"path\": \"<Gamepad>/buttonWest\",\r\n                    \"interactions\": \"\",\r\n                    \"processors\": \"\",\r\n                    \"groups\": \";Gamepad\",\r\n                    \"action\": \"ChatDelete\",\r\n                    \"isComposite\": false,\r\n                    \"isPartOfComposite\": false\r\n                },\r\n                {\r\n                    \"name\": \"\",\r\n                    \"id\": \"71e884fd-0791-4024-8f8f-c025a731c7aa\",\r\n                    \"path\": \"<Keyboard>/v\",\r\n                    \"interactions\": \"\",\r\n                    \"processors\": \"\",\r\n                    \"groups\": \";Keyboard&Mouse\",\r\n                    \"action\": \"PushToTalk\",\r\n                    \"isComposite\": false,\r\n                    \"isPartOfComposite\": false\r\n                },\r\n                {\r\n                    \"name\": \"\",\r\n                    \"id\": \"4707d27b-e093-448c-8e03-4c900889dbc6\",\r\n                    \"path\": \"\",\r\n                    \"interactions\": \"\",\r\n                    \"processors\": \"\",\r\n                    \"groups\": \";Gamepad\",\r\n                    \"action\": \"PushToTalk\",\r\n                    \"isComposite\": false,\r\n                    \"isPartOfComposite\": false\r\n                },\r\n                {\r\n                    \"name\": \"\",\r\n                    \"id\": \"1764d565-d73b-45c0-9e19-c3e6d1654771\",\r\n                    \"path\": \"<Keyboard>/b\",\r\n                    \"interactions\": \"\",\r\n                    \"processors\": \"\",\r\n                    \"groups\": \";Keyboard&Mouse\",\r\n                    \"action\": \"ToggleMute\",\r\n                    \"isComposite\": false,\r\n                    \"isPartOfComposite\": false\r\n                },\r\n                {\r\n                    \"name\": \"\",\r\n                    \"id\": \"5517e3d2-512a-4775-a056-c0cf0bb87052\",\r\n                    \"path\": \"\",\r\n                    \"interactions\": \"\",\r\n                    \"processors\": \"\",\r\n                    \"groups\": \";Gamepad\",\r\n                    \"action\": \"ToggleMute\",\r\n                    \"isComposite\": false,\r\n                    \"isPartOfComposite\": false\r\n                }\r\n            ]\r\n        }\r\n    ],\r\n    \"controlSchemes\": [\r\n        {\r\n            \"name\": \"Keyboard&Mouse\",\r\n            \"bindingGroup\": \"Keyboard&Mouse\",\r\n            \"devices\": [\r\n                {\r\n                    \"devicePath\": \"<Keyboard>\",\r\n                    \"isOptional\": false,\r\n                    \"isOR\": false\r\n                },\r\n                {\r\n                    \"devicePath\": \"<Mouse>\",\r\n                    \"isOptional\": false,\r\n                    \"isOR\": false\r\n                }\r\n            ]\r\n        },\r\n        {\r\n            \"name\": \"Gamepad\",\r\n            \"bindingGroup\": \"Gamepad\",\r\n            \"devices\": [\r\n                {\r\n                    \"devicePath\": \"<Gamepad>\",\r\n                    \"isOptional\": false,\r\n                    \"isOR\": false\r\n                }\r\n            ]\r\n        },\r\n        {\r\n            \"name\": \"Touch\",\r\n            \"bindingGroup\": \"Touch\",\r\n            \"devices\": [\r\n                {\r\n                    \"devicePath\": \"<Touchscreen>\",\r\n                    \"isOptional\": false,\r\n                    \"isOR\": false\r\n                }\r\n            ]\r\n        },\r\n        {\r\n            \"name\": \"Joystick\",\r\n            \"bindingGroup\": \"Joystick\",\r\n            \"devices\": [\r\n                {\r\n                    \"devicePath\": \"<Joystick>\",\r\n                    \"isOptional\": false,\r\n                    \"isOR\": false\r\n                }\r\n            ]\r\n        },\r\n        {\r\n            \"name\": \"XR\",\r\n            \"bindingGroup\": \"XR\",\r\n            \"devices\": [\r\n                {\r\n                    \"devicePath\": \"<XRController>\",\r\n                    \"isOptional\": false,\r\n                    \"isOR\": false\r\n                }\r\n            ]\r\n        }\r\n    ]\r\n}");
		m_Player = asset.FindActionMap("Player", true);
		m_Player_Movement = m_Player.FindAction("Movement", true);
		m_Player_MouseDelta = m_Player.FindAction("MouseDelta", true);
		m_Player_Grab = m_Player.FindAction("Grab", true);
		m_Player_Jump = m_Player.FindAction("Jump", true);
		m_Player_Crouch = m_Player.FindAction("Crouch", true);
		m_Player_Tumble = m_Player.FindAction("Tumble", true);
		m_Player_Sprint = m_Player.FindAction("Sprint", true);
		m_Player_Use = m_Player.FindAction("Use", true);
		m_Player_Map = m_Player.FindAction("Map", true);
		m_Player_Push = m_Player.FindAction("Push", true);
		m_Player_Pull = m_Player.FindAction("Pull", true);
		m_Player_Inventory1 = m_Player.FindAction("Inventory1", true);
		m_Player_Inventory2 = m_Player.FindAction("Inventory2", true);
		m_Player_Inventory3 = m_Player.FindAction("Inventory3", true);
		m_Player_SpectateNext = m_Player.FindAction("SpectateNext", true);
		m_Player_SpectatePrevious = m_Player.FindAction("SpectatePrevious", true);
		m_Player_Rotate = m_Player.FindAction("Rotate", true);
		m_Player_PushPull = m_Player.FindAction("PushPull", true);
		m_UI = asset.FindActionMap("UI", true);
		m_UI_Navigate = m_UI.FindAction("Navigate", true);
		m_UI_Click = m_UI.FindAction("Click", true);
		m_UI_TabLeft = m_UI.FindAction("TabLeft", true);
		m_UI_TabRight = m_UI.FindAction("TabRight", true);
		m_Application = asset.FindActionMap("Application", true);
		m_Application_BackEditor = m_Application.FindAction("BackEditor", true);
		m_Application_Menu = m_Application.FindAction("Menu", true);
		m_Application_Back = m_Application.FindAction("Back", true);
		m_Application_DebugConsole = m_Application.FindAction("DebugConsole", true);
		m_Application_Chat = m_Application.FindAction("Chat", true);
		m_Application_ChatConfirm = m_Application.FindAction("ChatConfirm", true);
		m_Application_ChatDelete = m_Application.FindAction("ChatDelete", true);
		m_Application_PushToTalk = m_Application.FindAction("PushToTalk", true);
		m_Application_ToggleMute = m_Application.FindAction("ToggleMute", true);
	}

	~InputSystem_Actions()
	{
	}

	public void Dispose()
	{
		Object.Destroy((Object)(object)asset);
	}

	public bool Contains(InputAction action)
	{
		return asset.Contains(action);
	}

	public IEnumerator<InputAction> GetEnumerator()
	{
		return asset.GetEnumerator();
	}

	IEnumerator IEnumerable.GetEnumerator()
	{
		return GetEnumerator();
	}

	public void Enable()
	{
		asset.Enable();
	}

	public void Disable()
	{
		asset.Disable();
	}

	public InputAction FindAction(string actionNameOrId, bool throwIfNotFound = false)
	{
		return asset.FindAction(actionNameOrId, throwIfNotFound);
	}

	public int FindBinding(InputBinding bindingMask, out InputAction action)
	{
		//IL_0006: Unknown result type (might be due to invalid IL or missing references)
		return asset.FindBinding(bindingMask, ref action);
	}
}
