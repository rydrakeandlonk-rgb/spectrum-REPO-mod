using System;
using System.Collections;
using System.Collections.Generic;
using System.Runtime.CompilerServices;
using Photon.Pun;
using Photon.Realtime;
using UnityEngine;
using UnityEngine.InputSystem;

public class PhysGrabber : MonoBehaviour, IPunObservable
{
	[Serializable]
	public class GamepadGrabCursor
	{
		[Range(0f, 50f)]
		public float horizontalPaddingPercent = 28f;

		[Range(0f, 50f)]
		public float verticalPaddingPercent = 15f;

		[Min(0f)]
		public float moveSpeed = 10f;

		[Min(0.1f)]
		public float returnSpeed = 5f;

		[Min(0f)]
		public float meleeVerticalRotationMultiplier = 2f;

		[Range(0f, 60f)]
		public float meleeVerticalRotationLimit = 60f;

		[Min(0f)]
		public float meleeHorizontalRotationMultiplier = 2f;

		[Range(0f, 60f)]
		public float meleeHorizontalRotationLimit = 60f;

		private Vector2 position;

		public Vector2 offset
		{
			[CompilerGenerated]
			get
			{
				//IL_0001: Unknown result type (might be due to invalid IL or missing references)
				return field;
			}
			[CompilerGenerated]
			private set
			{
				//IL_0001: Unknown result type (might be due to invalid IL or missing references)
				//IL_0002: Unknown result type (might be due to invalid IL or missing references)
				field = value;
			}
		}

		public void Tick(Vector2 input, float deltaTime, float percent = 70f, float speedPercent = 50f, float speedMultiplier = 1f)
		{
			//IL_0080: Unknown result type (might be due to invalid IL or missing references)
			//IL_0086: Unknown result type (might be due to invalid IL or missing references)
			//IL_008d: Unknown result type (might be due to invalid IL or missing references)
			//IL_0092: Unknown result type (might be due to invalid IL or missing references)
			//IL_0096: Unknown result type (might be due to invalid IL or missing references)
			//IL_009b: Unknown result type (might be due to invalid IL or missing references)
			//IL_009e: Unknown result type (might be due to invalid IL or missing references)
			//IL_00a3: Unknown result type (might be due to invalid IL or missing references)
			//IL_00ec: Unknown result type (might be due to invalid IL or missing references)
			//IL_00f3: Unknown result type (might be due to invalid IL or missing references)
			//IL_00f8: Unknown result type (might be due to invalid IL or missing references)
			//IL_00fc: Unknown result type (might be due to invalid IL or missing references)
			//IL_0101: Unknown result type (might be due to invalid IL or missing references)
			//IL_0104: Unknown result type (might be due to invalid IL or missing references)
			//IL_0106: Unknown result type (might be due to invalid IL or missing references)
			//IL_0108: Unknown result type (might be due to invalid IL or missing references)
			//IL_00c9: Unknown result type (might be due to invalid IL or missing references)
			//IL_00ce: Unknown result type (might be due to invalid IL or missing references)
			if (percent <= 0f || speedPercent <= 0f)
			{
				Reset();
				return;
			}
			float num = Mathf.Max(returnSpeed, 0.1f);
			float num2 = Mathf.Clamp(speedPercent, 0f, 100f) * 0.02f * Mathf.Max(0f, speedMultiplier);
			float num3 = Mathf.Max(0f, deltaTime);
			float num4 = 1f - Mathf.Exp((0f - num) * num3 * num2);
			float num5 = Mathf.Max(0f, moveSpeed) / num;
			Vector2 val = Vector2.ClampMagnitude(input, 1f) * num5;
			position = Vector2.Lerp(position, val, num4);
			if (input.sqrMagnitude == 0f && position.sqrMagnitude < 1E-06f)
			{
				position = Vector2.zero;
			}
			float num6 = Mathf.Sqrt(1f + position.sqrMagnitude);
			Vector2 val2 = position / num6;
			Vector2 val3 = EllipseSizeGet(percent);
			offset = Vector2.Scale(val2, val3);
		}

		public Vector2 EllipseSizeGet(float percent = 70f)
		{
			//IL_003c: Unknown result type (might be due to invalid IL or missing references)
			//IL_0048: Unknown result type (might be due to invalid IL or missing references)
			//IL_0054: Unknown result type (might be due to invalid IL or missing references)
			//IL_005b: Unknown result type (might be due to invalid IL or missing references)
			//IL_008e: Unknown result type (might be due to invalid IL or missing references)
			//IL_0098: Unknown result type (might be due to invalid IL or missing references)
			//IL_009d: Unknown result type (might be due to invalid IL or missing references)
			//IL_00af: Unknown result type (might be due to invalid IL or missing references)
			//IL_00b0: Unknown result type (might be due to invalid IL or missing references)
			//IL_00b4: Unknown result type (might be due to invalid IL or missing references)
			//IL_0085: Unknown result type (might be due to invalid IL or missing references)
			//IL_0088: Unknown result type (might be due to invalid IL or missing references)
			float num = Mathf.Clamp(horizontalPaddingPercent, 0f, 50f) * 0.01f;
			float num2 = Mathf.Clamp(verticalPaddingPercent, 0f, 50f) * 0.01f;
			Vector2 val = new Vector2(num, num2);
			Vector2 val2 = new Vector2(0.5f - val.x, 0.5f - val.y);
			float num3 = Mathf.Clamp(percent, 0f, 100f);
			if (num3 <= 70f)
			{
				float num4 = num3 / 70f;
				return val2 * num4;
			}
			Vector2 val3 = Vector2.one * 0.5f;
			float num5 = (num3 - 70f) / 30f;
			return Vector2.Lerp(val2, val3, num5);
		}

		public Vector3 DirectionGet(Vector3 forward, Vector3 right, Vector3 up, float fieldOfView, float aspect)
		{
			//IL_0031: Unknown result type (might be due to invalid IL or missing references)
			//IL_0047: Unknown result type (might be due to invalid IL or missing references)
			//IL_005a: Unknown result type (might be due to invalid IL or missing references)
			//IL_005b: Unknown result type (might be due to invalid IL or missing references)
			//IL_005d: Unknown result type (might be due to invalid IL or missing references)
			//IL_0062: Unknown result type (might be due to invalid IL or missing references)
			//IL_0067: Unknown result type (might be due to invalid IL or missing references)
			//IL_0069: Unknown result type (might be due to invalid IL or missing references)
			//IL_006e: Unknown result type (might be due to invalid IL or missing references)
			//IL_0073: Unknown result type (might be due to invalid IL or missing references)
			//IL_0077: Unknown result type (might be due to invalid IL or missing references)
			float num = Mathf.Tan(Mathf.Clamp(fieldOfView, 1f, 170f) * (MathF.PI / 180f) * 0.5f);
			float num2 = Mathf.Max(aspect, 0.1f);
			float num3 = offset.x * 2f * num * num2;
			float num4 = offset.y * 2f * num;
			Vector3 val = forward + right * num3 + up * num4;
			return val.normalized;
		}

		public Vector2 ClimbInputGet()
		{
			//IL_0031: Unknown result type (might be due to invalid IL or missing references)
			//IL_0037: Unknown result type (might be due to invalid IL or missing references)
			//IL_0041: Unknown result type (might be due to invalid IL or missing references)
			//IL_002a: Unknown result type (might be due to invalid IL or missing references)
			float num = Mathf.Max(0f, moveSpeed) / Mathf.Max(returnSpeed, 0.1f);
			if (num <= 0.0001f)
			{
				return Vector2.zero;
			}
			return Vector2.ClampMagnitude(position / num, 1f);
		}

		public float MeleePitchGet(float fieldOfView)
		{
			//IL_0023: Unknown result type (might be due to invalid IL or missing references)
			float num = Mathf.Tan(Mathf.Clamp(fieldOfView, 1f, 170f) * (MathF.PI / 180f) * 0.5f);
			float num2 = (0f - Mathf.Atan(offset.y * 2f * num)) * 57.29578f;
			float num3 = Mathf.Max(0f, meleeVerticalRotationMultiplier);
			float num4 = Mathf.Clamp(meleeVerticalRotationLimit, 0f, 60f);
			return Mathf.Clamp(num2 * num3, 0f - num4, num4);
		}

		public float MeleeYawGet(float fieldOfView, float aspect)
		{
			//IL_002f: Unknown result type (might be due to invalid IL or missing references)
			float num = Mathf.Tan(Mathf.Clamp(fieldOfView, 1f, 170f) * (MathF.PI / 180f) * 0.5f);
			float num2 = Mathf.Max(aspect, 0.1f);
			float num3 = Mathf.Atan(offset.x * 2f * num * num2) * 57.29578f;
			float num4 = Mathf.Max(0f, meleeHorizontalRotationMultiplier);
			float num5 = Mathf.Clamp(meleeHorizontalRotationLimit, 0f, 60f);
			return Mathf.Clamp(num3 * num4, 0f - num5, num5);
		}

		public void Reset()
		{
			//IL_0001: Unknown result type (might be due to invalid IL or missing references)
			//IL_0006: Unknown result type (might be due to invalid IL or missing references)
			//IL_000c: Unknown result type (might be due to invalid IL or missing references)
			position = Vector2.zero;
			offset = Vector2.zero;
		}
	}

	public class ClimbSwing
	{
		private Vector3 direction;

		private Vector3 angularVelocity;

		private Vector3 right;

		private Vector3 up;

		public float Length { get; private set; }

		public void Reset(Vector3 playerOffset, Vector3 viewRight, Vector3 viewUp, Vector3 playerVelocity)
		{
			//IL_002f: Unknown result type (might be due to invalid IL or missing references)
			//IL_0026: Unknown result type (might be due to invalid IL or missing references)
			//IL_0034: Unknown result type (might be due to invalid IL or missing references)
			//IL_003a: Unknown result type (might be due to invalid IL or missing references)
			//IL_003b: Unknown result type (might be due to invalid IL or missing references)
			//IL_003d: Unknown result type (might be due to invalid IL or missing references)
			//IL_0053: Unknown result type (might be due to invalid IL or missing references)
			//IL_0058: Unknown result type (might be due to invalid IL or missing references)
			//IL_005e: Unknown result type (might be due to invalid IL or missing references)
			//IL_0060: Unknown result type (might be due to invalid IL or missing references)
			//IL_0065: Unknown result type (might be due to invalid IL or missing references)
			//IL_006a: Unknown result type (might be due to invalid IL or missing references)
			//IL_0083: Unknown result type (might be due to invalid IL or missing references)
			//IL_0088: Unknown result type (might be due to invalid IL or missing references)
			//IL_0089: Unknown result type (might be due to invalid IL or missing references)
			//IL_008e: Unknown result type (might be due to invalid IL or missing references)
			//IL_00a6: Unknown result type (might be due to invalid IL or missing references)
			//IL_00ac: Unknown result type (might be due to invalid IL or missing references)
			//IL_00b1: Unknown result type (might be due to invalid IL or missing references)
			//IL_00b6: Unknown result type (might be due to invalid IL or missing references)
			//IL_00f0: Unknown result type (might be due to invalid IL or missing references)
			//IL_00f6: Unknown result type (might be due to invalid IL or missing references)
			//IL_00fb: Unknown result type (might be due to invalid IL or missing references)
			//IL_0100: Unknown result type (might be due to invalid IL or missing references)
			//IL_0103: Unknown result type (might be due to invalid IL or missing references)
			//IL_0108: Unknown result type (might be due to invalid IL or missing references)
			//IL_00ce: Unknown result type (might be due to invalid IL or missing references)
			//IL_00d4: Unknown result type (might be due to invalid IL or missing references)
			//IL_00d9: Unknown result type (might be due to invalid IL or missing references)
			//IL_00de: Unknown result type (might be due to invalid IL or missing references)
			Length = Mathf.Max(playerOffset.magnitude, 0.01f);
			direction = ((playerOffset.sqrMagnitude > 0.0001f) ? playerOffset.normalized : Vector3.back);
			angularVelocity = Vector3.Cross(playerOffset, playerVelocity) / Mathf.Max(playerOffset.sqrMagnitude, 0.0625f);
			right = Vector3.ProjectOnPlane(viewRight, direction);
			if (right.sqrMagnitude < 0.0001f)
			{
				right = Vector3.Cross(direction, viewUp);
			}
			if (right.sqrMagnitude < 0.0001f)
			{
				right = Vector3.ProjectOnPlane(Vector3.right, direction);
			}
			if (right.sqrMagnitude < 0.0001f)
			{
				right = Vector3.ProjectOnPlane(Vector3.forward, direction);
			}
			right.Normalize();
			Vector3 val = Vector3.Cross(right, direction);
			up = val.normalized;
		}

		public void LengthUpdate(Vector3 playerOffset)
		{
			//IL_0014: Unknown result type (might be due to invalid IL or missing references)
			//IL_0035: Unknown result type (might be due to invalid IL or missing references)
			//IL_003a: Unknown result type (might be due to invalid IL or missing references)
			float num = Mathf.Max(playerOffset.magnitude, 0.01f);
			angularVelocity *= Mathf.Max(Length, 0.25f) / Mathf.Max(num, 0.25f);
			Length = num;
		}

		public void Tick(Vector2 lead, Vector3 playerOffset, float speed, float response, float coastDamping, float deltaTime)
		{
			//IL_0001: Unknown result type (might be due to invalid IL or missing references)
			//IL_003a: Unknown result type (might be due to invalid IL or missing references)
			//IL_003b: Unknown result type (might be due to invalid IL or missing references)
			LengthUpdate(playerOffset);
			float num = Mathf.Max(0f, deltaTime);
			if (!(num <= 0f))
			{
				int num2 = Mathf.Max(1, Mathf.CeilToInt(num * 120f));
				float deltaTime2 = num / (float)num2;
				for (int i = 0; i < num2; i++)
				{
					Step(lead, playerOffset, speed, response, coastDamping, deltaTime2);
				}
			}
		}

		private void Step(Vector2 lead, Vector3 playerOffset, float speed, float response, float coastDamping, float deltaTime)
		{
			//IL_0003: Unknown result type (might be due to invalid IL or missing references)
			//IL_0009: Unknown result type (might be due to invalid IL or missing references)
			//IL_000e: Unknown result type (might be due to invalid IL or missing references)
			//IL_002d: Unknown result type (might be due to invalid IL or missing references)
			//IL_0032: Unknown result type (might be due to invalid IL or missing references)
			//IL_0038: Unknown result type (might be due to invalid IL or missing references)
			//IL_003e: Unknown result type (might be due to invalid IL or missing references)
			//IL_0043: Unknown result type (might be due to invalid IL or missing references)
			//IL_0049: Unknown result type (might be due to invalid IL or missing references)
			//IL_004e: Unknown result type (might be due to invalid IL or missing references)
			//IL_0054: Unknown result type (might be due to invalid IL or missing references)
			//IL_0059: Unknown result type (might be due to invalid IL or missing references)
			//IL_0093: Unknown result type (might be due to invalid IL or missing references)
			//IL_0099: Unknown result type (might be due to invalid IL or missing references)
			//IL_009e: Unknown result type (might be due to invalid IL or missing references)
			//IL_00cf: Unknown result type (might be due to invalid IL or missing references)
			//IL_00d4: Unknown result type (might be due to invalid IL or missing references)
			//IL_00d7: Unknown result type (might be due to invalid IL or missing references)
			//IL_00dc: Unknown result type (might be due to invalid IL or missing references)
			//IL_00e1: Unknown result type (might be due to invalid IL or missing references)
			//IL_00e8: Unknown result type (might be due to invalid IL or missing references)
			//IL_00ed: Unknown result type (might be due to invalid IL or missing references)
			//IL_00f0: Unknown result type (might be due to invalid IL or missing references)
			//IL_00f5: Unknown result type (might be due to invalid IL or missing references)
			//IL_00f7: Unknown result type (might be due to invalid IL or missing references)
			//IL_00fc: Unknown result type (might be due to invalid IL or missing references)
			//IL_00a9: Unknown result type (might be due to invalid IL or missing references)
			//IL_00ab: Unknown result type (might be due to invalid IL or missing references)
			//IL_00b1: Unknown result type (might be due to invalid IL or missing references)
			//IL_00b6: Unknown result type (might be due to invalid IL or missing references)
			//IL_00b7: Unknown result type (might be due to invalid IL or missing references)
			//IL_00c1: Unknown result type (might be due to invalid IL or missing references)
			//IL_00c6: Unknown result type (might be due to invalid IL or missing references)
			//IL_00cb: Unknown result type (might be due to invalid IL or missing references)
			//IL_01b3: Unknown result type (might be due to invalid IL or missing references)
			//IL_01b5: Unknown result type (might be due to invalid IL or missing references)
			//IL_0111: Unknown result type (might be due to invalid IL or missing references)
			//IL_0116: Unknown result type (might be due to invalid IL or missing references)
			//IL_0118: Unknown result type (might be due to invalid IL or missing references)
			//IL_011b: Unknown result type (might be due to invalid IL or missing references)
			//IL_0136: Unknown result type (might be due to invalid IL or missing references)
			//IL_0138: Unknown result type (might be due to invalid IL or missing references)
			//IL_0164: Unknown result type (might be due to invalid IL or missing references)
			//IL_0169: Unknown result type (might be due to invalid IL or missing references)
			//IL_016d: Unknown result type (might be due to invalid IL or missing references)
			//IL_0172: Unknown result type (might be due to invalid IL or missing references)
			//IL_0177: Unknown result type (might be due to invalid IL or missing references)
			//IL_0179: Unknown result type (might be due to invalid IL or missing references)
			//IL_017b: Unknown result type (might be due to invalid IL or missing references)
			//IL_019d: Unknown result type (might be due to invalid IL or missing references)
			//IL_01a2: Unknown result type (might be due to invalid IL or missing references)
			//IL_01a6: Unknown result type (might be due to invalid IL or missing references)
			//IL_01ab: Unknown result type (might be due to invalid IL or missing references)
			//IL_01b0: Unknown result type (might be due to invalid IL or missing references)
			Vector2 val = Vector2.ClampMagnitude(lead, 1f);
			float num = Mathf.Max(0f, speed) / Mathf.Max(Length, 0.25f);
			Vector3 val2 = (up * val.x - right * val.y) * num;
			float num2 = Mathf.Lerp(Mathf.Max(0f, coastDamping), Mathf.Max(0f, response), val.magnitude);
			float num3 = 1f - Mathf.Exp((0f - num2) * deltaTime);
			Vector3 val3 = angularVelocity * deltaTime;
			if (num2 > 0.0001f)
			{
				val3 = val2 * deltaTime + (angularVelocity - val2) * (num3 / num2);
			}
			angularVelocity = Vector3.Lerp(angularVelocity, val2, num3);
			val3 = Vector3.ClampMagnitude(val3, MathF.PI / 2f);
			Vector3 val4 = RotateGet(direction, val3);
			if (playerOffset.sqrMagnitude > 0.0001f)
			{
				Vector3 normalized = playerOffset.normalized;
				float num4 = Mathf.Min(Vector3.Dot(normalized, direction), Mathf.Cos(1.3089969f));
				if (Vector3.Dot(normalized, val4) < num4)
				{
					float num5 = 0f;
					float num6 = 1f;
					for (int i = 0; i < 10; i++)
					{
						float num7 = (num5 + num6) * 0.5f;
						Vector3 val5 = RotateGet(direction, val3 * num7);
						if (Vector3.Dot(normalized, val5) >= num4)
						{
							num5 = num7;
						}
						else
						{
							num6 = num7;
						}
					}
					val4 = RotateGet(direction, val3 * num5);
				}
			}
			direction = val4;
		}

		private static Vector3 RotateGet(Vector3 value, Vector3 rotation)
		{
			//IL_0012: Unknown result type (might be due to invalid IL or missing references)
			//IL_0014: Unknown result type (might be due to invalid IL or missing references)
			//IL_0019: Unknown result type (might be due to invalid IL or missing references)
			//IL_0021: Unknown result type (might be due to invalid IL or missing references)
			//IL_0023: Unknown result type (might be due to invalid IL or missing references)
			//IL_0028: Unknown result type (might be due to invalid IL or missing references)
			//IL_0029: Unknown result type (might be due to invalid IL or missing references)
			//IL_002a: Unknown result type (might be due to invalid IL or missing references)
			//IL_0035: Unknown result type (might be due to invalid IL or missing references)
			//IL_003a: Unknown result type (might be due to invalid IL or missing references)
			//IL_003f: Unknown result type (might be due to invalid IL or missing references)
			//IL_0040: Unknown result type (might be due to invalid IL or missing references)
			//IL_0041: Unknown result type (might be due to invalid IL or missing references)
			//IL_0047: Unknown result type (might be due to invalid IL or missing references)
			//IL_0053: Unknown result type (might be due to invalid IL or missing references)
			//IL_0058: Unknown result type (might be due to invalid IL or missing references)
			//IL_005d: Unknown result type (might be due to invalid IL or missing references)
			//IL_0060: Unknown result type (might be due to invalid IL or missing references)
			//IL_0010: Unknown result type (might be due to invalid IL or missing references)
			float magnitude = rotation.magnitude;
			if (magnitude < 1E-06f)
			{
				return value;
			}
			Vector3 val = rotation / magnitude;
			float num = Mathf.Cos(magnitude);
			Vector3 val2 = value * num + Vector3.Cross(val, value) * Mathf.Sin(magnitude) + val * Vector3.Dot(val, value) * (1f - num);
			return val2.normalized;
		}

		public void VelocityReset()
		{
			//IL_0001: Unknown result type (might be due to invalid IL or missing references)
			//IL_0006: Unknown result type (might be due to invalid IL or missing references)
			angularVelocity = Vector3.zero;
		}

		public Vector3 DirectionGet()
		{
			//IL_0001: Unknown result type (might be due to invalid IL or missing references)
			return direction;
		}
	}

	private enum ColorState
	{
		Orange,
		Green,
		Purple,
		Blue
	}

	public enum GrabState
	{
		None,
		Phys,
		Heal,
		Static,
		Climb
	}

	public class DiscoverSkip
	{
		public Transform transform;

		public float timer;
	}

	public GamepadGrabCursor gamepadGrabCursor = new GamepadGrabCursor();

	[Min(0f)]
	public float climbForceMultiplier = 1f;

	[Min(0f)]
	public float climbPushPullSpeed = 12f;

	[Min(0f)]
	public float climbSwingResponse = 12f;

	[Min(0f)]
	public float climbSwingCoastDamping = 1.2f;

	[Min(0f)]
	public float climbSwingDamping = 0.4f;

	[Min(0f)]
	public float climbCameraFollowStrength = 0.6f;

	[Range(0f, 1f)]
	public float climbCameraInputMultiplier = 0.2f;

	[Min(0f)]
	public float climbCameraFollowMaxSpeed = 20f;

	[Range(0f, 90f)]
	public float climbCameraFollowDeadZone = 8f;

	[Range(0f, 1f)]
	public float climbCameraVerticalInfluence = 0.5f;

	[Range(0f, 60f)]
	public float climbCameraPitchLimit = 45f;

	private readonly ClimbSwing climbSwing = new ClimbSwing();

	private int climbSwingRevision = -1;

	private Vector3 climbCameraDirection;

	private float gamepadMeleePitch;

	private float gamepadMeleePitchTarget;

	private float gamepadMeleeYaw;

	private float gamepadMeleeYawTarget;

	private ItemMelee grabbedMelee;

	private Camera playerCamera;

	[HideInInspector]
	public float grabRange = 4f;

	[HideInInspector]
	public float grabReleaseDistance = 8f;

	public static PhysGrabber instance;

	[Space]
	[HideInInspector]
	public float minDistanceFromPlayer = 1f;

	[HideInInspector]
	public float maxDistanceFromPlayer = 2.5f;

	private float minDistanceFromPlayerOriginal = 1f;

	[Space]
	public PhysGrabBeam physGrabBeamComponent;

	public GameObject physGrabBeam;

	private PhysGrabBeam physGrabBeamScript;

	public Transform physGrabPoint;

	public Transform physGrabPointPuller;

	public Transform physGrabPointPlane;

	public Transform climbStickTransform;

	public Transform climbTargetPositionTransform;

	internal GameObject physGrabPointVisual1;

	private GameObject physGrabPointVisual2;

	internal Vector3 grabbedcObjectPrevCamRelForward;

	internal Vector3 grabbedObjectPrevCamRelUp;

	internal PhysGrabObject grabbedPhysGrabObject;

	internal int grabbedPhysGrabObjectColliderID;

	internal Collider grabbedPhysGrabObjectCollider;

	internal StaticGrabObject grabbedStaticGrabObject;

	internal Rigidbody grabbedObject;

	[HideInInspector]
	public Transform grabbedObjectTransform;

	[HideInInspector]
	public float physGrabPointPullerDampen = 80f;

	[HideInInspector]
	public float springConstant = 0.9f;

	[HideInInspector]
	public float dampingConstant = 0.5f;

	[HideInInspector]
	public float forceConstant = 4f;

	[HideInInspector]
	public float forceMax = 4f;

	internal bool physGrabBeamActive;

	[HideInInspector]
	public PhotonView photonView;

	[HideInInspector]
	public bool isLocal;

	[HideInInspector]
	public bool grabbed;

	internal float grabDisableTimer;

	internal int grabRevision;

	[HideInInspector]
	public Vector3 physGrabPointPosition;

	[HideInInspector]
	public Vector3 physGrabPointPullerPosition;

	[HideInInspector]
	public PlayerAvatar playerAvatar;

	[HideInInspector]
	public Vector3 localGrabPosition;

	[HideInInspector]
	public Vector3 cameraRelativeGrabbedForward;

	[HideInInspector]
	public Vector3 cameraRelativeGrabbedUp;

	[HideInInspector]
	public Vector3 cameraRelativeGrabbedRight;

	private Transform physGrabPointVisualRotate;

	[HideInInspector]
	public Transform physGrabPointVisualGrid;

	[HideInInspector]
	public GameObject physGrabPointVisualGridObject;

	private List<GameObject> physGrabPointVisualGridObjects = new List<GameObject>();

	private float overrideMinimumGrabDistance;

	private float overrideMinimumGrabDistanceTimer;

	internal Vector3 currentGrabForce = Vector3.zero;

	internal Vector3 currentTorqueForce = Vector3.zero;

	private int prevColorState = -1;

	[HideInInspector]
	public int colorState;

	private float colorStateOverrideTimer;

	[Space]
	public LayerMask maskLayers;

	internal bool healing;

	internal ItemAttributes currentlyLookingAtItemAttributes;

	internal PhysGrabObject currentlyLookingAtPhysGrabObject;

	internal StaticGrabObject currentlyLookingAtStaticGrabObject;

	[Space]
	public Material physGrabBeamMaterial;

	public Material physGrabBeamMaterialBatteryCharge;

	[HideInInspector]
	public float physGrabForcesDisabledTimer;

	[HideInInspector]
	public float initialPressTimer;

	private bool overrideGrabRelease;

	private float overrideGrabTimer;

	internal PhysGrabObject overrideGrabTarget;

	private float overrideMinimumGrabTimer;

	private float overrideMinimumGrabDuration;

	private PhysGrabObject overrideMinimumGrabTarget;

	private float overrideBeamColorTimer;

	private Color overrideBeamColor = Color.white;

	private Color currentBeamColor = Color.white;

	private float overrideOverchargeDisableTimer;

	internal float overrideDisableSpecialGrabPowersTimer;

	private float overrideDisableSpecialGrabPowersZapCooldown;

	internal bool overrideDisableSpecialGrabPowers;

	private bool overrideDisableSpecialGrabPowersPrevious;

	private float physGrabBeamAlpha = 1f;

	private float physGrabBeamAlphaChangeTo = 1f;

	private float physGramBeamAlphaTimer;

	private float physGrabBeamAlphaChangeProgress;

	private float physGrabBeamAlphaOriginal;

	private float overrideGrabDistance;

	private float overrideGrabDistanceTimer;

	private float overrideDisableRotationControlsTimer;

	private bool overrideDisableRotationControls;

	private float overrideAlwaysGrabbableTimer;

	private Transform overrideAimTransform;

	private float overrideAimTransformTimer;

	private LayerMask mask;

	private float grabCheckTimer;

	internal float pullerDistance;

	public float gamepadPushPullSpeed = 6f;

	[Space]
	public Transform grabberAudioTransform;

	public Sound startSound;

	public Sound loopSound;

	public Sound stopSound;

	private float physRotatingTimer;

	private const float rotationReferenceFrameRate = 144f;

	private float remoteRotationSampleTimer;

	private PhysGrabObject objectTurningObject;

	private Quaternion turnGridRotation;

	private Quaternion prevTurnGridRotation;

	internal Quaternion physRotation;

	private Quaternion physRotationBase;

	[HideInInspector]
	public Vector3 mouseTurningVelocity;

	[HideInInspector]
	public float grabStrength = 1f;

	[HideInInspector]
	public float throwStrength;

	internal bool debugStickyGrabber;

	[HideInInspector]
	public float stopRotationTimer;

	[HideInInspector]
	public Quaternion nextPhysRotation;

	[HideInInspector]
	public bool isRotating;

	internal float physPushPullTimer;

	private float isRotatingTimer;

	internal bool isPushing;

	internal bool isPulling;

	internal bool isPushingAndChangedRange;

	internal bool isPullingAndChangedRange;

	private float isPushingTimer;

	private float isPullingTimer;

	private float prevPullerDistance;

	private float prevPullerDistanceRange;

	internal bool prevGrabbed;

	private ItemVehicle mountedVehicle;

	private SemiMounting mountedMounting;

	private InputModes mountedVehicleInputMode;

	private float vehicleGrabReleaseTimer;

	private bool toggleGrab;

	private float toggleGrabTimer;

	private float overrideGrabPointTimer;

	private Transform overrideGrabPointTransform;

	internal float overrideGrabStrength = -1f;

	private float overrideGrabStrengthTimer;

	private Transform overrideGrabberVisualTransform;

	private float overrideGrabberVisualPositionTimer;

	internal byte physGrabBeamOverCharge;

	internal float physGrabBeamOverChargeFloat;

	private float physGrabBeamOverChargeAmount;

	private float physGrabBeamOverChargeTimer;

	private float physGrabBeamOverchargeDecreaseCooldown;

	private float physGrabBeamOverchargeInitialBoostCooldown;

	private Vector3 grabClimbPos = Vector3.zero;

	private float climbStickLength;

	private float climbHoldLength;

	private float climbHoldMaxLength;

	private const float climbVaultLength = 2f;

	private int climbGrabTimestamp;

	private int grabInputTimestamp;

	private Collider grabClimbCollider;

	private Vector3 grabClimbColliderPosition;

	private bool grabStateStart;

	private Vector3 wallClimbPosition;

	private float climbStrengthEase;

	private SpringQuaternion climbSpring;

	private List<DiscoverSkip> discoverSkipList = new List<DiscoverSkip>();

	[HideInInspector]
	public GrabState grabState;

	private bool MountedVehicleGrab
	{
		get
		{
			if (!Object.op_Implicit((Object)(object)mountedVehicle))
			{
				return Object.op_Implicit((Object)(object)mountedMounting);
			}
			return true;
		}
	}

	private bool MeleeGrabLeadGet()
	{
		if (!Object.op_Implicit((Object)(object)grabbedPhysGrabObject) || !grabbedPhysGrabObject.isMelee)
		{
			return false;
		}
		if (!Object.op_Implicit((Object)(object)grabbedMelee) || (Object)(object)((Component)grabbedMelee).gameObject != (Object)(object)((Component)grabbedPhysGrabObject).gameObject)
		{
			grabbedMelee = ((Component)grabbedPhysGrabObject).GetComponent<ItemMelee>();
		}
		if (Object.op_Implicit((Object)(object)grabbedMelee))
		{
			return grabbedMelee.useMeleeGrabLead;
		}
		return false;
	}

	private void GamepadMeleeRotationReset()
	{
		gamepadMeleePitch = 0f;
		gamepadMeleePitchTarget = 0f;
		gamepadMeleeYaw = 0f;
		gamepadMeleeYawTarget = 0f;
	}

	private void GamepadMeleeRotationUpdate()
	{
		if (!grabbed || !MeleeGrabLeadGet() || isRotating || MountedVehicleGrab || grabState == GrabState.Climb || overrideAimTransformTimer > 0f || Object.op_Implicit((Object)(object)overrideGrabPointTransform) || physGrabForcesDisabledTimer > 0f || !Object.op_Implicit((Object)(object)playerAvatar) || playerAvatar.isDisabled || playerAvatar.deadSet)
		{
			GamepadMeleeRotationReset();
			return;
		}
		if (isLocal)
		{
			if (!Object.op_Implicit((Object)(object)InputManager.instance) || InputManager.instance.CurrentMode != InputModes.Gamepad || !Object.op_Implicit((Object)(object)playerCamera))
			{
				GamepadMeleeRotationReset();
				return;
			}
			gamepadMeleePitch = gamepadGrabCursor.MeleePitchGet(playerCamera.fieldOfView);
			gamepadMeleePitchTarget = gamepadMeleePitch;
			gamepadMeleeYaw = gamepadGrabCursor.MeleeYawGet(playerCamera.fieldOfView, playerCamera.aspect);
			gamepadMeleeYawTarget = gamepadMeleeYaw;
			return;
		}
		float num = 1f - Mathf.Exp(-25f * Time.deltaTime);
		gamepadMeleePitch = Mathf.Lerp(gamepadMeleePitch, gamepadMeleePitchTarget, num);
		gamepadMeleeYaw = Mathf.Lerp(gamepadMeleeYaw, gamepadMeleeYawTarget, num);
		float num2 = Mathf.Abs(gamepadMeleePitchTarget - gamepadMeleePitch);
		float num3 = Mathf.Abs(gamepadMeleeYawTarget - gamepadMeleeYaw);
		if (num2 < 0.01f)
		{
			gamepadMeleePitch = gamepadMeleePitchTarget;
		}
		if (num3 < 0.01f)
		{
			gamepadMeleeYaw = gamepadMeleeYawTarget;
		}
	}

	internal Quaternion GamepadMeleeRotationGet()
	{
		//IL_0020: Unknown result type (might be due to invalid IL or missing references)
		//IL_0037: Unknown result type (might be due to invalid IL or missing references)
		if (!((Behaviour)this).isActiveAndEnabled || !grabbed || !MeleeGrabLeadGet() || isRotating)
		{
			return Quaternion.identity;
		}
		return Quaternion.Euler(gamepadMeleePitch, gamepadMeleeYaw, 0f);
	}

	private bool ClimbGrabCursorActive()
	{
		if (isLocal && grabbed && grabState == GrabState.Climb)
		{
			return Object.op_Implicit((Object)(object)InputManager.instance);
		}
		return false;
	}

	internal Quaternion ClimbOrbitRotationGet(Quaternion fallback)
	{
		//IL_007c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0084: Unknown result type (might be due to invalid IL or missing references)
		//IL_0089: Unknown result type (might be due to invalid IL or missing references)
		//IL_008c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0093: Unknown result type (might be due to invalid IL or missing references)
		//IL_0099: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a0: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b5: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b6: Unknown result type (might be due to invalid IL or missing references)
		//IL_00bb: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b3: Unknown result type (might be due to invalid IL or missing references)
		if (!((Behaviour)this).isActiveAndEnabled || !grabbed || grabState != GrabState.Climb || overrideAimTransformTimer > 0f || Object.op_Implicit((Object)(object)overrideGrabPointTransform) || physGrabForcesDisabledTimer > 0f || !Object.op_Implicit((Object)(object)playerAvatar) || playerAvatar.isDisabled || playerAvatar.deadSet || grabStateStart || !Object.op_Implicit((Object)(object)climbStickTransform))
		{
			return fallback;
		}
		Vector3 forward = climbStickTransform.forward;
		Vector3 val = new Vector3(0f - forward.x, forward.y, 0f - forward.z);
		if (val.sqrMagnitude < 0.0001f)
		{
			return fallback;
		}
		return Quaternion.LookRotation(val, Vector3.up);
	}

	private void ClimbCameraReset()
	{
		if (isLocal && Object.op_Implicit((Object)(object)CameraAim.Instance))
		{
			CameraAim.Instance.AimTargetSoftReset(((Component)this).gameObject);
		}
	}

	private void ClimbSwingReset()
	{
		climbSwingRevision = -1;
		ClimbCameraReset();
	}

	private void ClimbSwingStart(Transform cameraTransform)
	{
		//IL_0027: Unknown result type (might be due to invalid IL or missing references)
		//IL_002c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0033: Unknown result type (might be due to invalid IL or missing references)
		//IL_0035: Unknown result type (might be due to invalid IL or missing references)
		//IL_003a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0040: Unknown result type (might be due to invalid IL or missing references)
		//IL_0046: Unknown result type (might be due to invalid IL or missing references)
		//IL_005b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0072: Unknown result type (might be due to invalid IL or missing references)
		//IL_0077: Unknown result type (might be due to invalid IL or missing references)
		//IL_007c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0081: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a4: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a9: Unknown result type (might be due to invalid IL or missing references)
		//IL_0091: Unknown result type (might be due to invalid IL or missing references)
		//IL_0096: Unknown result type (might be due to invalid IL or missing references)
		//IL_009b: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a0: Unknown result type (might be due to invalid IL or missing references)
		if (isLocal && climbSwingRevision != grabRevision)
		{
			Vector3 worldCenterOfMass = playerAvatar.tumble.rb.worldCenterOfMass;
			climbSwing.Reset(worldCenterOfMass - grabClimbPos, cameraTransform.right, cameraTransform.up, playerAvatar.tumble.rb.linearVelocity);
			climbSwingRevision = grabRevision;
			Vector3 val = Vector3.ProjectOnPlane(cameraTransform.forward, Vector3.up);
			if (val.sqrMagnitude < 0.0001f)
			{
				val = Vector3.Cross(cameraTransform.right, Vector3.up);
			}
			climbCameraDirection = val.normalized;
		}
	}

	internal static Vector3 ClimbCameraDirectionGet(Vector3 velocity, Vector3 previousDirection, float verticalInfluence, float pitchLimit)
	{
		//IL_0000: Unknown result type (might be due to invalid IL or missing references)
		//IL_0001: Unknown result type (might be due to invalid IL or missing references)
		//IL_0006: Unknown result type (might be due to invalid IL or missing references)
		//IL_000b: Unknown result type (might be due to invalid IL or missing references)
		//IL_001c: Unknown result type (might be due to invalid IL or missing references)
		//IL_001d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0022: Unknown result type (might be due to invalid IL or missing references)
		//IL_0027: Unknown result type (might be due to invalid IL or missing references)
		//IL_0043: Unknown result type (might be due to invalid IL or missing references)
		//IL_0082: Unknown result type (might be due to invalid IL or missing references)
		//IL_0089: Unknown result type (might be due to invalid IL or missing references)
		//IL_008e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0099: Unknown result type (might be due to invalid IL or missing references)
		//IL_009e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0036: Unknown result type (might be due to invalid IL or missing references)
		//IL_003b: Unknown result type (might be due to invalid IL or missing references)
		Vector3 val = Vector3.ProjectOnPlane(velocity, Vector3.up);
		float magnitude = val.magnitude;
		if (magnitude <= 0.5f)
		{
			val = Vector3.ProjectOnPlane(previousDirection, Vector3.up);
		}
		if (val.sqrMagnitude < 0.0001f)
		{
			val = Vector3.forward;
		}
		val.Normalize();
		float num = Mathf.Atan2(velocity.y, Mathf.Max(magnitude, 0.5f)) * Mathf.Clamp01(verticalInfluence);
		float num2 = Mathf.Clamp(pitchLimit, 0f, 60f) * (MathF.PI / 180f);
		num = Mathf.Clamp(num, 0f - num2, num2);
		return val * Mathf.Cos(num) + Vector3.up * Mathf.Sin(num);
	}

	private Vector3 ClimbGrabTargetGet(Transform cameraTransform)
	{
		//IL_002f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0035: Unknown result type (might be due to invalid IL or missing references)
		//IL_003a: Unknown result type (might be due to invalid IL or missing references)
		//IL_003f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0041: Unknown result type (might be due to invalid IL or missing references)
		//IL_0046: Unknown result type (might be due to invalid IL or missing references)
		//IL_0048: Unknown result type (might be due to invalid IL or missing references)
		//IL_004d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0053: Unknown result type (might be due to invalid IL or missing references)
		//IL_0058: Unknown result type (might be due to invalid IL or missing references)
		//IL_005d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0019: Unknown result type (might be due to invalid IL or missing references)
		ClimbCameraReset();
		if (!Object.op_Implicit((Object)(object)playerAvatar.tumble))
		{
			return grabClimbPos;
		}
		Vector3 playerOffset = playerAvatar.tumble.rb.worldCenterOfMass - grabClimbPos;
		return grabClimbPos + ClimbLookOffsetGet(playerOffset, -cameraTransform.forward, cameraTransform.right);
	}

	internal static Vector3 ClimbLookOffsetGet(Vector3 playerOffset, Vector3 lookDirection, Vector3 lookRight)
	{
		//IL_0012: Unknown result type (might be due to invalid IL or missing references)
		//IL_0017: Unknown result type (might be due to invalid IL or missing references)
		//IL_0018: Unknown result type (might be due to invalid IL or missing references)
		//IL_0019: Unknown result type (might be due to invalid IL or missing references)
		//IL_001a: Unknown result type (might be due to invalid IL or missing references)
		//IL_001f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0020: Unknown result type (might be due to invalid IL or missing references)
		//IL_0021: Unknown result type (might be due to invalid IL or missing references)
		//IL_0022: Unknown result type (might be due to invalid IL or missing references)
		//IL_0027: Unknown result type (might be due to invalid IL or missing references)
		//IL_0028: Unknown result type (might be due to invalid IL or missing references)
		//IL_0029: Unknown result type (might be due to invalid IL or missing references)
		//IL_002a: Unknown result type (might be due to invalid IL or missing references)
		//IL_002f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0030: Unknown result type (might be due to invalid IL or missing references)
		//IL_003c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0041: Unknown result type (might be due to invalid IL or missing references)
		//IL_0046: Unknown result type (might be due to invalid IL or missing references)
		//IL_0047: Unknown result type (might be due to invalid IL or missing references)
		//IL_004d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0052: Unknown result type (might be due to invalid IL or missing references)
		//IL_0053: Unknown result type (might be due to invalid IL or missing references)
		//IL_0054: Unknown result type (might be due to invalid IL or missing references)
		//IL_0055: Unknown result type (might be due to invalid IL or missing references)
		//IL_005a: Unknown result type (might be due to invalid IL or missing references)
		//IL_005d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0069: Unknown result type (might be due to invalid IL or missing references)
		//IL_000e: Unknown result type (might be due to invalid IL or missing references)
		if (playerOffset.sqrMagnitude < 0.0001f)
		{
			return playerOffset;
		}
		Vector3 normalized = playerOffset.normalized;
		Vector3 val = Vector3.ProjectOnPlane(lookDirection, normalized);
		Vector3 val2 = Vector3.Cross(lookRight, normalized);
		val = Vector3.ProjectOnPlane(val, val2) + val2 * (lookDirection.y * 1.25f);
		val = Vector3.ClampMagnitude(val, 1f);
		Vector3 val3 = normalized + val;
		return val3.normalized * playerOffset.magnitude;
	}

	private Vector3 GamepadGrabTargetGet(Transform cameraTransform, Transform aimTransform)
	{
		//IL_0001: Unknown result type (might be due to invalid IL or missing references)
		//IL_0007: Unknown result type (might be due to invalid IL or missing references)
		//IL_0012: Unknown result type (might be due to invalid IL or missing references)
		//IL_0017: Unknown result type (might be due to invalid IL or missing references)
		//IL_001c: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00da: Unknown result type (might be due to invalid IL or missing references)
		//IL_0128: Unknown result type (might be due to invalid IL or missing references)
		//IL_0133: Unknown result type (might be due to invalid IL or missing references)
		//IL_0138: Unknown result type (might be due to invalid IL or missing references)
		//IL_0140: Unknown result type (might be due to invalid IL or missing references)
		//IL_015c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0161: Unknown result type (might be due to invalid IL or missing references)
		//IL_0176: Unknown result type (might be due to invalid IL or missing references)
		//IL_017c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0182: Unknown result type (might be due to invalid IL or missing references)
		//IL_019d: Unknown result type (might be due to invalid IL or missing references)
		//IL_01a2: Unknown result type (might be due to invalid IL or missing references)
		//IL_01a5: Unknown result type (might be due to invalid IL or missing references)
		//IL_01aa: Unknown result type (might be due to invalid IL or missing references)
		//IL_01b2: Unknown result type (might be due to invalid IL or missing references)
		//IL_01b7: Unknown result type (might be due to invalid IL or missing references)
		//IL_016d: Unknown result type (might be due to invalid IL or missing references)
		Vector3 result = cameraTransform.position + aimTransform.forward * pullerDistance;
		bool flag = ClimbGrabCursorActive();
		if (!grabbed || ((!Object.op_Implicit((Object)(object)grabbedPhysGrabObject) || grabState == GrabState.Climb) && !flag) || MountedVehicleGrab || overrideAimTransformTimer > 0f || Object.op_Implicit((Object)(object)overrideGrabPointTransform) || physGrabForcesDisabledTimer > 0f || !Object.op_Implicit((Object)(object)InputManager.instance) || !Object.op_Implicit((Object)(object)playerCamera) || !Object.op_Implicit((Object)(object)playerAvatar) || playerAvatar.isDisabled || playerAvatar.deadSet)
		{
			gamepadGrabCursor.Reset();
			climbSwing.VelocityReset();
			ClimbCameraReset();
			return result;
		}
		if (flag)
		{
			return ClimbGrabTargetGet(cameraTransform);
		}
		ClimbCameraReset();
		bool melee = MeleeGrabLeadGet();
		int num = (flag ? 70 : InputManager.instance.GrabCursorDriftGet(melee));
		int num2 = (flag ? 50 : InputManager.instance.GrabCursorDriftSpeedGet(melee));
		if (num <= 0 || num2 <= 0)
		{
			gamepadGrabCursor.Reset();
			return result;
		}
		Vector2 input = InputManager.instance.GrabCursorLookGet(!flag);
		gamepadGrabCursor.Tick(input, Time.deltaTime, num, num2);
		if (gamepadGrabCursor.offset == Vector2.zero)
		{
			return result;
		}
		Vector3 val = gamepadGrabCursor.DirectionGet(aimTransform.forward, cameraTransform.right, cameraTransform.up, playerCamera.fieldOfView, playerCamera.aspect);
		return cameraTransform.position + val * pullerDistance;
	}

	[RuntimeInitializeOnLoadMethod(/*Could not decode attribute arguments.*/)]
	private static void RuntimeInitializeOnLoad()
	{
		instance = null;
	}

	private void Awake()
	{
		photonView = ((Component)this).GetComponent<PhotonView>();
	}

	private void Start()
	{
		//IL_002b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0030: Unknown result type (might be due to invalid IL or missing references)
		//IL_0036: Unknown result type (might be due to invalid IL or missing references)
		//IL_003b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0041: Unknown result type (might be due to invalid IL or missing references)
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0064: Unknown result type (might be due to invalid IL or missing references)
		//IL_00dd: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e3: Expected Obj, but got Unknown
		//IL_0253: Unknown result type (might be due to invalid IL or missing references)
		//IL_0268: Unknown result type (might be due to invalid IL or missing references)
		//IL_0296: Unknown result type (might be due to invalid IL or missing references)
		//IL_02ec: Unknown result type (might be due to invalid IL or missing references)
		//IL_02fc: Unknown result type (might be due to invalid IL or missing references)
		//IL_0322: Unknown result type (might be due to invalid IL or missing references)
		//IL_0332: Unknown result type (might be due to invalid IL or missing references)
		//IL_0110: Unknown result type (might be due to invalid IL or missing references)
		//IL_0116: Expected Obj, but got Unknown
		//IL_019f: Unknown result type (might be due to invalid IL or missing references)
		//IL_01a6: Expected Obj, but got Unknown
		minDistanceFromPlayerOriginal = minDistanceFromPlayer;
		((MonoBehaviour)this).StartCoroutine(LateStart());
		physGrabBeamScript = physGrabBeam.GetComponent<PhysGrabBeam>();
		physRotation = Quaternion.identity;
		physRotationBase = Quaternion.identity;
		mask = LayerMask.op_Implicit(LayerMask.op_Implicit(SemiFunc.LayerMaskGetVisionObstruct()) - LayerMask.GetMask(new string[1] { "Player" }));
		playerAvatar = ((Component)this).GetComponent<PlayerAvatar>();
		climbSpring = new SpringQuaternion();
		climbSpring.damping = 0.5f;
		climbSpring.speed = 20f;
		if (GameManager.instance.gameMode == 0 || photonView.IsMine)
		{
			isLocal = true;
			instance = this;
		}
		foreach (Transform item in physGrabPoint)
		{
			Transform val = item;
			if (((Object)val).name == "Visual1")
			{
				physGrabPointVisual1 = ((Component)val).gameObject;
				foreach (Transform item2 in val)
				{
					Transform val2 = item2;
					if (((Object)val2).name == "Visual2")
					{
						physGrabPointVisual2 = ((Component)val2).gameObject;
					}
				}
			}
			if (((Object)val).name == "Rotate")
			{
				physGrabPointVisualRotate = val;
				((Component)val).GetComponent<PhysGrabPointRotate>().physGrabber = this;
			}
			if (!(((Object)val).name == "Grid"))
			{
				continue;
			}
			physGrabPointVisualGrid = val;
			foreach (Transform item3 in val)
			{
				Transform val3 = item3;
				physGrabPointVisualGridObject = ((Component)val3).gameObject;
				physGrabPointVisualGridObject.SetActive(false);
			}
		}
		physGrabPoint.SetParent(((Component)this).transform.parent, true);
		PhysGrabPointDeactivate();
		((Component)physGrabPointPuller).gameObject.SetActive(false);
		physGrabBeam.transform.SetParent(((Component)this).transform.parent, false);
		physGrabBeam.transform.position = Vector3.zero;
		physGrabBeam.transform.rotation = Quaternion.identity;
		prevGrabbed = grabbed;
		grabbed = false;
		physGrabBeamAlphaOriginal = ((Renderer)physGrabBeam.GetComponent<LineRenderer>()).material.color.a;
		SoundsSetup();
		if (isLocal)
		{
			playerCamera = Camera.main;
			PlayerController.instance.physGrabPoint = physGrabPoint;
			physGrabPointPlane.SetParent(((Component)this).transform.parent, false);
			physGrabPointPlane.position = Vector3.zero;
			physGrabPointPlane.rotation = Quaternion.identity;
			physGrabPointPlane.SetParent(((Component)CameraAim.Instance).transform, false);
			physGrabPointPlane.localPosition = Vector3.zero;
			physGrabPointPlane.localRotation = Quaternion.identity;
		}
	}

	private void GrabStateNone()
	{
		if (grabStateStart)
		{
			grabStateStart = false;
		}
	}

	private void GrabStatePhys()
	{
		if (grabStateStart)
		{
			grabStateStart = false;
		}
	}

	private void GrabStateHeal()
	{
		if (grabStateStart)
		{
			grabStateStart = false;
		}
	}

	private void GrabStateStatic()
	{
		if (grabStateStart)
		{
			grabStateStart = false;
		}
	}

	private void GrabStateClimb()
	{
		//IL_0059: Unknown result type (might be due to invalid IL or missing references)
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0064: Unknown result type (might be due to invalid IL or missing references)
		//IL_0069: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ab: Unknown result type (might be due to invalid IL or missing references)
		//IL_02dd: Unknown result type (might be due to invalid IL or missing references)
		//IL_02e2: Unknown result type (might be due to invalid IL or missing references)
		//IL_02ee: Unknown result type (might be due to invalid IL or missing references)
		//IL_00fb: Unknown result type (might be due to invalid IL or missing references)
		//IL_0100: Unknown result type (might be due to invalid IL or missing references)
		//IL_010b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0110: Unknown result type (might be due to invalid IL or missing references)
		//IL_00cf: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d4: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d5: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e0: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e5: Unknown result type (might be due to invalid IL or missing references)
		//IL_0265: Unknown result type (might be due to invalid IL or missing references)
		//IL_026b: Unknown result type (might be due to invalid IL or missing references)
		//IL_014d: Unknown result type (might be due to invalid IL or missing references)
		//IL_01fe: Unknown result type (might be due to invalid IL or missing references)
		//IL_0203: Unknown result type (might be due to invalid IL or missing references)
		PlayerController playerController = PlayerController.instance;
		PlayerAvatar playerAvatarScript = playerController.playerAvatarScript;
		float num = 1f + Mathf.Max(0f, playerController.EnergyStart - 100f) / 331.2614f;
		if (grabStateStart)
		{
			if (isLocal)
			{
				PhysGrabBeamActivate();
			}
			Vector3 val = playerAvatar.tumble.rb.worldCenterOfMass - grabClimbPos;
			climbStickLength = Mathf.Max(val.magnitude, 0.01f);
			climbHoldLength = climbStickLength;
			climbHoldMaxLength = Mathf.Max(climbHoldLength, grabRange);
			climbStickTransform.position = grabClimbPos;
			if (val.sqrMagnitude > 0.0001f)
			{
				climbStickTransform.rotation = Quaternion.FromToRotation(climbStickTransform.forward, val) * climbStickTransform.rotation;
			}
			climbSpring.lastRotation = climbStickTransform.rotation;
			climbSpring.springVelocity = Vector3.zero;
			if (isLocal)
			{
				Transform overrideTransform = playerAvatar.localCamera.GetOverrideTransform();
				ClimbSwingStart(overrideTransform);
			}
			climbStickTransform.localScale = new Vector3(1f, 1f, climbStickLength);
			grabStateStart = false;
			if (isLocal)
			{
				playerController.tumbleInputDisableTimer = 0f;
				playerAvatar.tumble.tumbleOverride = false;
			}
			if (isLocal && !playerController.DebugEnergy)
			{
				float num2 = 1.5f * num;
				for (float num3 = playerAvatarScript.upgradeTumbleClimb - 1f; num3 > 0f; num3--)
				{
					num2 *= 0.8738524f;
				}
				playerController.EnergyCurrent -= num2;
				playerController.EnergyCurrent = Mathf.Max(playerController.EnergyCurrent, 0f);
			}
			wallClimbPosition = playerAvatar.tumble.rb.position;
			climbSpring.damping = 1f;
			climbSpring.speed = 50f;
			climbStrengthEase = 0f;
		}
		if (isLocal && (!Object.op_Implicit((Object)(object)grabClimbCollider) || !((Component)grabClimbCollider).gameObject.activeInHierarchy || ((Component)grabClimbCollider).transform.position != grabClimbColliderPosition || overrideDisableSpecialGrabPowers))
		{
			ReleaseObject(-1, 0.5f);
			return;
		}
		if (isLocal && (playerAvatar.tumble.tumbleOverride || playerController.tumbleInputDisableTimer > 0f) && grabState != GrabState.Climb)
		{
			ReleaseObject(-1, 0.5f);
			return;
		}
		colorState = 3;
		colorStateOverrideTimer = 0.1f;
		physGrabPointPosition = grabClimbPos;
		physGrabPoint.position = grabClimbPos;
		if (isLocal)
		{
			if (!playerController.DebugEnergy)
			{
				float num4 = 3.85f * num;
				for (float num5 = playerAvatarScript.upgradeTumbleClimb - 1f; num5 > 0f; num5--)
				{
					num4 *= 0.8738524f;
				}
				playerController.EnergyCurrent -= num4 * Time.deltaTime;
				if (playerController.EnergyCurrent < 0f)
				{
					OverrideDisableSpecialGrabPowers();
					ReleaseObject(-1, 0.5f);
					playerController.tumbleInputDisableTimer = 3f;
					playerController.EnergyCurrent = 0f;
					playerController.sprintRechargeTimer = 0.5f;
				}
			}
			Aim.instance.SetState(Aim.State.Climb);
		}
		if (SemiFunc.IsMasterClientOrSingleplayer() && playerAvatarScript.tumble.physGrabObject.rbVelocity.magnitude <= 3f)
		{
			playerAvatarScript.FallDamageResetSet(0.1f);
		}
	}

	private void StateMachine()
	{
		switch (grabState)
		{
		case GrabState.None:
			GrabStateNone();
			break;
		case GrabState.Phys:
			GrabStatePhys();
			break;
		case GrabState.Heal:
			GrabStateHeal();
			break;
		case GrabState.Static:
			GrabStateStatic();
			break;
		case GrabState.Climb:
			GrabStateClimb();
			break;
		}
	}

	private void OnDestroy()
	{
		Object.Destroy((Object)(object)physGrabBeam);
	}

	private float ClimbStrengthGet()
	{
		float num = 14f;
		float num2 = 2f;
		for (float num3 = playerAvatar.upgradeTumbleClimb - 1f; num3 > 0f; num3--)
		{
			num += num2;
			num2 *= 0.8f;
		}
		return num;
	}

	private void ClimbTargetUpdate()
	{
		//IL_0007: Unknown result type (might be due to invalid IL or missing references)
		//IL_0017: Unknown result type (might be due to invalid IL or missing references)
		//IL_001c: Unknown result type (might be due to invalid IL or missing references)
		//IL_001e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_0029: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0040: Unknown result type (might be due to invalid IL or missing references)
		//IL_0046: Unknown result type (might be due to invalid IL or missing references)
		//IL_004b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0050: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_0069: Unknown result type (might be due to invalid IL or missing references)
		//IL_0090: Unknown result type (might be due to invalid IL or missing references)
		//IL_0091: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c2: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c6: Unknown result type (might be due to invalid IL or missing references)
		//IL_00cb: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d9: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e0: Unknown result type (might be due to invalid IL or missing references)
		//IL_0100: Unknown result type (might be due to invalid IL or missing references)
		//IL_0111: Unknown result type (might be due to invalid IL or missing references)
		//IL_011c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0127: Unknown result type (might be due to invalid IL or missing references)
		//IL_012c: Unknown result type (might be due to invalid IL or missing references)
		//IL_013d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0142: Unknown result type (might be due to invalid IL or missing references)
		//IL_007e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0083: Unknown result type (might be due to invalid IL or missing references)
		//IL_0084: Unknown result type (might be due to invalid IL or missing references)
		//IL_0089: Unknown result type (might be due to invalid IL or missing references)
		//IL_008a: Unknown result type (might be due to invalid IL or missing references)
		//IL_008f: Unknown result type (might be due to invalid IL or missing references)
		climbStickTransform.position = grabClimbPos;
		Quaternion rotation = climbStickTransform.rotation;
		Vector3 val = physGrabPointPullerPosition - grabClimbPos;
		Vector3 val2 = playerAvatar.tumble.rb.worldCenterOfMass - grabClimbPos;
		climbStickLength = Mathf.Max(val2.magnitude, 0.01f);
		Quaternion val3 = rotation;
		if (val.sqrMagnitude > 0.0001f)
		{
			val3 = Quaternion.FromToRotation(climbStickTransform.forward, val) * rotation;
		}
		float num = Quaternion.Angle(rotation, val3);
		float num2 = 1f - Mathf.Pow(1f - Mathf.Clamp01(num / 60f), Time.fixedDeltaTime * 60f);
		Quaternion targetRotation = Quaternion.Lerp(rotation, val3, num2);
		climbStickTransform.rotation = SemiFunc.SpringQuaternionGet(climbSpring, targetRotation, Time.fixedDeltaTime);
		climbStickTransform.localScale = new Vector3(1f, 1f, climbStickLength);
		climbTargetPositionTransform.position = grabClimbPos + climbStickTransform.forward * climbStickLength;
		wallClimbPosition = climbTargetPositionTransform.position;
	}

	internal static Vector3 ClimbPushPullForceGet(Vector3 followForce, Vector3 playerOffset, Vector3 velocity, float input, float speed, float damping)
	{
		//IL_001f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0023: Unknown result type (might be due to invalid IL or missing references)
		//IL_0028: Unknown result type (might be due to invalid IL or missing references)
		//IL_0029: Unknown result type (might be due to invalid IL or missing references)
		//IL_002a: Unknown result type (might be due to invalid IL or missing references)
		//IL_005a: Unknown result type (might be due to invalid IL or missing references)
		//IL_005b: Unknown result type (might be due to invalid IL or missing references)
		//IL_005c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0061: Unknown result type (might be due to invalid IL or missing references)
		//IL_0063: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		if (input == 0f || speed <= 0f || playerOffset.sqrMagnitude < 0.0001f)
		{
			return followForce;
		}
		Vector3 normalized = playerOffset.normalized;
		float num = Vector3.Dot(velocity, normalized);
		float num2 = Mathf.Clamp(input, -1f, 1f) * speed - num * (1f + Mathf.Max(0f, damping));
		return Vector3.ProjectOnPlane(followForce, normalized) + normalized * num2;
	}

	internal static Vector3 ClimbAccelerationGet(Vector3 offset, Vector3 velocity, Vector3 steering, Vector3 gravity, float holdLength, float strength, float fullStrength, float coastDamping, float deltaTime, Vector3 vaultSteering)
	{
		//IL_0016: Unknown result type (might be due to invalid IL or missing references)
		//IL_0018: Unknown result type (might be due to invalid IL or missing references)
		//IL_001d: Unknown result type (might be due to invalid IL or missing references)
		//IL_001e: Unknown result type (might be due to invalid IL or missing references)
		//IL_001f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0026: Unknown result type (might be due to invalid IL or missing references)
		//IL_0027: Unknown result type (might be due to invalid IL or missing references)
		//IL_0028: Unknown result type (might be due to invalid IL or missing references)
		//IL_002d: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Unknown result type (might be due to invalid IL or missing references)
		//IL_002f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0030: Unknown result type (might be due to invalid IL or missing references)
		//IL_003a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0073: Unknown result type (might be due to invalid IL or missing references)
		//IL_007d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0082: Unknown result type (might be due to invalid IL or missing references)
		//IL_008f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0094: Unknown result type (might be due to invalid IL or missing references)
		//IL_009b: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a2: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ac: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b1: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b6: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b8: Unknown result type (might be due to invalid IL or missing references)
		//IL_0010: Unknown result type (might be due to invalid IL or missing references)
		//IL_0157: Unknown result type (might be due to invalid IL or missing references)
		//IL_0158: Unknown result type (might be due to invalid IL or missing references)
		//IL_0175: Unknown result type (might be due to invalid IL or missing references)
		//IL_0177: Unknown result type (might be due to invalid IL or missing references)
		//IL_017a: Unknown result type (might be due to invalid IL or missing references)
		//IL_017f: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c8: Unknown result type (might be due to invalid IL or missing references)
		//IL_00cd: Unknown result type (might be due to invalid IL or missing references)
		//IL_00cf: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d0: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f1: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f5: Unknown result type (might be due to invalid IL or missing references)
		//IL_0108: Unknown result type (might be due to invalid IL or missing references)
		//IL_010d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0112: Unknown result type (might be due to invalid IL or missing references)
		float magnitude = offset.magnitude;
		if (magnitude < 0.01f)
		{
			return Vector3.zero;
		}
		Vector3 val = offset / magnitude;
		float num = Vector3.Dot(velocity, val);
		Vector3 val2 = Vector3.ProjectOnPlane(velocity, val);
		Vector3 val3 = Vector3.ClampMagnitude(Vector3.ProjectOnPlane(steering, val), 1f);
		float num2 = Mathf.Max(1f, fullStrength / (1.3f + magnitude / 20f));
		float num3 = Mathf.Max(0f, val2.magnitude - num2);
		Vector3 val4 = val3 * strength * 1.5f - val2 * Mathf.Max(0f, coastDamping) - val2.normalized * num3 * 3f;
		if (vaultSteering.y > 0f)
		{
			Vector3 normalized = vaultSteering.normalized;
			float num4 = Vector3.Dot(val2, normalized);
			float num5 = Mathf.Clamp01(1f - num4 / (num2 * 0.4f));
			val4 += normalized * (vaultSteering.y * fullStrength * 4f * num5);
		}
		float num6 = 64f;
		float num7 = 16f;
		float num8 = Mathf.Max(0f, deltaTime);
		float num9 = (num6 * (holdLength - magnitude) - (num7 + num6 * num8) * num) / (1f + num7 * num8 + num6 * num8 * num8) - Vector3.Dot(gravity, val) - val2.sqrMagnitude / Mathf.Max(magnitude, 0.25f);
		return val4 + val * num9;
	}

	private void ClimbHoldLengthUpdate(float _input, float _vaultPull, float _vaultPush, float _strength)
	{
		float num = Mathf.Max(0f, climbPushPullSpeed) * 0.25f;
		float num2 = climbHoldLength + _input * num * Time.fixedDeltaTime;
		bool flag = climbHoldLength < 2f;
		if (!(flag ? (_input < 0f) : (_input > 0f)))
		{
			float num3 = (flag ? _vaultPush : _vaultPull);
			float num4 = Mathf.Abs(climbHoldLength - 2f);
			float num5 = num3 * _strength * Mathf.Clamp01(num4 / 2f);
			float num6 = Mathf.MoveTowards(climbHoldLength, 2f, num5 * Time.fixedDeltaTime);
			num2 = (flag ? Mathf.Max(num2, num6) : Mathf.Min(num2, num6));
		}
		climbHoldLength = Mathf.Clamp(num2, Mathf.Min(0.5f, climbHoldLength), climbHoldMaxLength);
	}

	private void ClimbPhysLogic()
	{
		//IL_0065: Unknown result type (might be due to invalid IL or missing references)
		//IL_006a: Unknown result type (might be due to invalid IL or missing references)
		//IL_006c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0095: Unknown result type (might be due to invalid IL or missing references)
		//IL_0097: Unknown result type (might be due to invalid IL or missing references)
		//IL_009c: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a1: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a2: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b9: Unknown result type (might be due to invalid IL or missing references)
		//IL_00be: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e8: Unknown result type (might be due to invalid IL or missing references)
		//IL_0117: Unknown result type (might be due to invalid IL or missing references)
		//IL_011c: Unknown result type (might be due to invalid IL or missing references)
		//IL_011f: Unknown result type (might be due to invalid IL or missing references)
		//IL_012c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0131: Unknown result type (might be due to invalid IL or missing references)
		//IL_0133: Unknown result type (might be due to invalid IL or missing references)
		//IL_013a: Unknown result type (might be due to invalid IL or missing references)
		//IL_013f: Unknown result type (might be due to invalid IL or missing references)
		//IL_014b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0167: Unknown result type (might be due to invalid IL or missing references)
		//IL_017d: Unknown result type (might be due to invalid IL or missing references)
		//IL_01d1: Unknown result type (might be due to invalid IL or missing references)
		//IL_01d3: Unknown result type (might be due to invalid IL or missing references)
		//IL_01d8: Unknown result type (might be due to invalid IL or missing references)
		//IL_01e5: Unknown result type (might be due to invalid IL or missing references)
		//IL_01ff: Unknown result type (might be due to invalid IL or missing references)
		//IL_0201: Unknown result type (might be due to invalid IL or missing references)
		//IL_0206: Unknown result type (might be due to invalid IL or missing references)
		//IL_0209: Unknown result type (might be due to invalid IL or missing references)
		if (grabState != GrabState.Climb || grabStateStart || !grabbed)
		{
			return;
		}
		ClimbTargetUpdate();
		if (!SemiFunc.IsMasterClientOrSingleplayer() || physGrabForcesDisabledTimer > 0f || !playerAvatar.isTumbling)
		{
			return;
		}
		Rigidbody rb = playerAvatar.tumble.rb;
		if (Object.op_Implicit((Object)(object)rb))
		{
			Vector3 worldCenterOfMass = rb.worldCenterOfMass;
			Vector3 val = wallClimbPosition;
			float num = ClimbStrengthGet();
			climbStrengthEase = Mathf.Lerp(climbStrengthEase, num, Time.fixedDeltaTime * 2f);
			Vector3 offset = worldCenterOfMass - grabClimbPos;
			Vector3 steering = (val - worldCenterOfMass) / Mathf.Max(offset.magnitude, 0.25f);
			float num2 = Mathf.Max(0f, climbForceMultiplier);
			float strength = climbStrengthEase * num2;
			float fullStrength = num * num2;
			Vector3 val2 = Vector3.zero;
			if (isLocal || grabInputTimestamp - climbGrabTimestamp > 0)
			{
				Transform overrideTransform = playerAvatar.localCamera.GetOverrideTransform();
				Vector3 normalized = offset.normalized;
				float num3 = 0f - overrideTransform.forward.y;
				val2 = Vector3.Cross(overrideTransform.right, normalized) * num3;
				float num4 = Mathf.InverseLerp(0.8f, 1f, 0f - normalized.y) * Mathf.Max(0f, num3);
				float vaultPull = Mathf.Clamp01(val2.y + num4);
				float vaultPush = Mathf.Max(0f, normalized.y) * Mathf.Max(0f, num3);
				float input = (isPushing ? 1f : 0f) - (isPulling ? 1f : 0f);
				ClimbHoldLengthUpdate(input, vaultPull, vaultPush, strength);
			}
			Vector3 val3 = ClimbAccelerationGet(offset, rb.linearVelocity, steering, playerAvatar.tumble.GravityAccelerationGet(), climbHoldLength, strength, fullStrength, climbSwingDamping, Time.fixedDeltaTime, val2);
			rb.AddForce(val3, (ForceMode)5);
			playerAvatar.tumble.OverrideLookAtCamera(0.5f, 5f, 10f);
		}
	}

	public void PhysGrabOverCharge(float _amount, float _multiplier = 1f)
	{
		if (!(overrideOverchargeDisableTimer > 0f) && !PlayerController.instance.DebugDisableOvercharge && SemiFunc.MoonLevel() >= 2)
		{
			float num = 1f;
			if (SemiFunc.MoonLevel() == 3)
			{
				num = 1.25f;
			}
			else if (SemiFunc.MoonLevel() >= 4)
			{
				num = 1.5f;
			}
			if (physGrabBeamOverChargeAmount == 0f && physGrabBeamOverchargeInitialBoostCooldown <= 0f)
			{
				physGrabBeamOverchargeInitialBoostCooldown = 1f;
				physGrabBeamOverChargeFloat += 0.1f * _multiplier * num;
			}
			physGrabBeamOverChargeAmount = _amount * num;
			physGrabBeamOverChargeTimer = 0.2f;
			physGrabBeamOverchargeDecreaseCooldown = 1.5f;
		}
	}

	private void PhysGrabOverChargeImpact()
	{
		//IL_0021: Unknown result type (might be due to invalid IL or missing references)
		//IL_0027: Unknown result type (might be due to invalid IL or missing references)
		if (SemiFunc.IsMultiplayer())
		{
			photonView.RPC("PhysGrabOverChargeImpactRPC", (RpcTarget)0, Array.Empty<object>());
		}
		else
		{
			PhysGrabOverChargeImpactRPC();
		}
	}

	[PunRPC]
	public void PhysGrabOverChargeImpactRPC(PhotonMessageInfo _info = default(PhotonMessageInfo))
	{
		//IL_0000: Unknown result type (might be due to invalid IL or missing references)
		if (SemiFunc.OwnerOnlyRPC(_info, photonView))
		{
			physGrabBeam.GetComponent<PhysGrabBeam>().OverChargeLaunchPlayer();
		}
	}

	private void PhysGrabOverChargeLogic()
	{
		//IL_0057: Unknown result type (might be due to invalid IL or missing references)
		//IL_005c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0062: Unknown result type (might be due to invalid IL or missing references)
		//IL_0067: Unknown result type (might be due to invalid IL or missing references)
		if (overrideOverchargeDisableTimer > 0f)
		{
			return;
		}
		if (physGrabBeamOverchargeInitialBoostCooldown > 0f)
		{
			physGrabBeamOverchargeInitialBoostCooldown -= Time.deltaTime;
		}
		if (physGrabBeamOverChargeFloat > 1f)
		{
			physGrabBeamOverChargeFloat = 1f;
		}
		if (!isLocal)
		{
			return;
		}
		if (!grabbed)
		{
			currentGrabForce = Vector3.zero;
			currentTorqueForce = Vector3.zero;
			physGrabBeamOverChargeAmount = 0f;
			physGrabBeamOverChargeTimer = 0f;
		}
		if (physGrabBeamOverChargeTimer <= 0f)
		{
			physGrabBeamOverChargeAmount = 0f;
		}
		if (physGrabBeamOverChargeTimer > 0f)
		{
			physGrabBeamOverChargeFloat += physGrabBeamOverChargeAmount * Time.deltaTime;
			if (physGrabBeamOverChargeFloat >= 1f)
			{
				physGrabBeamOverChargeFloat = 1f;
				OverrideGrabRelease(-1);
				PhysGrabOverChargeImpact();
				physGrabBeamOverChargeTimer = 0f;
			}
			physGrabBeamOverCharge = (byte)(physGrabBeamOverChargeFloat * 200f);
			physGrabBeamOverChargeTimer -= Time.deltaTime;
		}
		else if (physGrabBeamOverChargeFloat > 0f)
		{
			if (physGrabBeamOverchargeDecreaseCooldown > 0f)
			{
				physGrabBeamOverchargeDecreaseCooldown -= Time.deltaTime;
				return;
			}
			physGrabBeamOverChargeFloat -= 0.1f * Time.deltaTime;
			physGrabBeamOverCharge = (byte)(physGrabBeamOverChargeFloat * 200f);
		}
		else if (physGrabBeamOverCharge > 0)
		{
			physGrabBeamOverCharge = 0;
		}
	}

	public void OverrideGrabDistance(float dist)
	{
		prevPullerDistance = pullerDistance;
		pullerDistance = dist;
		overrideGrabDistance = dist;
		overrideGrabDistanceTimer = 0.1f;
	}

	public void OverrideMinimumGrabDistance(float dist)
	{
		overrideMinimumGrabDistance = dist;
		overrideMinimumGrabDistanceTimer = 0.1f;
	}

	private void OverrideGrabDistanceTick()
	{
		if (overrideGrabDistanceTimer > 0f)
		{
			overrideGrabDistanceTimer -= Time.deltaTime;
		}
		else if (overrideGrabDistanceTimer != -123f)
		{
			overrideGrabDistance = 0f;
			overrideGrabDistanceTimer = -123f;
		}
		if (overrideMinimumGrabDistanceTimer > 0f)
		{
			overrideMinimumGrabDistanceTimer -= Time.deltaTime;
		}
		else if (overrideMinimumGrabDistanceTimer != -123f)
		{
			overrideMinimumGrabDistance = 0f;
			minDistanceFromPlayer = minDistanceFromPlayerOriginal;
			overrideMinimumGrabDistanceTimer = -123f;
		}
	}

	private void OverrideGrabStrengthTick()
	{
		if (overrideGrabStrengthTimer > 0f)
		{
			overrideGrabStrengthTimer -= Time.deltaTime;
		}
		else if (overrideGrabStrengthTimer != -123f)
		{
			overrideGrabStrength = -1f;
			overrideGrabStrengthTimer = -123f;
		}
	}

	private IEnumerator LateStart()
	{
		if (!SemiFunc.MenuLevel())
		{
			while (!Object.op_Implicit((Object)(object)playerAvatar) || string.IsNullOrEmpty(playerAvatar.steamID))
			{
				yield return (object)new WaitForSeconds(0.2f);
			}
			string _steamID = SemiFunc.PlayerGetSteamID(playerAvatar);
			yield return (object)new WaitForSeconds(0.2f);
			while (!StatsManager.instance.statsSynced && !StatsManager.instance.playerUpgradeStrength.ContainsKey(_steamID) && !StatsManager.instance.playerUpgradeThrow.ContainsKey(_steamID) && !StatsManager.instance.playerUpgradeRange.ContainsKey(_steamID))
			{
				yield return (object)new WaitForSeconds(0.2f);
			}
			grabStrength += (float)StatsManager.instance.playerUpgradeStrength.GetValueOrDefault(_steamID, 0) * 0.2f;
			throwStrength += (float)StatsManager.instance.playerUpgradeThrow.GetValueOrDefault(_steamID, 0) * 0.3f;
			grabRange += (float)StatsManager.instance.playerUpgradeRange.GetValueOrDefault(_steamID, 0) * 1f;
		}
	}

	public void SoundsSetup()
	{
		SoundSetup(startSound);
		SoundSetup(loopSound);
		SoundSetup(stopSound);
	}

	private void SoundSetup(Sound _sound)
	{
		_sound.StoreDefault();
		if ((!SemiFunc.IsMultiplayer() || photonView.IsMine) && playerAvatar.playerAvatarVisuals.showSelfOverrideTimer <= 0f)
		{
			_sound.Volume = _sound.VolumeDefault;
			_sound.VolumeRandom = _sound.VolumeRandomDefault;
			_sound.SpatialBlend = 0f;
		}
		else
		{
			_sound.Volume = _sound.VolumeDefault * 0.5f;
			_sound.VolumeRandom = _sound.VolumeRandomDefault * 0.5f;
			_sound.SpatialBlend = 1f;
		}
	}

	public void OverrideDisableRotationControls()
	{
		overrideDisableRotationControls = true;
		overrideDisableRotationControlsTimer = 0.1f;
	}

	private void OverrideDisableRotationControlsTick()
	{
		if (overrideDisableRotationControlsTimer > 0f)
		{
			overrideDisableRotationControlsTimer -= Time.fixedDeltaTime;
			if (overrideDisableRotationControlsTimer <= 0f)
			{
				overrideDisableRotationControls = false;
			}
		}
	}

	public void OverrideGrab(PhysGrabObject target, float _grabTime = 0.1f, bool _grabRelease = false)
	{
		if (grabbed && Object.op_Implicit((Object)(object)target) && (Object)(object)grabbedPhysGrabObject != (Object)(object)target)
		{
			ReleaseObject(-1);
		}
		overrideGrabTarget = target;
		overrideGrabTimer = _grabTime;
		overrideGrabRelease = _grabRelease;
	}

	public void OverrideMinimumGrabTime(PhysGrabObject _target, float _time = 0.1f)
	{
		if (!isLocal || !Object.op_Implicit((Object)(object)_target))
		{
			return;
		}
		if (_time <= 0f)
		{
			if (!((Object)(object)overrideMinimumGrabTarget != (Object)(object)_target))
			{
				overrideMinimumGrabTimer = 0f;
				overrideMinimumGrabDuration = 0f;
				overrideMinimumGrabTarget = null;
			}
			return;
		}
		if ((Object)(object)overrideMinimumGrabTarget != (Object)(object)_target)
		{
			overrideMinimumGrabTimer = 0f;
			overrideMinimumGrabDuration = 0f;
		}
		overrideMinimumGrabTarget = _target;
		overrideMinimumGrabDuration = Mathf.Max(overrideMinimumGrabDuration, _time);
		overrideMinimumGrabTimer = Mathf.Max(overrideMinimumGrabTimer, overrideMinimumGrabDuration + Time.deltaTime);
		if (!grabbed || (Object)(object)grabbedPhysGrabObject != (Object)(object)_target)
		{
			ForceGrabPhysObject(_target, _toggleGrab: false);
			OverrideMinimumGrabTimeReacquired();
		}
	}

	private void OverrideMinimumGrabTimeTick()
	{
		if (!(overrideMinimumGrabTimer <= 0f))
		{
			overrideMinimumGrabTimer = Mathf.Max(0f, overrideMinimumGrabTimer - Time.deltaTime);
			if (!Object.op_Implicit((Object)(object)overrideMinimumGrabTarget))
			{
				overrideMinimumGrabTimer = 0f;
				overrideMinimumGrabDuration = 0f;
			}
			else if (overrideMinimumGrabTimer <= 0f)
			{
				overrideMinimumGrabTarget = null;
				overrideMinimumGrabDuration = 0f;
			}
			else if (!grabbed || (Object)(object)grabbedPhysGrabObject != (Object)(object)overrideMinimumGrabTarget)
			{
				ForceGrabPhysObject(overrideMinimumGrabTarget, _toggleGrab: false);
				OverrideMinimumGrabTimeReacquired();
			}
		}
	}

	private void OverrideMinimumGrabTimeReacquired()
	{
		if (Object.op_Implicit((Object)(object)overrideMinimumGrabTarget) && grabbed && !((Object)(object)grabbedPhysGrabObject != (Object)(object)overrideMinimumGrabTarget))
		{
			overrideMinimumGrabTimer = Mathf.Max(overrideMinimumGrabTimer, overrideMinimumGrabDuration + Time.deltaTime);
		}
	}

	private bool OverrideMinimumGrabTimeActive()
	{
		if (overrideMinimumGrabTimer > 0f && Object.op_Implicit((Object)(object)overrideMinimumGrabTarget))
		{
			return (Object)(object)grabbedPhysGrabObject == (Object)(object)overrideMinimumGrabTarget;
		}
		return false;
	}

	private void OverrideMinimumGrabTimeRelease(int _releaseObjectViewID)
	{
		if (Object.op_Implicit((Object)(object)overrideMinimumGrabTarget) && (!grabbed || !((Object)(object)grabbedPhysGrabObject != (Object)(object)overrideMinimumGrabTarget)) && (_releaseObjectViewID == -1 || (Object.op_Implicit((Object)(object)overrideMinimumGrabTarget.photonView) && overrideMinimumGrabTarget.photonView.ViewID == _releaseObjectViewID)))
		{
			overrideMinimumGrabTimer = 0f;
			overrideMinimumGrabDuration = 0f;
			overrideMinimumGrabTarget = null;
		}
	}

	public void OverrideBeamColor(Color _color, float _time = 0.1f)
	{
		//IL_0001: Unknown result type (might be due to invalid IL or missing references)
		//IL_0002: Unknown result type (might be due to invalid IL or missing references)
		overrideBeamColor = _color;
		overrideBeamColorTimer = _time;
	}

	public void OverrideOverchargeDisable(float _disableTimer = 0.1f)
	{
		overrideOverchargeDisableTimer = _disableTimer;
	}

	public void OverrideGrabPoint(Transform grabPoint)
	{
		overrideGrabPointTransform = grabPoint;
		overrideGrabPointTimer = 0.1f;
	}

	public void OverrideGrabStrength(float strength, float time = 0.1f)
	{
		overrideGrabStrength = strength;
		overrideGrabStrengthTimer = time;
	}

	public void OverrideGrabberVisualPosition(Transform _target)
	{
		overrideGrabberVisualPositionTimer = 0.1f;
		overrideGrabberVisualTransform = _target;
		ApplyGrabberVisualOverride();
	}

	private void ApplyGrabberVisualOverride()
	{
		//IL_001a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0030: Unknown result type (might be due to invalid IL or missing references)
		if (Object.op_Implicit((Object)(object)overrideGrabberVisualTransform))
		{
			physGrabPoint.position = overrideGrabberVisualTransform.position;
			physGrabPoint.rotation = overrideGrabberVisualTransform.rotation;
		}
	}

	public void OverrideAimTransform(Transform aimTransform, float time = 0.1f)
	{
		overrideAimTransform = aimTransform;
		overrideAimTransformTimer = time;
	}

	private void OverrideAimTransformTick()
	{
		if (overrideAimTransformTimer > 0f)
		{
			overrideAimTransformTimer -= Time.fixedDeltaTime;
			if (!Object.op_Implicit((Object)(object)overrideAimTransform))
			{
				overrideAimTransformTimer = 0f;
			}
		}
	}

	public void OverrideGrabRelease(int releaseObjectViewID, float _disableTimer = 0.5f)
	{
		if (SemiFunc.IsMultiplayer() && !SemiFunc.IsMasterClient() && !photonView.IsMine)
		{
			return;
		}
		if (!SemiFunc.IsMultiplayer())
		{
			ReleaseObject(releaseObjectViewID, _disableTimer);
			return;
		}
		Player val = (Object.op_Implicit((Object)(object)photonView) ? photonView.Owner : null);
		if (val != null)
		{
			int num = ((releaseObjectViewID == -1) ? (-1) : grabRevision);
			photonView.RPC("ReleaseObjectRPC", val, new object[4] { false, _disableTimer, releaseObjectViewID, num });
		}
	}

	public void OverrideGrabDisable(float _time)
	{
		if (_time > grabDisableTimer)
		{
			grabDisableTimer = _time;
		}
	}

	private void OverrideGrabTick()
	{
		if (overrideGrabTimer <= 0f)
		{
			if (overrideGrabRelease && (!Object.op_Implicit((Object)(object)overrideGrabTarget) || (Object)(object)grabbedPhysGrabObject == (Object)(object)overrideGrabTarget))
			{
				OverrideGrabRelease(-1);
			}
			overrideGrabRelease = false;
			overrideGrabTarget = null;
		}
		if (overrideGrabTimer > 0f)
		{
			overrideGrabTimer -= Time.deltaTime;
			if (Object.op_Implicit((Object)(object)overrideGrabTarget) && (Object)(object)grabbedPhysGrabObject != (Object)(object)overrideGrabTarget)
			{
				ForceGrabPhysObject(overrideGrabTarget);
			}
		}
	}

	private void OverrideBeamColorTick()
	{
		//IL_000e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0014: Unknown result type (might be due to invalid IL or missing references)
		//IL_003b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0041: Unknown result type (might be due to invalid IL or missing references)
		//IL_004f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0055: Unknown result type (might be due to invalid IL or missing references)
		if (overrideBeamColorTimer <= 0f && currentBeamColor == overrideBeamColor)
		{
			prevColorState = -1;
			ColorStates();
		}
		if (overrideBeamColorTimer > 0f)
		{
			if (currentBeamColor != overrideBeamColor)
			{
				ColorStateSetColor(overrideBeamColor, overrideBeamColor);
			}
			overrideBeamColorTimer -= Time.fixedDeltaTime;
		}
	}

	private void OverrideOverchargeDisableTick()
	{
		if (overrideOverchargeDisableTimer > 0f)
		{
			OverchargeResetValues();
			overrideOverchargeDisableTimer -= Time.fixedDeltaTime;
		}
	}

	private void OverrideSpecialPowersLogic()
	{
		physGrabBeamScript.GrabDisableLoopActive(overrideDisableSpecialGrabPowers);
		if (SemiFunc.IsMultiplayer() && !playerAvatar.photonView.IsMine)
		{
			return;
		}
		if (overrideDisableSpecialGrabPowersZapCooldown > 0f)
		{
			overrideDisableSpecialGrabPowersZapCooldown -= Time.deltaTime;
		}
		bool flag = false;
		if (overrideDisableSpecialGrabPowersTimer > 0f)
		{
			overrideDisableSpecialGrabPowersTimer -= Time.deltaTime;
			flag = true;
		}
		if (flag != overrideDisableSpecialGrabPowers)
		{
			overrideDisableSpecialGrabPowers = flag;
			if (SemiFunc.IsMultiplayer())
			{
				photonView.RPC("OverrideDisableSpecialGrabPowersSetRPC", (RpcTarget)0, new object[1] { flag });
			}
		}
	}

	[PunRPC]
	public void OverrideDisableSpecialGrabPowersSetRPC(bool _active, PhotonMessageInfo _info = default(PhotonMessageInfo))
	{
		//IL_0000: Unknown result type (might be due to invalid IL or missing references)
		if (SemiFunc.OwnerOnlyRPC(_info, photonView))
		{
			overrideDisableSpecialGrabPowers = _active;
		}
	}

	public void OverrideDisableSpecialGrabPowers(float _time = 1f)
	{
		if (SemiFunc.IsMultiplayer() && !photonView.IsMine)
		{
			Debug.LogError((object)"Disabling special grab powers should only be handled by the owner of the grabber!");
		}
		else
		{
			overrideDisableSpecialGrabPowersTimer = Mathf.Max(overrideDisableSpecialGrabPowersTimer, _time);
		}
	}

	private void GrabDisableZapTrigger(Vector3 _position)
	{
		//IL_002c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0008: Unknown result type (might be due to invalid IL or missing references)
		//IL_000b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0011: Unknown result type (might be due to invalid IL or missing references)
		if (!SemiFunc.IsMultiplayer())
		{
			GrabDisableZapRPC(_position);
			return;
		}
		photonView.RPC("GrabDisableZapRPC", (RpcTarget)0, new object[1] { _position });
	}

	[PunRPC]
	public void GrabDisableZapRPC(Vector3 _position, PhotonMessageInfo _info = default(PhotonMessageInfo))
	{
		//IL_0000: Unknown result type (might be due to invalid IL or missing references)
		//IL_0015: Unknown result type (might be due to invalid IL or missing references)
		if (SemiFunc.OwnerOnlyRPC(_info, photonView))
		{
			physGrabBeamScript.GrabDisableZap(_position);
		}
	}

	public void GrabberHeal()
	{
		if (!healing)
		{
			photonView.RPC("HealStart", (RpcTarget)0, Array.Empty<object>());
		}
	}

	private void ColorStateSetColor(Color mainColor, Color emissionColor)
	{
		//IL_0001: Unknown result type (might be due to invalid IL or missing references)
		//IL_0002: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b1: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c5: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d4: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e8: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f7: Unknown result type (might be due to invalid IL or missing references)
		//IL_010b: Unknown result type (might be due to invalid IL or missing references)
		//IL_011a: Unknown result type (might be due to invalid IL or missing references)
		//IL_012e: Unknown result type (might be due to invalid IL or missing references)
		//IL_013f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0150: Unknown result type (might be due to invalid IL or missing references)
		//IL_0166: Unknown result type (might be due to invalid IL or missing references)
		//IL_0177: Unknown result type (might be due to invalid IL or missing references)
		//IL_018d: Unknown result type (might be due to invalid IL or missing references)
		currentBeamColor = mainColor;
		Material material = ((Renderer)physGrabBeam.GetComponent<LineRenderer>()).material;
		Material material2 = ((Renderer)physGrabPointVisual1.GetComponent<MeshRenderer>()).material;
		Material material3 = ((Renderer)physGrabPointVisual2.GetComponent<MeshRenderer>()).material;
		Material material4 = ((Renderer)((Component)physGrabPointVisualRotate).GetComponent<MeshRenderer>()).material;
		Light grabberLight = playerAvatar.playerAvatarVisuals.playerAvatarRightArm.grabberLight;
		Material material5 = ((Renderer)playerAvatar.playerAvatarVisuals.playerAvatarRightArm.grabberOrbSpheres[0].GetComponent<MeshRenderer>()).material;
		Material material6 = ((Renderer)playerAvatar.playerAvatarVisuals.playerAvatarRightArm.grabberOrbSpheres[1].GetComponent<MeshRenderer>()).material;
		if (Object.op_Implicit((Object)(object)material))
		{
			material.color = mainColor;
		}
		if (Object.op_Implicit((Object)(object)material))
		{
			material.SetColor("_EmissionColor", emissionColor);
		}
		if (Object.op_Implicit((Object)(object)material2))
		{
			material2.color = mainColor;
		}
		if (Object.op_Implicit((Object)(object)material2))
		{
			material2.SetColor("_EmissionColor", emissionColor);
		}
		if (Object.op_Implicit((Object)(object)material3))
		{
			material3.color = mainColor;
		}
		if (Object.op_Implicit((Object)(object)material3))
		{
			material3.SetColor("_EmissionColor", emissionColor);
		}
		if (Object.op_Implicit((Object)(object)material4))
		{
			material4.color = mainColor;
		}
		if (Object.op_Implicit((Object)(object)material4))
		{
			material4.SetColor("_EmissionColor", emissionColor);
		}
		if (Object.op_Implicit((Object)(object)grabberLight))
		{
			grabberLight.color = mainColor;
		}
		if (Object.op_Implicit((Object)(object)material5))
		{
			material5.color = mainColor;
		}
		if (Object.op_Implicit((Object)(object)material5))
		{
			material5.SetColor("_EmissionColor", emissionColor);
		}
		if (Object.op_Implicit((Object)(object)material6))
		{
			material6.color = mainColor;
		}
		if (Object.op_Implicit((Object)(object)material6))
		{
			material6.SetColor("_EmissionColor", emissionColor);
		}
	}

	public void OverrideColorToGreen(float time = 0.1f)
	{
		colorState = 1;
		colorStateOverrideTimer = time;
	}

	public void OverrideAlwaysGrabbable(float time = 0.1f)
	{
		overrideAlwaysGrabbableTimer = time;
	}

	public void OverrideColorToPurple(float time = 0.1f)
	{
		colorState = 2;
		colorStateOverrideTimer = time;
	}

	private void ColorStates()
	{
		//IL_0031: Unknown result type (might be due to invalid IL or missing references)
		//IL_004c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0098: Unknown result type (might be due to invalid IL or missing references)
		//IL_007b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0109: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ec: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b9: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ba: Unknown result type (might be due to invalid IL or missing references)
		//IL_017a: Unknown result type (might be due to invalid IL or missing references)
		//IL_015d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0124: Unknown result type (might be due to invalid IL or missing references)
		//IL_012a: Unknown result type (might be due to invalid IL or missing references)
		//IL_012b: Unknown result type (might be due to invalid IL or missing references)
		//IL_01eb: Unknown result type (might be due to invalid IL or missing references)
		//IL_01ce: Unknown result type (might be due to invalid IL or missing references)
		//IL_0195: Unknown result type (might be due to invalid IL or missing references)
		//IL_019b: Unknown result type (might be due to invalid IL or missing references)
		//IL_019c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0206: Unknown result type (might be due to invalid IL or missing references)
		//IL_020c: Unknown result type (might be due to invalid IL or missing references)
		//IL_020d: Unknown result type (might be due to invalid IL or missing references)
		if (prevColorState != colorState)
		{
			prevColorState = colorState;
			Color val = new Color(1f, 0.1856f, 0f, 0.15f);
			Color val2 = new Color(1f, 0.1856f, 0f, 1f);
			if (colorState == 0)
			{
				val = (Object.op_Implicit((Object)(object)VideoGreenScreen.instance) ? new Color(1f, 0.1856f, 0f, 1f) : new Color(1f, 0.1856f, 0f, 0.15f));
				val2 = new Color(1f, 0.1856f, 0f, 1f);
				ColorStateSetColor(val, val2);
			}
			else if (colorState == 1)
			{
				val = (Object.op_Implicit((Object)(object)VideoGreenScreen.instance) ? new Color(0f, 1f, 0f, 1f) : new Color(0f, 1f, 0f, 0.15f));
				val2 = new Color(0f, 1f, 0f, 1f);
				ColorStateSetColor(val, val2);
			}
			else if (colorState == 2)
			{
				val = (Object.op_Implicit((Object)(object)VideoGreenScreen.instance) ? new Color(1f, 0f, 1f, 1f) : new Color(1f, 0f, 1f, 0.15f));
				val2 = new Color(1f, 0f, 1f, 1f);
				ColorStateSetColor(val, val2);
			}
			else if (colorState == 3)
			{
				val = (Object.op_Implicit((Object)(object)VideoGreenScreen.instance) ? new Color(0f, 0.5f, 1f, 1f) : new Color(0f, 0.5f, 1f, 0.15f));
				val2 = new Color(0f, 0.5f, 1f, 1f);
				ColorStateSetColor(val, val2);
			}
		}
	}

	private void ColorStateTick()
	{
		if (colorStateOverrideTimer > 0f)
		{
			colorStateOverrideTimer -= Time.fixedDeltaTime;
		}
		else
		{
			colorState = 0;
		}
	}

	[PunRPC]
	private void HealStart(PhotonMessageInfo _info = default(PhotonMessageInfo))
	{
		//IL_0000: Unknown result type (might be due to invalid IL or missing references)
		//IL_0066: Unknown result type (might be due to invalid IL or missing references)
		//IL_006b: Unknown result type (might be due to invalid IL or missing references)
		if (SemiFunc.OwnerOnlyRPC(_info, photonView))
		{
			((Renderer)physGrabBeam.GetComponent<LineRenderer>()).material = physGrabBeamMaterialBatteryCharge;
			((Renderer)physGrabPointVisual1.GetComponent<MeshRenderer>()).material = physGrabBeamMaterialBatteryCharge;
			((Renderer)physGrabPointVisual2.GetComponent<MeshRenderer>()).material = physGrabBeamMaterialBatteryCharge;
			physGrabBeam.GetComponent<PhysGrabBeam>().scrollSpeed = new Vector2(-5f, 0f);
			physGrabBeam.GetComponent<PhysGrabBeam>().lineMaterial = ((Renderer)physGrabBeam.GetComponent<LineRenderer>()).material;
			healing = true;
		}
	}

	private void ResetBeam()
	{
		//IL_0063: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		if (healing)
		{
			((Renderer)physGrabBeam.GetComponent<LineRenderer>()).material = physGrabBeamMaterial;
			((Renderer)physGrabPointVisual1.GetComponent<MeshRenderer>()).material = physGrabBeamMaterial;
			((Renderer)physGrabPointVisual2.GetComponent<MeshRenderer>()).material = physGrabBeamMaterial;
			physGrabBeam.GetComponent<PhysGrabBeam>().scrollSpeed = physGrabBeam.GetComponent<PhysGrabBeam>().originalScrollSpeed;
			physGrabBeam.GetComponent<PhysGrabBeam>().lineMaterial = ((Renderer)physGrabBeam.GetComponent<LineRenderer>()).material;
			healing = false;
		}
	}

	public void ChangeBeamAlpha(float alpha)
	{
		if (physGramBeamAlphaTimer == -123f)
		{
			physGrabBeamAlpha = physGrabBeamAlphaOriginal;
		}
		physGrabBeamAlphaChangeTo = alpha;
		physGramBeamAlphaTimer = 0.1f;
		physGrabBeamAlphaChangeProgress = 0f;
	}

	private void TickerBeamAlphaChange()
	{
		//IL_0165: Unknown result type (might be due to invalid IL or missing references)
		//IL_0170: Unknown result type (might be due to invalid IL or missing references)
		//IL_017b: Unknown result type (might be due to invalid IL or missing references)
		//IL_018b: Unknown result type (might be due to invalid IL or missing references)
		//IL_01c2: Unknown result type (might be due to invalid IL or missing references)
		//IL_01ce: Unknown result type (might be due to invalid IL or missing references)
		//IL_01da: Unknown result type (might be due to invalid IL or missing references)
		//IL_01ea: Unknown result type (might be due to invalid IL or missing references)
		//IL_01fd: Unknown result type (might be due to invalid IL or missing references)
		//IL_0209: Unknown result type (might be due to invalid IL or missing references)
		//IL_0215: Unknown result type (might be due to invalid IL or missing references)
		//IL_0225: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0078: Unknown result type (might be due to invalid IL or missing references)
		//IL_0083: Unknown result type (might be due to invalid IL or missing references)
		//IL_0093: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c6: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d1: Unknown result type (might be due to invalid IL or missing references)
		//IL_00dc: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ec: Unknown result type (might be due to invalid IL or missing references)
		//IL_00fd: Unknown result type (might be due to invalid IL or missing references)
		//IL_0108: Unknown result type (might be due to invalid IL or missing references)
		//IL_0113: Unknown result type (might be due to invalid IL or missing references)
		//IL_0123: Unknown result type (might be due to invalid IL or missing references)
		if (physGramBeamAlphaTimer > 0f)
		{
			physGrabBeamAlpha = Mathf.Lerp(physGrabBeamAlpha, physGrabBeamAlphaChangeTo, physGrabBeamAlphaChangeProgress);
			if (physGrabBeamAlphaChangeProgress < 1f)
			{
				physGrabBeamAlphaChangeProgress += 4f * Time.deltaTime;
				Material material = ((Renderer)physGrabBeam.GetComponent<LineRenderer>()).material;
				material.SetColor("_Color", new Color(material.color.r, material.color.g, material.color.b, physGrabBeamAlpha));
				Material material2 = ((Renderer)physGrabPointVisual1.GetComponent<MeshRenderer>()).material;
				Material material3 = ((Renderer)physGrabPointVisual2.GetComponent<MeshRenderer>()).material;
				material2.SetColor("_Color", new Color(material2.color.r, material2.color.g, material2.color.b, physGrabBeamAlpha));
				material3.SetColor("_Color", new Color(material3.color.r, material3.color.g, material3.color.b, physGrabBeamAlpha));
			}
		}
		else if (physGramBeamAlphaTimer != -123f)
		{
			physGrabBeamAlphaChangeProgress = 0f;
			Material material4 = ((Renderer)physGrabBeam.GetComponent<LineRenderer>()).material;
			material4.SetColor("_Color", new Color(material4.color.r, material4.color.g, material4.color.b, physGrabBeamAlphaOriginal));
			Material material5 = ((Renderer)physGrabPointVisual1.GetComponent<MeshRenderer>()).material;
			Material material6 = ((Renderer)physGrabPointVisual2.GetComponent<MeshRenderer>()).material;
			material5.SetColor("_Color", new Color(material5.color.r, material5.color.g, material5.color.b, physGrabBeamAlphaOriginal));
			material6.SetColor("_Color", new Color(material6.color.r, material6.color.g, material6.color.b, physGrabBeamAlphaOriginal));
			physGramBeamAlphaTimer = -123f;
		}
		if (physGramBeamAlphaTimer > 0f)
		{
			physGramBeamAlphaTimer -= Time.deltaTime;
		}
	}

	public Quaternion GetRotationInput()
	{
		//IL_000b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0010: Unknown result type (might be due to invalid IL or missing references)
		//IL_0015: Unknown result type (might be due to invalid IL or missing references)
		//IL_0022: Unknown result type (might be due to invalid IL or missing references)
		//IL_0027: Unknown result type (might be due to invalid IL or missing references)
		//IL_0037: Unknown result type (might be due to invalid IL or missing references)
		//IL_003c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0041: Unknown result type (might be due to invalid IL or missing references)
		//IL_0042: Unknown result type (might be due to invalid IL or missing references)
		//IL_0043: Unknown result type (might be due to invalid IL or missing references)
		//IL_0048: Unknown result type (might be due to invalid IL or missing references)
		//IL_0049: Unknown result type (might be due to invalid IL or missing references)
		Quaternion val = Quaternion.AngleAxis(mouseTurningVelocity.y, Vector3.right);
		Quaternion val2 = Quaternion.AngleAxis(0f - mouseTurningVelocity.x, Vector3.up);
		Quaternion val3 = Quaternion.AngleAxis(mouseTurningVelocity.z, Vector3.forward);
		return val2 * val * val3;
	}

	private Vector3 ObjectTurnAccelerationGet(float _mass)
	{
		//IL_000a: Unknown result type (might be due to invalid IL or missing references)
		//IL_000f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0014: Unknown result type (might be due to invalid IL or missing references)
		//IL_008c: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ac: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b1: Unknown result type (might be due to invalid IL or missing references)
		//IL_0071: Unknown result type (might be due to invalid IL or missing references)
		//IL_0077: Unknown result type (might be due to invalid IL or missing references)
		//IL_0081: Unknown result type (might be due to invalid IL or missing references)
		//IL_0086: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e0: Unknown result type (might be due to invalid IL or missing references)
		//IL_00fc: Unknown result type (might be due to invalid IL or missing references)
		//IL_00cc: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d8: Unknown result type (might be due to invalid IL or missing references)
		//IL_00dd: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c6: Unknown result type (might be due to invalid IL or missing references)
		//IL_0166: Unknown result type (might be due to invalid IL or missing references)
		//IL_0171: Unknown result type (might be due to invalid IL or missing references)
		InputManager inputManager = InputManager.instance;
		Vector3 val = Vector2.op_Implicit(inputManager.LookInputGet(out var _device, _useStickTravel: true));
		if (_device is Gamepad)
		{
			float num = Mathf.InverseLerp(0.2f, 1f, val.magnitude);
			float num2 = Mathf.Lerp(0.5f, 2.5f, num * num);
			float num3 = Mathf.Pow(4f, ((float)inputManager.inputPercentSettings[InputPercentSetting.RotationSensitivityGamepad] - 50f) / 50f);
			val = Vector3.ClampMagnitude(val * (num2 * num3), 5f);
		}
		else
		{
			val *= Mathf.Lerp(0.2f, 2.5f, GameplayManager.instance.aimSensitivity / 100f);
			if (_device is Pointer)
			{
				if (Time.unscaledDeltaTime <= 0f)
				{
					return Vector3.zero;
				}
				val /= Time.unscaledDeltaTime * 144f;
			}
			val.x = Mathf.Clamp(val.x, -5f, 5f);
			val.y = Mathf.Clamp(val.y, -5f, 5f);
		}
		float num4 = Mathf.Lerp(0.1f, 1f, _mass * 0.05f);
		float num5 = ((overrideGrabStrength >= 0f) ? overrideGrabStrength : grabStrength);
		if (grabbedPhysGrabObject.impactDetector.isCart)
		{
			num5 *= 0.25f;
		}
		return val * (225f * num4 * num5);
	}

	private float ObjectTurnMassGet()
	{
		if (!Object.op_Implicit((Object)(object)grabbedPhysGrabObject.rb))
		{
			return 1f;
		}
		return Mathf.Max(1f, grabbedPhysGrabObject.rb.mass);
	}

	private void ObjectTurningInputUpdate()
	{
		//IL_0077: Unknown result type (might be due to invalid IL or missing references)
		//IL_007c: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ce: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c0: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d5: Unknown result type (might be due to invalid IL or missing references)
		if (!isLocal)
		{
			return;
		}
		bool flag = grabbed && Object.op_Implicit((Object)(object)grabbedPhysGrabObject) && PlayerController.instance.InputDisableTimer <= 0f && SemiFunc.InputHold(InputKey.Rotate);
		if (flag)
		{
			isRotatingTimer = 0.1f;
		}
		if (!overrideDisableRotationControls)
		{
			bool flag2 = isRotatingTimer > 0f;
			if (flag2 && !isRotating && Object.op_Implicit((Object)(object)grabbedObjectTransform))
			{
				mouseTurningVelocity = Vector3.zero;
			}
			isRotating = flag2;
		}
		if (isRotatingTimer > 0f)
		{
			isRotatingTimer -= Time.deltaTime;
		}
		if (grabbed && Object.op_Implicit((Object)(object)grabbedPhysGrabObject))
		{
			Vector3 acceleration = (flag ? ObjectTurnAccelerationGet(ObjectTurnMassGet()) : Vector3.zero);
			ObjectTurnVelocityUpdate(acceleration, Time.deltaTime);
		}
	}

	private void ObjectTurnVelocityUpdate(Vector3 _acceleration, float _deltaTime)
	{
		//IL_0031: Unknown result type (might be due to invalid IL or missing references)
		//IL_0037: Unknown result type (might be due to invalid IL or missing references)
		//IL_003c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0046: Unknown result type (might be due to invalid IL or missing references)
		//IL_004b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0050: Unknown result type (might be due to invalid IL or missing references)
		//IL_0057: Unknown result type (might be due to invalid IL or missing references)
		//IL_0061: Unknown result type (might be due to invalid IL or missing references)
		//IL_0066: Unknown result type (might be due to invalid IL or missing references)
		//IL_008c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0091: Unknown result type (might be due to invalid IL or missing references)
		float num = (isRotating ? 1f : 10f);
		float num2 = Mathf.Pow(1f - num / 144f, _deltaTime * 144f);
		mouseTurningVelocity = mouseTurningVelocity * num2 + _acceleration * ((1f - num2) / num);
		mouseTurningVelocity = Vector3.ClampMagnitude(mouseTurningVelocity, 70f);
		if (_acceleration.sqrMagnitude == 0f && mouseTurningVelocity.sqrMagnitude <= 0.0001f)
		{
			mouseTurningVelocity = Vector3.zero;
		}
	}

	private void ObjectTurningGridUpdate()
	{
		//IL_002f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0070: Unknown result type (might be due to invalid IL or missing references)
		//IL_0076: Unknown result type (might be due to invalid IL or missing references)
		//IL_007c: Unknown result type (might be due to invalid IL or missing references)
		if (grabbed && Object.op_Implicit((Object)(object)grabbedPhysGrabObject) && Object.op_Implicit((Object)(object)physGrabPointVisualGrid))
		{
			physGrabPointVisualGrid.position = grabbedPhysGrabObject.midPoint;
			if (isRotating && !((Object)(object)objectTurningObject != (Object)(object)grabbedPhysGrabObject))
			{
				float num = (float)((Time.timeAsDouble - Time.fixedTimeAsDouble) / (double)Time.fixedDeltaTime);
				physGrabPointVisualGrid.rotation = Quaternion.Slerp(prevTurnGridRotation, turnGridRotation, num);
			}
		}
	}

	private void ObjectTurning()
	{
		//IL_0046: Unknown result type (might be due to invalid IL or missing references)
		//IL_004b: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c6: Unknown result type (might be due to invalid IL or missing references)
		//IL_00cb: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d7: Unknown result type (might be due to invalid IL or missing references)
		//IL_00dc: Unknown result type (might be due to invalid IL or missing references)
		//IL_0072: Unknown result type (might be due to invalid IL or missing references)
		//IL_0077: Unknown result type (might be due to invalid IL or missing references)
		//IL_010d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0112: Unknown result type (might be due to invalid IL or missing references)
		//IL_0091: Unknown result type (might be due to invalid IL or missing references)
		//IL_01bd: Unknown result type (might be due to invalid IL or missing references)
		//IL_01c2: Unknown result type (might be due to invalid IL or missing references)
		//IL_0179: Unknown result type (might be due to invalid IL or missing references)
		//IL_017e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0183: Unknown result type (might be due to invalid IL or missing references)
		//IL_0190: Unknown result type (might be due to invalid IL or missing references)
		//IL_0195: Unknown result type (might be due to invalid IL or missing references)
		//IL_019a: Unknown result type (might be due to invalid IL or missing references)
		//IL_01a6: Unknown result type (might be due to invalid IL or missing references)
		//IL_01ab: Unknown result type (might be due to invalid IL or missing references)
		//IL_0209: Unknown result type (might be due to invalid IL or missing references)
		//IL_020e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0213: Unknown result type (might be due to invalid IL or missing references)
		//IL_0221: Unknown result type (might be due to invalid IL or missing references)
		//IL_0226: Unknown result type (might be due to invalid IL or missing references)
		//IL_0237: Unknown result type (might be due to invalid IL or missing references)
		//IL_023c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0241: Unknown result type (might be due to invalid IL or missing references)
		//IL_0243: Unknown result type (might be due to invalid IL or missing references)
		//IL_0244: Unknown result type (might be due to invalid IL or missing references)
		//IL_0249: Unknown result type (might be due to invalid IL or missing references)
		//IL_024b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0250: Unknown result type (might be due to invalid IL or missing references)
		//IL_02b1: Unknown result type (might be due to invalid IL or missing references)
		//IL_02b6: Unknown result type (might be due to invalid IL or missing references)
		//IL_02c6: Unknown result type (might be due to invalid IL or missing references)
		//IL_02cb: Unknown result type (might be due to invalid IL or missing references)
		//IL_02cd: Unknown result type (might be due to invalid IL or missing references)
		//IL_02d0: Unknown result type (might be due to invalid IL or missing references)
		//IL_02d5: Unknown result type (might be due to invalid IL or missing references)
		//IL_02da: Unknown result type (might be due to invalid IL or missing references)
		//IL_02e2: Unknown result type (might be due to invalid IL or missing references)
		//IL_02e7: Unknown result type (might be due to invalid IL or missing references)
		//IL_02e9: Unknown result type (might be due to invalid IL or missing references)
		//IL_02eb: Unknown result type (might be due to invalid IL or missing references)
		//IL_031d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0322: Unknown result type (might be due to invalid IL or missing references)
		//IL_0327: Unknown result type (might be due to invalid IL or missing references)
		//IL_0334: Unknown result type (might be due to invalid IL or missing references)
		//IL_0339: Unknown result type (might be due to invalid IL or missing references)
		//IL_033e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0308: Unknown result type (might be due to invalid IL or missing references)
		//IL_030a: Unknown result type (might be due to invalid IL or missing references)
		//IL_030e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0313: Unknown result type (might be due to invalid IL or missing references)
		//IL_0373: Unknown result type (might be due to invalid IL or missing references)
		//IL_0375: Unknown result type (might be due to invalid IL or missing references)
		//IL_037a: Unknown result type (might be due to invalid IL or missing references)
		//IL_037f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0384: Unknown result type (might be due to invalid IL or missing references)
		//IL_038b: Unknown result type (might be due to invalid IL or missing references)
		//IL_038d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0392: Unknown result type (might be due to invalid IL or missing references)
		//IL_0397: Unknown result type (might be due to invalid IL or missing references)
		//IL_039c: Unknown result type (might be due to invalid IL or missing references)
		//IL_03d8: Unknown result type (might be due to invalid IL or missing references)
		//IL_03e0: Unknown result type (might be due to invalid IL or missing references)
		//IL_03e7: Unknown result type (might be due to invalid IL or missing references)
		//IL_03ec: Unknown result type (might be due to invalid IL or missing references)
		if (Object.op_Implicit((Object)(object)objectTurningObject) && (!grabbed || (Object)(object)objectTurningObject != (Object)(object)grabbedPhysGrabObject))
		{
			objectTurningObject = null;
		}
		if (!Object.op_Implicit((Object)(object)grabbedPhysGrabObject))
		{
			return;
		}
		if (!grabbed)
		{
			mouseTurningVelocity = Vector3.zero;
			((Component)physGrabPointVisualGrid).gameObject.SetActive(false);
			isRotating = false;
			return;
		}
		if (!isLocal && mouseTurningVelocity != Vector3.zero)
		{
			if (remoteRotationSampleTimer <= 0f)
			{
				ObjectTurnVelocityUpdate(Vector3.zero, Time.fixedDeltaTime);
			}
			if (remoteRotationSampleTimer > 0f)
			{
				remoteRotationSampleTimer -= Time.fixedDeltaTime;
			}
		}
		cameraRelativeGrabbedForward = cameraRelativeGrabbedForward.normalized;
		cameraRelativeGrabbedUp = cameraRelativeGrabbedUp.normalized;
		if (isRotating)
		{
			float num = ObjectTurnMassGet();
			if ((Object)(object)objectTurningObject != (Object)(object)grabbedPhysGrabObject)
			{
				turnGridRotation = physGrabPointVisualGrid.rotation;
			}
			objectTurningObject = grabbedPhysGrabObject;
			if (!isLocal || !DebugCommandHandler.instance.hideGrabber)
			{
				((Component)physGrabPointVisualGrid).gameObject.SetActive(true);
			}
			Transform overrideTransform = playerAvatar.localCamera.GetOverrideTransform();
			if (physRotatingTimer <= 0f)
			{
				physRotatingTimer = 0.25f;
				cameraRelativeGrabbedForward = overrideTransform.InverseTransformDirection(grabbedObjectTransform.forward);
				cameraRelativeGrabbedUp = overrideTransform.InverseTransformDirection(grabbedObjectTransform.up);
				turnGridRotation = grabbedObjectTransform.rotation;
			}
			physRotatingTimer = 0.25f;
			prevTurnGridRotation = turnGridRotation;
			float num2 = Mathf.Clamp(1f / num, 0f, 0.5f);
			if (num2 != 0f)
			{
				grabbedPhysGrabObject.OverrideAngularDrag(40f * num2);
			}
			Quaternion val = Quaternion.AngleAxis(mouseTurningVelocity.y, overrideTransform.right);
			Quaternion val2 = Quaternion.AngleAxis(0f - mouseTurningVelocity.x, overrideTransform.up);
			Quaternion val3 = Quaternion.AngleAxis(mouseTurningVelocity.z, overrideTransform.forward);
			Quaternion val4 = val2 * val * val3;
			float num3 = 1f / num;
			num3 = Mathf.Clamp(num3, 0f, 1f);
			if (num < grabbedPhysGrabObject.massOriginal && Object.op_Implicit((Object)(object)grabbedPhysGrabObject.roomVolumeCheck) && grabbedPhysGrabObject.roomVolumeCheck.currentSize.magnitude > 1f)
			{
				num3 = 0.25f;
			}
			val4 = Quaternion.SlerpUnclamped(Quaternion.identity, val4, Time.fixedDeltaTime * 20f * num3);
			Quaternion val5 = val4 * turnGridRotation;
			Quaternion rotation = grabbedObjectTransform.rotation;
			float num4 = Quaternion.Angle(rotation, val5);
			float num5 = 45f;
			if (num4 > num5)
			{
				float num6 = num5 / num4;
				val5 = Quaternion.Slerp(rotation, val5, num6);
			}
			cameraRelativeGrabbedForward = overrideTransform.InverseTransformDirection(grabbedObjectTransform.forward);
			cameraRelativeGrabbedUp = overrideTransform.InverseTransformDirection(grabbedObjectTransform.up);
			foreach (PhysGrabber item in grabbedPhysGrabObject.playerGrabbing)
			{
				Transform overrideTransform2 = item.playerAvatar.localCamera.GetOverrideTransform();
				item.cameraRelativeGrabbedForward = overrideTransform2.InverseTransformDirection(val5 * Vector3.forward);
				item.cameraRelativeGrabbedUp = overrideTransform2.InverseTransformDirection(val5 * Vector3.up);
			}
			float num7 = 1f - Mathf.Pow(71f / 72f, Time.fixedDeltaTime * 144f);
			turnGridRotation = Quaternion.Slerp(val5, grabbedObjectTransform.rotation, num7);
		}
		else
		{
			ObjectTurningRelease();
			((Component)physGrabPointVisualGrid).gameObject.SetActive(false);
		}
	}

	private void ObjectTurningRelease()
	{
		//IL_0028: Unknown result type (might be due to invalid IL or missing references)
		//IL_002d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0033: Unknown result type (might be due to invalid IL or missing references)
		//IL_0038: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a4: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a9: Unknown result type (might be due to invalid IL or missing references)
		//IL_012f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0134: Unknown result type (might be due to invalid IL or missing references)
		//IL_013b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0142: Unknown result type (might be due to invalid IL or missing references)
		//IL_0147: Unknown result type (might be due to invalid IL or missing references)
		//IL_014c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0178: Unknown result type (might be due to invalid IL or missing references)
		//IL_0165: Unknown result type (might be due to invalid IL or missing references)
		//IL_016a: Unknown result type (might be due to invalid IL or missing references)
		//IL_017d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0185: Unknown result type (might be due to invalid IL or missing references)
		//IL_018a: Unknown result type (might be due to invalid IL or missing references)
		//IL_018f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0197: Unknown result type (might be due to invalid IL or missing references)
		//IL_019c: Unknown result type (might be due to invalid IL or missing references)
		//IL_01a1: Unknown result type (might be due to invalid IL or missing references)
		//IL_01a6: Unknown result type (might be due to invalid IL or missing references)
		//IL_01ae: Unknown result type (might be due to invalid IL or missing references)
		//IL_01b3: Unknown result type (might be due to invalid IL or missing references)
		//IL_01b4: Unknown result type (might be due to invalid IL or missing references)
		//IL_01b6: Unknown result type (might be due to invalid IL or missing references)
		//IL_01bb: Unknown result type (might be due to invalid IL or missing references)
		//IL_01c0: Unknown result type (might be due to invalid IL or missing references)
		//IL_01c5: Unknown result type (might be due to invalid IL or missing references)
		//IL_01c6: Unknown result type (might be due to invalid IL or missing references)
		//IL_01d4: Unknown result type (might be due to invalid IL or missing references)
		//IL_01d6: Unknown result type (might be due to invalid IL or missing references)
		//IL_01dd: Unknown result type (might be due to invalid IL or missing references)
		//IL_01e2: Unknown result type (might be due to invalid IL or missing references)
		//IL_01e7: Unknown result type (might be due to invalid IL or missing references)
		//IL_01ec: Unknown result type (might be due to invalid IL or missing references)
		//IL_01ee: Unknown result type (might be due to invalid IL or missing references)
		//IL_01f3: Unknown result type (might be due to invalid IL or missing references)
		//IL_01f7: Unknown result type (might be due to invalid IL or missing references)
		//IL_01f9: Unknown result type (might be due to invalid IL or missing references)
		//IL_01fe: Unknown result type (might be due to invalid IL or missing references)
		//IL_0203: Unknown result type (might be due to invalid IL or missing references)
		//IL_020a: Unknown result type (might be due to invalid IL or missing references)
		//IL_020c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0211: Unknown result type (might be due to invalid IL or missing references)
		//IL_0216: Unknown result type (might be due to invalid IL or missing references)
		//IL_021d: Unknown result type (might be due to invalid IL or missing references)
		//IL_021f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0224: Unknown result type (might be due to invalid IL or missing references)
		//IL_0229: Unknown result type (might be due to invalid IL or missing references)
		//IL_0230: Unknown result type (might be due to invalid IL or missing references)
		//IL_0235: Unknown result type (might be due to invalid IL or missing references)
		//IL_024f: Unknown result type (might be due to invalid IL or missing references)
		PhysGrabObject physGrabObject = objectTurningObject;
		objectTurningObject = null;
		if (!Object.op_Implicit((Object)(object)physGrabObject) || physGrabObject.isGun || physGrabObject.isMelee)
		{
			return;
		}
		mouseTurningVelocity = Vector3.zero;
		currentTorqueForce = Vector3.zero;
		foreach (PhysGrabber item in physGrabObject.playerGrabbing)
		{
			if (Object.op_Implicit((Object)(object)item) && (Object)(object)item != (Object)(object)this && (Object)(object)item.grabbedPhysGrabObject == (Object)(object)physGrabObject && item.isRotating)
			{
				return;
			}
		}
		physGrabObject.RotationRelease();
		Quaternion rotation = physGrabObject.rb.rotation;
		foreach (PhysGrabber item2 in physGrabObject.playerGrabbing)
		{
			if (!Object.op_Implicit((Object)(object)item2) || (Object)(object)item2.grabbedPhysGrabObject != (Object)(object)physGrabObject || !Object.op_Implicit((Object)(object)item2.grabbedObjectTransform) || !Object.op_Implicit((Object)(object)item2.playerAvatar) || !Object.op_Implicit((Object)(object)item2.playerAvatar.localCamera))
			{
				continue;
			}
			Transform overrideTransform = item2.playerAvatar.localCamera.GetOverrideTransform();
			item2.mouseTurningVelocity = Vector3.zero;
			Quaternion val = item2.GamepadMeleeRotationGet() * item2.physRotation;
			Vector3 val2 = (Object.op_Implicit((Object)(object)item2.overrideGrabPointTransform) ? item2.overrideGrabPointTransform.position : item2.grabbedObjectTransform.TransformPoint(item2.localGrabPosition));
			Vector3 val3 = Quaternion.Inverse(((Component)physGrabObject).transform.rotation) * (val2 - ((Component)physGrabObject).transform.position);
			val2 = physGrabObject.rb.position + rotation * val3;
			if (physGrabObject.GrabHoldRotationTryGet(item2, rotation, val2, out var holdRotation))
			{
				Quaternion val4 = Quaternion.Inverse(val) * Quaternion.Inverse(overrideTransform.rotation) * holdRotation;
				item2.cameraRelativeGrabbedForward = val4 * Vector3.forward;
				item2.cameraRelativeGrabbedUp = val4 * Vector3.up;
				item2.cameraRelativeGrabbedRight = val4 * Vector3.right;
				item2.currentTorqueForce = Vector3.zero;
				if (Object.op_Implicit((Object)(object)item2.physGrabPointVisualGrid))
				{
					item2.physGrabPointVisualGrid.rotation = rotation;
				}
			}
		}
	}

	private void OverrideGrabPointTimer()
	{
		if (overrideGrabPointTimer > 0f)
		{
			overrideGrabPointTimer -= Time.fixedDeltaTime;
		}
		else
		{
			overrideGrabPointTransform = null;
		}
	}

	private void FixedUpdate()
	{
		OverrideGrabPointTimer();
		OverrideDisableRotationControlsTick();
		PhysGrabInTumbleStateLookAtCameraDirection();
		ClimbPhysLogic();
		if (isLocal && isRotating && !overrideDisableRotationControls)
		{
			SemiFunc.CameraOverrideStopAim();
		}
		ObjectTurning();
		if (physRotatingTimer > 0f)
		{
			physRotatingTimer -= Time.fixedDeltaTime;
		}
		if (stopRotationTimer > 0f)
		{
			stopRotationTimer -= Time.fixedDeltaTime;
		}
		ColorStateTick();
	}

	private void PushingPullingChecker()
	{
		if (!isLocal)
		{
			return;
		}
		if (overrideGrabDistanceTimer > 0f)
		{
			pullerDistance = overrideGrabDistance;
			prevPullerDistance = pullerDistance;
		}
		if (overrideMinimumGrabDistanceTimer > 0f && minDistanceFromPlayer < overrideMinimumGrabDistance)
		{
			minDistanceFromPlayer = overrideMinimumGrabDistance;
		}
		bool flag = grabState == GrabState.Climb && (PlayerController.instance.InputDisableTimer > 0f || GameDirector.instance.DisableInput || physGrabForcesDisabledTimer > 0f || SemiFunc.InputHold(InputKey.Rotate));
		if (!grabbed | flag)
		{
			isPushing = false;
			isPulling = false;
			isPushingTimer = 0f;
			isPullingTimer = 0f;
			prevPullerDistance = pullerDistance;
			return;
		}
		if (initialPressTimer > 0f)
		{
			prevPullerDistance = pullerDistance;
			isPushingTimer = 0f;
		}
		float num = InputManager.instance.KeyPullAndPush();
		if (num > 0f)
		{
			isPushingTimer = 0.1f;
			if (grabState == GrabState.Climb)
			{
				isPullingTimer = 0f;
			}
		}
		if (num < 0f)
		{
			isPullingTimer = 0.1f;
			if (grabState == GrabState.Climb)
			{
				isPushingTimer = 0f;
			}
		}
		if (isPushingTimer > 0f)
		{
			TutorialDirector.instance.playerPushedAndPulled = true;
			isPushing = true;
			isPushingTimer -= Time.deltaTime;
		}
		else
		{
			isPushing = false;
		}
		if (isPullingTimer > 0f)
		{
			TutorialDirector.instance.playerPushedAndPulled = true;
			isPulling = true;
			isPullingTimer -= Time.deltaTime;
		}
		else
		{
			isPulling = false;
		}
		if (overrideGrabDistanceTimer > 0f)
		{
			pullerDistance = overrideGrabDistance;
		}
	}

	public void OverridePullDistanceIncrement(float distSpeed)
	{
		pullerDistance += distSpeed;
	}

	private void OverchargeResetValues()
	{
		physGrabBeamOverCharge = 0;
		physGrabBeamOverChargeFloat = 0f;
		physGrabBeamOverChargeAmount = 0f;
		physGrabBeamOverChargeTimer = 0f;
	}

	private void OnDisable()
	{
		ClimbSwingReset();
		gamepadGrabCursor.Reset();
		GamepadMeleeRotationReset();
		mountedVehicle = null;
		mountedMounting = null;
		vehicleGrabReleaseTimer = 0f;
		OverchargeResetValues();
		overrideMinimumGrabTimer = 0f;
		overrideMinimumGrabDuration = 0f;
		overrideMinimumGrabTarget = null;
	}

	private void OnEnable()
	{
		gamepadGrabCursor.Reset();
		GamepadMeleeRotationReset();
		OverchargeResetValues();
	}

	private bool UpdateMountedVehicleGrab()
	{
		if (!isLocal)
		{
			return false;
		}
		ItemVehicle itemVehicle = ((grabbed && Object.op_Implicit((Object)(object)grabbedPhysGrabObject)) ? ItemVehicle.GetVehicleForPlayer(playerAvatar) : null);
		if (Object.op_Implicit((Object)(object)itemVehicle) && (Object)(object)itemVehicle.physGrabObject != (Object)(object)grabbedPhysGrabObject)
		{
			itemVehicle = null;
		}
		SemiMounting semiMounting = ((grabbed && Object.op_Implicit((Object)(object)grabbedPhysGrabObject)) ? ((Component)grabbedPhysGrabObject).GetComponent<SemiMounting>() : null);
		if (Object.op_Implicit((Object)(object)semiMounting) && !semiMounting.VehicleGrabActive(playerAvatar))
		{
			semiMounting = null;
		}
		InputModes currentMode = InputManager.instance.CurrentMode;
		if ((Object)(object)mountedMounting == (Object)(object)semiMounting && (Object)(object)mountedVehicle == (Object)(object)itemVehicle && ((!Object.op_Implicit((Object)(object)itemVehicle) && !Object.op_Implicit((Object)(object)semiMounting)) || mountedVehicleInputMode == currentMode))
		{
			return false;
		}
		mountedVehicle = itemVehicle;
		mountedMounting = semiMounting;
		mountedVehicleInputMode = currentMode;
		InputKey key = (MountedVehicleGrab ? InputKey.VehicleGrab : InputKey.Grab);
		toggleGrab = grabbed && InputManager.instance.InputToggleGet(key);
		toggleGrabTimer = (toggleGrab ? 0.1f : 0f);
		return MountedVehicleGrab;
	}

	internal bool GrabInputActiveGet(bool grabHeld, bool grabPressed, bool vehicleGrabStarted)
	{
		bool result = grabHeld || toggleGrab;
		bool flag = grabbed && MountedVehicleGrab;
		bool flag2 = VehicleMountingLocksInput();
		bool flag3 = InputManager.instance.InputToggleGet(flag ? InputKey.VehicleGrab : InputKey.Grab);
		if (flag3)
		{
			if ((!vehicleGrabStarted && !flag2 && PlayerController.instance.InputDisableTimer <= 0f) & grabPressed)
			{
				toggleGrab = !toggleGrab;
				if (toggleGrab)
				{
					toggleGrabTimer = 0.1f;
				}
			}
		}
		else if (toggleGrab && ((flag | grabHeld) || !GameplayManager.instance.itemUnequipAutoHold))
		{
			toggleGrab = false;
		}
		if (flag2)
		{
			return true;
		}
		if (flag)
		{
			if (!flag3)
			{
				return grabHeld;
			}
			return toggleGrab;
		}
		return result;
	}

	internal bool VehicleMountingLocksInput()
	{
		if (!grabbed || !Object.op_Implicit((Object)(object)grabbedPhysGrabObject) || !Object.op_Implicit((Object)(object)playerAvatar) || playerAvatar.isDisabled)
		{
			return false;
		}
		if (Object.op_Implicit((Object)(object)mountedVehicle))
		{
			return mountedVehicle.MountingInProgress(playerAvatar);
		}
		if (Object.op_Implicit((Object)(object)mountedMounting))
		{
			return mountedMounting.MountingLocksInput(playerAvatar);
		}
		return false;
	}

	private void Update()
	{
		//IL_02e3: Unknown result type (might be due to invalid IL or missing references)
		//IL_02f8: Unknown result type (might be due to invalid IL or missing references)
		//IL_0158: Unknown result type (might be due to invalid IL or missing references)
		//IL_013b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0140: Unknown result type (might be due to invalid IL or missing references)
		//IL_0376: Unknown result type (might be due to invalid IL or missing references)
		//IL_028a: Unknown result type (might be due to invalid IL or missing references)
		//IL_02c3: Unknown result type (might be due to invalid IL or missing references)
		//IL_02c8: Unknown result type (might be due to invalid IL or missing references)
		//IL_02ab: Unknown result type (might be due to invalid IL or missing references)
		//IL_02b0: Unknown result type (might be due to invalid IL or missing references)
		bool vehicleGrabStarted = UpdateMountedVehicleGrab();
		isPushingAndChangedRange = false;
		isPullingAndChangedRange = false;
		StateMachine();
		OverrideGrabTick();
		OverrideMinimumGrabTimeTick();
		OverrideOverchargeDisableTick();
		OverrideBeamColorTick();
		OverrideAimTransformTick();
		OverrideSpecialPowersLogic();
		OverrideDiscoverSkipListLogic();
		PushingPullingChecker();
		ColorStates();
		ObjectTurningInputUpdate();
		ObjectTurningGridUpdate();
		PhysGrabOverChargeLogic();
		if (Object.op_Implicit((Object)(object)grabbedObjectTransform) && ((Object)grabbedObjectTransform).name == ((Object)playerAvatar.healthGrab).name)
		{
			OverrideColorToGreen();
		}
		OverrideGrabDistanceTick();
		OverrideGrabStrengthTick();
		TickerBeamAlphaChange();
		if (initialPressTimer > 0f)
		{
			initialPressTimer -= Time.deltaTime;
		}
		if (physGrabForcesDisabledTimer > 0f)
		{
			physGrabForcesDisabledTimer -= Time.deltaTime;
		}
		if (physPushPullTimer > 0f)
		{
			physPushPullTimer -= Time.deltaTime;
		}
		if (grabbed && Object.op_Implicit((Object)(object)grabbedObjectTransform))
		{
			if (!Object.op_Implicit((Object)(object)overrideGrabPointTransform))
			{
				physGrabPoint.position = grabbedObjectTransform.TransformPoint(localGrabPosition);
			}
			else
			{
				physGrabPoint.position = overrideGrabPointTransform.position;
			}
		}
		if (isLocal)
		{
			if (PlayerController.instance.InputDisableTimer <= 0f && !SemiFunc.InputHold(InputKey.Rotate))
			{
				float num = InputManager.instance.KeyPullAndPush();
				if (InputManager.instance.KeyPullAndPushAnalog(out var axis))
				{
					pullerDistance += axis * Mathf.Abs(axis) * gamepadPushPullSpeed * Time.deltaTime;
				}
				else if (num > 0f)
				{
					pullerDistance += 0.2f;
				}
				else if (num < 0f)
				{
					pullerDistance -= 0.2f;
				}
			}
			if (overrideGrabDistanceTimer > 0f)
			{
				if (overrideGrabDistance > 0f)
				{
					pullerDistance = overrideGrabDistance;
				}
			}
			else
			{
				pullerDistance = Mathf.Clamp(pullerDistance, minDistanceFromPlayer, Mathf.Min(grabRange, maxDistanceFromPlayer));
			}
			Transform overrideTransform = playerAvatar.localCamera.GetOverrideTransform();
			Transform aimTransform = ((!(overrideAimTransformTimer > 0f)) ? overrideTransform : overrideAimTransform);
			physGrabPointPlane.position = GamepadGrabTargetGet(overrideTransform, aimTransform);
			if (grabbed && (grabState == GrabState.Climb || gamepadGrabCursor.offset != Vector2.zero))
			{
				physGrabPointPullerPosition = physGrabPointPuller.position;
			}
		}
		else if (overrideGrabDistanceTimer <= 0f)
		{
			pullerDistance = Vector3.Distance(physGrabPointPuller.position, playerAvatar.localCamera.GetOverrideTransform().position);
		}
		if (isPushing && pullerDistance > prevPullerDistanceRange)
		{
			isPushingAndChangedRange = true;
		}
		if (isPulling && pullerDistance < prevPullerDistanceRange)
		{
			isPullingAndChangedRange = true;
		}
		prevPullerDistanceRange = pullerDistance;
		GamepadMeleeRotationUpdate();
		if (Object.op_Implicit((Object)(object)physGrabBeamComponent.PhysGrabPointOrigin))
		{
			grabberAudioTransform.position = physGrabBeamComponent.PhysGrabPointOrigin.position;
		}
		loopSound.PlayLoop(physGrabBeamActive, 10f, 10f);
		ShowValue();
		if (!isLocal)
		{
			return;
		}
		bool flag = SemiFunc.InputHold(InputKey.Grab);
		if (vehicleGrabReleaseTimer > 0f)
		{
			vehicleGrabReleaseTimer = (flag ? 0.1f : Mathf.Max(0f, vehicleGrabReleaseTimer - Time.deltaTime));
		}
		bool flag2 = GrabInputActiveGet(flag, SemiFunc.InputDown(InputKey.Grab), vehicleGrabStarted);
		if (!MountedVehicleGrab && debugStickyGrabber && !SemiFunc.InputHold(InputKey.Rotate))
		{
			flag2 = true;
		}
		if (toggleGrabTimer > 0f)
		{
			toggleGrabTimer -= Time.deltaTime;
		}
		else if (!grabbed && toggleGrab)
		{
			toggleGrab = false;
		}
		if (overrideGrabTimer > 0f && Object.op_Implicit((Object)(object)overrideGrabTarget) && (flag || toggleGrab))
		{
			overrideGrabTarget = null;
		}
		if (overrideGrabTimer > 0f)
		{
			flag2 = true;
		}
		else if (PlayerController.instance.InputDisableTimer > 0f && !toggleGrab)
		{
			flag2 = false;
		}
		if (VehicleMountingLocksInput())
		{
			flag2 = true;
		}
		if (vehicleGrabReleaseTimer > 0f)
		{
			flag2 = false;
		}
		if (grabState == GrabState.Climb && !playerAvatar.isTumbling)
		{
			flag2 = false;
		}
		bool flag3 = false;
		if (flag2 && !grabbed)
		{
			if (grabDisableTimer <= 0f)
			{
				flag3 = true;
			}
		}
		else if (!flag2 && grabbed && !OverrideMinimumGrabTimeActive())
		{
			ReleaseObject(-1);
		}
		if (LevelGenerator.Instance.Generated && PlayerController.instance.InputDisableTimer <= 0f)
		{
			if ((grabCheckTimer <= 0f) | flag3)
			{
				grabCheckTimer = 0.02f;
				RayCheck(flag3);
			}
			else
			{
				grabCheckTimer -= Time.deltaTime;
			}
		}
		PhysGrabLogic();
		if (grabDisableTimer > 0f)
		{
			grabDisableTimer -= Time.deltaTime;
		}
	}

	private void PhysGrabLogic()
	{
		//IL_00ba: Unknown result type (might be due to invalid IL or missing references)
		//IL_00cf: Unknown result type (might be due to invalid IL or missing references)
		//IL_01ae: Unknown result type (might be due to invalid IL or missing references)
		//IL_01b3: Unknown result type (might be due to invalid IL or missing references)
		if (overrideAlwaysGrabbableTimer > 0f)
		{
			overrideAlwaysGrabbableTimer -= Time.deltaTime;
		}
		grabReleaseDistance = Mathf.Max(grabRange * 2f, 10f);
		if (!grabbed)
		{
			return;
		}
		if (grabState != GrabState.Climb)
		{
			if (physRotatingTimer > 0f)
			{
				Aim.instance.SetState(Aim.State.Rotate);
			}
			else if (physPushPullTimer > 0f)
			{
				Aim.instance.SetState(Aim.State.PushPull);
			}
			else if (overrideAlwaysGrabbableTimer > 0f || Object.op_Implicit((Object)(object)ArenaRace.instance))
			{
				Aim.instance.SetState(Aim.State.Grabbable);
			}
			else
			{
				Aim.instance.SetState(Aim.State.Grab);
			}
		}
		if (Vector3.Distance(physGrabPoint.position, playerAvatar.PlayerVisionTarget.VisionTransform.position) > grabReleaseDistance && overrideAlwaysGrabbableTimer <= 0f && !Object.op_Implicit((Object)(object)ArenaRace.instance) && !OverrideMinimumGrabTimeActive())
		{
			ReleaseObject(-1);
			return;
		}
		if (Object.op_Implicit((Object)(object)grabbedPhysGrabObject))
		{
			if (!((Behaviour)grabbedPhysGrabObject).enabled || grabbedPhysGrabObject.dead || !Object.op_Implicit((Object)(object)grabbedPhysGrabObjectCollider) || !grabbedPhysGrabObjectCollider.enabled)
			{
				ReleaseObject(-1);
				return;
			}
		}
		else if (Object.op_Implicit((Object)(object)grabbedStaticGrabObject))
		{
			if (!((Behaviour)grabbedStaticGrabObject).isActiveAndEnabled || grabbedStaticGrabObject.dead)
			{
				ReleaseObject(-1);
				return;
			}
		}
		else if (grabState != GrabState.Climb)
		{
			ReleaseObject(-1);
			return;
		}
		physGrabPointPullerPosition = physGrabPointPuller.position;
		PhysGrabStarted();
		PhysGrabBeamActivate();
	}

	private void PhysGrabBeamActivate()
	{
		//IL_0050: Unknown result type (might be due to invalid IL or missing references)
		//IL_0055: Unknown result type (might be due to invalid IL or missing references)
		if (GameManager.instance.gameMode == 0)
		{
			if (!physGrabBeamActive)
			{
				if (!isLocal || !DebugCommandHandler.instance.hideGrabber)
				{
					((Renderer)physGrabBeamScript.lineRenderer).enabled = true;
				}
				physGrabForcesDisabledTimer = 0f;
				physGrabBeamComponent.physGrabPointPullerSmoothPosition = physGrabPoint.position;
				physGrabBeamActive = true;
				PhysGrabStartEffects();
			}
		}
		else if (!physGrabBeamActive)
		{
			photonView.RPC("PhysGrabBeamActivateRPC", (RpcTarget)0, Array.Empty<object>());
			physGrabBeamActive = true;
		}
	}

	public void ShowValue()
	{
		//IL_008f: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c8: Unknown result type (might be due to invalid IL or missing references)
		if ((!isLocal && (!Object.op_Implicit((Object)(object)SpectateCamera.instance) || !SpectateCamera.instance.CheckState(SpectateCamera.State.Normal) || !((Object)(object)SpectateCamera.instance.player == (Object)(object)playerAvatar) || !((Component)physGrabPoint).gameObject.activeSelf)) || !grabbed || !Object.op_Implicit((Object)(object)grabbedPhysGrabObject))
		{
			return;
		}
		ValuableObject component = ((Component)grabbedPhysGrabObject).GetComponent<ValuableObject>();
		if (Object.op_Implicit((Object)(object)component))
		{
			WorldSpaceUIValue.instance.Show(grabbedPhysGrabObject, (int)component.dollarValueCurrent, _cost: false, Vector3.zero);
		}
		else if (SemiFunc.RunIsShop())
		{
			ItemAttributes component2 = ((Component)grabbedPhysGrabObject).GetComponent<ItemAttributes>();
			if (Object.op_Implicit((Object)(object)component2))
			{
				WorldSpaceUIValue.instance.Show(grabbedPhysGrabObject, component2.value, _cost: true, component2.costOffset);
			}
		}
	}

	private void PhysGrabStartEffects()
	{
		//IL_0016: Unknown result type (might be due to invalid IL or missing references)
		startSound.Play(((Component)loopSound.Source).transform.position);
		if (!GameManager.Multiplayer() || photonView.IsMine)
		{
			GameDirector.instance.CameraImpact.Shake(0.5f, 0.1f);
		}
	}

	private void PhysGrabEndEffects()
	{
		//IL_0016: Unknown result type (might be due to invalid IL or missing references)
		stopSound.Play(((Component)loopSound.Source).transform.position);
		if (!GameManager.Multiplayer() || photonView.IsMine)
		{
			GameDirector.instance.CameraImpact.Shake(0.5f, 0.1f);
		}
	}

	[PunRPC]
	private void PhysGrabBeamActivateRPC(PhotonMessageInfo _info = default(PhotonMessageInfo))
	{
		//IL_0000: Unknown result type (might be due to invalid IL or missing references)
		//IL_005c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0061: Unknown result type (might be due to invalid IL or missing references)
		if (SemiFunc.OwnerOnlyRPC(_info, photonView))
		{
			PhysGrabStartEffects();
			initialPressTimer = 0.1f;
			physGrabForcesDisabledTimer = 0f;
			if (!isLocal || !DebugCommandHandler.instance.hideGrabber)
			{
				((Renderer)physGrabBeamScript.lineRenderer).enabled = true;
			}
			physGrabBeamComponent.physGrabPointPullerSmoothPosition = physGrabPoint.position;
			physGrabBeamActive = true;
			((Component)physGrabPointVisualRotate).GetComponent<PhysGrabPointRotate>().animationEval = 0f;
			PhysGrabPointActivate();
		}
	}

	private void PhysGrabPointDeactivate()
	{
		//IL_0017: Unknown result type (might be due to invalid IL or missing references)
		physGrabPointVisualGrid.parent = physGrabPoint;
		physGrabPointVisualRotate.localScale = Vector3.zero;
		((Component)physGrabPointVisualRotate).GetComponent<PhysGrabPointRotate>().animationEval = 0f;
		GridObjectsRemove();
		((Component)physGrabPoint).gameObject.SetActive(false);
	}

	private void PhysGrabPointActivate()
	{
		//IL_0006: Unknown result type (might be due to invalid IL or missing references)
		//IL_0040: Unknown result type (might be due to invalid IL or missing references)
		//IL_0066: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f9: Unknown result type (might be due to invalid IL or missing references)
		//IL_00dd: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e7: Unknown result type (might be due to invalid IL or missing references)
		//IL_00be: Unknown result type (might be due to invalid IL or missing references)
		physGrabPointVisualRotate.localScale = Vector3.zero;
		PhysGrabPointRotate component = ((Component)physGrabPointVisualRotate).GetComponent<PhysGrabPointRotate>();
		if (Object.op_Implicit((Object)(object)component))
		{
			component.animationEval = 0f;
			component.rotationActiveTimer = 0f;
		}
		physGrabPointVisualGrid.localPosition = Vector3.zero;
		physGrabPointVisualGrid.parent = ((Component)this).transform.parent;
		physGrabPointVisualGrid.localScale = Vector3.one;
		if (Object.op_Implicit((Object)(object)grabbedObjectTransform))
		{
			grabbedPhysGrabObject = ((Component)grabbedObjectTransform).GetComponent<PhysGrabObject>();
			if (Object.op_Implicit((Object)(object)grabbedPhysGrabObject) && Object.op_Implicit((Object)(object)grabbedPhysGrabObject.rb))
			{
				physGrabPointVisualGrid.localRotation = grabbedPhysGrabObject.rb.rotation;
				GridObjectsInstantiate();
			}
		}
		if (grabState == GrabState.Climb)
		{
			physGrabPoint.localScale = Vector3.one * 2f;
		}
		else
		{
			physGrabPoint.localScale = Vector3.one;
		}
		((Component)physGrabPointVisualGrid).gameObject.SetActive(false);
		((Component)physGrabPoint).gameObject.SetActive(true);
		physGrabPointVisual1.SetActive(!isLocal || !DebugCommandHandler.instance.hideGrabber);
	}

	public void OverridePhysGrabForcesDisable(float _time)
	{
		physGrabForcesDisabledTimer = _time;
	}

	[PunRPC]
	private void PhysGrabBeamDeactivateRPC(PhotonMessageInfo _info = default(PhotonMessageInfo))
	{
		//IL_0000: Unknown result type (might be due to invalid IL or missing references)
		//IL_004b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0050: Unknown result type (might be due to invalid IL or missing references)
		if (SemiFunc.MasterAndOwnerOnlyRPC(_info, photonView))
		{
			physGrabForcesDisabledTimer = 0f;
			ResetBeam();
			((Renderer)physGrabBeamScript.lineRenderer).enabled = false;
			PhysGrabPointDeactivate();
			physGrabBeamActive = false;
			PhysGrabEndEffects();
			GamepadMeleeRotationReset();
			physRotation = Quaternion.identity;
		}
	}

	private void PhysGrabBeamDeactivate()
	{
		//IL_000a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0010: Unknown result type (might be due to invalid IL or missing references)
		if (!SemiFunc.IsMultiplayer())
		{
			PhysGrabBeamDeactivateRPC();
		}
		else
		{
			photonView.RPC("PhysGrabBeamDeactivateRPC", (RpcTarget)0, Array.Empty<object>());
		}
	}

	public void OnPhotonSerializeView(PhotonStream stream, PhotonMessageInfo info)
	{
		//IL_0000: Unknown result type (might be due to invalid IL or missing references)
		//IL_0001: Unknown result type (might be due to invalid IL or missing references)
		//IL_015d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0162: Unknown result type (might be due to invalid IL or missing references)
		//IL_016e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0184: Unknown result type (might be due to invalid IL or missing references)
		//IL_01a4: Unknown result type (might be due to invalid IL or missing references)
		//IL_019d: Unknown result type (might be due to invalid IL or missing references)
		//IL_01a9: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d0: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e6: Unknown result type (might be due to invalid IL or missing references)
		//IL_00fc: Unknown result type (might be due to invalid IL or missing references)
		//IL_0109: Unknown result type (might be due to invalid IL or missing references)
		if (!SemiFunc.MasterAndOwnerOnlyRPC(info, info.photonView))
		{
			return;
		}
		if (stream.IsWriting)
		{
			ushort num = (ushort)((colorState & 3) | (physGrabBeamOverCharge << 5));
			if (isRotating)
			{
				num |= 4;
			}
			if (isPushing)
			{
				num |= 8;
			}
			if (isPulling)
			{
				num |= 0x10;
			}
			byte b = (byte)Mathf.RoundToInt(Mathf.Clamp(gamepadMeleePitch, -60f, 60f) * 2f + 120f);
			bool flag = b != 120;
			if (flag)
			{
				num |= 0x2000;
			}
			byte b2 = (byte)Mathf.RoundToInt(Mathf.Clamp(gamepadMeleeYaw, -60f, 60f) * 2f + 120f);
			bool flag2 = b2 != 120;
			if (flag2)
			{
				num |= 0x4000;
			}
			stream.SendNext((object)physGrabPointPullerPosition);
			stream.SendNext((object)physGrabPointPlane.position);
			stream.SendNext(mouseTurningVelocity.Equals(Vector3.zero) ? null : ((object)mouseTurningVelocity));
			stream.SendNext((object)(short)num);
			if (flag)
			{
				stream.SendNext((object)b);
			}
			if (flag2)
			{
				stream.SendNext((object)b2);
			}
		}
		else
		{
			grabInputTimestamp = info.SentServerTimestamp;
			physGrabPointPullerPosition = (Vector3)stream.ReceiveNext();
			physGrabPointPuller.position = physGrabPointPullerPosition;
			physGrabPointPlane.position = (Vector3)stream.ReceiveNext();
			object obj = stream.ReceiveNext();
			mouseTurningVelocity = (Vector3)((obj == null) ? Vector3.zero : ((Vector3)obj));
			remoteRotationSampleTimer = 0.1f;
			ushort num2 = (ushort)(short)stream.ReceiveNext();
			colorState = num2 & 3;
			isRotating = (num2 & 4) != 0;
			isPushing = (num2 & 8) != 0;
			isPulling = (num2 & 0x10) != 0;
			physGrabBeamOverCharge = (byte)((num2 >> 5) & 0xFF);
			float num3 = ((float)(((num2 & 0x2000) != 0) ? ((byte)stream.ReceiveNext()) : 120) - 120f) * 0.5f;
			gamepadMeleePitchTarget = Mathf.Clamp(num3, -60f, 60f);
			float num4 = ((float)(((num2 & 0x4000) != 0) ? ((byte)stream.ReceiveNext()) : 120) - 120f) * 0.5f;
			gamepadMeleeYawTarget = Mathf.Clamp(num4, -60f, 60f);
		}
	}

	private void PhysGrabStarted()
	{
		if (Object.op_Implicit((Object)(object)grabbedPhysGrabObject))
		{
			grabbedPhysGrabObject.GrabStarted(this);
		}
		else if (Object.op_Implicit((Object)(object)grabbedStaticGrabObject))
		{
			grabbedStaticGrabObject.GrabStarted(this);
		}
		else if (grabState != GrabState.Climb)
		{
			ReleaseObject(-1);
		}
	}

	private void PhysGrabEnded()
	{
		if (Object.op_Implicit((Object)(object)grabbedPhysGrabObject))
		{
			grabbedPhysGrabObject.GrabEnded(this);
		}
		else if (Object.op_Implicit((Object)(object)grabbedStaticGrabObject))
		{
			grabbedStaticGrabObject.GrabEnded(this);
		}
		else if (grabState == GrabState.Climb && SemiFunc.IsMultiplayer())
		{
			photonView.RPC("GrabClimbEndedRPC", (RpcTarget)2, Array.Empty<object>());
		}
	}

	private void StartGrabbingPhysObject(RaycastHit hit, PhysGrabObject _physGrabObject)
	{
		//IL_0184: Unknown result type (might be due to invalid IL or missing references)
		//IL_0189: Unknown result type (might be due to invalid IL or missing references)
		//IL_01fa: Unknown result type (might be due to invalid IL or missing references)
		//IL_01ff: Unknown result type (might be due to invalid IL or missing references)
		//IL_020e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0214: Unknown result type (might be due to invalid IL or missing references)
		//IL_021a: Unknown result type (might be due to invalid IL or missing references)
		//IL_021f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0224: Unknown result type (might be due to invalid IL or missing references)
		//IL_022b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0237: Unknown result type (might be due to invalid IL or missing references)
		//IL_0252: Unknown result type (might be due to invalid IL or missing references)
		//IL_0257: Unknown result type (might be due to invalid IL or missing references)
		//IL_025c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0269: Unknown result type (might be due to invalid IL or missing references)
		//IL_026e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0273: Unknown result type (might be due to invalid IL or missing references)
		//IL_0280: Unknown result type (might be due to invalid IL or missing references)
		//IL_0285: Unknown result type (might be due to invalid IL or missing references)
		//IL_028a: Unknown result type (might be due to invalid IL or missing references)
		//IL_02a4: Unknown result type (might be due to invalid IL or missing references)
		//IL_02e7: Unknown result type (might be due to invalid IL or missing references)
		//IL_02e8: Unknown result type (might be due to invalid IL or missing references)
		//IL_02ed: Unknown result type (might be due to invalid IL or missing references)
		//IL_01d9: Unknown result type (might be due to invalid IL or missing references)
		//IL_01de: Unknown result type (might be due to invalid IL or missing references)
		//IL_01e2: Unknown result type (might be due to invalid IL or missing references)
		//IL_01e7: Unknown result type (might be due to invalid IL or missing references)
		//IL_04fb: Unknown result type (might be due to invalid IL or missing references)
		//IL_04bb: Unknown result type (might be due to invalid IL or missing references)
		//IL_04bd: Unknown result type (might be due to invalid IL or missing references)
		//IL_04c3: Unknown result type (might be due to invalid IL or missing references)
		//IL_03c7: Unknown result type (might be due to invalid IL or missing references)
		//IL_03cc: Unknown result type (might be due to invalid IL or missing references)
		//IL_03dc: Unknown result type (might be due to invalid IL or missing references)
		//IL_03e1: Unknown result type (might be due to invalid IL or missing references)
		//IL_03e4: Unknown result type (might be due to invalid IL or missing references)
		//IL_03e6: Unknown result type (might be due to invalid IL or missing references)
		//IL_03eb: Unknown result type (might be due to invalid IL or missing references)
		//IL_03f0: Unknown result type (might be due to invalid IL or missing references)
		//IL_03f6: Unknown result type (might be due to invalid IL or missing references)
		//IL_03f8: Unknown result type (might be due to invalid IL or missing references)
		//IL_03fd: Unknown result type (might be due to invalid IL or missing references)
		//IL_0402: Unknown result type (might be due to invalid IL or missing references)
		//IL_0408: Unknown result type (might be due to invalid IL or missing references)
		//IL_040a: Unknown result type (might be due to invalid IL or missing references)
		//IL_040f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0414: Unknown result type (might be due to invalid IL or missing references)
		//IL_0427: Unknown result type (might be due to invalid IL or missing references)
		//IL_042d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0433: Unknown result type (might be due to invalid IL or missing references)
		//IL_0438: Unknown result type (might be due to invalid IL or missing references)
		//IL_043e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0448: Unknown result type (might be due to invalid IL or missing references)
		//IL_044d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0452: Unknown result type (might be due to invalid IL or missing references)
		//IL_0302: Unknown result type (might be due to invalid IL or missing references)
		//IL_0307: Unknown result type (might be due to invalid IL or missing references)
		//IL_0316: Unknown result type (might be due to invalid IL or missing references)
		//IL_031c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0322: Unknown result type (might be due to invalid IL or missing references)
		//IL_0327: Unknown result type (might be due to invalid IL or missing references)
		//IL_032d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0337: Unknown result type (might be due to invalid IL or missing references)
		//IL_033c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0341: Unknown result type (might be due to invalid IL or missing references)
		//IL_0348: Unknown result type (might be due to invalid IL or missing references)
		//IL_0354: Unknown result type (might be due to invalid IL or missing references)
		//IL_0360: Unknown result type (might be due to invalid IL or missing references)
		//IL_036d: Unknown result type (might be due to invalid IL or missing references)
		//IL_036e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0373: Unknown result type (might be due to invalid IL or missing references)
		//IL_047a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0466: Unknown result type (might be due to invalid IL or missing references)
		//IL_048a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0496: Unknown result type (might be due to invalid IL or missing references)
		gamepadGrabCursor.Reset();
		GamepadMeleeRotationReset();
		grabbedPhysGrabObject = _physGrabObject;
		if (Object.op_Implicit((Object)(object)grabbedPhysGrabObject) && grabbedPhysGrabObject.rb.IsSleeping())
		{
			grabbedPhysGrabObject.OverrideIndestructible(0.5f);
			grabbedPhysGrabObject.OverrideBreakEffects(0.5f);
		}
		grabbedObjectTransform = hit.transform;
		if (Object.op_Implicit((Object)(object)grabbedPhysGrabObject))
		{
			PhysGrabObjectCollider component = ((Component)hit.collider).GetComponent<PhysGrabObjectCollider>();
			grabbedPhysGrabObjectCollider = hit.collider;
			grabbedPhysGrabObjectColliderID = component.colliderID;
			if (Object.op_Implicit((Object)(object)grabbedStaticGrabObject))
			{
				grabbedStaticGrabObject.GrabEnded(this);
				grabbedStaticGrabObject = null;
			}
		}
		else
		{
			grabbedPhysGrabObject = null;
			grabbedPhysGrabObjectCollider = null;
			grabbedPhysGrabObjectColliderID = 0;
			grabbedStaticGrabObject = ((Component)grabbedObjectTransform).GetComponent<StaticGrabObject>();
			if (!Object.op_Implicit((Object)(object)grabbedStaticGrabObject))
			{
				StaticGrabObject[] componentsInParent = ((Component)grabbedObjectTransform).GetComponentsInParent<StaticGrabObject>();
				foreach (StaticGrabObject staticGrabObject in componentsInParent)
				{
					if ((Object)(object)staticGrabObject.colliderTransform == (Object)(object)((Component)hit.collider).transform)
					{
						grabbedStaticGrabObject = staticGrabObject;
					}
				}
			}
			if (!Object.op_Implicit((Object)(object)grabbedStaticGrabObject) || !((Behaviour)grabbedStaticGrabObject).enabled)
			{
				return;
			}
		}
		GrabRevisionNext();
		PhysGrabPointActivate();
		((Component)physGrabPointPuller).gameObject.SetActive(true);
		grabbedObject = hit.rigidbody;
		Vector3 val = hit.point;
		if (Object.op_Implicit((Object)(object)grabbedPhysGrabObject) && Object.op_Implicit((Object)(object)grabbedPhysGrabObject.roomVolumeCheck) && !grabbedPhysGrabObject.ignoreGrabPointCentering && grabbedPhysGrabObject.roomVolumeCheck.currentSize.magnitude < 0.5f)
		{
			Bounds bounds = hit.collider.bounds;
			val = bounds.center;
		}
		Transform overrideTransform = playerAvatar.localCamera.GetOverrideTransform();
		float num = (pullerDistance = Vector3.Distance(overrideTransform.position, val));
		Vector3 position = overrideTransform.position + overrideTransform.forward * num;
		physGrabPointPlane.position = position;
		physGrabPointPuller.position = position;
		if (physRotatingTimer <= 0f)
		{
			cameraRelativeGrabbedForward = overrideTransform.InverseTransformDirection(grabbedObjectTransform.forward);
			cameraRelativeGrabbedUp = overrideTransform.InverseTransformDirection(grabbedObjectTransform.up);
			cameraRelativeGrabbedRight = overrideTransform.InverseTransformDirection(grabbedObjectTransform.right);
		}
		if (GameManager.instance.gameMode == 0)
		{
			physGrabPoint.position = val;
			if (!Object.op_Implicit((Object)(object)grabbedPhysGrabObject) || !Object.op_Implicit((Object)(object)grabbedPhysGrabObject.forceGrabPoint) || !((Component)grabbedPhysGrabObject.forceGrabPoint).gameObject.activeSelf)
			{
				localGrabPosition = grabbedObjectTransform.InverseTransformPoint(val);
			}
			else
			{
				val = grabbedPhysGrabObject.forceGrabPoint.position;
				num = (pullerDistance = 1f);
				position = overrideTransform.position + overrideTransform.forward * num - overrideTransform.up * 0.3f;
				physGrabPoint.position = val;
				physGrabPointPlane.position = position;
				physGrabPointPuller.position = position;
				localGrabPosition = grabbedObjectTransform.InverseTransformPoint(val);
			}
		}
		else if (Object.op_Implicit((Object)(object)grabbedPhysGrabObject))
		{
			if (Object.op_Implicit((Object)(object)grabbedPhysGrabObject.forceGrabPoint) && ((Component)grabbedPhysGrabObject.forceGrabPoint).gameObject.activeSelf)
			{
				val = grabbedPhysGrabObject.forceGrabPoint.position;
				Quaternion val2 = Quaternion.Euler(45f, 0f, 0f);
				cameraRelativeGrabbedForward = val2 * Vector3.forward;
				cameraRelativeGrabbedUp = val2 * Vector3.up;
				cameraRelativeGrabbedRight = val2 * Vector3.right;
				num = (pullerDistance = 1f);
				position = overrideTransform.position + overrideTransform.forward * num - overrideTransform.up * 0.3f;
				if (!Object.op_Implicit((Object)(object)overrideGrabPointTransform))
				{
					physGrabPoint.position = val;
				}
				else
				{
					physGrabPoint.position = overrideGrabPointTransform.position;
				}
				physGrabPointPlane.position = position;
				physGrabPointPuller.position = position;
			}
			if (isLocal)
			{
				grabbedPhysGrabObject.GrabLink(photonView.ViewID, grabbedPhysGrabObjectColliderID, val, cameraRelativeGrabbedForward, cameraRelativeGrabbedUp, grabRevision);
			}
		}
		else if (Object.op_Implicit((Object)(object)grabbedStaticGrabObject) && isLocal)
		{
			grabbedStaticGrabObject.GrabLink(photonView.ViewID, val, grabRevision);
		}
		if (isLocal)
		{
			PlayerController.instance.physGrabObject = ((Component)grabbedObjectTransform).gameObject;
			PlayerController.instance.physGrabActive = true;
		}
		initialPressTimer = 0.1f;
		prevGrabbed = grabbed;
		grabbed = true;
		if (Object.op_Implicit((Object)(object)playerAvatar.tumble))
		{
			playerAvatar.tumble.OverrideLookAtCamera(0.5f);
		}
	}

	public void RayCheck(bool _grab)
	{
		//IL_0065: Unknown result type (might be due to invalid IL or missing references)
		//IL_006a: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a5: Unknown result type (might be due to invalid IL or missing references)
		//IL_00bf: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c6: Unknown result type (might be due to invalid IL or missing references)
		//IL_0169: Unknown result type (might be due to invalid IL or missing references)
		//IL_016e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0173: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e1: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e6: Unknown result type (might be due to invalid IL or missing references)
		//IL_0112: Unknown result type (might be due to invalid IL or missing references)
		//IL_036c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0371: Unknown result type (might be due to invalid IL or missing references)
		//IL_0377: Unknown result type (might be due to invalid IL or missing references)
		//IL_013f: Unknown result type (might be due to invalid IL or missing references)
		//IL_022f: Unknown result type (might be due to invalid IL or missing references)
		//IL_042b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0430: Unknown result type (might be due to invalid IL or missing references)
		//IL_0438: Unknown result type (might be due to invalid IL or missing references)
		//IL_043d: Unknown result type (might be due to invalid IL or missing references)
		//IL_044a: Unknown result type (might be due to invalid IL or missing references)
		//IL_045c: Unknown result type (might be due to invalid IL or missing references)
		//IL_046e: Unknown result type (might be due to invalid IL or missing references)
		//IL_047b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0480: Unknown result type (might be due to invalid IL or missing references)
		//IL_0488: Unknown result type (might be due to invalid IL or missing references)
		//IL_048d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0495: Unknown result type (might be due to invalid IL or missing references)
		//IL_049a: Unknown result type (might be due to invalid IL or missing references)
		//IL_04d1: Unknown result type (might be due to invalid IL or missing references)
		//IL_03ea: Unknown result type (might be due to invalid IL or missing references)
		if ((playerAvatar.isDisabled || playerAvatar.deadSet) && (!Object.op_Implicit((Object)(object)playerAvatar.playerDeathHead) || !playerAvatar.playerDeathHead.spectated))
		{
			return;
		}
		float num = 10f;
		if (_grab)
		{
			grabDisableTimer = 0.1f;
		}
		Transform overrideTransform = playerAvatar.localCamera.GetOverrideTransform();
		Vector3 forward = overrideTransform.forward;
		bool isTumbling = playerAvatar.isTumbling;
		PhysGrabObject physGrabObject = null;
		if (isTumbling)
		{
			physGrabObject = playerAvatar.tumble.physGrabObject;
		}
		if (!_grab)
		{
			RaycastHit[] array = Physics.SphereCastAll(((Component)playerAvatar.localCamera).transform.position, 1f, ((Component)playerAvatar.localCamera).transform.forward, num, LayerMask.op_Implicit(mask), (QueryTriggerInteraction)2);
			for (int i = 0; i < array.Length; i++)
			{
				RaycastHit sphereHit = array[i];
				ValuableObject component = ((Component)sphereHit.transform).GetComponent<ValuableObject>();
				if (Object.op_Implicit((Object)(object)component) && (!component.discovered || component.discoveredReminder))
				{
					DiscoverLogic(sphereHit, component, null);
					continue;
				}
				PhysGrabObject component2 = ((Component)sphereHit.transform).GetComponent<PhysGrabObject>();
				if (Object.op_Implicit((Object)(object)component2) && component2.hasValuableDiscoverCustom)
				{
					DiscoverLogic(sphereHit, null, component2.valuableDiscoverCustom);
				}
			}
		}
		RaycastHit hit = default;
		if (grabState != GrabState.Climb && Physics.Raycast(overrideTransform.position, forward, ref hit, num, LayerMask.op_Implicit(mask), (QueryTriggerInteraction)1) && ((Component)hit.collider).CompareTag("Phys Grab Object"))
		{
			PhysGrabObject physGrabObject2 = ((Component)hit.transform).GetComponent<PhysGrabObject>();
			if ((isTumbling && (Object)(object)physGrabObject2 == (Object)(object)physGrabObject) || (Object)(object)hit.transform == (Object)(object)((Component)playerAvatar.healthGrab).transform || hit.distance > grabRange)
			{
				return;
			}
			if (_grab)
			{
				if (Object.op_Implicit((Object)(object)physGrabObject2) && physGrabObject2.grabDisableTimer > 0f)
				{
					return;
				}
				if (overrideGrabTimer <= 0f || !Object.op_Implicit((Object)(object)overrideGrabTarget) || (Object)(object)overrideGrabTarget == (Object)(object)physGrabObject2)
				{
					StartGrabbingPhysObject(hit, physGrabObject2);
					if (grabbed && overrideGrabTimer > 0f)
					{
						toggleGrab = true;
					}
				}
			}
			if (!grabbed)
			{
				bool flag = false;
				if (!Object.op_Implicit((Object)(object)physGrabObject2))
				{
					physGrabObject2 = ((Component)hit.transform).GetComponentInParent<PhysGrabObject>();
				}
				if (Object.op_Implicit((Object)(object)physGrabObject2) && physGrabObject2.grabDisableTimer <= 0f)
				{
					currentlyLookingAtPhysGrabObject = physGrabObject2;
					flag = true;
				}
				StaticGrabObject staticGrabObject = ((Component)hit.transform).GetComponent<StaticGrabObject>();
				if (!Object.op_Implicit((Object)(object)staticGrabObject))
				{
					staticGrabObject = ((Component)hit.transform).GetComponentInParent<StaticGrabObject>();
				}
				if (Object.op_Implicit((Object)(object)staticGrabObject) && ((Behaviour)staticGrabObject).enabled)
				{
					currentlyLookingAtStaticGrabObject = staticGrabObject;
					staticGrabObject.ShowHoverText();
					flag = true;
				}
				ItemAttributes component3 = ((Component)hit.transform).GetComponent<ItemAttributes>();
				if (Object.op_Implicit((Object)(object)component3))
				{
					currentlyLookingAtItemAttributes = component3;
					component3.ShowInfo();
				}
				if (flag)
				{
					Aim.instance.SetState(Aim.State.Grabbable);
				}
			}
		}
		if (!(PlayerController.instance.playerAvatarScript.upgradeTumbleClimb > 0f) || !(PlayerController.instance.EnergyCurrent > 0f) || grabbed)
		{
			return;
		}
		float num2 = 3f + grabRange;
		RaycastHit val = default;
		if (grabState == GrabState.Climb || !Physics.Raycast(overrideTransform.position, forward, ref val, num2, LayerMask.op_Implicit(mask), (QueryTriggerInteraction)1) || !isTumbling || grabState == GrabState.Climb || ((Component)val.collider).gameObject.layer != LayerMask.NameToLayer("Default"))
		{
			return;
		}
		if (overrideDisableSpecialGrabPowers)
		{
			Aim.instance.SetState(Aim.State.Disabled);
			if (_grab && overrideDisableSpecialGrabPowersZapCooldown <= 0f)
			{
				GrabDisableZapTrigger(val.point);
				overrideDisableSpecialGrabPowersZapCooldown = 0.2f;
			}
			return;
		}
		Aim.instance.SetState(Aim.State.Climbable);
		if (_grab)
		{
			grabClimbCollider = val.collider;
			grabClimbColliderPosition = ((Component)val.collider).transform.position;
			grabClimbPos = val.point;
			physGrabPoint.position = val.point;
			physGrabPointPlane.position = val.point;
			physGrabPointPuller.position = val.point;
			physGrabPointPullerPosition = val.point;
			physGrabPointPosition = val.point;
			localGrabPosition = val.point;
			initialPressTimer = 0.1f;
			prevGrabbed = grabbed;
			grabbed = true;
			((Component)physGrabPointPuller).gameObject.SetActive(true);
			GrabLinkClimb(val.point);
			ClimbSwingStart(overrideTransform);
			GrabStateSet(GrabState.Climb);
			PhysGrabPointActivate();
		}
	}

	private void DiscoverLogic(RaycastHit _sphereHit, ValuableObject _valuableObject, ValuableDiscoverCustom _valuableDiscoverCustom)
	{
		//IL_0002: Unknown result type (might be due to invalid IL or missing references)
		//IL_0007: Unknown result type (might be due to invalid IL or missing references)
		//IL_0008: Unknown result type (might be due to invalid IL or missing references)
		//IL_000f: Unknown result type (might be due to invalid IL or missing references)
		//IL_00aa: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b5: Unknown result type (might be due to invalid IL or missing references)
		//IL_00bf: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c4: Unknown result type (might be due to invalid IL or missing references)
		//IL_00fb: Unknown result type (might be due to invalid IL or missing references)
		//IL_0100: Unknown result type (might be due to invalid IL or missing references)
		//IL_0101: Unknown result type (might be due to invalid IL or missing references)
		//IL_0106: Unknown result type (might be due to invalid IL or missing references)
		//IL_0108: Unknown result type (might be due to invalid IL or missing references)
		//IL_010e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0118: Unknown result type (might be due to invalid IL or missing references)
		//IL_008b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0096: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a0: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a5: Unknown result type (might be due to invalid IL or missing references)
		//IL_037f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0384: Unknown result type (might be due to invalid IL or missing references)
		//IL_0385: Unknown result type (might be due to invalid IL or missing references)
		//IL_038a: Unknown result type (might be due to invalid IL or missing references)
		//IL_038c: Unknown result type (might be due to invalid IL or missing references)
		//IL_038d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0397: Unknown result type (might be due to invalid IL or missing references)
		//IL_0137: Unknown result type (might be due to invalid IL or missing references)
		//IL_013c: Unknown result type (might be due to invalid IL or missing references)
		//IL_03b3: Unknown result type (might be due to invalid IL or missing references)
		//IL_03b8: Unknown result type (might be due to invalid IL or missing references)
		//IL_025c: Unknown result type (might be due to invalid IL or missing references)
		//IL_026b: Unknown result type (might be due to invalid IL or missing references)
		//IL_02c1: Unknown result type (might be due to invalid IL or missing references)
		//IL_02d1: Unknown result type (might be due to invalid IL or missing references)
		Vector3 val = _sphereHit.point;
		Collider[] array = Physics.OverlapSphere(val, 0.01f, LayerMask.op_Implicit(mask));
		bool flag = false;
		Collider[] array2 = array;
		foreach (Collider val2 in array2)
		{
			if (Object.op_Implicit((Object)(object)_valuableObject))
			{
				if ((Object)(object)((Component)((Component)val2).transform).GetComponentInParent<ValuableObject>() != (Object)(object)_valuableObject)
				{
					flag = true;
					break;
				}
			}
			else if ((Object)(object)((Component)((Component)val2).transform).GetComponentInParent<PhysGrabObject>() != (Object)(object)_valuableDiscoverCustom.physGrabObject)
			{
				flag = true;
				break;
			}
		}
		if (flag)
		{
			if (Object.op_Implicit((Object)(object)_valuableObject))
			{
				if (Object.op_Implicit((Object)(object)_valuableObject.physGrabObject))
				{
					val = Vector3.MoveTowards(_sphereHit.point, _valuableObject.physGrabObject.centerPoint, 0.1f);
				}
			}
			else
			{
				val = Vector3.MoveTowards(_sphereHit.point, _valuableDiscoverCustom.physGrabObject.centerPoint, 0.1f);
			}
		}
		if ((Object.op_Implicit((Object)(object)_valuableObject) && !_valuableObject.discovered) || (Object.op_Implicit((Object)(object)_valuableDiscoverCustom) && !_valuableDiscoverCustom.discovered))
		{
			Vector3 val3 = ((Component)playerAvatar.localCamera).transform.position - val;
			RaycastHit[] array3 = Physics.SphereCastAll(val, 0.01f, val3, val3.magnitude, LayerMask.op_Implicit(mask), (QueryTriggerInteraction)2);
			bool flag2 = true;
			RaycastHit[] array4 = array3;
			for (int i = 0; i < array4.Length; i++)
			{
				RaycastHit val4 = array4[i];
				if (Object.op_Implicit((Object)(object)((Component)val4.transform).GetComponent<PlayerTumble>()))
				{
					continue;
				}
				bool flag3 = false;
				if (discoverSkipList.Count > 0)
				{
					PhysGrabObject componentInParent = ((Component)val4.transform).GetComponentInParent<PhysGrabObject>();
					if (Object.op_Implicit((Object)(object)componentInParent))
					{
						foreach (DiscoverSkip discoverSkip in discoverSkipList)
						{
							if ((Object)(object)((Component)componentInParent).transform == (Object)(object)discoverSkip.transform)
							{
								flag3 = true;
								break;
							}
						}
					}
				}
				if (!flag3 && !((Component)val4.transform).CompareTag("Player") && (Object)(object)val4.transform != (Object)(object)_sphereHit.transform && !Object.op_Implicit((Object)(object)((Component)val4.transform).GetComponent<PlayerDeathHead>()))
				{
					flag2 = false;
					break;
				}
			}
			if (!flag2)
			{
				return;
			}
			if (Object.op_Implicit((Object)(object)_valuableObject))
			{
				if (!_valuableObject.Discover(ValuableDiscoverGraphic.State.Discover) || !isLocal || !Object.op_Implicit((Object)(object)TruckSafetySpawnPoint.instance))
				{
					return;
				}
				float num = Vector3.Distance(((Component)playerAvatar).transform.position, ((Component)TruckSafetySpawnPoint.instance).transform.position) / 20f;
				if (SemiFunc.IsMultiplayer())
				{
					List<PlayerAvatar> list = SemiFunc.PlayerGetAll();
					float num2 = 0f;
					foreach (PlayerAvatar item in list)
					{
						if ((Object)(object)item != (Object)(object)playerAvatar)
						{
							num2 += Vector3.Distance(((Component)item).transform.position, ((Component)playerAvatar).transform.position);
						}
					}
					float num3 = num2 / (float)(list.Count - 1) / 10f;
					ProgressionManager.instance.roundPointsScouting += _valuableObject.dollarValueCurrent * (num3 + num) / 10f;
				}
				else
				{
					ProgressionManager.instance.roundPointsScouting += _valuableObject.dollarValueCurrent * num / 10f;
				}
			}
			else
			{
				_valuableDiscoverCustom.Discover();
			}
		}
		else
		{
			if (!Object.op_Implicit((Object)(object)_valuableObject) || !_valuableObject.discoveredReminder)
			{
				return;
			}
			Vector3 val5 = ((Component)playerAvatar.localCamera).transform.position - val;
			RaycastHit[] array5 = Physics.RaycastAll(val, val5, val5.magnitude, LayerMask.op_Implicit(mask), (QueryTriggerInteraction)2);
			bool flag4 = true;
			RaycastHit[] array4 = array5;
			for (int i = 0; i < array4.Length; i++)
			{
				RaycastHit val6 = array4[i];
				if (((Component)((Component)val6.collider).transform).CompareTag("Wall"))
				{
					flag4 = false;
					break;
				}
			}
			if (flag4)
			{
				_valuableObject.discoveredReminder = false;
				_valuableObject.Discover(ValuableDiscoverGraphic.State.Reminder);
			}
		}
	}

	private void ForceGrabPhysObject(PhysGrabObject _physObject, bool _toggleGrab = true)
	{
		//IL_0012: Unknown result type (might be due to invalid IL or missing references)
		//IL_0018: Unknown result type (might be due to invalid IL or missing references)
		//IL_001d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0022: Unknown result type (might be due to invalid IL or missing references)
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0057: Unknown result type (might be due to invalid IL or missing references)
		//IL_005c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0096: Unknown result type (might be due to invalid IL or missing references)
		Transform overrideTransform = playerAvatar.localCamera.GetOverrideTransform();
		Vector3 val = _physObject.midPoint - overrideTransform.position;
		RaycastHit[] array = Physics.RaycastAll(overrideTransform.position, val.normalized, val.magnitude, LayerMask.GetMask(new string[1] { "PhysGrabObject" }), (QueryTriggerInteraction)1);
		for (int i = 0; i < array.Length; i++)
		{
			RaycastHit hit = array[i];
			if (!Object.op_Implicit((Object)(object)_physObject))
			{
				continue;
			}
			Collider collider = hit.collider;
			if (!((Object)(object)((collider != null) ? ((Component)collider).GetComponentInParent<PhysGrabObject>() : null) != (Object)(object)_physObject))
			{
				if (grabbed)
				{
					ReleaseObject(-1);
				}
				StartGrabbingPhysObject(hit, _physObject);
				if (grabbed & _toggleGrab)
				{
					toggleGrab = true;
				}
				break;
			}
		}
	}

	private void GrabRevisionNext()
	{
		if (isLocal)
		{
			grabRevision = ((grabRevision == int.MaxValue) ? 1 : (grabRevision + 1));
		}
	}

	private void GrabLinkClimb(Vector3 point)
	{
		//IL_003d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0046: Unknown result type (might be due to invalid IL or missing references)
		//IL_004c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0021: Unknown result type (might be due to invalid IL or missing references)
		GrabRevisionNext();
		if (SemiFunc.IsMultiplayer())
		{
			photonView.RPC("GrabLinkClimbRPC", (RpcTarget)0, new object[2] { point, grabRevision });
		}
		else
		{
			GrabLinkClimbRPC(point, grabRevision);
		}
	}

	[PunRPC]
	private void GrabLinkClimbRPC(Vector3 point, int _grabRevision, PhotonMessageInfo _info = default(PhotonMessageInfo))
	{
		//IL_0000: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0035: Unknown result type (might be due to invalid IL or missing references)
		//IL_0036: Unknown result type (might be due to invalid IL or missing references)
		//IL_0041: Unknown result type (might be due to invalid IL or missing references)
		//IL_004d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0054: Unknown result type (might be due to invalid IL or missing references)
		//IL_0055: Unknown result type (might be due to invalid IL or missing references)
		//IL_005b: Unknown result type (might be due to invalid IL or missing references)
		//IL_005c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0062: Unknown result type (might be due to invalid IL or missing references)
		//IL_0063: Unknown result type (might be due to invalid IL or missing references)
		if (SemiFunc.OwnerOnlyRPC(_info, photonView) && _grabRevision > 0)
		{
			climbGrabTimestamp = _info.SentServerTimestamp;
			grabRevision = _grabRevision;
			physGrabPoint.position = point;
			physGrabPointPosition = point;
			physGrabPointPlane.position = point;
			physGrabPointPuller.position = point;
			physGrabPointPullerPosition = point;
			grabClimbPos = point;
			localGrabPosition = point;
			grabbedObjectTransform = null;
			grabbedPhysGrabObjectColliderID = -1;
			grabbedPhysGrabObjectCollider = null;
			prevGrabbed = grabbed;
			grabbed = true;
		}
	}

	[PunRPC]
	private void GrabClimbEndedRPC(PhotonMessageInfo _info = default(PhotonMessageInfo))
	{
		//IL_0000: Unknown result type (might be due to invalid IL or missing references)
		if (SemiFunc.OwnerOnlyRPC(_info, photonView))
		{
			prevGrabbed = grabbed;
			grabbed = false;
		}
	}

	public void ReleaseObject(int _releaseObjectViewID, float _disableTimer = 0.1f)
	{
		OverrideMinimumGrabTimeRelease(_releaseObjectViewID);
		if (!grabbed)
		{
			if (_releaseObjectViewID == -1)
			{
				return;
			}
			PhotonView val = PhotonView.Find(_releaseObjectViewID);
			if (!Object.op_Implicit((Object)(object)val))
			{
				return;
			}
			PhysGrabObject component = ((Component)val).GetComponent<PhysGrabObject>();
			if (Object.op_Implicit((Object)(object)component))
			{
				component.photonView.RPC("GrabEndedRPC", (RpcTarget)2, new object[1] { photonView.ViewID });
				return;
			}
			StaticGrabObject component2 = ((Component)val).GetComponent<StaticGrabObject>();
			if (Object.op_Implicit((Object)(object)component2))
			{
				component2.photonView.RPC("GrabEndedRPC", (RpcTarget)2, new object[1] { photonView.ViewID });
			}
			return;
		}
		if (_releaseObjectViewID != -1)
		{
			int num = -1;
			if (Object.op_Implicit((Object)(object)grabbedPhysGrabObject) && Object.op_Implicit((Object)(object)grabbedPhysGrabObject.photonView))
			{
				num = grabbedPhysGrabObject.photonView.ViewID;
			}
			else if (Object.op_Implicit((Object)(object)grabbedStaticGrabObject) && Object.op_Implicit((Object)(object)grabbedStaticGrabObject.photonView))
			{
				num = grabbedStaticGrabObject.photonView.ViewID;
			}
			if (num != _releaseObjectViewID)
			{
				return;
			}
		}
		overrideGrabTarget = null;
		if (Object.op_Implicit((Object)(object)physGrabPoint))
		{
			PhysGrabEnded();
			ClimbSwingReset();
			gamepadGrabCursor.Reset();
			GamepadMeleeRotationReset();
			physGrabPoint.SetParent(((Component)this).transform.parent, true);
			if (MountedVehicleGrab)
			{
				vehicleGrabReleaseTimer = 0.1f;
				toggleGrab = false;
				toggleGrabTimer = 0f;
				mountedVehicle = null;
				mountedMounting = null;
			}
			grabbedObject = null;
			grabbedObjectTransform = null;
			objectTurningObject = null;
			grabbedPhysGrabObject = null;
			grabbedStaticGrabObject = null;
			prevGrabbed = grabbed;
			grabbed = false;
			GrabStateSet(GrabState.None);
			((Renderer)physGrabBeamScript.lineRenderer).enabled = false;
			if (isLocal)
			{
				PlayerController.instance.physGrabObject = null;
				PlayerController.instance.physGrabActive = false;
			}
			if (Object.op_Implicit((Object)(object)physGrabPoint))
			{
				PhysGrabPointDeactivate();
			}
			if (Object.op_Implicit((Object)(object)physGrabPointPuller))
			{
				((Component)physGrabPointPuller).gameObject.SetActive(false);
			}
			PhysGrabBeamDeactivate();
			grabDisableTimer = _disableTimer;
		}
	}

	[PunRPC]
	public void ReleaseObjectRPC(bool _physGrabEnded, float _disableTimer, int _releaseObjectViewID, int _grabRevision = -1, PhotonMessageInfo _info = default(PhotonMessageInfo))
	{
		//IL_0000: Unknown result type (might be due to invalid IL or missing references)
		if (SemiFunc.MasterAndOwnerOnlyRPC(_info, photonView) && (_grabRevision == -1 || _grabRevision == grabRevision) && isLocal)
		{
			bool flag = grabbed;
			ReleaseObject(_releaseObjectViewID, _disableTimer);
			if (!flag)
			{
				grabDisableTimer = _disableTimer;
			}
		}
	}

	private void GridObjectsInstantiate()
	{
		//IL_0020: Unknown result type (might be due to invalid IL or missing references)
		//IL_0025: Unknown result type (might be due to invalid IL or missing references)
		//IL_0031: Unknown result type (might be due to invalid IL or missing references)
		//IL_01b1: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a1: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a6: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ae: Unknown result type (might be due to invalid IL or missing references)
		//IL_00be: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ce: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e8: Unknown result type (might be due to invalid IL or missing references)
		//IL_0101: Unknown result type (might be due to invalid IL or missing references)
		//IL_0106: Unknown result type (might be due to invalid IL or missing references)
		//IL_011b: Unknown result type (might be due to invalid IL or missing references)
		//IL_012e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0133: Unknown result type (might be due to invalid IL or missing references)
		//IL_0137: Unknown result type (might be due to invalid IL or missing references)
		//IL_014f: Unknown result type (might be due to invalid IL or missing references)
		//IL_017e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0190: Unknown result type (might be due to invalid IL or missing references)
		PhysGrabObject physGrabObject = grabbedPhysGrabObject;
		if (((Component)physGrabObject).GetComponent<PhysGrabObjectImpactDetector>().isCart)
		{
			return;
		}
		Quaternion rotation = grabbedPhysGrabObject.rb.rotation;
		grabbedPhysGrabObject.rb.rotation = Quaternion.identity;
		Collider[] componentsInChildren = ((Component)physGrabObject).GetComponentsInChildren<Collider>();
		foreach (Collider val in componentsInChildren)
		{
			if (!val.isTrigger && ((Component)val).gameObject.activeSelf && !(val is MeshCollider))
			{
				GameObject val2 = Object.Instantiate<GameObject>(physGrabPointVisualGridObject);
				val2.SetActive(true);
				SetGridObjectScale(val2.transform, val);
				Quaternion rotation2 = grabbedObjectTransform.rotation;
				physGrabPointVisualGrid.rotation = Quaternion.identity;
				grabbedObjectTransform.rotation = Quaternion.identity;
				physGrabPointVisualGrid.localRotation = Quaternion.identity;
				Vector3 position = ((Component)grabbedPhysGrabObject).transform.position;
				physGrabPointVisualGrid.position = ((Component)grabbedPhysGrabObject).transform.TransformPoint(grabbedPhysGrabObject.midPointOffset);
				((Component)grabbedPhysGrabObject).transform.position = Vector3.zero;
				Transform transform = val2.transform;
				Bounds bounds = val.bounds;
				transform.position = bounds.center;
				val2.transform.rotation = ((Component)val).transform.rotation;
				val2.transform.SetParent(physGrabPointVisualGrid);
				physGrabPointVisualGridObjects.Add(val2);
				grabbedObjectTransform.rotation = rotation2;
				((Component)grabbedPhysGrabObject).transform.position = position;
			}
		}
		grabbedPhysGrabObject.rb.rotation = rotation.normalized;
	}

	private void SetGridObjectScale(Transform _itemEquipCubeTransform, Collider _collider)
	{
		//IL_0006: Unknown result type (might be due to invalid IL or missing references)
		//IL_000b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0012: Unknown result type (might be due to invalid IL or missing references)
		//IL_0028: Unknown result type (might be due to invalid IL or missing references)
		//IL_0033: Unknown result type (might be due to invalid IL or missing references)
		//IL_0038: Unknown result type (might be due to invalid IL or missing references)
		//IL_0065: Unknown result type (might be due to invalid IL or missing references)
		//IL_0078: Unknown result type (might be due to invalid IL or missing references)
		//IL_008b: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a7: Unknown result type (might be due to invalid IL or missing references)
		//IL_013f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0125: Unknown result type (might be due to invalid IL or missing references)
		//IL_012a: Unknown result type (might be due to invalid IL or missing references)
		//IL_012f: Unknown result type (might be due to invalid IL or missing references)
		//IL_00cf: Unknown result type (might be due to invalid IL or missing references)
		//IL_00df: Unknown result type (might be due to invalid IL or missing references)
		//IL_0104: Unknown result type (might be due to invalid IL or missing references)
		//IL_0118: Unknown result type (might be due to invalid IL or missing references)
		Quaternion rotation = ((Component)_collider).transform.rotation;
		((Component)_collider).transform.rotation = Quaternion.identity;
		BoxCollider val = (BoxCollider)(object)((_collider is BoxCollider) ? _collider : null);
		if (val != null)
		{
			_itemEquipCubeTransform.localScale = Vector3.Scale(val.size, ((Component)_collider).transform.lossyScale);
		}
		else
		{
			SphereCollider val2 = (SphereCollider)(object)((_collider is SphereCollider) ? _collider : null);
			if (val2 != null)
			{
				float num = val2.radius * Mathf.Max(new float[3]
				{
					((Component)_collider).transform.lossyScale.x,
					((Component)_collider).transform.lossyScale.y,
					((Component)_collider).transform.lossyScale.z
				}) * 2f;
				_itemEquipCubeTransform.localScale = new Vector3(num, num, num);
			}
			else
			{
				CapsuleCollider val3 = (CapsuleCollider)(object)((_collider is CapsuleCollider) ? _collider : null);
				if (val3 != null)
				{
					float num2 = val3.radius * Mathf.Max(((Component)_collider).transform.lossyScale.x, ((Component)_collider).transform.lossyScale.z) * 2f;
					float num3 = val3.height * ((Component)_collider).transform.lossyScale.y;
					_itemEquipCubeTransform.localScale = new Vector3(num2, num3, num2);
				}
				else
				{
					Bounds bounds = _collider.bounds;
					_itemEquipCubeTransform.localScale = bounds.size;
				}
			}
		}
		((Component)_collider).transform.rotation = rotation;
	}

	public void GrabStateSet(GrabState _state)
	{
		//IL_003f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0045: Unknown result type (might be due to invalid IL or missing references)
		if (isLocal && _state != grabState)
		{
			if (SemiFunc.IsMultiplayer())
			{
				photonView.RPC("GrabStateSetRPC", (RpcTarget)0, new object[1] { (int)_state });
			}
			else
			{
				GrabStateSetRPC((int)_state);
			}
		}
	}

	[PunRPC]
	private void GrabStateSetRPC(int _state, PhotonMessageInfo _info = default(PhotonMessageInfo))
	{
		//IL_0000: Unknown result type (might be due to invalid IL or missing references)
		if (SemiFunc.OwnerOnlyRPC(_info, photonView))
		{
			grabState = (GrabState)_state;
			grabStateStart = true;
		}
	}

	private void GridObjectsRemove()
	{
		foreach (GameObject physGrabPointVisualGridObject in physGrabPointVisualGridObjects)
		{
			Object.Destroy((Object)(object)physGrabPointVisualGridObject);
		}
		physGrabPointVisualGridObjects.Clear();
	}

	private void PhysGrabInTumbleStateLookAtCameraDirection()
	{
		if (SemiFunc.IsMasterClientOrSingleplayer() && grabbed && grabState != GrabState.Climb && playerAvatar.isTumbling)
		{
			playerAvatar.tumble.OverrideLookAtCamera(0.5f);
		}
	}

	public void OverrideDisableGrabLookAt(float _time = 0.1f)
	{
		playerAvatar.playerAvatarVisuals.playerEyes.OverrideDisableGrabLookAt(_time);
		if (Object.op_Implicit((Object)(object)playerAvatar.tumble))
		{
			playerAvatar.tumble.OverrideDisableLookAtCamera(_time);
		}
	}

	private void LateUpdate()
	{
		if (overrideGrabberVisualPositionTimer > 0f)
		{
			ApplyGrabberVisualOverride();
			overrideGrabberVisualPositionTimer -= Time.deltaTime;
			if (overrideGrabberVisualPositionTimer <= 0f)
			{
				overrideGrabberVisualTransform = null;
			}
		}
	}

	public void SetThirdPerson(bool _state)
	{
		//IL_003d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0047: Unknown result type (might be due to invalid IL or missing references)
		//IL_0057: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d7: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e1: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f1: Unknown result type (might be due to invalid IL or missing references)
		if (_state)
		{
			physGrabPointPlane.SetParent(playerAvatar.playerAvatarVisuals.playerAvatarRightArm.grabberTransformTarget, true);
			physGrabPointPlane.localPosition = new Vector3(0f, 0f, physGrabPointPlane.localPosition.z);
			physGrabPointPlane.localRotation = Quaternion.identity;
			if (Object.op_Implicit((Object)(object)physGrabBeamComponent))
			{
				physGrabBeamComponent.PhysGrabPointOrigin = physGrabBeamComponent.PhysGrabPointOriginClient;
			}
		}
		else
		{
			if (Object.op_Implicit((Object)(object)physGrabBeamComponent))
			{
				physGrabBeamComponent.PhysGrabPointOrigin = physGrabBeamComponent.PhysGrabPointOriginLocal;
			}
			physGrabPointPlane.SetParent(((Component)CameraAim.Instance).transform, true);
			physGrabPointPlane.localPosition = new Vector3(0f, 0f, physGrabPointPlane.localPosition.z);
			physGrabPointPlane.localRotation = Quaternion.identity;
		}
	}

	public void OverrideDiscoverSkipListSet(Transform _transform)
	{
		foreach (DiscoverSkip discoverSkip2 in discoverSkipList)
		{
			if ((Object)(object)_transform == (Object)(object)discoverSkip2.transform)
			{
				discoverSkip2.timer = 0.25f;
				return;
			}
		}
		DiscoverSkip discoverSkip = new DiscoverSkip();
		discoverSkip.transform = _transform;
		discoverSkip.timer = 0.25f;
		discoverSkipList.Add(discoverSkip);
	}

	private void OverrideDiscoverSkipListLogic()
	{
		for (int i = 0; i < discoverSkipList.Count; i++)
		{
			DiscoverSkip discoverSkip = discoverSkipList[i];
			if (discoverSkip.timer <= 0f)
			{
				discoverSkipList.RemoveAt(i);
				i--;
			}
			else
			{
				discoverSkip.timer -= Time.deltaTime;
			}
		}
	}

	public PhysGrabber()
	{
		//IL_0110: Unknown result type (might be due to invalid IL or missing references)
		//IL_0115: Unknown result type (might be due to invalid IL or missing references)
		//IL_011b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0120: Unknown result type (might be due to invalid IL or missing references)
		//IL_012d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0132: Unknown result type (might be due to invalid IL or missing references)
		//IL_0138: Unknown result type (might be due to invalid IL or missing references)
		//IL_013d: Unknown result type (might be due to invalid IL or missing references)
		//IL_017a: Unknown result type (might be due to invalid IL or missing references)
		//IL_017f: Unknown result type (might be due to invalid IL or missing references)
	}
}
