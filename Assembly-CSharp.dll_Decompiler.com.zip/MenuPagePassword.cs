using TMPro;
using UnityEngine;
using UnityEngine.UI;

public class MenuPagePassword : MonoBehaviour
{
	public static MenuPagePassword instance;

	internal MenuPage menuPage;

	public MenuTextInput passwordInput;

	public SemiUI passwordSemiUI;

	public MenuButton confirmButton;

	public RectTransform confirmButtonAnimationTransform;

	public AnimationCurve confirmButtonAnimationCurve;

	private float confirmButtonAnimationLerp = 1f;

	private bool confirmButtonState;

	private bool showing;

	[Space]
	public Sprite showIconOn;

	public Sprite showIconOff;

	public RawImage showImage;

	[Space]
	public SemiUI showUI;

	public SemiUI copyUI;

	[Space]
	public LocalizedAsset localizedSkipText;

	public LocalizedAsset localizedConfirmText;

	[RuntimeInitializeOnLoadMethod(/*Could not decode attribute arguments.*/)]
	private static void RuntimeInitializeOnLoad()
	{
		instance = null;
	}

	private void Awake()
	{
		instance = this;
	}

	private void Start()
	{
		menuPage = ((Component)this).GetComponent<MenuPage>();
	}

	private void Update()
	{
		//IL_0144: Unknown result type (might be due to invalid IL or missing references)
		//IL_0149: Unknown result type (might be due to invalid IL or missing references)
		showUI.hideTimer = 0f;
		copyUI.hideTimer = 0f;
		string textCurrent = passwordInput.textCurrent;
		if (!confirmButtonState)
		{
			if (textCurrent.Length > 0)
			{
				confirmButton.buttonTextString = "Confirm";
				((TMP_Text)confirmButton.buttonText).text = localizedConfirmText?.GetLocalizedString() ?? "Confirm";
				confirmButtonAnimationLerp = 0f;
				confirmButtonState = true;
			}
		}
		else if (textCurrent.Length <= 0)
		{
			confirmButton.buttonTextString = "Skip";
			((TMP_Text)confirmButton.buttonText).text = localizedSkipText?.GetLocalizedString() ?? "Skip";
			confirmButtonAnimationLerp = 0f;
			confirmButtonState = false;
		}
		if (confirmButtonAnimationLerp < 1f)
		{
			confirmButtonAnimationLerp += Time.deltaTime * 5f;
			confirmButtonAnimationLerp = Mathf.Clamp01(confirmButtonAnimationLerp);
			confirmButtonAnimationTransform.anchoredPosition = Vector2.op_Implicit(new Vector3(0f, confirmButtonAnimationCurve.Evaluate(confirmButtonAnimationLerp) * 5f, 0f));
		}
		if ((Input.GetKeyDown((KeyCode)13) || Input.GetKeyDown((KeyCode)271)) && (!MenuManager.instance.isKeyboardNavigating || MenuManager.instance.currentMenuID == passwordInput.menuSelectableElement.menuID))
		{
			ConfirmButton();
		}
	}

	public void ToggleShowButton()
	{
		//IL_0006: Unknown result type (might be due to invalid IL or missing references)
		passwordSemiUI.SemiUITextFlashColor(Color.white, 0.1f);
		passwordSemiUI.SemiUISpringShakeY(2f, 5f, 0.2f);
		MenuManager.instance.MenuEffectClick(MenuManager.MenuClickEffectType.Confirm, null, 2f, 0.5f);
		showing = !showing;
		passwordInput.obscureText = !showing;
		if (showing)
		{
			((TMP_Text)passwordInput.textMain).alignment = (TextAlignmentOptions)513;
			showImage.texture = (Texture)(object)showIconOff.texture;
		}
		else
		{
			((TMP_Text)passwordInput.textMain).alignment = (TextAlignmentOptions)4097;
			showImage.texture = (Texture)(object)showIconOn.texture;
		}
		showUI.SemiUISpringShakeY(2f, 5f, 0.2f);
		passwordInput.InputTextSet();
	}

	public void CopyButton()
	{
		copyUI.SemiUISpringShakeY(2f, 5f, 0.2f);
		MenuManager.instance.MenuEffectClick(MenuManager.MenuClickEffectType.Confirm, null, 2f, 0.5f);
		GUIUtility.systemCopyBuffer = passwordInput.textCurrent;
	}

	public void ConfirmButton()
	{
		MenuManager.instance.PageReactivatePageUnderThisPage(menuPage);
		MenuManager.instance.MenuEffectPopUpClose();
		menuPage.PageStateSet(MenuPage.PageState.Closing);
		DataDirector.instance.networkPassword = passwordInput.textCurrent;
	}
}
