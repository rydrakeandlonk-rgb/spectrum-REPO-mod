using UnityEngine;

public class EnemyShadowAnim : MonoBehaviour
{
	public Enemy enemy;

	public EnemyShadow enemyShadow;

	[Header("Sounds")]
	public Sound backCrackLong;

	public Sound backCrackShort;

	public Sound neckCrackLong;

	public Sound neckCrackShort;

	public Sound clapSound;

	public Sound globalClapSound;

	public Sound clapTell;

	public Sound hurtSound;

	public Sound deathSound;

	public Sound idleLoop;

	public Sound moveShort;

	public Sound moveLong;

	public Sound targeted;

	public Sound notTargeted;

	[Header("Particles")]
	public ParticleSystem slapParticles;

	public ParticleSystem spawnSmokeParticle;

	public ParticleSystem shockwaveParticles;

	public ParticleSystem[] deathParticles;

	[Header("Misc")]
	public GameObject wooshLine1;

	public GameObject wooshLine2;

	private Animator animator;

	private static readonly int animDespawn = Animator.StringToHash("despawn");

	private static readonly int animDespawnTrigger = Animator.StringToHash("despawn_trigger");

	private static readonly int animSpawnTrigger = Animator.StringToHash("spawn_trigger");

	internal bool spawnTriggerImpulse = true;

	private Quaternion prevHeadLookRotation;

	private Quaternion prevRigidBodyRotation;

	private Quaternion prevBackRotation;

	private float moveSoundRigidBodyTimer;

	private float moveBackSoundTimer;

	private float moveSoundHeadTimer;

	private void Awake()
	{
		animator = ((Component)this).GetComponent<Animator>();
	}

	private void Update()
	{
		idleLoop.PlayLoop(enemyShadow.currentState != EnemyShadow.State.Despawn && enemy.CurrentState != EnemyState.Despawn, 1f, 1f);
		if (enemyShadow.currentState == EnemyShadow.State.Despawn || enemy.CurrentState == EnemyState.Despawn)
		{
			if (!animator.GetBool(animDespawn))
			{
				spawnSmokeParticle.Play();
				animator.SetTrigger(animDespawnTrigger);
			}
			animator.SetBool(animDespawn, true);
		}
		else
		{
			animator.SetBool(animDespawn, false);
			if (spawnTriggerImpulse)
			{
				spawnTriggerImpulse = false;
				animator.SetTrigger(animSpawnTrigger);
			}
		}
	}

	public void TurnSoundLogic(Transform _headTransform, Rigidbody _rb, Transform _backTransform)
	{
		//IL_0011: Unknown result type (might be due to invalid IL or missing references)
		//IL_0017: Unknown result type (might be due to invalid IL or missing references)
		//IL_0075: Unknown result type (might be due to invalid IL or missing references)
		//IL_007b: Unknown result type (might be due to invalid IL or missing references)
		//IL_00de: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e4: Unknown result type (might be due to invalid IL or missing references)
		//IL_003e: Unknown result type (might be due to invalid IL or missing references)
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0064: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b2: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d8: Unknown result type (might be due to invalid IL or missing references)
		//IL_01a1: Unknown result type (might be due to invalid IL or missing references)
		//IL_01a6: Unknown result type (might be due to invalid IL or missing references)
		//IL_01ad: Unknown result type (might be due to invalid IL or missing references)
		//IL_01b2: Unknown result type (might be due to invalid IL or missing references)
		//IL_01b9: Unknown result type (might be due to invalid IL or missing references)
		//IL_01be: Unknown result type (might be due to invalid IL or missing references)
		//IL_011b: Unknown result type (might be due to invalid IL or missing references)
		//IL_013c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0141: Unknown result type (might be due to invalid IL or missing references)
		//IL_0174: Unknown result type (might be due to invalid IL or missing references)
		//IL_0195: Unknown result type (might be due to invalid IL or missing references)
		//IL_019a: Unknown result type (might be due to invalid IL or missing references)
		if (SemiFunc.PerSecond(5f, (Object)(object)this))
		{
			float num = Quaternion.Angle(prevHeadLookRotation, _headTransform.rotation);
			if (num > 30f && moveSoundHeadTimer <= 0f)
			{
				neckCrackShort.Play(_headTransform.position);
				prevHeadLookRotation = _headTransform.rotation;
				moveSoundHeadTimer = 1f;
			}
			num = Quaternion.Angle(prevRigidBodyRotation, _rb.rotation);
			if (num > 20f && moveSoundRigidBodyTimer <= 0f)
			{
				moveSoundRigidBodyTimer = 0.5f;
				moveLong.Play(((Component)this).transform.position);
				prevRigidBodyRotation = _rb.rotation;
			}
			num = Quaternion.Angle(prevBackRotation, _backTransform.rotation);
			if (num > 30f && moveBackSoundTimer <= 0f)
			{
				moveBackSoundTimer = 1f;
				backCrackLong.Play(((Component)this).transform.position);
				prevBackRotation = _backTransform.rotation;
			}
			else if (num > 15f && moveBackSoundTimer <= 0f)
			{
				moveBackSoundTimer = 1f;
				backCrackShort.Play(((Component)this).transform.position);
				prevBackRotation = _backTransform.rotation;
			}
			prevHeadLookRotation = _headTransform.rotation;
			prevRigidBodyRotation = _rb.rotation;
			prevBackRotation = _backTransform.rotation;
		}
		if (moveSoundRigidBodyTimer > 0f)
		{
			moveSoundRigidBodyTimer -= Time.deltaTime;
		}
		if (moveSoundHeadTimer > 0f)
		{
			moveSoundHeadTimer -= Time.deltaTime;
		}
		if (moveBackSoundTimer > 0f)
		{
			moveBackSoundTimer -= Time.deltaTime;
		}
	}

	public void PlayBackCrackSound()
	{
		//IL_000c: Unknown result type (might be due to invalid IL or missing references)
		backCrackLong.Play(((Component)this).transform.position);
	}

	public void PlayClapSound()
	{
		//IL_000c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0037: Unknown result type (might be due to invalid IL or missing references)
		clapSound.Play(((Component)this).transform.position);
		globalClapSound.Play(((Component)this).transform.position);
	}

	public void PlayHurtSound()
	{
		//IL_000c: Unknown result type (might be due to invalid IL or missing references)
		hurtSound.Play(((Component)this).transform.position);
	}

	public void PlayDeathSound()
	{
		//IL_000c: Unknown result type (might be due to invalid IL or missing references)
		deathSound.Play(((Component)this).transform.position);
	}

	public void playTargetedSound(Vector3 _pos)
	{
		//IL_0006: Unknown result type (might be due to invalid IL or missing references)
		targeted.Play(_pos);
	}

	public void PlayUntargetedSound(Vector3 _pos)
	{
		//IL_0006: Unknown result type (might be due to invalid IL or missing references)
		notTargeted.Play(_pos);
	}

	public void PlaySlapParticles(Vector3 _pos)
	{
		//IL_000b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0028: Unknown result type (might be due to invalid IL or missing references)
		((Component)slapParticles).transform.position = _pos;
		slapParticles.Play(true);
		((Component)shockwaveParticles).transform.position = _pos;
		shockwaveParticles.Play(true);
	}

	public void ClapCameraShake()
	{
		//IL_001f: Unknown result type (might be due to invalid IL or missing references)
		//IL_004d: Unknown result type (might be due to invalid IL or missing references)
		GameDirector.instance.CameraShake.ShakeDistance(5f, 3f, 8f, ((Component)this).transform.position, 0.5f);
		GameDirector.instance.CameraImpact.ShakeDistance(10f, 3f, 8f, ((Component)this).transform.position, 0.1f);
	}

	public void PlayDeathParticles()
	{
		ParticleSystem[] array = deathParticles;
		for (int i = 0; i < array.Length; i++)
		{
			((Component)array[i]).gameObject.SetActive(true);
		}
	}

	public void ToggleWooshLines(bool _state)
	{
		wooshLine1.SetActive(_state);
		wooshLine2.SetActive(_state);
	}

	public void SetDespawn()
	{
		enemy.EnemyParent.Despawn();
	}
}
