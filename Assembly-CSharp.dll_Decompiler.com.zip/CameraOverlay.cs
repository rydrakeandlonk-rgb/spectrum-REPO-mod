using UnityEngine;

public class CameraOverlay : MonoBehaviour
{
	internal Camera overlayCamera;

	public static CameraOverlay instance;

	[RuntimeInitializeOnLoadMethod(/*Could not decode attribute arguments.*/)]
	private static void RuntimeInitializeOnLoad()
	{
		instance = null;
	}

	private void Start()
	{
		overlayCamera = ((Component)this).GetComponent<Camera>();
		instance = this;
	}
}
