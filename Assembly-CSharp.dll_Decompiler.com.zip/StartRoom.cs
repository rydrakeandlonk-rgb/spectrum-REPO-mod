using UnityEngine;

public class StartRoom : MonoBehaviour
{
	private void Start()
	{
		((Component)this).transform.parent = LevelGenerator.Instance.LevelParent.transform;
		if (!SemiFunc.IsMasterClientOrSingleplayer())
		{
			return;
		}
		CustomConnectionObject[] componentsInChildren = ((Component)this).GetComponentsInChildren<CustomConnectionObject>();
		foreach (CustomConnectionObject customConnectionObject in componentsInChildren)
		{
			if (((Component)customConnectionObject).gameObject.activeInHierarchy)
			{
				customConnectionObject.Setup();
			}
		}
	}
}
