using System;
using System.Collections.Generic;
using Photon.Pun;
using Photon.Realtime;
using UnityEngine;
using UnityEngine.Events;

[DefaultExecutionOrder(20)]
public class Larva : MonoBehaviourPunCallbacks
{
	public enum State
	{
		Spawn,
		Idle,
		Targeting,
		JumpCharge,
		Jump,
		JumpLand,
		LungeTell,
		Lunge,
		Puke,
		Recover,
		Held,
		Hurt,
		HeldPuke,
		Dormant
	}

	[Header("References")]
	public PhysGrabObject physGrabObject;

	public PhysGrabObjectImpactDetector impactDetector;

	public NotValuableObject health;

	public Rigidbody rb;

	public BotSystemSpringPoseAnimator botLimb;

	public BotSystemSpringPoseAnimatorPose idlePose;

	public BotSystemSpringPoseAnimatorPose jumpChargePose;

	public BotSystemSpringPoseAnimatorPose jumpPose;

	public SemiPuke semiPuke;

	public Transform mouthTransform;

	public Transform visionTransform;

	public Transform groundCheckTransform;

	public Transform headTransform;

	[Header("Sounds")]
	public Sound soundNotice;

	public Sound soundJump;

	public Sound soundLand;

	public Sound soundLungeTell;

	public Sound soundLunge;

	public Sound soundHurt;

	public Sound soundDestroy;

	public Sound soundDestroySplat;

	public Sound soundHeldPanicLoop;

	[Header("Gnome Sounds")]
	public Sound soundGnomeNotice;

	public Sound soundGnomeJump;

	public Sound soundGnomeLand;

	public Sound soundGnomeLungeTell;

	public Sound soundGnomeLunge;

	public Sound soundGnomeHurt;

	public Sound soundGnomeDestroy;

	public float soundGnomePitch = 3f;

	public float soundGnomePitchRandom = 0.5f;

	[Header("Sound Pitch")]
	public float soundPitch = 5f;

	public float soundPitchRandom = 3f;

	public float soundBakedPitch = 10f;

	public float soundLoopPitchNoiseSpeed = 3.5f;

	[Header("Particles")]
	public ParticleSystem movementSquirtParticles;

	public LarvaPukeDeathParticles deathPukeParticles;

	public int jumpSquirtParticleCount = 3;

	public int landSquirtParticleCount = 4;

	public float movementSquirtUpward = 0.3f;

	public float movementSquirtGroundOffset = 0.05f;

	[Header("Roam")]
	public float spawnRadius = 4f;

	public float idleHopDelayMin = 0.8f;

	public float idleHopDelayMax = 2.1f;

	public float jumpChargeTime = 1f;

	public float jumpChargeYawDamping = 8f;

	public float jumpHorizontalVelocity = 3.6f;

	public float jumpUpVelocity = 4.8f;

	public float jumpAngularVelocity = 1.3f;

	public float jumpMaximumTime = 1.5f;

	public float jumpLandTime = 0.2f;

	[Header("Dormancy")]
	public float dormantCheckTime = 5f;

	[Header("Player Lunge")]
	public float visionRange = 8f;

	public float visionCheckTime = 0.16f;

	public float attackCooldownOnSpawn = 1f;

	public float attackCooldownAfterAttack = 1f;

	public float targetAttackDelayTimeMin = 1f;

	public float targetAttackDelayTimeMax = 60f;

	public float targetLookTime = 1.2f;

	public float targetLookFacingAngle = 22f;

	public float lungeTellTime = 0.32f;

	public float lungeHorizontalVelocity = 8.5f;

	public float lungeUpVelocity = 2.4f;

	public float lungeAngularVelocity = 2f;

	public float lungePukeDelay = 0.22f;

	public float pukeTime = 1.15f;

	public float pukeRecoil = 300f;

	public float pukeRandomTorque = 65f;

	public float recoverTime = 0.45f;

	public float turnTorque = 7f;

	public float turnTorqueMaximum = 45f;

	[Header("Player Look")]
	public float playerLookYawMaximum = 60f;

	public float playerLookPitchUpMaximum = 30f;

	public float playerLookPitchDownMaximum = 20f;

	public float playerLookSmoothTime = 0.1f;

	public float playerLookMaximumSpeed = 420f;

	[Header("Attack Tell")]
	public float lungeTellSpringSpeed = 38f;

	public float lungeTellSpringDamping = 0.18f;

	public float lungeTellSlitherForce = 1.9f;

	public float lungeTellSlitherScale = 1.35f;

	public float lungeTellSlitherAxisUp = 0.28f;

	[Header("Jump Jelly")]
	public float jumpPoseExaggeration = 1.6f;

	public float jumpJellySpringSpeed = 24f;

	public float jumpJellySpringDamping = 0.4f;

	public float jumpJellyPulseTime = 0.16f;

	public float jumpJellyForceMin = 1.1f;

	public float jumpJellyForceMax = 2f;

	public float jumpJellyAxisUp = 0.38f;

	public float jumpJellyLandForceMin = 0.75f;

	public float jumpJellyLandForceMax = 1.4f;

	[Header("Ground")]
	public LayerMask groundMask;

	public float groundRadius = 0.31f;

	public float groundedContactNormalMinimum = 0.25f;

	public float groundedRefreshTime = 0.1f;

	public float groundedDisableAfterJump = 0.14f;

	[Header("Impact Damage")]
	public float impactDamageTime = 2f;

	[Header("Upright")]
	public float uprightTorque = 18f;

	public float uprightDamping = 4f;

	public float uprightTorqueMaximum = 24f;

	[Range(0f, 1f)]
	public float uprightAirMultiplier = 0.3f;

	[Header("Held Panic")]
	public float heldPanicChangeTimeMin = 0.11f;

	public float heldPanicChangeTimeMax = 0.18f;

	public float heldPanicTorqueMin = 45f;

	public float heldPanicTorqueMax = 80f;

	public float heldPanicForceMin = 2.5f;

	public float heldPanicForceMax = 5.5f;

	public float heldPanicAngularVelocityMaximum = 10f;

	public float heldPanicVisualChangeTimeMin = 0.22f;

	public float heldPanicVisualChangeTimeMax = 0.4f;

	public float heldPanicBoneForceMin = 18f;

	public float heldPanicBoneForceMax = 30f;

	public float heldPanicSpringSpeed = 8f;

	public float heldPanicSpringDamping = 0.32f;

	public float heldPanicPoseMotionSpeed = 1.35f;

	public float heldPanicSRootMultiplier = 0.55f;

	public float heldPanicSMiddleMultiplier = 1.9f;

	public float heldPanicSTipMultiplier = 2.8f;

	public float heldPanicSPlaneMix = 0.6f;

	public float heldPanicSoundFadeSpeed = 20f;

	public float heldPukeDelayMin = 0.35f;

	public float heldPukeDelayMax = 0.9f;

	public float heldPukeBurstTimeMin = 0.18f;

	public float heldPukeBurstTimeMax = 0.42f;

	[Header("BotLimb Poses")]
	public float idlePoseBlendTime = 0.3f;

	public float jumpPoseBlendTime = 0.16f;

	public float idlePoseMotionSpeed = 1f;

	public float targetLookPoseMotionSpeed = 0.55f;

	public float jumpChargeSquirmPoseMotionSpeed = 0.25f;

	public float lungeTellPoseMotionSpeed = 2.4f;

	public float jumpPoseMotionSpeed = 1.35f;

	public float hurtTime = 0.5f;

	public float hurtSpringForceMin = 0.8f;

	public float hurtSpringForceMax = 2.2f;

	public float hurtSpringSpeed = 32f;

	public float hurtSpringDamping = 0.45f;

	[HideInInspector]
	public State currentState;

	[HideInInspector]
	public Vector3 spawnPosition;

	private readonly Collider[] groundColliders = new Collider[16];

	private PlayerAvatar playerTarget;

	private int playerTargetViewID;

	private Vector3 hopTargetPosition;

	private Vector3 playerTargetPosition;

	private float stateTimer;

	private float stateTimerMax;

	private float stateGroundedTimer;

	private float attackCooldownTimer;

	private float visionCheckTimer;

	private float impactDamageTimer;

	private float groundedTimer;

	private float groundedDisableTimer;

	private float dormantCheckTimer;

	private float movementSquirtLandCooldownTimer;

	private float movementLandTimer;

	private float playerLookYaw;

	private float playerLookYawVelocity;

	private float playerLookPitch;

	private float playerLookPitchVelocity;

	private float heldPanicVisualTimer;

	private float heldPanicPhysicsTimer;

	private float soundLoopPitchNoiseOffset;

	private Vector3 heldPanicTorqueDirection;

	private Vector3 heldPanicForceDirection;

	private float heldPanicTorqueStrength;

	private float heldPanicForceStrength;

	private float heldPanicSPhase = 1f;

	private float heldPanicAngularVelocityOriginal = -1f;

	private bool stateImpulse = true;

	private Quaternion[] jumpChargePoseOriginalBoneRotations;

	private Quaternion[] jumpChargePoseOriginalIdleRotations;

	private float[] jumpChargePoseOriginalCurveOffsets;

	private float jumpChargePoseOriginalSpringSpeed;

	private float jumpChargePoseOriginalSpringDamping;

	private float jumpChargePoseOriginalIdleSpeed;

	private bool jumpChargePoseOriginalLoop;

	private bool jumpChargePoseOverrideApplied;

	private void Awake()
	{
		//IL_00e9: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ee: Unknown result type (might be due to invalid IL or missing references)
		//IL_0138: Unknown result type (might be due to invalid IL or missing references)
		//IL_012b: Unknown result type (might be due to invalid IL or missing references)
		//IL_013d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0144: Unknown result type (might be due to invalid IL or missing references)
		//IL_0149: Unknown result type (might be due to invalid IL or missing references)
		//IL_019d: Unknown result type (might be due to invalid IL or missing references)
		//IL_01a7: Expected Obj, but got Unknown
		//IL_01b9: Unknown result type (might be due to invalid IL or missing references)
		//IL_01c3: Expected Obj, but got Unknown
		//IL_01d5: Unknown result type (might be due to invalid IL or missing references)
		//IL_01df: Expected Obj, but got Unknown
		if (!Object.op_Implicit((Object)(object)physGrabObject))
		{
			physGrabObject = ((Component)this).GetComponent<PhysGrabObject>();
		}
		if (!Object.op_Implicit((Object)(object)impactDetector))
		{
			impactDetector = ((Component)this).GetComponent<PhysGrabObjectImpactDetector>();
		}
		if (!Object.op_Implicit((Object)(object)health))
		{
			health = ((Component)this).GetComponent<NotValuableObject>();
		}
		if (!Object.op_Implicit((Object)(object)rb))
		{
			rb = ((Component)this).GetComponent<Rigidbody>();
		}
		if (!Object.op_Implicit((Object)(object)groundCheckTransform))
		{
			groundCheckTransform = ((Component)this).transform;
		}
		if (!Object.op_Implicit((Object)(object)visionTransform))
		{
			visionTransform = ((Component)this).transform;
		}
		if (!Object.op_Implicit((Object)(object)mouthTransform))
		{
			mouthTransform = ((Component)this).transform;
		}
		if (!Object.op_Implicit((Object)(object)headTransform) && Object.op_Implicit((Object)(object)visionTransform))
		{
			headTransform = visionTransform.parent;
		}
		if (groundMask.value == 0)
		{
			groundMask = GroundMaskDefaultGet();
		}
		LarvaPoseSetup();
		soundLoopPitchNoiseOffset = Mathf.Abs(((Object)this).GetInstanceID() % 997);
		SoundPitchApply();
		spawnPosition = (Object.op_Implicit((Object)(object)rb) ? rb.position : ((Component)this).transform.position);
		playerTargetPosition = spawnPosition;
		currentState = State.Spawn;
		stateImpulse = true;
		stateTimer = 0f;
		stateTimerMax = 0f;
		AttackDelaySet(attackCooldownOnSpawn);
		if (Object.op_Implicit((Object)(object)impactDetector))
		{
			impactDetector.onAllBreaks.AddListener((UnityAction)BreakImpact);
			impactDetector.onHurtColliderHit.AddListener((UnityAction)HurtColliderHit);
			impactDetector.onDestroy.AddListener((UnityAction)DestroyEffectsPlay);
		}
		if (Object.op_Implicit((Object)(object)physGrabObject))
		{
			physGrabObject.OverrideIndestructible();
		}
	}

	private void Start()
	{
		StatePresentationApply(currentState, 0f);
	}

	private void Update()
	{
		DormancyTick();
		StateInterruptionTick();
		if (currentState == State.Dormant)
		{
			StateDormant();
			return;
		}
		ImpactDamageTick();
		TimersTick();
		StateMachine();
		MovementLandTick();
		HeldPanicTick();
		SoundLoopPitchTick();
		PoseMotionTick();
	}

	private void LateUpdate()
	{
		if (currentState != State.Dormant)
		{
			PlayerLookTick();
		}
	}

	private void FixedUpdate()
	{
		GroundedTick();
		ImpactDamageProtection();
		if (!SemiFunc.IsMasterClientOrSingleplayer())
		{
			HeldPanicPhysicsOverrideRestore();
		}
		else if (!Object.op_Implicit((Object)(object)rb) || rb.isKinematic)
		{
			HeldPanicPhysicsOverrideRestore();
		}
		else if (currentState == State.Dormant)
		{
			HeldPanicPhysicsOverrideRestore();
		}
		else if (PhysGrabbed())
		{
			if (currentState == State.Held || currentState == State.HeldPuke)
			{
				HeldPanicPhysicsOverrideApply();
				StateHeldFixed();
			}
		}
		else
		{
			HeldPanicPhysicsOverrideRestore();
			UprightTorque();
			StateMachineFixed();
		}
	}

	public override void OnDisable()
	{
		((MonoBehaviourPunCallbacks)this).OnDisable();
		HeldPanicAudioStop();
		if (Object.op_Implicit((Object)(object)semiPuke))
		{
			semiPuke.PukeStop();
		}
		HeldPanicPhysicsOverrideRestore();
		JumpChargePoseRestore();
	}

	private void OnDestroy()
	{
		//IL_0049: Unknown result type (might be due to invalid IL or missing references)
		//IL_0053: Expected Obj, but got Unknown
		//IL_0065: Unknown result type (might be due to invalid IL or missing references)
		//IL_006f: Expected Obj, but got Unknown
		//IL_0081: Unknown result type (might be due to invalid IL or missing references)
		//IL_008b: Expected Obj, but got Unknown
		HeldPanicAudioStop();
		if (Object.op_Implicit((Object)(object)semiPuke))
		{
			semiPuke.PukeStop();
		}
		HeldPanicPhysicsOverrideRestore();
		JumpChargePoseRestore();
		if (Object.op_Implicit((Object)(object)impactDetector))
		{
			impactDetector.onAllBreaks.RemoveListener((UnityAction)BreakImpact);
			impactDetector.onHurtColliderHit.RemoveListener((UnityAction)HurtColliderHit);
			impactDetector.onDestroy.RemoveListener((UnityAction)DestroyEffectsPlay);
		}
	}

	private void OnTriggerEnter(Collider _other)
	{
		HurtColliderTrigger(_other);
	}

	private void OnTriggerStay(Collider _other)
	{
		HurtColliderTrigger(_other);
	}

	private void OnCollisionEnter(Collision _collision)
	{
		GroundedCollisionRefresh(_collision);
	}

	private void OnCollisionStay(Collision _collision)
	{
		GroundedCollisionRefresh(_collision);
	}

	public override void OnPlayerEnteredRoom(Player _newPlayer)
	{
		//IL_004a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0058: Unknown result type (might be due to invalid IL or missing references)
		//IL_0066: Unknown result type (might be due to invalid IL or missing references)
		if (PhotonNetwork.IsMasterClient && _newPlayer != null)
		{
			((MonoBehaviourPun)this).photonView.RPC("StateSnapshotRPC", _newPlayer, new object[7]
			{
				(int)currentState,
				stateTimer,
				stateTimerMax,
				spawnPosition,
				hopTargetPosition,
				playerTargetPosition,
				playerTargetViewID
			});
		}
	}

	private void StateMachine()
	{
		switch (currentState)
		{
		case State.Spawn:
			StateSpawn();
			break;
		case State.Idle:
			StateIdle();
			break;
		case State.Targeting:
			StateTargeting();
			break;
		case State.JumpCharge:
			StateJumpCharge();
			break;
		case State.Jump:
			StateJump();
			break;
		case State.JumpLand:
			StateJumpLand();
			break;
		case State.LungeTell:
			StateLungeTell();
			break;
		case State.Lunge:
			StateLunge();
			break;
		case State.Puke:
			StatePuke();
			break;
		case State.Recover:
			StateRecover();
			break;
		case State.Held:
			StateHeld();
			break;
		case State.HeldPuke:
			StateHeldPuke();
			break;
		case State.Hurt:
			StateHurt();
			break;
		case State.Dormant:
			StateDormant();
			break;
		}
	}

	private void StateMachineFixed()
	{
		//IL_0043: Unknown result type (might be due to invalid IL or missing references)
		switch (currentState)
		{
		case State.JumpCharge:
			StateJumpChargeFixed();
			break;
		case State.Targeting:
			StateTargetingFixed();
			break;
		case State.LungeTell:
			StateLungeTellFixed();
			break;
		case State.Lunge:
			TargetFacingTorque(playerTargetPosition);
			break;
		case State.Puke:
			StatePukeFixed();
			break;
		case State.Jump:
		case State.JumpLand:
			break;
		}
	}

	private void StateSpawn()
	{
		if (stateImpulse)
		{
			stateImpulse = false;
			StatePresentationApply(currentState, 0f);
		}
		if (SemiFunc.IsMasterClientOrSingleplayer() && Object.op_Implicit((Object)(object)rb) && !rb.isKinematic && Grounded())
		{
			StateSet(State.Idle);
		}
	}

	private void StateDormant()
	{
		if (stateImpulse)
		{
			stateImpulse = false;
			StatePresentationApply(currentState, idlePoseBlendTime);
			HeldPanicAudioStop();
			if (Object.op_Implicit((Object)(object)semiPuke))
			{
				semiPuke.PukeStop();
			}
			if (SemiFunc.IsMasterClientOrSingleplayer())
			{
				impactDamageTimer = 0f;
				ImpactDamageProtection();
			}
		}
	}

	private void StateIdle()
	{
		//IL_0071: Unknown result type (might be due to invalid IL or missing references)
		//IL_0076: Unknown result type (might be due to invalid IL or missing references)
		if (stateImpulse)
		{
			stateImpulse = false;
			StatePresentationApply(currentState, idlePoseBlendTime);
		}
		if (!SemiFunc.IsMasterClientOrSingleplayer() || !Grounded())
		{
			return;
		}
		if (attackCooldownTimer <= 0f && visionCheckTimer <= 0f)
		{
			if (PlayerTargetFind())
			{
				return;
			}
			AttackDelaySet();
		}
		if (!(stateTimer < stateTimerMax))
		{
			hopTargetPosition = HopTargetPositionGet();
			StateSet(State.JumpCharge);
		}
	}

	private void StateTargeting()
	{
		if (stateImpulse)
		{
			stateImpulse = false;
			StatePresentationApply(currentState, idlePoseBlendTime);
			SoundPlay(soundNotice);
			SoundGnomePlay(soundGnomeNotice);
		}
		if (SemiFunc.IsMasterClientOrSingleplayer())
		{
			PlayerTargetPositionUpdate();
			if (!PlayerTargetValid())
			{
				TargetSet(null);
				StateSet(State.Recover);
			}
		}
	}

	private void StateJumpCharge()
	{
		if (stateImpulse)
		{
			stateImpulse = false;
			JumpChargePoseApply();
			StatePresentationApply(currentState, jumpPoseBlendTime);
			SoundPlay(soundLungeTell);
		}
	}

	private void StateJump()
	{
		if (stateImpulse)
		{
			stateImpulse = false;
			StatePresentationApply(currentState, jumpPoseBlendTime);
			SoundPlay(soundJump);
			SoundGnomePlay(soundGnomeJump);
			MovementSquirtJump();
			JumpJellyImpulse(jumpJellyForceMin, jumpJellyForceMax);
		}
		if (SemiFunc.IsMasterClientOrSingleplayer() && ((Grounded() && stateTimer > groundedDisableAfterJump) || stateTimer >= stateTimerMax))
		{
			StateSet(State.JumpLand);
		}
	}

	private void StateJumpLand()
	{
		if (stateImpulse)
		{
			stateImpulse = false;
			StatePresentationApply(currentState, jumpPoseBlendTime);
			JumpJellyImpulse(jumpJellyLandForceMin, jumpJellyLandForceMax);
			movementSquirtLandCooldownTimer = 0f;
		}
		if (!Grounded())
		{
			stateGroundedTimer = 0f;
			return;
		}
		stateGroundedTimer += Time.deltaTime;
		if (Object.op_Implicit((Object)(object)botLimb) && Object.op_Implicit((Object)(object)idlePose))
		{
			botLimb.BlendToPose(idlePose, jumpLandTime);
		}
		if (SemiFunc.IsMasterClientOrSingleplayer() && !(stateGroundedTimer < jumpLandTime))
		{
			StateSet(State.Idle);
		}
	}

	private void StateLungeTell()
	{
		if (stateImpulse)
		{
			stateImpulse = false;
			StatePresentationApply(currentState, jumpPoseBlendTime);
			SoundPlay(soundLungeTell);
			SoundGnomePlay(soundGnomeLungeTell);
			AttackTellSlither();
		}
		if (SemiFunc.IsMasterClientOrSingleplayer())
		{
			PlayerTargetPositionUpdate();
			if (!PlayerTargetValid())
			{
				TargetSet(null);
				StateSet(State.Recover);
			}
		}
	}

	private void StateLunge()
	{
		if (stateImpulse)
		{
			stateImpulse = false;
			StatePresentationApply(currentState, jumpPoseBlendTime);
			SoundPlay(soundLunge);
			SoundGnomePlay(soundGnomeLunge);
			MovementSquirtJump();
			JumpJellyImpulse(jumpJellyForceMin, jumpJellyForceMax);
		}
		if (SemiFunc.IsMasterClientOrSingleplayer())
		{
			PlayerTargetPositionUpdate();
			if (stateTimer >= stateTimerMax)
			{
				StateSet(State.Puke);
			}
		}
	}

	private void StatePuke()
	{
		//IL_0047: Unknown result type (might be due to invalid IL or missing references)
		//IL_0052: Unknown result type (might be due to invalid IL or missing references)
		if (stateImpulse)
		{
			stateImpulse = false;
			StatePresentationApply(currentState, jumpPoseBlendTime);
		}
		if (Object.op_Implicit((Object)(object)semiPuke) && Object.op_Implicit((Object)(object)mouthTransform))
		{
			semiPuke.PukeActive(mouthTransform.position, mouthTransform.rotation);
		}
		if (SemiFunc.IsMasterClientOrSingleplayer())
		{
			PlayerTargetPositionUpdate();
			if (stateTimer >= stateTimerMax)
			{
				StateSet(State.Recover);
			}
		}
	}

	private void StateRecover()
	{
		if (stateImpulse)
		{
			stateImpulse = false;
			StatePresentationApply(currentState, idlePoseBlendTime);
			if (SemiFunc.IsMasterClientOrSingleplayer())
			{
				TargetSet(null);
				AttackDelaySet(attackCooldownAfterAttack);
			}
		}
		if (!Grounded())
		{
			stateGroundedTimer = 0f;
			return;
		}
		stateGroundedTimer += Time.deltaTime;
		if (SemiFunc.IsMasterClientOrSingleplayer() && !(stateGroundedTimer < stateTimerMax))
		{
			StateSet(State.Idle);
		}
	}

	private void StateHeld()
	{
		if (stateImpulse)
		{
			stateImpulse = false;
			StatePresentationApply(currentState, jumpPoseBlendTime);
			HeldPanicReset();
		}
		if (SemiFunc.IsMasterClientOrSingleplayer())
		{
			if (!PhysGrabbed())
			{
				StateSet(State.Recover);
			}
			else if (!(stateTimer < stateTimerMax))
			{
				StateSet(State.HeldPuke);
			}
		}
	}

	private void StateHeldPuke()
	{
		//IL_0047: Unknown result type (might be due to invalid IL or missing references)
		//IL_0052: Unknown result type (might be due to invalid IL or missing references)
		if (stateImpulse)
		{
			stateImpulse = false;
			StatePresentationApply(currentState, jumpPoseBlendTime);
		}
		if (Object.op_Implicit((Object)(object)semiPuke) && Object.op_Implicit((Object)(object)mouthTransform))
		{
			semiPuke.PukeActive(mouthTransform.position, mouthTransform.rotation);
		}
		if (SemiFunc.IsMasterClientOrSingleplayer())
		{
			if (!PhysGrabbed())
			{
				StateSet(State.Recover);
			}
			else if (!(stateTimer < stateTimerMax))
			{
				StateSet(State.Held);
			}
		}
	}

	private void StateHurt()
	{
		if (stateImpulse)
		{
			stateImpulse = false;
			StatePresentationApply(currentState, jumpPoseBlendTime);
			SoundPlay(soundHurt);
			SoundGnomePlay(soundGnomeHurt);
			if (Object.op_Implicit((Object)(object)botLimb))
			{
				botLimb.SetTempSpeedAndDampingOnAllBones(hurtSpringSpeed, hurtSpringDamping, hurtTime);
				botLimb.SetRandomForceOnAllBones(hurtSpringForceMin, hurtSpringForceMax);
			}
		}
		if (SemiFunc.IsMasterClientOrSingleplayer() && !(stateTimer < stateTimerMax))
		{
			StateSet(State.Recover);
		}
	}

	private void StateJumpChargeFixed()
	{
		//IL_0034: Unknown result type (might be due to invalid IL or missing references)
		if (!Grounded())
		{
			if (stateTimer > 0.08f)
			{
				StateSet(State.Jump);
			}
			return;
		}
		JumpChargeRotationDamping();
		if (!(stateTimer < stateTimerMax))
		{
			JumpImpulse(hopTargetPosition, jumpHorizontalVelocity, jumpUpVelocity, jumpAngularVelocity);
			StateSet(State.Jump);
		}
	}

	private void StateTargetingFixed()
	{
		//IL_0020: Unknown result type (might be due to invalid IL or missing references)
		//IL_0053: Unknown result type (might be due to invalid IL or missing references)
		if (!PlayerTargetValid())
		{
			TargetSet(null);
			StateSet(State.Recover);
			return;
		}
		PlayerTargetPositionUpdate();
		TargetFacingTorque(playerTargetPosition);
		if (!Grounded())
		{
			TargetSet(null);
			StateSet(State.Recover);
		}
		else if (!(stateTimer < stateTimerMax) && TargetFacingAngleGet(playerTargetPosition) <= targetLookFacingAngle)
		{
			StateSet(State.LungeTell);
		}
	}

	private void StateLungeTellFixed()
	{
		//IL_0020: Unknown result type (might be due to invalid IL or missing references)
		//IL_004c: Unknown result type (might be due to invalid IL or missing references)
		if (!PlayerTargetValid())
		{
			TargetSet(null);
			StateSet(State.Recover);
			return;
		}
		PlayerTargetPositionUpdate();
		TargetFacingTorque(playerTargetPosition);
		if (!Grounded())
		{
			StateSet(State.Recover);
		}
		else if (!(stateTimer < stateTimerMax))
		{
			JumpImpulse(playerTargetPosition, lungeHorizontalVelocity, lungeUpVelocity, lungeAngularVelocity);
			StateSet(State.Lunge);
		}
	}

	private void StatePukeFixed()
	{
		//IL_0002: Unknown result type (might be due to invalid IL or missing references)
		//IL_0019: Unknown result type (might be due to invalid IL or missing references)
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_0029: Unknown result type (might be due to invalid IL or missing references)
		//IL_0030: Unknown result type (might be due to invalid IL or missing references)
		//IL_0035: Unknown result type (might be due to invalid IL or missing references)
		//IL_0040: Unknown result type (might be due to invalid IL or missing references)
		//IL_0045: Unknown result type (might be due to invalid IL or missing references)
		//IL_004c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0052: Unknown result type (might be due to invalid IL or missing references)
		//IL_0063: Unknown result type (might be due to invalid IL or missing references)
		//IL_0069: Unknown result type (might be due to invalid IL or missing references)
		TargetFacingTorque(playerTargetPosition);
		if (Object.op_Implicit((Object)(object)mouthTransform))
		{
			Vector3 val = Random.insideUnitSphere * pukeRandomTorque;
			Vector3 val2 = -mouthTransform.forward * pukeRecoil;
			rb.AddTorque(val * Time.fixedDeltaTime, (ForceMode)0);
			rb.AddForce(val2 * Time.fixedDeltaTime, (ForceMode)0);
		}
	}

	private void StateHeldFixed()
	{
		//IL_0088: Unknown result type (might be due to invalid IL or missing references)
		//IL_008d: Unknown result type (might be due to invalid IL or missing references)
		//IL_008f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0094: Unknown result type (might be due to invalid IL or missing references)
		//IL_0044: Unknown result type (might be due to invalid IL or missing references)
		//IL_0049: Unknown result type (might be due to invalid IL or missing references)
		//IL_004f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0054: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e8: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f9: Unknown result type (might be due to invalid IL or missing references)
		//IL_0104: Unknown result type (might be due to invalid IL or missing references)
		//IL_0115: Unknown result type (might be due to invalid IL or missing references)
		//IL_011c: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a9: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ae: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b4: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b9: Unknown result type (might be due to invalid IL or missing references)
		//IL_00be: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c1: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c6: Unknown result type (might be due to invalid IL or missing references)
		if (heldPanicPhysicsTimer > 0f)
		{
			heldPanicPhysicsTimer -= Time.fixedDeltaTime;
		}
		if (heldPanicPhysicsTimer <= 0f)
		{
			heldPanicPhysicsTimer = Random.Range(heldPanicChangeTimeMin, heldPanicChangeTimeMax);
			heldPanicTorqueDirection = Random.onUnitSphere;
			heldPanicForceDirection = Random.onUnitSphere;
			heldPanicTorqueStrength = Random.Range(heldPanicTorqueMin, heldPanicTorqueMax);
			heldPanicForceStrength = Random.Range(heldPanicForceMin, heldPanicForceMax);
		}
		Vector3 normalized = heldPanicForceDirection;
		Vector3 val = HeldPanicAwayDirectionGet();
		if (val.sqrMagnitude > 0.001f)
		{
			Vector3 val2 = normalized * 0.65f + val * 0.35f;
			normalized = val2.normalized;
		}
		rb.angularVelocity = Vector3.ClampMagnitude(rb.angularVelocity, Mathf.Max(0f, heldPanicAngularVelocityMaximum));
		rb.AddTorque(heldPanicTorqueDirection * heldPanicTorqueStrength, (ForceMode)5);
		rb.AddForce(normalized * heldPanicForceStrength, (ForceMode)5);
	}

	private void StateSet(State _state)
	{
		//IL_0050: Unknown result type (might be due to invalid IL or missing references)
		//IL_0056: Unknown result type (might be due to invalid IL or missing references)
		if (SemiFunc.IsMasterClientOrSingleplayer() && currentState != _state)
		{
			float num = StateDurationGet(_state);
			if (SemiFunc.IsMultiplayer())
			{
				((MonoBehaviourPun)this).photonView.RPC("StateSetRPC", (RpcTarget)0, new object[2]
				{
					(int)_state,
					num
				});
			}
			else
			{
				StateSetRPC((int)_state, num);
			}
		}
	}

	private float StateDurationGet(State _state)
	{
		return _state switch
		{
			State.Idle => Random.Range(idleHopDelayMin, idleHopDelayMax), 
			State.Targeting => targetLookTime, 
			State.JumpCharge => Mathf.Max(1f, jumpChargeTime), 
			State.Jump => jumpMaximumTime, 
			State.JumpLand => jumpLandTime, 
			State.LungeTell => lungeTellTime, 
			State.Lunge => lungePukeDelay, 
			State.Puke => pukeTime, 
			State.Recover => recoverTime, 
			State.Held => Random.Range(heldPukeDelayMin, heldPukeDelayMax), 
			State.HeldPuke => Random.Range(heldPukeBurstTimeMin, heldPukeBurstTimeMax), 
			State.Hurt => hurtTime, 
			_ => 0f, 
		};
	}

	[PunRPC]
	private void StateSetRPC(int _state, float _duration, PhotonMessageInfo _info = default(PhotonMessageInfo))
	{
		//IL_0000: Unknown result type (might be due to invalid IL or missing references)
		if (!SemiFunc.MasterOnlyRPC(_info) || _state < 0 || _state > 13)
		{
			return;
		}
		if (currentState != (State)_state)
		{
			if (currentState == State.JumpCharge)
			{
				JumpChargePoseRestore();
			}
			if ((currentState == State.Puke || currentState == State.HeldPuke) && Object.op_Implicit((Object)(object)semiPuke))
			{
				semiPuke.PukeStop();
			}
			currentState = (State)_state;
			stateTimer = 0f;
			stateTimerMax = Mathf.Max(0f, _duration);
			stateGroundedTimer = 0f;
			stateImpulse = true;
		}
	}

	[PunRPC]
	private void StateSnapshotRPC(int _state, float _stateTimer, float _stateTimerMax, Vector3 _spawnPosition, Vector3 _hopTargetPosition, Vector3 _playerTargetPosition, int _playerTargetViewID, PhotonMessageInfo _info = default(PhotonMessageInfo))
	{
		//IL_0000: Unknown result type (might be due to invalid IL or missing references)
		//IL_0088: Unknown result type (might be due to invalid IL or missing references)
		//IL_008a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0090: Unknown result type (might be due to invalid IL or missing references)
		//IL_0092: Unknown result type (might be due to invalid IL or missing references)
		//IL_0098: Unknown result type (might be due to invalid IL or missing references)
		//IL_009a: Unknown result type (might be due to invalid IL or missing references)
		if (!SemiFunc.MasterOnlyRPC(_info) || _state < 0 || _state > 13)
		{
			return;
		}
		if (currentState == State.JumpCharge && _state != 3)
		{
			JumpChargePoseRestore();
		}
		if ((currentState == State.Puke || currentState == State.HeldPuke) && Object.op_Implicit((Object)(object)semiPuke))
		{
			semiPuke.PukeStop();
		}
		currentState = (State)_state;
		stateTimerMax = Mathf.Max(0f, _stateTimerMax);
		stateTimer = Mathf.Clamp(_stateTimer, 0f, Mathf.Max(stateTimerMax, _stateTimer));
		spawnPosition = _spawnPosition;
		hopTargetPosition = _hopTargetPosition;
		playerTargetPosition = _playerTargetPosition;
		playerTargetViewID = _playerTargetViewID;
		playerTarget = PlayerTargetResolve(playerTargetViewID);
		stateGroundedTimer = 0f;
		stateImpulse = false;
		if (currentState == State.JumpCharge)
		{
			JumpChargePoseApply();
		}
		StatePresentationApply(currentState, 0.1f);
		if (currentState == State.Dormant)
		{
			HeldPanicAudioStop();
			if (Object.op_Implicit((Object)(object)semiPuke))
			{
				semiPuke.PukeStop();
			}
		}
	}

	private void TimersTick()
	{
		stateTimer += Time.deltaTime;
		if (attackCooldownTimer > 0f)
		{
			attackCooldownTimer -= Time.deltaTime;
		}
		if (visionCheckTimer > 0f)
		{
			visionCheckTimer -= Time.deltaTime;
		}
		if (movementSquirtLandCooldownTimer > 0f)
		{
			movementSquirtLandCooldownTimer -= Time.deltaTime;
		}
	}

	private void DormancyTick()
	{
		//IL_0088: Unknown result type (might be due to invalid IL or missing references)
		//IL_0090: Unknown result type (might be due to invalid IL or missing references)
		//IL_0096: Unknown result type (might be due to invalid IL or missing references)
		if (!SemiFunc.IsMasterClientOrSingleplayer())
		{
			return;
		}
		dormantCheckTimer = Mathf.Max(0f, dormantCheckTimer - Time.deltaTime);
		if (dormantCheckTimer > 0f)
		{
			return;
		}
		dormantCheckTimer = Mathf.Max(0.1f, dormantCheckTime);
		if (!Object.op_Implicit((Object)(object)GameDirector.instance) || GameDirector.instance.PlayerList == null || PhysGrabbed())
		{
			return;
		}
		float num = Mathf.Max(0f, RenderSettings.fogEndDistance);
		if (num > 0f && Object.op_Implicit((Object)(object)SemiFunc.PlayerGetNearestPlayerAvatarWithinRange(num, ((Component)this).transform.position)))
		{
			if (currentState == State.Dormant)
			{
				StateSet(Grounded() ? State.Idle : State.Recover);
			}
		}
		else if (currentState != State.Dormant)
		{
			TargetSet(null);
			StateSet(State.Dormant);
		}
	}

	private void ImpactDamageTick()
	{
		if (SemiFunc.IsMasterClientOrSingleplayer())
		{
			if (PhysGrabbed())
			{
				ImpactDamageOverride();
			}
			if (impactDamageTimer > 0f)
			{
				impactDamageTimer = Mathf.Max(0f, impactDamageTimer - Time.deltaTime);
			}
			ImpactDamageProtection();
		}
	}

	private void ImpactDamageOverride(float _time = -1f)
	{
		if (SemiFunc.IsMasterClientOrSingleplayer())
		{
			if (_time < 0f)
			{
				_time = impactDamageTime;
			}
			impactDamageTimer = Mathf.Max(impactDamageTimer, _time);
			ImpactDamageProtection();
		}
	}

	private void ImpactDamageProtection()
	{
		if (SemiFunc.IsMasterClientOrSingleplayer() && Object.op_Implicit((Object)(object)physGrabObject) && Object.op_Implicit((Object)(object)impactDetector))
		{
			if (impactDamageTimer > 0f)
			{
				impactDetector.indestructibleSpawnTimer = 0f;
				physGrabObject.ResetIndestructible();
			}
			else
			{
				physGrabObject.OverrideIndestructible();
			}
		}
	}

	private void HurtColliderHit()
	{
		ImpactDamageOverride();
	}

	private void HurtColliderTrigger(Collider _other)
	{
		if (SemiFunc.IsMasterClientOrSingleplayer() && Object.op_Implicit((Object)(object)_other))
		{
			HurtCollider componentInParent = ((Component)_other).GetComponentInParent<HurtCollider>();
			if (Object.op_Implicit((Object)(object)componentInParent) && componentInParent.physLogic && !((Component)componentInParent).transform.IsChildOf(((Component)this).transform) && (!Object.op_Implicit((Object)(object)physGrabObject) || !componentInParent.ignoreObjects.Contains(physGrabObject)))
			{
				ImpactDamageOverride();
			}
		}
	}

	private void StateInterruptionTick()
	{
		if (!SemiFunc.IsMasterClientOrSingleplayer())
		{
			return;
		}
		if (PhysGrabbed())
		{
			if (currentState != State.Held && currentState != State.HeldPuke)
			{
				AttackDelaySet(attackCooldownAfterAttack);
				TargetSet(null);
				StateSet(State.Held);
			}
		}
		else if (currentState == State.Held || currentState == State.HeldPuke)
		{
			StateSet(State.Recover);
		}
	}

	private void AttackDelaySet(float _minimum = 0f)
	{
		float num = Mathf.Max(new float[3] { 0f, targetAttackDelayTimeMin, _minimum });
		float num2 = Mathf.Max(num, targetAttackDelayTimeMax);
		attackCooldownTimer = Random.Range(num, num2);
	}

	private bool PlayerTargetFind()
	{
		//IL_0021: Unknown result type (might be due to invalid IL or missing references)
		//IL_008e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0099: Unknown result type (might be due to invalid IL or missing references)
		//IL_009e: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a8: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ad: Unknown result type (might be due to invalid IL or missing references)
		if (!SemiFunc.IsMasterClientOrSingleplayer())
		{
			return false;
		}
		visionCheckTimer = visionCheckTime;
		List<PlayerAvatar> list = SemiFunc.PlayerGetAllPlayerAvatarWithinRangeAndVision(visionRange, visionTransform.position, physGrabObject);
		float num = float.MaxValue;
		PlayerAvatar playerAvatar = null;
		foreach (PlayerAvatar item in list)
		{
			if (Object.op_Implicit((Object)(object)item) && !item.isDisabled && !item.deadSet && Object.op_Implicit((Object)(object)item.PlayerVisionTarget) && Object.op_Implicit((Object)(object)item.PlayerVisionTarget.VisionTransform))
			{
				Vector3 val = Vector3.ProjectOnPlane(item.PlayerVisionTarget.VisionTransform.position - visionTransform.position, Vector3.up);
				float sqrMagnitude = val.sqrMagnitude;
				if (!(sqrMagnitude <= 0.001f) && !(sqrMagnitude >= num))
				{
					num = sqrMagnitude;
					playerAvatar = item;
				}
			}
		}
		if (!Object.op_Implicit((Object)(object)playerAvatar))
		{
			return false;
		}
		TargetSet(playerAvatar);
		PlayerTargetPositionUpdate();
		StateSet(State.Targeting);
		return true;
	}

	private void TargetSet(PlayerAvatar _player)
	{
		if (!SemiFunc.IsMasterClientOrSingleplayer())
		{
			return;
		}
		if (!SemiFunc.IsMultiplayer())
		{
			if (!((Object)(object)playerTarget == (Object)(object)_player) || playerTargetViewID != 0)
			{
				playerTarget = _player;
				playerTargetViewID = 0;
			}
			return;
		}
		int num = ((Object.op_Implicit((Object)(object)_player) && Object.op_Implicit((Object)(object)_player.photonView)) ? _player.photonView.ViewID : 0);
		if (playerTargetViewID != num)
		{
			((MonoBehaviourPun)this).photonView.RPC("TargetSetRPC", (RpcTarget)0, new object[1] { num });
		}
	}

	[PunRPC]
	private void TargetSetRPC(int _viewID, PhotonMessageInfo _info = default(PhotonMessageInfo))
	{
		//IL_0000: Unknown result type (might be due to invalid IL or missing references)
		if (SemiFunc.MasterOnlyRPC(_info))
		{
			playerTargetViewID = Mathf.Max(0, _viewID);
			playerTarget = PlayerTargetResolve(playerTargetViewID);
		}
	}

	private PlayerAvatar PlayerTargetResolve(int _viewID)
	{
		if (_viewID <= 0)
		{
			return null;
		}
		foreach (PlayerAvatar item in SemiFunc.PlayerGetList())
		{
			if (Object.op_Implicit((Object)(object)item) && Object.op_Implicit((Object)(object)item.photonView) && item.photonView.ViewID == _viewID)
			{
				return item;
			}
		}
		return null;
	}

	private bool PlayerTargetValid()
	{
		if (Object.op_Implicit((Object)(object)playerTarget) && !playerTarget.isDisabled && !playerTarget.deadSet && Object.op_Implicit((Object)(object)playerTarget.PlayerVisionTarget))
		{
			return Object.op_Implicit((Object)(object)playerTarget.PlayerVisionTarget.VisionTransform);
		}
		return false;
	}

	private void PlayerTargetPositionUpdate()
	{
		//IL_0021: Unknown result type (might be due to invalid IL or missing references)
		//IL_0026: Unknown result type (might be due to invalid IL or missing references)
		if (SemiFunc.IsMasterClientOrSingleplayer() && PlayerTargetValid())
		{
			playerTargetPosition = playerTarget.PlayerVisionTarget.VisionTransform.position;
		}
	}

	private bool PlayerTargetVisualPositionGet(out Vector3 _position)
	{
		//IL_004f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0054: Unknown result type (might be due to invalid IL or missing references)
		//IL_0032: Unknown result type (might be due to invalid IL or missing references)
		//IL_0037: Unknown result type (might be due to invalid IL or missing references)
		if (!Object.op_Implicit((Object)(object)playerTarget) && playerTargetViewID > 0)
		{
			playerTarget = PlayerTargetResolve(playerTargetViewID);
		}
		if (!PlayerTargetValid())
		{
			_position = playerTargetPosition;
			return false;
		}
		_position = playerTarget.PlayerVisionTarget.VisionTransform.position;
		return true;
	}

	private Vector3 HopTargetPositionGet()
	{
		//IL_0000: Unknown result type (might be due to invalid IL or missing references)
		//IL_000b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0010: Unknown result type (might be due to invalid IL or missing references)
		//IL_0012: Unknown result type (might be due to invalid IL or missing references)
		//IL_0017: Unknown result type (might be due to invalid IL or missing references)
		//IL_0022: Unknown result type (might be due to invalid IL or missing references)
		//IL_0028: Unknown result type (might be due to invalid IL or missing references)
		//IL_002d: Unknown result type (might be due to invalid IL or missing references)
		Vector2 val = Random.insideUnitCircle * spawnRadius;
		return spawnPosition + new Vector3(val.x, 0f, val.y);
	}

	private void JumpImpulse(Vector3 _targetPosition, float _horizontalVelocity, float _upVelocity, float _angularVelocity)
	{
		//IL_0000: Unknown result type (might be due to invalid IL or missing references)
		//IL_0007: Unknown result type (might be due to invalid IL or missing references)
		//IL_000c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0011: Unknown result type (might be due to invalid IL or missing references)
		//IL_0016: Unknown result type (might be due to invalid IL or missing references)
		//IL_001b: Unknown result type (might be due to invalid IL or missing references)
		//IL_001e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0023: Unknown result type (might be due to invalid IL or missing references)
		//IL_0038: Unknown result type (might be due to invalid IL or missing references)
		//IL_003d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0042: Unknown result type (might be due to invalid IL or missing references)
		//IL_0047: Unknown result type (might be due to invalid IL or missing references)
		//IL_004a: Unknown result type (might be due to invalid IL or missing references)
		//IL_004f: Unknown result type (might be due to invalid IL or missing references)
		//IL_006a: Unknown result type (might be due to invalid IL or missing references)
		//IL_006f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0088: Unknown result type (might be due to invalid IL or missing references)
		//IL_005e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0063: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a7: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b5: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ba: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c0: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c5: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d0: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d5: Unknown result type (might be due to invalid IL or missing references)
		//IL_00da: Unknown result type (might be due to invalid IL or missing references)
		//IL_00df: Unknown result type (might be due to invalid IL or missing references)
		//IL_00fb: Unknown result type (might be due to invalid IL or missing references)
		//IL_00fe: Unknown result type (might be due to invalid IL or missing references)
		Vector3 val = Vector3.ProjectOnPlane(_targetPosition - rb.position, Vector3.up);
		Vector3 val2 = val.normalized;
		if (val2.sqrMagnitude < 0.001f)
		{
			val = Vector3.ProjectOnPlane(((Component)this).transform.forward, Vector3.up);
			val2 = val.normalized;
		}
		if (val2.sqrMagnitude < 0.001f)
		{
			val2 = Vector3.forward;
		}
		Vector3 linearVelocity = rb.linearVelocity;
		linearVelocity.x = 0f;
		linearVelocity.z = 0f;
		if (linearVelocity.y < 0f)
		{
			linearVelocity.y = 0f;
		}
		rb.linearVelocity = linearVelocity;
		rb.AddForce(val2 * _horizontalVelocity + Vector3.up * _upVelocity, (ForceMode)2);
		Vector3 val3 = Vector3.ProjectOnPlane(Random.insideUnitSphere, Vector3.up);
		if (val3.sqrMagnitude > 0.001f)
		{
			val3.Normalize();
		}
		rb.AddTorque(val3 * _angularVelocity, (ForceMode)2);
		groundedTimer = 0f;
		groundedDisableTimer = groundedDisableAfterJump;
	}

	private float TargetFacingAngleGet(Vector3 _targetPosition)
	{
		//IL_0000: Unknown result type (might be due to invalid IL or missing references)
		//IL_0007: Unknown result type (might be due to invalid IL or missing references)
		//IL_000c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0011: Unknown result type (might be due to invalid IL or missing references)
		//IL_0016: Unknown result type (might be due to invalid IL or missing references)
		//IL_001b: Unknown result type (might be due to invalid IL or missing references)
		//IL_001e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0023: Unknown result type (might be due to invalid IL or missing references)
		//IL_002a: Unknown result type (might be due to invalid IL or missing references)
		//IL_002f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0034: Unknown result type (might be due to invalid IL or missing references)
		//IL_0039: Unknown result type (might be due to invalid IL or missing references)
		//IL_003c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0041: Unknown result type (might be due to invalid IL or missing references)
		//IL_0064: Unknown result type (might be due to invalid IL or missing references)
		//IL_0065: Unknown result type (might be due to invalid IL or missing references)
		//IL_0066: Unknown result type (might be due to invalid IL or missing references)
		Vector3 val = Vector3.ProjectOnPlane(_targetPosition - rb.position, Vector3.up);
		Vector3 normalized = val.normalized;
		val = Vector3.ProjectOnPlane(((Component)this).transform.forward, Vector3.up);
		Vector3 normalized2 = val.normalized;
		if (normalized.sqrMagnitude < 0.001f || normalized2.sqrMagnitude < 0.001f)
		{
			return 180f;
		}
		return Mathf.Abs(Vector3.SignedAngle(normalized2, normalized, Vector3.up));
	}

	private void TargetFacingTorque(Vector3 _targetPosition)
	{
		//IL_0000: Unknown result type (might be due to invalid IL or missing references)
		//IL_0007: Unknown result type (might be due to invalid IL or missing references)
		//IL_000c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0011: Unknown result type (might be due to invalid IL or missing references)
		//IL_0016: Unknown result type (might be due to invalid IL or missing references)
		//IL_001b: Unknown result type (might be due to invalid IL or missing references)
		//IL_001e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0023: Unknown result type (might be due to invalid IL or missing references)
		//IL_002a: Unknown result type (might be due to invalid IL or missing references)
		//IL_002f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0034: Unknown result type (might be due to invalid IL or missing references)
		//IL_0039: Unknown result type (might be due to invalid IL or missing references)
		//IL_003c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0041: Unknown result type (might be due to invalid IL or missing references)
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0060: Unknown result type (might be due to invalid IL or missing references)
		//IL_0061: Unknown result type (might be due to invalid IL or missing references)
		//IL_008b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0091: Unknown result type (might be due to invalid IL or missing references)
		Vector3 val = Vector3.ProjectOnPlane(_targetPosition - rb.position, Vector3.up);
		Vector3 normalized = val.normalized;
		val = Vector3.ProjectOnPlane(((Component)this).transform.forward, Vector3.up);
		Vector3 normalized2 = val.normalized;
		if (!(normalized.sqrMagnitude < 0.001f) && !(normalized2.sqrMagnitude < 0.001f))
		{
			float num = Mathf.Clamp(Vector3.SignedAngle(normalized2, normalized, Vector3.up) * turnTorque, 0f - turnTorqueMaximum, turnTorqueMaximum);
			rb.AddTorque(Vector3.up * num, (ForceMode)0);
		}
	}

	private void JumpChargeRotationDamping()
	{
		//IL_000c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0011: Unknown result type (might be due to invalid IL or missing references)
		//IL_001c: Unknown result type (might be due to invalid IL or missing references)
		rb.AddTorque(-rb.angularVelocity * jumpChargeYawDamping, (ForceMode)5);
	}

	private void UprightTorque()
	{
		//IL_0006: Unknown result type (might be due to invalid IL or missing references)
		//IL_000b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0010: Unknown result type (might be due to invalid IL or missing references)
		//IL_0015: Unknown result type (might be due to invalid IL or missing references)
		//IL_0016: Unknown result type (might be due to invalid IL or missing references)
		//IL_0017: Unknown result type (might be due to invalid IL or missing references)
		//IL_0022: Unknown result type (might be due to invalid IL or missing references)
		//IL_0027: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a4: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a9: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ae: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b3: Unknown result type (might be due to invalid IL or missing references)
		//IL_0030: Unknown result type (might be due to invalid IL or missing references)
		//IL_0031: Unknown result type (might be due to invalid IL or missing references)
		//IL_0036: Unknown result type (might be due to invalid IL or missing references)
		//IL_003b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0088: Unknown result type (might be due to invalid IL or missing references)
		//IL_0098: Unknown result type (might be due to invalid IL or missing references)
		//IL_009d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0051: Unknown result type (might be due to invalid IL or missing references)
		//IL_0056: Unknown result type (might be due to invalid IL or missing references)
		//IL_005b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0060: Unknown result type (might be due to invalid IL or missing references)
		//IL_0065: Unknown result type (might be due to invalid IL or missing references)
		//IL_006a: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d5: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d6: Unknown result type (might be due to invalid IL or missing references)
		//IL_00dd: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e2: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e7: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e9: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f1: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f6: Unknown result type (might be due to invalid IL or missing references)
		//IL_00fe: Unknown result type (might be due to invalid IL or missing references)
		//IL_0102: Unknown result type (might be due to invalid IL or missing references)
		//IL_007a: Unknown result type (might be due to invalid IL or missing references)
		//IL_007f: Unknown result type (might be due to invalid IL or missing references)
		Vector3 val = rb.rotation * Vector3.up;
		float num = Vector3.Angle(val, Vector3.up);
		Vector3 val2 = Vector3.zero;
		if (num > 0.01f)
		{
			Vector3 val3 = Vector3.Cross(val, Vector3.up);
			if (val3.sqrMagnitude <= 0.001f)
			{
				val3 = Vector3.ProjectOnPlane(rb.rotation * Vector3.forward, Vector3.up);
				if (val3.sqrMagnitude <= 0.001f)
				{
					val3 = Vector3.right;
				}
			}
			val3.Normalize();
			val2 = val3 * (num * (MathF.PI / 180f) * uprightTorque);
		}
		Vector3 val4 = Vector3.ProjectOnPlane(rb.angularVelocity, Vector3.up);
		float num2 = (Grounded() ? 1f : Mathf.Max(0.65f, uprightAirMultiplier));
		Vector3 val5 = val2 - val4 * uprightDamping;
		val5 = Vector3.ClampMagnitude(val5, uprightTorqueMaximum);
		rb.AddTorque(val5 * num2, (ForceMode)5);
	}

	private void GroundedTick()
	{
		//IL_006a: Unknown result type (might be due to invalid IL or missing references)
		//IL_005d: Unknown result type (might be due to invalid IL or missing references)
		//IL_007c: Unknown result type (might be due to invalid IL or missing references)
		if (groundedTimer > 0f)
		{
			groundedTimer -= Time.fixedDeltaTime;
		}
		if (groundedDisableTimer > 0f)
		{
			groundedDisableTimer -= Time.fixedDeltaTime;
			groundedTimer = 0f;
			return;
		}
		int num = Physics.OverlapSphereNonAlloc(Object.op_Implicit((Object)(object)groundCheckTransform) ? groundCheckTransform.position : ((Component)this).transform.position, groundRadius, groundColliders, LayerMask.op_Implicit(groundMask), (QueryTriggerInteraction)1);
		for (int i = 0; i < num; i++)
		{
			Collider val = groundColliders[i];
			groundColliders[i] = null;
			if (Object.op_Implicit((Object)(object)val) && !((Object)(object)val.attachedRigidbody == (Object)(object)rb) && !((Object)(object)((Component)val).transform == (Object)(object)((Component)this).transform) && !((Component)val).transform.IsChildOf(((Component)this).transform))
			{
				groundedTimer = groundedRefreshTime;
				break;
			}
		}
	}

	private void GroundedCollisionRefresh(Collision _collision)
	{
		//IL_0017: Unknown result type (might be due to invalid IL or missing references)
		//IL_001c: Unknown result type (might be due to invalid IL or missing references)
		//IL_001f: Unknown result type (might be due to invalid IL or missing references)
		if (groundedDisableTimer > 0f || _collision == null)
		{
			return;
		}
		for (int i = 0; i < _collision.contactCount; i++)
		{
			ContactPoint contact = _collision.GetContact(i);
			if (!(contact.normal.y < groundedContactNormalMinimum) && (!Object.op_Implicit((Object)(object)contact.otherCollider) || !((Object)(object)contact.otherCollider.attachedRigidbody == (Object)(object)rb)))
			{
				groundedTimer = groundedRefreshTime;
				break;
			}
		}
	}

	private LayerMask GroundMaskDefaultGet()
	{
		//IL_0033: Unknown result type (might be due to invalid IL or missing references)
		return LayerMask.op_Implicit(LayerMask.GetMask(new string[5] { "Default", "StaticGrabObject", "PhysGrabObject", "PhysGrabObjectCart", "PhysGrabObjectHinge" }));
	}

	private bool Grounded()
	{
		if (groundedDisableTimer <= 0f)
		{
			return groundedTimer > 0f;
		}
		return false;
	}

	private void HeldPanicReset()
	{
		heldPanicPhysicsTimer = 0f;
	}

	private void HeldPanicPhysicsOverrideApply()
	{
		if (Object.op_Implicit((Object)(object)rb))
		{
			if (heldPanicAngularVelocityOriginal < 0f)
			{
				heldPanicAngularVelocityOriginal = rb.maxAngularVelocity;
			}
			rb.maxAngularVelocity = Mathf.Max(0.01f, heldPanicAngularVelocityMaximum);
		}
	}

	private void HeldPanicPhysicsOverrideRestore()
	{
		if (!(heldPanicAngularVelocityOriginal < 0f))
		{
			if (Object.op_Implicit((Object)(object)rb))
			{
				rb.maxAngularVelocity = heldPanicAngularVelocityOriginal;
			}
			heldPanicAngularVelocityOriginal = -1f;
		}
	}

	private void HeldPanicTick()
	{
		if (currentState != State.Held && currentState != State.HeldPuke)
		{
			HeldPanicAudioTick(_active: false);
			heldPanicVisualTimer = 0f;
		}
		else
		{
			HeldPanicBotLimbTick();
			HeldPanicAudioTick(_active: true);
		}
	}

	private void HeldPanicBotLimbTick()
	{
		if (Object.op_Implicit((Object)(object)botLimb) && botLimb.bones != null)
		{
			botLimb.CullingVisualOverride(0.1f);
			botLimb.SetTempSpeedAndDampingOnAllBones(heldPanicSpringSpeed, heldPanicSpringDamping);
			if (heldPanicVisualTimer > 0f)
			{
				heldPanicVisualTimer -= Time.deltaTime;
				return;
			}
			heldPanicVisualTimer = Random.Range(heldPanicVisualChangeTimeMin, heldPanicVisualChangeTimeMax);
			HeldPanicSImpulse();
		}
	}

	private void HeldPanicSImpulse()
	{
		//IL_004a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0055: Unknown result type (might be due to invalid IL or missing references)
		//IL_005c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0061: Unknown result type (might be due to invalid IL or missing references)
		//IL_0066: Unknown result type (might be due to invalid IL or missing references)
		//IL_006a: Unknown result type (might be due to invalid IL or missing references)
		//IL_006f: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d4: Unknown result type (might be due to invalid IL or missing references)
		//IL_0124: Unknown result type (might be due to invalid IL or missing references)
		//IL_0134: Unknown result type (might be due to invalid IL or missing references)
		int count = botLimb.bones.Count;
		if (count <= 0)
		{
			return;
		}
		int num = (count - 1) / 2;
		float num2 = Random.Range(heldPanicBoneForceMin, heldPanicBoneForceMax);
		float num3 = Mathf.Abs(heldPanicSPlaneMix);
		float num4 = Random.Range(0f - num3, num3);
		Vector3 val = ((Component)this).transform.up + ((Component)this).transform.right * num4;
		Vector3 normalized = val.normalized;
		heldPanicSPhase *= -1f;
		for (int i = 0; i < count; i++)
		{
			BotSystemSpringPoseAnimator.BoneSpring boneSpring = botLimb.bones[i];
			if ((Object)(object)boneSpring?.transform == (Object)null)
			{
				continue;
			}
			int num5 = Mathf.Abs(i - num);
			if (num5 == 0)
			{
				botLimb.SetForceOnBone(boneSpring.transform, Vector3.zero);
				continue;
			}
			float num6 = heldPanicSTipMultiplier;
			if (num5 == 1)
			{
				num6 = heldPanicSRootMultiplier;
			}
			if (num5 == 2)
			{
				num6 = heldPanicSMiddleMultiplier;
			}
			float num7 = ((num5 % 2 == 0) ? (-1f) : 1f);
			botLimb.SetForceOnBone(boneSpring.transform, normalized * (num2 * num6 * num7 * heldPanicSPhase));
		}
	}

	private Vector3 HeldPanicAwayDirectionGet()
	{
		//IL_002c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0032: Unknown result type (might be due to invalid IL or missing references)
		//IL_0037: Unknown result type (might be due to invalid IL or missing references)
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0062: Unknown result type (might be due to invalid IL or missing references)
		//IL_0067: Unknown result type (might be due to invalid IL or missing references)
		//IL_006c: Unknown result type (might be due to invalid IL or missing references)
		//IL_009a: Unknown result type (might be due to invalid IL or missing references)
		//IL_009f: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a2: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a7: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ac: Unknown result type (might be due to invalid IL or missing references)
		//IL_008e: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00bb: Unknown result type (might be due to invalid IL or missing references)
		if (!Object.op_Implicit((Object)(object)physGrabObject) || physGrabObject.playerGrabbing == null || physGrabObject.playerGrabbing.Count == 0)
		{
			return Vector3.zero;
		}
		Vector3 val = Vector3.zero;
		int num = 0;
		foreach (PhysGrabber item in physGrabObject.playerGrabbing)
		{
			if (Object.op_Implicit((Object)(object)item))
			{
				val += item.physGrabPointPullerPosition;
				num++;
			}
		}
		if (num <= 0)
		{
			return Vector3.zero;
		}
		Vector3 val2 = rb.worldCenterOfMass - val / (float)num;
		if (val2.sqrMagnitude <= 0.001f)
		{
			return Vector3.zero;
		}
		return val2.normalized;
	}

	private bool PhysGrabbed()
	{
		if (!Object.op_Implicit((Object)(object)physGrabObject))
		{
			return false;
		}
		if (!physGrabObject.grabbed)
		{
			return physGrabObject.playerGrabbing.Count > 0;
		}
		return true;
	}

	private void BreakImpact()
	{
		if (SemiFunc.IsMasterClientOrSingleplayer() && !PhysGrabbed() && currentState != State.Dormant)
		{
			AttackDelaySet(attackCooldownAfterAttack);
			TargetSet(null);
			StateSet(State.Hurt);
		}
	}

	private void MovementLandTick()
	{
		//IL_00d4: Unknown result type (might be due to invalid IL or missing references)
		//IL_0102: Unknown result type (might be due to invalid IL or missing references)
		switch (currentState)
		{
		default:
			movementLandTimer = 0f;
			break;
		case State.Jump:
		case State.JumpLand:
		case State.Lunge:
		case State.Puke:
		case State.Recover:
		case State.Hurt:
			if (!Grounded())
			{
				movementLandTimer = 0.25f;
			}
			else if (!(movementLandTimer <= 0f))
			{
				movementLandTimer = Mathf.Max(0f, movementLandTimer - Time.deltaTime);
				if (!(movementSquirtLandCooldownTimer > 0f))
				{
					movementLandTimer = 0f;
					movementSquirtLandCooldownTimer = 1f;
					SoundPlay(soundLand);
					SoundGnomePlay(soundGnomeLand);
					GameDirector.instance.CameraShake.ShakeDistance(0.3f, 1f, 3f, ((Component)this).transform.position, 0.05f);
					GameDirector.instance.CameraImpact.ShakeDistance(0.6f, 1f, 3f, ((Component)this).transform.position, 0.05f);
					MovementSquirtLand();
				}
			}
			break;
		}
	}

	private void MovementSquirtJump()
	{
		//IL_0011: Unknown result type (might be due to invalid IL or missing references)
		//IL_0016: Unknown result type (might be due to invalid IL or missing references)
		//IL_001b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0020: Unknown result type (might be due to invalid IL or missing references)
		//IL_0025: Unknown result type (might be due to invalid IL or missing references)
		//IL_0042: Unknown result type (might be due to invalid IL or missing references)
		//IL_0047: Unknown result type (might be due to invalid IL or missing references)
		//IL_0052: Unknown result type (might be due to invalid IL or missing references)
		//IL_0057: Unknown result type (might be due to invalid IL or missing references)
		//IL_0034: Unknown result type (might be due to invalid IL or missing references)
		//IL_0039: Unknown result type (might be due to invalid IL or missing references)
		//IL_003e: Unknown result type (might be due to invalid IL or missing references)
		movementSquirtLandCooldownTimer = 0f;
		Vector3 val = -Vector3.ProjectOnPlane(((Component)this).transform.forward, Vector3.up);
		if (val.sqrMagnitude <= 0.001f)
		{
			val = -Vector3.forward;
		}
		MovementSquirtEmit(val.normalized + Vector3.up * movementSquirtUpward, jumpSquirtParticleCount);
	}

	private void MovementSquirtLand()
	{
		//IL_0006: Unknown result type (might be due to invalid IL or missing references)
		//IL_000b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0010: Unknown result type (might be due to invalid IL or missing references)
		//IL_0015: Unknown result type (might be due to invalid IL or missing references)
		//IL_004f: Unknown result type (might be due to invalid IL or missing references)
		//IL_005a: Unknown result type (might be due to invalid IL or missing references)
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0061: Unknown result type (might be due to invalid IL or missing references)
		//IL_0062: Unknown result type (might be due to invalid IL or missing references)
		//IL_0063: Unknown result type (might be due to invalid IL or missing references)
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_0029: Unknown result type (might be due to invalid IL or missing references)
		//IL_0073: Unknown result type (might be due to invalid IL or missing references)
		//IL_0074: Unknown result type (might be due to invalid IL or missing references)
		//IL_0079: Unknown result type (might be due to invalid IL or missing references)
		//IL_007a: Unknown result type (might be due to invalid IL or missing references)
		Vector3 val = Vector3.ProjectOnPlane(((Component)this).transform.right, Vector3.up);
		if (val.sqrMagnitude <= 0.001f)
		{
			val = Vector3.right;
		}
		val.Normalize();
		int num = Mathf.Max(1, landSquirtParticleCount / 2);
		int num2 = Mathf.Max(0, landSquirtParticleCount - num);
		Vector3 val2 = Vector3.up * movementSquirtUpward;
		MovementSquirtEmit(val + val2, num);
		if (num2 > 0)
		{
			MovementSquirtEmit(-val + val2, num2);
		}
	}

	private void MovementSquirtEmit(Vector3 _direction, int _count)
	{
		//IL_0032: Unknown result type (might be due to invalid IL or missing references)
		//IL_0025: Unknown result type (might be due to invalid IL or missing references)
		//IL_0037: Unknown result type (might be due to invalid IL or missing references)
		//IL_0042: Unknown result type (might be due to invalid IL or missing references)
		//IL_0047: Unknown result type (might be due to invalid IL or missing references)
		//IL_004c: Unknown result type (might be due to invalid IL or missing references)
		//IL_004f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0054: Unknown result type (might be due to invalid IL or missing references)
		//IL_0059: Unknown result type (might be due to invalid IL or missing references)
		//IL_005e: Unknown result type (might be due to invalid IL or missing references)
		//IL_006a: Unknown result type (might be due to invalid IL or missing references)
		//IL_006b: Unknown result type (might be due to invalid IL or missing references)
		if (Object.op_Implicit((Object)(object)movementSquirtParticles) && _count > 0)
		{
			Vector3 val = (Object.op_Implicit((Object)(object)groundCheckTransform) ? groundCheckTransform.position : ((Component)this).transform.position) + Vector3.up * movementSquirtGroundOffset;
			Quaternion val2 = Quaternion.LookRotation(_direction.normalized, Vector3.up);
			((Component)movementSquirtParticles).transform.SetPositionAndRotation(val, val2);
			if (!movementSquirtParticles.isPlaying)
			{
				movementSquirtParticles.Play(true);
			}
			movementSquirtParticles.Emit(_count);
		}
	}

	private void SoundPitchApply()
	{
		SoundPitchApply(soundNotice, _randomPitch: true);
		SoundPitchApply(soundJump, _randomPitch: true);
		SoundPitchApply(soundLand, _randomPitch: true);
		SoundPitchApply(soundLungeTell, _randomPitch: true);
		SoundPitchApply(soundLunge, _randomPitch: true);
		SoundPitchApply(soundHurt, _randomPitch: true);
		SoundPitchApply(soundDestroy, _randomPitch: true);
		SoundPitchApply(soundDestroySplat, _randomPitch: true);
		SoundPitchApply(soundHeldPanicLoop, _randomPitch: false);
		if (Object.op_Implicit((Object)(object)semiPuke))
		{
			SoundPitchApply(semiPuke.soundPukeStart, _randomPitch: true);
			SoundPitchApply(semiPuke.soundPukeEnd, _randomPitch: true);
			SoundPitchApply(semiPuke.soundPukeLoop, _randomPitch: false);
		}
	}

	private void SoundPitchApply(Sound _sound, bool _randomPitch)
	{
		if (_sound != null)
		{
			float num = Mathf.Max(0.01f, soundBakedPitch);
			_sound.Pitch = Mathf.Max(0.01f, soundPitch / num);
			_sound.PitchRandom = (_randomPitch ? Mathf.Max(0f, soundPitchRandom / num) : 0f);
		}
	}

	private void SoundLoopPitchTick()
	{
		if (Object.op_Implicit((Object)(object)semiPuke))
		{
			semiPuke.OverrideSoundPitch(SoundLoopPitchGet(200f));
		}
	}

	private float SoundLoopPitchGet(float _offset)
	{
		float num = Time.time * Mathf.Max(0f, soundLoopPitchNoiseSpeed);
		float num2 = Mathf.PerlinNoise(soundLoopPitchNoiseOffset + _offset, num) * 2f - 1f;
		float num3 = soundPitch + num2 * soundPitchRandom;
		return Mathf.Max(0.01f, num3 / Mathf.Max(0.01f, soundBakedPitch));
	}

	private void HeldPanicAudioTick(bool _active)
	{
		HeldLoopSoundTick(soundHeldPanicLoop, _active, SoundLoopPitchGet(0f), heldPanicSoundFadeSpeed, heldPanicSoundFadeSpeed);
	}

	private void HeldPanicAudioStop()
	{
		SoundLoopStop(soundHeldPanicLoop);
		if (Object.op_Implicit((Object)(object)semiPuke))
		{
			SoundLoopStop(semiPuke.soundPukeLoop);
		}
	}

	private void SoundLoopStop(Sound _sound)
	{
		if (_sound != null && Object.op_Implicit((Object)(object)_sound.Source))
		{
			_sound.Source.Stop();
		}
	}

	private void HeldLoopSoundTick(Sound _sound, bool _active, float _pitch, float _fadeInSpeed, float _fadeOutSpeed)
	{
		if (_sound != null && Object.op_Implicit((Object)(object)_sound.Source) && _sound.Sounds != null && _sound.Sounds.Length != 0)
		{
			_sound.PlayLoop(_active, _fadeInSpeed, _fadeOutSpeed, _pitch);
		}
	}

	private void SoundPlay(Sound _sound)
	{
		if (_sound != null && _sound.Sounds != null && _sound.Sounds.Length != 0)
		{
			Transform followTarget = (Object.op_Implicit((Object)(object)mouthTransform) ? mouthTransform : ((Component)this).transform);
			_sound.Play(followTarget);
		}
	}

	private void SoundGnomePlay(Sound _sound)
	{
		if (_sound != null && _sound.Sounds != null && _sound.Sounds.Length != 0)
		{
			_sound.Pitch = Mathf.Max(0.01f, soundGnomePitch - Random.Range(0f, Mathf.Max(0f, soundGnomePitchRandom)));
			_sound.PitchRandom = 0f;
			Transform followTarget = (Object.op_Implicit((Object)(object)mouthTransform) ? mouthTransform : ((Component)this).transform);
			_sound.Play(followTarget);
		}
	}

	private void DestroyEffectsPlay()
	{
		//IL_0015: Unknown result type (might be due to invalid IL or missing references)
		//IL_001a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0044: Unknown result type (might be due to invalid IL or missing references)
		//IL_0088: Unknown result type (might be due to invalid IL or missing references)
		//IL_01a9: Unknown result type (might be due to invalid IL or missing references)
		//IL_01b0: Unknown result type (might be due to invalid IL or missing references)
		//IL_0115: Unknown result type (might be due to invalid IL or missing references)
		//IL_017b: Unknown result type (might be due to invalid IL or missing references)
		Vector3 position = ((Component)this).transform.TransformPoint(0f, 0.25f, 0f);
		if (soundDestroy != null && soundDestroy.Sounds != null && soundDestroy.Sounds.Length != 0)
		{
			soundDestroy.Play(position);
		}
		if (soundDestroySplat != null && soundDestroySplat.Sounds != null && soundDestroySplat.Sounds.Length != 0)
		{
			soundDestroySplat.Play(position);
		}
		if (soundGnomeDestroy != null && soundGnomeDestroy.Sounds != null && soundGnomeDestroy.Sounds.Length != 0)
		{
			soundGnomeDestroy.Pitch = Mathf.Max(0.01f, soundGnomePitch - Random.Range(0f, Mathf.Max(0f, soundGnomePitchRandom)));
			soundGnomeDestroy.PitchRandom = 0f;
			soundGnomeDestroy.Play(position);
		}
		if ((Object)(object)semiPuke != (Object)null && semiPuke.soundPukeEnd != null && semiPuke.soundPukeEnd.Sounds != null && semiPuke.soundPukeEnd.Sounds.Length != 0)
		{
			semiPuke.soundPukeEnd.Play(position);
		}
		if (Object.op_Implicit((Object)(object)deathPukeParticles))
		{
			deathPukeParticles.Burst(position, ((Component)this).transform.forward);
		}
	}

	private void LarvaPoseSetup()
	{
		//IL_0067: Unknown result type (might be due to invalid IL or missing references)
		//IL_007b: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a5: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b9: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f7: Unknown result type (might be due to invalid IL or missing references)
		//IL_0112: Unknown result type (might be due to invalid IL or missing references)
		//IL_0117: Unknown result type (might be due to invalid IL or missing references)
		//IL_0141: Unknown result type (might be due to invalid IL or missing references)
		//IL_0155: Unknown result type (might be due to invalid IL or missing references)
		//IL_017f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0193: Unknown result type (might be due to invalid IL or missing references)
		//IL_01bd: Unknown result type (might be due to invalid IL or missing references)
		//IL_01d1: Unknown result type (might be due to invalid IL or missing references)
		//IL_0247: Unknown result type (might be due to invalid IL or missing references)
		//IL_024c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0276: Unknown result type (might be due to invalid IL or missing references)
		//IL_027b: Unknown result type (might be due to invalid IL or missing references)
		//IL_02a5: Unknown result type (might be due to invalid IL or missing references)
		//IL_02aa: Unknown result type (might be due to invalid IL or missing references)
		//IL_02c5: Unknown result type (might be due to invalid IL or missing references)
		//IL_02ca: Unknown result type (might be due to invalid IL or missing references)
		//IL_02f4: Unknown result type (might be due to invalid IL or missing references)
		//IL_02f9: Unknown result type (might be due to invalid IL or missing references)
		//IL_0323: Unknown result type (might be due to invalid IL or missing references)
		//IL_0328: Unknown result type (might be due to invalid IL or missing references)
		//IL_0352: Unknown result type (might be due to invalid IL or missing references)
		//IL_0357: Unknown result type (might be due to invalid IL or missing references)
		if (Object.op_Implicit((Object)(object)idlePose))
		{
			idlePose.springSpeedMultiplier = 1f;
			idlePose.springDampingMultiplier = 1f;
			idlePose.idleSpeed = 2f;
			idlePose.loop = true;
			PoseBoneSetup(idlePose, "Larva Tail Main", new Vector3(2.5f, 15f, 0f), new Vector3(-2.5f, -15f, 0f), 1f);
			PoseBoneSetup(idlePose, "Larva Back Main", new Vector3(-4f, -20f, 0f), new Vector3(3.75f, 20f, 0f), 2f / 3f);
			PoseBoneSetup(idlePose, "Larva Middle Back Main", new Vector3(6.25f, 25f, 0f), new Vector3(-5f, -25f, 0f), 0.3333333f);
			PoseBoneSetup(idlePose, "Larva Center Main", Vector3.zero, Vector3.zero, 0f);
			PoseBoneSetup(idlePose, "Larva Middle Front Main", new Vector3(6.25f, 25f, 0f), new Vector3(-5f, -25f, 0f), 0.3333333f);
			PoseBoneSetup(idlePose, "Larva Front Main", new Vector3(-4f, -20f, 0f), new Vector3(3.75f, 20f, 0f), 2f / 3f);
			PoseBoneSetup(idlePose, "Larva Head Main", new Vector3(2.5f, 15f, 0f), new Vector3(-2.5f, -15f, 0f), 1f);
		}
		if (Object.op_Implicit((Object)(object)jumpPose))
		{
			jumpPose.springSpeedMultiplier = 1.35f;
			jumpPose.springDampingMultiplier = 0.82f;
			jumpPose.idleSpeed = 0f;
			jumpPose.loop = false;
			PoseBoneSetup(jumpPose, "Larva Tail Main", new Vector3(26.4f, 8.4f, 0f), Vector3.zero, 1f);
			PoseBoneSetup(jumpPose, "Larva Back Main", new Vector3(-44.4f, -14.4f, 0f), Vector3.zero, 2f / 3f);
			PoseBoneSetup(jumpPose, "Larva Middle Back Main", new Vector3(56.4f, 16.8f, 0f), Vector3.zero, 0.3333333f);
			PoseBoneSetup(jumpPose, "Larva Center Main", Vector3.zero, Vector3.zero, 0f);
			PoseBoneSetup(jumpPose, "Larva Middle Front Main", new Vector3(56.4f, 16.8f, 0f), Vector3.zero, 0.3333333f);
			PoseBoneSetup(jumpPose, "Larva Front Main", new Vector3(-44.4f, -14.4f, 0f), Vector3.zero, 2f / 3f);
			PoseBoneSetup(jumpPose, "Larva Head Main", new Vector3(26.4f, 8.4f, 0f), Vector3.zero, 1f);
		}
	}

	private void JumpChargePoseApply()
	{
		//IL_018f: Unknown result type (might be due to invalid IL or missing references)
		//IL_01a3: Unknown result type (might be due to invalid IL or missing references)
		//IL_01cd: Unknown result type (might be due to invalid IL or missing references)
		//IL_01e1: Unknown result type (might be due to invalid IL or missing references)
		//IL_020b: Unknown result type (might be due to invalid IL or missing references)
		//IL_021f: Unknown result type (might be due to invalid IL or missing references)
		//IL_023a: Unknown result type (might be due to invalid IL or missing references)
		//IL_023f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0269: Unknown result type (might be due to invalid IL or missing references)
		//IL_027d: Unknown result type (might be due to invalid IL or missing references)
		//IL_02a7: Unknown result type (might be due to invalid IL or missing references)
		//IL_02bb: Unknown result type (might be due to invalid IL or missing references)
		//IL_02e5: Unknown result type (might be due to invalid IL or missing references)
		//IL_02f9: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a2: Unknown result type (might be due to invalid IL or missing references)
		//IL_0095: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a7: Unknown result type (might be due to invalid IL or missing references)
		//IL_00cd: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c0: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d2: Unknown result type (might be due to invalid IL or missing references)
		if (!jumpChargePoseOverrideApplied && Object.op_Implicit((Object)(object)idlePose) && (!Object.op_Implicit((Object)(object)jumpChargePose) || !((Object)(object)jumpChargePose != (Object)(object)jumpPose)))
		{
			int count = idlePose.boneOffsets.Count;
			jumpChargePoseOriginalBoneRotations = new Quaternion[count];
			jumpChargePoseOriginalIdleRotations = new Quaternion[count];
			jumpChargePoseOriginalCurveOffsets = new float[count];
			for (int i = 0; i < count; i++)
			{
				BotSystemSpringPoseAnimatorPose.BoneOffset boneOffset = idlePose.boneOffsets[i];
				jumpChargePoseOriginalBoneRotations[i] = (Object.op_Implicit((Object)(object)boneOffset.bone) ? boneOffset.bone.localRotation : Quaternion.identity);
				jumpChargePoseOriginalIdleRotations[i] = (Object.op_Implicit((Object)(object)boneOffset.idleOffsetTransform) ? boneOffset.idleOffsetTransform.localRotation : Quaternion.identity);
				jumpChargePoseOriginalCurveOffsets[i] = boneOffset.curveOffset;
			}
			jumpChargePoseOriginalSpringSpeed = idlePose.springSpeedMultiplier;
			jumpChargePoseOriginalSpringDamping = idlePose.springDampingMultiplier;
			jumpChargePoseOriginalIdleSpeed = idlePose.idleSpeed;
			jumpChargePoseOriginalLoop = idlePose.loop;
			jumpChargePoseOverrideApplied = true;
			idlePose.springSpeedMultiplier = 1.6f;
			idlePose.springDampingMultiplier = 1.05f;
			idlePose.idleSpeed = 2.4f;
			idlePose.loop = true;
			PoseBoneSetup(idlePose, "Larva Tail Main", new Vector3(-23f, -8f, 0f), new Vector3(6f, 16f, 0f), 5f / 6f);
			PoseBoneSetup(idlePose, "Larva Back Main", new Vector3(-40f, 12f, 0f), new Vector3(8f, -24f, 0f), 2f / 3f);
			PoseBoneSetup(idlePose, "Larva Middle Back Main", new Vector3(-58f, -9f, 0f), new Vector3(12f, 18f, 0f), 0.5f);
			PoseBoneSetup(idlePose, "Larva Center Main", Vector3.zero, Vector3.zero, 0f);
			PoseBoneSetup(idlePose, "Larva Middle Front Main", new Vector3(-58f, -9f, 0f), new Vector3(12f, 18f, 0f), 0f);
			PoseBoneSetup(idlePose, "Larva Front Main", new Vector3(-40f, 12f, 0f), new Vector3(8f, -24f, 0f), 0.1666667f);
			PoseBoneSetup(idlePose, "Larva Head Main", new Vector3(-23f, -8f, 0f), new Vector3(6f, 16f, 0f), 0.3333333f);
			if (Object.op_Implicit((Object)(object)botLimb))
			{
				botLimb.currentPoseIdleTime = 0f;
			}
		}
	}

	private void JumpChargePoseRestore()
	{
		//IL_0064: Unknown result type (might be due to invalid IL or missing references)
		//IL_0075: Unknown result type (might be due to invalid IL or missing references)
		//IL_007a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0099: Unknown result type (might be due to invalid IL or missing references)
		if (!jumpChargePoseOverrideApplied || !Object.op_Implicit((Object)(object)idlePose))
		{
			return;
		}
		int num = Mathf.Min(idlePose.boneOffsets.Count, jumpChargePoseOriginalBoneRotations.Length);
		for (int i = 0; i < num; i++)
		{
			BotSystemSpringPoseAnimatorPose.BoneOffset boneOffset = idlePose.boneOffsets[i];
			if (Object.op_Implicit((Object)(object)boneOffset.bone))
			{
				boneOffset.bone.localRotation = jumpChargePoseOriginalBoneRotations[i];
				boneOffset.targetWorldRotation = boneOffset.bone.localRotation;
			}
			if (Object.op_Implicit((Object)(object)boneOffset.idleOffsetTransform))
			{
				boneOffset.idleOffsetTransform.localRotation = jumpChargePoseOriginalIdleRotations[i];
			}
			boneOffset.curveOffset = jumpChargePoseOriginalCurveOffsets[i];
		}
		idlePose.springSpeedMultiplier = jumpChargePoseOriginalSpringSpeed;
		idlePose.springDampingMultiplier = jumpChargePoseOriginalSpringDamping;
		idlePose.idleSpeed = jumpChargePoseOriginalIdleSpeed;
		idlePose.loop = jumpChargePoseOriginalLoop;
		jumpChargePoseOverrideApplied = false;
	}

	private void PoseBoneSetup(BotSystemSpringPoseAnimatorPose _pose, string _boneName, Vector3 _localEuler, Vector3 _idleEuler, float _curveOffset)
	{
		//IL_005b: Unknown result type (might be due to invalid IL or missing references)
		//IL_005c: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0072: Unknown result type (might be due to invalid IL or missing references)
		//IL_008a: Unknown result type (might be due to invalid IL or missing references)
		//IL_008c: Unknown result type (might be due to invalid IL or missing references)
		if (!Object.op_Implicit((Object)(object)_pose))
		{
			return;
		}
		foreach (BotSystemSpringPoseAnimatorPose.BoneOffset boneOffset in _pose.boneOffsets)
		{
			if (boneOffset != null && Object.op_Implicit((Object)(object)boneOffset.linkedMainRigBone) && !(((Object)boneOffset.linkedMainRigBone).name != _boneName))
			{
				if (Object.op_Implicit((Object)(object)boneOffset.bone))
				{
					boneOffset.bone.localRotation = Quaternion.Euler(_localEuler);
					boneOffset.targetWorldRotation = boneOffset.bone.localRotation;
				}
				if (Object.op_Implicit((Object)(object)boneOffset.idleOffsetTransform))
				{
					boneOffset.idleOffsetTransform.localRotation = Quaternion.Euler(_idleEuler);
				}
				boneOffset.amount = 1f;
				boneOffset.additive = true;
				boneOffset.curveOffset = _curveOffset;
				break;
			}
		}
	}

	private bool PlayerLookState()
	{
		if (currentState != State.Targeting && currentState != State.LungeTell && currentState != State.Lunge)
		{
			return currentState == State.Puke;
		}
		return true;
	}

	private void PlayerLookTick()
	{
		//IL_0123: Unknown result type (might be due to invalid IL or missing references)
		//IL_0139: Unknown result type (might be due to invalid IL or missing references)
		//IL_013e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0038: Unknown result type (might be due to invalid IL or missing references)
		//IL_003f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0044: Unknown result type (might be due to invalid IL or missing references)
		//IL_0049: Unknown result type (might be due to invalid IL or missing references)
		//IL_004e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0065: Unknown result type (might be due to invalid IL or missing references)
		//IL_006c: Unknown result type (might be due to invalid IL or missing references)
		//IL_007f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0086: Unknown result type (might be due to invalid IL or missing references)
		//IL_008d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0094: Unknown result type (might be due to invalid IL or missing references)
		//IL_0099: Unknown result type (might be due to invalid IL or missing references)
		if (!Object.op_Implicit((Object)(object)headTransform))
		{
			return;
		}
		float _yaw = 0f;
		float _pitch = 0f;
		if (PlayerLookState() && PlayerTargetVisualPositionGet(out var _position))
		{
			Vector3 val = headTransform.InverseTransformDirection(_position - headTransform.position);
			if (val.sqrMagnitude > 0.001f)
			{
				val.Normalize();
				_yaw = Mathf.Atan2(val.x, val.z) * 57.29578f;
				float y = val.y;
				Vector2 val2 = new Vector2(val.x, val.z);
				_pitch = (0f - Mathf.Atan2(y, val2.magnitude)) * 57.29578f;
				PlayerLookClamp(ref _yaw, ref _pitch);
			}
		}
		float num = Mathf.Max(0.01f, playerLookSmoothTime);
		float num2 = Mathf.Max(0f, playerLookMaximumSpeed);
		playerLookYaw = Mathf.SmoothDampAngle(playerLookYaw, _yaw, ref playerLookYawVelocity, num, num2, Time.deltaTime);
		playerLookPitch = Mathf.SmoothDampAngle(playerLookPitch, _pitch, ref playerLookPitchVelocity, num, num2, Time.deltaTime);
		Transform val3 = headTransform;
		val3.localRotation *= Quaternion.Euler(playerLookPitch, playerLookYaw, 0f);
	}

	private void PlayerLookClamp(ref float _yaw, ref float _pitch)
	{
		float num = Mathf.Max(0.01f, Mathf.Abs(playerLookYawMaximum));
		float num2 = ((_pitch < 0f) ? Mathf.Max(0.01f, Mathf.Abs(playerLookPitchUpMaximum)) : Mathf.Max(0.01f, Mathf.Abs(playerLookPitchDownMaximum)));
		float num3 = Mathf.Sqrt(Mathf.Pow(_yaw / num, 2f) + Mathf.Pow(_pitch / num2, 2f));
		if (!(num3 <= 1f))
		{
			_yaw /= num3;
			_pitch /= num3;
		}
	}

	private void AttackTellSlither()
	{
		//IL_003e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0049: Unknown result type (might be due to invalid IL or missing references)
		//IL_0054: Unknown result type (might be due to invalid IL or missing references)
		//IL_0059: Unknown result type (might be due to invalid IL or missing references)
		//IL_005e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0061: Unknown result type (might be due to invalid IL or missing references)
		//IL_0066: Unknown result type (might be due to invalid IL or missing references)
		//IL_00fa: Unknown result type (might be due to invalid IL or missing references)
		//IL_0100: Unknown result type (might be due to invalid IL or missing references)
		if (!Object.op_Implicit((Object)(object)botLimb) || botLimb.bones == null)
		{
			return;
		}
		botLimb.SetTempSpeedAndDampingOnAllBones(lungeTellSpringSpeed, lungeTellSpringDamping, lungeTellTime);
		Vector3 val = ((Component)this).transform.right + ((Component)this).transform.up * lungeTellSlitherAxisUp;
		Vector3 normalized = val.normalized;
		int count = botLimb.bones.Count;
		int num = Mathf.Max(1, count - 1);
		for (int i = 0; i < count; i++)
		{
			BotSystemSpringPoseAnimator.BoneSpring boneSpring = botLimb.bones[i];
			if (!((Object)(object)boneSpring?.transform == (Object)null))
			{
				float num2 = ((i % 2 == 0) ? 1f : (-1f));
				float num3 = Mathf.Lerp(0.75f, 1.4f, (float)i / (float)num) * lungeTellSlitherForce * lungeTellSlitherScale;
				botLimb.SetForceOnBone(boneSpring.transform, normalized * (num2 * num3));
			}
		}
	}

	private void JumpJellyImpulse(float _forceMin, float _forceMax)
	{
		//IL_005a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0065: Unknown result type (might be due to invalid IL or missing references)
		//IL_0070: Unknown result type (might be due to invalid IL or missing references)
		//IL_0075: Unknown result type (might be due to invalid IL or missing references)
		//IL_007a: Unknown result type (might be due to invalid IL or missing references)
		//IL_007e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0083: Unknown result type (might be due to invalid IL or missing references)
		//IL_0119: Unknown result type (might be due to invalid IL or missing references)
		//IL_0147: Unknown result type (might be due to invalid IL or missing references)
		//IL_0152: Unknown result type (might be due to invalid IL or missing references)
		if (!Object.op_Implicit((Object)(object)botLimb) || botLimb.bones == null)
		{
			return;
		}
		botLimb.SetTempSpeedAndDampingOnAllBones(jumpJellySpringSpeed, jumpJellySpringDamping, jumpJellyPulseTime);
		int count = botLimb.bones.Count;
		if (count <= 0)
		{
			return;
		}
		int num = (count - 1) / 2;
		Vector3 val = ((Component)this).transform.up + ((Component)this).transform.right * jumpJellyAxisUp;
		Vector3 normalized = val.normalized;
		float num2 = Random.Range(_forceMin, _forceMax);
		float num3 = ((Random.value >= 0.5f) ? 1f : (-1f));
		int num4 = Mathf.Max(1, num);
		for (int i = 0; i < count; i++)
		{
			BotSystemSpringPoseAnimator.BoneSpring boneSpring = botLimb.bones[i];
			if (!((Object)(object)boneSpring?.transform == (Object)null))
			{
				int num5 = Mathf.Abs(i - num);
				float num6 = (float)num5 / (float)num4;
				float num7 = Mathf.Lerp(0.25f, 1.2f, num6);
				if (num5 == 0)
				{
					botLimb.SetForceOnBone(boneSpring.transform, Vector3.zero);
					continue;
				}
				float num8 = ((num5 % 2 == 0) ? (-1f) : 1f);
				botLimb.SetForceOnBone(boneSpring.transform, normalized * (num2 * num7 * num8 * num3));
			}
		}
	}

	private void StatePresentationApply(State _state, float _blendTime)
	{
		if (!Object.op_Implicit((Object)(object)botLimb))
		{
			return;
		}
		switch (_state)
		{
		case State.Spawn:
		case State.Idle:
		case State.Targeting:
		case State.Recover:
		case State.Dormant:
			if (Object.op_Implicit((Object)(object)idlePose))
			{
				botLimb.BlendToPose(idlePose, _blendTime);
			}
			break;
		case State.JumpCharge:
			if (Object.op_Implicit((Object)(object)jumpChargePose) && (Object)(object)jumpChargePose != (Object)(object)jumpPose)
			{
				botLimb.BlendToPose(jumpChargePose, _blendTime);
			}
			else if (Object.op_Implicit((Object)(object)idlePose))
			{
				botLimb.BlendToPose(idlePose, _blendTime);
			}
			break;
		case State.Jump:
		case State.JumpLand:
		case State.LungeTell:
		case State.Lunge:
		case State.Puke:
		case State.Held:
		case State.Hurt:
		case State.HeldPuke:
			if (Object.op_Implicit((Object)(object)jumpPose))
			{
				botLimb.BlendToPose(jumpPose, _blendTime);
			}
			break;
		}
	}

	private void PoseMotionTick()
	{
		if (Object.op_Implicit((Object)(object)botLimb))
		{
			if (PlayerLookState())
			{
				botLimb.CullingVisualOverride(0.1f);
			}
			switch (currentState)
			{
			case State.Targeting:
				botLimb.OverridePoseMotionSpeed(targetLookPoseMotionSpeed);
				break;
			case State.JumpCharge:
				botLimb.OverridePoseMotionSpeed(jumpChargeSquirmPoseMotionSpeed);
				break;
			case State.LungeTell:
				botLimb.OverridePoseMotionSpeed(lungeTellPoseMotionSpeed);
				break;
			case State.Held:
			case State.HeldPuke:
				botLimb.OverridePoseMotionSpeed(heldPanicPoseMotionSpeed);
				break;
			case State.Jump:
			case State.JumpLand:
			case State.Lunge:
			case State.Puke:
			case State.Hurt:
				botLimb.OverridePoseMotionSpeed(jumpPoseMotionSpeed * jumpPoseExaggeration);
				break;
			default:
				botLimb.OverridePoseMotionSpeed(idlePoseMotionSpeed);
				break;
			}
		}
	}
}
