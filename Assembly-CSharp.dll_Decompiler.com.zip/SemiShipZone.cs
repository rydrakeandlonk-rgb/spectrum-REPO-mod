using System;
using System.Collections.Generic;
using UnityEngine;

[DefaultExecutionOrder(100)]
public class SemiShipZone : MonoBehaviour
{
	private class CarryZone
	{
		public BoxCollider collider;

		public Transform zoneTransform;

		public Vector3 velocity;

		public Vector3 angularVelocity;

		public float movingTimer;

		public float motionElapsed;

		public Vector3 updatePositionPrevious;

		public Quaternion updateRotationPrevious = Quaternion.identity;

		public float updateYawPrevious;

		public float updateYawDelta;

		public CarryZone()
		{
			//IL_0001: Unknown result type (might be due to invalid IL or missing references)
			//IL_0006: Unknown result type (might be due to invalid IL or missing references)
		}
	}

	private class Rider
	{
		public PhysGrabObject physGrabObject;

		public EnemyRigidbody enemyRigidbody;

		public CarryZone carryZone;

		public Vector3 pointVelocity;

		public bool hasPointVelocity;

		public bool anchorLocked;

		public bool anchorCaughtUp;

		public Vector3 anchorLocalPosition;

		public float anchorRelativeYaw;

		public float timer;
	}

	private class InsidePlayer
	{
		public PlayerAvatar playerAvatar;

		public float timer;
	}

	public List<BoxCollider> zones = new List<BoxCollider>();

	[Tooltip("extra reach around each zone box in meters... catches stuff resting right on a thin zone surface")]
	public float zonePadding = 0.1f;

	[Tooltip("only carry stuff whose center point is over a zone footprint or right above the ship itself.. turn on for moving platforms so side clips don't snag riders")]
	public bool requireOnTop;

	[Tooltip("how far below a center point the ship can be and still count as on top... covers zone gaps when boxes only roughly tile the surface")]
	public float requireOnTopRayLength = 3f;

	[Tooltip("how long stuff keeps getting carried after it stops overlapping the zone")]
	public float riderMemoryTime = 0.25f;

	[Tooltip("1 = riders match the ship velocity fully, lower = they slide")]
	public float carryStrength = 1f;

	[Tooltip("how fast riders' velocity catches up to the ship, like friction.. gets stuff moving that's placed on an already-moving ship")]
	public float carryCatchUpStrength = 5f;

	[Tooltip("point velocities above this count as a teleport and get ignored so riders don't get flung")]
	public float teleportSpeed = 30f;

	[Tooltip("spin riders to match the ship's rotation, for turntables and such")]
	public bool carrySpin = true;

	[Tooltip("how fast riders' spin catches up to the ship's rotation, like friction")]
	public float spinCarryStrength = 5f;

	[Tooltip("ship spin above this (rad/s) counts as a rotation snap and spin carry skips it")]
	public float teleportSpinSpeed = 15f;

	[Tooltip("turn the local player's aim with the zone's yaw spin, like standing on a turntable")]
	public bool carrySpinLocalPlayer = true;

	[Tooltip("lock settled riders to their spot on the zone... sets their velocity straight so weight and friction can't make them drift or lag")]
	public bool anchor = true;

	[Tooltip("riders moving slower than this (m/s) relative to the zone OR the world snap into the locked follow")]
	public float anchorLockSpeed = 0.3f;

	[Tooltip("correction velocity per meter of drift from the anchored spot.... moderate on purpose, cranking it turns frame-quantized platform motion into jitter")]
	public float anchorStrength = 15f;

	[Tooltip("correction velocity cap (m/s) so snap-backs never get violent")]
	public float anchorCorrectionMax = 3f;

	[Tooltip("locked riders accelerate at most this fast (m/s2)... a freshly locked rider ramps up to zone speed instead of snapping")]
	public float anchorAccelerationMax = 30f;

	[Tooltip("yaw correction spin cap (rad/s)")]
	public float anchorSpinCorrectionMax = 1.5f;

	[Tooltip("drift past this means something moved the rider on purpose.. re-anchor instead of dragging it back")]
	public float anchorBreakDistance = 0.5f;

	[Tooltip("riders moving this fast (m/s) relative to the zone are rolling/thrown/pushed... re-anchor")]
	public float anchorBreakSpeed = 1.5f;

	[Tooltip("riders spinning this fast (rad/s) relative to the zone re-anchor")]
	public float anchorBreakSpinSpeed = 3f;

	[Tooltip("yaw drift past this (degrees) re-anchors")]
	public float anchorBreakAngle = 60f;

	[Tooltip("editor only.. logs zone motion, rider carry state and lock transitions to the console")]
	public bool debugLogs;

	private Rigidbody shipRigidbody;

	private PhysGrabObject shipPhysGrabObject;

	private Transform shipRoot;

	private RaycastHit[] onTopRaycastBuffer = new RaycastHit[16];

	private readonly List<CarryZone> carryZones = new List<CarryZone>();

	private readonly List<Rider> riders = new List<Rider>();

	private readonly List<InsidePlayer> insidePlayers = new List<InsidePlayer>();

	private Collider[] overlapBuffer = new Collider[64];

	private int riderLayerMask;

	private CarryZone playerAnchorZone;

	private Vector3 playerAnchorLocalPosition;

	private CarryZone playerSpinZone;

	private float playerSpinTimer;

	private const float zoneMotionHoldTime = 0.05f;

	private void Awake()
	{
		//IL_0025: Unknown result type (might be due to invalid IL or missing references)
		shipRigidbody = ((Component)this).GetComponentInParent<Rigidbody>();
		shipPhysGrabObject = ((Component)this).GetComponentInParent<PhysGrabObject>();
		ShipRootSet();
		CarryZonesBuild();
		riderLayerMask = LayerMask.op_Implicit(SemiFunc.LayerMaskGetPlayersAndPhysObjects()) | LayerMask.GetMask(new string[1] { "Enemy" });
	}

	private void ShipRootSet()
	{
		shipRoot = ((Component)this).transform;
		if (Object.op_Implicit((Object)(object)shipRigidbody))
		{
			shipRoot = ((Component)shipRigidbody).transform;
		}
		if (Object.op_Implicit((Object)(object)shipPhysGrabObject))
		{
			shipRoot = ((Component)shipPhysGrabObject).transform;
		}
	}

	private void CarryZonesBuild()
	{
		//IL_003e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0043: Unknown result type (might be due to invalid IL or missing references)
		//IL_004f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0054: Unknown result type (might be due to invalid IL or missing references)
		//IL_0061: Unknown result type (might be due to invalid IL or missing references)
		foreach (BoxCollider zone in zones)
		{
			if (Object.op_Implicit((Object)(object)zone))
			{
				CarryZone carryZone = new CarryZone();
				carryZone.collider = zone;
				carryZone.zoneTransform = ((Component)zone).transform;
				carryZone.updatePositionPrevious = carryZone.zoneTransform.position;
				carryZone.updateRotationPrevious = carryZone.zoneTransform.rotation;
				carryZone.updateYawPrevious = FlatYaw(carryZone.zoneTransform.rotation);
				carryZones.Add(carryZone);
			}
		}
	}

	private void Update()
	{
		ZoneMotionTick();
		CarryLocalPlayerSpinTick();
		DebugZoneLog();
	}

	private void FixedUpdate()
	{
		DetectRiders();
		RiderTimerTick();
		InsidePlayerTimerTick();
		CarryRiders();
	}

	private void ZoneMotionTick()
	{
		//IL_0033: Unknown result type (might be due to invalid IL or missing references)
		//IL_0039: Unknown result type (might be due to invalid IL or missing references)
		//IL_003e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0043: Unknown result type (might be due to invalid IL or missing references)
		//IL_0045: Unknown result type (might be due to invalid IL or missing references)
		//IL_004b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0050: Unknown result type (might be due to invalid IL or missing references)
		//IL_0055: Unknown result type (might be due to invalid IL or missing references)
		//IL_005a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0112: Unknown result type (might be due to invalid IL or missing references)
		//IL_0117: Unknown result type (might be due to invalid IL or missing references)
		//IL_011d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0122: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a9: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b0: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b5: Unknown result type (might be due to invalid IL or missing references)
		//IL_00bb: Unknown result type (might be due to invalid IL or missing references)
		//IL_00cc: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d1: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ee: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00fa: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ff: Unknown result type (might be due to invalid IL or missing references)
		//IL_0148: Unknown result type (might be due to invalid IL or missing references)
		float num = default;
		Vector3 val3 = default;
		foreach (CarryZone carryZone in carryZones)
		{
			Transform zoneTransform = carryZone.zoneTransform;
			carryZone.motionElapsed += Time.deltaTime;
			Vector3 val = zoneTransform.position - carryZone.updatePositionPrevious;
			Quaternion val2 = zoneTransform.rotation * Quaternion.Inverse(carryZone.updateRotationPrevious);
			val2.ToAngleAxis(ref num, ref val3);
			if (num > 180f)
			{
				num -= 360f;
			}
			if ((val.sqrMagnitude > 1E-07f || Mathf.Abs(num) > 0.001f) && carryZone.motionElapsed > 0.0001f)
			{
				carryZone.velocity = val / carryZone.motionElapsed;
				carryZone.angularVelocity = val3 * (num * (MathF.PI / 180f) / carryZone.motionElapsed);
				carryZone.motionElapsed = 0f;
				carryZone.movingTimer = 0.05f;
				carryZone.updatePositionPrevious = zoneTransform.position;
				carryZone.updateRotationPrevious = zoneTransform.rotation;
			}
			if (carryZone.movingTimer <= 0f)
			{
				carryZone.velocity = Vector3.zero;
				carryZone.angularVelocity = Vector3.zero;
			}
			if (carryZone.movingTimer > 0f)
			{
				carryZone.movingTimer -= Time.deltaTime;
			}
			float num2 = FlatYaw(zoneTransform.rotation);
			carryZone.updateYawDelta = Mathf.DeltaAngle(carryZone.updateYawPrevious, num2);
			carryZone.updateYawPrevious = num2;
		}
	}

	private Vector3 ZonePointVelocity(CarryZone _carryZone, Vector3 _worldPoint)
	{
		//IL_0001: Unknown result type (might be due to invalid IL or missing references)
		//IL_0007: Unknown result type (might be due to invalid IL or missing references)
		//IL_000c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0013: Unknown result type (might be due to invalid IL or missing references)
		//IL_0018: Unknown result type (might be due to invalid IL or missing references)
		//IL_001d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0022: Unknown result type (might be due to invalid IL or missing references)
		return _carryZone.velocity + Vector3.Cross(_carryZone.angularVelocity, _worldPoint - _carryZone.zoneTransform.position);
	}

	private bool TeleportCheck(Vector3 _pointVelocity)
	{
		return _pointVelocity.sqrMagnitude > teleportSpeed * teleportSpeed;
	}

	private bool ZoneMoving(CarryZone _carryZone)
	{
		if (!(_carryZone.velocity.sqrMagnitude > 0.01f))
		{
			return _carryZone.angularVelocity.sqrMagnitude > 0.01f;
		}
		return true;
	}

	private float FlatYaw(Quaternion _rotation)
	{
		//IL_0000: Unknown result type (might be due to invalid IL or missing references)
		//IL_0001: Unknown result type (might be due to invalid IL or missing references)
		//IL_0006: Unknown result type (might be due to invalid IL or missing references)
		//IL_000b: Unknown result type (might be due to invalid IL or missing references)
		//IL_003e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0044: Unknown result type (might be due to invalid IL or missing references)
		//IL_0026: Unknown result type (might be due to invalid IL or missing references)
		//IL_0027: Unknown result type (might be due to invalid IL or missing references)
		//IL_002c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0031: Unknown result type (might be due to invalid IL or missing references)
		Vector3 val = _rotation * Vector3.forward;
		val.y = 0f;
		if (val.sqrMagnitude < 0.01f)
		{
			val = _rotation * Vector3.right;
			val.y = 0f;
		}
		return Mathf.Atan2(val.x, val.z) * 57.29578f;
	}

	private float ZoneRelativeYaw(CarryZone _carryZone, Rigidbody _rb)
	{
		//IL_0007: Unknown result type (might be due to invalid IL or missing references)
		//IL_0013: Unknown result type (might be due to invalid IL or missing references)
		return Mathf.DeltaAngle(FlatYaw(_carryZone.zoneTransform.rotation), FlatYaw(_rb.rotation));
	}

	private void DetectRiders()
	{
		foreach (CarryZone carryZone in carryZones)
		{
			DetectRidersInZone(carryZone);
		}
	}

	private void ZoneWorldBox(BoxCollider _zone, out Vector3 _center, out Vector3 _size, out Quaternion _rotation)
	{
		//IL_000a: Unknown result type (might be due to invalid IL or missing references)
		//IL_000f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0014: Unknown result type (might be due to invalid IL or missing references)
		//IL_001c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0021: Unknown result type (might be due to invalid IL or missing references)
		//IL_0027: Unknown result type (might be due to invalid IL or missing references)
		//IL_002c: Unknown result type (might be due to invalid IL or missing references)
		//IL_002f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0034: Unknown result type (might be due to invalid IL or missing references)
		//IL_003f: Unknown result type (might be due to invalid IL or missing references)
		//IL_004a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0055: Unknown result type (might be due to invalid IL or missing references)
		//IL_005a: Unknown result type (might be due to invalid IL or missing references)
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		Transform transform = ((Component)_zone).transform;
		_center = transform.TransformPoint(_zone.center);
		_rotation = transform.rotation;
		Vector3 lossyScale = transform.lossyScale;
		_size = Vector3.Scale(_zone.size, new Vector3(Mathf.Abs(lossyScale.x), Mathf.Abs(lossyScale.y), Mathf.Abs(lossyScale.z)));
	}

	private bool OnTopCheck(Vector3 _worldPoint)
	{
		//IL_0022: Unknown result type (might be due to invalid IL or missing references)
		//IL_0048: Unknown result type (might be due to invalid IL or missing references)
		if (!requireOnTop)
		{
			return true;
		}
		foreach (CarryZone carryZone in carryZones)
		{
			if (ZoneFootprintCheck(carryZone, _worldPoint))
			{
				return true;
			}
		}
		return ShipBelowCheck(_worldPoint);
	}

	private bool ZoneFootprintCheck(CarryZone _carryZone, Vector3 _worldPoint)
	{
		//IL_0006: Unknown result type (might be due to invalid IL or missing references)
		//IL_0007: Unknown result type (might be due to invalid IL or missing references)
		//IL_0012: Unknown result type (might be due to invalid IL or missing references)
		//IL_0017: Unknown result type (might be due to invalid IL or missing references)
		//IL_001c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0023: Unknown result type (might be due to invalid IL or missing references)
		//IL_002d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0032: Unknown result type (might be due to invalid IL or missing references)
		//IL_0033: Unknown result type (might be due to invalid IL or missing references)
		//IL_003e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0048: Unknown result type (might be due to invalid IL or missing references)
		//IL_0053: Unknown result type (might be due to invalid IL or missing references)
		//IL_005d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0063: Unknown result type (might be due to invalid IL or missing references)
		//IL_0070: Unknown result type (might be due to invalid IL or missing references)
		Vector3 val = _carryZone.zoneTransform.InverseTransformPoint(_worldPoint) - _carryZone.collider.center;
		Vector3 val2 = _carryZone.collider.size * 0.5f;
		if (Mathf.Abs(val.x) > val2.x)
		{
			return false;
		}
		if (Mathf.Abs(val.z) > val2.z)
		{
			return false;
		}
		if ((val.y + val2.y) * Mathf.Abs(_carryZone.zoneTransform.lossyScale.y) < 0f - zonePadding)
		{
			return false;
		}
		return true;
	}

	private bool ShipBelowCheck(Vector3 _worldPoint)
	{
		//IL_0000: Unknown result type (might be due to invalid IL or missing references)
		//IL_0001: Unknown result type (might be due to invalid IL or missing references)
		int num = Physics.RaycastNonAlloc(_worldPoint, Vector3.down, onTopRaycastBuffer, requireOnTopRayLength, -5, (QueryTriggerInteraction)1);
		for (int i = 0; i < num; i++)
		{
			if (onTopRaycastBuffer[i].transform.IsChildOf(shipRoot))
			{
				return true;
			}
		}
		return false;
	}

	private void DetectRidersInZone(CarryZone _carryZone)
	{
		//IL_0012: Unknown result type (might be due to invalid IL or missing references)
		//IL_0018: Unknown result type (might be due to invalid IL or missing references)
		//IL_001d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0028: Unknown result type (might be due to invalid IL or missing references)
		//IL_002d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0032: Unknown result type (might be due to invalid IL or missing references)
		//IL_0033: Unknown result type (might be due to invalid IL or missing references)
		//IL_0034: Unknown result type (might be due to invalid IL or missing references)
		//IL_003b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0061: Unknown result type (might be due to invalid IL or missing references)
		//IL_0062: Unknown result type (might be due to invalid IL or missing references)
		//IL_0069: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b1: Unknown result type (might be due to invalid IL or missing references)
		//IL_00fa: Unknown result type (might be due to invalid IL or missing references)
		//IL_0135: Unknown result type (might be due to invalid IL or missing references)
		//IL_018d: Unknown result type (might be due to invalid IL or missing references)
		ZoneWorldBox(_carryZone.collider, out var _center, out var _size, out var _rotation);
		Vector3 val = _size * 0.5f + Vector3.one * zonePadding;
		int num;
		for (num = Physics.OverlapBoxNonAlloc(_center, val, overlapBuffer, _rotation, riderLayerMask, (QueryTriggerInteraction)1); num == overlapBuffer.Length; num = Physics.OverlapBoxNonAlloc(_center, val, overlapBuffer, _rotation, riderLayerMask, (QueryTriggerInteraction)1))
		{
			overlapBuffer = new Collider[overlapBuffer.Length * 2];
		}
		for (int i = 0; i < num; i++)
		{
			Collider val2 = overlapBuffer[i];
			PlayerController componentInParent = ((Component)val2).GetComponentInParent<PlayerController>();
			if (Object.op_Implicit((Object)(object)componentInParent))
			{
				if (OnTopCheck(componentInParent.rb.position))
				{
					CarryLocalPlayer(componentInParent, _carryZone);
					InsidePlayerRenew(componentInParent.playerAvatarScript);
				}
				continue;
			}
			PlayerPhysPusher componentInParent2 = ((Component)val2).GetComponentInParent<PlayerPhysPusher>();
			if (Object.op_Implicit((Object)(object)componentInParent2))
			{
				if (OnTopCheck(((Component)componentInParent2.Player).transform.position))
				{
					InsidePlayerRenew(componentInParent2.Player);
				}
				continue;
			}
			PlayerAvatar componentInParent3 = ((Component)val2).GetComponentInParent<PlayerAvatar>();
			if (Object.op_Implicit((Object)(object)componentInParent3))
			{
				if (OnTopCheck(((Component)componentInParent3).transform.position))
				{
					InsidePlayerRenew(componentInParent3);
				}
			}
			else if (SemiFunc.IsMasterClientOrSingleplayer())
			{
				PhysGrabObject componentInParent4 = ((Component)val2).GetComponentInParent<PhysGrabObject>();
				if (Object.op_Implicit((Object)(object)componentInParent4) && (!Object.op_Implicit((Object)(object)shipPhysGrabObject) || !((Component)componentInParent4).transform.IsChildOf(((Component)shipPhysGrabObject).transform)) && OnTopCheck(componentInParent4.midPoint))
				{
					RiderRenew(componentInParent4, _carryZone);
				}
			}
		}
	}

	private void RiderRenew(PhysGrabObject _physGrabObject, CarryZone _carryZone)
	{
		foreach (Rider rider2 in riders)
		{
			if ((Object)(object)rider2.physGrabObject == (Object)(object)_physGrabObject)
			{
				if (rider2.carryZone != _carryZone)
				{
					RiderAnchorZoneTransfer(rider2, _carryZone);
					rider2.carryZone = _carryZone;
				}
				rider2.timer = riderMemoryTime;
				return;
			}
		}
		Rider rider = new Rider();
		rider.physGrabObject = _physGrabObject;
		rider.enemyRigidbody = ((Component)_physGrabObject).GetComponent<EnemyRigidbody>();
		rider.carryZone = _carryZone;
		rider.timer = riderMemoryTime;
		riders.Add(rider);
		DebugLog("riding: " + ((Object)_physGrabObject).name);
	}

	private void RiderTimerTick()
	{
		for (int i = 0; i < riders.Count; i++)
		{
			Rider rider = riders[i];
			if (rider.timer <= 0f || !Object.op_Implicit((Object)(object)rider.physGrabObject))
			{
				if (Object.op_Implicit((Object)(object)rider.physGrabObject))
				{
					DebugLog("dropped: " + ((Object)rider.physGrabObject).name);
				}
				riders.RemoveAt(i);
				i--;
			}
			else
			{
				rider.timer -= Time.fixedDeltaTime;
			}
		}
	}

	private void InsidePlayerRenew(PlayerAvatar _playerAvatar)
	{
		foreach (InsidePlayer insidePlayer2 in insidePlayers)
		{
			if ((Object)(object)insidePlayer2.playerAvatar == (Object)(object)_playerAvatar)
			{
				insidePlayer2.timer = riderMemoryTime;
				return;
			}
		}
		InsidePlayer insidePlayer = new InsidePlayer();
		insidePlayer.playerAvatar = _playerAvatar;
		insidePlayer.timer = riderMemoryTime;
		insidePlayers.Add(insidePlayer);
	}

	private void InsidePlayerTimerTick()
	{
		for (int i = 0; i < insidePlayers.Count; i++)
		{
			InsidePlayer insidePlayer = insidePlayers[i];
			if (insidePlayer.timer <= 0f || !Object.op_Implicit((Object)(object)insidePlayer.playerAvatar))
			{
				insidePlayers.RemoveAt(i);
				i--;
			}
			else
			{
				insidePlayer.timer -= Time.fixedDeltaTime;
			}
		}
	}

	private bool InsidePlayerCheck(PlayerAvatar _playerAvatar)
	{
		foreach (InsidePlayer insidePlayer in insidePlayers)
		{
			if ((Object)(object)insidePlayer.playerAvatar == (Object)(object)_playerAvatar)
			{
				return true;
			}
		}
		return false;
	}

	public void ShipCollision(Collision _collision)
	{
		if (Object.op_Implicit((Object)(object)shipRigidbody) && SemiFunc.IsMasterClientOrSingleplayer())
		{
			PlayerAvatar playerAvatar = PlayerAvatarFromCollision(_collision);
			if (Object.op_Implicit((Object)(object)playerAvatar) && InsidePlayerCheck(playerAvatar))
			{
				PlayerPushCancel(_collision);
			}
		}
	}

	private PlayerAvatar PlayerAvatarFromCollision(Collision _collision)
	{
		PlayerPhysPusher componentInParent = ((Component)_collision.collider).GetComponentInParent<PlayerPhysPusher>();
		if (Object.op_Implicit((Object)(object)componentInParent))
		{
			return componentInParent.Player;
		}
		PlayerController componentInParent2 = ((Component)_collision.collider).GetComponentInParent<PlayerController>();
		if (Object.op_Implicit((Object)(object)componentInParent2))
		{
			return componentInParent2.playerAvatarScript;
		}
		return null;
	}

	private void PlayerPushCancel(Collision _collision)
	{
		//IL_000a: Unknown result type (might be due to invalid IL or missing references)
		//IL_000f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0010: Unknown result type (might be due to invalid IL or missing references)
		//IL_0011: Unknown result type (might be due to invalid IL or missing references)
		//IL_001e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0021: Unknown result type (might be due to invalid IL or missing references)
		//IL_0026: Unknown result type (might be due to invalid IL or missing references)
		//IL_0029: Unknown result type (might be due to invalid IL or missing references)
		//IL_0041: Unknown result type (might be due to invalid IL or missing references)
		//IL_0046: Unknown result type (might be due to invalid IL or missing references)
		//IL_003a: Unknown result type (might be due to invalid IL or missing references)
		//IL_003b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0040: Unknown result type (might be due to invalid IL or missing references)
		//IL_004b: Unknown result type (might be due to invalid IL or missing references)
		//IL_004e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0053: Unknown result type (might be due to invalid IL or missing references)
		//IL_0056: Unknown result type (might be due to invalid IL or missing references)
		//IL_005b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0060: Unknown result type (might be due to invalid IL or missing references)
		//IL_0074: Unknown result type (might be due to invalid IL or missing references)
		//IL_0075: Unknown result type (might be due to invalid IL or missing references)
		//IL_007a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0082: Unknown result type (might be due to invalid IL or missing references)
		if (_collision.contactCount == 0)
		{
			return;
		}
		Vector3 val = _collision.impulse;
		if (!(val == Vector3.zero))
		{
			Vector3 val2 = val;
			ContactPoint contact = _collision.GetContact(0);
			if (Vector3.Dot(val2, contact.normal) < 0f)
			{
				val = -val;
			}
			Vector3 val3 = Vector3.zero;
			for (int i = 0; i < _collision.contactCount; i++)
			{
				Vector3 val4 = val3;
				contact = _collision.GetContact(i);
				val3 = val4 + contact.point;
			}
			shipRigidbody.AddForceAtPosition(-val, val3 / (float)_collision.contactCount, (ForceMode)1);
		}
	}

	private void CarryLocalPlayer(PlayerController _controller, CarryZone _carryZone)
	{
		//IL_0028: Unknown result type (might be due to invalid IL or missing references)
		//IL_002d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0032: Unknown result type (might be due to invalid IL or missing references)
		//IL_0034: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0071: Unknown result type (might be due to invalid IL or missing references)
		//IL_0076: Unknown result type (might be due to invalid IL or missing references)
		//IL_0078: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a6: Unknown result type (might be due to invalid IL or missing references)
		if (_controller.playerAvatarScript.isTumbling)
		{
			playerAnchorZone = null;
			return;
		}
		_controller.CollisionController.OverrideDisableFalling();
		Vector3 val = ZonePointVelocity(_carryZone, _controller.rb.position);
		if (TeleportCheck(val))
		{
			playerAnchorZone = null;
			DebugLog("player carry skipped, teleport speed " + val.magnitude.ToString("F1"));
			return;
		}
		val += PlayerAnchorCorrection(_controller, _carryZone);
		_controller.OverridePlatformVelocity(val);
		PlayerSpinRenew(_carryZone);
		if (Object.op_Implicit((Object)(object)shipPhysGrabObject))
		{
			_controller.CollisionGrounded.OverridePhysRiding(shipPhysGrabObject);
		}
		DebugPlayerLog(_controller, _carryZone, val);
	}

	private void PlayerSpinRenew(CarryZone _carryZone)
	{
		if (carrySpinLocalPlayer)
		{
			playerSpinZone = _carryZone;
			playerSpinTimer = riderMemoryTime;
		}
	}

	private void CarryLocalPlayerSpinTick()
	{
		if (!(playerSpinTimer <= 0f))
		{
			playerSpinTimer -= Time.deltaTime;
			float updateYawDelta = playerSpinZone.updateYawDelta;
			if (updateYawDelta != 0f && !(Mathf.Abs(updateYawDelta) > teleportSpinSpeed * 57.29578f * Time.deltaTime))
			{
				CameraAim.Instance.AdditiveAimX(updateYawDelta);
			}
		}
	}

	private void CarryRiders()
	{
		//IL_0048: Unknown result type (might be due to invalid IL or missing references)
		//IL_004d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0052: Unknown result type (might be due to invalid IL or missing references)
		//IL_0054: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b2: Unknown result type (might be due to invalid IL or missing references)
		//IL_00df: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e0: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ef: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c1: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c8: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d3: Unknown result type (might be due to invalid IL or missing references)
		//IL_0113: Unknown result type (might be due to invalid IL or missing references)
		//IL_0108: Unknown result type (might be due to invalid IL or missing references)
		//IL_011c: Unknown result type (might be due to invalid IL or missing references)
		if (!SemiFunc.IsMasterClientOrSingleplayer())
		{
			return;
		}
		foreach (Rider rider in riders)
		{
			Rigidbody rb = rider.physGrabObject.rb;
			if (!Object.op_Implicit((Object)(object)rb))
			{
				continue;
			}
			RiderWake(rider, rb);
			Vector3 val = ZonePointVelocity(rider.carryZone, rb.worldCenterOfMass);
			if (TeleportCheck(val))
			{
				rider.hasPointVelocity = false;
				rider.anchorLocked = false;
				DebugLog("carry skipped on " + ((Object)rb).name + ", teleport speed " + val.magnitude.ToString("F1"));
				continue;
			}
			if (Object.op_Implicit((Object)(object)rider.enemyRigidbody))
			{
				rider.enemyRigidbody.OverrideShipVelocity(val);
			}
			if (rider.hasPointVelocity)
			{
				rb.AddForce((val - rider.pointVelocity) * carryStrength, (ForceMode)2);
			}
			rider.pointVelocity = val;
			rider.hasPointVelocity = true;
			RiderAnchorLogic(rider, rb, val);
			CarrySpin(rider, rb);
			if (rider.anchorLocked)
			{
				CarryAnchorLock(rider, rb, val);
			}
			else
			{
				CarryCatchUp(rider, rb, val);
			}
			DebugRiderLog(rider, rb, val);
		}
	}

	private void RiderWake(Rider _rider, Rigidbody _rb)
	{
		if (ZoneMoving(_rider.carryZone))
		{
			_rb.WakeUp();
		}
	}

	private void CarryCatchUp(Rider _rider, Rigidbody _rb, Vector3 _pointVelocity)
	{
		//IL_002a: Unknown result type (might be due to invalid IL or missing references)
		//IL_002c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0031: Unknown result type (might be due to invalid IL or missing references)
		//IL_0036: Unknown result type (might be due to invalid IL or missing references)
		//IL_006a: Unknown result type (might be due to invalid IL or missing references)
		//IL_006c: Unknown result type (might be due to invalid IL or missing references)
		if (!(carryCatchUpStrength <= 0f) && !Object.op_Implicit((Object)(object)_rider.enemyRigidbody) && !_rider.physGrabObject.grabbed)
		{
			Vector3 val = _pointVelocity - _rb.linearVelocity;
			val.y = 0f;
			if (!(val.sqrMagnitude < 0.001f))
			{
				float num = Mathf.Min(1f, carryCatchUpStrength * Time.fixedDeltaTime);
				_rb.AddForce(val * num, (ForceMode)2);
			}
		}
	}

	private void CarrySpin(Rider _rider, Rigidbody _rb)
	{
		//IL_0039: Unknown result type (might be due to invalid IL or missing references)
		//IL_003e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0056: Unknown result type (might be due to invalid IL or missing references)
		//IL_0058: Unknown result type (might be due to invalid IL or missing references)
		//IL_005d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0062: Unknown result type (might be due to invalid IL or missing references)
		//IL_008a: Unknown result type (might be due to invalid IL or missing references)
		//IL_008c: Unknown result type (might be due to invalid IL or missing references)
		if (!carrySpin || spinCarryStrength <= 0f || Object.op_Implicit((Object)(object)_rider.enemyRigidbody) || _rider.physGrabObject.grabbed)
		{
			return;
		}
		Vector3 angularVelocity = _rider.carryZone.angularVelocity;
		if (!(angularVelocity.sqrMagnitude > teleportSpinSpeed * teleportSpinSpeed))
		{
			Vector3 val = angularVelocity - _rb.angularVelocity;
			if (!(val.sqrMagnitude < 0.001f))
			{
				float num = Mathf.Min(1f, spinCarryStrength * Time.fixedDeltaTime);
				_rb.AddTorque(val * num, (ForceMode)2);
			}
		}
	}

	private void RiderAnchorLogic(Rider _rider, Rigidbody _rb, Vector3 _pointVelocity)
	{
		//IL_00a8: Unknown result type (might be due to invalid IL or missing references)
		//IL_006e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0077: Unknown result type (might be due to invalid IL or missing references)
		if (!anchor || Object.op_Implicit((Object)(object)_rider.enemyRigidbody) || _rider.physGrabObject.grabbed || _rb.isKinematic || !ZoneMoving(_rider.carryZone))
		{
			if (_rider.anchorLocked)
			{
				DebugLog("lock off on " + ((Object)_rb).name + " (grabbed/kinematic/zone still)");
			}
			_rider.anchorLocked = false;
		}
		else if (_rider.anchorLocked)
		{
			RiderAnchorCaughtUpCheck(_rider, _rb, _pointVelocity);
			string text = RiderAnchorBreakReason(_rider, _rb, _pointVelocity);
			if (text != null)
			{
				_rider.anchorLocked = false;
				DebugLog("lock broke on " + ((Object)_rb).name + ": " + text);
			}
		}
		else if (RiderSettledCheck(_rider, _rb, _pointVelocity))
		{
			RiderAnchorSet(_rider, _rb);
			DebugLog("locked " + ((Object)_rb).name + " to " + ((Object)_rider.carryZone.zoneTransform).name);
		}
	}

	private bool RiderSettledCheck(Rider _rider, Rigidbody _rb, Vector3 _pointVelocity)
	{
		//IL_0001: Unknown result type (might be due to invalid IL or missing references)
		//IL_0006: Unknown result type (might be due to invalid IL or missing references)
		//IL_0007: Unknown result type (might be due to invalid IL or missing references)
		//IL_000c: Unknown result type (might be due to invalid IL or missing references)
		//IL_001a: Unknown result type (might be due to invalid IL or missing references)
		//IL_001f: Unknown result type (might be due to invalid IL or missing references)
		//IL_004a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0055: Unknown result type (might be due to invalid IL or missing references)
		//IL_005a: Unknown result type (might be due to invalid IL or missing references)
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		Vector3 val = _rb.linearVelocity - _pointVelocity;
		val.y = 0f;
		Vector3 linearVelocity = _rb.linearVelocity;
		linearVelocity.y = 0f;
		if (Mathf.Min(val.magnitude, linearVelocity.magnitude) > anchorLockSpeed)
		{
			return false;
		}
		Vector3 val2 = _rb.angularVelocity - _rider.carryZone.angularVelocity;
		if (val2.magnitude > anchorBreakSpinSpeed)
		{
			return false;
		}
		return true;
	}

	private void RiderAnchorSet(Rider _rider, Rigidbody _rb)
	{
		//IL_000d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0012: Unknown result type (might be due to invalid IL or missing references)
		//IL_0017: Unknown result type (might be due to invalid IL or missing references)
		_rider.anchorLocalPosition = _rider.carryZone.zoneTransform.InverseTransformPoint(_rb.worldCenterOfMass);
		_rider.anchorRelativeYaw = ZoneRelativeYaw(_rider.carryZone, _rb);
		_rider.anchorLocked = true;
		_rider.anchorCaughtUp = false;
	}

	private void RiderAnchorZoneTransfer(Rider _rider, CarryZone _newZone)
	{
		//IL_0015: Unknown result type (might be due to invalid IL or missing references)
		//IL_001a: Unknown result type (might be due to invalid IL or missing references)
		//IL_001f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0027: Unknown result type (might be due to invalid IL or missing references)
		//IL_0028: Unknown result type (might be due to invalid IL or missing references)
		//IL_002d: Unknown result type (might be due to invalid IL or missing references)
		//IL_003e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0058: Unknown result type (might be due to invalid IL or missing references)
		if (_rider.anchorLocked)
		{
			Vector3 val = _rider.carryZone.zoneTransform.TransformPoint(_rider.anchorLocalPosition);
			_rider.anchorLocalPosition = _newZone.zoneTransform.InverseTransformPoint(val);
			float num = FlatYaw(_rider.carryZone.zoneTransform.rotation) + _rider.anchorRelativeYaw;
			_rider.anchorRelativeYaw = Mathf.DeltaAngle(FlatYaw(_newZone.zoneTransform.rotation), num);
		}
	}

	private void RiderAnchorCaughtUpCheck(Rider _rider, Rigidbody _rb, Vector3 _pointVelocity)
	{
		//IL_000a: Unknown result type (might be due to invalid IL or missing references)
		//IL_000f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0010: Unknown result type (might be due to invalid IL or missing references)
		//IL_0015: Unknown result type (might be due to invalid IL or missing references)
		if (!_rider.anchorCaughtUp)
		{
			Vector3 val = _rb.linearVelocity - _pointVelocity;
			val.y = 0f;
			if (val.magnitude < anchorLockSpeed)
			{
				_rider.anchorCaughtUp = true;
			}
		}
	}

	private string RiderAnchorBreakReason(Rider _rider, Rigidbody _rb, Vector3 _pointVelocity)
	{
		//IL_00da: Unknown result type (might be due to invalid IL or missing references)
		//IL_00df: Unknown result type (might be due to invalid IL or missing references)
		//IL_000c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0011: Unknown result type (might be due to invalid IL or missing references)
		//IL_0012: Unknown result type (might be due to invalid IL or missing references)
		//IL_0017: Unknown result type (might be due to invalid IL or missing references)
		//IL_00fd: Unknown result type (might be due to invalid IL or missing references)
		//IL_0102: Unknown result type (might be due to invalid IL or missing references)
		//IL_0053: Unknown result type (might be due to invalid IL or missing references)
		//IL_005e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0063: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_009a: Unknown result type (might be due to invalid IL or missing references)
		//IL_009f: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b7: Unknown result type (might be due to invalid IL or missing references)
		//IL_00bc: Unknown result type (might be due to invalid IL or missing references)
		Vector3 val3;
		if (_rider.anchorCaughtUp)
		{
			Vector3 val = _rb.linearVelocity - _pointVelocity;
			val.y = 0f;
			if (val.magnitude > anchorBreakSpeed)
			{
				return "rel speed " + val.magnitude.ToString("F2");
			}
			Vector3 val2 = _rb.angularVelocity - _rider.carryZone.angularVelocity;
			if (val2.magnitude > anchorBreakSpinSpeed)
			{
				return "rel spin " + val2.magnitude.ToString("F2");
			}
			val3 = RiderAnchorDrift(_rider, _rb);
			if (val3.magnitude > anchorBreakDistance)
			{
				val3 = RiderAnchorDrift(_rider, _rb);
				return "drift " + val3.magnitude.ToString("F2");
			}
		}
		else
		{
			val3 = RiderAnchorDrift(_rider, _rb);
			if (val3.magnitude > anchorBreakDistance * 2f)
			{
				val3 = RiderAnchorDrift(_rider, _rb);
				return "catch up drift " + val3.magnitude.ToString("F2");
			}
		}
		if (Mathf.Abs(RiderAnchorYawError(_rider, _rb)) > anchorBreakAngle)
		{
			return "yaw error " + RiderAnchorYawError(_rider, _rb).ToString("F1");
		}
		return null;
	}

	private void CarryAnchorLock(Rider _rider, Rigidbody _rb, Vector3 _pointVelocity)
	{
		//IL_0003: Unknown result type (might be due to invalid IL or missing references)
		//IL_000e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0019: Unknown result type (might be due to invalid IL or missing references)
		//IL_001e: Unknown result type (might be due to invalid IL or missing references)
		//IL_001f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0020: Unknown result type (might be due to invalid IL or missing references)
		//IL_0021: Unknown result type (might be due to invalid IL or missing references)
		//IL_0026: Unknown result type (might be due to invalid IL or missing references)
		//IL_0028: Unknown result type (might be due to invalid IL or missing references)
		//IL_002d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0030: Unknown result type (might be due to invalid IL or missing references)
		//IL_003b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0041: Unknown result type (might be due to invalid IL or missing references)
		//IL_0048: Unknown result type (might be due to invalid IL or missing references)
		//IL_0053: Unknown result type (might be due to invalid IL or missing references)
		//IL_0059: Unknown result type (might be due to invalid IL or missing references)
		//IL_005e: Unknown result type (might be due to invalid IL or missing references)
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0072: Unknown result type (might be due to invalid IL or missing references)
		//IL_0074: Unknown result type (might be due to invalid IL or missing references)
		//IL_007a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0080: Unknown result type (might be due to invalid IL or missing references)
		//IL_0086: Unknown result type (might be due to invalid IL or missing references)
		//IL_00bf: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c4: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d4: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d9: Unknown result type (might be due to invalid IL or missing references)
		//IL_00db: Unknown result type (might be due to invalid IL or missing references)
		//IL_00dd: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e4: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e6: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f1: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f6: Unknown result type (might be due to invalid IL or missing references)
		//IL_00fb: Unknown result type (might be due to invalid IL or missing references)
		//IL_00fe: Unknown result type (might be due to invalid IL or missing references)
		Vector3 val = Vector3.ClampMagnitude(RiderAnchorDrift(_rider, _rb) * anchorStrength, anchorCorrectionMax);
		Vector3 val2 = _pointVelocity + val;
		Vector3 linearVelocity = _rb.linearVelocity;
		Vector3 val3 = new Vector3(linearVelocity.x, 0f, linearVelocity.z);
		Vector3 val4 = new Vector3(val2.x, 0f, val2.z);
		val3 = Vector3.MoveTowards(val3, val4, anchorAccelerationMax * Time.fixedDeltaTime);
		_rb.linearVelocity = new Vector3(val3.x, linearVelocity.y, val3.z);
		float num = Mathf.Clamp(RiderAnchorYawError(_rider, _rb) * (MathF.PI / 180f) * anchorStrength, 0f - anchorSpinCorrectionMax, anchorSpinCorrectionMax);
		float num2 = Vector3.Dot(_rider.carryZone.angularVelocity, Vector3.up) + num;
		Vector3 angularVelocity = _rb.angularVelocity;
		angularVelocity += Vector3.up * (num2 - Vector3.Dot(angularVelocity, Vector3.up));
		_rb.angularVelocity = angularVelocity;
	}

	private Vector3 RiderAnchorDrift(Rider _rider, Rigidbody _rb)
	{
		//IL_000c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0011: Unknown result type (might be due to invalid IL or missing references)
		//IL_0017: Unknown result type (might be due to invalid IL or missing references)
		//IL_001c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0021: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Unknown result type (might be due to invalid IL or missing references)
		Vector3 result = _rider.carryZone.zoneTransform.TransformPoint(_rider.anchorLocalPosition) - _rb.worldCenterOfMass;
		result.y = 0f;
		return result;
	}

	private float RiderAnchorYawError(Rider _rider, Rigidbody _rb)
	{
		return Mathf.DeltaAngle(ZoneRelativeYaw(_rider.carryZone, _rb), _rider.anchorRelativeYaw);
	}

	private Vector3 PlayerAnchorCorrection(PlayerController _controller, CarryZone _carryZone)
	{
		//IL_0008: Unknown result type (might be due to invalid IL or missing references)
		//IL_002f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0073: Unknown result type (might be due to invalid IL or missing references)
		//IL_0078: Unknown result type (might be due to invalid IL or missing references)
		//IL_0083: Unknown result type (might be due to invalid IL or missing references)
		//IL_0088: Unknown result type (might be due to invalid IL or missing references)
		//IL_008d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0051: Unknown result type (might be due to invalid IL or missing references)
		//IL_0056: Unknown result type (might be due to invalid IL or missing references)
		//IL_005b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0060: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b7: Unknown result type (might be due to invalid IL or missing references)
		//IL_00be: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c9: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b1: Unknown result type (might be due to invalid IL or missing references)
		if (!anchor)
		{
			return Vector3.zero;
		}
		if (_controller.moving || playerAnchorZone == null || !ZoneMoving(_carryZone))
		{
			PlayerAnchorSet(_controller, _carryZone);
			return Vector3.zero;
		}
		if (playerAnchorZone != _carryZone)
		{
			playerAnchorLocalPosition = _carryZone.zoneTransform.InverseTransformPoint(playerAnchorZone.zoneTransform.TransformPoint(playerAnchorLocalPosition));
			playerAnchorZone = _carryZone;
		}
		Vector3 val = _carryZone.zoneTransform.TransformPoint(playerAnchorLocalPosition) - _controller.rb.position;
		val.y = 0f;
		if (val.magnitude > anchorBreakDistance)
		{
			PlayerAnchorSet(_controller, _carryZone);
			return Vector3.zero;
		}
		return Vector3.ClampMagnitude(val * anchorStrength, anchorCorrectionMax);
	}

	private void PlayerAnchorSet(PlayerController _controller, CarryZone _carryZone)
	{
		//IL_0014: Unknown result type (might be due to invalid IL or missing references)
		//IL_0019: Unknown result type (might be due to invalid IL or missing references)
		//IL_001e: Unknown result type (might be due to invalid IL or missing references)
		playerAnchorZone = _carryZone;
		playerAnchorLocalPosition = _carryZone.zoneTransform.InverseTransformPoint(_controller.rb.position);
	}

	private void DebugLog(string _message)
	{
	}

	private void DebugZoneLog()
	{
	}

	private void DebugRiderLog(Rider _rider, Rigidbody _rb, Vector3 _pointVelocity)
	{
	}

	private void DebugPlayerLog(PlayerController _controller, CarryZone _carryZone, Vector3 _platformVelocity)
	{
	}
}
