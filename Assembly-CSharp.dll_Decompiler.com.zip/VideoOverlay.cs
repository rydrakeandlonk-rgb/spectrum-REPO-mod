using UnityEngine;
using UnityEngine.UI;

public class VideoOverlay : MonoBehaviour
{
	public static VideoOverlay Instance;

	public RawImage RawImage;

	[Space]
	public AnimationCurve IntroCurve;

	public float IntroSpeed;

	private float IntroLerp;

	[Space]
	public float IdleAlpha;

	public float IdleCooldownMin;

	public float IdleCooldownMax;

	private float IdleCooldown;

	public float IdleTimeMin;

	public float IdleTimeMax;

	private float IdleTimer = 0.1f;

	private float OverrideTimer;

	private float OverrideAmount;

	private float OverrideSpeed;

	[RuntimeInitializeOnLoadMethod(/*Could not decode attribute arguments.*/)]
	private static void RuntimeInitializeOnLoad()
	{
		Instance = null;
	}

	private void Awake()
	{
		Instance = this;
	}

	public void Override(float time, float amount, float speed)
	{
		OverrideTimer = time;
		OverrideAmount = amount;
		OverrideSpeed = speed;
	}

	private void Update()
	{
		//IL_0019: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0033: Unknown result type (might be due to invalid IL or missing references)
		//IL_0043: Unknown result type (might be due to invalid IL or missing references)
		//IL_007c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0081: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a7: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ac: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e6: Unknown result type (might be due to invalid IL or missing references)
		//IL_00eb: Unknown result type (might be due to invalid IL or missing references)
		//IL_0182: Unknown result type (might be due to invalid IL or missing references)
		//IL_0187: Unknown result type (might be due to invalid IL or missing references)
		//IL_0107: Unknown result type (might be due to invalid IL or missing references)
		//IL_011c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0121: Unknown result type (might be due to invalid IL or missing references)
		//IL_0131: Unknown result type (might be due to invalid IL or missing references)
		//IL_01f4: Unknown result type (might be due to invalid IL or missing references)
		//IL_01f9: Unknown result type (might be due to invalid IL or missing references)
		//IL_01ad: Unknown result type (might be due to invalid IL or missing references)
		//IL_01b2: Unknown result type (might be due to invalid IL or missing references)
		//IL_0216: Unknown result type (might be due to invalid IL or missing references)
		//IL_022c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0231: Unknown result type (might be due to invalid IL or missing references)
		//IL_0242: Unknown result type (might be due to invalid IL or missing references)
		//IL_0309: Unknown result type (might be due to invalid IL or missing references)
		//IL_030e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0328: Unknown result type (might be due to invalid IL or missing references)
		//IL_033e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0343: Unknown result type (might be due to invalid IL or missing references)
		//IL_0353: Unknown result type (might be due to invalid IL or missing references)
		if (GameDirector.instance.currentState == GameDirector.gameState.Result)
		{
			((Graphic)RawImage).color = Color.Lerp(((Graphic)RawImage).color, Color32.op_Implicit(new Color32(byte.MaxValue, byte.MaxValue, byte.MaxValue, (byte)5)), 5f * Time.deltaTime);
			return;
		}
		if (GameDirector.instance.currentState == GameDirector.gameState.Load || GameDirector.instance.currentState == GameDirector.gameState.End || GameDirector.instance.currentState == GameDirector.gameState.EndWait)
		{
			byte b = 5;
			if (Color32.op_Implicit(((Graphic)RawImage).color).a != b)
			{
				((Graphic)RawImage).color = Color32.op_Implicit(new Color32(byte.MaxValue, byte.MaxValue, byte.MaxValue, b));
			}
			return;
		}
		if ((GameDirector.instance.currentState == GameDirector.gameState.Start && LoadingUI.instance.levelAnimationCompleted) || GameDirector.instance.currentState == GameDirector.gameState.Outro)
		{
			byte b2 = 50;
			if (Color32.op_Implicit(((Graphic)RawImage).color).a != b2)
			{
				((Graphic)RawImage).color = Color.Lerp(((Graphic)RawImage).color, Color32.op_Implicit(new Color32(byte.MaxValue, byte.MaxValue, byte.MaxValue, b2)), Time.deltaTime * 20f);
			}
			return;
		}
		if (IntroLerp < 1f)
		{
			IntroLerp += Time.deltaTime * 0.5f;
			float num = IntroCurve.Evaluate(IntroLerp);
			byte b3 = (byte)(5f * num);
			if (Color32.op_Implicit(((Graphic)RawImage).color).a != b3)
			{
				((Graphic)RawImage).color = Color32.op_Implicit(new Color32(byte.MaxValue, byte.MaxValue, byte.MaxValue, b3));
			}
			return;
		}
		if (OverrideTimer > 0f)
		{
			OverrideTimer -= Time.deltaTime;
			byte b4 = (byte)(255f * OverrideAmount);
			if (Color32.op_Implicit(((Graphic)RawImage).color).a != b4)
			{
				((Graphic)RawImage).color = Color.Lerp(((Graphic)RawImage).color, Color32.op_Implicit(new Color32(byte.MaxValue, byte.MaxValue, byte.MaxValue, b4)), Time.deltaTime * OverrideSpeed);
			}
			return;
		}
		float num2 = 0f;
		if (IdleTimer > 0f)
		{
			IdleTimer -= Time.deltaTime;
			num2 = IdleAlpha;
			if (!GraphicsManager.instance.glitchLoop || Object.op_Implicit((Object)(object)VideoGreenScreen.instance))
			{
				num2 = 0f;
			}
			if (IdleTimer <= 0f)
			{
				IdleCooldown = Random.Range(IdleCooldownMin, IdleCooldownMax);
			}
		}
		else if (IdleCooldown > 0f)
		{
			IdleCooldown -= Time.deltaTime;
		}
		else
		{
			IdleTimer = Random.Range(IdleTimeMin, IdleTimeMax);
		}
		byte b5 = (byte)(100f * num2);
		if (Color32.op_Implicit(((Graphic)RawImage).color).a != b5)
		{
			((Graphic)RawImage).color = Color.Lerp(((Graphic)RawImage).color, Color32.op_Implicit(new Color32(byte.MaxValue, byte.MaxValue, byte.MaxValue, b5)), Time.deltaTime * 1f);
		}
	}
}
