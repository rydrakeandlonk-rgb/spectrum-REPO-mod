using TMPro;
using UnityEngine;
using UnityEngine.UI;

public class OverchargeUI : SemiUI
{
	private TextMeshProUGUI Text;

	public static OverchargeUI instance;

	public TextMeshProUGUI textOverchargeMax;

	private float warningTimer;

	public Sound soundOverchargeWarning;

	public Image roundBar;

	public OverchargeRoundBarUI overchargeRoundBarUI;

	[RuntimeInitializeOnLoadMethod(/*Could not decode attribute arguments.*/)]
	private static void RuntimeInitializeOnLoad()
	{
		instance = null;
	}

	protected override void Start()
	{
		base.Start();
		Text = ((Component)this).GetComponent<TextMeshProUGUI>();
		instance = this;
	}

	protected override void Update()
	{
		//IL_01c8: Unknown result type (might be due to invalid IL or missing references)
		//IL_01dd: Unknown result type (might be due to invalid IL or missing references)
		//IL_01fd: Unknown result type (might be due to invalid IL or missing references)
		base.Update();
		if (!PlayerAvatar.instance.isDisabled)
		{
			if (!Object.op_Implicit((Object)(object)PhysGrabber.instance) || (Object.op_Implicit((Object)(object)PhysGrabber.instance) && PhysGrabber.instance.physGrabBeamOverChargeFloat <= 0f))
			{
				Hide();
			}
		}
		else
		{
			Hide();
		}
		if (!isHidden)
		{
			float num = Mathf.Ceil(PhysGrabber.instance.physGrabBeamOverChargeFloat * 100f);
			if (!((Behaviour)roundBar).enabled)
			{
				((Behaviour)roundBar).enabled = true;
			}
			roundBar.fillAmount = num / 100f;
			((TMP_Text)Text).text = num.ToString();
			((TMP_Text)textOverchargeMax).text = "<b><color=red>/</color></b>" + Mathf.Ceil(100f);
			if (PhysGrabber.instance.grabbed && Object.op_Implicit((Object)(object)PhysGrabber.instance.grabbedPhysGrabObject) && PhysGrabber.instance.grabbedPhysGrabObject.isEnemy)
			{
				if (num > 70f)
				{
					warningTimer += Time.deltaTime * 2f;
				}
				if (num > 80f)
				{
					warningTimer += Time.deltaTime * 2f;
				}
				if (num > 90f)
				{
					warningTimer += Time.deltaTime * 2f;
				}
				if (num > 95f)
				{
					warningTimer += Time.deltaTime * 2f;
				}
			}
			else if (num > 90f)
			{
				warningTimer += Time.deltaTime * 2f;
			}
			if (warningTimer > 1f)
			{
				Color color = new Color(1f, 0.6f, 0f);
				soundOverchargeWarning.Play(((Component)PlayerAvatar.instance).transform.position);
				SemiUITextFlashColor(color, 0.05f);
				SemiUISpringScale(1.1f, 0.25f, 0.05f);
				warningTimer = 0f;
			}
		}
		else if (((Behaviour)roundBar).enabled)
		{
			((Behaviour)roundBar).enabled = false;
		}
	}
}
