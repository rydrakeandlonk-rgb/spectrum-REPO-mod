using UnityEngine;

public class PropLight : MonoBehaviour
{
	public bool levelLight = true;

	internal bool turnedOff;

	[Range(0f, 2f)]
	public float lightRangeMultiplier = 1f;

	internal Light lightComponent;

	internal float originalIntensity;

	internal Behaviour halo;

	internal bool hasHalo;

	internal PropLightFlickering propLightFlickering;

	internal float fadeEndTime;

	private void Awake()
	{
		lightComponent = ((Component)this).GetComponent<Light>();
		originalIntensity = lightComponent.intensity;
		Component component = ((Component)this).GetComponent("Halo");
		halo = (Behaviour)(object)((component is Behaviour) ? component : null);
		if (Object.op_Implicit((Object)(object)halo))
		{
			hasHalo = true;
		}
	}

	private void Start()
	{
		if (LevelGenerator.Instance.Generated)
		{
			SemiFunc.LightAdd(this);
		}
	}

	public void SetIntensity(float intensity)
	{
		lightComponent.intensity = intensity;
		originalIntensity = intensity;
	}
}
