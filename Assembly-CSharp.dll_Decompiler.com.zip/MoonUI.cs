using System.Collections.Generic;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

public class MoonUI : MonoBehaviour
{
	public enum State
	{
		None,
		Start,
		FadeIn,
		Show,
		Turn,
		Title,
		Attributes,
		Wait,
		Hide
	}

	public static MoonUI instance;

	internal bool debugNoWait;

	internal bool debugDisable;

	internal State state;

	private float stateTimer;

	private bool stateImpulse = true;

	public GameObject objectActive;

	[Space]
	public RawImage backgroundImage;

	public AnimationCurve backgroundCurve;

	private float backgroundLerp;

	[Space]
	public RectTransform showTransform;

	public AnimationCurve showCurve;

	public float showStartPosition;

	private float showLerp;

	[Space]
	public RectTransform turnTransform;

	public AnimationCurve turnCurve;

	public float turnStartPosition;

	private float turnLerp;

	[Space]
	public RectTransform turnBackTransform;

	public float turnBackStartPosition;

	[Space]
	public RectTransform turnPatternTransform;

	public float turnPatternStartPosition;

	[Space]
	public AnimationCurve pieceFadeCurve;

	private float pieceFadeLerp;

	[Space]
	public RectTransform titleTransform;

	public AnimationCurve titleCurve;

	private float titleLerp;

	[Space]
	public AnimationCurve hideCurve;

	public float hidePosition;

	private float hideLerp;

	private Vector3 hideStartPosition;

	[Space]
	public RectTransform shakeTransform;

	private float shakeTargetY;

	private float shakeTargetX;

	private float shakeTimer;

	private float shakeAmount;

	private float shakeAmountDecrease;

	private bool shakeImpulse;

	[Space]
	public RectTransform topCornerTransform;

	public RectTransform topCornerShakeTransform;

	public float topCornerStartPosition;

	public RawImage topCornerGraphicRight;

	public RawImage topCornerGraphicLeft;

	public RectTransform topCornerTransformRight;

	public RectTransform topCornerTransformLeft;

	[Space]
	public RectTransform botCornerTransform;

	public RectTransform botCornerShakeTransform;

	public float botCornerStartPosition;

	public RawImage botCornerGraphicRight;

	public RawImage botCornerGraphicLeft;

	public RectTransform botCornerTransformRight;

	public RectTransform botCornerTransformLeft;

	[Space]
	public RawImage moonGraphicPreviousest;

	public RawImage moonGraphicPrevious;

	public RawImage moonGraphicCurrent;

	public RawImage moonGraphicNext;

	[Space]
	public Color pieceFadeDefault;

	[Space]
	public TextMeshProUGUI textTitle;

	public GameObject attributesParent;

	public GameObject attributesPrefab;

	private List<Moon.MoonAttribute> attributes = new List<Moon.MoonAttribute>();

	private int attributesIndex;

	[Space]
	public RectTransform skipTransform;

	public LocalizedAsset localizedSkipText;

	public TextMeshProUGUI skipText;

	public float skipStartPosition;

	private bool skip;

	private List<InputKey> skipSharedKeys = new List<InputKey>();

	private bool skipSharedKeysActive;

	private SpringFloat skipTextSpring = new SpringFloat
	{
		damping = 0.4f,
		speed = 30f,
		lastPosition = 1f
	};

	[Space]
	public Sound soundShow;

	public Sound soundTurnStart;

	public Sound soundTurning;

	private bool soundTurningImpulse = true;

	public Sound soundTurnEnd;

	public Sound soundTitle;

	public Sound soundAttribute;

	public Sound soundHide;

	private bool tutorialImpulse = true;

	[RuntimeInitializeOnLoadMethod(/*Could not decode attribute arguments.*/)]
	private static void RuntimeInitializeOnLoad()
	{
		instance = null;
	}

	private void Awake()
	{
		instance = this;
		objectActive.SetActive(false);
		InputGlyphs.OnGlyphsChanged += SkipTextGlyphsChanged;
	}

	private void OnDestroy()
	{
		InputGlyphs.OnGlyphsChanged -= SkipTextGlyphsChanged;
	}

	private void Update()
	{
		switch (state)
		{
		case State.None:
			StateNone();
			break;
		case State.Start:
			StateStart();
			break;
		case State.FadeIn:
			StateFadeIn();
			break;
		case State.Show:
			StateShow();
			break;
		case State.Turn:
			StateTurn();
			break;
		case State.Title:
			StateTitle();
			break;
		case State.Attributes:
			StateAttributes();
			break;
		case State.Wait:
			StateWait();
			break;
		case State.Hide:
			StateHide();
			break;
		}
		if (state != State.None)
		{
			BackgroundLogic();
			MoonRotateLogic();
			TurnLogic();
			ShakeLogic();
			RotateLogic();
			SkipLogic();
		}
	}

	private void StateNone()
	{
		//IL_0031: Unknown result type (might be due to invalid IL or missing references)
		//IL_005c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0061: Unknown result type (might be due to invalid IL or missing references)
		//IL_008c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0091: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a7: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b7: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c7: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d6: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ec: Unknown result type (might be due to invalid IL or missing references)
		//IL_00fc: Unknown result type (might be due to invalid IL or missing references)
		//IL_010c: Unknown result type (might be due to invalid IL or missing references)
		//IL_012c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0131: Unknown result type (might be due to invalid IL or missing references)
		//IL_0147: Unknown result type (might be due to invalid IL or missing references)
		//IL_015d: Unknown result type (might be due to invalid IL or missing references)
		//IL_016d: Unknown result type (might be due to invalid IL or missing references)
		//IL_017d: Unknown result type (might be due to invalid IL or missing references)
		//IL_019d: Unknown result type (might be due to invalid IL or missing references)
		//IL_01bd: Unknown result type (might be due to invalid IL or missing references)
		//IL_01dd: Unknown result type (might be due to invalid IL or missing references)
		//IL_0200: Unknown result type (might be due to invalid IL or missing references)
		//IL_0224: Unknown result type (might be due to invalid IL or missing references)
		//IL_0235: Unknown result type (might be due to invalid IL or missing references)
		//IL_0246: Unknown result type (might be due to invalid IL or missing references)
		//IL_0297: Unknown result type (might be due to invalid IL or missing references)
		//IL_02e9: Unknown result type (might be due to invalid IL or missing references)
		//IL_02ee: Unknown result type (might be due to invalid IL or missing references)
		if (!stateImpulse)
		{
			return;
		}
		objectActive.SetActive(false);
		((Graphic)backgroundImage).color = new Color(0f, 0f, 0f, 0f);
		backgroundLerp = 0f;
		showTransform.anchoredPosition = Vector2.op_Implicit(new Vector3(0f, showStartPosition, 0f));
		showLerp = 0f;
		topCornerTransform.anchoredPosition = Vector2.op_Implicit(new Vector3(0f, topCornerStartPosition, 0f));
		((Graphic)topCornerGraphicRight).color = new Color(((Graphic)topCornerGraphicRight).color.r, ((Graphic)topCornerGraphicRight).color.g, ((Graphic)topCornerGraphicRight).color.b, 0f);
		((Graphic)topCornerGraphicLeft).color = ((Graphic)topCornerGraphicRight).color;
		((Transform)topCornerTransformRight).rotation = Quaternion.identity;
		((Transform)topCornerTransformLeft).rotation = Quaternion.identity;
		botCornerTransform.anchoredPosition = Vector2.op_Implicit(new Vector3(0f, botCornerStartPosition, 0f));
		((Graphic)botCornerGraphicRight).color = ((Graphic)topCornerGraphicLeft).color;
		((Graphic)botCornerGraphicLeft).color = ((Graphic)topCornerGraphicLeft).color;
		((Transform)botCornerTransformRight).rotation = Quaternion.identity;
		((Transform)botCornerTransformLeft).rotation = Quaternion.identity;
		((Transform)turnTransform).localEulerAngles = new Vector3(0f, 0f, turnStartPosition);
		((Transform)turnBackTransform).localEulerAngles = new Vector3(0f, 0f, turnBackStartPosition);
		((Transform)turnPatternTransform).localEulerAngles = new Vector3(0f, 0f, turnPatternStartPosition);
		turnLerp = 0f;
		soundTurningImpulse = true;
		((Graphic)moonGraphicPreviousest).color = pieceFadeDefault;
		((Graphic)moonGraphicPrevious).color = new Color(1f, 1f, 1f, 1f);
		((Graphic)moonGraphicCurrent).color = pieceFadeDefault;
		((Graphic)moonGraphicNext).color = pieceFadeDefault;
		pieceFadeLerp = 0f;
		((Component)titleTransform).gameObject.SetActive(false);
		titleLerp = 0f;
		attributesIndex = 0;
		foreach (Transform item in attributesParent.transform)
		{
			Object.Destroy((Object)(object)((Component)item).gameObject);
		}
		hideLerp = 0f;
		skip = false;
		skipTransform.anchoredPosition = Vector2.op_Implicit(new Vector3(0f, skipStartPosition, 0f));
		tutorialImpulse = true;
		stateImpulse = false;
	}

	private void StateStart()
	{
		if (stateImpulse)
		{
			stateTimer = 1f;
			if (debugNoWait)
			{
				stateTimer = 0.1f;
			}
			objectActive.SetActive(true);
			SkipTextRefresh();
			skipSharedKeys = InputManager.instance.GetKeysSharingControls(InputKey.Back);
			skipSharedKeysActive = true;
			stateImpulse = false;
		}
		stateTimer -= Time.deltaTime;
		if (stateTimer <= 0f)
		{
			SetState(State.FadeIn);
		}
	}

	private void StateFadeIn()
	{
		if (stateImpulse)
		{
			stateTimer = 0.5f;
			stateImpulse = false;
		}
		stateTimer -= Time.deltaTime;
		if (stateTimer <= 0f)
		{
			SetState(State.Show);
		}
	}

	private void StateShow()
	{
		//IL_000e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0093: Unknown result type (might be due to invalid IL or missing references)
		//IL_0098: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ae: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d8: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ee: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f3: Unknown result type (might be due to invalid IL or missing references)
		//IL_0113: Unknown result type (might be due to invalid IL or missing references)
		//IL_0118: Unknown result type (might be due to invalid IL or missing references)
		//IL_012e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0133: Unknown result type (might be due to invalid IL or missing references)
		//IL_0153: Unknown result type (might be due to invalid IL or missing references)
		//IL_0158: Unknown result type (might be due to invalid IL or missing references)
		//IL_016e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0173: Unknown result type (might be due to invalid IL or missing references)
		//IL_0189: Unknown result type (might be due to invalid IL or missing references)
		//IL_0199: Unknown result type (might be due to invalid IL or missing references)
		//IL_01a9: Unknown result type (might be due to invalid IL or missing references)
		//IL_01b8: Unknown result type (might be due to invalid IL or missing references)
		//IL_01c3: Unknown result type (might be due to invalid IL or missing references)
		//IL_01d3: Unknown result type (might be due to invalid IL or missing references)
		//IL_01e3: Unknown result type (might be due to invalid IL or missing references)
		//IL_01f2: Unknown result type (might be due to invalid IL or missing references)
		//IL_0208: Unknown result type (might be due to invalid IL or missing references)
		//IL_021e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0234: Unknown result type (might be due to invalid IL or missing references)
		//IL_024a: Unknown result type (might be due to invalid IL or missing references)
		if (stateImpulse)
		{
			soundShow.Play(Vector3.zero);
			stateTimer = 1f;
			shakeAmount = 1f;
			shakeAmountDecrease = 0.1f;
			stateImpulse = false;
		}
		if (showLerp < 1f)
		{
			showLerp += Time.deltaTime * 1.5f;
			showTransform.anchoredPosition = Vector2.op_Implicit(Vector3.LerpUnclamped(new Vector3(0f, showStartPosition, 0f), Vector3.zero, showCurve.Evaluate(showLerp)));
			skipTransform.anchoredPosition = Vector2.op_Implicit(Vector3.LerpUnclamped(new Vector3(0f, skipStartPosition, 0f), Vector3.zero, showCurve.Evaluate(showLerp)));
			topCornerTransform.anchoredPosition = Vector2.op_Implicit(Vector3.LerpUnclamped(new Vector3(0f, topCornerStartPosition, 0f), Vector3.zero, showCurve.Evaluate(showLerp)));
			botCornerTransform.anchoredPosition = Vector2.op_Implicit(Vector3.LerpUnclamped(new Vector3(0f, botCornerStartPosition, 0f), Vector3.zero, showCurve.Evaluate(showLerp)));
			((Graphic)topCornerGraphicRight).color = Color.Lerp(new Color(((Graphic)topCornerGraphicRight).color.r, ((Graphic)topCornerGraphicRight).color.g, ((Graphic)topCornerGraphicRight).color.b, 0f), new Color(((Graphic)topCornerGraphicRight).color.r, ((Graphic)topCornerGraphicRight).color.g, ((Graphic)topCornerGraphicRight).color.b, 1f), showCurve.Evaluate(showLerp));
			((Graphic)topCornerGraphicLeft).color = ((Graphic)topCornerGraphicRight).color;
			((Graphic)botCornerGraphicRight).color = ((Graphic)topCornerGraphicLeft).color;
			((Graphic)botCornerGraphicLeft).color = ((Graphic)topCornerGraphicLeft).color;
		}
		stateTimer -= Time.deltaTime;
		if (stateTimer <= 0f)
		{
			SetState(State.Turn);
		}
	}

	private void StateTurn()
	{
		//IL_0019: Unknown result type (might be due to invalid IL or missing references)
		if (stateImpulse)
		{
			stateTimer = 2.5f;
			soundTurnStart.Play(Vector3.zero);
			shakeAmount = 2f;
			shakeAmountDecrease = 0.5f;
			shakeImpulse = true;
			stateImpulse = false;
		}
		stateTimer -= Time.deltaTime;
		if (stateTimer <= 0f)
		{
			SetState(State.Title);
		}
	}

	private void StateTitle()
	{
		//IL_001f: Unknown result type (might be due to invalid IL or missing references)
		//IL_009b: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a0: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b6: Unknown result type (might be due to invalid IL or missing references)
		if (stateImpulse)
		{
			((Component)titleTransform).gameObject.SetActive(true);
			soundTitle.Play(Vector3.zero);
			shakeAmount = 1f;
			shakeAmountDecrease = 0.2f;
			stateTimer = 1f;
			stateImpulse = false;
		}
		if (titleLerp < 1f)
		{
			titleLerp += Time.deltaTime * 5f;
			titleTransform.anchoredPosition = Vector2.LerpUnclamped(new Vector2(0f, -10f), Vector2.zero, titleCurve.Evaluate(titleLerp));
		}
		stateTimer -= Time.deltaTime;
		if (stateTimer <= 0f)
		{
			SetState(State.Attributes);
		}
	}

	private void StateAttributes()
	{
		//IL_0039: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d2: Unknown result type (might be due to invalid IL or missing references)
		if (stateImpulse)
		{
			stateImpulse = false;
			stateTimer = 1f;
			if (attributesIndex >= attributes.Count)
			{
				SetState(State.Wait);
				return;
			}
			soundAttribute.Play(Vector3.zero);
			MoonAttributeUI component = Object.Instantiate<GameObject>(attributesPrefab, attributesParent.transform).GetComponent<MoonAttributeUI>();
			((TMP_Text)component.text).text = attributes[attributesIndex].LocalizedText?.GetLocalizedString() ?? attributes[attributesIndex].text;
			component.rect.anchoredPosition = new Vector2(0f, -18f * (float)attributesIndex);
			attributesIndex++;
		}
		stateTimer -= Time.deltaTime;
		if (stateTimer <= 0f)
		{
			stateImpulse = true;
		}
	}

	private void StateWait()
	{
		if (stateImpulse)
		{
			stateImpulse = false;
			stateTimer = 4f;
		}
		stateTimer -= Time.deltaTime;
		if (stateTimer <= 0f)
		{
			SetState(State.Hide);
		}
	}

	private void StateHide()
	{
		//IL_0069: Unknown result type (might be due to invalid IL or missing references)
		//IL_0032: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f3: Unknown result type (might be due to invalid IL or missing references)
		//IL_0108: Unknown result type (might be due to invalid IL or missing references)
		//IL_011e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0123: Unknown result type (might be due to invalid IL or missing references)
		//IL_0133: Unknown result type (might be due to invalid IL or missing references)
		//IL_0148: Unknown result type (might be due to invalid IL or missing references)
		//IL_015e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0163: Unknown result type (might be due to invalid IL or missing references)
		//IL_0173: Unknown result type (might be due to invalid IL or missing references)
		//IL_0188: Unknown result type (might be due to invalid IL or missing references)
		//IL_019e: Unknown result type (might be due to invalid IL or missing references)
		//IL_01a3: Unknown result type (might be due to invalid IL or missing references)
		//IL_01b3: Unknown result type (might be due to invalid IL or missing references)
		//IL_01c8: Unknown result type (might be due to invalid IL or missing references)
		//IL_01de: Unknown result type (might be due to invalid IL or missing references)
		//IL_01e3: Unknown result type (might be due to invalid IL or missing references)
		//IL_01f9: Unknown result type (might be due to invalid IL or missing references)
		//IL_0209: Unknown result type (might be due to invalid IL or missing references)
		//IL_0219: Unknown result type (might be due to invalid IL or missing references)
		//IL_0228: Unknown result type (might be due to invalid IL or missing references)
		//IL_0233: Unknown result type (might be due to invalid IL or missing references)
		//IL_0243: Unknown result type (might be due to invalid IL or missing references)
		//IL_0253: Unknown result type (might be due to invalid IL or missing references)
		//IL_0262: Unknown result type (might be due to invalid IL or missing references)
		//IL_0278: Unknown result type (might be due to invalid IL or missing references)
		//IL_028e: Unknown result type (might be due to invalid IL or missing references)
		//IL_02a4: Unknown result type (might be due to invalid IL or missing references)
		//IL_02ba: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a5: Unknown result type (might be due to invalid IL or missing references)
		//IL_00aa: Unknown result type (might be due to invalid IL or missing references)
		//IL_00af: Unknown result type (might be due to invalid IL or missing references)
		if (stateImpulse)
		{
			tutorialImpulse = true;
			stateImpulse = false;
			stateTimer = 4f;
			if (skip)
			{
				AudioSource val = soundHide.Play(Vector3.zero);
				val.pitch *= 2f;
			}
			else
			{
				soundHide.Play(Vector3.zero);
			}
			shakeAmount = 1.5f;
			shakeAmountDecrease = 0.1f;
			hideStartPosition = Vector2.op_Implicit(showTransform.anchoredPosition);
		}
		if (hideLerp <= 1f)
		{
			float num = 1f;
			if (skip)
			{
				num = 5f;
			}
			hideLerp += num * Time.deltaTime;
			showTransform.anchoredPosition = Vector2.op_Implicit(Vector3.LerpUnclamped(hideStartPosition, new Vector3(0f, hidePosition, 0f), hideCurve.Evaluate(hideLerp)));
			skipTransform.anchoredPosition = Vector2.op_Implicit(Vector3.LerpUnclamped(Vector3.zero, new Vector3(0f, skipStartPosition, 0f), hideCurve.Evaluate(hideLerp)));
			topCornerTransform.anchoredPosition = Vector2.op_Implicit(Vector3.LerpUnclamped(Vector3.zero, new Vector3(0f, topCornerStartPosition, 0f), hideCurve.Evaluate(hideLerp)));
			botCornerTransform.anchoredPosition = Vector2.op_Implicit(Vector3.LerpUnclamped(Vector3.zero, new Vector3(0f, botCornerStartPosition, 0f), hideCurve.Evaluate(hideLerp)));
			((Graphic)topCornerGraphicRight).color = Color.Lerp(new Color(((Graphic)topCornerGraphicRight).color.r, ((Graphic)topCornerGraphicRight).color.g, ((Graphic)topCornerGraphicRight).color.b, 1f), new Color(((Graphic)topCornerGraphicRight).color.r, ((Graphic)topCornerGraphicRight).color.g, ((Graphic)topCornerGraphicRight).color.b, 0f), hideCurve.Evaluate(hideLerp));
			((Graphic)topCornerGraphicLeft).color = ((Graphic)topCornerGraphicRight).color;
			((Graphic)botCornerGraphicRight).color = ((Graphic)topCornerGraphicLeft).color;
			((Graphic)botCornerGraphicLeft).color = ((Graphic)topCornerGraphicLeft).color;
		}
		stateTimer -= Time.deltaTime;
		if (tutorialImpulse && hideLerp > 0.5f)
		{
			Tutorials();
			tutorialImpulse = false;
		}
		if (stateTimer <= 0f)
		{
			SetState(State.None);
		}
	}

	public void Check()
	{
		//IL_008b: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ce: Unknown result type (might be due to invalid IL or missing references)
		//IL_010f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0152: Unknown result type (might be due to invalid IL or missing references)
		if (!SemiFunc.RunIsLevel() || !RunManager.instance.moonLevelChanged)
		{
			return;
		}
		if (!debugDisable && RunManager.instance.moonLevel > 0 && RunManager.instance.moonLevel <= RunManager.instance.moons.Count)
		{
			moonGraphicPreviousest.texture = RunManager.instance.MoonGetIcon(RunManager.instance.moonLevel - 2);
			if (!Object.op_Implicit((Object)(object)moonGraphicPreviousest.texture))
			{
				((Graphic)moonGraphicPreviousest).color = Color.clear;
			}
			moonGraphicPrevious.texture = RunManager.instance.MoonGetIcon(RunManager.instance.moonLevel - 1);
			if (!Object.op_Implicit((Object)(object)moonGraphicPrevious.texture))
			{
				((Graphic)moonGraphicPrevious).color = Color.clear;
			}
			moonGraphicCurrent.texture = RunManager.instance.MoonGetIcon(RunManager.instance.moonLevel);
			if (!Object.op_Implicit((Object)(object)moonGraphicCurrent.texture))
			{
				((Graphic)moonGraphicCurrent).color = Color.clear;
			}
			moonGraphicNext.texture = RunManager.instance.MoonGetIcon(RunManager.instance.moonLevel + 1);
			if (!Object.op_Implicit((Object)(object)moonGraphicNext.texture))
			{
				((Graphic)moonGraphicNext).color = Color.clear;
			}
			((TMP_Text)textTitle).text = RunManager.instance.MoonGetName(RunManager.instance.moonLevel);
			attributes = RunManager.instance.MoonGetAttributes(RunManager.instance.moonLevel);
			SetState(State.Start);
		}
		RunManager.instance.moonLevelChanged = false;
	}

	public void SetState(State _state)
	{
		if (state != _state)
		{
			state = _state;
			stateImpulse = true;
		}
	}

	private void BackgroundLogic()
	{
		//IL_00e0: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f9: Unknown result type (might be due to invalid IL or missing references)
		//IL_010f: Unknown result type (might be due to invalid IL or missing references)
		//IL_005e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0077: Unknown result type (might be due to invalid IL or missing references)
		//IL_008d: Unknown result type (might be due to invalid IL or missing references)
		if (state >= State.Hide)
		{
			if (backgroundLerp > 0f)
			{
				float num = 0.5f;
				if (skip)
				{
					num = 3f;
				}
				backgroundLerp -= num * Time.deltaTime;
				((Graphic)backgroundImage).color = Color.Lerp(new Color(0f, 0f, 0f, 0f), new Color(0f, 0f, 0f, 0.85f), backgroundCurve.Evaluate(backgroundLerp));
			}
		}
		else if (state >= State.FadeIn && backgroundLerp < 1f)
		{
			backgroundLerp += Time.deltaTime * 1f;
			((Graphic)backgroundImage).color = Color.Lerp(new Color(0f, 0f, 0f, 0f), new Color(0f, 0f, 0f, 0.85f), backgroundCurve.Evaluate(backgroundLerp));
		}
	}

	private void MoonRotateLogic()
	{
		//IL_000b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0020: Unknown result type (might be due to invalid IL or missing references)
		//IL_0035: Unknown result type (might be due to invalid IL or missing references)
		//IL_004a: Unknown result type (might be due to invalid IL or missing references)
		((Component)moonGraphicPreviousest).transform.rotation = Quaternion.identity;
		((Component)moonGraphicPrevious).transform.rotation = Quaternion.identity;
		((Component)moonGraphicCurrent).transform.rotation = Quaternion.identity;
		((Component)moonGraphicNext).transform.rotation = Quaternion.identity;
	}

	private void TurnLogic()
	{
		//IL_004a: Unknown result type (might be due to invalid IL or missing references)
		//IL_004f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0065: Unknown result type (might be due to invalid IL or missing references)
		//IL_0085: Unknown result type (might be due to invalid IL or missing references)
		//IL_008a: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a0: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c0: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c5: Unknown result type (might be due to invalid IL or missing references)
		//IL_00db: Unknown result type (might be due to invalid IL or missing references)
		//IL_01d1: Unknown result type (might be due to invalid IL or missing references)
		//IL_01d7: Unknown result type (might be due to invalid IL or missing references)
		//IL_01ed: Unknown result type (might be due to invalid IL or missing references)
		//IL_0100: Unknown result type (might be due to invalid IL or missing references)
		//IL_0210: Unknown result type (might be due to invalid IL or missing references)
		//IL_0229: Unknown result type (might be due to invalid IL or missing references)
		//IL_023f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0157: Unknown result type (might be due to invalid IL or missing references)
		if (state < State.Turn)
		{
			return;
		}
		if (turnLerp < 1f)
		{
			turnLerp += Time.deltaTime * 0.3f;
			((Transform)turnTransform).localEulerAngles = Vector3.LerpUnclamped(new Vector3(0f, 0f, turnStartPosition), Vector3.zero, turnCurve.Evaluate(turnLerp));
			((Transform)turnBackTransform).localEulerAngles = Vector3.LerpUnclamped(new Vector3(0f, 0f, turnBackStartPosition), Vector3.zero, turnCurve.Evaluate(turnLerp));
			((Transform)turnPatternTransform).localEulerAngles = Vector3.LerpUnclamped(new Vector3(0f, 0f, turnPatternStartPosition), Vector3.zero, turnCurve.Evaluate(turnLerp));
			if (shakeImpulse && turnLerp > 0.5f)
			{
				soundTurnEnd.Play(Vector3.zero);
				shakeImpulse = false;
				shakeAmount = 3f;
				shakeAmountDecrease = 0.5f;
			}
			if (soundTurningImpulse && turnLerp > 0.3f)
			{
				soundTurning.Play(Vector3.zero);
				soundTurningImpulse = false;
			}
		}
		if (pieceFadeLerp < 1f)
		{
			pieceFadeLerp += Time.deltaTime * 0.3f;
			if (Object.op_Implicit((Object)(object)moonGraphicPrevious.texture))
			{
				((Graphic)moonGraphicPrevious).color = Color.Lerp(new Color(1f, 1f, 1f, 1f), pieceFadeDefault, pieceFadeCurve.Evaluate(pieceFadeLerp));
			}
			if (Object.op_Implicit((Object)(object)moonGraphicCurrent.texture))
			{
				((Graphic)moonGraphicCurrent).color = Color.Lerp(pieceFadeDefault, new Color(1f, 1f, 1f, 1f), pieceFadeCurve.Evaluate(pieceFadeLerp));
			}
		}
	}

	private void ShakeLogic()
	{
		//IL_008b: Unknown result type (might be due to invalid IL or missing references)
		//IL_009c: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ac: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c2: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00dd: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ed: Unknown result type (might be due to invalid IL or missing references)
		//IL_0103: Unknown result type (might be due to invalid IL or missing references)
		//IL_0114: Unknown result type (might be due to invalid IL or missing references)
		//IL_011e: Unknown result type (might be due to invalid IL or missing references)
		//IL_012e: Unknown result type (might be due to invalid IL or missing references)
		if (shakeAmount > 0f)
		{
			if (shakeTimer <= 0f)
			{
				shakeTimer = 0.05f;
				shakeTargetX = Random.Range(0f - shakeAmount, shakeAmount);
				shakeTargetY = Random.Range(0f - shakeAmount, shakeAmount);
				shakeAmount -= shakeAmountDecrease;
			}
			else
			{
				shakeTimer -= Time.deltaTime;
			}
			shakeTransform.anchoredPosition = Vector2.Lerp(shakeTransform.anchoredPosition, new Vector2(shakeTargetX, shakeTargetY), 30f * Time.deltaTime);
			topCornerShakeTransform.anchoredPosition = Vector2.Lerp(shakeTransform.anchoredPosition, new Vector2(shakeTargetX, shakeTargetY) * 0.25f, 30f * Time.deltaTime);
			botCornerShakeTransform.anchoredPosition = Vector2.Lerp(shakeTransform.anchoredPosition, new Vector2(shakeTargetX, shakeTargetY) * 0.25f, 30f * Time.deltaTime);
		}
	}

	private void RotateLogic()
	{
		((Transform)topCornerTransformRight).Rotate(0f, 0f, Time.deltaTime * 5f);
		((Transform)topCornerTransformLeft).Rotate(0f, 0f, (0f - Time.deltaTime) * 5f);
		((Transform)botCornerTransformRight).Rotate(0f, 0f, Time.deltaTime * 5f);
		((Transform)botCornerTransformLeft).Rotate(0f, 0f, (0f - Time.deltaTime) * 5f);
	}

	private void SkipLogic()
	{
		//IL_00b3: Unknown result type (might be due to invalid IL or missing references)
		if (state != State.Hide && state != State.None)
		{
			if (SemiFunc.InputDown(InputKey.Back))
			{
				skip = true;
				SetState(State.Hide);
			}
			if (state != State.None)
			{
				GameDirector.instance.SetDisableEscMenu(1f);
			}
		}
		if (state == State.Hide && skipSharedKeysActive && !SemiFunc.InputHold(InputKey.Back))
		{
			skipSharedKeysActive = false;
		}
		if (skipSharedKeysActive && skipSharedKeys.Count > 0)
		{
			InputManager.instance.DisableControlsSpecific(0.1f, skipSharedKeys);
		}
		float num = SemiFunc.SpringFloatGet(skipTextSpring, 1f);
		((Transform)((TMP_Text)skipText).rectTransform).localScale = new Vector3(num, num, 1f);
	}

	private void SkipTextRefresh()
	{
		string text = localizedSkipText?.GetLocalizedString() ?? "[back] to skip";
		((TMP_Text)skipText).text = SemiFunc.InputDisplayReplaceTags(text, "<color=#FF8500><u><b>", "</b></u></color>");
	}

	private void SkipTextGlyphsChanged()
	{
		if (state != State.None)
		{
			SkipTextRefresh();
			skipTextSpring.springVelocity = 6f;
		}
	}

	private void Tutorials()
	{
		if (SemiFunc.MoonLevel() == 2 && TutorialDirector.instance.TutorialSettingCheck(DataDirector.Setting.TutorialOvercharge1, 1))
		{
			TutorialDirector.instance.ActivateTip("Overcharge1", 0f, _interrupt: false);
			TutorialDirector.instance.ScheduleTip("Overcharge2", 8f, _interrupt: false);
		}
	}
}
