using System.Collections.Generic;
using Photon.Pun;
using UnityEngine;

public class ArenaRaceTrackPiece : MonoBehaviour, IPunInstantiateMagicCallback
{
	public float minimumClearanceTime = 5f;

	internal int pieceIndex;

	internal List<GameObject> spawnedObjects = new List<GameObject>();

	private bool registered;

	internal bool countdownStarted;

	private bool warningPhaseStarted;

	internal float countdownTimer;

	private float countdownDuration;

	private int lastBeepSecond;

	private Light warningLight;

	private GameObject warningLightObject;

	private bool plunging;

	private float plungeSpeed = 30f;

	private Vector3 originalPosition;

	private Vector3 soundPlayPosition;

	private bool localPlayerOnPiece;

	private float spawnedObjectDestroyTimer;

	private float spawnedObjectDestroyInterval;

	private int spawnedObjectDestroyIndex;

	public void OnPhotonInstantiate(PhotonMessageInfo _info)
	{
		//IL_0000: Unknown result type (might be due to invalid IL or missing references)
		object[] instantiationData = _info.photonView.InstantiationData;
		if (instantiationData != null && instantiationData.Length >= 1)
		{
			pieceIndex = (int)instantiationData[0];
			TryRegister();
		}
	}

	private void TryRegister()
	{
		if (!registered && Object.op_Implicit((Object)(object)ArenaRace.instance))
		{
			ArenaRace.instance.RegisterTrackPiece(this);
			registered = true;
		}
	}

	public void StartCountdown()
	{
		//IL_009b: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a0: Unknown result type (might be due to invalid IL or missing references)
		if (!countdownStarted)
		{
			ArenaRace instance = ArenaRace.instance;
			float num = Mathf.Clamp01((float)instance.totalPiecesDisappeared / (float)instance.pieceCountdownScalePieceCount);
			float num2 = Mathf.Lerp(minimumClearanceTime * 2f, minimumClearanceTime, num);
			int num3 = Mathf.Max(1, instance.pieceCountdownScaleEndPieceCount - instance.pieceCountdownScalePieceCount);
			float num4 = Mathf.Clamp01((float)(instance.totalPiecesDisappeared - instance.pieceCountdownScalePieceCount) / (float)num3);
			num2 = Mathf.Lerp(num2, minimumClearanceTime * instance.pieceCountdownScaleEndMultiplier, num4);
			countdownStarted = true;
			countdownDuration = num2;
			countdownTimer = num2;
			originalPosition = ((Component)this).transform.position;
		}
	}

	public void StartCountdown(float _duration)
	{
		//IL_0025: Unknown result type (might be due to invalid IL or missing references)
		//IL_002a: Unknown result type (might be due to invalid IL or missing references)
		if (!countdownStarted)
		{
			countdownStarted = true;
			countdownDuration = _duration;
			countdownTimer = _duration;
			originalPosition = ((Component)this).transform.position;
		}
	}

	private void StartWarningPhase()
	{
		//IL_0011: Unknown result type (might be due to invalid IL or missing references)
		//IL_0016: Unknown result type (might be due to invalid IL or missing references)
		//IL_001a: Unknown result type (might be due to invalid IL or missing references)
		//IL_002a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0036: Unknown result type (might be due to invalid IL or missing references)
		//IL_0040: Unknown result type (might be due to invalid IL or missing references)
		//IL_0045: Unknown result type (might be due to invalid IL or missing references)
		if (!warningPhaseStarted)
		{
			warningPhaseStarted = true;
			Bounds val = CalculateBounds();
			soundPlayPosition = new Vector3(val.center.x, ((Component)this).transform.position.y, val.center.z);
		}
	}

	private void CreateWarningLight()
	{
		//IL_0014: Unknown result type (might be due to invalid IL or missing references)
		//IL_001e: Expected Obj, but got Unknown
		//IL_0050: Unknown result type (might be due to invalid IL or missing references)
		if (!Object.op_Implicit((Object)(object)warningLightObject))
		{
			warningLightObject = new GameObject("WarningLight");
			warningLight = warningLightObject.AddComponent<Light>();
			warningLight.type = (LightType)2;
			warningLight.color = new Color(0.5f, 0f, 0f);
			warningLight.intensity = 1f;
			warningLight.range = 20f;
		}
	}

	private void DestroyWarningLight()
	{
		if (Object.op_Implicit((Object)(object)warningLightObject))
		{
			Object.Destroy((Object)(object)warningLightObject);
			warningLightObject = null;
			warningLight = null;
		}
	}

	private bool LocalPlayerOnThisPiece()
	{
		foreach (KeyValuePair<ItemVehicle, int> item in ArenaRace.instance.vehicleCurrentPiece)
		{
			if (item.Value != pieceIndex || !Object.op_Implicit((Object)(object)item.Key))
			{
				continue;
			}
			ItemVehicle.VehicleSeat[] seats = item.Key.seats;
			foreach (ItemVehicle.VehicleSeat vehicleSeat in seats)
			{
				if (Object.op_Implicit((Object)(object)vehicleSeat.seatedPlayer) && vehicleSeat.seatedPlayer.isLocal)
				{
					return true;
				}
			}
		}
		return false;
	}

	private Bounds CalculateBounds()
	{
		//IL_000a: Unknown result type (might be due to invalid IL or missing references)
		//IL_000f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0019: Unknown result type (might be due to invalid IL or missing references)
		//IL_002d: Unknown result type (might be due to invalid IL or missing references)
		Renderer[] componentsInChildren = ((Component)this).GetComponentsInChildren<Renderer>();
		Bounds bounds = componentsInChildren[0].bounds;
		for (int i = 1; i < componentsInChildren.Length; i++)
		{
			bounds.Encapsulate(componentsInChildren[i].bounds);
		}
		return bounds;
	}

	private void Update()
	{
		if (!registered)
		{
			TryRegister();
		}
		if (countdownStarted && !plunging)
		{
			CountdownLogic();
		}
		if (plunging)
		{
			PlungeLogic();
		}
	}

	private void CountdownLogic()
	{
		//IL_0091: Unknown result type (might be due to invalid IL or missing references)
		//IL_0096: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a2: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ad: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b2: Unknown result type (might be due to invalid IL or missing references)
		//IL_0121: Unknown result type (might be due to invalid IL or missing references)
		//IL_0126: Unknown result type (might be due to invalid IL or missing references)
		//IL_012c: Unknown result type (might be due to invalid IL or missing references)
		//IL_017a: Unknown result type (might be due to invalid IL or missing references)
		countdownTimer -= Time.deltaTime;
		float pieceWarningDuration = ArenaRace.instance.pieceWarningDuration;
		if (countdownTimer <= pieceWarningDuration && !warningPhaseStarted)
		{
			StartWarningPhase();
		}
		if (warningPhaseStarted)
		{
			localPlayerOnPiece = LocalPlayerOnThisPiece();
			float num = 1f - Mathf.Clamp01(countdownTimer / pieceWarningDuration);
			if (localPlayerOnPiece && !SemiFunc.Photosensitivity())
			{
				if (!Object.op_Implicit((Object)(object)warningLightObject))
				{
					CreateWarningLight();
				}
				Vector3 position = ((Component)PlayerController.instance).transform.position;
				warningLightObject.transform.position = position + Vector3.up * 0.5f;
				float num2 = countdownTimer - Mathf.Floor(countdownTimer);
				float num3 = num2 * num2;
				float num4 = Mathf.Lerp(1f, 10f, num);
				float num5 = Mathf.Lerp(0.2f, 2f, num);
				warningLight.intensity = Mathf.Lerp(num5, num4, num3);
				warningLight.color = Color.Lerp(new Color(0.3f, 0f, 0f), Color.red, num);
			}
			else
			{
				DestroyWarningLight();
			}
			int num6 = Mathf.CeilToInt(countdownTimer);
			if (num6 != lastBeepSecond && num6 >= 0)
			{
				lastBeepSecond = num6;
				if (localPlayerOnPiece)
				{
					ArenaRace.instance.soundPieceCountdownBeep.Play(((Component)PlayerController.instance).transform.position);
				}
			}
		}
		if (countdownTimer <= 0f)
		{
			StartPlunge();
		}
	}

	private void StartPlunge()
	{
		//IL_0026: Unknown result type (might be due to invalid IL or missing references)
		plunging = true;
		if (localPlayerOnPiece)
		{
			ArenaRace.instance.soundPiecePlunge.Play(((Component)PlayerController.instance).transform.position);
			PlayerAvatar instance = PlayerAvatar.instance;
			if (Object.op_Implicit((Object)(object)instance) && !instance.isDisabled && !instance.deadSet)
			{
				GameDirector.instance.CameraShake.Shake(3f, 0.2f);
				GameDirector.instance.CameraImpact.Shake(5f, 0.08f);
			}
		}
		DestroyWarningLight();
		if (pieceIndex == 0)
		{
			ArenaRace.instance.OnStartingPiecePlunge();
		}
		if (pieceIndex == 4)
		{
			ArenaRace.instance.StartRoomDisable();
		}
		if (SemiFunc.IsMasterClientOrSingleplayer() && spawnedObjects.Count > 0)
		{
			spawnedObjectDestroyInterval = 1f / (float)spawnedObjects.Count;
			spawnedObjectDestroyTimer = 0f;
			spawnedObjectDestroyIndex = 0;
		}
	}

	private void DestroySpawnedObjectsOverTime()
	{
		if (spawnedObjectDestroyIndex < spawnedObjects.Count)
		{
			spawnedObjectDestroyTimer -= Time.deltaTime;
			if (!(spawnedObjectDestroyTimer > 0f))
			{
				spawnedObjectDestroyTimer = spawnedObjectDestroyInterval;
				DestroyNextSpawnedObject();
			}
		}
	}

	private void DestroyNextSpawnedObject()
	{
		if (spawnedObjectDestroyIndex >= spawnedObjects.Count)
		{
			return;
		}
		GameObject val = spawnedObjects[spawnedObjectDestroyIndex];
		spawnedObjectDestroyIndex++;
		if (Object.op_Implicit((Object)(object)val))
		{
			PhysGrabObjectImpactDetector component = val.GetComponent<PhysGrabObjectImpactDetector>();
			if (Object.op_Implicit((Object)(object)component))
			{
				component.DestroyObject();
			}
		}
	}

	private void DestroyRemainingSpawnedObjects()
	{
		if (SemiFunc.IsMasterClientOrSingleplayer())
		{
			while (spawnedObjectDestroyIndex < spawnedObjects.Count)
			{
				DestroyNextSpawnedObject();
			}
		}
	}

	private void OnDestroy()
	{
		DestroyRemainingSpawnedObjects();
	}

	private void PlungeLogic()
	{
		//IL_001f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0039: Unknown result type (might be due to invalid IL or missing references)
		//IL_003e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0054: Unknown result type (might be due to invalid IL or missing references)
		plungeSpeed += 20f * Time.deltaTime;
		Transform transform = ((Component)this).transform;
		transform.position += Vector3.down * plungeSpeed * Time.deltaTime;
		DestroySpawnedObjectsOverTime();
		if (((Component)this).transform.position.y < originalPosition.y - 50f)
		{
			Object.Destroy((Object)(object)((Component)this).gameObject);
		}
	}
}
