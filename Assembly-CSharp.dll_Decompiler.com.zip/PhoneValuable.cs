using System;
using System.Collections.Generic;
using Photon.Pun;
using UnityEngine;

public class PhoneValuable : MonoBehaviour
{
	public float ringDistance = 7.5f;

	public GameObject phoneLight;

	public Sound ringTone;

	public Sound vibrationSound;

	public Sound pickupSound;

	private PhotonView photonView;

	public GameObject phoneMesh;

	private Quaternion initialRotation;

	protected Rigidbody rb;

	private List<PlayerAvatar> players;

	private bool playersNearby;

	private bool enemiesNearby;

	private MeshRenderer meshRenderer;

	private PhysGrabObject physGrabObject;

	private bool phoneRinging;

	private bool vibrate;

	private bool visualsReset = true;

	private float joltTimer;

	private float joltInterval = 0.3f;

	public float ringIntervalTimer;

	private float ringIntervalMin = 30f;

	private float ringIntervalMax = 200f;

	public float ringTimer;

	private float ringTimerMin = 5f;

	private float ringTimerMax = 20f;

	private float maxVelocity = 0.5f;

	private bool reset;

	public bool hasRung;

	private float vibrateCycleTimer;

	private float vibrateCycleDuration = 2f;

	private float investigateTimer;

	private float investigateInterval = 2f;

	protected void Start()
	{
		//IL_0045: Unknown result type (might be due to invalid IL or missing references)
		//IL_004a: Unknown result type (might be due to invalid IL or missing references)
		rb = ((Component)this).GetComponent<Rigidbody>();
		physGrabObject = ((Component)this).GetComponent<PhysGrabObject>();
		meshRenderer = ((Component)this).GetComponentInChildren<MeshRenderer>();
		((Renderer)meshRenderer).material.DisableKeyword("_EMISSION");
		initialRotation = phoneMesh.transform.localRotation;
		photonView = ((Component)this).GetComponent<PhotonView>();
		joltTimer = joltInterval;
		ringIntervalTimer = Random.Range(ringIntervalMin, ringIntervalMax);
		ringTimer = Random.Range(ringTimerMin, ringTimerMax);
	}

	protected void Update()
	{
		RingVisuals();
		ringTone.PlayLoop(phoneRinging, 10f, 10f);
		vibrationSound.PlayLoop(vibrate, 10f, 10f);
		CheckForNearbyPlayers();
		CheckForNearbyEnemies();
	}

	private void CheckForNearbyPlayers()
	{
		//IL_0033: Unknown result type (might be due to invalid IL or missing references)
		//IL_003e: Unknown result type (might be due to invalid IL or missing references)
		if (!SemiFunc.PerSecond(5f, (Object)(object)this))
		{
			return;
		}
		players = SemiFunc.PlayerGetList();
		foreach (PlayerAvatar player in players)
		{
			if (Vector3.Distance(((Component)player).transform.position, ((Component)this).transform.position) < ringDistance)
			{
				playersNearby = true;
				reset = true;
				break;
			}
			playersNearby = false;
		}
	}

	private void CheckForNearbyEnemies()
	{
		//IL_0015: Unknown result type (might be due to invalid IL or missing references)
		if (SemiFunc.PerSecond(5f, (Object)(object)this))
		{
			enemiesNearby = Object.op_Implicit((Object)(object)SemiFunc.EnemyGetNearest(((Component)this).transform.position, ringDistance, _raycast: false));
		}
	}

	private void FixedUpdate()
	{
		if (playersNearby || reset)
		{
			PhoneRing();
		}
	}

	private void RingVisuals()
	{
		//IL_004f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0054: Unknown result type (might be due to invalid IL or missing references)
		//IL_01f8: Unknown result type (might be due to invalid IL or missing references)
		//IL_013b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0147: Unknown result type (might be due to invalid IL or missing references)
		//IL_014c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0188: Unknown result type (might be due to invalid IL or missing references)
		//IL_018d: Unknown result type (might be due to invalid IL or missing references)
		//IL_01a3: Unknown result type (might be due to invalid IL or missing references)
		//IL_01ad: Unknown result type (might be due to invalid IL or missing references)
		//IL_01b8: Unknown result type (might be due to invalid IL or missing references)
		//IL_01bd: Unknown result type (might be due to invalid IL or missing references)
		//IL_01c0: Unknown result type (might be due to invalid IL or missing references)
		//IL_01ca: Unknown result type (might be due to invalid IL or missing references)
		//IL_01cf: Unknown result type (might be due to invalid IL or missing references)
		//IL_01d7: Unknown result type (might be due to invalid IL or missing references)
		if (!phoneRinging)
		{
			if (!visualsReset)
			{
				((Renderer)meshRenderer).material.DisableKeyword("_EMISSION");
				phoneLight.SetActive(false);
				vibrate = false;
				vibrateCycleTimer = 0f;
				initialRotation = phoneMesh.transform.localRotation;
				physGrabObject.ignoreGrabPointCentering = false;
				visualsReset = true;
			}
			return;
		}
		visualsReset = false;
		physGrabObject.ignoreGrabPointCentering = true;
		((Renderer)meshRenderer).material.EnableKeyword("_EMISSION");
		if (!phoneLight.activeSelf)
		{
			phoneLight.SetActive(true);
		}
		vibrateCycleTimer -= Time.deltaTime;
		if (vibrateCycleTimer < 0f)
		{
			vibrateCycleTimer = vibrateCycleDuration;
		}
		vibrate = vibrateCycleTimer >= vibrateCycleDuration / 2f;
		if (vibrate)
		{
			float num = 80f;
			float num2 = 2f * Mathf.Sin(Time.time * num);
			float num3 = 2f * Mathf.Sin(Time.time * num + MathF.PI / 2f);
			phoneMesh.transform.localRotation = initialRotation * Quaternion.Euler(num2, 0f, num3);
			if (!SemiFunc.IsMasterClientOrSingleplayer())
			{
				return;
			}
			joltTimer -= Time.deltaTime;
			if (joltTimer <= 0f)
			{
				Vector3 val = rb.linearVelocity;
				if (val.magnitude < maxVelocity)
				{
					rb.AddForce(Vector3.up * 0.05f, (ForceMode)1);
					val = Random.insideUnitSphere;
					Vector3 val2 = val.normalized * 0.1f;
					rb.AddTorque(val2, (ForceMode)1);
				}
				joltTimer = joltInterval;
			}
		}
		else
		{
			phoneMesh.transform.localRotation = initialRotation;
		}
	}

	private void PhoneRing()
	{
		//IL_0072: Unknown result type (might be due to invalid IL or missing references)
		if (!SemiFunc.IsMasterClientOrSingleplayer())
		{
			return;
		}
		if (!phoneRinging && playersNearby && (!hasRung || enemiesNearby))
		{
			ringIntervalTimer -= Time.deltaTime;
		}
		if (ringIntervalTimer <= 0f && ringTimer > 0f)
		{
			if (investigateTimer <= 0f)
			{
				EnemyDirector.instance.SetInvestigate(((Component)this).transform.position, 15f);
				investigateTimer = investigateInterval;
			}
			else
			{
				investigateTimer -= Time.deltaTime;
			}
			if (!phoneRinging)
			{
				phoneRinging = true;
				hasRung = true;
				if (SemiFunc.IsMultiplayer())
				{
					photonView.RPC("SetRingRPC", (RpcTarget)1, new object[1] { phoneRinging });
				}
			}
			ringTimer -= Time.deltaTime;
		}
		else
		{
			if (!(ringTimer <= 0f))
			{
				return;
			}
			investigateTimer = 0f;
			ringIntervalTimer = Random.Range(ringIntervalMin, ringIntervalMax);
			ringTimer = Random.Range(ringTimerMin, ringTimerMax);
			if (phoneRinging)
			{
				phoneRinging = false;
				if (SemiFunc.IsMultiplayer())
				{
					photonView.RPC("SetRingRPC", (RpcTarget)1, new object[1] { phoneRinging });
				}
			}
			if (!playersNearby)
			{
				reset = false;
			}
		}
	}

	public void PickUp()
	{
		//IL_0013: Unknown result type (might be due to invalid IL or missing references)
		//IL_0019: Unknown result type (might be due to invalid IL or missing references)
		if (phoneRinging)
		{
			if (!SemiFunc.IsMultiplayer())
			{
				PickUpRPC();
			}
			else if (PhotonNetwork.IsMasterClient)
			{
				photonView.RPC("PickUpRPC", (RpcTarget)0, Array.Empty<object>());
			}
		}
	}

	private void PickUpLogic()
	{
		//IL_0017: Unknown result type (might be due to invalid IL or missing references)
		ringTimer = 0f;
		pickupSound.Play(((Component)this).transform.position);
	}

	[PunRPC]
	private void PickUpRPC(PhotonMessageInfo _info = default(PhotonMessageInfo))
	{
		//IL_0000: Unknown result type (might be due to invalid IL or missing references)
		if (SemiFunc.MasterOnlyRPC(_info))
		{
			PickUpLogic();
		}
	}

	[PunRPC]
	private void SetRingRPC(bool _ringing, PhotonMessageInfo _info = default(PhotonMessageInfo))
	{
		//IL_0000: Unknown result type (might be due to invalid IL or missing references)
		if (SemiFunc.MasterOnlyRPC(_info))
		{
			phoneRinging = _ringing;
			hasRung = true;
		}
	}
}
