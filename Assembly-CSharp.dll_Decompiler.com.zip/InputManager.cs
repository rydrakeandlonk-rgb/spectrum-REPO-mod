using System;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Events;
using UnityEngine.InputSystem;
using UnityEngine.InputSystem.Controls;
using UnityEngine.InputSystem.DualShock;
using UnityEngine.InputSystem.Layouts;
using UnityEngine.InputSystem.Utilities;
using UnityEngine.InputSystem.XInput;

public class InputManager : MonoBehaviour
{
	private struct UINavigateMirror
	{
		public int navigateIndex;

		public int movementIndex;

		public string suffix;
	}

	[Serializable]
	public class ControlLocalizationPair
	{
		public string controlPath;

		public LocalizedAsset LocalizedAsset;
	}

	public enum RumbleThockType
	{
		LetterTap,
		ConfirmTap,
		Deny,
		BigButton,
		MenuDown,
		MenuUp
	}

	[Serializable]
	public class ExcludedControlEntry
	{
		public InputKey inputKey;

		public List<string> excludedPaths = new List<string>();
	}

	private class GamepadRumbleAnimation
	{
		private CameraShake source;

		private float strength;

		private float strengthMax;

		private float strengthLoss;

		private float strengthLossTimer;

		internal void Add(CameraShake _source, float _strength, float _time)
		{
			if ((Object)(object)source != (Object)(object)_source)
			{
				Reset();
			}
			if (!(_source.StrengthMax <= 0f))
			{
				float num = Mathf.Clamp01(_strength / _source.StrengthMax);
				float num2 = Mathf.SmoothStep(0f, 1f, Mathf.InverseLerp(0.05f, 0.25f, num));
				_strength *= num2 * num2;
				if (!(_strength <= strength))
				{
					source = _source;
					strengthMax = _source.StrengthMax;
					strengthLoss = _source.StrengthLoss;
					strength = Mathf.Min(strength + _strength, strengthMax);
					strengthLossTimer = Mathf.Max(_time, strengthLossTimer);
				}
			}
		}

		internal float Tick(CameraShake _source)
		{
			if (!Object.op_Implicit((Object)(object)source) || (Object)(object)source != (Object)(object)_source)
			{
				Reset();
				return 0f;
			}
			if (strength <= 0f)
			{
				return 0f;
			}
			float result = Mathf.Sqrt(Mathf.Clamp01(strength / strengthMax));
			if (strengthLossTimer > 0f)
			{
				strengthLossTimer = Mathf.Max(0f, strengthLossTimer - Time.deltaTime);
				return result;
			}
			strength = Mathf.Max(0f, strength - strengthLoss * Time.deltaTime);
			if (strength <= 0.1f)
			{
				strength = 0f;
			}
			return result;
		}

		internal void Reset()
		{
			source = null;
			strength = 0f;
			strengthMax = 0f;
			strengthLoss = 0f;
			strengthLossTimer = 0f;
		}
	}

	public static InputManager instance;

	[HideInInspector]
	public bool textInputsActivePrevFrame;

	[HideInInspector]
	public bool externalTextInputActivePrevFrame;

	private float gamepadTextInputBlockTimer;

	private bool gamepadTextInputBlockAllowKeyboard;

	private const int BINDINGS_VERSION = 2;

	internal const string SchemeKeyboardMouse = "Keyboard&Mouse";

	internal const string SchemeGamepad = "Gamepad";

	private const string LEGACY_DEFAULT_KEYBINDINGS_FILENAME = "DefaultKeyBindings.es3";

	internal const string CURRENT_KEYBINDINGS_FILENAME = "CurrentKeyBindings.es3";

	public List<ExcludedControlEntry> excludedControls = new List<ExcludedControlEntry>();

	private Dictionary<InputKey, InputAction> inputActions;

	private Dictionary<InputKey, bool> inputToggleKeyboardMouse;

	private Dictionary<InputKey, bool> inputToggleGamepad;

	internal Dictionary<InputPercentSetting, int> inputPercentSettings;

	private Dictionary<MovementDirection, int> movementBindingIndices;

	private List<UINavigateMirror> uiNavigateMirrors;

	private Dictionary<InputKey, List<string>> defaultBindingPaths;

	private Dictionary<InputKey, bool> defaultInputToggleStatesKeyboardMouse;

	private Dictionary<InputKey, bool> defaultInputToggleStatesGamepad;

	private Dictionary<InputPercentSetting, int> defaultInputPercentSettings;

	private readonly Dictionary<string, char> numpadKeyLookup = new Dictionary<string, char>
	{
		{ "/Keyboard/numpadDivide", '/' },
		{ "/Keyboard/numpadMultiply", '*' },
		{ "/Keyboard/numpadPlus", '+' },
		{ "/Keyboard/numpadMinus", '-' },
		{ "/Keyboard/numpadPeriod", '.' },
		{ "/Keyboard/numpadEquals", '=' },
		{ "/Keyboard/numpad1", '1' },
		{ "/Keyboard/numpad2", '2' },
		{ "/Keyboard/numpad3", '3' },
		{ "/Keyboard/numpad4", '4' },
		{ "/Keyboard/numpad5", '5' },
		{ "/Keyboard/numpad6", '6' },
		{ "/Keyboard/numpad7", '7' },
		{ "/Keyboard/numpad8", '8' },
		{ "/Keyboard/numpad9", '9' },
		{ "/Keyboard/numpad0", '0' }
	};

	public List<ControlLocalizationPair> localizedKeyboardActionsList = new List<ControlLocalizationPair>();

	public List<ControlLocalizationPair> localizedMouseActionsList = new List<ControlLocalizationPair>();

	private readonly Dictionary<string, LocalizedAsset> localizedKeyboardActions = new Dictionary<string, LocalizedAsset>();

	private readonly Dictionary<string, LocalizedAsset> localizedMouseActions = new Dictionary<string, LocalizedAsset>();

	public UnityEvent<string> keyboardLayoutChangedEvents = new UnityEvent<string>();

	internal float inputChangeDebounceTimer;

	private const float MouseDeviceSwitchDelta = 2f;

	private const float GamepadHeldStickAmount = 0.2f;

	private const float GamepadRecentInputTime = 2f;

	private float gamepadRecentInputTimer;

	private float vehicleGamepadOverrideTimer;

	private int vehicleGamepadOverrideFrame = -2;

	internal float disableMovementTimer;

	internal float disableAimingTimer;

	private List<InputKey> disableControlsExceptList;

	private float disableControlsExceptTimer;

	private List<InputKey> disableControlsIncludeList;

	private float disableControlsIncludeTimer;

	private string keyboardLayout;

	internal float mouseSensitivity = 0.1f;

	private const float ThockPower = 1f;

	private const float ThockClickTime = 0.01f;

	private const float ThockLetterTapPower = 0.28f;

	private const float ThockConfirmTapPower = 0.75f;

	private const float ThockDenyPower = 0.85f;

	private const float ThockBigButtonPower = 1f;

	private const float ThockMenuDownPower = 0.3f;

	private const float ThockMenuUpPower = 0.3f;

	private float rumbleThockTimer;

	private float rumbleThockStrength;

	private int rumbleThockPriority;

	private int rumbleThockFrame = -1;

	private readonly GamepadRumbleAnimation rumbleImpactAnimation = new GamepadRumbleAnimation();

	private readonly GamepadRumbleAnimation rumbleShakeAnimation = new GamepadRumbleAnimation();

	private Gamepad rumbleGamepad;

	private float rumbleImpactStrength;

	private float rumbleImpactTimer;

	private float rumbleShakeStrength;

	private float rumbleShakeTimer;

	private float rumbleShakeSmoothed;

	private float rumbleOverrideStrength;

	private float rumbleOverrideTimer;

	private Vector2 rumbleContinuousStrength;

	private float rumbleContinuousTimer;

	private float rumbleLowFrequency;

	private float rumbleHighFrequency;

	private int gamepadAimFrame = -1;

	private Vector2 gamepadAimDelta;

	private float gamepadAimAccelerationTime;

	private Vector2 gamepadAimAccelerationDirection;

	private Dictionary<string, InputKey> tagDictionary = new Dictionary<string, InputKey>();

	internal RebindingOperation rebindingOperation;

	private InputSystem_Actions inputSystemActions;

	private readonly HashSet<InputAction> heldFromUIActions = new HashSet<InputAction>();

	public InputModes CurrentMode { get; private set; }

	public InputDeviceType CurrentDeviceType { get; private set; }

	public event Action<InputDeviceType> OnDeviceTypeChanged;

	[RuntimeInitializeOnLoadMethod(/*Could not decode attribute arguments.*/)]
	private static void RuntimeInitializeOnLoad()
	{
		instance = null;
	}

	private void Awake()
	{
		if ((Object)(object)instance == (Object)null)
		{
			instance = this;
			Object.DontDestroyOnLoad((Object)(object)((Component)this).gameObject);
			InitializeInputs();
			StoreDefaultBindings();
			UpdateLocalizedActionDictionaries();
		}
		else
		{
			Object.Destroy((Object)(object)((Component)this).gameObject);
		}
	}

	private void Start()
	{
		//IL_004e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0058: Expected Obj, but got Unknown
		try
		{
			InputSystem.settings.backgroundBehavior = (BackgroundBehavior)1;
		}
		catch (Exception ex)
		{
			Debug.LogError((object)ex);
		}
		try
		{
			if (ES3.FileExists("DefaultKeyBindings.es3"))
			{
				ES3.DeleteFile("DefaultKeyBindings.es3");
				Debug.Log((object)"Deleted leftover default keybinds file: DefaultKeyBindings.es3");
			}
		}
		catch
		{
		}
		if (!ES3.FileExists(new ES3Settings("CurrentKeyBindings.es3", new Enum[1] { (Enum)(object)(Location)0 })))
		{
			SaveCurrentKeyBindings("CurrentKeyBindings.es3");
		}
		LoadKeyBindings("CurrentKeyBindings.es3");
	}

	private void LateUpdate()
	{
		GamepadRumbleTick();
		if (inputChangeDebounceTimer > 0f)
		{
			inputChangeDebounceTimer = Mathf.Max(0f, inputChangeDebounceTimer - Time.unscaledDeltaTime);
		}
		if (gamepadRecentInputTimer > 0f)
		{
			gamepadRecentInputTimer = Mathf.Max(0f, gamepadRecentInputTimer - Time.unscaledDeltaTime);
		}
		textInputsActivePrevFrame = !SemiFunc.NoTextInputsActive();
		externalTextInputActivePrevFrame = !SemiFunc.NoExternalTextInputActive();
		if (gamepadTextInputBlockTimer > 0f)
		{
			gamepadTextInputBlockTimer -= Time.unscaledDeltaTime;
		}
		if (gamepadAimFrame != Time.frameCount)
		{
			gamepadAimAccelerationTime = 0f;
		}
		if (heldFromUIActions.Count > 0)
		{
			heldFromUIActions.RemoveWhere((InputAction action) => !ActionButtonHeld(action));
		}
	}

	private void FixedUpdate()
	{
		float num = Mathf.Min(Time.fixedDeltaTime, 0.05f);
		if (disableMovementTimer > 0f)
		{
			disableMovementTimer -= num;
		}
		if (disableAimingTimer > 0f)
		{
			disableAimingTimer -= num;
		}
		if (disableControlsExceptTimer > 0f)
		{
			disableControlsExceptTimer -= num;
		}
		if (disableControlsIncludeTimer > 0f)
		{
			disableControlsIncludeTimer -= num;
		}
		if ((object)keyboardLayout != Keyboard.current.keyboardLayout)
		{
			Debug.Log((object)("[Input Manager] Input layout switched from [" + keyboardLayout + "] to [" + Keyboard.current.keyboardLayout + "]."));
			keyboardLayout = Keyboard.current.keyboardLayout;
			keyboardLayoutChangedEvents.Invoke(keyboardLayout);
		}
	}

	public void OverrideVehicleGamepad(float time = 0.1f)
	{
		float num = Time.unscaledTime + time;
		vehicleGamepadOverrideTimer = Mathf.Max(vehicleGamepadOverrideTimer, num);
		vehicleGamepadOverrideFrame = Time.frameCount;
	}

	private bool VehicleGamepadOverrideActive()
	{
		if (CurrentMode != InputModes.Gamepad)
		{
			return false;
		}
		if (!(vehicleGamepadOverrideTimer > Time.unscaledTime))
		{
			return Time.frameCount <= vehicleGamepadOverrideFrame + 1;
		}
		return true;
	}

	public bool VehicleInputAllowed()
	{
		if (!Application.isFocused || !SemiFunc.NoTextInputsActive())
		{
			return false;
		}
		if (!inputSystemActions.Player.enabled || disableMovementTimer > 0f)
		{
			return false;
		}
		if (Object.op_Implicit((Object)(object)GameDirector.instance) && GameDirector.instance.DisableInput)
		{
			return false;
		}
		if (Object.op_Implicit((Object)(object)PlayerController.instance) && PlayerController.instance.InputDisableTimer > 0f)
		{
			return false;
		}
		if (disableControlsExceptTimer > 0f && (disableControlsExceptList == null || !disableControlsExceptList.Contains(InputKey.Movement)))
		{
			return false;
		}
		if (disableControlsIncludeTimer > 0f && disableControlsIncludeList != null && disableControlsIncludeList.Contains(InputKey.Movement))
		{
			return false;
		}
		return true;
	}

	public bool VehicleGamepadInputAllowed()
	{
		if (!VehicleInputAllowed() || CurrentMode != InputModes.Gamepad)
		{
			return false;
		}
		if (Gamepad.current != null)
		{
			return ((InputDevice)Gamepad.current).enabled;
		}
		return false;
	}

	private void VehicleGamepadBindingsSetup()
	{
		//IL_0065: Unknown result type (might be due to invalid IL or missing references)
		//IL_0084: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c2: Unknown result type (might be due to invalid IL or missing references)
		VehicleGamepadBindingAdd(InputKey.VehicleAccelerate, "<Gamepad>/leftStick/up", (InputActionType)0, "Axis");
		VehicleGamepadBindingAdd(InputKey.VehicleBrake, "<Gamepad>/leftStick/down", (InputActionType)0, "Axis");
		VehicleGamepadBindingAdd(InputKey.VehicleDriftLeft, "<Gamepad>/rightShoulder", (InputActionType)1, "Button");
		VehicleGamepadBindingAdd(InputKey.VehicleDriftRight, "<Gamepad>/leftShoulder", (InputActionType)1, "Button");
		InputActionSetupExtensions.AddBinding(inputActions[InputKey.VehicleAccelerate], "<Keyboard>/w", (string)null, (string)null, "Keyboard&Mouse");
		InputActionSetupExtensions.AddBinding(inputActions[InputKey.VehicleBrake], "<Keyboard>/s", (string)null, (string)null, "Keyboard&Mouse");
		InputActionSetupExtensions.AddBinding(inputActions[InputKey.VehicleDriftLeft], "<Keyboard>/a", (string)null, (string)null, "Keyboard&Mouse");
		InputActionSetupExtensions.AddBinding(inputActions[InputKey.VehicleDriftRight], "<Keyboard>/d", (string)null, (string)null, "Keyboard&Mouse");
		inputToggleKeyboardMouse.Add(InputKey.VehicleGrab, value: true);
		inputToggleGamepad.Add(InputKey.VehicleGrab, value: true);
	}

	private void VehicleGamepadBindingAdd(InputKey key, string path, InputActionType type, string controlType)
	{
		//IL_0020: Unknown result type (might be due to invalid IL or missing references)
		//IL_003d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0042: Unknown result type (might be due to invalid IL or missing references)
		//IL_0043: Unknown result type (might be due to invalid IL or missing references)
		//IL_004d: Unknown result type (might be due to invalid IL or missing references)
		InputAction val = InputActionSetupExtensions.AddAction(inputSystemActions.Player.Get(), key.ToString(), type, (string)null, (string)null, (string)null, (string)null, (string)null);
		val.expectedControlType = controlType;
		BindingSyntax val2 = InputActionSetupExtensions.AddBinding(val, path, (string)null, (string)null, "Gamepad");
		if ((int)type == 0)
		{
			val2.WithProcessor("axisDeadzone");
		}
		inputActions[key] = val;
	}

	private void ExpressionWheelBindingSetup()
	{
		//IL_003c: Unknown result type (might be due to invalid IL or missing references)
		//IL_004f: Unknown result type (might be due to invalid IL or missing references)
		InputAction val = InputActionSetupExtensions.AddAction(inputSystemActions.Player.Get(), "ExpressionWheel", (InputActionType)1, (string)null, (string)null, (string)null, (string)null, (string)null);
		val.expectedControlType = "Button";
		InputActionSetupExtensions.AddBinding(val, "<Gamepad>/buttonNorth", (string)null, (string)null, "Gamepad");
		InputActionSetupExtensions.AddBinding(val, "<Keyboard>/g", (string)null, (string)null, "Keyboard&Mouse");
		inputActions[InputKey.ExpressionWheel] = val;
		inputToggleKeyboardMouse.Add(InputKey.ExpressionWheel, value: false);
		inputToggleGamepad.Add(InputKey.ExpressionWheel, value: false);
	}

	public bool ExpressionWheelInputAllowed()
	{
		if (!Application.isFocused || !inputSystemActions.Player.enabled || rebindingOperation != null)
		{
			return false;
		}
		if (!Object.op_Implicit((Object)(object)LevelGenerator.Instance) || !LevelGenerator.Instance.Generated || !SemiFunc.NoTextInputsActive())
		{
			return false;
		}
		if (Object.op_Implicit((Object)(object)MenuManager.instance) && Object.op_Implicit((Object)(object)MenuManager.instance.currentMenuPage))
		{
			return false;
		}
		if (Object.op_Implicit((Object)(object)GameDirector.instance) && GameDirector.instance.DisableInput)
		{
			return false;
		}
		if (Object.op_Implicit((Object)(object)PlayerController.instance) && PlayerController.instance.InputDisableTimer > 0f)
		{
			return false;
		}
		if (!Object.op_Implicit((Object)(object)PlayerAvatar.instance) || PlayerAvatar.instance.isDisabled || PlayerAvatar.instance.deadSet)
		{
			return false;
		}
		if (disableMovementTimer > 0f || VehicleInputBlocked(InputKey.ExpressionWheel) || VehicleGamepadControlReserved(InputKey.ExpressionWheel))
		{
			return false;
		}
		if (CurrentMode == InputModes.Gamepad && (Gamepad.current == null || !((InputDevice)Gamepad.current).enabled))
		{
			return false;
		}
		if (Object.op_Implicit((Object)(object)PlayerExpressionsUI.instance) && Object.op_Implicit((Object)(object)PlayerExpressionsUI.instance.wheel) && ((Behaviour)PlayerExpressionsUI.instance.wheel).isActiveAndEnabled)
		{
			return PlayerExpressionsUI.instance.wheel.Ready;
		}
		return false;
	}

	public bool ExpressionWheelActive()
	{
		if (!ExpressionWheelInputAllowed())
		{
			return false;
		}
		if (PlayerExpressionsUI.instance.wheel.InputActive)
		{
			return true;
		}
		return KeyDown(InputKey.ExpressionWheel);
	}

	private bool ExpressionWheelUsesLeftStick()
	{
		if (CurrentMode == InputModes.Gamepad)
		{
			return inputPercentSettings[InputPercentSetting.ExpressionWheelRightStickGamepad] == 0;
		}
		return false;
	}

	private bool ExpressionWheelLookReserved()
	{
		if (!ExpressionWheelUsesLeftStick())
		{
			return ExpressionWheelActive();
		}
		return false;
	}

	public Vector2 ExpressionWheelLookGet()
	{
		//IL_0008: Unknown result type (might be due to invalid IL or missing references)
		//IL_0025: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a6: Unknown result type (might be due to invalid IL or missing references)
		//IL_0045: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ad: Unknown result type (might be due to invalid IL or missing references)
		//IL_0061: Unknown result type (might be due to invalid IL or missing references)
		//IL_006b: Unknown result type (might be due to invalid IL or missing references)
		if (!ExpressionWheelActive())
		{
			return Vector2.zero;
		}
		InputKey key = ((!ExpressionWheelUsesLeftStick()) ? InputKey.MouseDelta : InputKey.Movement);
		if (VehicleInputBlocked(key))
		{
			return Vector2.zero;
		}
		if (CurrentMode == InputModes.Gamepad)
		{
			Gamepad current = Gamepad.current;
			if (current == null || !((InputDevice)current).enabled)
			{
				return Vector2.zero;
			}
			return Vector2.ClampMagnitude(((InputControl<Vector2>)(object)(ExpressionWheelUsesLeftStick() ? current.leftStick : current.rightStick)).ReadValue(), 1f);
		}
		if (inputActions.TryGetValue(InputKey.MouseDelta, out var value) && value.enabled)
		{
			InputControl activeControl = value.activeControl;
			Vector2Control val = (Vector2Control)(object)((activeControl is Vector2Control) ? activeControl : null);
			if (val != null && (object)((InputControl)val).device == Mouse.current)
			{
				return ((InputControl<Vector2>)(object)val).ReadValue();
			}
		}
		return Vector2.zero;
	}

	private bool ExpressionWheelControlReserved(InputKey key)
	{
		//IL_0067: Unknown result type (might be due to invalid IL or missing references)
		//IL_006c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0070: Unknown result type (might be due to invalid IL or missing references)
		//IL_0075: Unknown result type (might be due to invalid IL or missing references)
		if (key == InputKey.ExpressionWheel || !ExpressionWheelActive())
		{
			return false;
		}
		if (key == InputKey.Movement && ExpressionWheelUsesLeftStick())
		{
			return true;
		}
		switch (key)
		{
		case InputKey.MouseDelta:
			return !ExpressionWheelUsesLeftStick();
		case InputKey.Rotate:
		case InputKey.PushPull:
			return true;
		default:
		{
			if (!inputActions.TryGetValue(key, out var value) || !inputActions.TryGetValue(InputKey.ExpressionWheel, out var value2))
			{
				return false;
			}
			InputControl activeControl = value2.activeControl;
			if (activeControl == null)
			{
				return false;
			}
			Enumerator<InputControl> enumerator = value.controls.GetEnumerator();
			try
			{
				while (enumerator.MoveNext())
				{
					if (enumerator.Current == activeControl)
					{
						return true;
					}
				}
			}
			finally
			{
				((IDisposable)enumerator/*cast due to constrained. prefix*/).Dispose();
			}
			return false;
		}
		}
	}

	private bool VehicleInputBlocked(InputKey key)
	{
		if (!(disableControlsExceptTimer > 0f) || (disableControlsExceptList != null && disableControlsExceptList.Contains(key)))
		{
			if (disableControlsIncludeTimer > 0f && disableControlsIncludeList != null)
			{
				return disableControlsIncludeList.Contains(key);
			}
			return false;
		}
		return true;
	}

	public bool VehicleGamepadLookAllowed()
	{
		if (ExpressionWheelLookReserved() || !VehicleGamepadInputAllowed() || disableAimingTimer > 0f || VehicleInputBlocked(InputKey.MouseDelta))
		{
			return false;
		}
		if (Object.op_Implicit((Object)(object)CameraAim.Instance))
		{
			if (!CameraAim.Instance.AimTargetActive)
			{
				return !CameraAim.Instance.overrideAimStop;
			}
			return false;
		}
		return true;
	}

	private Vector2 VehicleGamepadLookInputGet()
	{
		//IL_0008: Unknown result type (might be due to invalid IL or missing references)
		//IL_0043: Unknown result type (might be due to invalid IL or missing references)
		//IL_004a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0054: Unknown result type (might be due to invalid IL or missing references)
		if (!VehicleGamepadLookAllowed())
		{
			return Vector2.zero;
		}
		if (inputActions.TryGetValue(InputKey.MouseDelta, out var value) && value.enabled)
		{
			InputControl activeControl = value.activeControl;
			Vector2Control val = (Vector2Control)(object)((activeControl is Vector2Control) ? activeControl : null);
			if (val != null && (object)((InputControl)val).device == Gamepad.current)
			{
				return Vector2.ClampMagnitude(((InputControl<Vector2>)(object)val).ReadValue(), 1f);
			}
		}
		return Vector2.zero;
	}

	public float VehicleGamepadLookGet()
	{
		//IL_0001: Unknown result type (might be due to invalid IL or missing references)
		return VehicleGamepadLookInputGet().y;
	}

	private float VehicleGamepadActionValueGet(InputKey key)
	{
		if (VehicleInputBlocked(key))
		{
			return 0f;
		}
		if (!inputActions.TryGetValue(key, out var value) || !value.enabled || value.activeControl == null || (object)value.activeControl.device != Gamepad.current)
		{
			return 0f;
		}
		return value.ReadValue<float>();
	}

	public void VehicleGamepadInputUpdate(ItemVehicle.VehicleGamepad gamepad, bool allowDrifting = true)
	{
		//IL_0021: Unknown result type (might be due to invalid IL or missing references)
		//IL_0026: Unknown result type (might be due to invalid IL or missing references)
		//IL_0009: Unknown result type (might be due to invalid IL or missing references)
		//IL_0079: Unknown result type (might be due to invalid IL or missing references)
		if (!VehicleGamepadInputAllowed())
		{
			gamepad.InputUpdate(Vector2.zero, 0f, 0f, leftShoulder: false, rightShoulder: false);
			return;
		}
		Vector2 stick = VehicleGamepadLookInputGet();
		float acceleration = VehicleGamepadActionValueGet(InputKey.VehicleAccelerate);
		float brake = VehicleGamepadActionValueGet(InputKey.VehicleBrake);
		bool leftShoulder = allowDrifting && VehicleGamepadActionValueGet(InputKey.VehicleDriftLeft) > 0f && KeyHold(InputKey.VehicleDriftLeft);
		bool rightShoulder = allowDrifting && VehicleGamepadActionValueGet(InputKey.VehicleDriftRight) > 0f && KeyHold(InputKey.VehicleDriftRight);
		gamepad.InputUpdate(stick, acceleration, brake, leftShoulder, rightShoulder);
	}

	public float VehicleThrottleGet()
	{
		if (!VehicleInputAllowed())
		{
			return 0f;
		}
		bool flag = KeyHold(InputKey.VehicleAccelerate);
		bool flag2 = KeyHold(InputKey.VehicleBrake);
		return (flag ? 1f : 0f) - (flag2 ? 1f : 0f);
	}

	public float VehicleSteeringGet()
	{
		if (!VehicleInputAllowed())
		{
			return 0f;
		}
		bool flag = KeyHold(InputKey.VehicleDriftLeft);
		return (KeyHold(InputKey.VehicleDriftRight) ? 1f : 0f) - (flag ? 1f : 0f);
	}

	private static bool VehicleControlsOverlap(InputControl control, InputControl vehicleControl)
	{
		InputControl val = control;
		while (val != null && !(val is InputDevice))
		{
			if (val == vehicleControl)
			{
				return true;
			}
			val = val.parent;
		}
		InputControl val2 = vehicleControl;
		while (val2 != null && !(val2 is InputDevice))
		{
			if (val2 == control)
			{
				return true;
			}
			val2 = val2.parent;
		}
		return false;
	}

	private bool VehicleGamepadControlReserved(InputKey key)
	{
		//IL_0059: Unknown result type (might be due to invalid IL or missing references)
		//IL_005e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0061: Unknown result type (might be due to invalid IL or missing references)
		//IL_0066: Unknown result type (might be due to invalid IL or missing references)
		//IL_0093: Unknown result type (might be due to invalid IL or missing references)
		//IL_0098: Unknown result type (might be due to invalid IL or missing references)
		//IL_009b: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a0: Unknown result type (might be due to invalid IL or missing references)
		if (!VehicleGamepadOverrideActive())
		{
			return false;
		}
		switch (key)
		{
		case InputKey.Grab:
			return false;
		case InputKey.MouseDelta:
			return true;
		case InputKey.VehicleAccelerate:
		case InputKey.VehicleBrake:
		case InputKey.VehicleDriftLeft:
		case InputKey.VehicleDriftRight:
			return false;
		default:
		{
			if (!inputActions.TryGetValue(key, out var value))
			{
				return false;
			}
			if (value.actionMap != inputSystemActions.Player.Get() && key != InputKey.PushPull)
			{
				return false;
			}
			Enumerator<InputControl> enumerator = value.controls.GetEnumerator();
			try
			{
				while (enumerator.MoveNext())
				{
					InputControl current = enumerator.Current;
					if ((object)current.device != Gamepad.current)
					{
						continue;
					}
					for (InputKey inputKey = InputKey.VehicleAccelerate; inputKey <= InputKey.VehicleDriftRight; inputKey++)
					{
						Enumerator<InputControl> enumerator2 = inputActions[inputKey].controls.GetEnumerator();
						try
						{
							while (enumerator2.MoveNext())
							{
								InputControl current2 = enumerator2.Current;
								if (VehicleControlsOverlap(current, current2))
								{
									return true;
								}
							}
						}
						finally
						{
							((IDisposable)enumerator2/*cast due to constrained. prefix*/).Dispose();
						}
					}
				}
			}
			finally
			{
				((IDisposable)enumerator/*cast due to constrained. prefix*/).Dispose();
			}
			return false;
		}
		}
	}

	private void OnDestroy()
	{
		InputSystem.onActionChange -= OnAnyGameplayInput;
		InputSystem.onDeviceChange -= GamepadRumbleDeviceChanged;
		GamepadRumbleReset();
	}

	internal void GamepadRumbleShake(CameraShake _source, float _strength, float _time)
	{
		if (((Behaviour)this).isActiveAndEnabled && GamepadRumbleAvailable() && inputSystemActions.Player.enabled && !(Time.timeScale <= 0f) && Object.op_Implicit((Object)(object)GameDirector.instance) && GameDirector.instance.currentState == GameDirector.gameState.Main && inputPercentSettings[InputPercentSetting.RumbleGamepad] > 0 && Object.op_Implicit((Object)(object)_source) && float.IsFinite(_strength) && float.IsFinite(_time))
		{
			if ((Object)(object)_source == (Object)(object)GameDirector.instance.CameraImpact)
			{
				rumbleImpactAnimation.Add(_source, _strength, _time);
			}
			else if ((Object)(object)_source == (Object)(object)GameDirector.instance.CameraShake)
			{
				rumbleShakeAnimation.Add(_source, _strength, _time);
			}
		}
	}

	private void GamepadRumbleAnimationTick()
	{
		float num = rumbleImpactAnimation.Tick(GameDirector.instance.CameraImpact);
		float num2 = rumbleShakeAnimation.Tick(GameDirector.instance.CameraShake);
		if (num > 0f)
		{
			OverrideGamepadRumble(num, _impact: true);
		}
		if (num2 > 0f)
		{
			OverrideGamepadRumble(num2, _impact: false);
		}
	}

	public void GamepadRumbleThock(RumbleThockType _type)
	{
		if (!((Behaviour)this).isActiveAndEnabled || !GamepadRumbleAvailable())
		{
			return;
		}
		float num;
		int num2;
		switch (_type)
		{
		default:
			return;
		case RumbleThockType.LetterTap:
			num = 0.28f;
			num2 = 0;
			break;
		case RumbleThockType.ConfirmTap:
			num = 0.75f;
			num2 = 3;
			break;
		case RumbleThockType.Deny:
			num = 0.85f;
			num2 = 4;
			break;
		case RumbleThockType.BigButton:
			num = 1f;
			num2 = 2;
			break;
		case RumbleThockType.MenuDown:
			num = 0.3f;
			num2 = 1;
			break;
		case RumbleThockType.MenuUp:
			num = 0.3f;
			num2 = 1;
			break;
		}
		float num3 = Mathf.Clamp01(num) * Mathf.Clamp01(1f);
		if (!(num3 <= 0f))
		{
			if (rumbleGamepad != null && rumbleGamepad != Gamepad.current)
			{
				GamepadRumbleReset();
			}
			if (!(rumbleThockTimer > 0f) || (num2 >= rumbleThockPriority && (num2 != rumbleThockPriority || rumbleThockFrame != Time.frameCount)))
			{
				rumbleThockStrength = num3;
				rumbleThockPriority = num2;
				rumbleThockFrame = Time.frameCount;
				rumbleThockTimer = 0.01f;
			}
		}
	}

	private Vector2 GamepadRumbleThockTick()
	{
		//IL_001e: Unknown result type (might be due to invalid IL or missing references)
		//IL_000d: Unknown result type (might be due to invalid IL or missing references)
		if (rumbleThockTimer <= 0f)
		{
			return Vector2.zero;
		}
		Vector2 result = new Vector2(0f, rumbleThockStrength);
		rumbleThockTimer = Mathf.Max(0f, rumbleThockTimer - Time.unscaledDeltaTime);
		return result;
	}

	private bool GamepadRumbleAvailable()
	{
		Gamepad current = Gamepad.current;
		if (CurrentMode == InputModes.Gamepad && Application.isFocused && current != null && ((InputDevice)current).added && ((InputDevice)current).enabled && inputSystemActions != null)
		{
			if (!inputSystemActions.Player.enabled)
			{
				return inputSystemActions.UI.enabled;
			}
			return true;
		}
		return false;
	}

	private void GamepadRumbleGameplayReset()
	{
		//IL_0064: Unknown result type (might be due to invalid IL or missing references)
		//IL_0069: Unknown result type (might be due to invalid IL or missing references)
		rumbleImpactAnimation.Reset();
		rumbleShakeAnimation.Reset();
		rumbleImpactStrength = 0f;
		rumbleImpactTimer = 0f;
		rumbleShakeStrength = 0f;
		rumbleShakeTimer = 0f;
		rumbleShakeSmoothed = 0f;
		rumbleOverrideStrength = 0f;
		rumbleOverrideTimer = 0f;
		rumbleContinuousStrength = Vector2.zero;
		rumbleContinuousTimer = 0f;
	}

	public void GamepadRumbleOverride(float _strength, float _time)
	{
		if (((Behaviour)this).isActiveAndEnabled && GamepadRumbleAvailable() && !(_time <= 0f) && !float.IsNaN(_strength) && !float.IsInfinity(_strength) && !float.IsNaN(_time) && !float.IsInfinity(_time))
		{
			if (rumbleGamepad != null && rumbleGamepad != Gamepad.current)
			{
				GamepadRumbleReset();
			}
			rumbleOverrideStrength = Mathf.Clamp01(_strength);
			rumbleOverrideTimer = _time;
		}
	}

	internal void GamepadRumbleContinuous(float _lowFrequency, float _highFrequency, float _time = 0.05f)
	{
		//IL_006e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0073: Unknown result type (might be due to invalid IL or missing references)
		if (((Behaviour)this).isActiveAndEnabled && GamepadRumbleAvailable() && inputSystemActions.Player.enabled && !(_time <= 0f) && float.IsFinite(_time) && float.IsFinite(_lowFrequency) && float.IsFinite(_highFrequency))
		{
			if (rumbleGamepad != null && rumbleGamepad != Gamepad.current)
			{
				GamepadRumbleReset();
			}
			rumbleContinuousStrength = new Vector2(Mathf.Clamp01(_lowFrequency), Mathf.Clamp01(_highFrequency));
			rumbleContinuousTimer = _time;
		}
	}

	public void OverrideGamepadRumble(float _strength, bool _impact, float _time = 0.1f)
	{
		if (((Behaviour)this).isActiveAndEnabled)
		{
			if (_impact)
			{
				rumbleImpactStrength = Mathf.Clamp01(_strength);
				rumbleImpactTimer = Mathf.Max(rumbleImpactTimer, _time);
			}
			else
			{
				rumbleShakeStrength = Mathf.Clamp01(_strength);
				rumbleShakeTimer = Mathf.Max(rumbleShakeTimer, _time);
			}
		}
	}

	private void GamepadRumbleTick()
	{
		//IL_0106: Unknown result type (might be due to invalid IL or missing references)
		//IL_010b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0199: Unknown result type (might be due to invalid IL or missing references)
		//IL_01aa: Unknown result type (might be due to invalid IL or missing references)
		Gamepad current = Gamepad.current;
		if (!GamepadRumbleAvailable())
		{
			GamepadRumbleReset();
			return;
		}
		if (rumbleGamepad != null && rumbleGamepad != current)
		{
			GamepadRumbleReset();
			return;
		}
		float num = Mathf.Clamp01((float)inputPercentSettings[InputPercentSetting.RumbleGamepad] / 100f);
		if (num <= 0f)
		{
			GamepadRumbleReset();
			return;
		}
		rumbleGamepad = current;
		if (Time.timeScale <= 0f || !Object.op_Implicit((Object)(object)GameDirector.instance) || (GameDirector.instance.currentState != GameDirector.gameState.Main && GameDirector.instance.currentState != GameDirector.gameState.Death) || !inputSystemActions.Player.enabled)
		{
			GamepadRumbleGameplayReset();
		}
		else
		{
			GamepadRumbleAnimationTick();
		}
		if (rumbleImpactTimer <= 0f)
		{
			rumbleImpactStrength = 0f;
		}
		if (rumbleShakeTimer <= 0f)
		{
			rumbleShakeStrength = 0f;
		}
		rumbleShakeSmoothed = Mathf.MoveTowards(rumbleShakeSmoothed, rumbleShakeStrength, 4f * Time.unscaledDeltaTime);
		Vector2 val = GamepadRumbleThockTick();
		float num2 = Mathf.Max(rumbleImpactStrength, rumbleShakeSmoothed * 0.35f);
		float num3 = Mathf.Max(rumbleImpactStrength * 0.8f, rumbleShakeSmoothed * 0.15f);
		if (rumbleContinuousTimer > 0f)
		{
			num2 = Mathf.Max(num2, rumbleContinuousStrength.x);
			num3 = Mathf.Max(num3, rumbleContinuousStrength.y);
		}
		if (rumbleOverrideTimer > 0f)
		{
			num2 = rumbleOverrideStrength;
			num3 = rumbleOverrideStrength * 0.8f;
		}
		float lowFrequency = Mathf.Max(num2, val.x) * num;
		float highFrequency = Mathf.Max(num3, val.y) * num;
		GamepadRumbleSet(lowFrequency, highFrequency);
		if (rumbleContinuousTimer > 0f)
		{
			rumbleContinuousTimer = Mathf.Max(0f, rumbleContinuousTimer - Time.unscaledDeltaTime);
		}
		if (rumbleOverrideTimer > 0f)
		{
			rumbleOverrideTimer = Mathf.Max(0f, rumbleOverrideTimer - Time.unscaledDeltaTime);
		}
		if (rumbleImpactTimer > 0f)
		{
			rumbleImpactTimer = Mathf.Max(0f, rumbleImpactTimer - Time.unscaledDeltaTime);
		}
		if (rumbleShakeTimer > 0f)
		{
			rumbleShakeTimer = Mathf.Max(0f, rumbleShakeTimer - Time.unscaledDeltaTime);
		}
	}

	private void GamepadRumbleSet(float _lowFrequency, float _highFrequency)
	{
		if (!Mathf.Approximately(rumbleLowFrequency, _lowFrequency) || !Mathf.Approximately(rumbleHighFrequency, _highFrequency))
		{
			rumbleGamepad.SetMotorSpeeds(_lowFrequency, _highFrequency);
			rumbleLowFrequency = _lowFrequency;
			rumbleHighFrequency = _highFrequency;
		}
	}

	internal void GamepadRumbleReset()
	{
		if (rumbleGamepad != null && ((InputDevice)rumbleGamepad).added)
		{
			rumbleGamepad.ResetHaptics();
		}
		rumbleGamepad = null;
		GamepadRumbleGameplayReset();
		rumbleThockTimer = 0f;
		rumbleThockStrength = 0f;
		rumbleThockPriority = 0;
		rumbleThockFrame = -1;
		rumbleLowFrequency = 0f;
		rumbleHighFrequency = 0f;
	}

	private void OnEnable()
	{
		if ((Object)(object)instance == (Object)(object)this)
		{
			InputSystem.onDeviceChange += GamepadRumbleDeviceChanged;
		}
	}

	private void OnDisable()
	{
		InputSystem.onDeviceChange -= GamepadRumbleDeviceChanged;
		GamepadRumbleReset();
	}

	private void OnApplicationFocus(bool _focused)
	{
		if (!_focused)
		{
			GamepadRumbleReset();
		}
	}

	private void OnApplicationPause(bool _paused)
	{
		if (_paused)
		{
			GamepadRumbleReset();
		}
	}

	private void OnApplicationQuit()
	{
		GamepadRumbleReset();
	}

	private void GamepadRumbleDeviceChanged(InputDevice _device, InputDeviceChange _change)
	{
		//IL_000a: Unknown result type (might be due to invalid IL or missing references)
		//IL_000c: Invalid comparison between Unknown and I4
		//IL_000e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0010: Invalid comparison between Unknown and I4
		//IL_0012: Unknown result type (might be due to invalid IL or missing references)
		//IL_0014: Invalid comparison between Unknown and I4
		//IL_0016: Unknown result type (might be due to invalid IL or missing references)
		//IL_0018: Invalid comparison between Unknown and I4
		//IL_001a: Unknown result type (might be due to invalid IL or missing references)
		//IL_001d: Invalid comparison between Unknown and I4
		if ((object)_device == rumbleGamepad && ((int)_change == 2 || (int)_change == 1 || (int)_change == 5 || (int)_change == 8 || (int)_change == 9))
		{
			GamepadRumbleReset();
		}
	}

	private void UpdateLocalizedActionDictionaries()
	{
		foreach (ControlLocalizationPair localizedKeyboardActions in localizedKeyboardActionsList)
		{
			this.localizedKeyboardActions.Add(localizedKeyboardActions.controlPath, localizedKeyboardActions.LocalizedAsset);
		}
		foreach (ControlLocalizationPair localizedMouseActions in localizedMouseActionsList)
		{
			this.localizedMouseActions.Add(localizedMouseActions.controlPath, localizedMouseActions.LocalizedAsset);
		}
	}

	internal void InitializeInputs()
	{
		//IL_00ef: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f4: Unknown result type (might be due to invalid IL or missing references)
		//IL_0101: Unknown result type (might be due to invalid IL or missing references)
		//IL_0106: Unknown result type (might be due to invalid IL or missing references)
		//IL_01b8: Unknown result type (might be due to invalid IL or missing references)
		//IL_01be: Expected Obj, but got Unknown
		//IL_01c7: Unknown result type (might be due to invalid IL or missing references)
		//IL_022d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0233: Expected Obj, but got Unknown
		//IL_06f5: Unknown result type (might be due to invalid IL or missing references)
		//IL_06fb: Expected Obj, but got Unknown
		//IL_0733: Unknown result type (might be due to invalid IL or missing references)
		//IL_0739: Expected Obj, but got Unknown
		//IL_0755: Unknown result type (might be due to invalid IL or missing references)
		//IL_075b: Expected Obj, but got Unknown
		//IL_0777: Unknown result type (might be due to invalid IL or missing references)
		//IL_077d: Expected Obj, but got Unknown
		//IL_0799: Unknown result type (might be due to invalid IL or missing references)
		//IL_079f: Expected Obj, but got Unknown
		//IL_07bb: Unknown result type (might be due to invalid IL or missing references)
		//IL_07c1: Expected Obj, but got Unknown
		inputSystemActions = new InputSystem_Actions();
		InputSystem.onActionChange += OnAnyGameplayInput;
		inputActions = new Dictionary<InputKey, InputAction>();
		movementBindingIndices = new Dictionary<MovementDirection, int>();
		inputToggleKeyboardMouse = new Dictionary<InputKey, bool>();
		inputToggleGamepad = new Dictionary<InputKey, bool>();
		InputAction movement = inputSystemActions.Player.Movement;
		inputActions[InputKey.Movement] = movement;
		inputActions[InputKey.UINavigate] = inputSystemActions.UI.Navigate;
		inputActions[InputKey.UIClick] = inputSystemActions.UI.Click;
		inputActions[InputKey.UITabLeft] = inputSystemActions.UI.TabLeft;
		inputActions[InputKey.UITabRight] = inputSystemActions.UI.TabRight;
		ReadOnlyArray<InputBinding> bindings = movement.bindings;
		for (int i = 0; i < bindings.Count; i++)
		{
			InputBinding val = bindings[i];
			if (val.isPartOfComposite)
			{
				switch (val.name.ToLower())
				{
				case "up":
					movementBindingIndices[MovementDirection.Up] = i;
					break;
				case "down":
					movementBindingIndices[MovementDirection.Down] = i;
					break;
				case "left":
					movementBindingIndices[MovementDirection.Left] = i;
					break;
				case "right":
					movementBindingIndices[MovementDirection.Right] = i;
					break;
				}
			}
		}
		InputAction val2 = new InputAction("Scroll", (InputActionType)0, (string)null, (string)null, (string)null, (string)null);
		InputActionSetupExtensions.AddBinding(val2, "<Mouse>/scroll/y", (string)null, (string)null, (string)null);
		inputActions[InputKey.Scroll] = val2;
		InputAction jump = inputSystemActions.Player.Jump;
		inputActions[InputKey.Jump] = jump;
		jump = inputSystemActions.Player.Use;
		inputActions[InputKey.Interact] = jump;
		jump = new InputAction("MouseInput", (InputActionType)0, "<Pointer>/position", (string)null, (string)null, (string)null);
		inputActions[InputKey.MouseInput] = jump;
		InputAction push = inputSystemActions.Player.Push;
		inputActions[InputKey.Push] = push;
		InputAction pull = inputSystemActions.Player.Pull;
		inputActions[InputKey.Pull] = pull;
		InputAction pushPull = inputSystemActions.Player.PushPull;
		inputActions[InputKey.PushPull] = pushPull;
		inputToggleKeyboardMouse.Add(InputKey.PushPull, value: false);
		inputToggleGamepad.Add(InputKey.PushPull, value: false);
		jump = inputSystemActions.Application.Menu;
		inputActions[InputKey.Menu] = jump;
		jump = inputSystemActions.Application.Back;
		inputActions[InputKey.Back] = jump;
		jump = inputSystemActions.Application.BackEditor;
		inputActions[InputKey.BackEditor] = jump;
		jump = inputSystemActions.Application.DebugConsole;
		inputActions[InputKey.DebugConsole] = jump;
		jump = inputSystemActions.Application.Chat;
		inputActions[InputKey.Chat] = jump;
		jump = inputSystemActions.Player.Map;
		inputActions[InputKey.Map] = jump;
		inputToggleKeyboardMouse.Add(InputKey.Map, value: false);
		inputToggleGamepad.Add(InputKey.Map, value: false);
		jump = inputSystemActions.Application.ChatConfirm;
		inputActions[InputKey.ChatConfirm] = jump;
		jump = inputSystemActions.Player.Grab;
		inputActions[InputKey.Grab] = jump;
		inputToggleKeyboardMouse.Add(InputKey.Grab, value: false);
		inputToggleGamepad.Add(InputKey.Grab, value: false);
		jump = inputSystemActions.Player.Rotate;
		inputActions[InputKey.Rotate] = jump;
		jump = inputSystemActions.Player.Crouch;
		inputActions[InputKey.Crouch] = jump;
		inputToggleKeyboardMouse.Add(InputKey.Crouch, value: false);
		inputToggleGamepad.Add(InputKey.Crouch, value: true);
		jump = inputSystemActions.Application.ChatDelete;
		inputActions[InputKey.ChatDelete] = jump;
		jump = inputSystemActions.Player.Tumble;
		inputActions[InputKey.Tumble] = jump;
		jump = inputSystemActions.Player.Sprint;
		inputActions[InputKey.Sprint] = jump;
		inputToggleKeyboardMouse.Add(InputKey.Sprint, value: false);
		inputToggleGamepad.Add(InputKey.Sprint, value: true);
		jump = inputSystemActions.Player.MouseDelta;
		inputActions[InputKey.MouseDelta] = jump;
		inputActions[InputKey.Inventory1] = inputSystemActions.Player.Inventory1;
		inputActions[InputKey.Inventory2] = inputSystemActions.Player.Inventory2;
		inputActions[InputKey.Inventory3] = inputSystemActions.Player.Inventory3;
		inputActions[InputKey.SpectateNext] = inputSystemActions.Player.SpectateNext;
		inputActions[InputKey.SpectatePrevious] = inputSystemActions.Player.SpectatePrevious;
		jump = inputSystemActions.Application.PushToTalk;
		inputActions[InputKey.PushToTalk] = jump;
		jump = inputSystemActions.Application.ToggleMute;
		inputActions[InputKey.ToggleMute] = jump;
		inputPercentSettings = new Dictionary<InputPercentSetting, int>();
		inputPercentSettings[InputPercentSetting.MouseSensitivity] = 50;
		inputPercentSettings[InputPercentSetting.GrabCursorDriftMouseAndKeyboard] = 0;
		inputPercentSettings[InputPercentSetting.GrabCursorDriftGamepad] = 20;
		inputPercentSettings[InputPercentSetting.GrabCursorDriftSpeedMouseAndKeyboard] = 50;
		inputPercentSettings[InputPercentSetting.GrabCursorDriftSpeedGamepad] = 5;
		inputPercentSettings[InputPercentSetting.MeleeGrabCursorDriftMouseAndKeyboard] = 0;
		inputPercentSettings[InputPercentSetting.MeleeGrabCursorDriftGamepad] = 50;
		inputPercentSettings[InputPercentSetting.MeleeGrabCursorDriftSpeedMouseAndKeyboard] = 50;
		inputPercentSettings[InputPercentSetting.MeleeGrabCursorDriftSpeedGamepad] = 50;
		inputPercentSettings[InputPercentSetting.AimSensitivityGamepad] = 40;
		inputPercentSettings[InputPercentSetting.AimAccelerationGamepad] = 50;
		inputPercentSettings[InputPercentSetting.AimInvertVerticalGamepad] = 0;
		inputPercentSettings[InputPercentSetting.RumbleGamepad] = 100;
		inputPercentSettings[InputPercentSetting.ExpressionWheelRightStickGamepad] = 0;
		inputPercentSettings[InputPercentSetting.RotationSensitivityGamepad] = 50;
		jump = new InputAction("Expression1", (InputActionType)0, "<Keyboard>/5", (string)null, (string)null, (string)null);
		inputActions[InputKey.Expression1] = jump;
		inputToggleKeyboardMouse.Add(InputKey.Expression1, value: true);
		inputToggleGamepad.Add(InputKey.Expression1, value: true);
		jump = new InputAction("Expression2", (InputActionType)0, "<Keyboard>/6", (string)null, (string)null, (string)null);
		inputActions[InputKey.Expression2] = jump;
		jump = new InputAction("Expression3", (InputActionType)0, "<Keyboard>/7", (string)null, (string)null, (string)null);
		inputActions[InputKey.Expression3] = jump;
		jump = new InputAction("Expression4", (InputActionType)0, "<Keyboard>/8", (string)null, (string)null, (string)null);
		inputActions[InputKey.Expression4] = jump;
		jump = new InputAction("Expression5", (InputActionType)0, "<Keyboard>/9", (string)null, (string)null, (string)null);
		inputActions[InputKey.Expression5] = jump;
		jump = new InputAction("Expression6", (InputActionType)0, "<Keyboard>/0", (string)null, (string)null, (string)null);
		inputActions[InputKey.Expression6] = jump;
		VehicleGamepadBindingsSetup();
		ExpressionWheelBindingSetup();
		foreach (InputAction value in inputActions.Values)
		{
			value.Enable();
		}
		inputSystemActions.Application.Enable();
		CacheUINavigateMirrorBindings();
		SyncUINavigateWithMovement();
	}

	public void OnAnyGameplayInput(object obj, InputActionChange change)
	{
		//IL_0000: Unknown result type (might be due to invalid IL or missing references)
		//IL_0002: Invalid comparison between Unknown and I4
		if ((int)change != 5)
		{
			return;
		}
		object obj2 = ((obj is InputAction) ? obj : null);
		InputControl val = ((obj2 != null) ? ((InputAction)obj2).activeControl : null);
		if (val == null || !InputControlExtensions.IsActuated(val, 0f))
		{
			return;
		}
		ButtonControl val2 = (ButtonControl)(object)((val is ButtonControl) ? val : null);
		if (val2 == null || val2.isPressed)
		{
			if (val.device is Gamepad)
			{
				gamepadRecentInputTimer = 2f;
			}
			if (!MouseDeltaTooSmallForDeviceSwitch(val) && TryClassifyDevice(val.device, out var deviceType))
			{
				bool bypassDebounce = val is ButtonControl;
				SetDeviceType(deviceType, bypassDebounce);
			}
		}
	}

	private bool MouseDeltaTooSmallForDeviceSwitch(InputControl _control)
	{
		//IL_0020: Unknown result type (might be due to invalid IL or missing references)
		//IL_0025: Unknown result type (might be due to invalid IL or missing references)
		InputDevice device = _control.device;
		Mouse val = (Mouse)(object)((device is Mouse) ? device : null);
		if (val == null || (object)_control != ((Pointer)val).delta)
		{
			return false;
		}
		Vector2 val2 = ((InputControl<Vector2>)(object)((Pointer)val).delta).ReadValue();
		return val2.sqrMagnitude < 4f;
	}

	private bool GamepadHeld()
	{
		//IL_0000: Unknown result type (might be due to invalid IL or missing references)
		//IL_0005: Unknown result type (might be due to invalid IL or missing references)
		//IL_0008: Unknown result type (might be due to invalid IL or missing references)
		//IL_000d: Unknown result type (might be due to invalid IL or missing references)
		//IL_002c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0031: Unknown result type (might be due to invalid IL or missing references)
		//IL_0046: Unknown result type (might be due to invalid IL or missing references)
		//IL_004b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0060: Unknown result type (might be due to invalid IL or missing references)
		//IL_0065: Unknown result type (might be due to invalid IL or missing references)
		//IL_0069: Unknown result type (might be due to invalid IL or missing references)
		//IL_006e: Unknown result type (might be due to invalid IL or missing references)
		Enumerator<Gamepad> enumerator = Gamepad.all.GetEnumerator();
		try
		{
			while (enumerator.MoveNext())
			{
				Gamepad current = enumerator.Current;
				if (!((InputDevice)current).enabled)
				{
					continue;
				}
				Vector2 val = ((InputControl<Vector2>)(object)current.leftStick).ReadValue();
				if (!(val.magnitude > 0.2f))
				{
					val = ((InputControl<Vector2>)(object)current.rightStick).ReadValue();
					if (!(val.magnitude > 0.2f))
					{
						Enumerator<InputControl> enumerator2 = ((InputDevice)current).allControls.GetEnumerator();
						try
						{
							while (enumerator2.MoveNext())
							{
								InputControl current2 = enumerator2.Current;
								ButtonControl val2 = (ButtonControl)(object)((current2 is ButtonControl) ? current2 : null);
								if (val2 != null && !((InputControl)val2).synthetic && val2.isPressed)
								{
									return true;
								}
							}
						}
						finally
						{
							((IDisposable)enumerator2/*cast due to constrained. prefix*/).Dispose();
						}
						continue;
					}
				}
				return true;
			}
		}
		finally
		{
			((IDisposable)enumerator/*cast due to constrained. prefix*/).Dispose();
		}
		return false;
	}

	private bool TryClassifyDevice(InputDevice device, out InputDeviceType deviceType)
	{
		if (device is Keyboard || device is Mouse)
		{
			deviceType = InputDeviceType.KeyboardMouse;
			return true;
		}
		Gamepad val = (Gamepad)(object)((device is Gamepad) ? device : null);
		if (val != null)
		{
			deviceType = ClassifyGamepad(val);
			return true;
		}
		deviceType = InputDeviceType.KeyboardMouse;
		return false;
	}

	private InputDeviceType ClassifyGamepad(Gamepad gamepad)
	{
		//IL_0025: Unknown result type (might be due to invalid IL or missing references)
		//IL_002a: Unknown result type (might be due to invalid IL or missing references)
		if (gamepad is XInputController)
		{
			return InputDeviceType.Xbox;
		}
		if (gamepad is DualShockGamepad)
		{
			return InputDeviceType.PlayStation;
		}
		string text = ((InputControl)gamepad).layout ?? string.Empty;
		InputDeviceDescription description = ((InputDevice)gamepad).description;
		string text2 = description.product ?? string.Empty;
		if (text.IndexOf("Switch", StringComparison.OrdinalIgnoreCase) >= 0 || text.IndexOf("NPad", StringComparison.OrdinalIgnoreCase) >= 0)
		{
			return InputDeviceType.Switch;
		}
		if (text.IndexOf("Steam", StringComparison.OrdinalIgnoreCase) >= 0 || text2.IndexOf("Steam", StringComparison.OrdinalIgnoreCase) >= 0)
		{
			if (text.IndexOf("Deck", StringComparison.OrdinalIgnoreCase) < 0 && text2.IndexOf("Deck", StringComparison.OrdinalIgnoreCase) < 0)
			{
				return InputDeviceType.SteamController;
			}
			return InputDeviceType.SteamDeck;
		}
		return InputDeviceType.GenericGamepad;
	}

	private void SetDeviceType(InputDeviceType deviceType, bool bypassDebounce = false)
	{
		if (CurrentDeviceType == deviceType)
		{
			inputChangeDebounceTimer = 0.5f;
		}
		else if ((!(inputChangeDebounceTimer > 0f) || bypassDebounce) && (deviceType != InputDeviceType.KeyboardMouse || !(gamepadRecentInputTimer > 0f) || !GamepadHeld()))
		{
			inputChangeDebounceTimer = 0.5f;
			InputModes mode = ((deviceType != InputDeviceType.KeyboardMouse) ? InputModes.Gamepad : InputModes.MouseAndKeyboard);
			SetMode(mode);
			CurrentDeviceType = deviceType;
			Debug.Log((object)("[InputManager] Input device changed to: " + deviceType));
			OnDeviceTypeChanged?.Invoke(deviceType);
			InputGlyphs.NotifyGlyphsChanged();
		}
	}

	private void SetMode(InputModes mode)
	{
		if (CurrentMode != mode)
		{
			GamepadRumbleReset();
			CurrentMode = mode;
			Debug.Log((object)("[InputManager] Input mode changed to: " + mode));
		}
	}

	public int GetActiveBindingIndex(InputAction action)
	{
		return GetActiveBindingIndex(action, CurrentDeviceType);
	}

	public int GetActiveBindingIndex(InputAction action, InputDeviceType deviceType)
	{
		string scheme = ((deviceType == InputDeviceType.KeyboardMouse) ? "Keyboard&Mouse" : "Gamepad");
		return GetActiveBindingIndexForScheme(action, scheme);
	}

	public int GetActiveBindingIndexForScheme(InputAction action, string scheme, int occurrence = 0)
	{
		//IL_0006: Unknown result type (might be due to invalid IL or missing references)
		//IL_000b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0015: Unknown result type (might be due to invalid IL or missing references)
		//IL_001a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_0054: Unknown result type (might be due to invalid IL or missing references)
		//IL_0059: Unknown result type (might be due to invalid IL or missing references)
		if (action == null)
		{
			return -1;
		}
		ReadOnlyArray<InputBinding> bindings = action.bindings;
		int num = 0;
		for (int i = 0; i < bindings.Count; i++)
		{
			InputBinding binding = bindings[i];
			if (!binding.isComposite && BindingMatchesScheme(binding, scheme))
			{
				if (num == occurrence)
				{
					return i;
				}
				num++;
			}
		}
		if (occurrence > 0)
		{
			return -1;
		}
		for (int j = 0; j < bindings.Count; j++)
		{
			InputBinding val = bindings[j];
			if (!val.isComposite)
			{
				return j;
			}
		}
		return 0;
	}

	private static bool BindingMatchesScheme(InputBinding binding, string scheme)
	{
		if (string.IsNullOrEmpty(binding.groups))
		{
			return scheme == "Keyboard&Mouse";
		}
		string[] array = binding.groups.Split(';');
		for (int i = 0; i < array.Length; i++)
		{
			if (array[i].Trim().Equals(scheme, StringComparison.OrdinalIgnoreCase))
			{
				return true;
			}
		}
		return false;
	}

	public string GetActiveControlPath(InputKey key)
	{
		return GetActiveControlPath(key, CurrentDeviceType);
	}

	public string GetActiveControlPath(InputKey key, InputDeviceType deviceType)
	{
		//IL_001c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0021: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0033: Unknown result type (might be due to invalid IL or missing references)
		//IL_0037: Unknown result type (might be due to invalid IL or missing references)
		//IL_003c: Unknown result type (might be due to invalid IL or missing references)
		InputAction action = GetAction(key);
		if (action == null)
		{
			return null;
		}
		int activeBindingIndex = GetActiveBindingIndex(action, deviceType);
		if (activeBindingIndex < 0 || activeBindingIndex >= action.bindings.Count)
		{
			return null;
		}
		InputBinding val = action.bindings[activeBindingIndex];
		return val.effectivePath;
	}

	public void SwitchToPlayerInputs()
	{
		Debug.Log((object)"[InputManager] Switch to Player Inputs");
		inputSystemActions.Player.Enable();
		inputSystemActions.UI.Disable();
		heldFromUIActions.Clear();
		foreach (InputAction item in inputSystemActions.Player.Get())
		{
			if (ActionButtonHeld(item))
			{
				heldFromUIActions.Add(item);
			}
		}
	}

	private static bool ActionButtonHeld(InputAction action)
	{
		//IL_0001: Unknown result type (might be due to invalid IL or missing references)
		//IL_0007: Invalid comparison between Unknown and I4
		//IL_002e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0033: Unknown result type (might be due to invalid IL or missing references)
		//IL_0036: Unknown result type (might be due to invalid IL or missing references)
		//IL_003b: Unknown result type (might be due to invalid IL or missing references)
		if ((int)action.type != 1 && !string.IsNullOrEmpty(action.expectedControlType) && !(action.expectedControlType == "Button"))
		{
			return false;
		}
		Enumerator<InputControl> enumerator = action.controls.GetEnumerator();
		try
		{
			while (enumerator.MoveNext())
			{
				InputControl current = enumerator.Current;
				ButtonControl val = (ButtonControl)(object)((current is ButtonControl) ? current : null);
				if (val != null && val.isPressed)
				{
					return true;
				}
			}
		}
		finally
		{
			((IDisposable)enumerator/*cast due to constrained. prefix*/).Dispose();
		}
		return false;
	}

	private bool HeldFromUI(InputAction action)
	{
		if (heldFromUIActions.Count > 0)
		{
			return heldFromUIActions.Contains(action);
		}
		return false;
	}

	public void SwitchToUIInputs()
	{
		Debug.Log((object)"[InputManager] Switch to UI Inputs");
		inputSystemActions.UI.Enable();
		inputSystemActions.Player.Disable();
		GamepadRumbleGameplayReset();
	}

	private static Dictionary<InputKey, List<string>> ExtractSchemeOverrides(Dictionary<InputKey, InputAction> actions, string scheme)
	{
		//IL_0027: Unknown result type (might be due to invalid IL or missing references)
		//IL_002c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0030: Unknown result type (might be due to invalid IL or missing references)
		//IL_0035: Unknown result type (might be due to invalid IL or missing references)
		//IL_003b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0040: Unknown result type (might be due to invalid IL or missing references)
		//IL_0042: Unknown result type (might be due to invalid IL or missing references)
		Dictionary<InputKey, List<string>> dictionary = new Dictionary<InputKey, List<string>>();
		foreach (KeyValuePair<InputKey, InputAction> action in actions)
		{
			InputAction value = action.Value;
			List<string> list = new List<string>();
			Enumerator<InputBinding> enumerator2 = value.bindings.GetEnumerator();
			try
			{
				while (enumerator2.MoveNext())
				{
					InputBinding current2 = enumerator2.Current;
					if (BindingMatchesScheme(current2, scheme))
					{
						list.Add(current2.overridePath ?? current2.path);
					}
					else
					{
						list.Add(null);
					}
				}
			}
			finally
			{
				((IDisposable)enumerator2/*cast due to constrained. prefix*/).Dispose();
			}
			dictionary[action.Key] = list;
		}
		return dictionary;
	}

	private static Dictionary<InputKey, List<string>> ExtractLegacyOverrides(Dictionary<InputKey, InputAction> actions)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_0029: Unknown result type (might be due to invalid IL or missing references)
		//IL_002d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0032: Unknown result type (might be due to invalid IL or missing references)
		//IL_0038: Unknown result type (might be due to invalid IL or missing references)
		//IL_003d: Unknown result type (might be due to invalid IL or missing references)
		Dictionary<InputKey, List<string>> dictionary = new Dictionary<InputKey, List<string>>();
		foreach (KeyValuePair<InputKey, InputAction> action in actions)
		{
			List<string> list = new List<string>();
			Enumerator<InputBinding> enumerator2 = action.Value.bindings.GetEnumerator();
			try
			{
				while (enumerator2.MoveNext())
				{
					InputBinding current2 = enumerator2.Current;
					list.Add(current2.overridePath ?? current2.path);
				}
			}
			finally
			{
				((IDisposable)enumerator2/*cast due to constrained. prefix*/).Dispose();
			}
			dictionary[action.Key] = list;
		}
		return dictionary;
	}

	private static Dictionary<InputKey, List<string>> FilterOverridesForScheme(Dictionary<InputKey, List<string>> positionalOverrides, Dictionary<InputKey, InputAction> actions, string scheme)
	{
		//IL_0052: Unknown result type (might be due to invalid IL or missing references)
		//IL_0057: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c7: Unknown result type (might be due to invalid IL or missing references)
		//IL_00cc: Unknown result type (might be due to invalid IL or missing references)
		//IL_0095: Unknown result type (might be due to invalid IL or missing references)
		//IL_009a: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a0: Unknown result type (might be due to invalid IL or missing references)
		Dictionary<InputKey, List<string>> dictionary = new Dictionary<InputKey, List<string>>();
		if (positionalOverrides == null)
		{
			return dictionary;
		}
		foreach (KeyValuePair<InputKey, List<string>> positionalOverride in positionalOverrides)
		{
			if (!actions.TryGetValue(positionalOverride.Key, out var value))
			{
				continue;
			}
			List<string> value2 = positionalOverride.Value;
			if (value2 == null)
			{
				continue;
			}
			List<string> list = new List<string>();
			bool flag = value2.Count != value.bindings.Count;
			for (int i = 0; i < value.bindings.Count; i++)
			{
				if (i >= value2.Count || (flag && scheme != "Keyboard&Mouse"))
				{
					list.Add(null);
				}
				else
				{
					list.Add(BindingMatchesScheme(value.bindings[i], scheme) ? value2[i] : null);
				}
			}
			dictionary[positionalOverride.Key] = list;
		}
		return dictionary;
	}

	private static void ApplySchemeOverrides(Dictionary<InputKey, InputAction> actions, Dictionary<InputKey, List<string>> overrides, List<ExcludedControlEntry> exclusions)
	{
		//IL_004f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0054: Unknown result type (might be due to invalid IL or missing references)
		//IL_0102: Unknown result type (might be due to invalid IL or missing references)
		//IL_0107: Unknown result type (might be due to invalid IL or missing references)
		//IL_009e: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a9: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ae: Unknown result type (might be due to invalid IL or missing references)
		if (overrides == null)
		{
			return;
		}
		foreach (InputKey key in overrides.Keys)
		{
			if (!actions.TryGetValue(key, out var value))
			{
				continue;
			}
			List<string> list = overrides[key];
			if (list.Count != value.bindings.Count)
			{
				continue;
			}
			ExcludedControlEntry excludedControlEntry = exclusions?.Find((ExcludedControlEntry x) => x.inputKey == key);
			bool enabled = value.enabled;
			value.Disable();
			for (int num = 0; num < list.Count && num < value.bindings.Count; num++)
			{
				string text = list[num];
				if (text == null)
				{
					continue;
				}
				InputBinding val = value.bindings[num];
				if (!val.isComposite)
				{
					if (text.Length == 0)
					{
						InputActionRebindingExtensions.ApplyBindingOverride(value, num, "");
					}
					else if (excludedControlEntry == null || !excludedControlEntry.excludedPaths.Contains(text))
					{
						InputActionRebindingExtensions.ApplyBindingOverride(value, num, text);
					}
				}
			}
			if (enabled)
			{
				value.Enable();
			}
		}
	}

	private void CacheUINavigateMirrorBindings()
	{
		//IL_002f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0034: Unknown result type (might be due to invalid IL or missing references)
		//IL_0051: Unknown result type (might be due to invalid IL or missing references)
		//IL_0056: Unknown result type (might be due to invalid IL or missing references)
		//IL_0061: Unknown result type (might be due to invalid IL or missing references)
		//IL_0066: Unknown result type (might be due to invalid IL or missing references)
		//IL_0196: Unknown result type (might be due to invalid IL or missing references)
		//IL_019b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0089: Unknown result type (might be due to invalid IL or missing references)
		//IL_008e: Unknown result type (might be due to invalid IL or missing references)
		//IL_014d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0152: Unknown result type (might be due to invalid IL or missing references)
		//IL_0158: Unknown result type (might be due to invalid IL or missing references)
		//IL_015d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0099: Unknown result type (might be due to invalid IL or missing references)
		//IL_0171: Unknown result type (might be due to invalid IL or missing references)
		//IL_01bc: Unknown result type (might be due to invalid IL or missing references)
		//IL_01c1: Unknown result type (might be due to invalid IL or missing references)
		//IL_01cc: Unknown result type (might be due to invalid IL or missing references)
		uiNavigateMirrors = new List<UINavigateMirror>();
		if (!inputActions.TryGetValue(InputKey.Movement, out var value) || !inputActions.TryGetValue(InputKey.UINavigate, out var value2))
		{
			return;
		}
		ReadOnlyArray<InputBinding> bindings = value2.bindings;
		foreach (KeyValuePair<MovementDirection, int> movementBindingIndex in movementBindingIndices)
		{
			InputBinding val = value.bindings[movementBindingIndex.Value];
			string path = val.path;
			if (string.IsNullOrEmpty(path))
			{
				continue;
			}
			for (int i = 0; i < bindings.Count; i++)
			{
				InputBinding binding = bindings[i];
				if (binding.isPartOfComposite && BindingMatchesScheme(binding, "Keyboard&Mouse") && string.Equals(binding.name, movementBindingIndex.Key.ToString(), StringComparison.OrdinalIgnoreCase) && !(binding.path != path))
				{
					uiNavigateMirrors.Add(new UINavigateMirror
					{
						navigateIndex = i,
						movementIndex = movementBindingIndex.Value,
						suffix = null
					});
					break;
				}
			}
		}
		int movementIndex = -1;
		string text = null;
		for (int j = 0; j < value.bindings.Count; j++)
		{
			InputBinding binding2 = value.bindings[j];
			if (!binding2.isComposite && !binding2.isPartOfComposite && BindingMatchesScheme(binding2, "Gamepad"))
			{
				movementIndex = j;
				text = binding2.path;
				break;
			}
		}
		if (string.IsNullOrEmpty(text))
		{
			return;
		}
		for (int k = 0; k < bindings.Count; k++)
		{
			InputBinding binding3 = bindings[k];
			if (binding3.isPartOfComposite && BindingMatchesScheme(binding3, "Gamepad") && binding3.path != null && binding3.path.StartsWith(text + "/", StringComparison.OrdinalIgnoreCase))
			{
				uiNavigateMirrors.Add(new UINavigateMirror
				{
					navigateIndex = k,
					movementIndex = movementIndex,
					suffix = binding3.path.Substring(text.Length)
				});
			}
		}
	}

	public void SyncUINavigateWithMovement()
	{
		//IL_0051: Unknown result type (might be due to invalid IL or missing references)
		//IL_0056: Unknown result type (might be due to invalid IL or missing references)
		//IL_0061: Unknown result type (might be due to invalid IL or missing references)
		//IL_0066: Unknown result type (might be due to invalid IL or missing references)
		if (uiNavigateMirrors == null || !inputActions.TryGetValue(InputKey.Movement, out var value) || !inputActions.TryGetValue(InputKey.UINavigate, out var value2))
		{
			return;
		}
		bool enabled = value2.enabled;
		value2.Disable();
		foreach (UINavigateMirror uiNavigateMirror in uiNavigateMirrors)
		{
			InputBinding val = value.bindings[uiNavigateMirror.movementIndex];
			string effectivePath = val.effectivePath;
			effectivePath = (string.IsNullOrEmpty(effectivePath) ? "" : (effectivePath + uiNavigateMirror.suffix));
			InputActionRebindingExtensions.ApplyBindingOverride(value2, uiNavigateMirror.navigateIndex, effectivePath);
		}
		if (enabled)
		{
			value2.Enable();
		}
	}

	private void StoreDefaultBindings()
	{
		//IL_0059: Unknown result type (might be due to invalid IL or missing references)
		//IL_005e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0062: Unknown result type (might be due to invalid IL or missing references)
		//IL_0067: Unknown result type (might be due to invalid IL or missing references)
		//IL_006c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0071: Unknown result type (might be due to invalid IL or missing references)
		defaultBindingPaths = new Dictionary<InputKey, List<string>>();
		defaultInputToggleStatesKeyboardMouse = new Dictionary<InputKey, bool>();
		defaultInputToggleStatesGamepad = new Dictionary<InputKey, bool>();
		defaultInputPercentSettings = new Dictionary<InputPercentSetting, int>();
		foreach (InputKey key in inputActions.Keys)
		{
			InputAction val = inputActions[key];
			List<string> list = new List<string>();
			Enumerator<InputBinding> enumerator2 = val.bindings.GetEnumerator();
			try
			{
				while (enumerator2.MoveNext())
				{
					InputBinding current2 = enumerator2.Current;
					list.Add(current2.path);
				}
			}
			finally
			{
				((IDisposable)enumerator2/*cast due to constrained. prefix*/).Dispose();
			}
			defaultBindingPaths[key] = list;
		}
		foreach (KeyValuePair<InputKey, bool> item in inputToggleKeyboardMouse)
		{
			defaultInputToggleStatesKeyboardMouse[item.Key] = item.Value;
		}
		foreach (KeyValuePair<InputKey, bool> item2 in inputToggleGamepad)
		{
			defaultInputToggleStatesGamepad[item2.Key] = item2.Value;
		}
		foreach (KeyValuePair<InputPercentSetting, int> inputPercentSetting in inputPercentSettings)
		{
			defaultInputPercentSettings[inputPercentSetting.Key] = inputPercentSetting.Value;
		}
	}

	public void SaveCurrentKeyBindings(string filepath)
	{
		//IL_00b2: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b8: Expected Obj, but got Unknown
		KeyBindingSaveData keyBindingSaveData = new KeyBindingSaveData();
		keyBindingSaveData.version = 2;
		keyBindingSaveData.vehicleBindingsVersion = 5;
		keyBindingSaveData.expressionWheelBindingsVersion = 1;
		keyBindingSaveData.pushPullBindingsVersion = 1;
		keyBindingSaveData.keyboardMouseOverrides = ExtractSchemeOverrides(inputActions, "Keyboard&Mouse");
		keyBindingSaveData.gamepadOverrides = ExtractSchemeOverrides(inputActions, "Gamepad");
		keyBindingSaveData.bindingOverrides = ExtractLegacyOverrides(inputActions);
		keyBindingSaveData.inputToggleStatesKeyboardMouse = new Dictionary<InputKey, bool>(inputToggleKeyboardMouse);
		keyBindingSaveData.inputToggleStatesGamepad = new Dictionary<InputKey, bool>(inputToggleGamepad);
		keyBindingSaveData.inputToggleStates = new Dictionary<InputKey, bool>(inputToggleKeyboardMouse);
		keyBindingSaveData.inputPercentSettings = new Dictionary<InputPercentSetting, int>(inputPercentSettings);
		ES3Settings val = new ES3Settings(new Enum[1] { (Enum)(object)(Location)4 });
		val.path = filepath;
		ES3.Save<KeyBindingSaveData>("KeyBindings", keyBindingSaveData, val);
		try
		{
			ES3.StoreCachedFile(val);
		}
		catch (Exception ex)
		{
			Debug.LogError((object)ex);
		}
	}

	private bool ExpressionWheelBindingMigrate(KeyBindingSaveData saveData)
	{
		if (saveData.expressionWheelBindingsVersion >= 1)
		{
			return false;
		}
		saveData.expressionWheelBindingsVersion = 1;
		Dictionary<InputKey, List<string>> gamepadOverrides = saveData.gamepadOverrides;
		if (gamepadOverrides == null || !gamepadOverrides.TryGetValue(InputKey.ExpressionWheel, out var value) || value == null)
		{
			return true;
		}
		for (int i = 0; i < value.Count; i++)
		{
			if (string.Equals(value[i], "<Gamepad>/rightShoulder", StringComparison.OrdinalIgnoreCase))
			{
				value[i] = "<Gamepad>/buttonNorth";
			}
		}
		return true;
	}

	private bool PushPullGamepadBindingsMigrate(KeyBindingSaveData saveData)
	{
		if (saveData.pushPullBindingsVersion >= 1)
		{
			return false;
		}
		saveData.pushPullBindingsVersion = 1;
		Dictionary<InputKey, List<string>>[] array = new Dictionary<InputKey, List<string>>[2] { saveData.keyboardMouseOverrides, saveData.gamepadOverrides };
		foreach (Dictionary<InputKey, List<string>> dictionary in array)
		{
			if (dictionary == null)
			{
				continue;
			}
			InputKey[] array2 = new InputKey[2]
			{
				InputKey.Push,
				InputKey.Pull
			};
			foreach (InputKey key in array2)
			{
				if (dictionary.TryGetValue(key, out var value) && value != null && value.Count == 1)
				{
					value.Add(null);
				}
			}
		}
		return true;
	}

	private bool VehicleGamepadBindingsMigrate(KeyBindingSaveData saveData)
	{
		if (saveData.vehicleBindingsVersion >= 5)
		{
			return false;
		}
		Dictionary<InputKey, List<string>> gamepadOverrides = saveData.gamepadOverrides;
		if (saveData.vehicleBindingsVersion < 2 && gamepadOverrides != null && gamepadOverrides.TryGetValue(InputKey.VehicleAccelerate, out var value) && gamepadOverrides.TryGetValue(InputKey.VehicleBrake, out var value2) && value != null && value2 != null && value.Count == 1 && value2.Count == 1 && ((value[0] == "<Gamepad>/rightStick/up" && value2[0] == "<Gamepad>/rightStick/down") || (saveData.vehicleBindingsVersion < 1 && value[0] == "<Gamepad>/rightTrigger" && value2[0] == "<Gamepad>/leftTrigger")))
		{
			value[0] = "<Gamepad>/leftStick/up";
			value2[0] = "<Gamepad>/leftStick/down";
		}
		if (saveData.vehicleBindingsVersion < 3 && gamepadOverrides != null && gamepadOverrides.TryGetValue(InputKey.VehicleDriftLeft, out var value3) && gamepadOverrides.TryGetValue(InputKey.VehicleDriftRight, out var value4) && value3 != null && value4 != null && value3.Count == 1 && value4.Count == 1 && value3[0] == "<Gamepad>/leftShoulder" && value4[0] == "<Gamepad>/rightShoulder")
		{
			value3[0] = "<Gamepad>/rightShoulder";
			value4[0] = "<Gamepad>/leftShoulder";
		}
		if (saveData.vehicleBindingsVersion < 4)
		{
			VehicleKeyboardBindingMigrate(saveData, InputKey.VehicleDriftLeft, MovementDirection.Left);
			VehicleKeyboardBindingMigrate(saveData, InputKey.VehicleDriftRight, MovementDirection.Right);
		}
		VehicleKeyboardBindingMigrate(saveData, InputKey.VehicleAccelerate, MovementDirection.Up);
		VehicleKeyboardBindingMigrate(saveData, InputKey.VehicleBrake, MovementDirection.Down);
		saveData.vehicleBindingsVersion = 5;
		return true;
	}

	private void VehicleKeyboardBindingMigrate(KeyBindingSaveData saveData, InputKey key, MovementDirection direction)
	{
		if (saveData.gamepadOverrides != null && saveData.gamepadOverrides.TryGetValue(key, out var value) && value != null && value.Count == 1)
		{
			value.Add(null);
		}
		if (saveData.keyboardMouseOverrides == null)
		{
			saveData.keyboardMouseOverrides = new Dictionary<InputKey, List<string>>();
		}
		if (!saveData.keyboardMouseOverrides.TryGetValue(key, out var value2) || value2 == null || value2.Count != 2)
		{
			string item = GetMovementKeyString(direction);
			int movementBindingIndex = GetMovementBindingIndex(direction);
			if (saveData.keyboardMouseOverrides.TryGetValue(InputKey.Movement, out var value3) && value3 != null && movementBindingIndex >= 0 && movementBindingIndex < value3.Count && !string.IsNullOrEmpty(value3[movementBindingIndex]))
			{
				item = value3[movementBindingIndex];
			}
			saveData.keyboardMouseOverrides[key] = new List<string> { null, item };
		}
	}

	public void LoadKeyBindings(string filename)
	{
		//IL_0010: Unknown result type (might be due to invalid IL or missing references)
		//IL_0016: Expected Obj, but got Unknown
		try
		{
			ES3Settings val = new ES3Settings(filename, new Enum[1] { (Enum)(object)(Location)0 });
			if (ES3.FileExists(val))
			{
				KeyBindingSaveData keyBindingSaveData = ES3.Load<KeyBindingSaveData>("KeyBindings", val);
				bool flag = false;
				if (keyBindingSaveData.keyboardMouseOverrides == null && keyBindingSaveData.gamepadOverrides == null && keyBindingSaveData.bindingOverrides != null)
				{
					keyBindingSaveData.keyboardMouseOverrides = FilterOverridesForScheme(keyBindingSaveData.bindingOverrides, inputActions, "Keyboard&Mouse");
					keyBindingSaveData.gamepadOverrides = FilterOverridesForScheme(keyBindingSaveData.bindingOverrides, inputActions, "Gamepad");
					keyBindingSaveData.bindingOverrides = null;
					keyBindingSaveData.version = 2;
					flag = true;
				}
				flag |= VehicleGamepadBindingsMigrate(keyBindingSaveData);
				flag |= ExpressionWheelBindingMigrate(keyBindingSaveData);
				flag |= PushPullGamepadBindingsMigrate(keyBindingSaveData);
				ApplyLoadedKeyBindings(keyBindingSaveData);
				if (flag)
				{
					Debug.Log((object)("[InputManager] updated the key bindings save (" + filename + ")"));
					if (filename == "CurrentKeyBindings.es3")
					{
						SaveCurrentKeyBindings("CurrentKeyBindings.es3");
					}
				}
			}
			else
			{
				Debug.LogWarning((object)("Keybindings file not found: " + filename));
			}
		}
		catch (Exception ex)
		{
			Debug.LogError((object)("Failed to load keybindings: " + ex.Message));
		}
	}

	private void ApplyLoadedKeyBindings(KeyBindingSaveData saveData)
	{
		ApplySchemeOverrides(inputActions, saveData.keyboardMouseOverrides, excludedControls);
		ApplySchemeOverrides(inputActions, saveData.gamepadOverrides, excludedControls);
		if (saveData.inputToggleStatesKeyboardMouse != null)
		{
			foreach (KeyValuePair<InputKey, bool> item in saveData.inputToggleStatesKeyboardMouse)
			{
				inputToggleKeyboardMouse[item.Key] = item.Value;
			}
		}
		else if (saveData.inputToggleStates != null)
		{
			foreach (KeyValuePair<InputKey, bool> inputToggleState in saveData.inputToggleStates)
			{
				inputToggleKeyboardMouse[inputToggleState.Key] = inputToggleState.Value;
			}
		}
		if (saveData.inputToggleStatesGamepad != null)
		{
			foreach (KeyValuePair<InputKey, bool> item2 in saveData.inputToggleStatesGamepad)
			{
				inputToggleGamepad[item2.Key] = item2.Value;
			}
		}
		if (saveData.inputPercentSettings != null)
		{
			foreach (KeyValuePair<InputPercentSetting, int> inputPercentSetting in saveData.inputPercentSettings)
			{
				inputPercentSettings[inputPercentSetting.Key] = inputPercentSetting.Value;
			}
		}
		SyncUINavigateWithMovement();
	}

	public void ResetSchemeToDefault(string scheme)
	{
		Dictionary<InputKey, List<string>> overrides = FilterOverridesForScheme(defaultBindingPaths, inputActions, scheme);
		ApplySchemeOverrides(inputActions, overrides, excludedControls);
		Dictionary<InputKey, bool> dictionary = ((scheme == "Gamepad") ? defaultInputToggleStatesGamepad : defaultInputToggleStatesKeyboardMouse);
		Dictionary<InputKey, bool> dictionary2 = ((scheme == "Gamepad") ? inputToggleGamepad : inputToggleKeyboardMouse);
		if (dictionary != null)
		{
			foreach (KeyValuePair<InputKey, bool> item in dictionary)
			{
				dictionary2[item.Key] = item.Value;
			}
		}
		InputPercentSetting key = ((!(scheme == "Gamepad")) ? InputPercentSetting.GrabCursorDriftMouseAndKeyboard : InputPercentSetting.GrabCursorDriftGamepad);
		inputPercentSettings[key] = defaultInputPercentSettings[key];
		InputPercentSetting key2 = ((scheme == "Gamepad") ? InputPercentSetting.GrabCursorDriftSpeedGamepad : InputPercentSetting.GrabCursorDriftSpeedMouseAndKeyboard);
		inputPercentSettings[key2] = defaultInputPercentSettings[key2];
		InputPercentSetting key3 = ((scheme == "Gamepad") ? InputPercentSetting.MeleeGrabCursorDriftGamepad : InputPercentSetting.MeleeGrabCursorDriftMouseAndKeyboard);
		inputPercentSettings[key3] = defaultInputPercentSettings[key3];
		InputPercentSetting key4 = ((scheme == "Gamepad") ? InputPercentSetting.MeleeGrabCursorDriftSpeedGamepad : InputPercentSetting.MeleeGrabCursorDriftSpeedMouseAndKeyboard);
		inputPercentSettings[key4] = defaultInputPercentSettings[key4];
		if (scheme == "Gamepad")
		{
			inputPercentSettings[InputPercentSetting.AimSensitivityGamepad] = defaultInputPercentSettings[InputPercentSetting.AimSensitivityGamepad];
			inputPercentSettings[InputPercentSetting.AimAccelerationGamepad] = defaultInputPercentSettings[InputPercentSetting.AimAccelerationGamepad];
			inputPercentSettings[InputPercentSetting.AimInvertVerticalGamepad] = defaultInputPercentSettings[InputPercentSetting.AimInvertVerticalGamepad];
			inputPercentSettings[InputPercentSetting.RumbleGamepad] = defaultInputPercentSettings[InputPercentSetting.RumbleGamepad];
			inputPercentSettings[InputPercentSetting.ExpressionWheelRightStickGamepad] = defaultInputPercentSettings[InputPercentSetting.ExpressionWheelRightStickGamepad];
			inputPercentSettings[InputPercentSetting.RotationSensitivityGamepad] = defaultInputPercentSettings[InputPercentSetting.RotationSensitivityGamepad];
		}
		else
		{
			DataDirector.instance.ResetSettingToDefault(DataDirector.Setting.AimSensitivity);
			DataDirector.instance.ResetSettingToDefault(DataDirector.Setting.AimInvertVertical);
			if (Object.op_Implicit((Object)(object)GameplayManager.instance))
			{
				GameplayManager.instance.UpdateAimSensitivity();
				GameplayManager.instance.UpdateAimInvertVertical();
			}
		}
		SyncUINavigateWithMovement();
	}

	public void ResetKeyboardMouseToDefault()
	{
		ResetSchemeToDefault("Keyboard&Mouse");
	}

	public void ResetGamepadToDefault()
	{
		ResetSchemeToDefault("Gamepad");
	}

	public void ResetKeyToDefault(InputKey key)
	{
		if (inputActions.TryGetValue(key, out var value))
		{
			bool enabled = value.enabled;
			value.Disable();
			List<string> list = defaultBindingPaths[key];
			for (int i = 0; i < list.Count; i++)
			{
				InputActionRebindingExtensions.ApplyBindingOverride(value, i, list[i]);
			}
			if (enabled)
			{
				value.Enable();
			}
			if (defaultInputToggleStatesKeyboardMouse.TryGetValue(key, out var value2))
			{
				inputToggleKeyboardMouse[key] = value2;
			}
			if (defaultInputToggleStatesGamepad.TryGetValue(key, out var value3))
			{
				inputToggleGamepad[key] = value3;
			}
			SyncUINavigateWithMovement();
		}
		else
		{
			Debug.LogWarning((object)("InputKey not found: " + key));
		}
	}

	public void GamepadTextInputBlock(float _time = 0.2f, bool _allowKeyboard = false)
	{
		gamepadTextInputBlockTimer = _time;
		gamepadTextInputBlockAllowKeyboard = _allowKeyboard;
	}

	private bool GamepadTextInputBlocked(InputKey key)
	{
		if (gamepadTextInputBlockTimer <= 0f)
		{
			return false;
		}
		if (!gamepadTextInputBlockAllowKeyboard)
		{
			return true;
		}
		if (inputActions.TryGetValue(key, out var value))
		{
			InputControl activeControl = value.activeControl;
			return !(((activeControl != null) ? activeControl.device : null) is Keyboard);
		}
		return true;
	}

	public bool KeyDown(InputKey key, bool allowWhenDisabled = false)
	{
		if (GamepadTextInputBlocked(key))
		{
			return false;
		}
		if (ExpressionWheelControlReserved(key) || VehicleGamepadControlReserved(key))
		{
			return false;
		}
		if (key == InputKey.PushPull && GamepadSeparatePushPull())
		{
			return false;
		}
		if (!allowWhenDisabled)
		{
			if ((key == InputKey.Jump || key == InputKey.Crouch || key == InputKey.Tumble || key == InputKey.Inventory1 || key == InputKey.Inventory2 || key == InputKey.Inventory3 || key == InputKey.Interact || key == InputKey.ToggleMute || key == InputKey.Expression1 || key == InputKey.Expression2 || key == InputKey.Expression3 || key == InputKey.Expression4 || key == InputKey.Expression5 || key == InputKey.Expression6) && disableMovementTimer > 0f)
			{
				return false;
			}
			if ((disableControlsExceptTimer > 0f && !disableControlsExceptList.Contains(key)) || (disableControlsIncludeTimer > 0f && disableControlsIncludeList.Contains(key)))
			{
				return false;
			}
		}
		if (inputActions.TryGetValue(key, out var value))
		{
			if (HeldFromUI(value))
			{
				return false;
			}
			return key switch
			{
				InputKey.Push => PushPullActionValueGet(key) > 0f, 
				InputKey.Pull => PushPullActionValueGet(key) < 0f, 
				_ => value.WasPressedThisFrame(), 
			};
		}
		return false;
	}

	public bool KeyUp(InputKey key, bool allowWhenDisabled = false)
	{
		if (GamepadTextInputBlocked(key))
		{
			return false;
		}
		if (ExpressionWheelControlReserved(key) || VehicleGamepadControlReserved(key))
		{
			return false;
		}
		if (key == InputKey.PushPull && GamepadSeparatePushPull())
		{
			return false;
		}
		if (!allowWhenDisabled)
		{
			if ((key == InputKey.Jump || key == InputKey.Crouch || key == InputKey.Tumble) && disableMovementTimer > 0f)
			{
				return false;
			}
			if ((disableControlsExceptTimer > 0f && !disableControlsExceptList.Contains(key)) || (disableControlsIncludeTimer > 0f && disableControlsIncludeList.Contains(key)))
			{
				return false;
			}
		}
		if (inputActions.TryGetValue(key, out var value))
		{
			if (HeldFromUI(value))
			{
				return false;
			}
			if (key == InputKey.Push || key == InputKey.Pull)
			{
				return false;
			}
			return value.WasReleasedThisFrame();
		}
		return false;
	}

	public bool GamepadSeparatePushPull()
	{
		bool value = default;
		return (CurrentMode == InputModes.Gamepad && inputToggleGamepad.TryGetValue(InputKey.PushPull, out value)) & value;
	}

	private bool GamepadPushPullHeld()
	{
		if (SemiFunc.InputMode() == InputModes.Gamepad && Object.op_Implicit((Object)(object)PhysGrabber.instance) && PhysGrabber.instance.grabbed && KeyHold(InputKey.PushPull, allowWhenDisabled: true))
		{
			return !KeyHold(InputKey.Rotate, allowWhenDisabled: true);
		}
		return false;
	}

	private float PushPullActionValueGet(InputKey key)
	{
		if (!inputActions.TryGetValue(key, out var value))
		{
			return 0f;
		}
		InputControl activeControl = value.activeControl;
		if (activeControl == null)
		{
			return 0f;
		}
		if (activeControl.device is Gamepad && !GamepadSeparatePushPull())
		{
			return 0f;
		}
		float num = ((key == InputKey.Push) ? 1f : (-1f));
		if (!(activeControl is ButtonControl))
		{
			if (activeControl is AxisControl || activeControl is Vector2Control)
			{
				float num2 = value.ReadValue<float>();
				if (!(num2 * num > 0f))
				{
					return 0f;
				}
				return num2;
			}
			return 0f;
		}
		if (!InputControlExtensions.IsPressed(activeControl, 0f))
		{
			return 0f;
		}
		return num;
	}

	private float GamepadPushPullButtonsGet()
	{
		if (!GamepadSeparatePushPull() || ExpressionWheelActive() || !Object.op_Implicit((Object)(object)PhysGrabber.instance) || !PhysGrabber.instance.grabbed)
		{
			return 0f;
		}
		float num = 0f;
		InputKey[] array = new InputKey[2]
		{
			InputKey.Push,
			InputKey.Pull
		};
		foreach (InputKey key in array)
		{
			if (!VehicleInputBlocked(key) && !VehicleGamepadControlReserved(key) && inputActions.TryGetValue(key, out var value))
			{
				InputControl activeControl = value.activeControl;
				if (((activeControl != null) ? activeControl.device : null) is Gamepad)
				{
					num += PushPullActionValueGet(key);
				}
			}
		}
		return num;
	}

	public bool KeyPullAndPushAnalog(out float axis)
	{
		//IL_0092: Unknown result type (might be due to invalid IL or missing references)
		axis = 0f;
		if (GamepadSeparatePushPull())
		{
			axis = GamepadPushPullButtonsGet();
			return axis != 0f;
		}
		if (VehicleGamepadControlReserved(InputKey.PushPull) || !GamepadPushPullHeld())
		{
			return false;
		}
		if ((disableControlsExceptTimer > 0f && !disableControlsExceptList.Contains(InputKey.Push)) || (disableControlsIncludeTimer > 0f && disableControlsIncludeList.Contains(InputKey.Push)))
		{
			return false;
		}
		if (inputActions.TryGetValue(InputKey.MouseDelta, out var value))
		{
			InputControl activeControl = value.activeControl;
			Vector2Control val = (Vector2Control)(object)((activeControl is Vector2Control) ? activeControl : null);
			if (val != null)
			{
				axis = Mathf.Clamp(((InputControl<Vector2>)(object)val).ReadValue().y, -1f, 1f);
			}
		}
		return true;
	}

	public float KeyPullAndPush()
	{
		//IL_0089: Unknown result type (might be due to invalid IL or missing references)
		if (ExpressionWheelActive() || VehicleGamepadControlReserved(InputKey.PushPull))
		{
			return 0f;
		}
		float num = 0f;
		if (GamepadPushPullHeld())
		{
			if ((disableControlsExceptTimer > 0f && !disableControlsExceptList.Contains(InputKey.Push)) || (disableControlsIncludeTimer > 0f && disableControlsIncludeList.Contains(InputKey.Push)))
			{
				return 0f;
			}
			PhysGrabber.instance.physPushPullTimer = 0.25f;
			float result = 0f;
			if (inputActions.TryGetValue(InputKey.MouseDelta, out var value))
			{
				result = value.ReadValue<Vector2>().y;
			}
			DisableAiming();
			return result;
		}
		float num2 = GamepadPushPullButtonsGet();
		if (num2 != 0f)
		{
			PhysGrabber.instance.physPushPullTimer = 0.25f;
			return num2;
		}
		if (inputActions.ContainsKey(InputKey.Push))
		{
			if ((disableControlsExceptTimer > 0f && !disableControlsExceptList.Contains(InputKey.Push)) || (disableControlsIncludeTimer > 0f && disableControlsIncludeList.Contains(InputKey.Push)))
			{
				return 0f;
			}
			num += PushPullActionValueGet(InputKey.Push);
		}
		if (inputActions.ContainsKey(InputKey.Pull))
		{
			if ((disableControlsExceptTimer > 0f && !disableControlsExceptList.Contains(InputKey.Pull)) || (disableControlsIncludeTimer > 0f && disableControlsIncludeList.Contains(InputKey.Pull)))
			{
				return 0f;
			}
			num += PushPullActionValueGet(InputKey.Pull);
		}
		return num;
	}

	public bool IsUIClickFromMouseThisFrame()
	{
		if (inputActions.TryGetValue(InputKey.UIClick, out var value) && value.WasPressedThisFrame())
		{
			InputControl activeControl = value.activeControl;
			return ((activeControl != null) ? activeControl.device : null) is Mouse;
		}
		return false;
	}

	public bool IsUIClickFromKeyboardThisFrame()
	{
		if (inputActions.TryGetValue(InputKey.UIClick, out var value) && value.WasPressedThisFrame())
		{
			InputControl activeControl = value.activeControl;
			return ((activeControl != null) ? activeControl.device : null) is Keyboard;
		}
		return false;
	}

	public bool IsActionTriggeredByEscapeThisFrame(InputKey key)
	{
		if (inputActions.TryGetValue(key, out var value) && value.WasPressedThisFrame())
		{
			InputControl activeControl = value.activeControl;
			Keyboard current = Keyboard.current;
			return (object)activeControl == ((current != null) ? current.escapeKey : null);
		}
		return false;
	}

	public InputAction GetAction(InputKey key)
	{
		if (inputActions.TryGetValue(key, out var value))
		{
			return value;
		}
		return null;
	}

	public InputAction GetMovementAction()
	{
		if (inputActions.TryGetValue(InputKey.Movement, out var value))
		{
			return value;
		}
		return null;
	}

	public int GetMovementBindingIndex(MovementDirection direction)
	{
		if (movementBindingIndices.TryGetValue(direction, out var value))
		{
			return value;
		}
		return -1;
	}

	public bool KeyHold(InputKey key, bool allowWhenDisabled = false)
	{
		if (GamepadTextInputBlocked(key))
		{
			return false;
		}
		if (ExpressionWheelControlReserved(key) || VehicleGamepadControlReserved(key))
		{
			return false;
		}
		if (key == InputKey.PushPull && GamepadSeparatePushPull())
		{
			return false;
		}
		if (!allowWhenDisabled)
		{
			if ((key == InputKey.Jump || key == InputKey.Crouch || key == InputKey.Tumble || key == InputKey.Expression1 || key == InputKey.Expression2 || key == InputKey.Expression3 || key == InputKey.Expression4 || key == InputKey.Expression5 || key == InputKey.Expression6) && disableMovementTimer > 0f)
			{
				return false;
			}
			if ((disableControlsExceptTimer > 0f && !disableControlsExceptList.Contains(key)) || (disableControlsIncludeTimer > 0f && disableControlsIncludeList.Contains(key)))
			{
				return false;
			}
		}
		if (inputActions.TryGetValue(key, out var value))
		{
			if (HeldFromUI(value))
			{
				return false;
			}
			return key switch
			{
				InputKey.Push => PushPullActionValueGet(key) > 0f, 
				InputKey.Pull => PushPullActionValueGet(key) < 0f, 
				_ => value.IsPressed(), 
			};
		}
		return false;
	}

	public float GetMovementX(bool allowWhenDisabled = false)
	{
		//IL_00c4: Unknown result type (might be due to invalid IL or missing references)
		if (ExpressionWheelUsesLeftStick() && ExpressionWheelActive())
		{
			return 0f;
		}
		if (!allowWhenDisabled)
		{
			if (disableMovementTimer > 0f)
			{
				return 0f;
			}
			if ((disableControlsExceptTimer > 0f && !disableControlsExceptList.Contains(InputKey.Movement)) || (disableControlsIncludeTimer > 0f && disableControlsIncludeList.Contains(InputKey.Movement)))
			{
				return 0f;
			}
		}
		if (CurrentMode == InputModes.MouseAndKeyboard && Object.op_Implicit((Object)(object)ItemVehicle.GetVehicleForPlayer(PlayerAvatar.instance)))
		{
			bool flag = KeyHold(InputKey.VehicleDriftLeft, allowWhenDisabled);
			return (KeyHold(InputKey.VehicleDriftRight, allowWhenDisabled) ? 1f : 0f) - (flag ? 1f : 0f);
		}
		if (inputActions.TryGetValue(InputKey.Movement, out var value))
		{
			return value.ReadValue<Vector2>().x;
		}
		return 0f;
	}

	public float GetScrollY(bool allowWhenDisabled = false)
	{
		if (!allowWhenDisabled && ((disableControlsExceptTimer > 0f && !disableControlsExceptList.Contains(InputKey.Scroll)) || (disableControlsIncludeTimer > 0f && disableControlsIncludeList.Contains(InputKey.Scroll))))
		{
			return 0f;
		}
		if (inputActions.TryGetValue(InputKey.Scroll, out var value))
		{
			return value.ReadValue<float>();
		}
		return 0f;
	}

	public float GetMovementY(bool allowWhenDisabled = false)
	{
		//IL_00c4: Unknown result type (might be due to invalid IL or missing references)
		if (ExpressionWheelUsesLeftStick() && ExpressionWheelActive())
		{
			return 0f;
		}
		if (!allowWhenDisabled)
		{
			if (disableMovementTimer > 0f)
			{
				return 0f;
			}
			if ((disableControlsExceptTimer > 0f && !disableControlsExceptList.Contains(InputKey.Movement)) || (disableControlsIncludeTimer > 0f && disableControlsIncludeList.Contains(InputKey.Movement)))
			{
				return 0f;
			}
		}
		if (CurrentMode == InputModes.MouseAndKeyboard && Object.op_Implicit((Object)(object)ItemVehicle.GetVehicleForPlayer(PlayerAvatar.instance)))
		{
			bool flag = KeyHold(InputKey.VehicleAccelerate, allowWhenDisabled);
			bool flag2 = KeyHold(InputKey.VehicleBrake, allowWhenDisabled);
			return (flag ? 1f : 0f) - (flag2 ? 1f : 0f);
		}
		if (inputActions.TryGetValue(InputKey.Movement, out var value))
		{
			return value.ReadValue<Vector2>().y;
		}
		return 0f;
	}

	public Vector2 GetMovement()
	{
		//IL_000d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0023: Unknown result type (might be due to invalid IL or missing references)
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_007c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0076: Unknown result type (might be due to invalid IL or missing references)
		if (disableMovementTimer > 0f)
		{
			return Vector2.zero;
		}
		if (ExpressionWheelUsesLeftStick() && ExpressionWheelActive())
		{
			return Vector2.zero;
		}
		if ((disableControlsExceptTimer > 0f && !disableControlsExceptList.Contains(InputKey.Movement)) || (disableControlsIncludeTimer > 0f && disableControlsIncludeList.Contains(InputKey.Movement)))
		{
			return Vector2.zero;
		}
		if (inputActions.TryGetValue(InputKey.Movement, out var value))
		{
			return value.ReadValue<Vector2>();
		}
		return Vector2.zero;
	}

	public Vector2 GetUINavigate()
	{
		//IL_000a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0051: Unknown result type (might be due to invalid IL or missing references)
		//IL_004b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0044: Unknown result type (might be due to invalid IL or missing references)
		if (GamepadTextInputBlocked(InputKey.UINavigate))
		{
			return Vector2.zero;
		}
		if (inputActions.TryGetValue(InputKey.UINavigate, out var value))
		{
			if (CurrentMode == InputModes.MouseAndKeyboard && Object.op_Implicit((Object)(object)PlayerAvatarMenu.instance) && PlayerAvatarMenu.instance.IsUIContextActive())
			{
				return GetUINavigateKeys(value, _movementMirrors: false);
			}
			return value.ReadValue<Vector2>();
		}
		return Vector2.zero;
	}

	public float GetUINavigateMovementX()
	{
		//IL_002d: Unknown result type (might be due to invalid IL or missing references)
		if (gamepadTextInputBlockTimer > 0f)
		{
			return 0f;
		}
		if (!inputActions.TryGetValue(InputKey.UINavigate, out var value))
		{
			return 0f;
		}
		return GetUINavigateKeys(value, _movementMirrors: true).x;
	}

	private Vector2 GetUINavigateKeys(InputAction _action, bool _movementMirrors)
	{
		//IL_0000: Unknown result type (might be due to invalid IL or missing references)
		//IL_0005: Unknown result type (might be due to invalid IL or missing references)
		//IL_0007: Unknown result type (might be due to invalid IL or missing references)
		//IL_000c: Unknown result type (might be due to invalid IL or missing references)
		//IL_000f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0014: Unknown result type (might be due to invalid IL or missing references)
		//IL_014a: Unknown result type (might be due to invalid IL or missing references)
		//IL_015f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0174: Unknown result type (might be due to invalid IL or missing references)
		//IL_0089: Unknown result type (might be due to invalid IL or missing references)
		//IL_008e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0099: Unknown result type (might be due to invalid IL or missing references)
		//IL_009e: Unknown result type (might be due to invalid IL or missing references)
		Vector2 zero = Vector2.zero;
		Enumerator<InputControl> enumerator = _action.controls.GetEnumerator();
		try
		{
			while (enumerator.MoveNext())
			{
				InputControl current = enumerator.Current;
				KeyControl val = (KeyControl)(object)((current is KeyControl) ? current : null);
				if (val == null || !((ButtonControl)val).isPressed)
				{
					continue;
				}
				int _bindingIndex = InputActionRebindingExtensions.GetBindingIndexForControl(_action, current);
				if (_bindingIndex >= 0 && (uiNavigateMirrors != null && uiNavigateMirrors.Exists((UINavigateMirror _mirror) => _mirror.navigateIndex == _bindingIndex)) == _movementMirrors)
				{
					InputBinding val2 = _action.bindings[_bindingIndex];
					switch (val2.name.ToLowerInvariant())
					{
					case "up":
						zero.y++;
						break;
					case "down":
						zero.y--;
						break;
					case "left":
						zero.x--;
						break;
					case "right":
						zero.x++;
						break;
					}
				}
			}
		}
		finally
		{
			((IDisposable)enumerator/*cast due to constrained. prefix*/).Dispose();
		}
		return new Vector2(Mathf.Clamp(zero.x, -1f, 1f), Mathf.Clamp(zero.y, -1f, 1f));
	}

	public int GrabCursorDriftGet(bool melee = false)
	{
		bool flag = CurrentMode == InputModes.Gamepad;
		InputPercentSetting key = ((!flag) ? InputPercentSetting.GrabCursorDriftMouseAndKeyboard : InputPercentSetting.GrabCursorDriftGamepad);
		if (melee)
		{
			key = (flag ? InputPercentSetting.MeleeGrabCursorDriftGamepad : InputPercentSetting.MeleeGrabCursorDriftMouseAndKeyboard);
		}
		return Mathf.Clamp(inputPercentSettings[key], 0, 100);
	}

	public int GrabCursorDriftSpeedGet(bool melee = false)
	{
		bool flag = CurrentMode == InputModes.Gamepad;
		InputPercentSetting key = (flag ? InputPercentSetting.GrabCursorDriftSpeedGamepad : InputPercentSetting.GrabCursorDriftSpeedMouseAndKeyboard);
		if (melee)
		{
			key = (flag ? InputPercentSetting.MeleeGrabCursorDriftSpeedGamepad : InputPercentSetting.MeleeGrabCursorDriftSpeedMouseAndKeyboard);
		}
		return Mathf.Clamp(inputPercentSettings[key], 0, 100);
	}

	public Vector2 GrabCursorLookGet(bool clampInput = true)
	{
		//IL_000f: Unknown result type (might be due to invalid IL or missing references)
		//IL_003f: Unknown result type (might be due to invalid IL or missing references)
		//IL_005d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0080: Unknown result type (might be due to invalid IL or missing references)
		//IL_00aa: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e8: Unknown result type (might be due to invalid IL or missing references)
		//IL_0104: Unknown result type (might be due to invalid IL or missing references)
		//IL_012a: Unknown result type (might be due to invalid IL or missing references)
		//IL_019e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0159: Unknown result type (might be due to invalid IL or missing references)
		//IL_0160: Unknown result type (might be due to invalid IL or missing references)
		//IL_016a: Unknown result type (might be due to invalid IL or missing references)
		//IL_016f: Unknown result type (might be due to invalid IL or missing references)
		//IL_01f6: Unknown result type (might be due to invalid IL or missing references)
		//IL_01c4: Unknown result type (might be due to invalid IL or missing references)
		//IL_01e6: Unknown result type (might be due to invalid IL or missing references)
		//IL_01eb: Unknown result type (might be due to invalid IL or missing references)
		//IL_0207: Unknown result type (might be due to invalid IL or missing references)
		//IL_020d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0205: Unknown result type (might be due to invalid IL or missing references)
		if (!Application.isFocused || ExpressionWheelActive())
		{
			return Vector2.zero;
		}
		if (!inputSystemActions.Player.enabled || disableAimingTimer > 0f || VehicleGamepadOverrideActive())
		{
			return Vector2.zero;
		}
		if (Object.op_Implicit((Object)(object)GameDirector.instance) && GameDirector.instance.DisableInput)
		{
			return Vector2.zero;
		}
		if (Object.op_Implicit((Object)(object)PlayerController.instance) && PlayerController.instance.InputDisableTimer > 0f)
		{
			return Vector2.zero;
		}
		if (Object.op_Implicit((Object)(object)CameraAim.Instance) && (CameraAim.Instance.AimTargetActive || CameraAim.Instance.overrideAimStop))
		{
			return Vector2.zero;
		}
		if ((disableControlsExceptTimer > 0f && !disableControlsExceptList.Contains(InputKey.MouseDelta)) || (disableControlsIncludeTimer > 0f && disableControlsIncludeList.Contains(InputKey.MouseDelta)))
		{
			return Vector2.zero;
		}
		if (KeyHold(InputKey.Rotate) || KeyHold(InputKey.PushPull))
		{
			return Vector2.zero;
		}
		if (inputActions.TryGetValue(InputKey.MouseDelta, out var value))
		{
			InputControl activeControl = value.activeControl;
			Vector2Control val = (Vector2Control)(object)((activeControl is Vector2Control) ? activeControl : null);
			if (val != null)
			{
				Vector2 val2;
				if (CurrentMode == InputModes.Gamepad)
				{
					if (Gamepad.current == null || !((InputDevice)Gamepad.current).enabled || (object)((InputControl)val).device != Gamepad.current)
					{
						return Vector2.zero;
					}
					val2 = Vector2.ClampMagnitude(((InputControl<Vector2>)(object)val).ReadValue(), 1f);
				}
				else
				{
					if (Mouse.current == null || !((InputDevice)Mouse.current).enabled || (object)((InputControl)val).device != Mouse.current || Time.deltaTime <= 0f)
					{
						return Vector2.zero;
					}
					float num = (Object.op_Implicit((Object)(object)CameraAim.Instance) ? CameraAim.Instance.AimSpeedMouse : 1f);
					Vector2 val3 = ((InputControl<Vector2>)(object)val).ReadValue();
					float num2 = 180f * Time.deltaTime;
					float num3 = mouseSensitivity * num / num2;
					val2 = val3 * num3;
				}
				if (AimInvertVerticalGet())
				{
					val2.y = 0f - val2.y;
				}
				if (!clampInput)
				{
					return val2;
				}
				return Vector2.ClampMagnitude(val2, 1f);
			}
		}
		return Vector2.zero;
	}

	public Vector2 GetMenuMouseDelta()
	{
		//IL_0015: Unknown result type (might be due to invalid IL or missing references)
		//IL_0009: Unknown result type (might be due to invalid IL or missing references)
		Mouse current = Mouse.current;
		if (current == null)
		{
			return Vector2.zero;
		}
		return ((InputControl<Vector2>)(object)((Pointer)current).delta).ReadValue();
	}

	public Vector2 GetRawMouseDelta()
	{
		//IL_0012: Unknown result type (might be due to invalid IL or missing references)
		//IL_0030: Unknown result type (might be due to invalid IL or missing references)
		//IL_002a: Unknown result type (might be due to invalid IL or missing references)
		if (ExpressionWheelLookReserved() || VehicleGamepadControlReserved(InputKey.MouseDelta))
		{
			return Vector2.zero;
		}
		if (inputActions.TryGetValue(InputKey.MouseDelta, out var value))
		{
			return value.ReadValue<Vector2>();
		}
		return Vector2.zero;
	}

	internal Vector2 LookInputGet(out InputDevice _device, bool _useStickTravel = false)
	{
		//IL_005a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0071: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b4: Unknown result type (might be due to invalid IL or missing references)
		//IL_00bf: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ad: Unknown result type (might be due to invalid IL or missing references)
		_device = null;
		if (ExpressionWheelLookReserved() || VehicleGamepadControlReserved(InputKey.MouseDelta) || disableAimingTimer > 0f || (disableControlsExceptTimer > 0f && !disableControlsExceptList.Contains(InputKey.MouseDelta)) || (disableControlsIncludeTimer > 0f && disableControlsIncludeList.Contains(InputKey.MouseDelta)))
		{
			return Vector2.zero;
		}
		if (!inputActions.TryGetValue(InputKey.MouseDelta, out var value))
		{
			return Vector2.zero;
		}
		InputControl activeControl = value.activeControl;
		_device = ((activeControl != null) ? activeControl.device : null);
		if (_useStickTravel && _device is Gamepad)
		{
			Vector2Control val = (Vector2Control)(object)((activeControl is Vector2Control) ? activeControl : null);
			if (val != null)
			{
				return Vector2.ClampMagnitude(((InputControl<Vector2>)(object)val).ReadValue(), 1f);
			}
		}
		return value.ReadValue<Vector2>() * mouseSensitivity;
	}

	public float GetMouseX()
	{
		//IL_0004: Unknown result type (might be due to invalid IL or missing references)
		InputDevice _device;
		return LookInputGet(out _device).x;
	}

	public float GetMouseY()
	{
		//IL_0004: Unknown result type (might be due to invalid IL or missing references)
		InputDevice _device;
		return LookInputGet(out _device).y;
	}

	public bool AimIsGamepad()
	{
		return GamepadAimStickGet() != null;
	}

	private Vector2Control GamepadAimStickGet()
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_0029: Unknown result type (might be due to invalid IL or missing references)
		//IL_002d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0032: Unknown result type (might be due to invalid IL or missing references)
		//IL_0065: Unknown result type (might be due to invalid IL or missing references)
		//IL_006a: Unknown result type (might be due to invalid IL or missing references)
		if (!inputActions.TryGetValue(InputKey.MouseDelta, out var value) || !value.enabled)
		{
			return null;
		}
		Vector2Control result = null;
		float num = 0f;
		Enumerator<InputControl> enumerator = value.controls.GetEnumerator();
		try
		{
			while (enumerator.MoveNext())
			{
				InputControl current = enumerator.Current;
				Vector2Control val = (Vector2Control)(object)((current is Vector2Control) ? current : null);
				if (val != null && ((InputControl)val).device is Gamepad && ((InputControl)val).device.enabled)
				{
					Vector2 val2 = ((InputControl<Vector2>)(object)val).ReadValue();
					float sqrMagnitude = val2.sqrMagnitude;
					if (sqrMagnitude > num)
					{
						result = val;
						num = sqrMagnitude;
					}
				}
			}
			return result;
		}
		finally
		{
			((IDisposable)enumerator/*cast due to constrained. prefix*/).Dispose();
		}
	}

	public bool AimInvertVerticalGet()
	{
		if (CurrentMode == InputModes.Gamepad)
		{
			return inputPercentSettings[InputPercentSetting.AimInvertVerticalGamepad] == 1;
		}
		if (Object.op_Implicit((Object)(object)GameplayManager.instance))
		{
			return GameplayManager.instance.aimInvertVertical;
		}
		return false;
	}

	public Vector2 GamepadAimDeltaGet()
	{
		//IL_0020: Unknown result type (might be due to invalid IL or missing references)
		//IL_0025: Unknown result type (might be due to invalid IL or missing references)
		//IL_000e: Unknown result type (might be due to invalid IL or missing references)
		//IL_008d: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b0: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ba: Unknown result type (might be due to invalid IL or missing references)
		//IL_00bf: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a9: Unknown result type (might be due to invalid IL or missing references)
		//IL_00dd: Unknown result type (might be due to invalid IL or missing references)
		//IL_00df: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e4: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f6: Unknown result type (might be due to invalid IL or missing references)
		//IL_01bc: Unknown result type (might be due to invalid IL or missing references)
		//IL_01c8: Unknown result type (might be due to invalid IL or missing references)
		//IL_01cd: Unknown result type (might be due to invalid IL or missing references)
		//IL_0125: Unknown result type (might be due to invalid IL or missing references)
		//IL_012a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0137: Unknown result type (might be due to invalid IL or missing references)
		//IL_013c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0140: Unknown result type (might be due to invalid IL or missing references)
		//IL_0120: Unknown result type (might be due to invalid IL or missing references)
		//IL_01fa: Unknown result type (might be due to invalid IL or missing references)
		//IL_0145: Unknown result type (might be due to invalid IL or missing references)
		if (gamepadAimFrame == Time.frameCount)
		{
			return gamepadAimDelta;
		}
		gamepadAimFrame = Time.frameCount;
		gamepadAimDelta = Vector2.zero;
		if (ExpressionWheelLookReserved() || VehicleGamepadControlReserved(InputKey.MouseDelta) || disableAimingTimer > 0f || (disableControlsExceptTimer > 0f && !disableControlsExceptList.Contains(InputKey.MouseDelta)) || (disableControlsIncludeTimer > 0f && disableControlsIncludeList.Contains(InputKey.MouseDelta)))
		{
			gamepadAimAccelerationTime = 0f;
			return gamepadAimDelta;
		}
		Vector2Control val = GamepadAimStickGet();
		if (val == null)
		{
			gamepadAimAccelerationTime = 0f;
			return gamepadAimDelta;
		}
		Vector2 val2 = Vector2.ClampMagnitude(((InputControl<Vector2>)(object)val).ReadValue(), 1f);
		float magnitude = val2.magnitude;
		if (magnitude < 0.5f)
		{
			gamepadAimAccelerationTime = 0f;
		}
		else
		{
			Vector2 val3 = val2 / magnitude;
			if (gamepadAimAccelerationTime > 0f && Vector2.Angle(val3, gamepadAimAccelerationDirection) > 60f)
			{
				gamepadAimAccelerationTime = 0f;
			}
			Vector2 val4;
			if (!(gamepadAimAccelerationTime > 0f))
			{
				val4 = val3;
			}
			else
			{
				Vector2 val5 = Vector2.Lerp(gamepadAimAccelerationDirection, val3, 10f * Time.deltaTime);
				val4 = val5.normalized;
			}
			gamepadAimAccelerationDirection = val4;
			gamepadAimAccelerationTime += Time.deltaTime;
		}
		float num = (float)inputPercentSettings[InputPercentSetting.AimAccelerationGamepad] / 50f;
		float num2 = Mathf.Clamp01((gamepadAimAccelerationTime - 0.15f) / 0.6f);
		float num3 = 1f + num2 * num;
		float num4 = Mathf.LerpUnclamped(60f, 360f, (float)inputPercentSettings[InputPercentSetting.AimSensitivityGamepad] / 100f);
		gamepadAimDelta = val2 * (num4 * num3 * Time.deltaTime);
		if (inputPercentSettings[InputPercentSetting.AimInvertVerticalGamepad] == 1)
		{
			gamepadAimDelta.y = 0f - gamepadAimDelta.y;
		}
		return gamepadAimDelta;
	}

	public Vector2 GetMousePosition()
	{
		//IL_000d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0049: Unknown result type (might be due to invalid IL or missing references)
		//IL_0066: Unknown result type (might be due to invalid IL or missing references)
		//IL_0060: Unknown result type (might be due to invalid IL or missing references)
		if (disableAimingTimer > 0f)
		{
			return Vector2.zero;
		}
		if ((disableControlsExceptTimer > 0f && !disableControlsExceptList.Contains(InputKey.MouseInput)) || (disableControlsIncludeTimer > 0f && disableControlsIncludeList.Contains(InputKey.MouseInput)))
		{
			return Vector2.zero;
		}
		if (inputActions.TryGetValue(InputKey.MouseInput, out var value))
		{
			return value.ReadValue<Vector2>();
		}
		return Vector2.zero;
	}

	public void Rebind(InputKey key, string group, string newBinding)
	{
		if (inputActions.TryGetValue(key, out var value))
		{
			InputActionRebindingExtensions.ApplyBindingOverride(value, newBinding, group, (string)null);
			SyncUINavigateWithMovement();
		}
	}

	public void RebindMovementKey(MovementDirection direction, string newBinding)
	{
		if (inputActions.TryGetValue(InputKey.Movement, out var value))
		{
			if (movementBindingIndices.TryGetValue(direction, out var value2))
			{
				InputActionRebindingExtensions.ApplyBindingOverride(value, value2, newBinding);
				SyncUINavigateWithMovement();
			}
			else
			{
				Debug.LogWarning((object)$"Binding index for {direction} not found.");
			}
		}
	}

	public void DisableMovement(float _time = 0.1f)
	{
		disableMovementTimer = _time;
	}

	public void DisableAiming(float _time = 0.1f)
	{
		disableAimingTimer = _time;
	}

	public void DisableControlsExcept(float _time = 0.1f, List<InputKey> _keys = null)
	{
		disableControlsExceptList = _keys;
		disableControlsExceptTimer = _time;
	}

	public void DisableControlsSpecific(float _time = 0.1f, List<InputKey> _keys = null)
	{
		disableControlsIncludeList = _keys;
		disableControlsIncludeTimer = _time;
	}

	public List<InputKey> GetKeysSharingControls(InputKey key)
	{
		//IL_0014: Unknown result type (might be due to invalid IL or missing references)
		//IL_0019: Unknown result type (might be due to invalid IL or missing references)
		//IL_006f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0074: Unknown result type (might be due to invalid IL or missing references)
		//IL_0078: Unknown result type (might be due to invalid IL or missing references)
		//IL_007d: Unknown result type (might be due to invalid IL or missing references)
		//IL_008c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0091: Unknown result type (might be due to invalid IL or missing references)
		List<InputKey> list = new List<InputKey>();
		InputAction action = GetAction(key);
		if (action == null)
		{
			return list;
		}
		ReadOnlyArray<InputControl> controls = action.controls;
		if (controls.Count == 0)
		{
			return list;
		}
		foreach (KeyValuePair<InputKey, InputAction> inputAction in inputActions)
		{
			if (inputAction.Key == key || inputAction.Value == null || inputAction.Value == action)
			{
				continue;
			}
			bool flag = false;
			Enumerator<InputControl> enumerator2 = inputAction.Value.controls.GetEnumerator();
			try
			{
				while (enumerator2.MoveNext())
				{
					InputControl current2 = enumerator2.Current;
					Enumerator<InputControl> enumerator3 = controls.GetEnumerator();
					try
					{
						while (enumerator3.MoveNext())
						{
							InputControl current3 = enumerator3.Current;
							if (current2 == current3)
							{
								flag = true;
								break;
							}
						}
					}
					finally
					{
						((IDisposable)enumerator3/*cast due to constrained. prefix*/).Dispose();
					}
					if (flag)
					{
						break;
					}
				}
			}
			finally
			{
				((IDisposable)enumerator2/*cast due to constrained. prefix*/).Dispose();
			}
			if (flag)
			{
				list.Add(inputAction.Key);
			}
		}
		return list;
	}

	public void InputToggleRebind(InputKey key, bool toggle)
	{
		((SemiFunc.InputMode() == InputModes.Gamepad) ? inputToggleGamepad : inputToggleKeyboardMouse)[key] = toggle;
	}

	public bool InputToggleGet(InputKey key)
	{
		return ((SemiFunc.InputMode() == InputModes.Gamepad) ? inputToggleGamepad : inputToggleKeyboardMouse)[key];
	}

	public void InputToggleRebind(InputKey key, bool toggle, string scheme)
	{
		((scheme == "Gamepad") ? inputToggleGamepad : inputToggleKeyboardMouse)[key] = toggle;
	}

	public bool InputToggleGet(InputKey key, string scheme)
	{
		return ((scheme == "Gamepad") ? inputToggleGamepad : inputToggleKeyboardMouse)[key];
	}

	public string GetKeyString(InputKey key)
	{
		//IL_000d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0012: Unknown result type (might be due to invalid IL or missing references)
		//IL_0016: Unknown result type (might be due to invalid IL or missing references)
		//IL_001b: Unknown result type (might be due to invalid IL or missing references)
		InputAction action = GetAction(key);
		if (action == null)
		{
			return null;
		}
		InputBinding val = action.bindings[0];
		return val.effectivePath;
	}

	public string GetMovementKeyString(MovementDirection direction)
	{
		//IL_0014: Unknown result type (might be due to invalid IL or missing references)
		//IL_0019: Unknown result type (might be due to invalid IL or missing references)
		//IL_001d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0022: Unknown result type (might be due to invalid IL or missing references)
		InputAction movementAction = GetMovementAction();
		int movementBindingIndex = GetMovementBindingIndex(direction);
		if (movementAction == null)
		{
			return null;
		}
		InputBinding val = movementAction.bindings[movementBindingIndex];
		return val.effectivePath;
	}

	public string InputDisplayGet(InputKey _inputKey, KeyType _keyType, MovementDirection _movementDirection, string _schemeOverride = null, int _occurrence = 0)
	{
		switch (_keyType)
		{
		case KeyType.InputKey:
		{
			InputAction action = GetAction(_inputKey);
			if (action != null)
			{
				int num = ((_schemeOverride != null) ? GetActiveBindingIndexForScheme(action, _schemeOverride, _occurrence) : GetActiveBindingIndex(action));
				if (num < 0)
				{
					return "Unassigned";
				}
				return InputDisplayGetString(action, num);
			}
			break;
		}
		case KeyType.MovementKey:
		{
			InputAction movementAction = GetMovementAction();
			int movementBindingIndex = GetMovementBindingIndex(_movementDirection);
			if (movementAction != null && movementBindingIndex >= 0)
			{
				return InputDisplayGetString(movementAction, movementBindingIndex);
			}
			break;
		}
		}
		return "Unassigned";
	}

	private static InputControl GetInputControl(InputAction _action, string _effectivePath)
	{
		//IL_000b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0010: Unknown result type (might be due to invalid IL or missing references)
		//IL_0013: Unknown result type (might be due to invalid IL or missing references)
		//IL_0018: Unknown result type (might be due to invalid IL or missing references)
		if (string.IsNullOrEmpty(_effectivePath))
		{
			return null;
		}
		Enumerator<InputControl> enumerator = _action.controls.GetEnumerator();
		try
		{
			while (enumerator.MoveNext())
			{
				InputControl current = enumerator.Current;
				if (InputControlPath.Matches(_effectivePath, current))
				{
					return current;
				}
			}
		}
		finally
		{
			((IDisposable)enumerator/*cast due to constrained. prefix*/).Dispose();
		}
		return null;
	}

	public string InputDisplayGetString(InputAction _action, int _index)
	{
		//IL_0001: Unknown result type (might be due to invalid IL or missing references)
		//IL_0006: Unknown result type (might be due to invalid IL or missing references)
		//IL_000a: Unknown result type (might be due to invalid IL or missing references)
		//IL_000f: Unknown result type (might be due to invalid IL or missing references)
		InputBinding val = _action.bindings[_index];
		string effectivePath = val.effectivePath;
		if (string.IsNullOrEmpty(effectivePath))
		{
			return "Unassigned";
		}
		InputControl inputControl = GetInputControl(_action, effectivePath);
		if (inputControl == null)
		{
			return InputControlPath.ToHumanReadableString(effectivePath, (HumanReadableStringOptions)2, (InputControl)null).ToUpper();
		}
		LocalizedAsset value3;
		if (inputControl.device is Keyboard)
		{
			if (localizedKeyboardActions.TryGetValue(inputControl.path, out var value))
			{
				if (numpadKeyLookup.TryGetValue(inputControl.path, out var value2))
				{
					return value.GetLocalizedString(new object[1]
					{
						new
						{
							value = value2
						}
					}, null).ToUpper();
				}
				return value.GetLocalizedString().ToUpper();
			}
		}
		else if (inputControl.device is Mouse && localizedMouseActions.TryGetValue(inputControl.name, out value3))
		{
			LocalizedAsset localizedAsset = value3;
			object[] array = new object[1];
			string path = inputControl.path;
			array[0] = new
			{
				value = path[path.Length - 1]
			};
			return localizedAsset.GetLocalizedString(array, null).ToUpper();
		}
		return InputControlPath.ToHumanReadableString(effectivePath, (HumanReadableStringOptions)2, inputControl).ToUpper();
	}

	public void ResetInput()
	{
		GamepadRumbleReset();
		InputSystem.ResetHaptics();
		if (Keyboard.current != null)
		{
			InputSystem.ResetDevice((InputDevice)(object)Keyboard.current, false);
		}
		foreach (KeyValuePair<InputKey, InputAction> inputAction in inputActions)
		{
			inputAction.Value.Reset();
		}
	}

	[Obsolete("This will be removed in the next update. Use SemiFunc.InputDisplayReplaceTags instead.")]
	public void InputDisplayReplaceTags(string _text, string _prefix = "<u><b>", string _suffix = "</b></u>")
	{
		SemiFunc.InputDisplayReplaceTags(_text, _prefix, _suffix);
	}
}
