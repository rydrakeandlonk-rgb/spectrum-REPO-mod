using System;
using System.Collections.Generic;
using Photon.Pun;
using UnityEngine;
using UnityEngine.AI;

public class EnemyBirthdayBoy : MonoBehaviour
{
	public enum State
	{
		Spawn,
		Despawn,
		Idle,
		GoToBalloonPlacement,
		PlaceBalloon,
		LeaveAfterBalloon,
		GoToPlayerAngry,
		GoToBalloonAngry,
		PlayerNotice,
		LookAround,
		SeekPlayer,
		Investigate,
		CreepyStare,
		Attack,
		AttackUnderStart,
		AttackUnder,
		AttackUnderEnd,
		StandUp,
		AttackOver,
		Leave,
		Stunned,
		FlyBackUp,
		FlyBackToNavMesh
	}

	[HideInInspector]
	public State currentState;

	[Header("Scripts & Components")]
	public BirthdayBoyAnim anim;

	public EnemyParent enemyParent;

	public MeshRenderer mr;

	[Header("Balloon Placement")]
	public int maxBalloons = 30;

	public GameObject balloonPrefab;

	public List<Transform> balloonSpawnPoints;

	[Header("Collision Checkers")]
	public Transform balloonCollisionChecker;

	public Transform standUpCollisionChecker;

	public Transform doorCollisionChecker;

	[Header("Collider")]
	public CapsuleCollider BBcollider;

	public CapsuleCollider colliderSmall;

	[Header("Code Anim components")]
	public Transform visualMesh;

	public Transform headPivot;

	public Transform leftEyePivot;

	public Transform rightEyePivot;

	public Transform bottom;

	public Transform animatingBalloon;

	[Header("Rotation Logic")]
	private Quaternion horizontalRotationTarget = Quaternion.identity;

	public SpringQuaternion horizontalRotationSpring;

	public GameObject balloonPopEffect;

	[HideInInspector]
	public bool blowing;

	[HideInInspector]
	public PlayerAvatar playerTarget;

	private State previousState;

	private Enemy enemy;

	private PhotonView photonView;

	public Dictionary<Vector3, GameObject> balloons = new Dictionary<Vector3, GameObject>();

	private List<Vector3> balloonsToRemove = new List<Vector3>();

	private List<int> balloonPlacements;

	private float stateTimer;

	private float secondStateTimer;

	private float thirdStateTimer;

	private float popAggroRadius = 10f;

	private float stateTimerClient;

	private float balloonInterval = 3f;

	private float onScreenTimer;

	private float creepyStareTimer;

	private float maxHeadRotationUpDown = 40f;

	private float maxHeadRotationLeftRight = 70f;

	private float idleBreakerTimer;

	private float breakerPlayTime = 2f;

	private float breakerPlayTimer;

	private float preferredBalloonDistance = 1.8f;

	private bool stateImpulse;

	private bool startOfStateClient;

	private bool SkipStateImpulse;

	private bool nonAggroInvestigate;

	private bool hasPendingBalloon;

	private bool checkedForDuplicates;

	private bool replaceOldBalloons;

	private bool onNavMesh;

	private bool playerOnNavMesh;

	private bool angrySpawn;

	private Vector3 targetPosition;

	private Vector3 stuckAttackTarget;

	private Vector3 agentDestination;

	private Vector3 moveBackPosition;

	private Vector3 pendingBalloonPoint;

	private Vector3 bPos;

	private Vector3 bScale;

	private int minBalloonsPerPlacement = 2;

	private int maxBalloonsPerPlacement = 5;

	private int balloonCount;

	private int balloonsPlaced;

	private int balloonsPlacedTotal;

	private int myIndex;

	private Color[] colors = new Color[8]
	{
		Color.red,
		Color.blue,
		Color.green,
		Color.cyan,
		Color.yellow,
		new Color(0.5f, 0f, 1f),
		Color.magenta,
		Color.white
	};

	private Color balloonColor = Color.red;

	private void Awake()
	{
		enemy = ((Component)this).GetComponent<Enemy>();
		photonView = ((Component)this).GetComponent<PhotonView>();
	}

	private void OnDestroy()
	{
		//IL_001a: Unknown result type (might be due to invalid IL or missing references)
		//IL_001f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0026: Unknown result type (might be due to invalid IL or missing references)
		foreach (Vector3 item in new List<Vector3>(balloons.Keys))
		{
			Object.Destroy((Object)(object)balloons[item]);
		}
	}

	private void FixedUpdate()
	{
		//IL_0040: Unknown result type (might be due to invalid IL or missing references)
		//IL_0086: Unknown result type (might be due to invalid IL or missing references)
		//IL_008b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0062: Unknown result type (might be due to invalid IL or missing references)
		//IL_006c: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ab: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b5: Unknown result type (might be due to invalid IL or missing references)
		if (!SemiFunc.IsMasterClientOrSingleplayer())
		{
			return;
		}
		enemy.Rigidbody.gravity = !FlyState();
		if (currentState == State.FlyBackUp)
		{
			if (enemy.Rigidbody.rb.linearVelocity.y < 0f)
			{
				Rigidbody rb = enemy.Rigidbody.rb;
				rb.linearVelocity *= 0.8f;
			}
			Vector3 angularVelocity = enemy.Rigidbody.rb.angularVelocity;
			if (angularVelocity.magnitude > 5f)
			{
				Rigidbody rb2 = enemy.Rigidbody.rb;
				rb2.angularVelocity *= 0.95f;
			}
		}
	}

	private void Update()
	{
		//IL_0164: Unknown result type (might be due to invalid IL or missing references)
		//IL_01bb: Unknown result type (might be due to invalid IL or missing references)
		//IL_01c0: Unknown result type (might be due to invalid IL or missing references)
		//IL_01f6: Unknown result type (might be due to invalid IL or missing references)
		//IL_01fd: Unknown result type (might be due to invalid IL or missing references)
		stateTimerClient += Time.deltaTime;
		CheckForStartOfStateClient();
		BodyRotationLogic();
		HeadRotationLogic();
		if (currentState == State.Stunned && startOfStateClient)
		{
			anim.animator.SetTrigger("stun_trigger");
		}
		if (currentState == State.CreepyStare && startOfStateClient)
		{
			anim.CrackSound();
		}
		if (anim.breaker)
		{
			breakerPlayTimer += Time.deltaTime;
			if (breakerPlayTimer > breakerPlayTime)
			{
				anim.breaker = false;
				breakerPlayTimer = 0f;
			}
		}
		if (!SemiFunc.IsMasterClientOrSingleplayer())
		{
			return;
		}
		ColliderSizeLogic();
		if (enemy.IsStunned() && currentState != State.Stunned && currentState != State.Despawn)
		{
			replaceOldBalloons = false;
			if (currentState == State.PlaceBalloon)
			{
				InterruptBalloonPop();
				hasPendingBalloon = false;
			}
			UpdateState(State.Stunned);
		}
		if (PlayerTargetState() && (!Object.op_Implicit((Object)(object)playerTarget) || playerTarget.isDisabled))
		{
			if (currentState == State.AttackUnder)
			{
				UpdateState(State.AttackUnderEnd);
			}
			else
			{
				UpdateState(State.Idle);
			}
		}
		else if (enemy.CurrentState == EnemyState.Despawn)
		{
			UpdateState(State.Despawn);
		}
		if (((Component)enemy.Rigidbody).transform.position.y - moveBackPosition.y < -2.5f && !enemy.IsStunned() && currentState != State.Despawn && !FlyState())
		{
			float num = float.PositiveInfinity;
			RaycastHit val = default;
			if (Physics.Raycast(((Component)enemy.Rigidbody).transform.position, Vector3.down, ref val, 5f, LayerMask.GetMask(new string[1] { "Default" })))
			{
				num = Vector3.Distance(((Component)enemy.Rigidbody).transform.position, val.point);
			}
			if (num > 2f)
			{
				UpdateState(State.FlyBackUp);
			}
		}
		CheckForCreepyStareStart();
		if (NavMeshState() && !enemy.Jump.jumping)
		{
			UpdateMoveBackPosition();
		}
		CheckForPoppedBalloons();
		if (!FlyState())
		{
			RotationLogic();
		}
		switch (currentState)
		{
		case State.Spawn:
			StateSpawn();
			break;
		case State.Despawn:
			StateDespawn();
			break;
		case State.Idle:
			StateIdle();
			break;
		case State.GoToBalloonPlacement:
			StateGoToBalloonPlacement();
			break;
		case State.PlaceBalloon:
			StatePlaceBalloon();
			break;
		case State.LeaveAfterBalloon:
			StateLeaveAfterBalloon();
			break;
		case State.Leave:
			StateLeave();
			break;
		case State.PlayerNotice:
			StatePlayerNotice();
			break;
		case State.GoToPlayerAngry:
			StateGoToPlayerAngry();
			break;
		case State.GoToBalloonAngry:
			StateGoToBalloonAngry();
			break;
		case State.SeekPlayer:
			StateSeekPlayer();
			break;
		case State.Investigate:
			StateInvestigate();
			break;
		case State.Attack:
			StateAttack();
			break;
		case State.AttackUnderStart:
			StateAttackUnderStart();
			break;
		case State.AttackUnder:
			StateAttackUnder();
			break;
		case State.AttackUnderEnd:
			StateAttackUnderEnd();
			break;
		case State.AttackOver:
			StateAttackOver();
			break;
		case State.StandUp:
			StateStandUp();
			break;
		case State.CreepyStare:
			StateCreepyStare();
			break;
		case State.LookAround:
			StateLookAround();
			break;
		case State.Stunned:
			StateStunned();
			break;
		case State.FlyBackUp:
			StateFlyBackUp();
			break;
		case State.FlyBackToNavMesh:
			StateFlyBackToNavMesh();
			break;
		}
	}

	private void PlayIdleBreaker(int index)
	{
		//IL_0034: Unknown result type (might be due to invalid IL or missing references)
		//IL_003a: Unknown result type (might be due to invalid IL or missing references)
		if (SemiFunc.IsMasterClientOrSingleplayer())
		{
			if (SemiFunc.IsMultiplayer())
			{
				photonView.RPC("PlayIdleBreakerRPC", (RpcTarget)0, new object[1] { index });
			}
			else
			{
				PlayIdleBreakerRPC(index);
			}
		}
	}

	[PunRPC]
	private void PlayIdleBreakerRPC(int index, PhotonMessageInfo _info = default(PhotonMessageInfo))
	{
		//IL_0000: Unknown result type (might be due to invalid IL or missing references)
		//IL_0059: Unknown result type (might be due to invalid IL or missing references)
		if (SemiFunc.MasterOnlyRPC(_info))
		{
			anim.breaker = true;
			AudioClip val = anim.idleBreakers[index];
			AudioClip[] sounds = new AudioClip[1] { val };
			anim.idleBreaker.Sounds = sounds;
			anim.idleBreaker.Play(enemy.CenterTransform.position);
		}
	}

	private void InterruptBalloonPop()
	{
		if (SemiFunc.IsMasterClientOrSingleplayer())
		{
			anim.InterruptBalloonPop();
			if (GameManager.Multiplayer())
			{
				photonView.RPC("InterruptBalloonPopRPC", (RpcTarget)1, Array.Empty<object>());
			}
		}
	}

	[PunRPC]
	private void InterruptBalloonPopRPC(PhotonMessageInfo _info = default(PhotonMessageInfo))
	{
		//IL_0000: Unknown result type (might be due to invalid IL or missing references)
		if (SemiFunc.MasterOnlyRPC(_info))
		{
			anim.InterruptBalloonPop();
		}
	}

	public void UpdateState(State _nextState)
	{
		if (SemiFunc.IsMasterClientOrSingleplayer() && _nextState != currentState)
		{
			onScreenTimer = 0f;
			stateImpulse = true;
			currentState = _nextState;
			if (GameManager.Multiplayer())
			{
				photonView.RPC("UpdateStateRPC", (RpcTarget)1, new object[1] { _nextState });
			}
		}
	}

	[PunRPC]
	private void UpdateStateRPC(State _nextState, PhotonMessageInfo _info = default(PhotonMessageInfo))
	{
		//IL_0000: Unknown result type (might be due to invalid IL or missing references)
		if (SemiFunc.MasterOnlyRPC(_info))
		{
			currentState = _nextState;
		}
	}

	private void BalloonPopEffect(Vector3 _pos, bool _global = true)
	{
		//IL_0006: Unknown result type (might be due to invalid IL or missing references)
		//IL_0007: Unknown result type (might be due to invalid IL or missing references)
		//IL_0018: Unknown result type (might be due to invalid IL or missing references)
		//IL_0037: Unknown result type (might be due to invalid IL or missing references)
		//IL_0094: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b8: Unknown result type (might be due to invalid IL or missing references)
		//IL_0060: Unknown result type (might be due to invalid IL or missing references)
		GameObject val = Object.Instantiate<GameObject>(balloonPopEffect, _pos, Quaternion.identity);
		val.GetComponent<BirthdayBoyBalloonPopParticle>().ChangeParticleColor(balloonColor);
		val.GetComponent<BirthdayBoyBalloonPopParticle>().PlayParticle();
		anim.balloonPopSound.Play(_pos);
		if (_global)
		{
			anim.balloonPopGlobal.Play(_pos);
		}
		GameDirector.instance.CameraShake.ShakeDistance(2f, 3f, 8f, _pos, 0.5f);
		GameDirector.instance.CameraImpact.ShakeDistance(2f, 3f, 8f, _pos, 0.1f);
	}

	private void RemoveBalloon(Vector3 _position, bool _manualRemove = false)
	{
		//IL_0001: Unknown result type (might be due to invalid IL or missing references)
		//IL_001b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0062: Unknown result type (might be due to invalid IL or missing references)
		//IL_0069: Unknown result type (might be due to invalid IL or missing references)
		//IL_006f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0047: Unknown result type (might be due to invalid IL or missing references)
		float num = CheckIfPlayersNearbyPop(_position);
		if (!_manualRemove && num > popAggroRadius)
		{
			return;
		}
		bool poppedWhileDespawned = balloons[_position].GetComponentInChildren<BirthdayBoyBalloon>().poppedWhileDespawned;
		if (GameManager.Multiplayer())
		{
			photonView.RPC("RemoveBalloonRPC", (RpcTarget)0, new object[2]
			{
				_position,
				!_manualRemove
			});
		}
		else
		{
			RemoveBalloonRPC(_position, !_manualRemove);
		}
		if (_manualRemove)
		{
			return;
		}
		if (poppedWhileDespawned)
		{
			UpdateState(State.Spawn);
			angrySpawn = true;
		}
		else if (currentState != State.GoToPlayerAngry && currentState != State.Despawn && !AttackState())
		{
			if (Object.op_Implicit((Object)(object)playerTarget))
			{
				replaceOldBalloons = false;
				UpdateState(State.GoToPlayerAngry);
			}
			else if (num < popAggroRadius / 2f)
			{
				replaceOldBalloons = false;
				UpdateState(State.GoToBalloonAngry);
			}
		}
	}

	[PunRPC]
	private void RemoveBalloonRPC(Vector3 _position, bool _global, PhotonMessageInfo _info = default(PhotonMessageInfo))
	{
		//IL_0000: Unknown result type (might be due to invalid IL or missing references)
		//IL_000a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0017: Unknown result type (might be due to invalid IL or missing references)
		//IL_002d: Unknown result type (might be due to invalid IL or missing references)
		//IL_003c: Unknown result type (might be due to invalid IL or missing references)
		if (SemiFunc.MasterOnlyRPC(_info))
		{
			BalloonPopEffect(_position, _global);
			if (balloons.TryGetValue(_position, out var value))
			{
				Object.Destroy((Object)(object)value);
				balloons.Remove(_position);
			}
			if (_global)
			{
				EnemyDirector.instance.SetInvestigate(_position, 5f);
			}
		}
	}

	private void SpawnBalloon(Vector3 _position)
	{
		//IL_0067: Unknown result type (might be due to invalid IL or missing references)
		//IL_0069: Unknown result type (might be due to invalid IL or missing references)
		//IL_006f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0077: Unknown result type (might be due to invalid IL or missing references)
		//IL_007d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0033: Unknown result type (might be due to invalid IL or missing references)
		//IL_003d: Unknown result type (might be due to invalid IL or missing references)
		//IL_004b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0089: Unknown result type (might be due to invalid IL or missing references)
		if (SemiFunc.IsMasterClientOrSingleplayer())
		{
			float num = Random.Range(0.5f, 1.5f);
			if (GameManager.Multiplayer())
			{
				photonView.RPC("SpawnBalloonRPC", (RpcTarget)0, new object[4] { _position, bPos, bScale, num });
			}
			else
			{
				SpawnBalloonRPC(_position, bPos, bScale, num);
			}
			balloons[_position].GetComponentInChildren<BirthdayBoyBalloon>().balloonIndex = balloonsPlacedTotal;
		}
	}

	[PunRPC]
	private void SpawnBalloonRPC(Vector3 _keyPos, Vector3 _spawnPos, Vector3 _spawnScale, float _randomSpeed, PhotonMessageInfo _info = default(PhotonMessageInfo))
	{
		//IL_0000: Unknown result type (might be due to invalid IL or missing references)
		//IL_0010: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0035: Unknown result type (might be due to invalid IL or missing references)
		//IL_0036: Unknown result type (might be due to invalid IL or missing references)
		//IL_004b: Unknown result type (might be due to invalid IL or missing references)
		//IL_009f: Unknown result type (might be due to invalid IL or missing references)
		//IL_00aa: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ab: Unknown result type (might be due to invalid IL or missing references)
		//IL_008f: Unknown result type (might be due to invalid IL or missing references)
		if (SemiFunc.MasterOnlyRPC(_info))
		{
			if (balloons.TryGetValue(_keyPos, out var value) && Object.op_Implicit((Object)(object)value))
			{
				Object.Destroy((Object)(object)value);
			}
			balloons[_keyPos] = Object.Instantiate<GameObject>(balloonPrefab, _keyPos, Quaternion.identity);
			BirthdayBoyBalloon componentInChildren = balloons[_keyPos].GetComponentInChildren<BirthdayBoyBalloon>();
			componentInChildren.enemyParent = enemy.EnemyParent;
			componentInChildren.placerIndex = myIndex;
			componentInChildren.randomSpeed = _randomSpeed;
			if (myIndex != 0 && myIndex < 8)
			{
				componentInChildren.ChangeColor(balloonColor);
			}
			balloons[_keyPos].GetComponentInChildren<BirthdayBoyBalloon>().TakeToSpawnPoint(_spawnPos, _spawnScale);
		}
	}

	private void SyncBalloonPlacements()
	{
		//IL_0043: Unknown result type (might be due to invalid IL or missing references)
		//IL_0049: Unknown result type (might be due to invalid IL or missing references)
		if (SemiFunc.IsMasterClientOrSingleplayer())
		{
			List<int> nonCollidingBalloonSpawnPoints = GetNonCollidingBalloonSpawnPoints();
			int[] array = GetBalloonSpawnPointIndexes(nonCollidingBalloonSpawnPoints).ToArray();
			if (GameManager.Multiplayer())
			{
				photonView.RPC("SyncBalloonPlacementsRPC", (RpcTarget)0, new object[1] { array });
			}
			else
			{
				SyncBalloonPlacementsRPC(array);
			}
		}
	}

	[PunRPC]
	private void SyncBalloonPlacementsRPC(int[] _spawnPoints, PhotonMessageInfo _info = default(PhotonMessageInfo))
	{
		//IL_0000: Unknown result type (might be due to invalid IL or missing references)
		if (SemiFunc.MasterOnlyRPC(_info))
		{
			List<int> list = new List<int>(_spawnPoints);
			balloonPlacements = list;
		}
	}

	private void BlowBalloonAnimation()
	{
		//IL_0021: Unknown result type (might be due to invalid IL or missing references)
		//IL_0027: Unknown result type (might be due to invalid IL or missing references)
		if (GameManager.Multiplayer())
		{
			photonView.RPC("BlowBalloonAnimationRPC", (RpcTarget)0, Array.Empty<object>());
		}
		else
		{
			BlowBalloonAnimationRPC();
		}
	}

	[PunRPC]
	private void BlowBalloonAnimationRPC(PhotonMessageInfo _info = default(PhotonMessageInfo))
	{
		//IL_0000: Unknown result type (might be due to invalid IL or missing references)
		if (SemiFunc.MasterOnlyRPC(_info))
		{
			anim.BlowBalloonAnimationTrigger();
		}
	}

	private void UpdatePlayerTarget(PlayerAvatar _target)
	{
		if (SemiFunc.IsMasterClientOrSingleplayer())
		{
			if (SemiFunc.IsMultiplayer() && (Object)(object)_target != (Object)null && (Object)(object)_target != (Object)(object)playerTarget)
			{
				photonView.RPC("UpdatePlayerTargetRPC", (RpcTarget)1, new object[1] { _target.photonView.ViewID });
			}
			playerTarget = _target;
		}
	}

	[PunRPC]
	private void UpdatePlayerTargetRPC(int photonViewID, PhotonMessageInfo _info = default(PhotonMessageInfo))
	{
		//IL_0000: Unknown result type (might be due to invalid IL or missing references)
		if (SemiFunc.MasterOnlyRPC(_info))
		{
			playerTarget = SemiFunc.PlayerAvatarGetFromPhotonID(photonViewID);
		}
	}

	private void UpdateLookTarget(PlayerAvatar _target)
	{
		if (SemiFunc.IsMasterClientOrSingleplayer())
		{
			if (!SemiFunc.IsMultiplayer())
			{
				anim.lookTarget = _target;
			}
			else if (!Object.op_Implicit((Object)(object)anim.lookTarget) || anim.lookTarget.photonView.ViewID != _target.photonView.ViewID)
			{
				anim.lookTarget = _target;
				photonView.RPC("UpdateLookTargetRPC", (RpcTarget)1, new object[1] { _target.photonView.ViewID });
			}
		}
	}

	[PunRPC]
	private void UpdateLookTargetRPC(int photonViewID, PhotonMessageInfo _info = default(PhotonMessageInfo))
	{
		//IL_0000: Unknown result type (might be due to invalid IL or missing references)
		if (SemiFunc.MasterOnlyRPC(_info))
		{
			anim.lookTarget = SemiFunc.PlayerAvatarGetFromPhotonID(photonViewID);
		}
	}

	private void PopAllBalloons()
	{
		//IL_0029: Unknown result type (might be due to invalid IL or missing references)
		//IL_002f: Unknown result type (might be due to invalid IL or missing references)
		if (SemiFunc.IsMasterClientOrSingleplayer())
		{
			if (GameManager.Multiplayer())
			{
				photonView.RPC("PopAllBalloonsRPC", (RpcTarget)0, Array.Empty<object>());
			}
			else
			{
				PopAllBalloonsRPC();
			}
		}
	}

	[PunRPC]
	private void PopAllBalloonsRPC(PhotonMessageInfo _info = default(PhotonMessageInfo))
	{
		//IL_0000: Unknown result type (might be due to invalid IL or missing references)
		//IL_0023: Unknown result type (might be due to invalid IL or missing references)
		//IL_0028: Unknown result type (might be due to invalid IL or missing references)
		//IL_002a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0037: Unknown result type (might be due to invalid IL or missing references)
		//IL_0048: Unknown result type (might be due to invalid IL or missing references)
		if (!SemiFunc.MasterOnlyRPC(_info))
		{
			return;
		}
		foreach (Vector3 item in new List<Vector3>(balloons.Keys))
		{
			BalloonPopEffect(item, _global: false);
			Object.Destroy((Object)(object)balloons[item]);
			balloons.Remove(item);
		}
	}

	[PunRPC]
	private void ToggleShrinkColliderRPC(bool _active, PhotonMessageInfo _info = default(PhotonMessageInfo))
	{
		//IL_0000: Unknown result type (might be due to invalid IL or missing references)
		if (SemiFunc.MasterOnlyRPC(_info))
		{
			((Component)BBcollider).gameObject.SetActive(!_active);
			((Component)colliderSmall).gameObject.SetActive(_active);
		}
	}

	private void StateSpawn()
	{
		if (stateImpulse)
		{
			stateImpulse = false;
			stateTimer = 1f;
		}
		stateTimer -= Time.deltaTime;
		if (!(stateTimer <= 0f))
		{
			return;
		}
		if (angrySpawn)
		{
			angrySpawn = false;
			if (Object.op_Implicit((Object)(object)playerTarget))
			{
				UpdateState(State.GoToPlayerAngry);
			}
			else
			{
				UpdateState(State.GoToBalloonAngry);
			}
		}
		else
		{
			UpdateState(State.Idle);
		}
	}

	private void StateDespawn()
	{
		if (stateImpulse)
		{
			stateImpulse = false;
			ResetNavMesh();
		}
	}

	private void StateIdle()
	{
		if (stateImpulse && !SkipStateImpulse)
		{
			ResetNavMesh();
			stateTimer = Random.Range(4f, 8f);
			stateImpulse = false;
			if (Random.Range(0, 10) > 4)
			{
				int index = Random.Range(0, 3);
				PlayIdleBreaker(index);
			}
		}
		SkipStateImpulse = false;
		if (!SemiFunc.EnemySpawnIdlePause())
		{
			stateTimer -= Time.deltaTime;
			if (stateTimer <= 0f)
			{
				UpdateState(State.GoToBalloonPlacement);
			}
			if (SemiFunc.EnemyForceLeave(enemy))
			{
				UpdateState(State.Leave);
			}
		}
	}

	private void StateGoToBalloonPlacement()
	{
		//IL_00ea: Unknown result type (might be due to invalid IL or missing references)
		//IL_0011: Unknown result type (might be due to invalid IL or missing references)
		//IL_0034: Unknown result type (might be due to invalid IL or missing references)
		//IL_013f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0145: Unknown result type (might be due to invalid IL or missing references)
		//IL_0057: Unknown result type (might be due to invalid IL or missing references)
		//IL_005c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0066: Unknown result type (might be due to invalid IL or missing references)
		//IL_006b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0081: Unknown result type (might be due to invalid IL or missing references)
		//IL_0086: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ad: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b2: Unknown result type (might be due to invalid IL or missing references)
		if (stateImpulse)
		{
			LevelPoint levelPoint = SemiFunc.LevelPointGet(((Component)this).transform.position, 5f, 15f);
			if (!Object.op_Implicit((Object)(object)levelPoint))
			{
				levelPoint = SemiFunc.LevelPointGet(((Component)this).transform.position, 0f, 999f);
			}
			NavMeshHit val = default;
			if (Object.op_Implicit((Object)(object)levelPoint) && NavMesh.SamplePosition(((Component)levelPoint).transform.position + Random.insideUnitSphere * 3f, ref val, 5f, -1) && Physics.Raycast(val.position, Vector3.down, 5f, LayerMask.GetMask(new string[1] { "Default" })))
			{
				agentDestination = val.position;
			}
			stateTimer = 5f;
			enemy.Rigidbody.notMovingTimer = 0f;
			stateImpulse = false;
		}
		enemy.NavMeshAgent.SetDestination(agentDestination);
		JumpIfStuck();
		if (enemy.Rigidbody.notMovingTimer > 2f)
		{
			stateTimer -= Time.deltaTime;
		}
		if (stateTimer <= 0f)
		{
			UpdateState(State.Idle);
		}
		else if (Vector3.Distance(((Component)this).transform.position, agentDestination) < 1f)
		{
			UpdateState(State.PlaceBalloon);
		}
		else if (SemiFunc.EnemyForceLeave(enemy))
		{
			UpdateState(State.Leave);
		}
	}

	private void StatePlaceBalloon()
	{
		//IL_01b6: Unknown result type (might be due to invalid IL or missing references)
		//IL_01bb: Unknown result type (might be due to invalid IL or missing references)
		//IL_01c3: Unknown result type (might be due to invalid IL or missing references)
		//IL_01d6: Unknown result type (might be due to invalid IL or missing references)
		//IL_0074: Unknown result type (might be due to invalid IL or missing references)
		//IL_0079: Unknown result type (might be due to invalid IL or missing references)
		//IL_01e1: Unknown result type (might be due to invalid IL or missing references)
		//IL_01eb: Unknown result type (might be due to invalid IL or missing references)
		//IL_01ed: Unknown result type (might be due to invalid IL or missing references)
		//IL_0084: Unknown result type (might be due to invalid IL or missing references)
		//IL_0089: Unknown result type (might be due to invalid IL or missing references)
		//IL_0090: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a6: Unknown result type (might be due to invalid IL or missing references)
		//IL_0241: Unknown result type (might be due to invalid IL or missing references)
		//IL_0246: Unknown result type (might be due to invalid IL or missing references)
		//IL_024e: Unknown result type (might be due to invalid IL or missing references)
		//IL_00be: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e7: Unknown result type (might be due to invalid IL or missing references)
		//IL_0258: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c6: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c7: Unknown result type (might be due to invalid IL or missing references)
		if (stateImpulse && !SkipStateImpulse)
		{
			ResetNavMesh();
			SyncBalloonPlacements();
			balloonCount = balloonPlacements.Count;
			balloonsPlaced = 0;
			balloonsToRemove = new List<Vector3>();
			if (balloons.Count >= maxBalloons)
			{
				for (int i = 0; i < balloonCount; i++)
				{
					List<Vector3> list = new List<Vector3>(balloons.Keys);
					Vector3 val = list[0];
					foreach (Vector3 item in list)
					{
						if (balloons[item].GetComponentInChildren<BirthdayBoyBalloon>().balloonIndex < balloons[val].GetComponentInChildren<BirthdayBoyBalloon>().balloonIndex && !balloonsToRemove.Contains(item))
						{
							val = item;
						}
					}
					balloonsToRemove.Add(val);
				}
				replaceOldBalloons = true;
			}
			stateTimer = (float)balloonCount * balloonInterval + 0.5f;
			secondStateTimer = 0f;
			stateImpulse = false;
		}
		SkipStateImpulse = false;
		stateTimer -= Time.deltaTime;
		secondStateTimer -= Time.deltaTime;
		if (stateTimer <= 0f)
		{
			replaceOldBalloons = false;
			UpdateState(State.LeaveAfterBalloon);
		}
		else
		{
			if (balloonsPlaced >= balloonCount || !(secondStateTimer <= 0f))
			{
				return;
			}
			int index = balloonPlacements[balloonsPlaced];
			Vector3 position = balloonSpawnPoints[index].position;
			if (balloons.ContainsKey(position))
			{
				return;
			}
			if (!IsColliding(balloonCollisionChecker, position) && !NearbyDoor(position))
			{
				pendingBalloonPoint = position;
				hasPendingBalloon = true;
				BlowBalloonAnimation();
			}
			else
			{
				SemiLogger.LogMonika("Didnt spawn, was colliding");
			}
			secondStateTimer = balloonInterval;
			if (replaceOldBalloons && balloonsToRemove.Count > 0)
			{
				Vector3 val2 = balloonsToRemove[0];
				if (balloons.ContainsKey(val2))
				{
					RemoveBalloon(val2, _manualRemove: true);
				}
				balloonsToRemove.RemoveAt(0);
			}
			balloonsPlaced++;
			balloonsPlacedTotal++;
		}
	}

	private void StateLeaveAfterBalloon()
	{
		//IL_00ea: Unknown result type (might be due to invalid IL or missing references)
		//IL_0011: Unknown result type (might be due to invalid IL or missing references)
		//IL_0034: Unknown result type (might be due to invalid IL or missing references)
		//IL_0137: Unknown result type (might be due to invalid IL or missing references)
		//IL_013d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0057: Unknown result type (might be due to invalid IL or missing references)
		//IL_005c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0066: Unknown result type (might be due to invalid IL or missing references)
		//IL_006b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0081: Unknown result type (might be due to invalid IL or missing references)
		//IL_0086: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ad: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b2: Unknown result type (might be due to invalid IL or missing references)
		if (stateImpulse)
		{
			LevelPoint levelPoint = SemiFunc.LevelPointGet(((Component)this).transform.position, 5f, 15f);
			if (!Object.op_Implicit((Object)(object)levelPoint))
			{
				levelPoint = SemiFunc.LevelPointGet(((Component)this).transform.position, 0f, 999f);
			}
			NavMeshHit val = default;
			if (Object.op_Implicit((Object)(object)levelPoint) && NavMesh.SamplePosition(((Component)levelPoint).transform.position + Random.insideUnitSphere * 3f, ref val, 5f, -1) && Physics.Raycast(val.position, Vector3.down, 5f, LayerMask.GetMask(new string[1] { "Default" })))
			{
				agentDestination = val.position;
			}
			stateTimer = 5f;
			enemy.Rigidbody.notMovingTimer = 0f;
			stateImpulse = false;
		}
		enemy.NavMeshAgent.SetDestination(agentDestination);
		JumpIfStuck();
		if (enemy.Rigidbody.notMovingTimer > 2f)
		{
			stateTimer -= Time.deltaTime;
		}
		if (stateTimer <= 0f || Vector3.Distance(((Component)this).transform.position, agentDestination) < 1f)
		{
			UpdateState(State.Idle);
		}
		else if (SemiFunc.EnemyForceLeave(enemy))
		{
			UpdateState(State.Leave);
		}
	}

	private void StateLeave()
	{
		//IL_00b3: Unknown result type (might be due to invalid IL or missing references)
		//IL_0011: Unknown result type (might be due to invalid IL or missing references)
		//IL_0035: Unknown result type (might be due to invalid IL or missing references)
		//IL_011f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0125: Unknown result type (might be due to invalid IL or missing references)
		//IL_0054: Unknown result type (might be due to invalid IL or missing references)
		//IL_0059: Unknown result type (might be due to invalid IL or missing references)
		if (stateImpulse)
		{
			LevelPoint levelPoint = SemiFunc.LevelPointGetPlayerDistance(((Component)this).transform.position, 25f, 50f);
			if (!Object.op_Implicit((Object)(object)levelPoint))
			{
				levelPoint = SemiFunc.LevelPointGetFurthestFromPlayer(((Component)this).transform.position, 5f);
			}
			if (Object.op_Implicit((Object)(object)levelPoint))
			{
				agentDestination = ((Component)levelPoint).transform.position;
			}
			else
			{
				enemy.EnemyParent.SpawnedTimerSet(0f);
			}
			stateTimer = 10f;
			stateImpulse = false;
			enemy.Rigidbody.notMovingTimer = 0f;
			SemiFunc.EnemyLeaveStart(enemy);
		}
		enemy.NavMeshAgent.SetDestination(agentDestination);
		JumpIfStuck();
		if (enemy.Rigidbody.notMovingTimer > 2f)
		{
			stateTimer -= Time.deltaTime;
		}
		enemy.NavMeshAgent.OverrideAgent(6f, 12f, 0.25f);
		if (stateTimer <= 0f || Vector3.Distance(((Component)this).transform.position, agentDestination) < 1f)
		{
			UpdateState(State.Idle);
		}
	}

	private void StateStunned()
	{
		if (stateImpulse)
		{
			stateImpulse = false;
			ResetNavMesh();
		}
		if (!enemy.IsStunned())
		{
			stateTimer = 20f;
			UpdateState(State.SeekPlayer);
		}
	}

	private void StateGoToPlayerAngry()
	{
		//IL_0045: Unknown result type (might be due to invalid IL or missing references)
		//IL_0075: Unknown result type (might be due to invalid IL or missing references)
		//IL_0085: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f7: Unknown result type (might be due to invalid IL or missing references)
		//IL_010c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0129: Unknown result type (might be due to invalid IL or missing references)
		//IL_013e: Unknown result type (might be due to invalid IL or missing references)
		if (stateImpulse)
		{
			stateTimer = 30f;
			stateImpulse = false;
			enemy.Rigidbody.notMovingTimer = 0f;
		}
		enemy.NavMeshAgent.SetDestination(((Component)playerTarget).transform.position);
		JumpIfStuck();
		if (SemiFunc.PerSecond(5f, (Object)(object)this))
		{
			playerOnNavMesh = PlayerOnNavMesh();
		}
		if (Vector3.Distance(((Component)this).transform.position, ((Component)playerTarget).transform.position) < 2f && !enemy.IsStunned())
		{
			enemy.NavMeshAgent.ResetPath();
			stateTimer = 20f;
			UpdateState(State.Attack);
			return;
		}
		if (playerTarget.isCrawling && enemy.Rigidbody.notMovingTimer > 0.5f && Mathf.Abs(((Component)this).transform.position.x - ((Component)playerTarget).transform.position.x) < 2f && Mathf.Abs(((Component)this).transform.position.z - ((Component)playerTarget).transform.position.z) < 2f && !enemy.Jump.jumping && !playerOnNavMesh)
		{
			stateTimer = 20f;
			UpdateState(State.AttackUnderStart);
			return;
		}
		enemy.NavMeshAgent.OverrideAgent(4f, 10f, 0.25f);
		stateTimer -= Time.deltaTime;
		if (stateTimer <= 0f || enemy.Rigidbody.notMovingTimer > 2f)
		{
			stateTimer = 20f;
			UpdateState(State.SeekPlayer);
		}
	}

	private void StateGoToBalloonAngry()
	{
		//IL_003b: Unknown result type (might be due to invalid IL or missing references)
		if (stateImpulse)
		{
			stateTimer = 30f;
			stateImpulse = false;
			enemy.Rigidbody.notMovingTimer = 0f;
			enemy.NavMeshAgent.SetDestination(targetPosition);
			return;
		}
		JumpIfStuck();
		if (CloseToNavMeshTarget() && !enemy.IsStunned())
		{
			stateTimer = 20f;
			UpdateState(State.LookAround);
			return;
		}
		enemy.NavMeshAgent.OverrideAgent(4f, 10f, 0.25f);
		stateTimer -= Time.deltaTime;
		if (stateTimer <= 0f)
		{
			UpdateState(State.Idle);
		}
	}

	private void StateAttack()
	{
		//IL_005b: Unknown result type (might be due to invalid IL or missing references)
		//IL_01e3: Unknown result type (might be due to invalid IL or missing references)
		//IL_01fd: Unknown result type (might be due to invalid IL or missing references)
		//IL_0157: Unknown result type (might be due to invalid IL or missing references)
		//IL_016c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0217: Unknown result type (might be due to invalid IL or missing references)
		//IL_022c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0189: Unknown result type (might be due to invalid IL or missing references)
		//IL_019e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0249: Unknown result type (might be due to invalid IL or missing references)
		//IL_025e: Unknown result type (might be due to invalid IL or missing references)
		if (stateImpulse)
		{
			secondStateTimer = 0f;
			enemy.Rigidbody.notMovingTimer = 0f;
			stateImpulse = false;
		}
		if (secondStateTimer > 3f)
		{
			UpdateState(State.SeekPlayer);
			return;
		}
		enemy.NavMeshAgent.SetDestination(((Component)playerTarget).transform.position);
		enemy.NavMeshAgent.OverrideAgent(4f, 5f, 0.25f);
		if (enemy.Vision.VisionsTriggered[playerTarget.photonView.ViewID] != 0)
		{
			secondStateTimer = 0f;
		}
		else
		{
			secondStateTimer += Time.deltaTime;
		}
		JumpIfStuck();
		if (SemiFunc.PerSecond(5f, (Object)(object)this))
		{
			playerOnNavMesh = PlayerOnNavMesh();
		}
		stateTimer -= Time.deltaTime;
		if (stateTimer <= 0f)
		{
			UpdateState(State.Idle);
		}
		else if (secondStateTimer > 3f)
		{
			UpdateState(State.SeekPlayer);
		}
		else if (playerTarget.isCrawling && enemy.Rigidbody.notMovingTimer > 0.5f && Mathf.Abs(((Component)this).transform.position.x - ((Component)playerTarget).transform.position.x) < 2f && Mathf.Abs(((Component)this).transform.position.z - ((Component)playerTarget).transform.position.z) < 2f && !enemy.Jump.jumping && !playerOnNavMesh)
		{
			UpdateState(State.AttackUnderStart);
		}
		else if (((Component)playerTarget).transform.position.y > ((Component)enemy.Rigidbody).transform.position.y && !playerOnNavMesh && Mathf.Abs(((Component)this).transform.position.x - ((Component)playerTarget).transform.position.x) < 2f && Mathf.Abs(((Component)this).transform.position.z - ((Component)playerTarget).transform.position.z) < 2f)
		{
			UpdateState(State.AttackOver);
		}
	}

	private void StateAttackUnderStart()
	{
		if (stateImpulse)
		{
			stateImpulse = false;
		}
		enemy.Vision.StandOverride(0.25f);
	}

	private void StateAttackUnder()
	{
		//IL_009b: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ab: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f9: Unknown result type (might be due to invalid IL or missing references)
		//IL_0109: Unknown result type (might be due to invalid IL or missing references)
		//IL_0115: Unknown result type (might be due to invalid IL or missing references)
		//IL_012a: Unknown result type (might be due to invalid IL or missing references)
		//IL_013f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0144: Unknown result type (might be due to invalid IL or missing references)
		//IL_0149: Unknown result type (might be due to invalid IL or missing references)
		//IL_015d: Unknown result type (might be due to invalid IL or missing references)
		//IL_015e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0163: Unknown result type (might be due to invalid IL or missing references)
		//IL_0168: Unknown result type (might be due to invalid IL or missing references)
		//IL_017f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0184: Unknown result type (might be due to invalid IL or missing references)
		//IL_0190: Unknown result type (might be due to invalid IL or missing references)
		//IL_01e4: Unknown result type (might be due to invalid IL or missing references)
		//IL_025d: Unknown result type (might be due to invalid IL or missing references)
		if (stateImpulse)
		{
			thirdStateTimer = 10f;
			enemy.Rigidbody.notMovingTimer = 0f;
			secondStateTimer = 0f;
			stateImpulse = false;
		}
		if (enemy.Vision.VisionsTriggered[playerTarget.photonView.ViewID] != 0)
		{
			secondStateTimer = 0f;
		}
		else
		{
			secondStateTimer += Time.deltaTime;
		}
		enemy.Vision.StandOverride(0.25f);
		float num = Vector3.Distance(((Component)this).transform.position, ((Component)playerTarget).transform.position);
		if (num > 0.5f)
		{
			enemy.NavMeshAgent.Disable(0.1f);
			float num2 = enemy.NavMeshAgent.DefaultSpeed * 0.5f;
			((Component)this).transform.position = Vector3.MoveTowards(((Component)this).transform.position, ((Component)playerTarget).transform.position, num2 * Time.deltaTime);
			Vector3 val = ((Component)playerTarget).transform.position - ((Component)enemy.Rigidbody).transform.position;
			val.y = 0f;
			val.Normalize();
			Quaternion val2 = Quaternion.LookRotation(val, Vector3.up);
			((Component)this).transform.rotation = Quaternion.Slerp(((Component)enemy.Rigidbody).transform.rotation, val2, Time.deltaTime * 15f);
		}
		else
		{
			enemy.NavMeshAgent.OverrideAgent(0.5f, 12f, 0.25f);
		}
		if (SemiFunc.PerSecond(5f, (Object)(object)this))
		{
			onNavMesh = enemy.NavMeshAgent.OnNavmesh(((Component)enemy.Rigidbody).transform.position, 1f, _checkPit: true);
		}
		stateTimer -= Time.deltaTime;
		if (secondStateTimer > 3f || !playerTarget.isCrawling || stateTimer <= 0f)
		{
			UpdateState(State.AttackUnderEnd);
		}
		else if (onNavMesh && thirdStateTimer <= 0f && !IsColliding(standUpCollisionChecker, standUpCollisionChecker.position, _collideWithPlayer: false))
		{
			UpdateState(State.StandUp);
		}
		else if (num > 0.5f && enemy.Rigidbody.notMovingTimer > 2f)
		{
			thirdStateTimer -= Time.deltaTime;
			if (thirdStateTimer <= 0f)
			{
				UpdateState(State.AttackUnderEnd);
			}
		}
		else
		{
			thirdStateTimer = 10f;
		}
	}

	private void StateAttackUnderEnd()
	{
		//IL_0050: Unknown result type (might be due to invalid IL or missing references)
		//IL_0056: Unknown result type (might be due to invalid IL or missing references)
		//IL_0071: Unknown result type (might be due to invalid IL or missing references)
		//IL_00af: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ba: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e1: Unknown result type (might be due to invalid IL or missing references)
		//IL_0139: Unknown result type (might be due to invalid IL or missing references)
		//IL_013f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0114: Unknown result type (might be due to invalid IL or missing references)
		if (stateImpulse)
		{
			secondStateTimer = 0f;
			stateImpulse = false;
		}
		enemy.NavMeshAgent.Disable(0.1f);
		enemy.Vision.StandOverride(0.25f);
		((Component)this).transform.position = Vector3.MoveTowards(((Component)this).transform.position, moveBackPosition, enemy.NavMeshAgent.DefaultSpeed * Time.deltaTime);
		stateTimer -= Time.deltaTime;
		secondStateTimer += Time.deltaTime;
		if (Vector3.Distance(((Component)enemy.Rigidbody).transform.position, ((Component)this).transform.position) > 2f)
		{
			((Component)this).transform.position = ((Component)enemy.Rigidbody).transform.position;
		}
		if (SemiFunc.PerSecond(5f, (Object)(object)this))
		{
			onNavMesh = enemy.NavMeshAgent.OnNavmesh(((Component)enemy.Rigidbody).transform.position, 1f, _checkPit: true);
		}
		if (Vector3.Distance(((Component)enemy.Rigidbody).transform.position, moveBackPosition) <= 1f || onNavMesh)
		{
			UpdateState(State.StandUp);
		}
		else if (secondStateTimer > 30f)
		{
			enemy.EnemyParent.SpawnedTimerSet(0f);
			UpdateState(State.Despawn);
		}
	}

	private void StateStandUp()
	{
		if (stateImpulse)
		{
			stateImpulse = false;
			secondStateTimer = 0f;
		}
		enemy.Vision.StandOverride(0.25f);
		secondStateTimer += Time.deltaTime;
		if (secondStateTimer > 1f)
		{
			if (stateTimer > 0f)
			{
				UpdateState(State.Attack);
			}
			else
			{
				UpdateState(State.Idle);
			}
		}
	}

	private void StateAttackOver()
	{
		//IL_005a: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c0: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c5: Unknown result type (might be due to invalid IL or missing references)
		//IL_00eb: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f0: Unknown result type (might be due to invalid IL or missing references)
		//IL_014f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0120: Unknown result type (might be due to invalid IL or missing references)
		//IL_0125: Unknown result type (might be due to invalid IL or missing references)
		//IL_012d: Unknown result type (might be due to invalid IL or missing references)
		//IL_017e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0193: Unknown result type (might be due to invalid IL or missing references)
		//IL_0198: Unknown result type (might be due to invalid IL or missing references)
		//IL_019d: Unknown result type (might be due to invalid IL or missing references)
		//IL_01b1: Unknown result type (might be due to invalid IL or missing references)
		//IL_01b2: Unknown result type (might be due to invalid IL or missing references)
		//IL_01b7: Unknown result type (might be due to invalid IL or missing references)
		//IL_01bc: Unknown result type (might be due to invalid IL or missing references)
		//IL_01d3: Unknown result type (might be due to invalid IL or missing references)
		//IL_01d8: Unknown result type (might be due to invalid IL or missing references)
		//IL_01e4: Unknown result type (might be due to invalid IL or missing references)
		//IL_01f9: Unknown result type (might be due to invalid IL or missing references)
		//IL_020f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0278: Unknown result type (might be due to invalid IL or missing references)
		//IL_0289: Unknown result type (might be due to invalid IL or missing references)
		//IL_028e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0293: Unknown result type (might be due to invalid IL or missing references)
		//IL_0297: Unknown result type (might be due to invalid IL or missing references)
		//IL_029c: Unknown result type (might be due to invalid IL or missing references)
		//IL_02a9: Unknown result type (might be due to invalid IL or missing references)
		//IL_02db: Unknown result type (might be due to invalid IL or missing references)
		//IL_02f1: Unknown result type (might be due to invalid IL or missing references)
		//IL_02f6: Unknown result type (might be due to invalid IL or missing references)
		//IL_02fc: Unknown result type (might be due to invalid IL or missing references)
		if (stateImpulse)
		{
			secondStateTimer = 0f;
			thirdStateTimer = 10f;
			stateImpulse = false;
		}
		if (SemiFunc.PerSecond(5f, (Object)(object)this))
		{
			playerOnNavMesh = PlayerOnNavMesh();
			onNavMesh = enemy.NavMeshAgent.OnNavmesh(((Component)enemy.Rigidbody).transform.position, 1f, _checkPit: true);
		}
		if (enemy.Vision.VisionsTriggered[playerTarget.photonView.ViewID] != 0)
		{
			secondStateTimer = 0f;
		}
		else
		{
			secondStateTimer += Time.deltaTime;
		}
		Vector3 position = ((Component)playerTarget).transform.position;
		enemy.NavMeshAgent.Disable(0.1f);
		if (Vector3.Distance(((Component)enemy.Rigidbody).transform.position, position) > 1.5f)
		{
			float num = enemy.NavMeshAgent.DefaultSpeed * 0.75f;
			((Component)this).transform.position = Vector3.MoveTowards(((Component)this).transform.position, position, num * Time.deltaTime);
		}
		else
		{
			((Component)this).transform.position = ((Component)enemy.Rigidbody).transform.position;
			enemy.Rigidbody.DisableFollowPosition(0.1f, 5f);
		}
		Vector3 val = ((Component)playerTarget).transform.position - ((Component)enemy.Rigidbody).transform.position;
		val.y = 0f;
		val.Normalize();
		Quaternion val2 = Quaternion.LookRotation(val, Vector3.up);
		((Component)this).transform.rotation = Quaternion.Slerp(((Component)enemy.Rigidbody).transform.rotation, val2, Time.deltaTime * 15f);
		SemiFunc.EnemyCartJump(enemy);
		if (position.y > ((Component)enemy.Rigidbody).transform.position.y + 0.3f && !enemy.Jump.jumping && !enemy.Jump.jumpingDelay && !enemy.Jump.landDelay && !enemy.Jump.stuckJumpImpulse)
		{
			Vector3 val3 = position - ((Component)enemy.Rigidbody).transform.position;
			Vector3 normalized = val3.normalized;
			enemy.Jump.StuckTrigger(normalized);
			enemy.Rigidbody.WarpDisable(0.25f);
			((Component)this).transform.position = ((Component)enemy.Rigidbody).transform.position;
			((Component)this).transform.position = Vector3.MoveTowards(((Component)this).transform.position, position, 2f);
			stateTimer -= 0.5f;
		}
		stateTimer -= Time.deltaTime;
		if (stateTimer <= 0f)
		{
			UpdateState(State.Idle);
		}
		else
		{
			if (enemy.Jump.jumping || enemy.Jump.jumpingDelay || enemy.Jump.landDelay)
			{
				return;
			}
			if (onNavMesh && playerOnNavMesh)
			{
				UpdateState(State.Attack);
			}
			else if (secondStateTimer > 3f || enemy.Rigidbody.notMovingTimer > 2f)
			{
				thirdStateTimer -= Time.deltaTime;
				if (thirdStateTimer <= 0f)
				{
					UpdateState(State.Idle);
				}
			}
			else
			{
				thirdStateTimer = 10f;
			}
		}
	}

	private void StateLookAround()
	{
		if (stateImpulse)
		{
			ResetNavMesh();
			stateImpulse = false;
			secondStateTimer = 3f;
		}
		stateTimer -= Time.deltaTime;
		secondStateTimer -= Time.deltaTime;
		if (secondStateTimer <= 0f)
		{
			UpdateState(State.SeekPlayer);
		}
	}

	private void StateSeekPlayer()
	{
		//IL_0089: Unknown result type (might be due to invalid IL or missing references)
		//IL_008f: Unknown result type (might be due to invalid IL or missing references)
		//IL_000f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0014: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e6: Unknown result type (might be due to invalid IL or missing references)
		//IL_004e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0053: Unknown result type (might be due to invalid IL or missing references)
		//IL_0059: Unknown result type (might be due to invalid IL or missing references)
		//IL_005e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0063: Unknown result type (might be due to invalid IL or missing references)
		if (stateImpulse)
		{
			targetPosition = ((Component)this).transform.position;
			LevelPoint levelPoint = SemiFunc.LevelPointInTargetRoomGet(enemy.Rigidbody.physGrabObject.roomVolumeCheck, 2f, 15f);
			if (!Object.op_Implicit((Object)(object)levelPoint))
			{
				UpdateState(State.Idle);
				return;
			}
			targetPosition = ((Component)levelPoint).transform.position;
			Debug.DrawRay(targetPosition, Vector3.up, Color.green, 5f);
			stateImpulse = false;
		}
		if (Vector3.Distance(((Component)this).transform.position, targetPosition) < 1f)
		{
			UpdateState(State.LookAround);
			return;
		}
		JumpIfStuck();
		enemy.NavMeshAgent.OverrideAgent(3f, enemy.NavMeshAgent.DefaultAcceleration, 0.2f);
		enemy.NavMeshAgent.SetDestination(targetPosition);
		stateTimer -= Time.deltaTime;
		if (stateTimer <= 0f || enemy.Rigidbody.notMovingTimer > 3f)
		{
			UpdateState(State.Leave);
		}
	}

	private void StateInvestigate()
	{
		//IL_0055: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b2: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b8: Unknown result type (might be due to invalid IL or missing references)
		if (stateImpulse)
		{
			stateImpulse = false;
			stateTimer += 3f;
			if (nonAggroInvestigate)
			{
				stateTimer = 10f;
			}
			enemy.Rigidbody.notMovingTimer = 0f;
		}
		enemy.NavMeshAgent.SetDestination(agentDestination);
		JumpIfStuck();
		enemy.NavMeshAgent.OverrideAgent(2.5f, 12f, 0.25f);
		stateTimer -= Time.deltaTime;
		if (stateTimer <= 0f)
		{
			UpdateState(State.Idle);
		}
		else if (Vector3.Distance(((Component)this).transform.position, agentDestination) < 2f)
		{
			if (nonAggroInvestigate)
			{
				nonAggroInvestigate = false;
				UpdateState(State.Idle);
			}
			else
			{
				UpdateState(State.SeekPlayer);
			}
		}
		else if (SemiFunc.EnemyForceLeave(enemy))
		{
			UpdateState(State.Leave);
		}
	}

	private void StateCreepyStare()
	{
		SkipStateImpulse = true;
		if (stateImpulse)
		{
			stateImpulse = false;
			thirdStateTimer = 4f;
			creepyStareTimer = 30f;
		}
		thirdStateTimer -= Time.deltaTime;
		if (thirdStateTimer <= 0f)
		{
			SkipStateImpulse = true;
			UpdateState(State.Idle);
		}
	}

	private void StatePlayerNotice()
	{
		if (stateImpulse)
		{
			secondStateTimer = 1.2f;
			stateImpulse = false;
		}
		enemy.NavMeshAgent.ResetPath();
		enemy.NavMeshAgent.Stop(0.1f);
		secondStateTimer -= Time.deltaTime;
		if (secondStateTimer <= 0f)
		{
			UpdateState(State.Attack);
		}
	}

	private void StateFlyBackUp()
	{
		//IL_0037: Unknown result type (might be due to invalid IL or missing references)
		//IL_0058: Unknown result type (might be due to invalid IL or missing references)
		//IL_0062: Unknown result type (might be due to invalid IL or missing references)
		//IL_0073: Unknown result type (might be due to invalid IL or missing references)
		//IL_0078: Unknown result type (might be due to invalid IL or missing references)
		//IL_0084: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e8: Unknown result type (might be due to invalid IL or missing references)
		//IL_00eb: Unknown result type (might be due to invalid IL or missing references)
		//IL_00fa: Unknown result type (might be due to invalid IL or missing references)
		//IL_010a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0124: Unknown result type (might be due to invalid IL or missing references)
		//IL_012f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0156: Unknown result type (might be due to invalid IL or missing references)
		//IL_0196: Unknown result type (might be due to invalid IL or missing references)
		if (stateImpulse)
		{
			stateImpulse = false;
			stateTimer = 30f;
		}
		enemy.NavMeshAgent.Disable(0.1f);
		Vector3 val = new Vector3(((Component)this).transform.position.x, moveBackPosition.y + 1.5f, ((Component)this).transform.position.z);
		((Component)this).transform.position = Vector3.MoveTowards(((Component)this).transform.position, val, Time.deltaTime * 5f);
		enemy.Rigidbody.OverrideFollowPosition(0.1f, 1f);
		enemy.Rigidbody.OverrideFollowRotation(0.1f, 0.25f);
		Transform transform = ((Component)this).transform;
		Quaternion rotation = ((Component)this).transform.rotation;
		Quaternion rotation2 = ((Component)this).transform.rotation;
		transform.rotation = Quaternion.Slerp(rotation, Quaternion.Euler(0f, rotation2.eulerAngles.y, 0f), Time.deltaTime * 5f);
		if (Vector3.Distance(((Component)enemy.Rigidbody).transform.position, ((Component)this).transform.position) > 2f)
		{
			((Component)this).transform.position = ((Component)enemy.Rigidbody).transform.position;
		}
		stateTimer -= Time.deltaTime;
		if (stateTimer <= 0f)
		{
			UpdateState(State.Despawn);
		}
		if (((Component)enemy.Rigidbody).transform.position.y - moveBackPosition.y > 1f)
		{
			UpdateState(State.FlyBackToNavMesh);
		}
	}

	private void StateFlyBackToNavMesh()
	{
		//IL_0046: Unknown result type (might be due to invalid IL or missing references)
		//IL_004c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0051: Unknown result type (might be due to invalid IL or missing references)
		//IL_005b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0060: Unknown result type (might be due to invalid IL or missing references)
		//IL_0070: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ce: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f5: Unknown result type (might be due to invalid IL or missing references)
		//IL_012a: Unknown result type (might be due to invalid IL or missing references)
		//IL_012f: Unknown result type (might be due to invalid IL or missing references)
		//IL_01e8: Unknown result type (might be due to invalid IL or missing references)
		//IL_01ee: Unknown result type (might be due to invalid IL or missing references)
		//IL_0168: Unknown result type (might be due to invalid IL or missing references)
		//IL_017d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0187: Unknown result type (might be due to invalid IL or missing references)
		//IL_018c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0191: Unknown result type (might be due to invalid IL or missing references)
		//IL_01b9: Unknown result type (might be due to invalid IL or missing references)
		//IL_01d0: Unknown result type (might be due to invalid IL or missing references)
		//IL_01d5: Unknown result type (might be due to invalid IL or missing references)
		if (stateImpulse)
		{
			stateImpulse = false;
			stateTimer = 20f;
			secondStateTimer = 0f;
		}
		enemy.NavMeshAgent.Disable(0.1f);
		((Component)this).transform.position = Vector3.MoveTowards(((Component)this).transform.position, moveBackPosition + Vector3.up * 0.5f, 0.75f * Time.deltaTime);
		enemy.Rigidbody.OverrideFollowPosition(0.1f, 1f);
		enemy.Rigidbody.OverrideFollowRotation(0.1f, 0.25f);
		if (Vector3.Distance(((Component)enemy.Rigidbody).transform.position, ((Component)this).transform.position) > 2f)
		{
			((Component)this).transform.position = ((Component)enemy.Rigidbody).transform.position;
		}
		if (secondStateTimer <= 0f)
		{
			secondStateTimer = 0.25f;
			RaycastHit val = default;
			if (Physics.Raycast(((Component)enemy.Rigidbody).transform.position, Vector3.down, ref val, 5f, LayerMask.GetMask(new string[1] { "Default" })))
			{
				NavMeshHit val2 = default;
				if (Physics.Raycast(((Component)enemy.Rigidbody).transform.position + ((Component)enemy.Rigidbody).transform.forward * 0.5f, Vector3.down, ref val, 5f, LayerMask.GetMask(new string[1] { "Default" })) && NavMesh.SamplePosition(val.point, ref val2, 0.5f, -1))
				{
					moveBackPosition = val2.position;
					UpdateState(State.Idle);
					return;
				}
			}
			else if (Vector3.Distance(((Component)this).transform.position, moveBackPosition) < 0.1f)
			{
				UpdateState(State.Idle);
			}
		}
		else
		{
			secondStateTimer -= Time.deltaTime;
		}
		stateTimer -= Time.deltaTime;
		if (stateTimer <= 0f)
		{
			UpdateState(State.Despawn);
		}
	}

	public void OnSpawn()
	{
		if (!checkedForDuplicates)
		{
			CheckForDuplicates();
			checkedForDuplicates = true;
		}
		if (SemiFunc.IsMasterClientOrSingleplayer() && SemiFunc.EnemySpawn(enemy))
		{
			UpdateState(State.Spawn);
		}
		if (((Behaviour)anim).isActiveAndEnabled)
		{
			anim.SetSpawn();
		}
	}

	public void OnHurt()
	{
		//IL_0016: Unknown result type (might be due to invalid IL or missing references)
		anim.hurtSound.Play(enemy.CenterTransform.position);
		if (SemiFunc.IsMasterClientOrSingleplayer() && !AttackState() && !enemy.IsStunned())
		{
			stateTimer = 20f;
			UpdateState(State.SeekPlayer);
		}
	}

	public void OnVision()
	{
		if (SemiFunc.IsMasterClientOrSingleplayer() && currentState == State.GoToPlayerAngry && (Object)(object)enemy.Vision.onVisionTriggeredPlayer == (Object)(object)playerTarget)
		{
			UpdateState(State.PlayerNotice);
		}
	}

	public void OnDeath()
	{
		//IL_0016: Unknown result type (might be due to invalid IL or missing references)
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_008d: Unknown result type (might be due to invalid IL or missing references)
		anim.deathSound.Play(enemy.CenterTransform.position);
		anim.PlayDeathParticles();
		GameDirector.instance.CameraShake.ShakeDistance(5f, 3f, 8f, ((Component)this).transform.position, 0.5f);
		GameDirector.instance.CameraImpact.ShakeDistance(5f, 3f, 8f, ((Component)this).transform.position, 0.1f);
		if (SemiFunc.IsMasterClientOrSingleplayer())
		{
			PopAllBalloons();
			enemy.EnemyParent.Despawn();
			UpdateState(State.Despawn);
		}
	}

	public void OnInvestigate()
	{
		//IL_002f: Unknown result type (might be due to invalid IL or missing references)
		//IL_003f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0016: Unknown result type (might be due to invalid IL or missing references)
		//IL_001b: Unknown result type (might be due to invalid IL or missing references)
		//IL_005c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0061: Unknown result type (might be due to invalid IL or missing references)
		if (currentState == State.SeekPlayer)
		{
			agentDestination = enemy.StateInvestigate.onInvestigateTriggeredPosition;
			UpdateState(State.Investigate);
		}
		else if (Vector3.Distance(((Component)this).transform.position, enemy.StateInvestigate.onInvestigateTriggeredPosition) > 15f)
		{
			agentDestination = enemy.StateInvestigate.onInvestigateTriggeredPosition;
			nonAggroInvestigate = true;
			UpdateState(State.Investigate);
		}
	}

	public void OnBalloonBlowComplete()
	{
		//IL_000a: Unknown result type (might be due to invalid IL or missing references)
		if (hasPendingBalloon)
		{
			SpawnBalloon(pendingBalloonPoint);
			hasPendingBalloon = false;
		}
	}

	public void CrouchedDown()
	{
		if (SemiFunc.IsMasterClientOrSingleplayer())
		{
			UpdateState(State.AttackUnder);
		}
	}

	public void DoneWithBalloonBlow()
	{
		if (SemiFunc.IsMasterClientOrSingleplayer())
		{
			UpdateState(State.PlaceBalloon);
		}
	}

	public void StoreBalloonLocation()
	{
		//IL_0007: Unknown result type (might be due to invalid IL or missing references)
		//IL_000c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0018: Unknown result type (might be due to invalid IL or missing references)
		//IL_001d: Unknown result type (might be due to invalid IL or missing references)
		bPos = animatingBalloon.position;
		bScale = animatingBalloon.localScale;
	}

	private void ColliderSizeLogic()
	{
		if (startOfStateClient)
		{
			if (currentState == State.AttackUnder)
			{
				ToggleShrinkCollider(_active: true);
			}
			else if (currentState == State.StandUp)
			{
				ToggleShrinkCollider(_active: false);
			}
		}
	}

	private void RotationLogic()
	{
		//IL_0010: Unknown result type (might be due to invalid IL or missing references)
		//IL_0015: Unknown result type (might be due to invalid IL or missing references)
		//IL_007b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0085: Unknown result type (might be due to invalid IL or missing references)
		//IL_0035: Unknown result type (might be due to invalid IL or missing references)
		//IL_003a: Unknown result type (might be due to invalid IL or missing references)
		//IL_003f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0055: Unknown result type (might be due to invalid IL or missing references)
		//IL_0064: Unknown result type (might be due to invalid IL or missing references)
		Vector3 normalized = enemy.NavMeshAgent.AgentVelocity.normalized;
		if (normalized.magnitude > 0.1f)
		{
			horizontalRotationTarget = Quaternion.LookRotation(enemy.NavMeshAgent.AgentVelocity.normalized);
			horizontalRotationTarget.eulerAngles = new Vector3(0f, horizontalRotationTarget.eulerAngles.y, 0f);
		}
		((Component)this).transform.rotation = SemiFunc.SpringQuaternionGet(horizontalRotationSpring, horizontalRotationTarget);
	}

	private void CheckForCreepyStareStart()
	{
		if (!CreepyStareStartState())
		{
			return;
		}
		if (enemy.OnScreen.OnScreenAny)
		{
			onScreenTimer += Time.deltaTime;
		}
		else
		{
			onScreenTimer = 0f;
		}
		creepyStareTimer -= Time.deltaTime;
		if (onScreenTimer > 3f && CreepyStareStartState() && creepyStareTimer <= 0f)
		{
			PlayerAvatar playerAvatar = PlayerNearby();
			if (Object.op_Implicit((Object)(object)playerAvatar))
			{
				UpdateLookTarget(playerAvatar);
				UpdateState(State.CreepyStare);
			}
			else
			{
				onScreenTimer = 0f;
			}
		}
	}

	private void CheckForStartOfStateClient()
	{
		if (currentState != previousState)
		{
			startOfStateClient = true;
			if (currentState != State.CreepyStare)
			{
				stateTimerClient = 0f;
			}
			previousState = currentState;
		}
		else
		{
			startOfStateClient = false;
		}
	}

	private void CheckForPoppedBalloons()
	{
		//IL_0080: Unknown result type (might be due to invalid IL or missing references)
		//IL_0085: Unknown result type (might be due to invalid IL or missing references)
		//IL_008d: Unknown result type (might be due to invalid IL or missing references)
		if (!SemiFunc.IsMasterClientOrSingleplayer())
		{
			return;
		}
		foreach (KeyValuePair<Vector3, GameObject> balloon in balloons)
		{
			if (balloon.Value.GetComponentInChildren<BirthdayBoyBalloon>().popped)
			{
				if (currentState != State.GoToPlayerAngry && !AttackState())
				{
					playerTarget = balloon.Value.GetComponentInChildren<BirthdayBoyBalloon>().popper;
					UpdatePlayerTarget(balloon.Value.GetComponentInChildren<BirthdayBoyBalloon>().popper);
				}
				targetPosition = balloon.Value.transform.position;
				RemoveBalloon(balloon.Key);
				break;
			}
		}
	}

	private void JumpIfStuck(bool _cartJump = true)
	{
		//IL_0019: Unknown result type (might be due to invalid IL or missing references)
		//IL_001e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0077: Unknown result type (might be due to invalid IL or missing references)
		//IL_0088: Unknown result type (might be due to invalid IL or missing references)
		//IL_008d: Unknown result type (might be due to invalid IL or missing references)
		if (_cartJump)
		{
			SemiFunc.EnemyCartJump(enemy);
		}
		Vector3 destination = enemy.NavMeshAgent.GetDestination();
		if (!enemy.Jump.jumping && !enemy.Jump.jumpingDelay && !enemy.Jump.landDelay && enemy.Rigidbody.notMovingTimer > 2f)
		{
			enemy.Jump.StuckTrigger(destination - ((Component)enemy.Rigidbody).transform.position);
		}
	}

	private void ResetNavMesh()
	{
		//IL_002b: Unknown result type (might be due to invalid IL or missing references)
		enemy.NavMeshAgent.ResetPath();
		enemy.NavMeshAgent.Warp(((Component)enemy.Rigidbody).transform.position);
	}

	private void UpdateMoveBackPosition()
	{
		//IL_0014: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0033: Unknown result type (might be due to invalid IL or missing references)
		//IL_005a: Unknown result type (might be due to invalid IL or missing references)
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		NavMeshHit val = default;
		if (SemiFunc.PerSecond(1f, (Object)(object)this) && NavMesh.SamplePosition(((Component)this).transform.position, ref val, 1.5f, -1) && Physics.Raycast(((Component)this).transform.position, Vector3.down, 2f, LayerMask.GetMask(new string[1] { "Default" })))
		{
			moveBackPosition = val.position;
		}
	}

	private void RotateBodyTowards(Vector3 _target, float _slerpSpeed = 1f)
	{
		//IL_0000: Unknown result type (might be due to invalid IL or missing references)
		//IL_0007: Unknown result type (might be due to invalid IL or missing references)
		//IL_000c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0011: Unknown result type (might be due to invalid IL or missing references)
		//IL_001e: Unknown result type (might be due to invalid IL or missing references)
		//IL_001f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_0029: Unknown result type (might be due to invalid IL or missing references)
		//IL_0036: Unknown result type (might be due to invalid IL or missing references)
		//IL_003b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0043: Unknown result type (might be due to invalid IL or missing references)
		Vector3 val = _target - visualMesh.position;
		val.y = 0f;
		Quaternion val2 = Quaternion.LookRotation(val, Vector3.up);
		visualMesh.rotation = Quaternion.Slerp(visualMesh.rotation, val2, Time.deltaTime * _slerpSpeed);
	}

	private void BodyRotationLogic()
	{
		//IL_0043: Unknown result type (might be due to invalid IL or missing references)
		//IL_01a3: Unknown result type (might be due to invalid IL or missing references)
		//IL_01a8: Unknown result type (might be due to invalid IL or missing references)
		//IL_01b8: Unknown result type (might be due to invalid IL or missing references)
		//IL_0132: Unknown result type (might be due to invalid IL or missing references)
		//IL_0137: Unknown result type (might be due to invalid IL or missing references)
		//IL_0144: Unknown result type (might be due to invalid IL or missing references)
		//IL_0149: Unknown result type (might be due to invalid IL or missing references)
		//IL_0155: Unknown result type (might be due to invalid IL or missing references)
		//IL_0187: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a8: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b8: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f9: Unknown result type (might be due to invalid IL or missing references)
		if (currentState == State.CreepyStare)
		{
			if (!(stateTimerClient < 1f) && Object.op_Implicit((Object)(object)anim.lookTarget))
			{
				RotateBodyTowards(anim.lookTarget.localCamera.GetOverrideTransform().position, 0.2f);
			}
		}
		else if (currentState == State.PlaceBalloon && balloonPlacements != null && balloonPlacements.Count != 0)
		{
			int num = (int)(stateTimerClient / balloonInterval);
			if (num >= balloonPlacements.Count)
			{
				visualMesh.localRotation = Quaternion.Slerp(visualMesh.localRotation, Quaternion.identity, Time.deltaTime * 2f);
				return;
			}
			if (num >= balloonPlacements.Count)
			{
				num = balloonPlacements.Count - 1;
			}
			int index = balloonPlacements[num];
			RotateBodyTowards(balloonSpawnPoints[index].position, 2f);
		}
		else if (currentState == State.LookAround)
		{
			if (stateTimerClient > 1.5f)
			{
				Quaternion val = Quaternion.Euler(0f, 180f, 0f);
				visualMesh.localRotation = Quaternion.Slerp(visualMesh.localRotation, val, Time.deltaTime * 2f);
			}
		}
		else if (currentState == State.PlayerNotice && Object.op_Implicit((Object)(object)playerTarget))
		{
			RotateBodyTowards(playerTarget.localCamera.GetOverrideTransform().position, 4f);
		}
		else
		{
			visualMesh.localRotation = Quaternion.Slerp(visualMesh.localRotation, Quaternion.identity, Time.deltaTime * 2f);
		}
	}

	private void RotateHeadTowardsPlayer(float speed = 1f, bool clamp = true)
	{
		//IL_0057: Unknown result type (might be due to invalid IL or missing references)
		//IL_005c: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0074: Unknown result type (might be due to invalid IL or missing references)
		//IL_0079: Unknown result type (might be due to invalid IL or missing references)
		//IL_007e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0082: Unknown result type (might be due to invalid IL or missing references)
		//IL_0087: Unknown result type (might be due to invalid IL or missing references)
		//IL_0044: Unknown result type (might be due to invalid IL or missing references)
		//IL_0049: Unknown result type (might be due to invalid IL or missing references)
		//IL_0097: Unknown result type (might be due to invalid IL or missing references)
		//IL_0098: Unknown result type (might be due to invalid IL or missing references)
		//IL_009d: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a2: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c7: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b5: Unknown result type (might be due to invalid IL or missing references)
		//IL_00cc: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d1: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d2: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d7: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e5: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ea: Unknown result type (might be due to invalid IL or missing references)
		//IL_00fd: Unknown result type (might be due to invalid IL or missing references)
		//IL_0110: Unknown result type (might be due to invalid IL or missing references)
		//IL_0115: Unknown result type (might be due to invalid IL or missing references)
		//IL_011c: Unknown result type (might be due to invalid IL or missing references)
		//IL_012f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0178: Unknown result type (might be due to invalid IL or missing references)
		PlayerAvatar playerAvatar = (Object.op_Implicit((Object)(object)playerTarget) ? playerTarget : anim.lookTarget);
		if (!Object.op_Implicit((Object)(object)playerAvatar))
		{
			return;
		}
		Vector3 position;
		if (SemiFunc.IsMultiplayer() && !playerAvatar.isLocal)
		{
			position = playerAvatar.playerAvatarVisuals.headLookAtTransform.position;
		}
		else
		{
			position = playerAvatar.localCamera.GetOverrideTransform().position;
			position.y -= 0.3f;
		}
		Vector3 val = position - headPivot.position;
		Vector3 normalized = val.normalized;
		if (!(normalized.sqrMagnitude < 1E-06f))
		{
			Quaternion val2 = Quaternion.LookRotation(normalized, Vector3.up);
			Quaternion val3 = Quaternion.Inverse(Object.op_Implicit((Object)(object)headPivot.parent) ? headPivot.parent.rotation : Quaternion.identity) * val2;
			headPivot.localRotation = Quaternion.Slerp(headPivot.localRotation, val3, Time.deltaTime * Mathf.Max(0f, speed));
			if (clamp)
			{
				Vector3 localEulerAngles = headPivot.localEulerAngles;
				float num = Mathf.DeltaAngle(0f, localEulerAngles.x);
				float num2 = Mathf.DeltaAngle(0f, localEulerAngles.y);
				num = Mathf.Clamp(num, 0f - maxHeadRotationUpDown, maxHeadRotationUpDown);
				num2 = Mathf.Clamp(num2, 0f - maxHeadRotationLeftRight, maxHeadRotationLeftRight);
				headPivot.localRotation = Quaternion.Euler(num, num2, 0f);
			}
		}
	}

	private void HeadRotationLogic()
	{
		//IL_002a: Unknown result type (might be due to invalid IL or missing references)
		//IL_002f: Unknown result type (might be due to invalid IL or missing references)
		//IL_003c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0041: Unknown result type (might be due to invalid IL or missing references)
		//IL_004d: Unknown result type (might be due to invalid IL or missing references)
		//IL_02e8: Unknown result type (might be due to invalid IL or missing references)
		//IL_02ed: Unknown result type (might be due to invalid IL or missing references)
		//IL_02fd: Unknown result type (might be due to invalid IL or missing references)
		//IL_021a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0225: Unknown result type (might be due to invalid IL or missing references)
		//IL_022a: Unknown result type (might be due to invalid IL or missing references)
		//IL_022f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0234: Unknown result type (might be due to invalid IL or missing references)
		//IL_0239: Unknown result type (might be due to invalid IL or missing references)
		//IL_0247: Unknown result type (might be due to invalid IL or missing references)
		//IL_024c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0259: Unknown result type (might be due to invalid IL or missing references)
		//IL_0269: Unknown result type (might be due to invalid IL or missing references)
		//IL_026e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0275: Unknown result type (might be due to invalid IL or missing references)
		//IL_0288: Unknown result type (might be due to invalid IL or missing references)
		//IL_02d1: Unknown result type (might be due to invalid IL or missing references)
		//IL_0123: Unknown result type (might be due to invalid IL or missing references)
		//IL_012e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0133: Unknown result type (might be due to invalid IL or missing references)
		//IL_0138: Unknown result type (might be due to invalid IL or missing references)
		//IL_013d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0142: Unknown result type (might be due to invalid IL or missing references)
		//IL_014f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0154: Unknown result type (might be due to invalid IL or missing references)
		//IL_0160: Unknown result type (might be due to invalid IL or missing references)
		//IL_0170: Unknown result type (might be due to invalid IL or missing references)
		//IL_0175: Unknown result type (might be due to invalid IL or missing references)
		//IL_017c: Unknown result type (might be due to invalid IL or missing references)
		//IL_018f: Unknown result type (might be due to invalid IL or missing references)
		//IL_01d8: Unknown result type (might be due to invalid IL or missing references)
		if (currentState == State.LookAround)
		{
			Quaternion val = Quaternion.Euler(0f, Mathf.Sin(Time.time * 2f) * 75f, 0f);
			headPivot.localRotation = Quaternion.Slerp(headPivot.localRotation, val, Time.deltaTime * 2f);
		}
		else if (currentState == State.CreepyStare)
		{
			if (!(stateTimerClient < 0.5f))
			{
				RotateHeadTowardsPlayer();
			}
		}
		else if (LookAtTargetPlayerState() && currentState != State.AttackUnder)
		{
			RotateHeadTowardsPlayer();
		}
		else if (currentState == State.PlaceBalloon && !startOfStateClient && balloonPlacements != null && balloonPlacements.Count != 0 && !blowing)
		{
			int num = (int)(stateTimerClient / balloonInterval);
			if (num >= balloonPlacements.Count)
			{
				num = balloonPlacements.Count - 1;
			}
			if (num < 0)
			{
				num = 0;
			}
			int index = balloonPlacements[num];
			Quaternion val2 = Quaternion.LookRotation(balloonSpawnPoints[index].position - headPivot.position, Vector3.up);
			headPivot.rotation = Quaternion.Slerp(headPivot.rotation, val2, Time.deltaTime * 2f);
			Vector3 localEulerAngles = headPivot.localEulerAngles;
			float num2 = Mathf.DeltaAngle(0f, localEulerAngles.x);
			float num3 = Mathf.DeltaAngle(0f, localEulerAngles.y);
			num2 = Mathf.Clamp(num2, 0f - maxHeadRotationUpDown, maxHeadRotationUpDown);
			num3 = Mathf.Clamp(num3, 0f - maxHeadRotationLeftRight, maxHeadRotationLeftRight);
			headPivot.localRotation = Quaternion.Euler(num2, num3, 0f);
		}
		else if (currentState == State.PlayerNotice || currentState == State.GoToPlayerAngry)
		{
			RotateHeadTowardsPlayer(2f);
		}
		else if (currentState == State.Investigate)
		{
			Quaternion val3 = Quaternion.LookRotation(enemy.StateInvestigate.onInvestigateTriggeredPosition - headPivot.position, Vector3.up);
			headPivot.rotation = Quaternion.Slerp(headPivot.rotation, val3, Time.deltaTime * 2f);
			Vector3 localEulerAngles2 = headPivot.localEulerAngles;
			float num4 = Mathf.DeltaAngle(0f, localEulerAngles2.x);
			float num5 = Mathf.DeltaAngle(0f, localEulerAngles2.y);
			num4 = Mathf.Clamp(num4, 0f - maxHeadRotationUpDown, maxHeadRotationUpDown);
			num5 = Mathf.Clamp(num5, 0f - maxHeadRotationLeftRight, maxHeadRotationLeftRight);
			headPivot.localRotation = Quaternion.Euler(num4, num5, 0f);
		}
		else
		{
			headPivot.localRotation = Quaternion.Slerp(headPivot.localRotation, Quaternion.identity, Time.deltaTime * 2f);
		}
	}

	private void CheckForDuplicates()
	{
		//IL_009a: Unknown result type (might be due to invalid IL or missing references)
		//IL_009f: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ba: Unknown result type (might be due to invalid IL or missing references)
		//IL_00da: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e4: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ff: Unknown result type (might be due to invalid IL or missing references)
		List<EnemyParent> enemiesSpawned = EnemyDirector.instance.enemiesSpawned;
		int num = 0;
		int num2 = 0;
		foreach (EnemyParent item in enemiesSpawned)
		{
			if (Object.op_Implicit((Object)(object)item) && ((Object)item).name == "Enemy - Birthday boy(Clone)")
			{
				if ((Object)(object)item == (Object)(object)enemyParent)
				{
					myIndex = num2;
				}
				num++;
			}
			num2++;
		}
		if (num != 1 && myIndex != 0 && myIndex < 8)
		{
			balloonColor = colors[myIndex % colors.Length];
			((Renderer)((Component)animatingBalloon).GetComponentInChildren<MeshRenderer>()).material.SetColor("_BaseColor", balloonColor);
			((Renderer)((Component)animatingBalloon).GetComponentInChildren<MeshRenderer>()).material.SetColor("_EmissionColor", balloonColor * 0.28f);
			((Renderer)mr).material.SetColor("_AlbedoColor", balloonColor);
		}
	}

	public bool AttackState()
	{
		if (currentState != State.Attack && currentState != State.AttackUnder && currentState != State.AttackUnderStart)
		{
			return currentState == State.AttackOver;
		}
		return true;
	}

	private bool PlayerTargetState()
	{
		if (currentState != State.Attack && currentState != State.GoToPlayerAngry && currentState != State.AttackUnder && currentState != State.AttackUnderStart)
		{
			return currentState == State.AttackOver;
		}
		return true;
	}

	private bool CreepyStareStartState()
	{
		return currentState == State.Idle;
	}

	private bool CloseToNavMeshTarget(float _treshold = 1.5f)
	{
		//IL_0006: Unknown result type (might be due to invalid IL or missing references)
		//IL_0016: Unknown result type (might be due to invalid IL or missing references)
		return Mathf.Abs(Vector3.Distance(((Component)this).transform.position, enemy.NavMeshAgent.GetDestination())) < _treshold;
	}

	private bool VisionRelevantState()
	{
		if (currentState != State.SeekPlayer && currentState != State.Investigate && currentState != State.LookAround)
		{
			if (currentState == State.GoToBalloonAngry)
			{
				return CloseToNavMeshTarget(5f);
			}
			return false;
		}
		return true;
	}

	private bool LookAtTargetPlayerState()
	{
		if (currentState != State.Attack && currentState != State.AttackUnder && currentState != State.AttackUnderStart && currentState != State.AttackOver)
		{
			return currentState == State.StandUp;
		}
		return true;
	}

	private bool PlayerOnNavMesh()
	{
		//IL_001a: Unknown result type (might be due to invalid IL or missing references)
		if (!Object.op_Implicit((Object)(object)playerTarget))
		{
			return false;
		}
		NavMeshHit val = default;
		return NavMesh.SamplePosition(((Component)playerTarget).transform.position, ref val, 0.5f, -1);
	}

	private bool NavMeshState()
	{
		if (currentState != State.AttackUnder && currentState != State.AttackOver && currentState != State.AttackUnderStart && currentState != State.FlyBackUp && currentState != State.FlyBackToNavMesh)
		{
			return currentState != State.Stunned;
		}
		return false;
	}

	private bool FlyState()
	{
		if (currentState != State.FlyBackUp)
		{
			return currentState == State.FlyBackToNavMesh;
		}
		return true;
	}

	private float CheckIfPlayersNearbyPop(Vector3 _pos)
	{
		//IL_0021: Unknown result type (might be due to invalid IL or missing references)
		//IL_0026: Unknown result type (might be due to invalid IL or missing references)
		//IL_004c: Unknown result type (might be due to invalid IL or missing references)
		//IL_004d: Unknown result type (might be due to invalid IL or missing references)
		//IL_005b: Unknown result type (might be due to invalid IL or missing references)
		//IL_005c: Unknown result type (might be due to invalid IL or missing references)
		//IL_003a: Unknown result type (might be due to invalid IL or missing references)
		//IL_003f: Unknown result type (might be due to invalid IL or missing references)
		List<PlayerAvatar> list = SemiFunc.PlayerGetList();
		float num = float.PositiveInfinity;
		foreach (PlayerAvatar item in list)
		{
			Vector3 position = ((Component)item).transform.position;
			if (item.isDisabled)
			{
				position = ((Component)item.playerDeathHead).transform.position;
			}
			position.y = 0f;
			Vector3 val = _pos;
			val.y = 0f;
			float num2 = Vector3.Distance(position, val);
			if (num2 < num)
			{
				num = num2;
			}
		}
		return num;
	}

	private List<int> GetNonCollidingBalloonSpawnPoints()
	{
		//IL_0016: Unknown result type (might be due to invalid IL or missing references)
		//IL_001b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0023: Unknown result type (might be due to invalid IL or missing references)
		//IL_002d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0036: Unknown result type (might be due to invalid IL or missing references)
		List<int> list = new List<int>();
		for (int i = 0; i < balloonSpawnPoints.Count; i++)
		{
			Vector3 position = balloonSpawnPoints[i].position;
			if (!IsColliding(balloonCollisionChecker, position) && !IsCollidingWithOtherBalloons(position) && !IsTooCloseToExistingBalloons(position, preferredBalloonDistance))
			{
				list.Add(i);
			}
		}
		return list;
	}

	private List<int> GetBalloonSpawnPointIndexes(List<int> _nonCollidingBalloonSpawnPoints)
	{
		//IL_00a4: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a9: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d1: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d6: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d8: Unknown result type (might be due to invalid IL or missing references)
		//IL_00da: Unknown result type (might be due to invalid IL or missing references)
		//IL_0121: Unknown result type (might be due to invalid IL or missing references)
		//IL_0123: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f1: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f3: Unknown result type (might be due to invalid IL or missing references)
		List<int> list = new List<int>();
		int num = Mathf.Min(_nonCollidingBalloonSpawnPoints.Count, minBalloonsPerPlacement);
		int num2 = Mathf.Min(_nonCollidingBalloonSpawnPoints.Count, maxBalloonsPerPlacement);
		if (balloons.Count < maxBalloons)
		{
			num2 = Mathf.Min(num2, maxBalloons - balloons.Count);
			if (num > num2)
			{
				num = num2;
			}
		}
		int num3 = Random.Range(num, num2);
		for (int i = 0; i < num3; i++)
		{
			int num4 = 0;
			bool flag = false;
			int num5;
			do
			{
				int index = Random.Range(0, _nonCollidingBalloonSpawnPoints.Count);
				num5 = _nonCollidingBalloonSpawnPoints[index];
				if (!list.Contains(num5))
				{
					Vector3 position = balloonSpawnPoints[num5].position;
					flag = true;
					foreach (int item in list)
					{
						Vector3 position2 = balloonSpawnPoints[item].position;
						if (Vector3.Distance(position, position2) < preferredBalloonDistance)
						{
							flag = false;
							SemiLogger.LogMonika(" Too close to already selected point. Distance: " + Vector3.Distance(position, position2));
							break;
						}
						SemiLogger.LogMonika("Not too close. Distance: " + Vector3.Distance(position, position2));
					}
				}
				num4++;
			}
			while (num4 <= 50 && !flag);
			if (flag)
			{
				list.Add(num5);
			}
		}
		return list;
	}

	private PlayerAvatar PlayerNearby()
	{
		//IL_002b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0036: Unknown result type (might be due to invalid IL or missing references)
		PlayerAvatar result = null;
		float num = float.MaxValue;
		foreach (PlayerAvatar item in SemiFunc.PlayerGetList())
		{
			if (!item.isDisabled)
			{
				float num2 = Vector3.Distance(((Component)item).transform.position, ((Component)this).transform.position);
				if (num2 < num)
				{
					result = item;
					num = num2;
				}
			}
		}
		if (num <= 10f)
		{
			return result;
		}
		return null;
	}

	private void ToggleShrinkCollider(bool _active)
	{
		//IL_002c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0032: Unknown result type (might be due to invalid IL or missing references)
		if (SemiFunc.IsMultiplayer())
		{
			photonView.RPC("ToggleShrinkColliderRPC", (RpcTarget)0, new object[1] { _active });
		}
		else
		{
			ToggleShrinkColliderRPC(_active);
		}
	}

	private Collider[] GetCollidingColliders(Transform _collisionChecker, Vector3 _pos)
	{
		//IL_0000: Unknown result type (might be due to invalid IL or missing references)
		//IL_0002: Unknown result type (might be due to invalid IL or missing references)
		//IL_000c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0012: Unknown result type (might be due to invalid IL or missing references)
		return Physics.OverlapBox(_pos, _collisionChecker.lossyScale / 2f, _collisionChecker.rotation);
	}

	private bool NearbyDoor(Vector3 _pos)
	{
		//IL_0007: Unknown result type (might be due to invalid IL or missing references)
		Collider[] collidingColliders = GetCollidingColliders(doorCollisionChecker, _pos);
		for (int i = 0; i < collidingColliders.Length; i++)
		{
			if (((Component)collidingColliders[i]).gameObject.layer == LayerMask.NameToLayer("PhysGrabObjectHinge"))
			{
				return true;
			}
		}
		return false;
	}

	private bool IsColliding(Transform _collisionChecker, Vector3 _pos, bool _collideWithPlayer = true)
	{
		//IL_0002: Unknown result type (might be due to invalid IL or missing references)
		Collider[] collidingColliders = GetCollidingColliders(_collisionChecker, _pos);
		foreach (Collider val in collidingColliders)
		{
			if (((Component)val).gameObject.layer == LayerMask.NameToLayer("RoomVolume") || ((Component)val).gameObject.layer == LayerMask.NameToLayer("Triggers") || ((Component)val).transform.IsChildOf(((Component)this).transform) || ((Component)val).transform.IsChildOf(((Component)enemy.EnemyParent).transform) || !(((Object)val).name != "Trigger Collider Balloon (Hurt collider)") || ((Object)val).name.Contains("Level Point"))
			{
				continue;
			}
			BirthdayBoyBalloon componentInParent = ((Component)val).GetComponentInParent<BirthdayBoyBalloon>();
			if (Object.op_Implicit((Object)(object)componentInParent) && componentInParent.placerIndex != myIndex)
			{
				if (componentInParent.placerIndex != myIndex)
				{
					return true;
				}
			}
			else if ((_collideWithPlayer || !((Component)val).CompareTag("Player")) && ((Component)val).gameObject.layer != LayerMask.NameToLayer("StaticGrabObject"))
			{
				SemiLogger.LogMonika("Colliding with: " + ((Object)val).name + " at position: " + ((object)_pos/*cast due to constrained. prefix*/).ToString());
				return true;
			}
		}
		return false;
	}

	private bool IsCollidingWithOtherBalloons(Vector3 _pos)
	{
		//IL_001b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0025: Unknown result type (might be due to invalid IL or missing references)
		//IL_0034: Unknown result type (might be due to invalid IL or missing references)
		//IL_003e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0050: Unknown result type (might be due to invalid IL or missing references)
		//IL_0069: Unknown result type (might be due to invalid IL or missing references)
		//IL_0082: Unknown result type (might be due to invalid IL or missing references)
		//IL_0087: Unknown result type (might be due to invalid IL or missing references)
		foreach (KeyValuePair<Vector3, GameObject> balloon in balloons)
		{
			float num = Mathf.Abs(balloon.Key.y - _pos.y);
			if (Mathf.Abs(balloon.Key.x - _pos.x) < balloonCollisionChecker.lossyScale.x / 2f && num < balloonCollisionChecker.lossyScale.y / 2f)
			{
				SemiLogger.LogMonika("Colliding with other balloon at: " + ((object)balloon.Key/*cast due to constrained. prefix*/).ToString() + "position: " + ((object)_pos/*cast due to constrained. prefix*/).ToString());
				return true;
			}
		}
		return false;
	}

	private bool IsTooCloseToExistingBalloons(Vector3 _pos, float _minDistance)
	{
		//IL_0018: Unknown result type (might be due to invalid IL or missing references)
		//IL_001d: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b6: Unknown result type (might be due to invalid IL or missing references)
		//IL_00bb: Unknown result type (might be due to invalid IL or missing references)
		foreach (KeyValuePair<Vector3, GameObject> balloon in balloons)
		{
			if (Vector3.Distance(balloon.Key, _pos) < _minDistance)
			{
				return true;
			}
		}
		foreach (EnemyParent item in EnemyDirector.instance.enemiesSpawned)
		{
			if (!Object.op_Implicit((Object)(object)item) || !(((Object)item).name == "Enemy - Birthday boy(Clone)"))
			{
				continue;
			}
			EnemyBirthdayBoy componentInChildren = ((Component)item).GetComponentInChildren<EnemyBirthdayBoy>();
			if (!Object.op_Implicit((Object)(object)componentInChildren) || !((Object)(object)componentInChildren != (Object)(object)this))
			{
				continue;
			}
			foreach (KeyValuePair<Vector3, GameObject> balloon2 in componentInChildren.balloons)
			{
				if (Vector3.Distance(balloon2.Key, _pos) < _minDistance)
				{
					return true;
				}
			}
		}
		return false;
	}

	public void GetAngry()
	{
		if (SemiFunc.IsMasterClientOrSingleplayer() && !enemy.IsStunned() && currentState != State.FlyBackUp && currentState != State.FlyBackToNavMesh && currentState != State.LookAround && currentState != State.PlayerNotice && currentState != State.Despawn && !AttackState())
		{
			stateTimer = 20f;
			UpdateState(State.LookAround);
		}
	}

	public EnemyBirthdayBoy()
	{
		//IL_0009: Unknown result type (might be due to invalid IL or missing references)
		//IL_000e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0082: Unknown result type (might be due to invalid IL or missing references)
		//IL_0087: Unknown result type (might be due to invalid IL or missing references)
		//IL_008e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0093: Unknown result type (might be due to invalid IL or missing references)
		//IL_009a: Unknown result type (might be due to invalid IL or missing references)
		//IL_009f: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a6: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ab: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b2: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b7: Unknown result type (might be due to invalid IL or missing references)
		//IL_00cd: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d2: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d9: Unknown result type (might be due to invalid IL or missing references)
		//IL_00de: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e5: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ea: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f5: Unknown result type (might be due to invalid IL or missing references)
		//IL_00fa: Unknown result type (might be due to invalid IL or missing references)
	}
}
