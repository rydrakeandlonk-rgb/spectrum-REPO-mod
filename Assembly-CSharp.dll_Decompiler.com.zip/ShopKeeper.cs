using System;
using System.Collections.Generic;
using System.Linq;
using Photon.Pun;
using TMPro;
using UnityEngine;

public class ShopKeeper : MonoBehaviour
{
	public enum State
	{
		Sleeping,
		WakeUp,
		GoToSleep,
		Observe,
		Flash,
		Shock,
		Hurt,
		Aim,
		WaitForRuckusPlayer,
		SeeRuckusPlayer,
		GrabRuckusPlayer,
		JudgeRuckusPlayer,
		Shoot,
		AngryObservation,
		WarnGrabPlayer,
		WarnTellOff,
		SeeWarnPlayer,
		ScanObject,
		Verdict,
		ReactPositive,
		ReactNegative,
		NegativeGrab,
		NegativeShakeToss,
		PositiveGrab,
		PositivePlay,
		NegativeMeleeGrab,
		NegativeMeleeWindup,
		NegativeMeleeSwing,
		NoticeItem,
		DenyItem
	}

	public class PlayerRuckusRecord
	{
		public PlayerAvatar victim;

		public float damageAccumulated;

		public int hitCount;

		public int tumbleCount;

		public float cooldownTimer;

		public bool angryTriggered;
	}

	public class PlayerCarryThrustRecord
	{
		public PlayerAvatar victim;

		public int thrustCount;

		public float windowTimer;

		public bool angryTriggered;
	}

	public class PlayerRuckusScoreRecord
	{
		public PlayerAvatar player;

		public float score;

		public int angryThresholdIndex;

		public float lastWarnedTime;

		public PhysGrabObject discountDeniedItem;

		public float discountDeniedTimer;
	}

	public static ShopKeeper instance;

	private PhotonView photonView;

	public BotSystemSpringPoseAnimator pose;

	public Transform detectionSphere;

	public GameObject[] sensorLights;

	public GameObject onOffSwitchLight;

	public ParticleSystem sparks;

	public GameObject skeletonSkull;

	public GameObject[] emissiveBodyParts;

	public SphereCollider awakeCollider;

	public SphereCollider sleepCollider;

	[Min(0f)]
	public float headPushRadius = 0.75f;

	public Vector3 headPushOffset = new Vector3(0f, -0.5f, 0f);

	[Min(0f)]
	public float headPushAcceleration = 30f;

	[Min(0f)]
	public float headPushSpeed = 4f;

	private List<Material> emissiveMaterials = new List<Material>();

	private Color emissionColor;

	private bool emissionEnabled = true;

	private float emissionDelay;

	private float emissionDelayDuration = 1f;

	public GameObject OnOffSwitch;

	public AnimationCurve switchOnCurve;

	public AnimationCurve switchOffCurve;

	private Material onOffSwitchMaterial;

	private Color onOffSwitchEmissionColor;

	private Vector3 onOffSwitchOriginalPosition;

	private float onOffSwitchEval;

	private bool onOffSwitchActive;

	private bool onOffSwitchTurningOff;

	private float onOffCooldown;

	private Color onOffSwitchEmissionCurrent;

	private Color onOffSwitchEmissionTarget;

	private bool sleepColliderActive;

	private SphereCollider headPushCollider;

	private Collider[] headPushColliders = new Collider[64];

	private readonly HashSet<Rigidbody> headPushRigidbodies = new HashSet<Rigidbody>();

	public Transform gunArm;

	public Transform gunCog;

	public SpringQuaternion gunCogSpring;

	public Transform gunBarrelBig;

	public Transform gunBarrelSmall;

	public AnimationCurve barrelCurveOut;

	public AnimationCurve barrelCurveIn;

	public Transform gunTipBigTransform;

	public Transform gunTipSmallTransform;

	public MeshRenderer gunBarrelMesh;

	public Color gunBarrelEmissionCharged = Color.yellow;

	private Quaternion gunArmTarget = Quaternion.identity;

	private bool gunArmSoundPlayedExtend;

	private bool gunReadyReset;

	private SpringQuaternion gunArmSpring = new SpringQuaternion();

	private Quaternion gunCogTarget = Quaternion.identity;

	private bool gunBarrelActiveOut;

	private bool gunBarrelActiveIn;

	private float gunBarrelLerp;

	private float gunBarrelLerpSpeed = 1.5f;

	public Transform aimHorizontal;

	public Transform aimVertical;

	private SpringQuaternion rotationSpringY = new SpringQuaternion();

	private SpringQuaternion rotationSpringX = new SpringQuaternion();

	private Quaternion prevAimHorizontalRot;

	private Quaternion prevAimVerticalRot;

	private float rotationSpeed = 10f;

	private float rotationDampening = 0.75f;

	public AnimationCurve BigSensorCurve;

	public AnimationCurve SmallSensorCurve;

	public Transform BigSensor;

	public Transform SmallSensor;

	public float SmallSensorLerp;

	public float SmallSensorLerpSpeed = 1f;

	public State currentState;

	public float stateTimer;

	private bool stateImpulse;

	private float stateTicker;

	private float currentStateEnterTime;

	private double currentStateNetworkStartTime;

	private int networkPlayerTargetViewID = -1;

	private int networkItemTargetViewID = -1;

	private int networkItemReactPlayerViewID = -1;

	private float networkTargetRetryTimer;

	private bool skipPendingRuckusOnNextObserve;

	public Sound hurtSound;

	public Sound shockWaveBuildUpSound;

	public Sound FlashSound;

	public Sound moveSmall;

	public Sound moveBig;

	public Sound moveLoopHorizontal;

	public Sound moveLoopVertical;

	public Sound idleLoop;

	public Sound powerOn;

	public Sound powerDown;

	public Sound lightsOn;

	public Sound lightsOff;

	public Sound smallSensorSound;

	public Sound bigSensorSound;

	public Sound onOffSwitchSoundOn;

	public Sound onOffSwitchSoundOff;

	public Sound soundHit;

	public Sound soundShoot;

	public Sound soundShootGlobal;

	public Sound bonkSound;

	public Sound shakePlayerSound;

	public Sound throwPlayerSound;

	public Transform VoiceBox;

	public AudioSource voiceBoxSource;

	public Sound voiceBoxSound;

	public List<AudioClip> voiceBoxSoundClips;

	public List<AudioClip> voiceBoxSoundClipsAngry;

	public List<AudioClip> voiceBoxSoundClipsHurt;

	public List<AudioClip> voiceBoxSoundClipsSee;

	public List<AudioClip> voiceBoxSoundClipsGrab;

	public List<AudioClip> voiceBoxSoundClipsJudge;

	private bool VoiceBoxActive;

	private bool VoiceBoxActiveAngry;

	private bool VoiceBoxActiveSee;

	private bool VoiceBoxActiveGrab;

	private bool VoiceBoxActiveJudge;

	public Sound scanSound;

	public Sound grabSound;

	public Sound releaseSound;

	public Sound grabLoop;

	public AudioSource grabLoopSource;

	public float grabLoopPitchMin = 0.6f;

	public float grabLoopPitchMax = 1f;

	public Sound itemScanSound;

	public Sound itemApproveSound;

	public Sound itemDisapproveSound;

	public Sound itemDenySound;

	public Color itemDenyBeamColor = new Color(0.5f, 0.9f, 1f);

	[Min(0.05f)]
	public float itemDenyZapTime = 0.25f;

	[Min(0f)]
	public float itemDenyPushSpeed = 8f;

	[Min(0f)]
	public float itemDenyPushUp = 2f;

	public Sound itemTossSound;

	public float itemScanDurationMin = 1f;

	public float itemScanDurationMax = 3f;

	public float itemVerdictDuration = 1.5f;

	public float itemReactDuration = 1f;

	public float itemPlayDurationMin = 2f;

	public float itemPlayDurationMax = 6f;

	public float itemReachInDuration = 12f;

	[Min(0f)]
	public float itemDislikeGrabDurationMin = 5f;

	[Min(0f)]
	public float itemDislikeGrabDurationMax = 10f;

	public Vector2 itemLikeDiscountRange = new Vector2(0.5f, 0.7f);

	[Min(0f)]
	public int itemLikeDiscountMinimumValue = 5000;

	[Min(0f)]
	public float itemDiscountDeniedRuckus = 100f;

	[Min(0f)]
	public float itemLikeVoicePitch = 1.5f;

	public PrefabRef itemLikeParticlesPrefab;

	[Min(0f)]
	public float itemLikeParticlesLifetime = 6f;

	public Color itemLikeLightColor = new Color(0.25f, 1f, 0.35f);

	[Min(0f)]
	public float itemLikeLightDuration = 1.25f;

	[Min(0f)]
	public float itemLikeLightIntensityMultiplier = 2f;

	public Color itemDislikeLightColor = Color.red;

	[Min(0f)]
	public float itemDislikeLightDuration = 1.25f;

	[Min(0f)]
	public float itemDislikeLightIntensityMultiplier = 2f;

	public PrefabRef itemDislikeAffectPrefab;

	public float itemDislikeAffectTime = 2f;

	public float itemHoldDistance = 1f;

	public float itemFollowMaxSpeed = 6f;

	public float itemGrabLightMass = 0.5f;

	public float itemGrabHeavyMass = 4f;

	public float itemGrabHeavySpeedMultiplier = 0.25f;

	public float itemGrabFollowStrength = 7f;

	public float itemGrabMaxAcceleration = 30f;

	public float itemGrabHeavyForceMultiplier = 0.65f;

	public float itemGrabAngryStrengthMultiplier = 10f;

	public float itemTossHeavyMultiplier = 0.4f;

	public float itemLookPitchMax = 40f;

	public float itemBeamScanDurationMin = 0.25f;

	public float itemBeamScanDurationMax = 1f;

	public float itemBeamIntroOutroFraction = 0.2f;

	[Min(0f)]
	public float itemPresentationRadius = 3f;

	[Range(0f, 180f)]
	public float itemPresentationConeAngle = 120f;

	[Min(2f)]
	public float itemPresentationDuration = 2f;

	[Min(0f)]
	public float itemPresentationGraceDuration = 0.35f;

	public float itemTossOutForce = 22f;

	public float itemTossOutUp = 7f;

	public float itemShakeFrequency = 8f;

	public float itemShakeAmplitude = 0.35f;

	public float itemShakeMaxSpeed = 18f;

	public float itemPlaySwingMaxSpeed = 14f;

	[Range(0f, 1f)]
	public float itemMeleeAttackChance = 0.5f;

	[Min(0f)]
	public float itemMeleeWindupDurationLight = 0.45f;

	[Min(0f)]
	public float itemMeleeWindupDurationHeavy = 0.85f;

	[Min(0f)]
	public float itemMeleeSwingDurationLight = 0.35f;

	[Min(0f)]
	public float itemMeleeSwingDurationHeavy = 0.65f;

	[Range(0f, 180f)]
	public float itemMeleeWindupAngle = 125f;

	[Range(0f, 180f)]
	public float itemMeleeFollowThroughAngle = 105f;

	[Range(0f, 1f)]
	public float itemMeleeStrengthMultiplier = 0.25f;

	[Min(0f)]
	public float itemMeleeWindupMaxSpeed = 8f;

	[Min(0f)]
	public float itemMeleeSwingMaxSpeed = 16f;

	[Min(0f)]
	public float itemMeleeAngularAccelerationLight = 55f;

	[Min(0f)]
	public float itemMeleeAngularAccelerationHeavy = 35f;

	[Min(0f)]
	public float itemMeleeMaxAngularVelocity = 14f;

	[Min(0f)]
	public float itemMeleePredictionMax = 0.65f;

	public Color itemBeamColorScan = new Color(1f, 0.55f, 0f);

	public Color itemBeamColorHoldScan = new Color(0.55f, 0.18f, 0.02f);

	public Color itemBeamColorScanLine = Color.yellow;

	[Range(0.1f, 1f)]
	public float itemBeamScanWidthMultiplier = 0.65f;

	public Color itemBeamColorPositive = new Color(0.4f, 1f, 0.5f);

	public Color itemBeamColorNegative = Color.red;

	private float grabInitialDistance = 1f;

	private const int itemDiscountAttemptLimit = 3;

	private int itemDiscountAttempts;

	internal const string itemDenyEffectsPath = "Items/Item Mine Stun";

	private ItemMineStun itemDenyEffects;

	private float itemDenyBeamTimer;

	private Vector3 itemDenyBeamPosition;

	private PhysGrabObject itemDenyBeamTarget;

	private float itemPresentationGraceTimer;

	private int itemScanSeed;

	private Vector2 itemScanAim;

	private int itemScanPresentationSeed = int.MinValue;

	private LineBetweenTwoPoints itemScanLineBetweenTwoPoints;

	private Color itemScanLineColorCurrent;

	private readonly List<Collider> itemPresentationColliders = new List<Collider>();

	private readonly Dictionary<PhysGrabber, int> itemPresentationReleasedGrabs = new Dictionary<PhysGrabber, int>();

	private int[] itemReactionSnapshotViewIDs;

	private int[] itemReactionSnapshotTimesShown;

	private int[] itemReactionSnapshotStates;

	private int[] itemReactionSnapshotValues;

	private int itemReactionSnapshotShopTotalCost = int.MinValue;

	private readonly HashSet<int> itemReactionSnapshotPendingViewIDs = new HashSet<int>();

	private float itemReactionSnapshotRetryTimer;

	private float itemReactionSnapshotRetryTimeoutTimer;

	public AnimationCurve judgeChargeCurve;

	public Sound judgeBuildUpLoop;

	public Light barrelChargeLight;

	public float barrelChargeLightMaxIntensity = 4f;

	public ParticleSystem judgeChargeParticles;

	public float judgeChargeParticlesMaxScale = 8f;

	public float judgeBuildUpPitchMin = 0.5f;

	public float judgeBuildUpPitchMax = 6f;

	public float judgeBuildUpVolumeMin;

	public float judgeBuildUpVolumeMax = 1f;

	public float judgeGunShakeMaxAngle = 3f;

	public float judgeGunShakeSpeed = 30f;

	private Material gunBarrelMaterial;

	private float judgeCharge;

	private float judgeReleaseTimer;

	private bool judgeReleaseActive;

	private float judgeChargeAtShoot;

	private Quaternion frozenAimTargetX = Quaternion.identity;

	private Quaternion frozenAimTargetY = Quaternion.identity;

	private float voiceCoolDown = 1.5f;

	private float VoiceBoxSoundTime;

	private float VoiceBoxSoundClipTimer;

	private float VoiceBoxSoundClipLoudness;

	private int VoiceBoxSoundClipSampleDataLength = 1024;

	private float[] VoiceBoxSoundClipSampleData;

	private bool moveShakeImpactReady;

	private PlayerAvatar playerTarget;

	private PlayerAvatar prevPlayerTarget;

	private bool ruckusTarget;

	private Transform itemTarget;

	private Quaternion rotationTargetX = Quaternion.identity;

	private Quaternion rotationTargetY = Quaternion.identity;

	public TextMeshProUGUI textMesh;

	public Sound soundEmojiGlitch;

	public GameObject emojiScreenGlitch;

	public Color emojiScreenGlitchColor = Color.yellow;

	public Transform lookAtEmojiHereTransform;

	public Transform emojiForcePosition;

	[HideInInspector]
	[SerializeField]
	private string[] noticeEmoji = new string[20]
	{
		"void", "grave", "void_eye", "finger_wag", "point", "jail", "fedup", "eyeclosed", "eye", "mouthsad",
		"eyesmall", "X", "!", "?", "thumbsdown", "realistic_eye", "handcuffs", "mouth", "nasty_lips", "heartbreak"
	};

	[HideInInspector]
	[SerializeField]
	private string[] shootEmoji = new string[7] { "bang", "skull", "thumbsdown", "fire", "rocketfire", "deathhead", "weird_eye" };

	[HideInInspector]
	[SerializeField]
	private string[] idleEmoji = new string[7] { "sparkle", "police", "register", "shop", "shoppingcart", "mouthhappy", "$$" };

	[HideInInspector]
	[SerializeField]
	private string[] angryEmoji = new string[11]
	{
		"handcuffs", "!", "weird_eye", "void_eye", "heartbreak", "fist", "mouthsurprised", "jail", "void", "blood",
		"grave"
	};

	[HideInInspector]
	[SerializeField]
	private string[] veryAngryEmoji = new string[13]
	{
		"angry", "fist", "finger_wag", "fedup", "disappointed", "disappointed2", "smh", "dry", "thumbsdown", "thumbsdown2",
		":(", ":|", ":/"
	};

	[HideInInspector]
	[SerializeField]
	private string[] scanEmoji = new string[8] { "eye", "eyesmall", "realistic_eye", "weird_eye", "void_eye", "?", "think", "spiral" };

	[HideInInspector]
	[SerializeField]
	private string[] approveEmoji = new string[9] { "mouthhappy", "sparkle", "$$", "heart", "hearteyes", "thumbsup", "moneyeyes", "shoppingcart", "deal" };

	[HideInInspector]
	[SerializeField]
	private string[] disapproveEmoji = new string[8] { "thumbsdown", "mouthsad", "nasty_lips", "X", "fedup", "heartbreak", "dry", "poop" };

	private List<string[]> emojiTypes;

	private int prevTypeIndex;

	private int prevEmojiIndex;

	private string currentDisplayedEmoji = "";

	private float emojiScreenGlitchTimer;

	private float emojiScreenGlitchScaleTimer;

	private bool BigSensorActive;

	private float BigSensorLerp;

	private float BigSensorLerpSpeed = 1.5f;

	private float BigSensorTimer;

	private float BigSensorDelay;

	private bool SmallSensorActive;

	private float SmallSensorTimer;

	private float SmallSensorDelay;

	public GameObject Flash;

	public GameObject shockWave;

	private bool flashActive;

	private float flashTimer;

	private float flashLength = 0.4f;

	private float flashDelay;

	private float flashDelayLength = 3f;

	public PropLight shootLight;

	public PropLight hitLight;

	public Light scanLight;

	public AnimationCurve scanLightInCurve;

	public AnimationCurve scanLightOutCurve;

	public AnimationCurve scanLightJudgeCurve;

	public Color scanLightColorSee = Color.white;

	public Color scanLightColorGrab = Color.red;

	public Color scanLightColorWarning = new Color(1f, 0.55f, 0f);

	public float scanLightSpotAngleJudge = 10f;

	public SpringQuaternion scanLightSpring = new SpringQuaternion();

	private float shootLightIntensity;

	private bool shootLightActive;

	private float hitLightIntensity;

	private bool hitLightActive;

	private float scanLightIntensityOriginal;

	private float scanLightSpotAngleOriginal;

	private float scanLightInTimer;

	private float scanLightOutTimer;

	private bool scanLightOn;

	private Vector3 scanLightAimTarget;

	private Quaternion scanLightRotationTarget = Quaternion.identity;

	private float judgeLightOutroTriggerTime = 0.2f;

	public LineRenderer lineRenderer;

	public LineRenderer linerendererSmall;

	public AnimationCurve lineRendererWidthCurve;

	public HurtCollider hurtCollider;

	private float lineRendererLerp;

	private bool lineRendererActive;

	private float hurtColliderTimer;

	public LineBetweenTwoPoints lineBetweenTwoPoints;

	public Transform lineStartPoint;

	public Transform playerPoint;

	public Transform playerPoint2;

	public Transform shopkeeperFacePoint;

	public Color lineColorSee = Color.white;

	public Color lineColorGrab = Color.red;

	public Color lineColorWarning = new Color(0.75f, 0.22f, 0.05f);

	public Color emissionColorGrab = Color.red;

	private Color lineColorCurrent;

	private float seeRayTimer;

	private int seeRayIndex;

	private float grabReachTimer;

	private bool grabReached;

	public float stuckPushForce = 8f;

	public float stuckPhaseDuration = 1f;

	public float dislodgeBackwardForce = 5f;

	public float dislodgeUpForce = 3f;

	public float dislodgeTorqueForce = 8f;

	public float ruckusWaitDistance = 16f;

	public float ruckusWaitDuration = 16f;

	private float stuckPrevDistance;

	private float stuckNotClosingTimer;

	private bool stuckActive;

	private bool stuckPhaseDislodge;

	private float stuckPhaseTimer;

	private Vector3 stuckPushDirection;

	private float beamFromSensorTimer;

	private float scanBeamOverrideTimer;

	private Vector3 scanBeamOverrideTarget;

	private bool scanBeamOverrideActive;

	private float grabBeamOverrideTimer;

	private Vector3 grabBeamOverrideTarget;

	private bool grabBeamOverrideActive;

	private bool grabBeamReleaseSoundPlayed;

	private const float beamOverrideRefresh = 0.1f;

	private PhysGrabObject itemReactObject;

	private PlayerAvatar itemReactPlayer;

	private ItemMelee itemReactMelee;

	private Rigidbody itemReactMeleeRigidbody;

	private Transform itemMeleeGripPoint;

	private Transform itemMeleeSwingPoint;

	private Collider itemMeleeHitCollider;

	private Vector3 itemMeleeHitLocalDirection;

	private float itemMeleeSwingDuration;

	private float itemMeleeSwingContactFraction;

	private float itemMeleeSwingDirection;

	private float itemMeleeMaxAngularVelocityOriginal;

	private bool itemMeleePhysicsOverrideApplied;

	private bool itemMeleeSwingImpulse;

	private bool itemVerdictPositive;

	private bool itemTossApplied;

	private float itemPlaySwingTimer;

	private Vector3 itemPlaySwingTarget;

	private bool itemReactSensorReady;

	private float itemReactSensorTimer;

	private Quaternion bigSensorMainLocalRotation;

	private float itemReactionLightTimer;

	private Light itemReactionFlashLight;

	private float itemReactionLightDuration;

	private float itemReactionLightIntensityMultiplier;

	private Color itemReactionLightColor;

	private Vector3 itemReactionLightTarget;

	private List<Collider> itemScanColliders = new List<Collider>();

	private int itemScanColliderIndex;

	private Collider itemScanCurrentCollider;

	private float itemScanBeamTimer;

	private float itemScanBeamDuration = 0.5f;

	private const float shopkeeperItemScanCooldownTime = 0.5f;

	private float shopkeeperItemScanCooldown;

	public Transform shootEffectTransform;

	public List<ParticleSystem> shootEffects;

	public Transform shootEffectSmallTransform;

	public List<ParticleSystem> shootEffectsSmall;

	public Transform hitEffectTransform;

	public List<ParticleSystem> hitEffects;

	public ParticleSystem screenBonkParticles;

	private Dictionary<PlayerAvatar, List<PlayerRuckusRecord>> ruckusRecords = new Dictionary<PlayerAvatar, List<PlayerRuckusRecord>>();

	private Dictionary<PlayerAvatar, List<PlayerCarryThrustRecord>> carryThrustRecords = new Dictionary<PlayerAvatar, List<PlayerCarryThrustRecord>>();

	private Dictionary<PlayerAvatar, PlayerRuckusScoreRecord> ruckusScores = new Dictionary<PlayerAvatar, PlayerRuckusScoreRecord>();

	private HashSet<PlayerAvatar> ruckusPunishFromScoreCache = new HashSet<PlayerAvatar>();

	private List<PlayerAvatar> ruckusRecordKeyCache = new List<PlayerAvatar>();

	private const float ruckusRecordTimer = 6f;

	private const float ruckusDamageThreshold = 20f;

	private const int ruckusHitThreshold = 3;

	private const int carryThrustThreshold = 6;

	private const float carryThrustWindow = 12f;

	private const float ruckusScoreDamageMultiplier = 5f;

	private const float ruckusScoreHit = 15f;

	private const float ruckusScoreShoot = 100f;

	private const float ruckusScoreMineActivated = 100f;

	private const float ruckusScoreExplosionDetonated = 200f;

	private const float ruckusScoreStaffCast = 200f;

	private const float ruckusScoreMeleePhysHit = 100f;

	private const float ruckusScorePhysObjectHitPlayer = 150f;

	private const float ruckusScoreVehicleImpactHitPlayer = 100f;

	private const float ruckusScoreTumble = 50f;

	private const float ruckusScoreCarryThrust = 40f;

	private const float ruckusScoreDriftPerSec = 50f;

	private const float ruckusScoreLaserPerSec = 100f;

	private const float ruckusScoreExplosive = 200f;

	private const float ruckusScoreLimit = 1000f;

	private const float ruckusScoreSleepingCap = 500f;

	private const float ruckusScoreAfterPunish = 800f;

	private const float ruckusScoreAttackShopkeeper = 100f;

	private static readonly float[] angryScoreThresholds = new float[4] { 200f, 400f, 600f, 800f };

	private const float warnCooldownTime = 5f;

	private const float angryObservationMinDuration = 1f;

	private const float angryObservationMaxDuration = 3f;

	private const float angryObservationSensorInterval = 0.4f;

	private const float ruckusJudgeRecoilDegrees = 20f;

	private const float shopkeeperAttentionRange = 15f;

	private float angryObservationSensorTimer;

	private const float warnTellOffStareMin = 1f;

	private const float warnTellOffStareMax = 2f;

	private const float warnTellOffStareHoldMaxSpeed = 6f;

	private const float warnTellOffShakeMin = 1f;

	private const float warnTellOffShakeMax = 3f;

	private const float warnTellOffShakeFrequency = 6f;

	private const float warnTellOffShakeAmplitude = 0.3f;

	private const float warnTellOffShakeMaxSpeed = 15f;

	private const float warnTellOffLectureMin = 1f;

	private const float warnTellOffLectureMax = 2f;

	private const float warnTellOffLectureMaxSpeed = 6f;

	private const float warnTellOffBonkChance = 0.5f;

	private const float warnTellOffBonkWindow = 0.13f;

	private const float warnTellOffBonkMaxSpeed = 40f;

	private const float warnTellOffPullInDuration = 0.18f;

	private const float warnTellOffThrowOutDuration = 0.22f;

	private const float warnTellOffPullInForce = 14f;

	private const float warnTellOffThrowOutForce = 22f;

	private const float warnTellOffThrowOutUp = 7f;

	private const float warnTellOffSensorInterval = 0.3f;

	private static readonly float[][] warnTellOffBonkPatterns = new float[3][]
	{
		new float[3] { 0.1f, 0.5f, 0.9f },
		new float[9] { 0f, 0.2f, 1.2f, 1.4f, 1.6f, 1.8f, 2f, 2.2f, 2.4f },
		new float[4] { 0.25f, 0.75f, 1.25f, 1.75f }
	};

	private static readonly float[] warnTellOffBonkPatternDurations = new float[3] { 1f, 2.5f, 2f };

	private float warnTellOffStareBeforeDuration;

	private float warnTellOffStareAfterDuration;

	private float warnTellOffShakeDuration;

	private float warnTellOffLectureDuration;

	private float warnTellOffBonkDuration;

	private float warnTellOffSensorTimer;

	private bool warnTellOffThrowApplied;

	private bool warnTellOffShakeEntered;

	private bool warnTellOffStareAfterEntered;

	private bool warnTellOffLectureEntered;

	private bool warnTellOffOnEmojiScreen;

	private bool warnTellOffAimFrozen;

	private int warnTellOffBonkSoundsPlayed;

	private const float warnTellOffBonkSoundProximity = 0.2f;

	private bool warnTellOffBonkActive;

	private bool warnTellOffBonkEntered;

	private int warnTellOffBonkPatternIndex;

	private int warnTellOffBonksApplied;

	private float warnTellOffShakePrevY;

	private bool warnTellOffShakeReleaseEnabled;

	private float warnTellOffShakeReleaseTime;

	private bool warnTellOffShakeReleaseFired;

	private const float warnTellOffShakeReleaseChance = 0.3f;

	private const float warnTellOffShakeReleaseMinTime = 0.5f;

	private const float warnTellOffShakeReleaseDirForce = 15f;

	private const float warnTellOffShakeReleaseAwayForce = 8f;

	private bool shakeSoundActive;

	private Rigidbody shakeSoundTarget;

	private float shakeSoundPrevY;

	private bool shakeSoundSampleReady;

	private bool shakeSoundGoingUp;

	private float shakeSoundCooldown;

	private const float shakeSoundCooldownTime = 0.05f;

	[HideInInspector]
	public bool debugRuckus;

	[RuntimeInitializeOnLoadMethod(/*Could not decode attribute arguments.*/)]
	private static void RuntimeInitializeOnLoad()
	{
		instance = null;
	}

	private void Awake()
	{
		//IL_004d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0052: Unknown result type (might be due to invalid IL or missing references)
		//IL_0079: Unknown result type (might be due to invalid IL or missing references)
		//IL_007e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0085: Unknown result type (might be due to invalid IL or missing references)
		//IL_008a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0091: Unknown result type (might be due to invalid IL or missing references)
		//IL_009b: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a0: Unknown result type (might be due to invalid IL or missing references)
		//IL_0109: Unknown result type (might be due to invalid IL or missing references)
		//IL_010e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0137: Unknown result type (might be due to invalid IL or missing references)
		//IL_013c: Unknown result type (might be due to invalid IL or missing references)
		instance = this;
		photonView = ((Component)this).GetComponent<PhotonView>();
		HeadPushSetup();
		VoiceBoxSoundClipSampleData = new float[VoiceBoxSoundClipSampleDataLength];
		flashTimer = flashLength;
		flashDelay = flashDelayLength;
		onOffSwitchOriginalPosition = OnOffSwitch.transform.localPosition;
		onOffSwitchMaterial = OnOffSwitch.GetComponent<Renderer>().material;
		onOffSwitchEmissionColor = onOffSwitchMaterial.GetColor("_EmissionColor");
		onOffSwitchEmissionCurrent = onOffSwitchEmissionColor;
		onOffSwitchEmissionTarget = onOffSwitchEmissionColor * 0.1f;
		GameObject[] array = emissiveBodyParts;
		for (int i = 0; i < array.Length; i++)
		{
			Renderer component = array[i].GetComponent<Renderer>();
			if (Object.op_Implicit((Object)(object)component) && Object.op_Implicit((Object)(object)component.material))
			{
				emissiveMaterials.Add(component.material);
			}
		}
		if (emissiveMaterials.Count > 0)
		{
			emissionColor = emissiveMaterials[0].GetColor("_EmissionColor");
		}
		if ((Object)(object)textMesh == (Object)null)
		{
			Debug.LogError((object)"TextMeshProUGUI component is not assigned.");
		}
		bigSensorMainLocalRotation = BigSensor.parent.localRotation;
		emojiTypes = new List<string[]> { noticeEmoji, shootEmoji, idleEmoji, angryEmoji, veryAngryEmoji, scanEmoji, approveEmoji, disapproveEmoji };
	}

	private void Start()
	{
		//IL_01e5: Unknown result type (might be due to invalid IL or missing references)
		//IL_0268: Unknown result type (might be due to invalid IL or missing references)
		//IL_026e: Unknown result type (might be due to invalid IL or missing references)
		if (!RunManager.instance.multiplayerPool.ResourceCache.TryGetValue("Items/Item Mine Stun", out var value) || !Object.op_Implicit((Object)(object)value))
		{
			value = Resources.Load<GameObject>("Items/Item Mine Stun");
		}
		if (Object.op_Implicit((Object)(object)value))
		{
			itemDenyEffects = value.GetComponent<ItemMineStun>();
		}
		shootLightIntensity = shootLight.lightComponent.intensity;
		hitLightIntensity = hitLight.lightComponent.intensity;
		if (SemiFunc.IsMasterClientOrSingleplayer())
		{
			currentStateNetworkStartTime = (SemiFunc.IsMultiplayer() ? PhotonNetwork.Time : ((double)Time.time));
			ShopKeeperStateSend();
			ItemReactionSnapshotSend();
		}
		if (Object.op_Implicit((Object)(object)scanLight))
		{
			scanLightIntensityOriginal = scanLight.intensity;
			scanLightSpotAngleOriginal = scanLight.spotAngle;
			itemReactionFlashLight = Object.Instantiate<Light>(scanLight, ((Component)scanLight).transform.parent);
			((Object)itemReactionFlashLight).name = "Item Reaction Light";
			itemReactionFlashLight.intensity = 0f;
			((Behaviour)itemReactionFlashLight).enabled = false;
			scanLight.intensity = 0f;
			((Behaviour)scanLight).enabled = false;
			scanLightInTimer = 0.2f;
			scanLightOutTimer = 0.2f;
		}
		if (Object.op_Implicit((Object)(object)lineBetweenTwoPoints))
		{
			itemScanLineBetweenTwoPoints = Object.Instantiate<LineBetweenTwoPoints>(lineBetweenTwoPoints, ((Component)lineBetweenTwoPoints).transform.parent);
			((Object)itemScanLineBetweenTwoPoints).name = "Item Scan Beam";
			itemScanLineBetweenTwoPoints.baseWidth *= itemBeamScanWidthMultiplier;
			itemScanLineBetweenTwoPoints.baseWidthOscillation *= itemBeamScanWidthMultiplier;
		}
		if (Object.op_Implicit((Object)(object)gunBarrelMesh))
		{
			gunBarrelMaterial = ((Renderer)gunBarrelMesh).material;
			gunBarrelMaterial.SetColor("_EmissionColor", Color.black);
		}
		if (Object.op_Implicit((Object)(object)barrelChargeLight))
		{
			barrelChargeLight.intensity = 0f;
			((Behaviour)barrelChargeLight).enabled = false;
		}
		if (Object.op_Implicit((Object)(object)grabLoopSource))
		{
			grabLoop.Source = grabLoopSource;
		}
		if (Random.Range(0, 10) == 0 && SemiFunc.IsMasterClientOrSingleplayer())
		{
			if (SemiFunc.IsMultiplayer())
			{
				photonView.RPC("SetSkullActiveRPC", (RpcTarget)0, Array.Empty<object>());
			}
			else
			{
				SetSkullActiveRPC();
			}
		}
	}

	private void OnDisable()
	{
		itemDenyBeamTimer = 0f;
		itemDenyBeamTarget = null;
	}

	private void Update()
	{
		//IL_0148: Unknown result type (might be due to invalid IL or missing references)
		//IL_014e: Unknown result type (might be due to invalid IL or missing references)
		//IL_015e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0163: Unknown result type (might be due to invalid IL or missing references)
		//IL_0174: Unknown result type (might be due to invalid IL or missing references)
		//IL_020a: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f6: Unknown result type (might be due to invalid IL or missing references)
		//IL_0106: Unknown result type (might be due to invalid IL or missing references)
		//IL_0373: Unknown result type (might be due to invalid IL or missing references)
		//IL_0347: Unknown result type (might be due to invalid IL or missing references)
		//IL_06a3: Unknown result type (might be due to invalid IL or missing references)
		//IL_05a4: Unknown result type (might be due to invalid IL or missing references)
		//IL_04be: Unknown result type (might be due to invalid IL or missing references)
		//IL_04c8: Unknown result type (might be due to invalid IL or missing references)
		//IL_0864: Unknown result type (might be due to invalid IL or missing references)
		//IL_0833: Unknown result type (might be due to invalid IL or missing references)
		//IL_0838: Unknown result type (might be due to invalid IL or missing references)
		//IL_081c: Unknown result type (might be due to invalid IL or missing references)
		//IL_07f0: Unknown result type (might be due to invalid IL or missing references)
		//IL_07f5: Unknown result type (might be due to invalid IL or missing references)
		//IL_05f9: Unknown result type (might be due to invalid IL or missing references)
		//IL_0869: Unknown result type (might be due to invalid IL or missing references)
		//IL_0852: Unknown result type (might be due to invalid IL or missing references)
		//IL_084a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0821: Unknown result type (might be due to invalid IL or missing references)
		//IL_080f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0807: Unknown result type (might be due to invalid IL or missing references)
		//IL_0871: Unknown result type (might be due to invalid IL or missing references)
		//IL_0876: Unknown result type (might be due to invalid IL or missing references)
		//IL_08ac: Unknown result type (might be due to invalid IL or missing references)
		//IL_08b1: Unknown result type (might be due to invalid IL or missing references)
		//IL_0524: Unknown result type (might be due to invalid IL or missing references)
		//IL_094f: Unknown result type (might be due to invalid IL or missing references)
		//IL_097e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0983: Unknown result type (might be due to invalid IL or missing references)
		//IL_099d: Unknown result type (might be due to invalid IL or missing references)
		//IL_06ea: Unknown result type (might be due to invalid IL or missing references)
		//IL_0c25: Unknown result type (might be due to invalid IL or missing references)
		//IL_0d59: Unknown result type (might be due to invalid IL or missing references)
		//IL_0d8a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0e2d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0e5e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0db5: Unknown result type (might be due to invalid IL or missing references)
		//IL_0e8c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0ce1: Unknown result type (might be due to invalid IL or missing references)
		//IL_0f62: Unknown result type (might be due to invalid IL or missing references)
		//IL_0f04: Unknown result type (might be due to invalid IL or missing references)
		//IL_0f2f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0fda: Unknown result type (might be due to invalid IL or missing references)
		//IL_1005: Unknown result type (might be due to invalid IL or missing references)
		//IL_11e9: Unknown result type (might be due to invalid IL or missing references)
		//IL_1236: Unknown result type (might be due to invalid IL or missing references)
		//IL_133c: Unknown result type (might be due to invalid IL or missing references)
		//IL_145a: Unknown result type (might be due to invalid IL or missing references)
		//IL_1464: Unknown result type (might be due to invalid IL or missing references)
		//IL_147b: Unknown result type (might be due to invalid IL or missing references)
		//IL_1485: Unknown result type (might be due to invalid IL or missing references)
		//IL_14ad: Unknown result type (might be due to invalid IL or missing references)
		//IL_14b7: Unknown result type (might be due to invalid IL or missing references)
		//IL_14ce: Unknown result type (might be due to invalid IL or missing references)
		//IL_14d8: Unknown result type (might be due to invalid IL or missing references)
		//IL_1503: Unknown result type (might be due to invalid IL or missing references)
		//IL_150e: Unknown result type (might be due to invalid IL or missing references)
		//IL_1548: Unknown result type (might be due to invalid IL or missing references)
		//IL_15a8: Unknown result type (might be due to invalid IL or missing references)
		//IL_15b3: Unknown result type (might be due to invalid IL or missing references)
		//IL_15cb: Unknown result type (might be due to invalid IL or missing references)
		//IL_15d0: Unknown result type (might be due to invalid IL or missing references)
		//IL_15dc: Unknown result type (might be due to invalid IL or missing references)
		//IL_15e1: Unknown result type (might be due to invalid IL or missing references)
		//IL_1588: Unknown result type (might be due to invalid IL or missing references)
		NetworkTargetsResolveTick();
		ItemReactionSnapshotTick();
		if (SemiFunc.IsMasterClientOrSingleplayer())
		{
			StateMachine();
			if (currentState != State.Flash && currentState != State.Sleeping)
			{
				SensorBreakers();
			}
			if (shopkeeperItemScanCooldown > 0f)
			{
				shopkeeperItemScanCooldown -= Time.deltaTime;
			}
			RuckusRecordTick();
			ItemDiscountDeniedTick();
			ItemScanProximityLogic();
			if (currentState == State.Sleeping && !sleepColliderActive && SemiFunc.PerSecond(5f, (Object)(object)this))
			{
				SemiLogger.LogJannek("CHECKING");
				if (Physics.OverlapSphere(((Component)sleepCollider).transform.position, sleepCollider.radius, LayerMask.op_Implicit(SemiFunc.LayerMaskGetPlayersAndPhysObjects())).Length == 0)
				{
					ActivateSleepCollider();
				}
			}
			if (currentState != State.Sleeping && sleepColliderActive && SemiFunc.PerSecond(5f, (Object)(object)this) && Physics.OverlapSphere(((Component)awakeCollider).transform.position, awakeCollider.radius, LayerMask.op_Implicit(SemiFunc.LayerMaskGetPlayersAndPhysObjects())).Length == 0)
			{
				ActivateAwakeCollider();
			}
		}
		ItemScanPresentationSyncLogic();
		if (onOffCooldown > 0f)
		{
			onOffCooldown -= Time.deltaTime;
		}
		onOffSwitchEmissionCurrent = Color.Lerp(onOffSwitchEmissionCurrent, onOffSwitchEmissionTarget, Time.deltaTime * 10f);
		onOffSwitchMaterial.SetColor("_EmissionColor", onOffSwitchEmissionCurrent);
		if (onOffSwitchActive)
		{
			onOffSwitchEval += 5f * Time.deltaTime;
			onOffSwitchEval = Mathf.Clamp01(onOffSwitchEval);
			AnimationCurve val = (onOffSwitchTurningOff ? switchOnCurve : switchOffCurve);
			OnOffSwitch.transform.localPosition = new Vector3(onOffSwitchOriginalPosition.x, onOffSwitchOriginalPosition.y - 0.08f * val.Evaluate(onOffSwitchEval), onOffSwitchOriginalPosition.z);
			if (onOffSwitchEval >= 1f)
			{
				onOffSwitchActive = false;
			}
		}
		if (currentState == State.Flash || currentState == State.Aim || currentState == State.Shoot || currentState == State.WaitForRuckusPlayer || currentState == State.SeeRuckusPlayer || currentState == State.SeeWarnPlayer || currentState == State.GrabRuckusPlayer || currentState == State.AngryObservation || currentState == State.WarnGrabPlayer || currentState == State.WarnTellOff)
		{
			LookAtPlayer();
			if ((currentState == State.Aim || currentState == State.Shoot || currentState == State.SeeRuckusPlayer || currentState == State.SeeWarnPlayer || currentState == State.GrabRuckusPlayer || currentState == State.AngryObservation || currentState == State.WarnGrabPlayer || currentState == State.WarnTellOff) && Object.op_Implicit((Object)(object)playerTarget))
			{
				UpdateGunCogTarget();
			}
		}
		if (currentState == State.Aim || currentState == State.GrabRuckusPlayer || currentState == State.JudgeRuckusPlayer || currentState == State.WarnGrabPlayer || currentState == State.WarnTellOff || ItemControlState(currentState))
		{
			if (!gunArmSoundPlayedExtend)
			{
				moveBig.Play(gunArm.position);
			}
			gunArmSoundPlayedExtend = true;
			float num = gunArm.localEulerAngles.x;
			if (num > 180f)
			{
				num -= 360f;
			}
			if (Mathf.Abs(num - -70f) < 5f && !gunBarrelActiveOut && gunBarrelLerp < 1f)
			{
				gunBarrelActiveOut = true;
				gunBarrelActiveIn = false;
				gunBarrelLerp = 0f;
			}
		}
		else
		{
			if (gunBarrelActiveOut || gunBarrelLerp > 0f)
			{
				gunBarrelActiveOut = false;
				if (!gunBarrelActiveIn)
				{
					gunBarrelActiveIn = true;
					gunBarrelLerp = 0f;
				}
			}
			gunArmSoundPlayedExtend = false;
		}
		if (currentState == State.Sleeping)
		{
			if ((Object)(object)pose.currentPose != (Object)(object)pose.GetPoseByName("Sleeping"))
			{
				pose.SetPoseByName("Sleeping");
			}
			idleLoop.PlayLoop(playing: false, 10f, 10f);
			if (emissionEnabled)
			{
				emissionDelay -= Time.deltaTime;
				if (emissionDelay <= 0f)
				{
					foreach (Material emissiveMaterial in emissiveMaterials)
					{
						emissiveMaterial.SetColor("_EmissionColor", emissionColor * 0.1f);
					}
					DisplayEmoji();
					GameObject[] array = sensorLights;
					for (int i = 0; i < array.Length; i++)
					{
						array[i].SetActive(false);
					}
					lightsOff.Play(((Component)this).transform.position);
					emissionEnabled = false;
					emissionDelay = emissionDelayDuration;
				}
			}
		}
		else
		{
			if (!emissionEnabled)
			{
				emissionDelay -= Time.deltaTime;
				if (emissionDelay <= 0f)
				{
					foreach (Material emissiveMaterial2 in emissiveMaterials)
					{
						emissiveMaterial2.SetColor("_EmissionColor", emissionColor);
					}
					GameObject[] array = sensorLights;
					for (int i = 0; i < array.Length; i++)
					{
						array[i].SetActive(true);
					}
					lightsOn.Play(((Component)this).transform.position);
					emissionEnabled = true;
					emissionDelay = emissionDelayDuration;
				}
			}
			if (currentState == State.Aim || currentState == State.WaitForRuckusPlayer || currentState == State.SeeRuckusPlayer || currentState == State.GrabRuckusPlayer || currentState == State.JudgeRuckusPlayer || currentState == State.Shoot || currentState == State.AngryObservation || currentState == State.WarnTellOff || ItemNegativeState(currentState))
			{
				foreach (Material emissiveMaterial3 in emissiveMaterials)
				{
					emissiveMaterial3.SetColor("_EmissionColor", emissionColorGrab);
				}
			}
			else if (emissionEnabled)
			{
				foreach (Material emissiveMaterial4 in emissiveMaterials)
				{
					emissiveMaterial4.SetColor("_EmissionColor", emissionColor);
				}
			}
		}
		if (currentState == State.Shoot || currentState == State.Aim || currentState == State.GrabRuckusPlayer || currentState == State.JudgeRuckusPlayer || currentState == State.WarnGrabPlayer || currentState == State.WarnTellOff || ItemControlState(currentState))
		{
			if ((currentState == State.Shoot || currentState == State.Aim || currentState == State.GrabRuckusPlayer || currentState == State.JudgeRuckusPlayer || currentState == State.WarnGrabPlayer || currentState == State.WarnTellOff || ItemAimPoseState(currentState)) && (Object)(object)pose.currentPose != (Object)(object)pose.GetPoseByName("Aim"))
			{
				pose.SetPoseByName("Aim");
			}
			Vector3 val2;
			if (ItemControlState(currentState))
			{
				if (ItemTargetValid())
				{
					val2 = itemReactObject.centerPoint;
				}
				else
				{
					val2 = ((grabBeamOverrideTarget != Vector3.zero) ? grabBeamOverrideTarget : ((Component)this).transform.position);
				}
			}
			else if (Object.op_Implicit((Object)(object)playerTarget))
			{
				val2 = ((Component)playerTarget).transform.position;
			}
			else
			{
				val2 = ((grabBeamOverrideTarget != Vector3.zero) ? grabBeamOverrideTarget : ((Component)this).transform.position);
			}
			float num2 = Vector3.Distance(((Component)this).transform.position, val2);
			float num3 = Mathf.Lerp(50f, 0f, Mathf.InverseLerp(4f, 10f, num2));
			gunArmTarget = Quaternion.Euler(-70f, 0f - num3, num3);
			if (currentState == State.Shoot || currentState == State.JudgeRuckusPlayer)
			{
				rotationSpringX.speed = 30f;
				rotationSpringY.speed = 40f;
				rotationSpringY.damping = 0.9f;
			}
			else
			{
				rotationSpringX.speed = 3f;
				rotationSpringY.speed = 20f;
				rotationSpringY.damping = 0.35f;
			}
			gunReadyReset = false;
		}
		else if (!gunReadyReset)
		{
			moveBig.Play(gunArm.position);
			gunArmTarget = Quaternion.Euler(0f, 0f, 0f);
			gunCogTarget.eulerAngles = new Vector3(0f, 0f, 0f);
			rotationSpringX.speed = rotationSpeed;
			rotationSpringY.speed = rotationSpeed;
			rotationSpringY.damping = rotationDampening;
			gunReadyReset = true;
		}
		if (currentState == State.WakeUp || currentState == State.Observe || currentState == State.Flash)
		{
			if ((Object)(object)pose.currentPose != (Object)(object)pose.GetPoseByName("Idle"))
			{
				pose.SetPoseByName("Idle");
			}
			idleLoop.PlayLoop(playing: true, 10f, 10f);
		}
		if (currentState == State.SeeRuckusPlayer || currentState == State.SeeWarnPlayer || currentState == State.WaitForRuckusPlayer)
		{
			if ((Object)(object)pose.currentPose != (Object)(object)pose.GetPoseByName("Shock"))
			{
				pose.SetPoseByName("Shock");
			}
			idleLoop.PlayLoop(playing: true, 10f, 10f);
		}
		if (currentState == State.Hurt && (Object)(object)pose.currentPose != (Object)(object)pose.GetPoseByName("Hurt"))
		{
			pose.SetPoseByName("Hurt");
		}
		if (currentState == State.Shock)
		{
			if (Object.op_Implicit((Object)(object)itemTarget))
			{
				LookAtItem();
			}
			if ((Object)(object)pose.currentPose != (Object)(object)pose.GetPoseByName("Shock"))
			{
				pose.SetPoseByName("Shock");
			}
		}
		if (InItemReactionFlow())
		{
			LookAtItemReactTarget();
			idleLoop.PlayLoop(playing: true, 10f, 10f);
			if (currentState == State.ReactPositive)
			{
				if ((Object)(object)pose.currentPose != (Object)(object)pose.GetPoseByName("Idle"))
				{
					pose.SetPoseByName("Idle");
				}
			}
			else if (ItemScanPoseState(currentState) && (Object)(object)pose.currentPose != (Object)(object)pose.GetPoseByName("Shock"))
			{
				pose.SetPoseByName("Shock");
			}
		}
		pose.OverrideBoneLocalRotation(BigSensor.parent, bigSensorMainLocalRotation);
		LineRendererLogic();
		HurtColliderTimer();
		SeeRuckusScanLogic();
		BeamOverridePing();
		ItemReactionBeamOverridePing();
		LineBetweenTwoPointsLogic();
		ItemScanBeamLogic();
		PlayerEyesOverrideLogic();
		ScanLightLogic();
		JudgeChargeLogic();
		GrabLoopLogic();
		BeamOverrideTick();
		BeamFromSensorTick();
		EmojiScreenGlitchLogic();
		ShakeSoundLocalLogic();
		if (currentState == State.NoticeItem || currentState == State.ScanObject || currentState == State.DenyItem)
		{
			BigSensorActive = false;
			BigSensorLerp = 0f;
		}
		else if (BigSensorActive)
		{
			if (BigSensorLerp == 0f)
			{
				bigSensorSound.Play(BigSensor.position);
			}
			BigSensorLerp += BigSensorLerpSpeed * Time.deltaTime;
			if (BigSensorLerp >= 1f)
			{
				BigSensorLerp = 0f;
				BigSensorActive = false;
			}
		}
		BigSensor.localPosition = new Vector3(0f, BigSensorCurve.Evaluate(BigSensorLerp), 0f);
		BigSensor.localEulerAngles = new Vector3(0f, BigSensorCurve.Evaluate(BigSensorLerp) * 500f, 0f);
		if (SmallSensorActive)
		{
			if (SmallSensorLerp == 0f)
			{
				smallSensorSound.Play(SmallSensor.position);
			}
			SmallSensorLerp += SmallSensorLerpSpeed * Time.deltaTime;
			if (SmallSensorLerp >= 1f)
			{
				SmallSensorLerp = 0f;
				SmallSensorActive = false;
			}
		}
		SmallSensor.localPosition = new Vector3(0f, SmallSensorCurve.Evaluate(SmallSensorLerp), 0f);
		SmallSensor.localEulerAngles = new Vector3(0f, SmallSensorCurve.Evaluate(SmallSensorLerp) * 1000f, 0f);
		if (gunBarrelActiveOut)
		{
			if (gunBarrelLerp == 0f)
			{
				moveSmall.Play(gunBarrelBig.position);
			}
			gunBarrelLerp += gunBarrelLerpSpeed * Time.deltaTime;
			if (gunBarrelLerp >= 1f)
			{
				gunBarrelLerp = 1f;
				gunBarrelActiveOut = false;
			}
			gunBarrelBig.localPosition = new Vector3(0f, barrelCurveOut.Evaluate(gunBarrelLerp), 0f);
			gunBarrelSmall.localPosition = new Vector3(0f, barrelCurveOut.Evaluate(gunBarrelLerp), 0f);
		}
		else if (gunBarrelActiveIn)
		{
			if (gunBarrelLerp == 0f)
			{
				moveSmall.Play(gunBarrelBig.position);
			}
			gunBarrelLerp += gunBarrelLerpSpeed * Time.deltaTime;
			if (gunBarrelLerp >= 1f)
			{
				gunBarrelLerp = 1f;
				gunBarrelActiveIn = false;
			}
			gunBarrelBig.localPosition = new Vector3(0f, barrelCurveIn.Evaluate(gunBarrelLerp), 0f);
			gunBarrelSmall.localPosition = new Vector3(0f, barrelCurveIn.Evaluate(gunBarrelLerp), 0f);
			if (!gunBarrelActiveIn)
			{
				gunBarrelLerp = 0f;
			}
		}
		if (VoiceBoxActive && Time.time - VoiceBoxSoundTime > voiceCoolDown)
		{
			PlayLine(Random.Range(0, voiceBoxSoundClips.Count));
			VoiceBoxSoundTime = Time.time;
			VoiceBoxActive = false;
		}
		if (VoiceBoxActiveAngry && Time.time - VoiceBoxSoundTime > voiceCoolDown)
		{
			PlayLine(Random.Range(0, voiceBoxSoundClipsAngry.Count), 1);
			VoiceBoxSoundTime = Time.time;
			VoiceBoxActiveAngry = false;
		}
		if (VoiceBoxActiveSee && voiceBoxSoundClipsSee.Count > 0 && Time.time - VoiceBoxSoundTime > voiceCoolDown)
		{
			PlayLine(Random.Range(0, voiceBoxSoundClipsSee.Count), 2);
			VoiceBoxSoundTime = Time.time;
			VoiceBoxActiveSee = false;
		}
		if (VoiceBoxActiveGrab && voiceBoxSoundClipsGrab.Count > 0 && Time.time - VoiceBoxSoundTime > voiceCoolDown)
		{
			PlayLine(Random.Range(0, voiceBoxSoundClipsGrab.Count), 3);
			VoiceBoxSoundTime = Time.time;
			VoiceBoxActiveGrab = false;
		}
		if (VoiceBoxActiveJudge && voiceBoxSoundClipsJudge.Count > 0 && Time.time - VoiceBoxSoundTime > voiceCoolDown)
		{
			PlayLine(Random.Range(0, voiceBoxSoundClipsJudge.Count), 4);
			VoiceBoxSoundTime = Time.time;
			VoiceBoxActiveJudge = false;
		}
		float voiceBoxSoundClipLoudness = VoiceBoxSoundClipLoudness;
		voiceBoxSoundClipLoudness = Mathf.Log10(voiceBoxSoundClipLoudness * 10f + 1f);
		voiceBoxSoundClipLoudness = Mathf.Lerp(0.8f, 1.2f, Mathf.Clamp01(voiceBoxSoundClipLoudness / 3f));
		VoiceBox.localScale = new Vector3(voiceBoxSoundClipLoudness, voiceBoxSoundClipLoudness, voiceBoxSoundClipLoudness);
		float voiceBoxSoundClipLoudness2 = VoiceBoxSoundClipLoudness;
		voiceBoxSoundClipLoudness2 = Mathf.Log10(voiceBoxSoundClipLoudness2 * 1000f + 1f);
		voiceBoxSoundClipLoudness2 = Mathf.Lerp(0f, -0.05f, Mathf.Clamp01(voiceBoxSoundClipLoudness2 / 3f));
		VoiceBox.localPosition = new Vector3(voiceBoxSoundClipLoudness2, 0f, voiceBoxSoundClipLoudness2);
		if (VoiceBoxSoundClipTimer <= 0f)
		{
			VoiceBoxSoundClipTimer = 0.01f;
			VoiceBoxSoundClipLoudness = 0f;
			if (Object.op_Implicit((Object)(object)voiceBoxSource.clip) && voiceBoxSource.isPlaying)
			{
				voiceBoxSource.clip.GetData(VoiceBoxSoundClipSampleData, voiceBoxSource.timeSamples);
				float[] voiceBoxSoundClipSampleData = VoiceBoxSoundClipSampleData;
				foreach (float num4 in voiceBoxSoundClipSampleData)
				{
					VoiceBoxSoundClipLoudness += Mathf.Abs(num4);
				}
				VoiceBoxSoundClipLoudness /= VoiceBoxSoundClipSampleDataLength;
			}
		}
		else
		{
			VoiceBoxSoundClipTimer -= Time.deltaTime;
		}
		if (flashActive)
		{
			Flash.SetActive(true);
			if (flashTimer == flashLength)
			{
				FlashSound.Play(((Component)this).transform.position);
			}
			if (flashTimer > 0f)
			{
				flashTimer -= Time.deltaTime;
			}
			else
			{
				Flash.SetActive(false);
				flashActive = false;
				flashTimer = flashLength;
			}
		}
		if (shootLightActive)
		{
			Light lightComponent = shootLight.lightComponent;
			lightComponent.intensity -= Time.deltaTime * 20f;
			if (shootLight.lightComponent.intensity <= 0f)
			{
				((Behaviour)shootLight.lightComponent).enabled = false;
				shootLightActive = false;
			}
		}
		if (hitLightActive)
		{
			Light lightComponent2 = hitLight.lightComponent;
			lightComponent2.intensity -= Time.deltaTime * 20f;
			if (hitLight.lightComponent.intensity <= 0f)
			{
				((Behaviour)hitLight.lightComponent).enabled = false;
				hitLightActive = false;
			}
		}
		aimHorizontal.localRotation = SemiFunc.SpringQuaternionGet(rotationSpringY, rotationTargetY);
		aimVertical.localRotation = SemiFunc.SpringQuaternionGet(rotationSpringX, rotationTargetX);
		rotationSpringX.damping = rotationDampening;
		gunCog.localRotation = SemiFunc.SpringQuaternionGet(gunCogSpring, gunCogTarget);
		gunArm.localRotation = SemiFunc.SpringQuaternionGet(gunArmSpring, gunArmTarget);
		gunArmSpring.speed = 20f;
		gunArmSpring.damping = 0.35f;
		float num5 = Quaternion.Angle(prevAimHorizontalRot, aimHorizontal.localRotation) / Time.deltaTime;
		if (num5 > 10f)
		{
			GameDirector.instance.CameraShake.ShakeDistance(num5 * 0.005f, 3f, 8f, ((Component)this).transform.position, 0.2f);
			if (num5 > 75f && moveShakeImpactReady)
			{
				GameDirector.instance.CameraImpact.ShakeDistance(num5 * 0.005f, 3f, 8f, ((Component)this).transform.position, 0.05f);
				moveShakeImpactReady = false;
			}
		}
		else
		{
			moveShakeImpactReady = true;
		}
		float num6 = Quaternion.Angle(prevAimVerticalRot, aimVertical.localRotation) / Time.deltaTime;
		prevAimHorizontalRot = aimHorizontal.localRotation;
		prevAimVerticalRot = aimVertical.localRotation;
		moveLoopHorizontal.PlayLoop(num5 > 1f, 10f, 10f, Mathf.Lerp(0.9f, 1.1f, Mathf.InverseLerp(0f, 60f, num5)));
		moveLoopVertical.PlayLoop(num6 > 1f, 10f, 10f, Mathf.Lerp(0.9f, 1.1f, Mathf.InverseLerp(0f, 60f, num6)));
	}

	private void StateMachine()
	{
		switch (currentState)
		{
		case State.Sleeping:
			StateSleeping();
			break;
		case State.WakeUp:
			StateWakeUp();
			break;
		case State.Observe:
			StateObserve();
			break;
		case State.Flash:
			StateFlash();
			break;
		case State.Shock:
			StateShock();
			break;
		case State.Hurt:
			StateHurt();
			break;
		case State.Aim:
			StateAim();
			break;
		case State.WaitForRuckusPlayer:
			StateWaitForRuckusPlayer();
			break;
		case State.SeeRuckusPlayer:
			StateSeeRuckusPlayer();
			break;
		case State.GrabRuckusPlayer:
			StateGrabRuckusPlayer();
			break;
		case State.JudgeRuckusPlayer:
			StateJudgeRuckusPlayer();
			break;
		case State.Shoot:
			StateShoot();
			break;
		case State.AngryObservation:
			StateAngryObservation();
			break;
		case State.WarnGrabPlayer:
			StateWarnGrabPlayer();
			break;
		case State.WarnTellOff:
			StateWarnTellOff();
			break;
		case State.SeeWarnPlayer:
			StateSeeWarnPlayer();
			break;
		case State.NoticeItem:
			StateNoticeItem();
			break;
		case State.DenyItem:
			StateDenyItem();
			break;
		case State.ScanObject:
			StateScanObject();
			break;
		case State.Verdict:
			StateVerdict();
			break;
		case State.ReactPositive:
			StateReactPositive();
			break;
		case State.ReactNegative:
			StateReactNegative();
			break;
		case State.NegativeGrab:
			StateNegativeGrab();
			break;
		case State.NegativeMeleeGrab:
			StateNegativeMeleeGrab();
			break;
		case State.NegativeMeleeWindup:
			StateNegativeMeleeWindup();
			break;
		case State.NegativeMeleeSwing:
			StateNegativeMeleeSwing();
			break;
		case State.NegativeShakeToss:
			StateNegativeShakeToss();
			break;
		case State.PositiveGrab:
			StatePositiveGrab();
			break;
		case State.PositivePlay:
			StatePositivePlay();
			break;
		case State.GoToSleep:
			break;
		}
	}

	public void OnTriggerEnterLogic(Collider other)
	{
		if (!SemiFunc.IsMasterClientOrSingleplayer() || currentState == State.Sleeping || !other.isTrigger)
		{
			return;
		}
		HurtCollider component = ((Component)other).GetComponent<HurtCollider>();
		if (!Object.op_Implicit((Object)(object)component))
		{
			return;
		}
		PhysGrabObject componentInParent = ((Component)component).GetComponentInParent<PhysGrabObject>();
		if ((!ItemControlState(currentState) || !Object.op_Implicit((Object)(object)componentInParent) || !((Object)(object)componentInParent == (Object)(object)itemReactObject)) && component.enemyDamage > 0 && !InRuckusFlow() && !InWarnFlow())
		{
			if (InItemReactionFlow())
			{
				EndItemReaction();
			}
			UpdateState(State.Hurt);
		}
	}

	private bool InRuckusFlow()
	{
		if (currentState != State.WaitForRuckusPlayer && currentState != State.SeeRuckusPlayer && currentState != State.GrabRuckusPlayer && currentState != State.JudgeRuckusPlayer)
		{
			return currentState == State.Shoot;
		}
		return true;
	}

	private bool InWarnFlow()
	{
		if (currentState != State.SeeWarnPlayer && currentState != State.WarnGrabPlayer)
		{
			return currentState == State.WarnTellOff;
		}
		return true;
	}

	private bool ShopkeeperHoldingPlayer()
	{
		if (currentState != State.GrabRuckusPlayer && currentState != State.JudgeRuckusPlayer && currentState != State.WarnGrabPlayer)
		{
			return currentState == State.WarnTellOff;
		}
		return true;
	}

	private void UpdateState(State _state)
	{
		if (SemiFunc.IsMasterClientOrSingleplayer() && _state != currentState && (!InItemReactionFlow() || !Object.op_Implicit((Object)(object)itemReactObject) || ItemReactionState(_state)))
		{
			OnLeavingStateVisualCleanup(currentState, _state);
			currentState = _state;
			currentStateEnterTime = Time.time;
			currentStateNetworkStartTime = (SemiFunc.IsMultiplayer() ? PhotonNetwork.Time : ((double)Time.time));
			stateImpulse = true;
			stateTimer = 0f;
			ShopKeeperStateSend();
		}
	}

	private void ShopKeeperStateSend()
	{
		//IL_016d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0174: Unknown result type (might be due to invalid IL or missing references)
		//IL_017a: Unknown result type (might be due to invalid IL or missing references)
		//IL_013f: Unknown result type (might be due to invalid IL or missing references)
		if (SemiFunc.IsMasterClientOrSingleplayer())
		{
			int num = ((Object.op_Implicit((Object)(object)playerTarget) && Object.op_Implicit((Object)(object)playerTarget.photonView)) ? playerTarget.photonView.ViewID : (-1));
			int num2 = ((Object.op_Implicit((Object)(object)itemReactObject) && Object.op_Implicit((Object)(object)itemReactObject.photonView)) ? itemReactObject.photonView.ViewID : (-1));
			int num3 = ((Object.op_Implicit((Object)(object)itemReactPlayer) && Object.op_Implicit((Object)(object)itemReactPlayer.photonView)) ? itemReactPlayer.photonView.ViewID : (-1));
			networkPlayerTargetViewID = num;
			networkItemTargetViewID = num2;
			networkItemReactPlayerViewID = num3;
			if (GameManager.Multiplayer())
			{
				PhotonNetwork.RemoveBufferedRPCs(photonView.ViewID, "UpdateStateRPC", (int[])null);
				photonView.RPC("UpdateStateRPC", (RpcTarget)3, new object[8] { currentState, num, num2, num3, itemScanSeed, currentStateNetworkStartTime, itemDiscountAttempts, itemScanAim });
			}
			else
			{
				UpdateStateRPC(currentState, num, num2, num3, itemScanSeed, currentStateNetworkStartTime, itemDiscountAttempts, itemScanAim);
			}
		}
	}

	private void NetworkTargetsResolveTick()
	{
		if (!SemiFunc.IsMultiplayer())
		{
			return;
		}
		networkTargetRetryTimer -= Time.deltaTime;
		if (networkTargetRetryTimer > 0f)
		{
			return;
		}
		networkTargetRetryTimer = 0.25f;
		if (networkPlayerTargetViewID <= 0)
		{
			playerTarget = null;
		}
		if (networkItemReactPlayerViewID <= 0)
		{
			itemReactPlayer = null;
		}
		if (networkItemTargetViewID <= 0)
		{
			itemReactObject = null;
			itemTarget = null;
		}
		if (networkPlayerTargetViewID > 0 && (!Object.op_Implicit((Object)(object)playerTarget) || !Object.op_Implicit((Object)(object)playerTarget.photonView) || playerTarget.photonView.ViewID != networkPlayerTargetViewID))
		{
			foreach (PlayerAvatar item in SemiFunc.PlayerGetList())
			{
				if (Object.op_Implicit((Object)(object)item) && Object.op_Implicit((Object)(object)item.photonView) && item.photonView.ViewID == networkPlayerTargetViewID)
				{
					playerTarget = item;
					break;
				}
			}
		}
		if (networkItemReactPlayerViewID > 0 && (!Object.op_Implicit((Object)(object)itemReactPlayer) || !Object.op_Implicit((Object)(object)itemReactPlayer.photonView) || itemReactPlayer.photonView.ViewID != networkItemReactPlayerViewID))
		{
			foreach (PlayerAvatar item2 in SemiFunc.PlayerGetList())
			{
				if (Object.op_Implicit((Object)(object)item2) && Object.op_Implicit((Object)(object)item2.photonView) && item2.photonView.ViewID == networkItemReactPlayerViewID)
				{
					itemReactPlayer = item2;
					break;
				}
			}
		}
		if (networkItemTargetViewID <= 0 || (Object.op_Implicit((Object)(object)itemReactObject) && Object.op_Implicit((Object)(object)itemReactObject.photonView) && itemReactObject.photonView.ViewID == networkItemTargetViewID))
		{
			return;
		}
		PhotonView val = PhotonView.Find(networkItemTargetViewID);
		if (Object.op_Implicit((Object)(object)val))
		{
			PhysGrabObject physGrabObject = ((Component)val).GetComponent<PhysGrabObject>();
			if (!Object.op_Implicit((Object)(object)physGrabObject))
			{
				physGrabObject = ((Component)val).GetComponentInParent<PhysGrabObject>();
			}
			if (!Object.op_Implicit((Object)(object)physGrabObject))
			{
				physGrabObject = ((Component)val).GetComponentInChildren<PhysGrabObject>();
			}
			if (Object.op_Implicit((Object)(object)physGrabObject))
			{
				itemReactObject = physGrabObject;
				itemTarget = ((Component)physGrabObject).transform;
			}
		}
	}

	private void OnLeavingStateVisualCleanup(State _from, State _to)
	{
		//IL_0097: Unknown result type (might be due to invalid IL or missing references)
		//IL_009c: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f9: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ff: Unknown result type (might be due to invalid IL or missing references)
		if (_from == State.DenyItem)
		{
			itemDenyBeamTimer = 0f;
			itemDenyBeamTarget = null;
		}
		bool num = _from == State.GrabRuckusPlayer || _from == State.JudgeRuckusPlayer || _from == State.WarnGrabPlayer || _from == State.WarnTellOff;
		bool flag = _to == State.GrabRuckusPlayer || _to == State.JudgeRuckusPlayer || _to == State.WarnGrabPlayer || _to == State.WarnTellOff;
		if (num && !flag)
		{
			ForceClearGrabBeamOverride(_to != State.Shoot);
		}
		bool num2 = _from == State.SeeRuckusPlayer || _from == State.SeeWarnPlayer || _from == State.WaitForRuckusPlayer;
		bool flag2 = flag || _to == State.SeeRuckusPlayer || _to == State.SeeWarnPlayer || _to == State.WaitForRuckusPlayer;
		if (num2 && !flag2)
		{
			scanBeamOverrideTimer = 0f;
			scanBeamOverrideActive = false;
			scanBeamOverrideTarget = Vector3.zero;
		}
		if (_from == State.WarnTellOff && _to != State.WarnTellOff)
		{
			warnTellOffOnEmojiScreen = false;
			warnTellOffAimFrozen = false;
		}
		if ((_from == State.WarnTellOff || _from == State.NegativeShakeToss) && shakeSoundActive && SemiFunc.IsMasterClientOrSingleplayer())
		{
			if (SemiFunc.IsMultiplayer())
			{
				photonView.RPC("ShakeSoundEndRPC", (RpcTarget)0, Array.Empty<object>());
			}
			else
			{
				ShakeSoundEndRPC();
			}
		}
		if (_from == State.AngryObservation && _to != State.AngryObservation)
		{
			VoiceBoxActiveAngry = false;
		}
		bool num3 = _from == State.GrabRuckusPlayer || _from == State.JudgeRuckusPlayer || _from == State.WarnTellOff;
		bool flag3 = _to == State.GrabRuckusPlayer || _to == State.JudgeRuckusPlayer || _to == State.WarnTellOff || _to == State.Shoot;
		if (num3 && !flag3)
		{
			judgeCharge = 0f;
			judgeReleaseActive = false;
			judgeReleaseTimer = 0f;
			grabReached = false;
			grabReachTimer = 0f;
		}
	}

	private void StateSleeping()
	{
	}

	private void StateWakeUp()
	{
		if (stateImpulse)
		{
			stateImpulse = false;
			stateTimer = 1f;
		}
		stateTimer -= Time.deltaTime;
		if (stateTimer <= 0f)
		{
			UpdateState(State.Observe);
		}
	}

	private void StateObserve()
	{
		if (stateImpulse)
		{
			stateImpulse = false;
			stateTimer = 5f;
			VoiceBoxActive = true;
			IdleScan();
			ShowNewEmoji(idleEmoji);
			if (skipPendingRuckusOnNextObserve)
			{
				skipPendingRuckusOnNextObserve = false;
			}
			else
			{
				CheckPendingRuckusActions();
				if (currentState != State.Observe)
				{
					return;
				}
			}
		}
		stateTimer -= Time.deltaTime;
		if (stateTimer <= 0f)
		{
			IdleScan();
			stateTimer = 5f;
			if (Random.Range(0, 3) == 0)
			{
				UpdateState(State.Flash);
			}
		}
	}

	private void StateAngryObservation()
	{
		//IL_007d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0083: Unknown result type (might be due to invalid IL or missing references)
		//IL_008c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0092: Unknown result type (might be due to invalid IL or missing references)
		//IL_012e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0134: Unknown result type (might be due to invalid IL or missing references)
		//IL_011d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0123: Unknown result type (might be due to invalid IL or missing references)
		if (stateImpulse)
		{
			stateImpulse = false;
			stateTimer = Random.Range(1f, 3f);
			VoiceBoxActiveAngry = true;
			ShowNewEmoji(angryEmoji);
			angryObservationSensorTimer = 0f;
			if (SemiFunc.IsMultiplayer())
			{
				photonView.RPC("SmallSensorBreakerRPC", (RpcTarget)0, Array.Empty<object>());
				photonView.RPC("BigSensorBreakerRPC", (RpcTarget)0, Array.Empty<object>());
			}
			else
			{
				SmallSensorBreakerRPC();
				BigSensorBreakerRPC();
			}
		}
		if (!PlayerTargetValid())
		{
			UpdateState(State.Observe);
			return;
		}
		angryObservationSensorTimer -= Time.deltaTime;
		if (angryObservationSensorTimer <= 0f)
		{
			angryObservationSensorTimer = 0.4f;
			bool flag = Random.Range(0, 2) == 0;
			if (SemiFunc.IsMultiplayer())
			{
				if (flag)
				{
					photonView.RPC("BigSensorBreakerRPC", (RpcTarget)0, Array.Empty<object>());
				}
				else
				{
					photonView.RPC("SmallSensorBreakerRPC", (RpcTarget)0, Array.Empty<object>());
				}
			}
			else if (flag)
			{
				BigSensorBreakerRPC();
			}
			else
			{
				SmallSensorBreakerRPC();
			}
		}
		stateTimer -= Time.deltaTime;
		if (stateTimer <= 0f)
		{
			UpdateState(State.Observe);
		}
	}

	private void TriggerAngryObservation(PlayerAvatar _offender)
	{
		if (SemiFunc.IsMasterClientOrSingleplayer() && Object.op_Implicit((Object)(object)_offender) && currentState == State.Observe)
		{
			playerTarget = _offender;
			prevPlayerTarget = _offender;
			if (SemiFunc.IsMultiplayer() && Object.op_Implicit((Object)(object)_offender.photonView))
			{
				photonView.RPC("UpdatePlayerTargetRPC", (RpcTarget)1, new object[1] { _offender.photonView.ViewID });
			}
			UpdateState(State.AngryObservation);
		}
	}

	public void WarnPlayer(PlayerAvatar _player)
	{
		if (SemiFunc.IsMasterClientOrSingleplayer() && Object.op_Implicit((Object)(object)_player) && !InItemReactionFlow() && currentState != State.Sleeping && currentState != State.WakeUp && (!((Object)(object)playerTarget == (Object)(object)_player) || !InWarnFlow()) && !InRuckusFlow())
		{
			if ((currentState == State.WarnGrabPlayer || currentState == State.WarnTellOff) && PlayerTargetValid() && (Object)(object)playerTarget != (Object)(object)_player)
			{
				ThrowCurrentTargetAway();
			}
			playerTarget = _player;
			prevPlayerTarget = _player;
			if (SemiFunc.IsMultiplayer() && Object.op_Implicit((Object)(object)_player.photonView))
			{
				photonView.RPC("UpdatePlayerTargetRPC", (RpcTarget)1, new object[1] { _player.photonView.ViewID });
			}
			UpdateState(State.SeeWarnPlayer);
		}
	}

	private void StateSeeWarnPlayer()
	{
		if (stateImpulse)
		{
			stateImpulse = false;
			stateTimer = 1.5f;
			VoiceBoxActiveSee = true;
			ShowNewEmoji(noticeEmoji);
		}
		if (!PlayerTargetValid())
		{
			UpdateState(State.Observe);
			return;
		}
		stateTimer -= Time.deltaTime;
		if (stateTimer <= 0f)
		{
			UpdateState(State.Observe);
		}
	}

	private void StateWarnGrabPlayer()
	{
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0064: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f9: Unknown result type (might be due to invalid IL or missing references)
		//IL_0255: Unknown result type (might be due to invalid IL or missing references)
		//IL_0202: Unknown result type (might be due to invalid IL or missing references)
		//IL_01f5: Unknown result type (might be due to invalid IL or missing references)
		//IL_00cc: Unknown result type (might be due to invalid IL or missing references)
		//IL_0271: Unknown result type (might be due to invalid IL or missing references)
		//IL_0272: Unknown result type (might be due to invalid IL or missing references)
		//IL_0279: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e8: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ea: Unknown result type (might be due to invalid IL or missing references)
		//IL_026c: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e3: Unknown result type (might be due to invalid IL or missing references)
		//IL_02b3: Unknown result type (might be due to invalid IL or missing references)
		//IL_0195: Unknown result type (might be due to invalid IL or missing references)
		//IL_01b1: Unknown result type (might be due to invalid IL or missing references)
		//IL_01b8: Unknown result type (might be due to invalid IL or missing references)
		//IL_01bf: Unknown result type (might be due to invalid IL or missing references)
		//IL_01ac: Unknown result type (might be due to invalid IL or missing references)
		if (stateImpulse)
		{
			stateImpulse = false;
			stateTimer = 12f;
			grabReachTimer = 0f;
			grabReached = false;
			stuckActive = false;
			stuckPhaseDislodge = false;
			stuckPhaseTimer = 0f;
			stuckNotClosingTimer = 0f;
			stuckPrevDistance = float.MaxValue;
			stuckPushDirection = Vector3.zero;
			VoiceBoxActiveAngry = true;
			grabBeamReleaseSoundPlayed = false;
			ShowNewEmoji(noticeEmoji);
			if (PlayerTargetValid())
			{
				Vector3 pos = ((playerTarget.isTumbling && Object.op_Implicit((Object)(object)playerTarget.tumble) && Object.op_Implicit((Object)(object)playerTarget.tumble.rb)) ? playerTarget.tumble.rb.position : ((Component)playerTarget).transform.position);
				PlayGrabSound(pos);
			}
			else
			{
				PlayGrabSound(gunTipBigTransform.position);
			}
			if (PlayerTargetValid() && Object.op_Implicit((Object)(object)playerTarget.tumble) && !playerTarget.isTumbling)
			{
				playerTarget.tumble.TumbleRequest(_isTumbling: true, _playerInput: false);
			}
			if (PlayerTargetValid() && Object.op_Implicit((Object)(object)playerPoint))
			{
				Vector3 val = ((playerTarget.isTumbling && Object.op_Implicit((Object)(object)playerTarget.tumble) && Object.op_Implicit((Object)(object)playerTarget.tumble.rb)) ? playerTarget.tumble.rb.position : ((Component)playerTarget).transform.position);
				grabInitialDistance = Mathf.Max(0.01f, Vector3.Distance(val, playerPoint.position));
			}
			ForceReleasePlayerTargetGrabs();
		}
		if (!PlayerTargetValid())
		{
			PlayReleaseSoundOnce(Object.op_Implicit((Object)(object)playerPoint) ? playerPoint.position : gunTipBigTransform.position);
			UpdateState(State.Observe);
			return;
		}
		Vector3 val2 = ((playerTarget.isTumbling && Object.op_Implicit((Object)(object)playerTarget.tumble) && Object.op_Implicit((Object)(object)playerTarget.tumble.rb)) ? playerTarget.tumble.rb.position : ((Component)playerTarget).transform.position);
		if (Vector3.Distance(val2, playerPoint.position) <= 1f)
		{
			UpdateState(State.WarnTellOff);
			return;
		}
		stateTimer -= Time.deltaTime;
		if (stateTimer <= 0f)
		{
			PlayReleaseSoundOnce(val2);
			UpdateState(State.Observe);
		}
	}

	private void StateWarnTellOff()
	{
		//IL_0285: Unknown result type (might be due to invalid IL or missing references)
		//IL_0278: Unknown result type (might be due to invalid IL or missing references)
		//IL_0179: Unknown result type (might be due to invalid IL or missing references)
		//IL_017f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0399: Unknown result type (might be due to invalid IL or missing references)
		//IL_039f: Unknown result type (might be due to invalid IL or missing references)
		//IL_01d6: Unknown result type (might be due to invalid IL or missing references)
		//IL_01dc: Unknown result type (might be due to invalid IL or missing references)
		//IL_01e7: Unknown result type (might be due to invalid IL or missing references)
		//IL_01ed: Unknown result type (might be due to invalid IL or missing references)
		//IL_0493: Unknown result type (might be due to invalid IL or missing references)
		//IL_0499: Unknown result type (might be due to invalid IL or missing references)
		//IL_04a3: Unknown result type (might be due to invalid IL or missing references)
		//IL_04a9: Unknown result type (might be due to invalid IL or missing references)
		//IL_04b4: Unknown result type (might be due to invalid IL or missing references)
		//IL_04ba: Unknown result type (might be due to invalid IL or missing references)
		//IL_0350: Unknown result type (might be due to invalid IL or missing references)
		//IL_0356: Unknown result type (might be due to invalid IL or missing references)
		//IL_03f1: Unknown result type (might be due to invalid IL or missing references)
		//IL_03f7: Unknown result type (might be due to invalid IL or missing references)
		//IL_0401: Unknown result type (might be due to invalid IL or missing references)
		//IL_0407: Unknown result type (might be due to invalid IL or missing references)
		//IL_023f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0245: Unknown result type (might be due to invalid IL or missing references)
		//IL_024f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0255: Unknown result type (might be due to invalid IL or missing references)
		//IL_05d6: Unknown result type (might be due to invalid IL or missing references)
		//IL_057a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0580: Unknown result type (might be due to invalid IL or missing references)
		//IL_0568: Unknown result type (might be due to invalid IL or missing references)
		//IL_056e: Unknown result type (might be due to invalid IL or missing references)
		//IL_05db: Unknown result type (might be due to invalid IL or missing references)
		//IL_05de: Unknown result type (might be due to invalid IL or missing references)
		//IL_05ce: Unknown result type (might be due to invalid IL or missing references)
		//IL_05c1: Unknown result type (might be due to invalid IL or missing references)
		if (stateImpulse)
		{
			stateImpulse = false;
			warnTellOffStareBeforeDuration = Random.Range(1f, 2f);
			warnTellOffShakeDuration = Random.Range(1f, 3f);
			warnTellOffStareAfterDuration = Random.Range(1f, 2f);
			warnTellOffLectureDuration = Random.Range(1f, 2f);
			warnTellOffBonkActive = Random.value < 0.5f;
			if (warnTellOffBonkActive)
			{
				warnTellOffBonkPatternIndex = Random.Range(0, warnTellOffBonkPatterns.Length);
				warnTellOffBonkDuration = warnTellOffBonkPatternDurations[warnTellOffBonkPatternIndex];
			}
			else
			{
				warnTellOffBonkPatternIndex = 0;
				warnTellOffBonkDuration = 0f;
			}
			warnTellOffBonksApplied = 0;
			warnTellOffBonkEntered = false;
			warnTellOffShakeReleaseEnabled = Random.value < 0.3f;
			warnTellOffShakeReleaseFired = false;
			warnTellOffShakeReleaseTime = (warnTellOffShakeReleaseEnabled ? Random.Range(0.5f, Mathf.Max(0.6f, warnTellOffShakeDuration - 0.1f)) : (-1f));
			stateTimer = warnTellOffStareBeforeDuration + warnTellOffShakeDuration + warnTellOffStareAfterDuration + warnTellOffLectureDuration + warnTellOffBonkDuration + 0.18f + 0.22f;
			warnTellOffSensorTimer = 0f;
			warnTellOffThrowApplied = false;
			warnTellOffShakeEntered = false;
			warnTellOffStareAfterEntered = false;
			warnTellOffLectureEntered = false;
			warnTellOffBonkSoundsPlayed = 0;
			FreezeAim(rotationTargetX, rotationTargetY);
			if (SemiFunc.IsMultiplayer())
			{
				photonView.RPC("WarnTellOffOnEmojiScreenRPC", (RpcTarget)0, new object[1] { false });
				photonView.RPC("WarnTellOffAimFrozenRPC", (RpcTarget)0, new object[1] { true });
			}
			else
			{
				WarnTellOffOnEmojiScreenRPC(_on: false);
				WarnTellOffAimFrozenRPC(_frozen: true);
			}
			VoiceBoxActiveAngry = true;
			ShowNewEmoji(angryEmoji);
			if (SemiFunc.IsMultiplayer())
			{
				photonView.RPC("SmallSensorBreakerRPC", (RpcTarget)0, Array.Empty<object>());
				photonView.RPC("BigSensorBreakerRPC", (RpcTarget)0, Array.Empty<object>());
			}
			else
			{
				SmallSensorBreakerRPC();
				BigSensorBreakerRPC();
			}
		}
		if (!PlayerTargetValid())
		{
			PlayReleaseSoundOnce(Object.op_Implicit((Object)(object)playerPoint) ? playerPoint.position : gunTipBigTransform.position);
			UpdateState(State.Observe);
			return;
		}
		float num = warnTellOffStareBeforeDuration;
		float num2 = num + warnTellOffShakeDuration;
		float num3 = num2 + warnTellOffStareAfterDuration;
		float num4 = num3 + warnTellOffLectureDuration;
		float num5 = num4 + warnTellOffBonkDuration + 0.18f + 0.22f - stateTimer;
		if (!warnTellOffShakeEntered && num5 >= num)
		{
			warnTellOffShakeEntered = true;
			warnTellOffShakePrevY = 0f;
			if (PlayerTargetValid() && Object.op_Implicit((Object)(object)playerTarget.photonView))
			{
				int viewID = playerTarget.photonView.ViewID;
				if (SemiFunc.IsMultiplayer())
				{
					photonView.RPC("ShakeSoundStartRPC", (RpcTarget)0, new object[1] { viewID });
				}
				else
				{
					ShakeSoundStartRPC(viewID);
				}
			}
		}
		if (!warnTellOffStareAfterEntered && num5 >= num2)
		{
			warnTellOffStareAfterEntered = true;
			if (SemiFunc.IsMultiplayer())
			{
				photonView.RPC("ShakeSoundEndRPC", (RpcTarget)0, Array.Empty<object>());
			}
			else
			{
				ShakeSoundEndRPC();
			}
			VoiceBoxActiveAngry = true;
			ShowNewEmoji(angryEmoji);
			if (SemiFunc.IsMultiplayer())
			{
				photonView.RPC("SmallSensorBreakerRPC", (RpcTarget)0, Array.Empty<object>());
				photonView.RPC("BigSensorBreakerRPC", (RpcTarget)0, Array.Empty<object>());
			}
			else
			{
				SmallSensorBreakerRPC();
				BigSensorBreakerRPC();
			}
		}
		if (!warnTellOffLectureEntered && num5 >= num3)
		{
			warnTellOffLectureEntered = true;
			VoiceBoxActiveAngry = true;
			ShowNewEmoji(veryAngryEmoji);
			if (SemiFunc.IsMultiplayer())
			{
				photonView.RPC("SmallSensorBreakerRPC", (RpcTarget)0, Array.Empty<object>());
				photonView.RPC("BigSensorBreakerRPC", (RpcTarget)0, Array.Empty<object>());
				photonView.RPC("WarnTellOffOnEmojiScreenRPC", (RpcTarget)0, new object[1] { true });
			}
			else
			{
				SmallSensorBreakerRPC();
				BigSensorBreakerRPC();
				WarnTellOffOnEmojiScreenRPC(_on: true);
			}
		}
		if (warnTellOffBonkActive && !warnTellOffBonkEntered && num5 >= num4)
		{
			warnTellOffBonkEntered = true;
			VoiceBoxActiveAngry = true;
			ShowNewEmoji(veryAngryEmoji);
		}
		warnTellOffSensorTimer -= Time.deltaTime;
		if (warnTellOffSensorTimer <= 0f)
		{
			warnTellOffSensorTimer = 0.3f;
			bool flag = Random.Range(0, 2) == 0;
			if (SemiFunc.IsMultiplayer())
			{
				if (flag)
				{
					photonView.RPC("BigSensorBreakerRPC", (RpcTarget)0, Array.Empty<object>());
				}
				else
				{
					photonView.RPC("SmallSensorBreakerRPC", (RpcTarget)0, Array.Empty<object>());
				}
			}
			else if (flag)
			{
				BigSensorBreakerRPC();
			}
			else
			{
				SmallSensorBreakerRPC();
			}
		}
		stateTimer -= Time.deltaTime;
		if (stateTimer <= 0f)
		{
			Vector3 pos;
			if (PlayerTargetValid())
			{
				pos = PlayerTargetCenterPos();
			}
			else
			{
				pos = (Object.op_Implicit((Object)(object)playerPoint) ? playerPoint.position : gunTipBigTransform.position);
			}
			PlayReleaseSoundOnce(pos);
			UpdateState(State.Observe);
		}
	}

	private void StateFlash()
	{
		//IL_0055: Unknown result type (might be due to invalid IL or missing references)
		//IL_0065: Unknown result type (might be due to invalid IL or missing references)
		//IL_00bf: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c5: Unknown result type (might be due to invalid IL or missing references)
		if (stateImpulse)
		{
			stateImpulse = false;
			stateTimer = 10f;
			flashDelay = flashDelayLength;
			NearestPlayerAsTarget();
		}
		if (SemiFunc.PerSecond(1f, (Object)(object)this))
		{
			NearestPlayerAsTarget();
		}
		if (Object.op_Implicit((Object)(object)playerTarget) && Vector3.Distance(((Component)this).transform.position, ((Component)playerTarget).transform.position) < 6f)
		{
			flashDelay -= Time.deltaTime;
			if (flashDelay <= 0f && !flashActive)
			{
				if (SemiFunc.IsMultiplayer())
				{
					photonView.RPC("FlashRPC", (RpcTarget)0, Array.Empty<object>());
				}
				else
				{
					FlashRPC();
				}
				flashDelay = flashDelayLength;
				stateTimer = flashLength + 1f;
			}
		}
		stateTimer -= Time.deltaTime;
		if (stateTimer <= 0f)
		{
			UpdateState(State.Observe);
		}
	}

	private void StateShock()
	{
		//IL_0062: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		if (stateImpulse)
		{
			stateImpulse = false;
			stateTimer = 0.5f;
			VoiceBoxActiveAngry = true;
		}
		stateTimer -= Time.deltaTime;
		if (stateTimer <= 0f)
		{
			if (SemiFunc.IsMultiplayer())
			{
				photonView.RPC("InstantiateShockWaveRPC", (RpcTarget)0, Array.Empty<object>());
			}
			else
			{
				InstantiateShockWaveRPC();
			}
			UpdateState(State.Flash);
		}
	}

	private void StateHurt()
	{
		if (stateImpulse)
		{
			stateImpulse = false;
			stateTimer = 0.5f;
			VoiceBoxActiveAngry = true;
			ShowNewEmoji(angryEmoji);
		}
		stateTimer -= Time.deltaTime;
		if (stateTimer <= 0f)
		{
			UpdateState(State.Observe);
		}
	}

	private void StateAim()
	{
		if (stateImpulse)
		{
			if (!ruckusTarget)
			{
				NearestPlayerAsTarget();
			}
			ruckusTarget = false;
			stateImpulse = false;
			stateTimer = 1f;
			ShowNewEmoji(noticeEmoji);
		}
		if (!PlayerTargetValid())
		{
			UpdateState(State.Observe);
			return;
		}
		stateTimer -= Time.deltaTime;
		if (stateTimer <= 0f)
		{
			UpdateState(State.Shoot);
		}
	}

	private void StateWaitForRuckusPlayer()
	{
		//IL_0050: Unknown result type (might be due to invalid IL or missing references)
		//IL_0060: Unknown result type (might be due to invalid IL or missing references)
		if (stateImpulse)
		{
			stateImpulse = false;
			stateTimer = ruckusWaitDuration;
			VoiceBoxActiveSee = true;
			ShowNewEmoji(noticeEmoji);
		}
		if (!PlayerTargetValid())
		{
			ResolveRuckusPunishmentFailed(playerTarget);
			UpdateState(State.Observe);
			return;
		}
		if (Vector3.Distance(((Component)this).transform.position, ((Component)playerTarget).transform.position) <= ruckusWaitDistance)
		{
			UpdateState(State.SeeRuckusPlayer);
			return;
		}
		stateTimer -= Time.deltaTime;
		if (stateTimer <= 0f)
		{
			ResolveRuckusPunishmentFailed(playerTarget);
			UpdateState(State.Observe);
		}
	}

	private void StateSeeRuckusPlayer()
	{
		if (stateImpulse)
		{
			stateImpulse = false;
			stateTimer = 3f;
			VoiceBoxActiveSee = true;
			ShowNewEmoji(noticeEmoji);
		}
		if (!PlayerTargetValid())
		{
			ResolveRuckusPunishmentFailed(playerTarget);
			UpdateState(State.Observe);
			return;
		}
		stateTimer -= Time.deltaTime;
		if (stateTimer <= 0f)
		{
			ResolveRuckusPunishmentFailed(playerTarget);
			UpdateState(State.Observe);
		}
	}

	private void SeeRuckusScanLogic()
	{
		//IL_0083: Unknown result type (might be due to invalid IL or missing references)
		//IL_0088: Unknown result type (might be due to invalid IL or missing references)
		//IL_008f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0094: Unknown result type (might be due to invalid IL or missing references)
		//IL_016c: Unknown result type (might be due to invalid IL or missing references)
		//IL_016d: Unknown result type (might be due to invalid IL or missing references)
		//IL_016e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0173: Unknown result type (might be due to invalid IL or missing references)
		//IL_017c: Unknown result type (might be due to invalid IL or missing references)
		//IL_017f: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a1: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a8: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ad: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b2: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b6: Unknown result type (might be due to invalid IL or missing references)
		//IL_00bb: Unknown result type (might be due to invalid IL or missing references)
		//IL_00bd: Unknown result type (might be due to invalid IL or missing references)
		//IL_00bf: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c4: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c9: Unknown result type (might be due to invalid IL or missing references)
		//IL_00cd: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d2: Unknown result type (might be due to invalid IL or missing references)
		//IL_01af: Unknown result type (might be due to invalid IL or missing references)
		//IL_01a8: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f9: Unknown result type (might be due to invalid IL or missing references)
		//IL_00fb: Unknown result type (might be due to invalid IL or missing references)
		//IL_00fd: Unknown result type (might be due to invalid IL or missing references)
		//IL_0102: Unknown result type (might be due to invalid IL or missing references)
		//IL_0106: Unknown result type (might be due to invalid IL or missing references)
		//IL_010b: Unknown result type (might be due to invalid IL or missing references)
		//IL_012f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0130: Unknown result type (might be due to invalid IL or missing references)
		//IL_0139: Unknown result type (might be due to invalid IL or missing references)
		//IL_013e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0147: Unknown result type (might be due to invalid IL or missing references)
		//IL_014c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0153: Unknown result type (might be due to invalid IL or missing references)
		//IL_0158: Unknown result type (might be due to invalid IL or missing references)
		//IL_015d: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e2: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e4: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e9: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ee: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f2: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f7: Unknown result type (might be due to invalid IL or missing references)
		//IL_01b0: Unknown result type (might be due to invalid IL or missing references)
		//IL_01b3: Unknown result type (might be due to invalid IL or missing references)
		//IL_01b5: Unknown result type (might be due to invalid IL or missing references)
		//IL_01c0: Unknown result type (might be due to invalid IL or missing references)
		if ((currentState != State.SeeRuckusPlayer && currentState != State.SeeWarnPlayer) || !PlayerTargetValid() || !Object.op_Implicit((Object)(object)playerTarget.PlayerVisionTarget) || !Object.op_Implicit((Object)(object)playerTarget.PlayerVisionTarget.VisionTransform))
		{
			return;
		}
		seeRayTimer -= Time.deltaTime;
		if (seeRayTimer > 0f)
		{
			return;
		}
		seeRayTimer = 0.1f;
		Vector3 position = playerTarget.PlayerVisionTarget.VisionTransform.position;
		Vector3 val = gunTipBigTransform.position;
		if (seeRayIndex > 0)
		{
			Vector3 val2 = position - gunTipBigTransform.position;
			Vector3 normalized = val2.normalized;
			val2 = Vector3.Cross(normalized, Vector3.up);
			Vector3 normalized2 = val2.normalized;
			if (normalized2.sqrMagnitude < 0.001f)
			{
				val2 = Vector3.Cross(normalized, Vector3.right);
				normalized2 = val2.normalized;
			}
			val2 = Vector3.Cross(normalized2, normalized);
			Vector3 normalized3 = val2.normalized;
			float num = Random.Range(0f, MathF.PI * 2f);
			float num2 = Random.Range(0f, 2f);
			val += (normalized2 * Mathf.Cos(num) + normalized3 * Mathf.Sin(num)) * num2;
		}
		seeRayIndex++;
		Vector3 val3 = position - val;
		float magnitude = val3.magnitude;
		RaycastHit val4 = default;
		bool flag = !Physics.Raycast(val, val3.normalized, ref val4, magnitude, LayerMask.GetMask(new string[1] { "Default" }), (QueryTriggerInteraction)1);
		Vector3 position2 = (scanLightAimTarget = (flag ? position : val4.point));
		scanSound.Play(position2);
		if (Object.op_Implicit((Object)(object)lineBetweenTwoPoints))
		{
			lineBetweenTwoPoints.TriggerPointSwitch();
		}
		if (flag && SemiFunc.IsMasterClientOrSingleplayer())
		{
			UpdateState((currentState == State.SeeWarnPlayer) ? State.WarnGrabPlayer : State.GrabRuckusPlayer);
		}
	}

	private void StateGrabRuckusPlayer()
	{
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0064: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f9: Unknown result type (might be due to invalid IL or missing references)
		//IL_0261: Unknown result type (might be due to invalid IL or missing references)
		//IL_0202: Unknown result type (might be due to invalid IL or missing references)
		//IL_01f5: Unknown result type (might be due to invalid IL or missing references)
		//IL_00cc: Unknown result type (might be due to invalid IL or missing references)
		//IL_027d: Unknown result type (might be due to invalid IL or missing references)
		//IL_027e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0285: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e8: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ea: Unknown result type (might be due to invalid IL or missing references)
		//IL_0278: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e3: Unknown result type (might be due to invalid IL or missing references)
		//IL_02a7: Unknown result type (might be due to invalid IL or missing references)
		//IL_0371: Unknown result type (might be due to invalid IL or missing references)
		//IL_02d3: Unknown result type (might be due to invalid IL or missing references)
		//IL_02d8: Unknown result type (might be due to invalid IL or missing references)
		//IL_02db: Unknown result type (might be due to invalid IL or missing references)
		//IL_02de: Unknown result type (might be due to invalid IL or missing references)
		//IL_0195: Unknown result type (might be due to invalid IL or missing references)
		//IL_030a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0310: Unknown result type (might be due to invalid IL or missing references)
		//IL_01b1: Unknown result type (might be due to invalid IL or missing references)
		//IL_01b8: Unknown result type (might be due to invalid IL or missing references)
		//IL_01bf: Unknown result type (might be due to invalid IL or missing references)
		//IL_01ac: Unknown result type (might be due to invalid IL or missing references)
		if (stateImpulse)
		{
			stateImpulse = false;
			stateTimer = 12f;
			grabReachTimer = 0f;
			grabReached = false;
			stuckActive = false;
			stuckPhaseDislodge = false;
			stuckPhaseTimer = 0f;
			stuckNotClosingTimer = 0f;
			stuckPrevDistance = float.MaxValue;
			stuckPushDirection = Vector3.zero;
			VoiceBoxActiveGrab = true;
			grabBeamReleaseSoundPlayed = false;
			ShowNewEmoji(angryEmoji);
			if (PlayerTargetValid())
			{
				Vector3 pos = ((playerTarget.isTumbling && Object.op_Implicit((Object)(object)playerTarget.tumble) && Object.op_Implicit((Object)(object)playerTarget.tumble.rb)) ? playerTarget.tumble.rb.position : ((Component)playerTarget).transform.position);
				PlayGrabSound(pos);
			}
			else
			{
				PlayGrabSound(gunTipBigTransform.position);
			}
			if (PlayerTargetValid() && Object.op_Implicit((Object)(object)playerTarget.tumble) && !playerTarget.isTumbling)
			{
				playerTarget.tumble.TumbleRequest(_isTumbling: true, _playerInput: false);
			}
			if (PlayerTargetValid() && Object.op_Implicit((Object)(object)playerPoint))
			{
				Vector3 val = ((playerTarget.isTumbling && Object.op_Implicit((Object)(object)playerTarget.tumble) && Object.op_Implicit((Object)(object)playerTarget.tumble.rb)) ? playerTarget.tumble.rb.position : ((Component)playerTarget).transform.position);
				grabInitialDistance = Mathf.Max(0.01f, Vector3.Distance(val, playerPoint.position));
			}
			ForceReleasePlayerTargetGrabs();
		}
		if (!PlayerTargetValid())
		{
			PlayReleaseSoundOnce(Object.op_Implicit((Object)(object)playerPoint) ? playerPoint.position : gunTipBigTransform.position);
			ResolveRuckusPunishmentFailed(playerTarget);
			UpdateState(State.Observe);
			return;
		}
		Vector3 val2 = ((playerTarget.isTumbling && Object.op_Implicit((Object)(object)playerTarget.tumble) && Object.op_Implicit((Object)(object)playerTarget.tumble.rb)) ? playerTarget.tumble.rb.position : ((Component)playerTarget).transform.position);
		if (Vector3.Distance(val2, playerPoint.position) <= 1f)
		{
			if (!grabReached)
			{
				float num = rotationTargetX.eulerAngles.x;
				if (num > 180f)
				{
					num -= 360f;
				}
				Quaternion aimX = Quaternion.Euler(num + 20f, 0f, 0f);
				FreezeAim(aimX, rotationTargetY);
				if (SemiFunc.IsMultiplayer())
				{
					photonView.RPC("BigSensorBreakerRPC", (RpcTarget)0, Array.Empty<object>());
				}
				else
				{
					BigSensorBreakerRPC();
				}
			}
			grabReached = true;
			grabReachTimer += Time.deltaTime;
			if (grabReachTimer >= 2f)
			{
				UpdateState(State.JudgeRuckusPlayer);
				return;
			}
		}
		else
		{
			grabReachTimer = 0f;
		}
		stateTimer -= Time.deltaTime;
		if (stateTimer <= 0f)
		{
			PlayReleaseSoundOnce(val2);
			ResolveRuckusPunishmentFailed(playerTarget);
			UpdateState(State.Observe);
		}
	}

	private void StateJudgeRuckusPlayer()
	{
		//IL_0036: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d0: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d5: Unknown result type (might be due to invalid IL or missing references)
		//IL_0063: Unknown result type (might be due to invalid IL or missing references)
		//IL_0069: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ef: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e7: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ab: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b1: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ba: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c0: Unknown result type (might be due to invalid IL or missing references)
		if (stateImpulse)
		{
			stateImpulse = false;
			stateTimer = 1.5f;
			VoiceBoxActiveJudge = true;
			ShowNewEmoji(angryEmoji);
			float num = frozenAimTargetX.eulerAngles.x;
			if (num > 180f)
			{
				num -= 360f;
			}
			FreezeAim(Quaternion.Euler(num - 20f, 0f, 0f), frozenAimTargetY);
			if (SemiFunc.IsMultiplayer())
			{
				photonView.RPC("SmallSensorBreakerRPC", (RpcTarget)0, Array.Empty<object>());
				photonView.RPC("BigSensorBreakerRPC", (RpcTarget)0, Array.Empty<object>());
			}
			else
			{
				SmallSensorBreakerRPC();
				BigSensorBreakerRPC();
			}
		}
		if (!PlayerTargetValid())
		{
			PlayReleaseSoundOnce((grabBeamOverrideTarget != Vector3.zero) ? grabBeamOverrideTarget : gunTipBigTransform.position);
			ResolveRuckusPunishmentFailed(playerTarget);
			UpdateState(State.Observe);
			return;
		}
		stateTimer -= Time.deltaTime;
		if (stateTimer <= 0f)
		{
			UpdateState(State.Shoot);
		}
	}

	private void StateShoot()
	{
		//IL_001d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0028: Unknown result type (might be due to invalid IL or missing references)
		//IL_0032: Unknown result type (might be due to invalid IL or missing references)
		//IL_0037: Unknown result type (might be due to invalid IL or missing references)
		//IL_003c: Unknown result type (might be due to invalid IL or missing references)
		//IL_004b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0057: Unknown result type (might be due to invalid IL or missing references)
		//IL_0099: Unknown result type (might be due to invalid IL or missing references)
		//IL_009e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0289: Unknown result type (might be due to invalid IL or missing references)
		//IL_0290: Unknown result type (might be due to invalid IL or missing references)
		//IL_029a: Unknown result type (might be due to invalid IL or missing references)
		//IL_029f: Unknown result type (might be due to invalid IL or missing references)
		//IL_02a4: Unknown result type (might be due to invalid IL or missing references)
		//IL_0245: Unknown result type (might be due to invalid IL or missing references)
		//IL_0250: Unknown result type (might be due to invalid IL or missing references)
		//IL_025c: Unknown result type (might be due to invalid IL or missing references)
		//IL_02cf: Unknown result type (might be due to invalid IL or missing references)
		//IL_02d2: Unknown result type (might be due to invalid IL or missing references)
		//IL_02d8: Unknown result type (might be due to invalid IL or missing references)
		//IL_02c0: Unknown result type (might be due to invalid IL or missing references)
		//IL_0283: Unknown result type (might be due to invalid IL or missing references)
		//IL_0288: Unknown result type (might be due to invalid IL or missing references)
		//IL_0127: Unknown result type (might be due to invalid IL or missing references)
		//IL_012c: Unknown result type (might be due to invalid IL or missing references)
		//IL_013d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0148: Unknown result type (might be due to invalid IL or missing references)
		//IL_014d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0152: Unknown result type (might be due to invalid IL or missing references)
		//IL_015a: Unknown result type (might be due to invalid IL or missing references)
		//IL_015f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0168: Unknown result type (might be due to invalid IL or missing references)
		//IL_01f0: Unknown result type (might be due to invalid IL or missing references)
		//IL_01f5: Unknown result type (might be due to invalid IL or missing references)
		//IL_0203: Unknown result type (might be due to invalid IL or missing references)
		//IL_0208: Unknown result type (might be due to invalid IL or missing references)
		//IL_0183: Unknown result type (might be due to invalid IL or missing references)
		//IL_0188: Unknown result type (might be due to invalid IL or missing references)
		//IL_0222: Unknown result type (might be due to invalid IL or missing references)
		//IL_0227: Unknown result type (might be due to invalid IL or missing references)
		if (stateImpulse)
		{
			ShowNewEmoji(shootEmoji);
			Vector3 val = aimVertical.position + aimVertical.forward * 50f;
			float num = 1f;
			bool flag = false;
			RaycastHit[] array = Physics.SphereCastAll(aimVertical.position, num, aimVertical.forward, 50f, LayerMask.GetMask(new string[1] { "Player" }) + LayerMask.GetMask(new string[1] { "PhysGrabObject" }));
			for (int i = 0; i < array.Length; i++)
			{
				RaycastHit val2 = array[i];
				PlayerAvatar playerAvatar = null;
				bool flag2 = false;
				if (((Component)val2.transform).gameObject.layer == LayerMask.NameToLayer("Player"))
				{
					flag2 = true;
					PlayerController componentInParent = ((Component)val2.transform).GetComponentInParent<PlayerController>();
					playerAvatar = ((!Object.op_Implicit((Object)(object)componentInParent)) ? ((Component)val2.transform).GetComponentInParent<PlayerAvatar>() : componentInParent.playerAvatarScript);
				}
				else
				{
					PlayerTumble componentInParent2 = ((Component)val2.transform).GetComponentInParent<PlayerTumble>();
					if (Object.op_Implicit((Object)(object)componentInParent2))
					{
						playerAvatar = componentInParent2.playerAvatar;
						flag2 = true;
					}
				}
				if (!flag2)
				{
					continue;
				}
				bool flag3 = true;
				if (val2.point != Vector3.zero)
				{
					Vector3 val3 = val2.point - aimVertical.position;
					RaycastHit[] array2 = Physics.RaycastAll(aimVertical.position, val3, val3.magnitude, LayerMask.op_Implicit(SemiFunc.LayerMaskGetVisionObstruct()), (QueryTriggerInteraction)1);
					for (int j = 0; j < array2.Length; j++)
					{
						RaycastHit val4 = array2[j];
						if (((Component)val4.transform).gameObject.layer != LayerMask.NameToLayer("Player") && (((Component)val4.transform).gameObject.layer != LayerMask.NameToLayer("PhysGrabObject") || !Object.op_Implicit((Object)(object)((Component)val4.transform).GetComponentInParent<PlayerTumble>())))
						{
							flag3 = false;
							break;
						}
					}
				}
				if (flag3)
				{
					if (val2.point != Vector3.zero)
					{
						val = val2.point;
						flag = true;
					}
					else if (Object.op_Implicit((Object)(object)playerAvatar))
					{
						val = playerAvatar.PlayerVisionTarget.VisionTransform.position;
						flag = true;
					}
					break;
				}
			}
			RaycastHit val5 = default;
			if (!flag && Physics.Raycast(aimVertical.position, aimVertical.forward, ref val5, 50f, LayerMask.op_Implicit(SemiFunc.LayerMaskGetVisionObstruct()) + LayerMask.GetMask(new string[1] { "Enemy" })))
			{
				val = val5.point;
			}
			val -= aimVertical.forward * 0.1f;
			if (SemiFunc.IsMultiplayer())
			{
				photonView.RPC("ShootRPC", (RpcTarget)0, new object[1] { val });
			}
			else
			{
				ShootRPC(val);
			}
			ForceReleasePlayerTargetGrabs();
			ResolveRuckusPunishment(playerTarget);
			stateImpulse = false;
			stateTimer = 2f;
		}
		stateTimer -= Time.deltaTime;
		if (stateTimer <= 0f)
		{
			UpdateState(State.Observe);
		}
	}

	private void ForceReleasePlayerTargetGrabs()
	{
		if (!Object.op_Implicit((Object)(object)playerTarget))
		{
			return;
		}
		if (Object.op_Implicit((Object)(object)playerTarget.physGrabber))
		{
			PhysGrabObject grabbedPhysGrabObject = playerTarget.physGrabber.grabbedPhysGrabObject;
			if (Object.op_Implicit((Object)(object)grabbedPhysGrabObject))
			{
				if (SemiFunc.IsMultiplayer())
				{
					playerTarget.physGrabber.OverrideGrabRelease(grabbedPhysGrabObject.photonView.ViewID);
				}
				else
				{
					playerTarget.physGrabber.ReleaseObject(grabbedPhysGrabObject.photonView.ViewID, 0.5f);
				}
			}
		}
		if (Object.op_Implicit((Object)(object)playerTarget.tumble) && Object.op_Implicit((Object)(object)playerTarget.tumble.physGrabObject))
		{
			PhysGrabObject physGrabObject = playerTarget.tumble.physGrabObject;
			foreach (PhysGrabber item in physGrabObject.playerGrabbing.ToList())
			{
				if (Object.op_Implicit((Object)(object)item))
				{
					if (SemiFunc.IsMultiplayer())
					{
						item.OverrideGrabRelease(physGrabObject.photonView.ViewID);
					}
					else
					{
						item.ReleaseObject(physGrabObject.photonView.ViewID, 0.5f);
					}
				}
			}
		}
		SemiFunc.PlayerDronesDeactivate(playerTarget);
	}

	private bool ItemMeleeAttackState(State _state)
	{
		if (_state != State.NegativeMeleeGrab && _state != State.NegativeMeleeWindup)
		{
			return _state == State.NegativeMeleeSwing;
		}
		return true;
	}

	private bool ItemNegativeState(State _state)
	{
		if (_state != State.ReactNegative && _state != State.NegativeGrab && _state != State.NegativeMeleeGrab && _state != State.NegativeMeleeWindup && _state != State.NegativeMeleeSwing)
		{
			return _state == State.NegativeShakeToss;
		}
		return true;
	}

	private bool InItemReactionFlow()
	{
		return ItemReactionState(currentState);
	}

	private bool ItemReactionState(State _state)
	{
		if (_state != State.NoticeItem && _state != State.DenyItem && _state != State.ScanObject && _state != State.Verdict && _state != State.ReactPositive && _state != State.ReactNegative && _state != State.NegativeGrab && _state != State.NegativeMeleeGrab && _state != State.NegativeMeleeWindup && _state != State.NegativeMeleeSwing && _state != State.NegativeShakeToss && _state != State.PositiveGrab)
		{
			return _state == State.PositivePlay;
		}
		return true;
	}

	private bool ItemControlState(State _state)
	{
		if (_state != State.ScanObject && _state != State.Verdict && _state != State.ReactPositive && _state != State.ReactNegative && _state != State.NegativeGrab && _state != State.NegativeMeleeGrab && _state != State.NegativeMeleeWindup && _state != State.NegativeMeleeSwing && _state != State.NegativeShakeToss && _state != State.PositiveGrab)
		{
			return _state == State.PositivePlay;
		}
		return true;
	}

	private bool ItemScanPoseState(State _state)
	{
		if (_state != State.NoticeItem && _state != State.DenyItem && _state != State.ScanObject)
		{
			return _state == State.Verdict;
		}
		return true;
	}

	private bool ItemAimPoseState(State _state)
	{
		if (ItemControlState(_state) && !ItemScanPoseState(_state))
		{
			return _state != State.ReactPositive;
		}
		return false;
	}

	private bool ItemTargetValid()
	{
		if (!Object.op_Implicit((Object)(object)itemReactObject))
		{
			return false;
		}
		if (itemReactObject.dead)
		{
			return false;
		}
		if (!((Component)itemReactObject).gameObject.activeInHierarchy)
		{
			return false;
		}
		if (!Object.op_Implicit((Object)(object)itemReactObject.rb))
		{
			return false;
		}
		return true;
	}

	private Vector3 ItemPresentationOriginGet()
	{
		//IL_001f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0013: Unknown result type (might be due to invalid IL or missing references)
		if (!Object.op_Implicit((Object)(object)detectionSphere))
		{
			return ((Component)this).transform.position;
		}
		return detectionSphere.position;
	}

	private Vector3 ItemScanPointGet(PhysGrabObject _physGrab)
	{
		//IL_0001: Unknown result type (might be due to invalid IL or missing references)
		//IL_0006: Unknown result type (might be due to invalid IL or missing references)
		//IL_0008: Unknown result type (might be due to invalid IL or missing references)
		//IL_000d: Unknown result type (might be due to invalid IL or missing references)
		//IL_000e: Unknown result type (might be due to invalid IL or missing references)
		//IL_000f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0010: Unknown result type (might be due to invalid IL or missing references)
		//IL_0015: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c6: Unknown result type (might be due to invalid IL or missing references)
		//IL_0088: Unknown result type (might be due to invalid IL or missing references)
		//IL_0089: Unknown result type (might be due to invalid IL or missing references)
		//IL_008e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0090: Unknown result type (might be due to invalid IL or missing references)
		//IL_0092: Unknown result type (might be due to invalid IL or missing references)
		//IL_0093: Unknown result type (might be due to invalid IL or missing references)
		//IL_0098: Unknown result type (might be due to invalid IL or missing references)
		//IL_00aa: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ac: Unknown result type (might be due to invalid IL or missing references)
		Vector3 val = ItemPresentationOriginGet();
		Vector3 val2 = _physGrab.centerPoint;
		Vector3 val3 = val2 - val;
		float num = val3.sqrMagnitude;
		itemPresentationColliders.Clear();
		((Component)_physGrab).GetComponentsInChildren<Collider>(false, itemPresentationColliders);
		foreach (Collider itemPresentationCollider in itemPresentationColliders)
		{
			if (Object.op_Implicit((Object)(object)itemPresentationCollider) && itemPresentationCollider.enabled && ((Component)itemPresentationCollider).gameObject.activeInHierarchy && !itemPresentationCollider.isTrigger && !((Object)(object)((Component)itemPresentationCollider).GetComponentInParent<PhysGrabObject>() != (Object)(object)_physGrab))
			{
				Vector3 val4 = itemPresentationCollider.ClosestPoint(val);
				val3 = val4 - val;
				float sqrMagnitude = val3.sqrMagnitude;
				if (!(sqrMagnitude >= num))
				{
					num = sqrMagnitude;
					val2 = val4;
				}
			}
		}
		return val2;
	}

	private float ItemScanDistanceGet(PhysGrabObject _physGrab)
	{
		//IL_0001: Unknown result type (might be due to invalid IL or missing references)
		//IL_0008: Unknown result type (might be due to invalid IL or missing references)
		return Vector3.Distance(ItemPresentationOriginGet(), ItemScanPointGet(_physGrab));
	}

	private bool ItemReactPlayerValid()
	{
		if (!Object.op_Implicit((Object)(object)itemReactPlayer))
		{
			return false;
		}
		if (itemReactPlayer.isDisabled)
		{
			return false;
		}
		if (itemReactPlayer.deadSet)
		{
			return false;
		}
		if (itemReactPlayer.spectating)
		{
			return false;
		}
		if (!((Component)itemReactPlayer).gameObject.activeInHierarchy)
		{
			return false;
		}
		return true;
	}

	private Vector3 ItemReactPlayerPositionGet()
	{
		//IL_00e2: Unknown result type (might be due to invalid IL or missing references)
		//IL_008d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0092: Unknown result type (might be due to invalid IL or missing references)
		//IL_0046: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d1: Unknown result type (might be due to invalid IL or missing references)
		if (itemReactPlayer.isTumbling && Object.op_Implicit((Object)(object)itemReactPlayer.tumble) && Object.op_Implicit((Object)(object)itemReactPlayer.tumble.rb))
		{
			return itemReactPlayer.tumble.rb.worldCenterOfMass;
		}
		if (Object.op_Implicit((Object)(object)itemReactPlayer.playerAvatarCollision) && Object.op_Implicit((Object)(object)itemReactPlayer.playerAvatarCollision.Collider))
		{
			CapsuleCollider collider = itemReactPlayer.playerAvatarCollision.Collider;
			return ((Component)collider).transform.TransformPoint(collider.center);
		}
		if (Object.op_Implicit((Object)(object)itemReactPlayer.PlayerVisionTarget) && Object.op_Implicit((Object)(object)itemReactPlayer.PlayerVisionTarget.VisionTransform))
		{
			return itemReactPlayer.PlayerVisionTarget.VisionTransform.position;
		}
		return ((Component)itemReactPlayer).transform.position;
	}

	private Vector3 ItemReactPlayerVelocityGet()
	{
		//IL_0052: Unknown result type (might be due to invalid IL or missing references)
		//IL_0046: Unknown result type (might be due to invalid IL or missing references)
		if (itemReactPlayer.isTumbling && Object.op_Implicit((Object)(object)itemReactPlayer.tumble) && Object.op_Implicit((Object)(object)itemReactPlayer.tumble.rb))
		{
			return itemReactPlayer.tumble.rb.linearVelocity;
		}
		return itemReactPlayer.rbVelocityRaw;
	}

	private Vector3 ItemMeleeColliderCenterGet(Collider _collider)
	{
		//IL_0011: Unknown result type (might be due to invalid IL or missing references)
		//IL_0016: Unknown result type (might be due to invalid IL or missing references)
		//IL_002d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0032: Unknown result type (might be due to invalid IL or missing references)
		//IL_0049: Unknown result type (might be due to invalid IL or missing references)
		//IL_004e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0091: Unknown result type (might be due to invalid IL or missing references)
		//IL_0077: Unknown result type (might be due to invalid IL or missing references)
		//IL_007c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0080: Unknown result type (might be due to invalid IL or missing references)
		//IL_0085: Unknown result type (might be due to invalid IL or missing references)
		BoxCollider val = (BoxCollider)(object)((_collider is BoxCollider) ? _collider : null);
		if (val != null)
		{
			return ((Component)val).transform.TransformPoint(val.center);
		}
		SphereCollider val2 = (SphereCollider)(object)((_collider is SphereCollider) ? _collider : null);
		if (val2 != null)
		{
			return ((Component)val2).transform.TransformPoint(val2.center);
		}
		CapsuleCollider val3 = (CapsuleCollider)(object)((_collider is CapsuleCollider) ? _collider : null);
		if (val3 != null)
		{
			return ((Component)val3).transform.TransformPoint(val3.center);
		}
		MeshCollider val4 = (MeshCollider)(object)((_collider is MeshCollider) ? _collider : null);
		if (val4 != null && Object.op_Implicit((Object)(object)val4.sharedMesh))
		{
			Transform transform = ((Component)val4).transform;
			Bounds bounds = val4.sharedMesh.bounds;
			return transform.TransformPoint(bounds.center);
		}
		return ((Component)_collider).transform.position;
	}

	private bool ItemMeleeReferencesSet()
	{
		//IL_00c4: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c9: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ce: Unknown result type (might be due to invalid IL or missing references)
		//IL_00dd: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e2: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e7: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e9: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ee: Unknown result type (might be due to invalid IL or missing references)
		//IL_010a: Unknown result type (might be due to invalid IL or missing references)
		//IL_010f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0114: Unknown result type (might be due to invalid IL or missing references)
		//IL_0116: Unknown result type (might be due to invalid IL or missing references)
		//IL_011b: Unknown result type (might be due to invalid IL or missing references)
		//IL_015b: Unknown result type (might be due to invalid IL or missing references)
		//IL_015d: Unknown result type (might be due to invalid IL or missing references)
		if (!ItemTargetValid())
		{
			return false;
		}
		ItemMelee component = ((Component)itemReactObject).GetComponent<ItemMelee>();
		if (!Object.op_Implicit((Object)(object)component) || !component.ForceSwingCanUse())
		{
			return false;
		}
		if ((Object)(object)itemReactMelee == (Object)(object)component && (Object)(object)itemReactMeleeRigidbody == (Object)(object)itemReactObject.rb && Object.op_Implicit((Object)(object)itemMeleeGripPoint) && Object.op_Implicit((Object)(object)itemMeleeSwingPoint) && Object.op_Implicit((Object)(object)itemMeleeHitCollider) && itemMeleeHitLocalDirection.sqrMagnitude > 0.0001f)
		{
			return true;
		}
		Transform val = component.ForceGrabPointGet();
		Transform val2 = component.SwingPointGet();
		Collider val3 = component.HurtColliderGet();
		if (!Object.op_Implicit((Object)(object)val) || !Object.op_Implicit((Object)(object)val2) || !Object.op_Implicit((Object)(object)val3))
		{
			return false;
		}
		Vector3 val4 = ((Component)itemReactObject).transform.InverseTransformPoint(val.position);
		Vector3 val5 = ((Component)itemReactObject).transform.InverseTransformPoint(ItemMeleeColliderCenterGet(val3)) - val4;
		if (val5.sqrMagnitude <= 0.0001f)
		{
			val5 = ((Component)itemReactObject).transform.InverseTransformPoint(val2.position) - val4;
		}
		if (val5.sqrMagnitude <= 0.0001f)
		{
			return false;
		}
		itemReactMelee = component;
		itemReactMeleeRigidbody = itemReactObject.rb;
		itemMeleeGripPoint = val;
		itemMeleeSwingPoint = val2;
		itemMeleeHitCollider = val3;
		itemMeleeHitLocalDirection = val5;
		itemMeleeSwingDirection = ((itemScanSeed % 2 == 0) ? (-1f) : 1f);
		return true;
	}

	private bool ItemMeleeAttackTrySetup()
	{
		if (!ItemReactPlayerValid())
		{
			return false;
		}
		if (!ItemMeleeReferencesSet())
		{
			return false;
		}
		if (Random.value >= Mathf.Clamp01(itemMeleeAttackChance))
		{
			ItemMeleeReferencesClear();
			return false;
		}
		ItemMeleePhysicsOverrideApply();
		return true;
	}

	private bool ItemMeleeAttackValid()
	{
		if (!Object.op_Implicit((Object)(object)playerPoint))
		{
			return false;
		}
		if (!ItemReactPlayerValid())
		{
			return false;
		}
		return ItemMeleeReferencesSet();
	}

	private void ItemMeleePhysicsOverrideApply()
	{
		if (!itemMeleePhysicsOverrideApplied && Object.op_Implicit((Object)(object)itemReactMeleeRigidbody))
		{
			itemMeleeMaxAngularVelocityOriginal = itemReactMeleeRigidbody.maxAngularVelocity;
			itemReactMeleeRigidbody.maxAngularVelocity = Mathf.Max(itemMeleeMaxAngularVelocityOriginal, itemMeleeMaxAngularVelocity);
			itemMeleePhysicsOverrideApplied = true;
		}
	}

	private void ItemMeleePhysicsOverrideRestore()
	{
		if (itemMeleePhysicsOverrideApplied)
		{
			if (Object.op_Implicit((Object)(object)itemReactMeleeRigidbody))
			{
				itemReactMeleeRigidbody.maxAngularVelocity = itemMeleeMaxAngularVelocityOriginal;
			}
			itemMeleePhysicsOverrideApplied = false;
		}
	}

	private void ItemMeleeReferencesClear()
	{
		//IL_002a: Unknown result type (might be due to invalid IL or missing references)
		//IL_002f: Unknown result type (might be due to invalid IL or missing references)
		ItemMeleePhysicsOverrideRestore();
		itemReactMelee = null;
		itemReactMeleeRigidbody = null;
		itemMeleeGripPoint = null;
		itemMeleeSwingPoint = null;
		itemMeleeHitCollider = null;
		itemMeleeHitLocalDirection = Vector3.zero;
		itemMeleeSwingDuration = 0f;
		itemMeleeSwingContactFraction = 0f;
		itemMeleeSwingDirection = 0f;
		itemMeleeSwingImpulse = false;
	}

	private void ItemMeleeAttackClear()
	{
		if (Object.op_Implicit((Object)(object)itemReactMelee) && SemiFunc.IsMasterClientOrSingleplayer())
		{
			itemReactMelee.OverrideSwingDisable(0.5f);
		}
		ItemMeleeReferencesClear();
	}

	private void ItemMeleeAttackFallback()
	{
		//IL_000e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0013: Unknown result type (might be due to invalid IL or missing references)
		//IL_0015: Unknown result type (might be due to invalid IL or missing references)
		//IL_003e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0031: Unknown result type (might be due to invalid IL or missing references)
		if (ItemTargetValid())
		{
			Vector3 centerPoint = itemReactObject.centerPoint;
			PlayReleaseSoundOnce(centerPoint);
		}
		else
		{
			PlayReleaseSoundOnce(Object.op_Implicit((Object)(object)playerPoint) ? playerPoint.position : gunTipBigTransform.position);
		}
		EndItemReaction();
		UpdateState(State.Observe);
	}

	private bool ItemDiscountTargetValid(PhysGrabObject _physGrab)
	{
		if (!Object.op_Implicit((Object)(object)_physGrab))
		{
			return false;
		}
		ItemAttributes component = ((Component)_physGrab).GetComponent<ItemAttributes>();
		if (Object.op_Implicit((Object)(object)component) && component.shopItem)
		{
			return component.value > 0;
		}
		return false;
	}

	private bool ItemPresentationAlignmentValid(PhysGrabObject _physGrab)
	{
		//IL_001b: Unknown result type (might be due to invalid IL or missing references)
		//IL_000e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0020: Unknown result type (might be due to invalid IL or missing references)
		//IL_0041: Unknown result type (might be due to invalid IL or missing references)
		//IL_0034: Unknown result type (might be due to invalid IL or missing references)
		//IL_0047: Unknown result type (might be due to invalid IL or missing references)
		//IL_004c: Unknown result type (might be due to invalid IL or missing references)
		//IL_004d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0052: Unknown result type (might be due to invalid IL or missing references)
		//IL_006f: Unknown result type (might be due to invalid IL or missing references)
		Vector3 val = (Object.op_Implicit((Object)(object)shopkeeperFacePoint) ? shopkeeperFacePoint.position : ItemPresentationOriginGet());
		Vector3 val2 = (Object.op_Implicit((Object)(object)shopkeeperFacePoint) ? shopkeeperFacePoint.up : ((Component)this).transform.forward);
		Vector3 val3 = _physGrab.centerPoint - val;
		float num = Mathf.Clamp(itemPresentationConeAngle, 0f, 180f) * 0.5f;
		return Vector3.Angle(val2, val3) <= num;
	}

	private bool ItemPresentationTargetValid(PhysGrabObject _physGrab, PlayerAvatar _player)
	{
		if (!Object.op_Implicit((Object)(object)_physGrab))
		{
			return false;
		}
		if (_physGrab.dead)
		{
			return false;
		}
		if (!((Component)_physGrab).gameObject.activeInHierarchy)
		{
			return false;
		}
		if (!Object.op_Implicit((Object)(object)_physGrab.rb))
		{
			return false;
		}
		if (_physGrab.isPlayer || _physGrab.isEnemy)
		{
			return false;
		}
		if (itemDiscountAttempts < 3 && !ItemDiscountTargetValid(_physGrab))
		{
			return false;
		}
		if (!Object.op_Implicit((Object)(object)_player))
		{
			return false;
		}
		if (_player.isDisabled)
		{
			return false;
		}
		if (_player.deadSet)
		{
			return false;
		}
		if (_player.spectating)
		{
			return false;
		}
		if (!((Component)_player).gameObject.activeInHierarchy)
		{
			return false;
		}
		if (ruckusScores.TryGetValue(_player, out var value) && value.discountDeniedTimer > 0f)
		{
			return false;
		}
		PhysGrabber physGrabber = _player.physGrabber;
		if (!Object.op_Implicit((Object)(object)physGrabber))
		{
			return false;
		}
		if (!physGrabber.grabbed)
		{
			return false;
		}
		if ((Object)(object)physGrabber.grabbedPhysGrabObject != (Object)(object)_physGrab)
		{
			return false;
		}
		if (!_physGrab.playerGrabbing.Contains(physGrabber))
		{
			return false;
		}
		if (itemPresentationReleasedGrabs.TryGetValue(physGrabber, out var value2) && value2 == physGrabber.grabRevision)
		{
			return false;
		}
		if (SemiFunc.IsMultiplayer())
		{
			if (!Object.op_Implicit((Object)(object)_physGrab.photonView) || _physGrab.photonView.ViewID <= 0)
			{
				return false;
			}
			if (!Object.op_Implicit((Object)(object)_player.photonView) || _player.photonView.ViewID <= 0)
			{
				return false;
			}
		}
		if (ItemScanDistanceGet(_physGrab) > Mathf.Max(0f, itemPresentationRadius))
		{
			return false;
		}
		return ItemPresentationAlignmentValid(_physGrab);
	}

	private bool ItemPresentationCanStart(PhysGrabObject _physGrab, PlayerAvatar _player)
	{
		if (!ItemPresentationTargetValid(_physGrab, _player))
		{
			return false;
		}
		if (shopkeeperItemScanCooldown > 0f)
		{
			return false;
		}
		if (currentState != State.Observe || stateImpulse)
		{
			return false;
		}
		return true;
	}

	private void ItemNoticeStart(PhysGrabObject _physGrab, PlayerAvatar _player)
	{
		if (SemiFunc.IsMasterClientOrSingleplayer() && ItemPresentationCanStart(_physGrab, _player))
		{
			itemReactObject = _physGrab;
			itemReactPlayer = _player;
			itemTarget = ((Component)_physGrab).transform;
			UpdateState((itemDiscountAttempts >= 3) ? State.DenyItem : State.NoticeItem);
		}
	}

	private void ItemScanProximityLogic()
	{
		if (shopkeeperItemScanCooldown > 0f || currentState != State.Observe || stateImpulse)
		{
			return;
		}
		float num = float.MaxValue;
		PhysGrabObject physGrabObject = null;
		PlayerAvatar playerAvatar = null;
		foreach (PlayerAvatar item in SemiFunc.PlayerGetList())
		{
			if (!Object.op_Implicit((Object)(object)item) || !Object.op_Implicit((Object)(object)item.physGrabber))
			{
				continue;
			}
			PhysGrabObject grabbedPhysGrabObject = item.physGrabber.grabbedPhysGrabObject;
			if (ItemPresentationCanStart(grabbedPhysGrabObject, item))
			{
				float num2 = ItemScanDistanceGet(grabbedPhysGrabObject);
				if (!(num2 >= num))
				{
					num = num2;
					physGrabObject = grabbedPhysGrabObject;
					playerAvatar = item;
				}
			}
		}
		if (Object.op_Implicit((Object)(object)physGrabObject) && Object.op_Implicit((Object)(object)playerAvatar))
		{
			ItemNoticeStart(physGrabObject, playerAvatar);
		}
	}

	private void StateNoticeItem()
	{
		if (stateImpulse)
		{
			stateImpulse = false;
			stateTimer = Mathf.Max(2f, itemPresentationDuration);
			itemPresentationGraceTimer = Mathf.Max(0f, itemPresentationGraceDuration);
			ShowNewEmoji(scanEmoji);
		}
		PlayerAvatar playerAvatar = ItemPresentationPlayerGet();
		if (Object.op_Implicit((Object)(object)playerAvatar))
		{
			if ((Object)(object)itemReactPlayer != (Object)(object)playerAvatar)
			{
				itemReactPlayer = playerAvatar;
				ShopKeeperStateSend();
			}
			itemPresentationGraceTimer = Mathf.Max(0f, itemPresentationGraceDuration);
			stateTimer -= Time.deltaTime;
			if (stateTimer > 0f)
			{
				return;
			}
			PhysGrabObject physGrab = itemReactObject;
			if (TryStartItemDiscount(physGrab, playerAvatar))
			{
				return;
			}
		}
		else
		{
			stateTimer = Mathf.Max(2f, itemPresentationDuration);
			itemPresentationGraceTimer -= Time.deltaTime;
			if (itemPresentationGraceTimer > 0f)
			{
				return;
			}
		}
		ItemNoticeCancel();
	}

	private PlayerAvatar ItemPresentationPlayerGet()
	{
		if (ItemPresentationTargetValid(itemReactObject, itemReactPlayer))
		{
			return itemReactPlayer;
		}
		foreach (PlayerAvatar item in SemiFunc.PlayerGetList())
		{
			if (ItemPresentationTargetValid(itemReactObject, item))
			{
				return item;
			}
		}
		return null;
	}

	private void ItemNoticeCancel()
	{
		ItemNoticeClearRefs();
		UpdateState(State.Observe);
	}

	private void ItemNoticeClearRefs()
	{
		itemReactObject = null;
		itemReactPlayer = null;
		itemTarget = null;
		itemPresentationGraceTimer = 0f;
	}

	private bool TryStartItemDiscount(PhysGrabObject _physGrab, PlayerAvatar _player)
	{
		//IL_0049: Unknown result type (might be due to invalid IL or missing references)
		//IL_0059: Unknown result type (might be due to invalid IL or missing references)
		//IL_0063: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		if (!SemiFunc.IsMasterClientOrSingleplayer())
		{
			return false;
		}
		if (currentState != State.NoticeItem)
		{
			return false;
		}
		if (!ItemPresentationTargetValid(_physGrab, _player))
		{
			return false;
		}
		if (itemDiscountAttempts >= 3)
		{
			UpdateState(State.DenyItem);
			return true;
		}
		itemDiscountAttempts++;
		itemScanAim = new Vector2(aimVertical.localEulerAngles.x, aimHorizontal.localEulerAngles.y);
		itemScanSeed = Random.Range(1, int.MaxValue);
		itemScanPresentationSeed = int.MinValue;
		itemReactPlayer = _player;
		itemReactObject = _physGrab;
		itemTarget = ((Component)_physGrab).transform;
		ItemGrabStart();
		UpdateState(State.ScanObject);
		return true;
	}

	private void StateDenyItem()
	{
		if (stateImpulse)
		{
			stateImpulse = false;
			stateTimer = Mathf.Max(0.1f, itemReactDuration);
			itemTossApplied = false;
			ShowNewEmoji(disapproveEmoji);
			ItemDiscountDeniedSet();
		}
		else
		{
			stateTimer -= Time.deltaTime;
			if (!(stateTimer > 0f))
			{
				EndItemReaction();
				UpdateState(State.Observe);
			}
		}
	}

	private void ItemDenyPhysics()
	{
		//IL_0042: Unknown result type (might be due to invalid IL or missing references)
		//IL_0047: Unknown result type (might be due to invalid IL or missing references)
		//IL_0048: Unknown result type (might be due to invalid IL or missing references)
		//IL_004a: Unknown result type (might be due to invalid IL or missing references)
		//IL_004f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0054: Unknown result type (might be due to invalid IL or missing references)
		//IL_0059: Unknown result type (might be due to invalid IL or missing references)
		//IL_005e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0073: Unknown result type (might be due to invalid IL or missing references)
		//IL_0078: Unknown result type (might be due to invalid IL or missing references)
		//IL_007d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0082: Unknown result type (might be due to invalid IL or missing references)
		//IL_0099: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ae: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c8: Unknown result type (might be due to invalid IL or missing references)
		//IL_00cd: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d2: Unknown result type (might be due to invalid IL or missing references)
		//IL_0091: Unknown result type (might be due to invalid IL or missing references)
		//IL_0096: Unknown result type (might be due to invalid IL or missing references)
		//IL_0140: Unknown result type (might be due to invalid IL or missing references)
		//IL_0143: Unknown result type (might be due to invalid IL or missing references)
		//IL_0148: Unknown result type (might be due to invalid IL or missing references)
		//IL_017c: Unknown result type (might be due to invalid IL or missing references)
		//IL_017f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0185: Unknown result type (might be due to invalid IL or missing references)
		//IL_016e: Unknown result type (might be due to invalid IL or missing references)
		if (SemiFunc.IsMasterClientOrSingleplayer() && currentState == State.DenyItem && !stateImpulse && !itemTossApplied && itemDiscountAttempts >= 3 && ItemTargetValid())
		{
			itemTossApplied = true;
			Vector3 centerPoint = itemReactObject.centerPoint;
			Vector3 val = Vector3.ProjectOnPlane(centerPoint - ItemPresentationOriginGet(), Vector3.up);
			if (val.sqrMagnitude < 0.0001f)
			{
				val = Vector3.ProjectOnPlane(((Component)this).transform.forward, Vector3.up);
			}
			if (val.sqrMagnitude < 0.0001f)
			{
				val = Vector3.forward;
			}
			Vector3 val2 = val.normalized * Mathf.Max(0f, itemDenyPushSpeed) + Vector3.up * Mathf.Max(0f, itemDenyPushUp);
			ForceReleaseItemGrabs();
			itemReactObject.OverrideGrabDisable(1f);
			itemReactObject.OverrideIndestructible(1f);
			itemReactObject.OverrideBreakEffects(1f);
			ItemMelee component = ((Component)itemReactObject).GetComponent<ItemMelee>();
			if (Object.op_Implicit((Object)(object)component))
			{
				component.OverrideSwingDisable(1f);
			}
			Rigidbody rb = itemReactObject.rb;
			if (!rb.isKinematic)
			{
				rb.AddForce(val2 - rb.linearVelocity, (ForceMode)2);
			}
			if (SemiFunc.IsMultiplayer())
			{
				photonView.RPC("ItemDenyZapRPC", (RpcTarget)0, new object[1] { centerPoint });
			}
			else
			{
				ItemDenyZapRPC(centerPoint);
			}
		}
	}

	private void ItemDiscountDeniedSet()
	{
		if (SemiFunc.IsMasterClientOrSingleplayer() && ItemReactPlayerValid())
		{
			if (!ruckusScores.TryGetValue(itemReactPlayer, out var value))
			{
				value = new PlayerRuckusScoreRecord();
				value.player = itemReactPlayer;
				ruckusScores[itemReactPlayer] = value;
			}
			value.discountDeniedItem = itemReactObject;
			value.discountDeniedTimer = Mathf.Max(0.1f, itemPresentationGraceDuration);
		}
	}

	private void ItemDiscountDeniedTick()
	{
		foreach (PlayerRuckusScoreRecord value in ruckusScores.Values)
		{
			if (value.discountDeniedTimer <= 0f)
			{
				continue;
			}
			PlayerAvatar player = value.player;
			PhysGrabObject discountDeniedItem = value.discountDeniedItem;
			PhysGrabber physGrabber = (Object.op_Implicit((Object)(object)player) ? player.physGrabber : null);
			if (Object.op_Implicit((Object)(object)discountDeniedItem) && !discountDeniedItem.dead && ((Component)discountDeniedItem).gameObject.activeInHierarchy && Object.op_Implicit((Object)(object)physGrabber) && physGrabber.grabbed && (Object)(object)physGrabber.grabbedPhysGrabObject == (Object)(object)discountDeniedItem && ItemScanDistanceGet(discountDeniedItem) <= Mathf.Max(0f, itemPresentationRadius))
			{
				value.discountDeniedTimer = Mathf.Max(0.1f, itemPresentationGraceDuration);
				continue;
			}
			value.discountDeniedTimer = Mathf.Max(0f, value.discountDeniedTimer - Time.deltaTime);
			if (value.discountDeniedTimer <= 0f)
			{
				value.discountDeniedItem = null;
			}
		}
	}

	private void StateScanObject()
	{
		if (!ItemTargetValid() || !ItemDiscountTargetValid(itemReactObject))
		{
			EndItemReaction();
			UpdateState(State.Observe);
			return;
		}
		if (stateImpulse)
		{
			stateImpulse = false;
			stateTimer = Random.Range(itemScanDurationMin, itemScanDurationMax);
			VoiceBoxActive = true;
			ShowNewEmoji(scanEmoji);
			ItemScanPresentationSetup();
		}
		stateTimer -= Time.deltaTime;
		if (stateTimer <= 0f)
		{
			UpdateState(State.Verdict);
		}
	}

	private void StateVerdict()
	{
		//IL_008f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0095: Unknown result type (might be due to invalid IL or missing references)
		//IL_009e: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a4: Unknown result type (might be due to invalid IL or missing references)
		if (!ItemTargetValid() || !ItemDiscountTargetValid(itemReactObject))
		{
			EndItemReaction();
			UpdateState(State.Observe);
			return;
		}
		if (stateImpulse)
		{
			stateImpulse = false;
			stateTimer = itemVerdictDuration;
			itemVerdictPositive = ItemVerdictPositiveGet();
			ShowNewEmoji(scanEmoji);
			if (SemiFunc.IsMultiplayer())
			{
				photonView.RPC("SmallSensorBreakerRPC", (RpcTarget)0, Array.Empty<object>());
				photonView.RPC("BigSensorBreakerRPC", (RpcTarget)0, Array.Empty<object>());
			}
			else
			{
				SmallSensorBreakerRPC();
				BigSensorBreakerRPC();
			}
		}
		stateTimer -= Time.deltaTime;
		if (stateTimer <= 0f)
		{
			UpdateState(itemVerdictPositive ? State.ReactPositive : State.ReactNegative);
		}
	}

	private void StateReactPositive()
	{
		//IL_0050: Unknown result type (might be due to invalid IL or missing references)
		//IL_0056: Unknown result type (might be due to invalid IL or missing references)
		if (stateImpulse)
		{
			stateImpulse = false;
			PlayItemLikeVoice();
			ShowNewEmoji(approveEmoji);
			PlayItemReactionSound(_positive: true);
			ItemDiscountApply();
			if (SemiFunc.IsMultiplayer())
			{
				photonView.RPC("BigSensorBreakerRPC", (RpcTarget)0, Array.Empty<object>());
			}
			else
			{
				BigSensorBreakerRPC();
			}
			UpdateState(State.PositiveGrab);
		}
	}

	private void StateReactNegative()
	{
		//IL_0044: Unknown result type (might be due to invalid IL or missing references)
		//IL_004a: Unknown result type (might be due to invalid IL or missing references)
		if (stateImpulse)
		{
			stateImpulse = false;
			ShowNewEmoji(disapproveEmoji);
			PlayItemReactionSound(_positive: false);
			if (SemiFunc.IsMultiplayer())
			{
				photonView.RPC("BigSensorBreakerRPC", (RpcTarget)0, Array.Empty<object>());
			}
			else
			{
				BigSensorBreakerRPC();
			}
			State state = (ItemMeleeAttackTrySetup() ? State.NegativeMeleeGrab : State.NegativeGrab);
			UpdateState(state);
		}
	}

	private void StateNegativeGrab()
	{
		//IL_0093: Unknown result type (might be due to invalid IL or missing references)
		//IL_009e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0075: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_00df: Unknown result type (might be due to invalid IL or missing references)
		if (stateImpulse)
		{
			stateImpulse = false;
			float num = Mathf.Min(itemDislikeGrabDurationMin, itemDislikeGrabDurationMax);
			float num2 = Mathf.Max(itemDislikeGrabDurationMin, itemDislikeGrabDurationMax);
			stateTimer = Random.Range(num, num2);
			ShowNewEmoji(disapproveEmoji);
		}
		if (!ItemTargetValid())
		{
			PlayReleaseSoundOnce(Object.op_Implicit((Object)(object)playerPoint) ? playerPoint.position : gunTipBigTransform.position);
			EndItemReaction();
			UpdateState(State.Observe);
			return;
		}
		if (Vector3.Distance(itemReactObject.centerPoint, playerPoint.position) <= itemHoldDistance)
		{
			UpdateState(State.NegativeShakeToss);
			return;
		}
		stateTimer -= Time.deltaTime;
		if (stateTimer <= 0f)
		{
			PlayReleaseSoundOnce(itemReactObject.centerPoint);
			EndItemReaction();
			UpdateState(State.Observe);
		}
	}

	private void StateNegativeMeleeGrab()
	{
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0078: Unknown result type (might be due to invalid IL or missing references)
		if (stateImpulse)
		{
			stateImpulse = false;
			float num = Mathf.Min(itemDislikeGrabDurationMin, itemDislikeGrabDurationMax);
			float num2 = Mathf.Max(itemDislikeGrabDurationMin, itemDislikeGrabDurationMax);
			stateTimer = Random.Range(num, num2);
			ShowNewEmoji(disapproveEmoji);
			ItemMeleePhysicsOverrideApply();
		}
		if (!ItemMeleeAttackValid())
		{
			ItemMeleeAttackFallback();
			return;
		}
		ItemMeleePhysicsOverrideApply();
		if (Vector3.Distance(itemMeleeGripPoint.position, playerPoint.position) <= itemHoldDistance)
		{
			UpdateState(State.NegativeMeleeWindup);
			return;
		}
		stateTimer -= Time.deltaTime;
		if (stateTimer <= 0f)
		{
			ItemMeleeAttackFallback();
		}
	}

	private void StateNegativeMeleeWindup()
	{
		if (!ItemMeleeAttackValid())
		{
			ItemMeleeAttackFallback();
			return;
		}
		if (stateImpulse)
		{
			stateImpulse = false;
			stateTimer = Mathf.Lerp(itemMeleeWindupDurationLight, itemMeleeWindupDurationHeavy, ItemWeightLerp());
			ShowNewEmoji(disapproveEmoji);
			ItemMeleePhysicsOverrideApply();
		}
		stateTimer -= Time.deltaTime;
		if (stateTimer <= 0f)
		{
			UpdateState(State.NegativeMeleeSwing);
		}
	}

	private void StateNegativeMeleeSwing()
	{
		if (!ItemMeleeAttackValid())
		{
			ItemMeleeAttackFallback();
			return;
		}
		if (stateImpulse)
		{
			stateImpulse = false;
			itemMeleeSwingDuration = Mathf.Max(0.05f, Mathf.Lerp(itemMeleeSwingDurationLight, itemMeleeSwingDurationHeavy, ItemWeightLerp()));
			stateTimer = itemMeleeSwingDuration;
			float num = Mathf.Max(0.001f, itemMeleeWindupAngle + itemMeleeFollowThroughAngle);
			itemMeleeSwingContactFraction = itemMeleeWindupAngle / num;
			itemMeleeSwingImpulse = true;
			ItemMeleePhysicsOverrideApply();
			itemReactMelee.ForceSwing(itemMeleeSwingDuration + 0.1f);
			ShowNewEmoji(disapproveEmoji);
		}
		stateTimer -= Time.deltaTime;
		if (stateTimer <= 0f)
		{
			itemReactMelee.OverrideSwingDisable(0.5f);
			ItemMeleePhysicsOverrideRestore();
			UpdateState(State.NegativeShakeToss);
		}
	}

	private void StateNegativeShakeToss()
	{
		//IL_0088: Unknown result type (might be due to invalid IL or missing references)
		//IL_008e: Unknown result type (might be due to invalid IL or missing references)
		if (stateImpulse)
		{
			stateImpulse = false;
			stateTimer = 1.5f;
			if (Object.op_Implicit((Object)(object)itemReactMelee))
			{
				itemReactMelee.OverrideSwingDisable(0.5f);
			}
			ItemMeleePhysicsOverrideRestore();
			ShakeSoundItemStart(itemReactObject);
			itemTossApplied = false;
			VoiceBoxActiveAngry = true;
			ShowNewEmoji(disapproveEmoji);
			if (SemiFunc.IsMultiplayer())
			{
				photonView.RPC("SmallSensorBreakerRPC", (RpcTarget)0, Array.Empty<object>());
			}
			else
			{
				SmallSensorBreakerRPC();
			}
		}
		if (!ItemTargetValid())
		{
			EndItemReaction();
			UpdateState(State.Observe);
		}
		else
		{
			stateTimer -= Time.deltaTime;
		}
	}

	private void StatePositiveGrab()
	{
		//IL_006e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0079: Unknown result type (might be due to invalid IL or missing references)
		//IL_0050: Unknown result type (might be due to invalid IL or missing references)
		//IL_0043: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ba: Unknown result type (might be due to invalid IL or missing references)
		if (stateImpulse)
		{
			stateImpulse = false;
			stateTimer = itemReachInDuration;
			ShowNewEmoji(approveEmoji);
		}
		if (!ItemTargetValid())
		{
			PlayReleaseSoundOnce(Object.op_Implicit((Object)(object)playerPoint) ? playerPoint.position : gunTipBigTransform.position);
			EndItemReaction();
			UpdateState(State.Observe);
			return;
		}
		if (Vector3.Distance(itemReactObject.centerPoint, playerPoint.position) <= itemHoldDistance)
		{
			UpdateState(State.PositivePlay);
			return;
		}
		stateTimer -= Time.deltaTime;
		if (stateTimer <= 0f)
		{
			PlayReleaseSoundOnce(itemReactObject.centerPoint);
			EndItemReaction();
			UpdateState(State.Observe);
		}
	}

	private void StatePositivePlay()
	{
		//IL_00ff: Unknown result type (might be due to invalid IL or missing references)
		//IL_00cd: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d3: Unknown result type (might be due to invalid IL or missing references)
		if (stateImpulse)
		{
			stateImpulse = false;
			stateTimer = Random.Range(itemPlayDurationMin, itemPlayDurationMax);
			VoiceBoxActive = true;
			ShowNewEmoji(approveEmoji);
			itemPlaySwingTimer = 0f;
			itemReactSensorTimer = 0f;
			PickNewPlaySwingTarget();
		}
		if (!ItemTargetValid())
		{
			EndItemReaction();
			UpdateState(State.Observe);
			return;
		}
		itemReactSensorTimer -= Time.deltaTime;
		if (itemReactSensorTimer <= 0f)
		{
			itemReactSensorTimer = Random.Range(0.5f, 1.2f);
			ShowNewEmoji(approveEmoji);
			if (SemiFunc.IsMultiplayer())
			{
				photonView.RPC("SmallSensorBreakerRPC", (RpcTarget)0, Array.Empty<object>());
			}
			else
			{
				SmallSensorBreakerRPC();
			}
		}
		stateTimer -= Time.deltaTime;
		if (stateTimer <= 0f)
		{
			PlayReleaseSoundOnce(itemReactObject.centerPoint);
			EndItemReaction();
			UpdateState(State.Observe);
		}
	}

	private void PickNewPlaySwingTarget()
	{
		//IL_0020: Unknown result type (might be due to invalid IL or missing references)
		//IL_0013: Unknown result type (might be due to invalid IL or missing references)
		//IL_0025: Unknown result type (might be due to invalid IL or missing references)
		//IL_0026: Unknown result type (might be due to invalid IL or missing references)
		//IL_0030: Unknown result type (might be due to invalid IL or missing references)
		//IL_0035: Unknown result type (might be due to invalid IL or missing references)
		//IL_0038: Unknown result type (might be due to invalid IL or missing references)
		//IL_004f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0050: Unknown result type (might be due to invalid IL or missing references)
		//IL_0051: Unknown result type (might be due to invalid IL or missing references)
		//IL_0056: Unknown result type (might be due to invalid IL or missing references)
		Vector3 val = (Object.op_Implicit((Object)(object)playerPoint) ? playerPoint.position : gunTipBigTransform.position);
		Vector3 val2 = Random.insideUnitSphere * 0.6f;
		val2.y = Mathf.Abs(val2.y) * 0.5f;
		itemPlaySwingTarget = val + val2;
	}

	private void PlayItemReactionSound(bool _positive)
	{
		//IL_0020: Unknown result type (might be due to invalid IL or missing references)
		//IL_0013: Unknown result type (might be due to invalid IL or missing references)
		//IL_0025: Unknown result type (might be due to invalid IL or missing references)
		//IL_0059: Unknown result type (might be due to invalid IL or missing references)
		//IL_005c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0062: Unknown result type (might be due to invalid IL or missing references)
		//IL_004a: Unknown result type (might be due to invalid IL or missing references)
		Vector3 val = (Object.op_Implicit((Object)(object)itemReactObject) ? itemReactObject.centerPoint : gunTipBigTransform.position);
		if (SemiFunc.IsMultiplayer())
		{
			photonView.RPC("ItemReactionSoundRPC", (RpcTarget)0, new object[2] { _positive, val });
		}
		else
		{
			ItemReactionSoundRPC(_positive, val);
		}
	}

	[PunRPC]
	private void ItemReactionSoundRPC(bool _positive, Vector3 _pos, PhotonMessageInfo _info = default(PhotonMessageInfo))
	{
		//IL_0000: Unknown result type (might be due to invalid IL or missing references)
		//IL_0054: Unknown result type (might be due to invalid IL or missing references)
		//IL_0075: Unknown result type (might be due to invalid IL or missing references)
		//IL_0091: Unknown result type (might be due to invalid IL or missing references)
		//IL_0093: Unknown result type (might be due to invalid IL or missing references)
		//IL_0012: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0030: Unknown result type (might be due to invalid IL or missing references)
		//IL_0047: Unknown result type (might be due to invalid IL or missing references)
		if (SemiFunc.MasterOnlyRPC(_info))
		{
			if (_positive)
			{
				itemApproveSound.Play(_pos);
				ItemReactionLightPlay(_pos, itemLikeLightColor, itemLikeLightDuration, itemLikeLightIntensityMultiplier);
				ItemLikeParticlesPlay(_pos);
			}
			else
			{
				itemDisapproveSound.Play(_pos);
				itemDenySound.Play(_pos);
				ItemReactionLightPlay(_pos, itemDislikeLightColor, itemDislikeLightDuration, itemDislikeLightIntensityMultiplier);
			}
		}
	}

	[PunRPC]
	private void ItemDenyZapRPC(Vector3 _position, PhotonMessageInfo _info = default(PhotonMessageInfo))
	{
		//IL_0000: Unknown result type (might be due to invalid IL or missing references)
		//IL_0020: Unknown result type (might be due to invalid IL or missing references)
		//IL_0021: Unknown result type (might be due to invalid IL or missing references)
		//IL_0058: Unknown result type (might be due to invalid IL or missing references)
		//IL_004b: Unknown result type (might be due to invalid IL or missing references)
		//IL_00cf: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d1: Unknown result type (might be due to invalid IL or missing references)
		//IL_008f: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b6: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c8: Unknown result type (might be due to invalid IL or missing references)
		if (SemiFunc.MasterOnlyRPC(_info))
		{
			itemDenyBeamTimer = Mathf.Max(0.05f, itemDenyZapTime);
			itemDenyBeamPosition = _position;
			itemDenyBeamTarget = itemReactObject;
			itemDenySound.Play(Object.op_Implicit((Object)(object)shopkeeperFacePoint) ? shopkeeperFacePoint.position : ((Component)this).transform.position);
			if (Object.op_Implicit((Object)(object)itemDenyEffects))
			{
				itemDenyEffects.soundElectricity.Play(_position);
				ItemDenyParticlesPlay(itemDenyEffects.particleLightning, _position);
				ItemDenyParticlesPlay(itemDenyEffects.particleFlash, _position);
			}
			ItemReactionLightPlay(_position, itemDenyBeamColor, itemDenyBeamTimer, itemDislikeLightIntensityMultiplier);
		}
	}

	private void ItemDenyParticlesPlay(ParticleSystem _prefab, Vector3 _position)
	{
		//IL_000a: Unknown result type (might be due to invalid IL or missing references)
		//IL_000b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0029: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0042: Unknown result type (might be due to invalid IL or missing references)
		//IL_0047: Unknown result type (might be due to invalid IL or missing references)
		if (Object.op_Implicit((Object)(object)_prefab))
		{
			ParticleSystem val = Object.Instantiate<ParticleSystem>(_prefab, _position, Quaternion.identity);
			((Component)val).gameObject.SetActive(true);
			val.Play(true);
			MainModule main = val.main;
			GameObject gameObject = ((Component)val).gameObject;
			float duration = main.duration;
			MinMaxCurve startLifetime = main.startLifetime;
			Object.Destroy((Object)(object)gameObject, Mathf.Max(1f, duration + startLifetime.constantMax));
		}
	}

	private void PlayItemLikeVoice()
	{
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006e: Unknown result type (might be due to invalid IL or missing references)
		if (voiceBoxSoundClips != null && voiceBoxSoundClips.Count != 0)
		{
			int num = Random.Range(0, voiceBoxSoundClips.Count);
			if (SemiFunc.IsMultiplayer())
			{
				photonView.RPC("ItemLikeVoiceRPC", (RpcTarget)0, new object[2] { num, itemLikeVoicePitch });
			}
			else
			{
				ItemLikeVoiceRPC(num, itemLikeVoicePitch);
			}
		}
	}

	[PunRPC]
	private void ItemLikeVoiceRPC(int _index, float _pitch, PhotonMessageInfo _info = default(PhotonMessageInfo))
	{
		//IL_0000: Unknown result type (might be due to invalid IL or missing references)
		//IL_0086: Unknown result type (might be due to invalid IL or missing references)
		if (SemiFunc.MasterOnlyRPC(_info) && voiceBoxSoundClips != null && _index >= 0 && _index < voiceBoxSoundClips.Count)
		{
			AudioClip[] sounds = new AudioClip[1] { voiceBoxSoundClips[_index] };
			voiceBoxSound.Sounds = sounds;
			float pitch = voiceBoxSound.Pitch;
			float pitchRandom = voiceBoxSound.PitchRandom;
			voiceBoxSound.Pitch = _pitch;
			voiceBoxSound.PitchRandom = 0f;
			voiceBoxSound.Play(VoiceBox.position);
			voiceBoxSound.Pitch = pitch;
			voiceBoxSound.PitchRandom = pitchRandom;
			VoiceBoxSoundTime = Time.time;
		}
	}

	private void ItemReactionLightPlay(Vector3 _position, Color _color, float _duration, float _intensityMultiplier)
	{
		//IL_0001: Unknown result type (might be due to invalid IL or missing references)
		//IL_0002: Unknown result type (might be due to invalid IL or missing references)
		//IL_0008: Unknown result type (might be due to invalid IL or missing references)
		//IL_0009: Unknown result type (might be due to invalid IL or missing references)
		//IL_0075: Unknown result type (might be due to invalid IL or missing references)
		itemReactionLightTarget = _position;
		itemReactionLightColor = _color;
		itemReactionLightDuration = Mathf.Max(0f, _duration);
		itemReactionLightIntensityMultiplier = Mathf.Max(0f, _intensityMultiplier);
		itemReactionLightTimer = itemReactionLightDuration;
		if (Object.op_Implicit((Object)(object)itemReactionFlashLight))
		{
			((Behaviour)itemReactionFlashLight).enabled = true;
			itemReactionFlashLight.intensity = scanLightIntensityOriginal * itemReactionLightIntensityMultiplier;
			itemReactionFlashLight.color = itemReactionLightColor;
		}
		if (Object.op_Implicit((Object)(object)scanLight))
		{
			((Behaviour)scanLight).enabled = false;
		}
		scanLightOn = false;
		scanLightInTimer = 0.2f;
		scanLightOutTimer = 0.2f;
	}

	private void ItemLikeParticlesPlay(Vector3 _position)
	{
		//IL_0027: Unknown result type (might be due to invalid IL or missing references)
		//IL_0028: Unknown result type (might be due to invalid IL or missing references)
		if (itemLikeParticlesPrefab != null && !((Object)(object)itemLikeParticlesPrefab.Prefab == (Object)null))
		{
			GameObject val = Object.Instantiate<GameObject>(itemLikeParticlesPrefab.Prefab, _position, Quaternion.identity);
			EnemySpinnyParticle component = val.GetComponent<EnemySpinnyParticle>();
			if (Object.op_Implicit((Object)(object)component))
			{
				component.playOnStart = true;
			}
			Object.Destroy((Object)(object)val, Mathf.Max(0.1f, itemLikeParticlesLifetime));
		}
	}

	private void ForceReleaseItemGrabs()
	{
		if (!SemiFunc.IsMasterClientOrSingleplayer() || !Object.op_Implicit((Object)(object)itemReactObject))
		{
			return;
		}
		foreach (PlayerAvatar item in SemiFunc.PlayerGetList())
		{
			if (!Object.op_Implicit((Object)(object)item))
			{
				continue;
			}
			PhysGrabber physGrabber = item.physGrabber;
			if (Object.op_Implicit((Object)(object)physGrabber) && physGrabber.grabbed && !((Object)(object)physGrabber.grabbedPhysGrabObject != (Object)(object)itemReactObject))
			{
				itemPresentationReleasedGrabs[physGrabber] = physGrabber.grabRevision;
				if (SemiFunc.IsMultiplayer())
				{
					physGrabber.OverrideGrabRelease(itemReactObject.photonView.ViewID);
				}
				else
				{
					physGrabber.ReleaseObject(itemReactObject.photonView.ViewID, 0.5f);
				}
			}
		}
	}

	private void ItemGrabStart()
	{
		//IL_0027: Unknown result type (might be due to invalid IL or missing references)
		//IL_0050: Unknown result type (might be due to invalid IL or missing references)
		//IL_005b: Unknown result type (might be due to invalid IL or missing references)
		if (ItemTargetValid())
		{
			grabBeamReleaseSoundPlayed = false;
			itemReactObject.OverrideGrabDisable(0.25f);
			PlayGrabSound(itemReactObject.centerPoint);
			ForceReleaseItemGrabs();
			if (Object.op_Implicit((Object)(object)playerPoint))
			{
				grabInitialDistance = Mathf.Max(0.01f, Vector3.Distance(itemReactObject.centerPoint, playerPoint.position));
			}
		}
	}

	private void EndItemReaction()
	{
		ForceClearGrabBeamOverride(_playRelease: true);
		ItemReactionClearRefs();
	}

	private void EndItemReactionSilent()
	{
		ForceClearGrabBeamOverride(_playRelease: false);
		ItemReactionClearRefs();
	}

	private void ItemReactionClearRefs()
	{
		if (ItemControlState(currentState))
		{
			ForceReleaseItemGrabs();
		}
		ItemRejectionFinish();
		ItemMeleeAttackClear();
		itemReactObject = null;
		itemReactPlayer = null;
		itemTarget = null;
		itemScanColliders.Clear();
		itemScanCurrentCollider = null;
		shopkeeperItemScanCooldown = 0.5f;
	}

	private void ItemRejectionFinish()
	{
		if (SemiFunc.IsMasterClientOrSingleplayer() && ItemTargetValid() && (ItemNegativeState(currentState) || (currentState == State.Verdict && !stateImpulse && !itemVerdictPositive)))
		{
			ItemDislikeAffectApply(itemReactObject);
		}
	}

	private void BuildItemScanColliders()
	{
		itemScanColliders.Clear();
		if (!Object.op_Implicit((Object)(object)itemReactObject))
		{
			return;
		}
		Collider[] componentsInChildren = ((Component)itemReactObject).GetComponentsInChildren<Collider>();
		foreach (Collider val in componentsInChildren)
		{
			if (Object.op_Implicit((Object)(object)val) && val.enabled && ((Component)val).gameObject.activeInHierarchy && !val.isTrigger && (val is BoxCollider || val is SphereCollider || val is CapsuleCollider))
			{
				itemScanColliders.Add(val);
			}
		}
		Random random = new Random(itemScanSeed);
		for (int num = itemScanColliders.Count - 1; num > 0; num--)
		{
			int num2 = random.Next(0, num + 1);
			List<Collider> list = itemScanColliders;
			int i = num;
			List<Collider> list2 = itemScanColliders;
			int index = num2;
			Collider val2 = itemScanColliders[num2];
			Collider val3 = itemScanColliders[num];
			Collider val4 = (list[i] = val2);
			val4 = (list2[index] = val3);
		}
	}

	private void ItemScanPresentationSyncLogic()
	{
		if (currentState != State.ScanObject)
		{
			itemScanPresentationSeed = int.MinValue;
		}
		else if (ItemTargetValid() && itemScanPresentationSeed != itemScanSeed)
		{
			ItemScanPresentationSetup();
		}
	}

	private void ItemScanPresentationSetup()
	{
		if (ItemTargetValid() && itemScanPresentationSeed != itemScanSeed)
		{
			BuildItemScanColliders();
			itemScanBeamTimer = 0f;
			itemScanCurrentCollider = null;
			itemScanColliderIndex = 0;
			if (itemScanColliders.Count > 0)
			{
				itemScanBeamDuration = Mathf.Clamp(1f / (float)itemScanColliders.Count, itemBeamScanDurationMin, itemBeamScanDurationMax);
			}
			itemScanPresentationSeed = itemScanSeed;
		}
	}

	private void AdvanceItemScanCollider()
	{
		if (itemScanColliders.Count == 0)
		{
			itemScanCurrentCollider = null;
			return;
		}
		for (int i = 0; i < itemScanColliders.Count; i++)
		{
			if (itemScanColliderIndex >= itemScanColliders.Count)
			{
				itemScanColliderIndex = 0;
			}
			Collider val = itemScanColliders[itemScanColliderIndex];
			itemScanColliderIndex = (itemScanColliderIndex + 1) % itemScanColliders.Count;
			if (Object.op_Implicit((Object)(object)val))
			{
				itemScanCurrentCollider = val;
				return;
			}
		}
		itemScanCurrentCollider = null;
	}

	private Vector3 GetItemScanPoint(Collider _col, float _progress)
	{
		//IL_0000: Unknown result type (might be due to invalid IL or missing references)
		//IL_0005: Unknown result type (might be due to invalid IL or missing references)
		//IL_0006: Unknown result type (might be due to invalid IL or missing references)
		//IL_000b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0017: Unknown result type (might be due to invalid IL or missing references)
		//IL_001c: Unknown result type (might be due to invalid IL or missing references)
		//IL_001e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0023: Unknown result type (might be due to invalid IL or missing references)
		//IL_0037: Unknown result type (might be due to invalid IL or missing references)
		//IL_003c: Unknown result type (might be due to invalid IL or missing references)
		//IL_003d: Unknown result type (might be due to invalid IL or missing references)
		//IL_004f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0054: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d9: Unknown result type (might be due to invalid IL or missing references)
		//IL_00de: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e1: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e7: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f9: Unknown result type (might be due to invalid IL or missing references)
		//IL_0105: Unknown result type (might be due to invalid IL or missing references)
		//IL_010b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0117: Unknown result type (might be due to invalid IL or missing references)
		//IL_011c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0123: Unknown result type (might be due to invalid IL or missing references)
		//IL_0065: Unknown result type (might be due to invalid IL or missing references)
		//IL_006a: Unknown result type (might be due to invalid IL or missing references)
		//IL_014d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0154: Unknown result type (might be due to invalid IL or missing references)
		//IL_012c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0133: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a6: Unknown result type (might be due to invalid IL or missing references)
		//IL_016e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0173: Unknown result type (might be due to invalid IL or missing references)
		//IL_0175: Unknown result type (might be due to invalid IL or missing references)
		//IL_015d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0162: Unknown result type (might be due to invalid IL or missing references)
		//IL_0164: Unknown result type (might be due to invalid IL or missing references)
		//IL_013c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0141: Unknown result type (might be due to invalid IL or missing references)
		//IL_0143: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ce: Unknown result type (might be due to invalid IL or missing references)
		//IL_00bf: Unknown result type (might be due to invalid IL or missing references)
		//IL_01b0: Unknown result type (might be due to invalid IL or missing references)
		//IL_01b1: Unknown result type (might be due to invalid IL or missing references)
		//IL_01b5: Unknown result type (might be due to invalid IL or missing references)
		//IL_01ba: Unknown result type (might be due to invalid IL or missing references)
		//IL_01bf: Unknown result type (might be due to invalid IL or missing references)
		Vector3 val = Vector3.zero;
		Vector3 val2 = Vector3.zero;
		BoxCollider val3 = (BoxCollider)(object)((_col is BoxCollider) ? _col : null);
		if (val3 != null)
		{
			val = val3.center;
			val2 = val3.size;
		}
		else
		{
			SphereCollider val4 = (SphereCollider)(object)((_col is SphereCollider) ? _col : null);
			if (val4 != null)
			{
				val = val4.center;
				val2 = Vector3.one * (val4.radius * 2f);
			}
			else
			{
				CapsuleCollider val5 = (CapsuleCollider)(object)((_col is CapsuleCollider) ? _col : null);
				if (val5 != null)
				{
					val = val5.center;
					float num = Mathf.Max(val5.height, val5.radius * 2f);
					float num2 = val5.radius * 2f;
					if (val5.direction != 0)
					{
						val2 = ((val5.direction != 1) ? new Vector3(num2, num2, num) : new Vector3(num2, num, num2));
					}
					else
					{
						val2 = new Vector3(num, num2, num2);
					}
				}
			}
		}
		Vector3 lossyScale = ((Component)_col).transform.lossyScale;
		Vector3 val6 = new Vector3(val2.x * Mathf.Abs(lossyScale.x), val2.y * Mathf.Abs(lossyScale.y), val2.z * Mathf.Abs(lossyScale.z));
		Vector3 val7;
		float num3;
		if (val6.x >= val6.y && val6.x >= val6.z)
		{
			val7 = Vector3.right;
			num3 = val2.x;
		}
		else if (val6.y >= val6.z)
		{
			val7 = Vector3.up;
			num3 = val2.y;
		}
		else
		{
			val7 = Vector3.forward;
			num3 = val2.z;
		}
		float num4 = Mathf.PingPong(_progress * 2f, 1f);
		float num5 = Mathf.Lerp((0f - num3) * 0.5f, num3 * 0.5f, num4);
		return ((Component)_col).transform.TransformPoint(val + val7 * num5);
	}

	private void ItemReactionBeamOverridePing()
	{
		//IL_002e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0033: Unknown result type (might be due to invalid IL or missing references)
		//IL_0057: Unknown result type (might be due to invalid IL or missing references)
		//IL_0050: Unknown result type (might be due to invalid IL or missing references)
		//IL_0055: Unknown result type (might be due to invalid IL or missing references)
		if (ItemControlState(currentState) && ItemTargetValid())
		{
			itemReactObject.OverrideGrabDisable(0.25f);
			Vector3 target = itemReactObject.centerPoint;
			if (ItemMeleeAttackState(currentState) && ItemMeleeReferencesSet())
			{
				target = itemMeleeGripPoint.position;
			}
			GrabBeamOverride(target);
		}
	}

	private void ItemScanBeamLogic()
	{
		//IL_0036: Unknown result type (might be due to invalid IL or missing references)
		//IL_003c: Unknown result type (might be due to invalid IL or missing references)
		//IL_004a: Unknown result type (might be due to invalid IL or missing references)
		//IL_004f: Unknown result type (might be due to invalid IL or missing references)
		//IL_005b: Unknown result type (might be due to invalid IL or missing references)
		//IL_01a5: Unknown result type (might be due to invalid IL or missing references)
		//IL_01aa: Unknown result type (might be due to invalid IL or missing references)
		//IL_0189: Unknown result type (might be due to invalid IL or missing references)
		//IL_018e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0156: Unknown result type (might be due to invalid IL or missing references)
		//IL_01b7: Unknown result type (might be due to invalid IL or missing references)
		//IL_01bc: Unknown result type (might be due to invalid IL or missing references)
		if (currentState != State.ScanObject || !Object.op_Implicit((Object)(object)itemScanLineBetweenTwoPoints) || !Object.op_Implicit((Object)(object)shopkeeperFacePoint) || !ItemTargetValid())
		{
			return;
		}
		BeamFromSensor();
		if (itemScanLineColorCurrent != itemBeamColorScanLine)
		{
			itemScanLineColorCurrent = itemBeamColorScanLine;
			itemScanLineBetweenTwoPoints.SetColor(itemBeamColorScanLine);
		}
		float num = 0f;
		if (itemScanColliders.Count > 0)
		{
			itemScanBeamDuration = Mathf.Clamp(1f / (float)itemScanColliders.Count, itemBeamScanDurationMin, itemBeamScanDurationMax);
			float num2 = Mathf.Max(0f, Time.time - currentStateEnterTime);
			int num3 = Mathf.FloorToInt(num2 / itemScanBeamDuration);
			int num4 = num3 % itemScanColliders.Count;
			Collider val = itemScanCurrentCollider;
			itemScanCurrentCollider = itemScanColliders[num4];
			itemScanColliderIndex = (num4 + 1) % itemScanColliders.Count;
			itemScanBeamTimer = num2 - (float)num3 * itemScanBeamDuration;
			num = Mathf.Clamp01(itemScanBeamTimer / itemScanBeamDuration);
			if ((Object)(object)itemScanCurrentCollider != (Object)(object)val && Object.op_Implicit((Object)(object)itemScanCurrentCollider))
			{
				PlayItemScanSound(((Component)itemScanCurrentCollider).transform.position);
			}
		}
		else
		{
			itemScanCurrentCollider = null;
			itemScanBeamTimer = 0f;
		}
		Vector3 point;
		if (Object.op_Implicit((Object)(object)itemScanCurrentCollider))
		{
			point = GetItemScanPoint(itemScanCurrentCollider, num);
			if (num >= 1f - itemBeamIntroOutroFraction)
			{
				return;
			}
		}
		else
		{
			point = itemReactObject.centerPoint;
		}
		itemScanLineBetweenTwoPoints.DrawLineAnimated(shopkeeperFacePoint.position, point);
	}

	private void PlayItemScanSound(Vector3 _position)
	{
		//IL_0031: Unknown result type (might be due to invalid IL or missing references)
		//IL_0034: Unknown result type (might be due to invalid IL or missing references)
		//IL_003a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0023: Unknown result type (might be due to invalid IL or missing references)
		if (SemiFunc.IsMasterClientOrSingleplayer())
		{
			if (SemiFunc.IsMultiplayer())
			{
				photonView.RPC("ItemScanSoundRPC", (RpcTarget)0, new object[1] { _position });
			}
			else
			{
				ItemScanSoundRPC(_position);
			}
		}
	}

	[PunRPC]
	private void ItemScanSoundRPC(Vector3 _position, PhotonMessageInfo _info = default(PhotonMessageInfo))
	{
		//IL_0000: Unknown result type (might be due to invalid IL or missing references)
		//IL_000f: Unknown result type (might be due to invalid IL or missing references)
		if (SemiFunc.MasterOnlyRPC(_info))
		{
			itemScanSound.Play(_position);
		}
	}

	private void LookAtItemReactTarget()
	{
		//IL_0033: Unknown result type (might be due to invalid IL or missing references)
		//IL_0038: Unknown result type (might be due to invalid IL or missing references)
		//IL_0053: Unknown result type (might be due to invalid IL or missing references)
		//IL_0058: Unknown result type (might be due to invalid IL or missing references)
		//IL_007f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0091: Unknown result type (might be due to invalid IL or missing references)
		//IL_008c: Unknown result type (might be due to invalid IL or missing references)
		//IL_00af: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b6: Unknown result type (might be due to invalid IL or missing references)
		//IL_00bb: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c0: Unknown result type (might be due to invalid IL or missing references)
		//IL_010e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0115: Unknown result type (might be due to invalid IL or missing references)
		//IL_011a: Unknown result type (might be due to invalid IL or missing references)
		//IL_011f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0124: Unknown result type (might be due to invalid IL or missing references)
		//IL_00db: Unknown result type (might be due to invalid IL or missing references)
		//IL_00dc: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e1: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ee: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f8: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f9: Unknown result type (might be due to invalid IL or missing references)
		//IL_00fe: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a9: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ae: Unknown result type (might be due to invalid IL or missing references)
		//IL_0133: Unknown result type (might be due to invalid IL or missing references)
		//IL_0134: Unknown result type (might be due to invalid IL or missing references)
		//IL_0139: Unknown result type (might be due to invalid IL or missing references)
		//IL_013d: Unknown result type (might be due to invalid IL or missing references)
		//IL_017f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0184: Unknown result type (might be due to invalid IL or missing references)
		if (!ItemTargetValid())
		{
			return;
		}
		if (currentState == State.ScanObject || currentState == State.Verdict)
		{
			rotationTargetX = Quaternion.Euler(itemScanAim.x, 0f, 0f);
			rotationTargetY = Quaternion.Euler(0f, itemScanAim.y, 0f);
			return;
		}
		Vector3 val = ((ItemControlState(currentState) && Object.op_Implicit((Object)(object)playerPoint)) ? playerPoint.position : itemReactObject.centerPoint);
		if (ItemMeleeAttackState(currentState) && ItemReactPlayerValid())
		{
			val = ItemReactPlayerPositionGet();
		}
		Vector3 val2 = val - aimHorizontal.position;
		val2.y = 0f;
		if (val2.sqrMagnitude > 0.25f)
		{
			Quaternion val3 = Quaternion.LookRotation(val2);
			rotationTargetY = Quaternion.Inverse(aimHorizontal.parent.rotation) * val3;
		}
		Vector3 val4 = aimVertical.parent.InverseTransformDirection(val - aimVertical.position);
		if (val4.sqrMagnitude > 0.0001f)
		{
			Quaternion val5 = Quaternion.LookRotation(val4);
			float num = val5.eulerAngles.x;
			if (num > 180f)
			{
				num -= 360f;
			}
			num = Mathf.Clamp(num, 0f - itemLookPitchMax, itemLookPitchMax);
			rotationTargetX = Quaternion.Euler(num, 0f, 0f);
		}
	}

	private void DragItemLogic()
	{
		//IL_03a5: Unknown result type (might be due to invalid IL or missing references)
		//IL_03aa: Unknown result type (might be due to invalid IL or missing references)
		//IL_03ac: Unknown result type (might be due to invalid IL or missing references)
		//IL_03b1: Unknown result type (might be due to invalid IL or missing references)
		//IL_03b3: Unknown result type (might be due to invalid IL or missing references)
		//IL_03c4: Unknown result type (might be due to invalid IL or missing references)
		//IL_03c9: Unknown result type (might be due to invalid IL or missing references)
		//IL_03cc: Unknown result type (might be due to invalid IL or missing references)
		//IL_03cd: Unknown result type (might be due to invalid IL or missing references)
		//IL_03d8: Unknown result type (might be due to invalid IL or missing references)
		//IL_03da: Unknown result type (might be due to invalid IL or missing references)
		//IL_03df: Unknown result type (might be due to invalid IL or missing references)
		//IL_03e4: Unknown result type (might be due to invalid IL or missing references)
		//IL_03e8: Unknown result type (might be due to invalid IL or missing references)
		//IL_03ed: Unknown result type (might be due to invalid IL or missing references)
		//IL_03f4: Unknown result type (might be due to invalid IL or missing references)
		//IL_03fb: Unknown result type (might be due to invalid IL or missing references)
		//IL_0400: Unknown result type (might be due to invalid IL or missing references)
		//IL_0403: Unknown result type (might be due to invalid IL or missing references)
		//IL_040b: Unknown result type (might be due to invalid IL or missing references)
		//IL_032a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0330: Unknown result type (might be due to invalid IL or missing references)
		//IL_0336: Unknown result type (might be due to invalid IL or missing references)
		//IL_0347: Unknown result type (might be due to invalid IL or missing references)
		//IL_034c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0350: Unknown result type (might be due to invalid IL or missing references)
		//IL_0352: Unknown result type (might be due to invalid IL or missing references)
		//IL_0364: Unknown result type (might be due to invalid IL or missing references)
		//IL_036a: Unknown result type (might be due to invalid IL or missing references)
		//IL_036f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0374: Unknown result type (might be due to invalid IL or missing references)
		//IL_0378: Unknown result type (might be due to invalid IL or missing references)
		//IL_0383: Unknown result type (might be due to invalid IL or missing references)
		//IL_0388: Unknown result type (might be due to invalid IL or missing references)
		//IL_038b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0393: Unknown result type (might be due to invalid IL or missing references)
		//IL_0153: Unknown result type (might be due to invalid IL or missing references)
		//IL_0164: Unknown result type (might be due to invalid IL or missing references)
		//IL_0169: Unknown result type (might be due to invalid IL or missing references)
		//IL_016e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0171: Unknown result type (might be due to invalid IL or missing references)
		//IL_0176: Unknown result type (might be due to invalid IL or missing references)
		//IL_0179: Unknown result type (might be due to invalid IL or missing references)
		//IL_018a: Unknown result type (might be due to invalid IL or missing references)
		//IL_018f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0193: Unknown result type (might be due to invalid IL or missing references)
		//IL_0195: Unknown result type (might be due to invalid IL or missing references)
		//IL_01a6: Unknown result type (might be due to invalid IL or missing references)
		//IL_01b1: Unknown result type (might be due to invalid IL or missing references)
		//IL_01b6: Unknown result type (might be due to invalid IL or missing references)
		//IL_01b9: Unknown result type (might be due to invalid IL or missing references)
		//IL_01c1: Unknown result type (might be due to invalid IL or missing references)
		//IL_01e0: Unknown result type (might be due to invalid IL or missing references)
		//IL_01eb: Unknown result type (might be due to invalid IL or missing references)
		//IL_01f0: Unknown result type (might be due to invalid IL or missing references)
		//IL_01f5: Unknown result type (might be due to invalid IL or missing references)
		//IL_01f9: Unknown result type (might be due to invalid IL or missing references)
		//IL_01fe: Unknown result type (might be due to invalid IL or missing references)
		//IL_0233: Unknown result type (might be due to invalid IL or missing references)
		//IL_023b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0240: Unknown result type (might be due to invalid IL or missing references)
		//IL_024b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0250: Unknown result type (might be due to invalid IL or missing references)
		//IL_0257: Unknown result type (might be due to invalid IL or missing references)
		//IL_025c: Unknown result type (might be due to invalid IL or missing references)
		//IL_025f: Unknown result type (might be due to invalid IL or missing references)
		//IL_026a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0273: Unknown result type (might be due to invalid IL or missing references)
		//IL_027e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0285: Unknown result type (might be due to invalid IL or missing references)
		//IL_0291: Unknown result type (might be due to invalid IL or missing references)
		//IL_0296: Unknown result type (might be due to invalid IL or missing references)
		//IL_0214: Unknown result type (might be due to invalid IL or missing references)
		//IL_0219: Unknown result type (might be due to invalid IL or missing references)
		//IL_02c3: Unknown result type (might be due to invalid IL or missing references)
		//IL_02c7: Unknown result type (might be due to invalid IL or missing references)
		//IL_02cd: Unknown result type (might be due to invalid IL or missing references)
		//IL_02b3: Unknown result type (might be due to invalid IL or missing references)
		if (!ItemControlState(currentState) || !ItemTargetValid() || !SemiFunc.IsMasterClientOrSingleplayer())
		{
			return;
		}
		Rigidbody rb = itemReactObject.rb;
		itemReactObject.OverrideGrabDisable(0.25f);
		itemReactObject.OverrideIndestructible(0.25f);
		itemReactObject.OverrideZeroGravity();
		if (ItemMeleeAttackState(currentState))
		{
			if (!ItemMeleeAttackValid())
			{
				return;
			}
			ItemMeleePhysicsOverrideApply();
			if (currentState != State.NegativeMeleeSwing)
			{
				itemReactMelee.OverrideSwingDisable(0.25f);
			}
			if (!stateImpulse)
			{
				if (currentState == State.NegativeMeleeGrab)
				{
					ItemMeleeGrabLogic();
				}
				else if (currentState == State.NegativeMeleeWindup)
				{
					ItemMeleeWindupLogic();
				}
				else if (currentState == State.NegativeMeleeSwing)
				{
					ItemMeleeSwingLogic();
				}
			}
			return;
		}
		if (Object.op_Implicit((Object)(object)itemReactMelee) && currentState != State.NegativeMeleeSwing)
		{
			itemReactMelee.OverrideSwingDisable(0.25f);
		}
		Vector3 val2;
		if (currentState == State.NegativeShakeToss)
		{
			if (stateImpulse)
			{
				return;
			}
			float num = 1.5f - stateTimer;
			float num2 = 1f;
			if (num < num2)
			{
				float num3 = Mathf.Sin(num * itemShakeFrequency * MathF.PI * 2f) * itemShakeAmplitude;
				Vector3 targetPosition = playerPoint.position + new Vector3(0f, num3, 0f);
				Vector3 velocityChange = SemiFunc.PhysFollowPosition(rb.position, targetPosition, rb.linearVelocity, ItemGrabWeightMaxSpeed(itemShakeMaxSpeed));
				rb.AddForce(ItemGrabWeightImpulse(velocityChange), (ForceMode)1);
				Vector3 val = SemiFunc.PhysFollowDirection(((Component)rb).transform, Random.insideUnitSphere, rb, 12f);
				rb.AddTorque(val / rb.mass, (ForceMode)0);
			}
			else if (!itemTossApplied)
			{
				itemTossApplied = true;
				val2 = rb.position - ((Component)this).transform.position;
				Vector3 val3 = val2.normalized;
				if (val3.sqrMagnitude < 0.001f)
				{
					val3 = ((Component)this).transform.forward;
				}
				float num4 = Mathf.Lerp(1f, itemTossHeavyMultiplier, ItemWeightLerp());
				Vector3 val4 = (val3 * itemTossOutForce + Vector3.up * itemTossOutUp) * num4;
				rb.linearVelocity = Vector3.zero;
				rb.AddForce(val4, (ForceMode)2);
				rb.AddTorque(Random.insideUnitSphere * itemTossOutForce * num4, (ForceMode)2);
				Vector3 position = rb.position;
				if (SemiFunc.IsMultiplayer())
				{
					photonView.RPC("ItemTossSoundRPC", (RpcTarget)0, new object[1] { position });
				}
				else
				{
					ItemTossSoundRPC(position);
				}
				EndItemReactionSilent();
				UpdateState(State.Observe);
			}
		}
		else if (currentState == State.PositivePlay)
		{
			itemPlaySwingTimer -= Time.deltaTime;
			if (itemPlaySwingTimer <= 0f)
			{
				itemPlaySwingTimer = Random.Range(0.3f, 0.8f);
				PickNewPlaySwingTarget();
			}
			Vector3 velocityChange2 = SemiFunc.PhysFollowPosition(rb.position, itemPlaySwingTarget, rb.linearVelocity, ItemGrabWeightMaxSpeed(itemPlaySwingMaxSpeed));
			rb.AddForce(ItemGrabWeightImpulse(velocityChange2), (ForceMode)1);
			Transform transform = ((Component)rb).transform;
			val2 = itemPlaySwingTarget - rb.position;
			Vector3 val5 = SemiFunc.PhysFollowDirection(transform, val2.normalized, rb, 10f);
			rb.AddTorque(val5 / rb.mass, (ForceMode)0);
		}
		else
		{
			Vector3 position2 = playerPoint.position;
			Vector3 velocityChange3 = SemiFunc.PhysFollowPosition(rb.position, position2, rb.linearVelocity, ItemGrabWeightMaxSpeed(itemFollowMaxSpeed));
			rb.AddForce(ItemGrabWeightImpulse(velocityChange3), (ForceMode)1);
			val2 = position2 - rb.position;
			Vector3 normalized = val2.normalized;
			Vector3 val6 = SemiFunc.PhysFollowDirection(((Component)rb).transform, normalized, rb, 10f);
			rb.AddTorque(val6 / rb.mass, (ForceMode)0);
		}
	}

	private bool ItemMeleeContactGet(float _predictionTime, out Vector3 _gripTarget, out Vector3 _contactDirection)
	{
		//IL_0001: Unknown result type (might be due to invalid IL or missing references)
		//IL_0006: Unknown result type (might be due to invalid IL or missing references)
		//IL_000c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0011: Unknown result type (might be due to invalid IL or missing references)
		//IL_0040: Unknown result type (might be due to invalid IL or missing references)
		//IL_0045: Unknown result type (might be due to invalid IL or missing references)
		//IL_0046: Unknown result type (might be due to invalid IL or missing references)
		//IL_0048: Unknown result type (might be due to invalid IL or missing references)
		//IL_005e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0063: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0071: Unknown result type (might be due to invalid IL or missing references)
		//IL_0076: Unknown result type (might be due to invalid IL or missing references)
		//IL_007b: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ca: Unknown result type (might be due to invalid IL or missing references)
		//IL_00cf: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d4: Unknown result type (might be due to invalid IL or missing references)
		//IL_00eb: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f6: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ae: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a1: Unknown result type (might be due to invalid IL or missing references)
		//IL_010c: Unknown result type (might be due to invalid IL or missing references)
		//IL_010e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0114: Unknown result type (might be due to invalid IL or missing references)
		//IL_0119: Unknown result type (might be due to invalid IL or missing references)
		//IL_011e: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b3: Unknown result type (might be due to invalid IL or missing references)
		_gripTarget = Vector3.zero;
		_contactDirection = Vector3.zero;
		if (!Object.op_Implicit((Object)(object)playerPoint) || !Object.op_Implicit((Object)(object)itemMeleeGripPoint) || !Object.op_Implicit((Object)(object)itemMeleeSwingPoint))
		{
			return false;
		}
		Vector3 val = ItemReactPlayerPositionGet();
		val += ItemReactPlayerVelocityGet() * Mathf.Clamp(_predictionTime, 0f, itemMeleePredictionMax);
		_contactDirection = val - playerPoint.position;
		if (_contactDirection.sqrMagnitude <= 0.0001f)
		{
			_contactDirection = (Object.op_Implicit((Object)(object)shopkeeperFacePoint) ? shopkeeperFacePoint.up : ((Component)this).transform.forward);
		}
		_contactDirection.Normalize();
		Vector3 val2 = ((Component)itemReactObject).transform.TransformVector(itemMeleeHitLocalDirection);
		float num = val2.magnitude;
		if (num <= 0.05f)
		{
			num = Vector3.Distance(itemMeleeGripPoint.position, itemMeleeSwingPoint.position);
		}
		if (num <= 0.05f)
		{
			return false;
		}
		_gripTarget = val - _contactDirection * num;
		return true;
	}

	private void ItemMeleeGrabLogic()
	{
		//IL_0020: Unknown result type (might be due to invalid IL or missing references)
		//IL_0025: Unknown result type (might be due to invalid IL or missing references)
		//IL_002a: Unknown result type (might be due to invalid IL or missing references)
		//IL_002b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0030: Unknown result type (might be due to invalid IL or missing references)
		//IL_0038: Unknown result type (might be due to invalid IL or missing references)
		//IL_003d: Unknown result type (might be due to invalid IL or missing references)
		if (ItemMeleeContactGet(0f, out var _, out var _contactDirection))
		{
			Vector3 hitDirection = Quaternion.AngleAxis((0f - itemMeleeWindupAngle) * itemMeleeSwingDirection, Vector3.up) * _contactDirection;
			ItemMeleePoseFollow(playerPoint.position, hitDirection, itemFollowMaxSpeed);
		}
	}

	private void ItemMeleeWindupLogic()
	{
		//IL_0060: Unknown result type (might be due to invalid IL or missing references)
		//IL_0065: Unknown result type (might be due to invalid IL or missing references)
		//IL_006a: Unknown result type (might be due to invalid IL or missing references)
		//IL_006c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0071: Unknown result type (might be due to invalid IL or missing references)
		//IL_0074: Unknown result type (might be due to invalid IL or missing references)
		//IL_0076: Unknown result type (might be due to invalid IL or missing references)
		float num = Mathf.Lerp(itemMeleeSwingDurationLight, itemMeleeSwingDurationHeavy, ItemWeightLerp());
		float num2 = Mathf.Max(0.001f, itemMeleeWindupAngle + itemMeleeFollowThroughAngle);
		float num3 = itemMeleeWindupAngle / num2;
		float predictionTime = stateTimer + num * num3;
		if (ItemMeleeContactGet(predictionTime, out var _gripTarget, out var _contactDirection))
		{
			Vector3 hitDirection = Quaternion.AngleAxis((0f - itemMeleeWindupAngle) * itemMeleeSwingDirection, Vector3.up) * _contactDirection;
			ItemMeleePoseFollow(_gripTarget, hitDirection, itemMeleeWindupMaxSpeed);
		}
	}

	private void ItemMeleeSwingLogic()
	{
		//IL_001d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0027: Unknown result type (might be due to invalid IL or missing references)
		//IL_0033: Unknown result type (might be due to invalid IL or missing references)
		//IL_003d: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ad: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b2: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b7: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b9: Unknown result type (might be due to invalid IL or missing references)
		//IL_00be: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c1: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c2: Unknown result type (might be due to invalid IL or missing references)
		Rigidbody rb = itemReactObject.rb;
		if (itemMeleeSwingImpulse)
		{
			itemMeleeSwingImpulse = false;
			rb.linearVelocity *= 0.25f;
			rb.angularVelocity *= 0.25f;
		}
		float num = Mathf.Clamp01((itemMeleeSwingDuration - stateTimer) / Mathf.Max(0.01f, itemMeleeSwingDuration));
		float predictionTime = Mathf.Max(0f, itemMeleeSwingContactFraction - num) * itemMeleeSwingDuration;
		if (ItemMeleeContactGet(predictionTime, out var _gripTarget, out var _contactDirection))
		{
			Vector3 hitDirection = Quaternion.AngleAxis(Mathf.Lerp(0f - itemMeleeWindupAngle, itemMeleeFollowThroughAngle, num) * itemMeleeSwingDirection, Vector3.up) * _contactDirection;
			ItemMeleePoseFollow(_gripTarget, hitDirection, itemMeleeSwingMaxSpeed);
		}
	}

	private void ItemMeleePoseFollow(Vector3 _gripTarget, Vector3 _hitDirection, float _maxSpeed)
	{
		//IL_0012: Unknown result type (might be due to invalid IL or missing references)
		//IL_0017: Unknown result type (might be due to invalid IL or missing references)
		//IL_0019: Unknown result type (might be due to invalid IL or missing references)
		//IL_001a: Unknown result type (might be due to invalid IL or missing references)
		//IL_001f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0020: Unknown result type (might be due to invalid IL or missing references)
		//IL_0021: Unknown result type (might be due to invalid IL or missing references)
		//IL_0022: Unknown result type (might be due to invalid IL or missing references)
		//IL_002a: Unknown result type (might be due to invalid IL or missing references)
		//IL_002f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0032: Unknown result type (might be due to invalid IL or missing references)
		//IL_0033: Unknown result type (might be due to invalid IL or missing references)
		//IL_0038: Unknown result type (might be due to invalid IL or missing references)
		//IL_004b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0050: Unknown result type (might be due to invalid IL or missing references)
		//IL_0055: Unknown result type (might be due to invalid IL or missing references)
		//IL_0076: Unknown result type (might be due to invalid IL or missing references)
		//IL_007d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0082: Unknown result type (might be due to invalid IL or missing references)
		//IL_0087: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b5: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d1: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e2: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ff: Unknown result type (might be due to invalid IL or missing references)
		//IL_0128: Unknown result type (might be due to invalid IL or missing references)
		//IL_0143: Unknown result type (might be due to invalid IL or missing references)
		//IL_0148: Unknown result type (might be due to invalid IL or missing references)
		//IL_0155: Unknown result type (might be due to invalid IL or missing references)
		//IL_015a: Unknown result type (might be due to invalid IL or missing references)
		//IL_015d: Unknown result type (might be due to invalid IL or missing references)
		Rigidbody rb = itemReactObject.rb;
		Vector3 position = itemMeleeGripPoint.position;
		Vector3 pointVelocity = rb.GetPointVelocity(position);
		Vector3 velocityChange = SemiFunc.PhysFollowPosition(position, _gripTarget, pointVelocity, ItemGrabWeightMaxSpeed(_maxSpeed));
		rb.AddForceAtPosition(ItemGrabWeightImpulse(velocityChange), position, (ForceMode)1);
		Vector3 val = ((Component)itemReactObject).transform.TransformVector(itemMeleeHitLocalDirection);
		if (!(val.sqrMagnitude <= 0.0001f) && !(_hitDirection.sqrMagnitude <= 0.0001f))
		{
			Quaternion val2 = Quaternion.FromToRotation(val.normalized, _hitDirection.normalized);
			float num = default;
			Vector3 val3 = default;
			val2.ToAngleAxis(ref num, ref val3);
			if (num > 180f)
			{
				num -= 360f;
			}
			if (!(val3.sqrMagnitude <= 0.0001f) && !float.IsNaN(val3.x) && !float.IsNaN(val3.y) && !float.IsNaN(val3.z))
			{
				Vector3 val4 = val3.normalized * (num * (MathF.PI / 180f) / Mathf.Max(0.01f, Time.fixedDeltaTime));
				float num2 = ItemWeightLerp();
				float num3 = itemMeleeMaxAngularVelocity * Mathf.Lerp(1f, 0.65f, num2);
				Vector3 val5 = Vector3.ClampMagnitude(val4, num3);
				float num4 = Mathf.Lerp(itemMeleeAngularAccelerationLight, itemMeleeAngularAccelerationHeavy, num2);
				Vector3 val6 = Vector3.ClampMagnitude(val5 - rb.angularVelocity, num4 * Time.fixedDeltaTime);
				rb.AddTorque(val6, (ForceMode)2);
			}
		}
	}

	private float ItemWeightLerp()
	{
		float num = ((itemReactObject.massOriginal > 0f) ? itemReactObject.massOriginal : itemReactObject.rb.mass);
		return Mathf.InverseLerp(itemGrabLightMass, itemGrabHeavyMass, num);
	}

	private float ItemGrabWeightMaxSpeed(float _baseMaxSpeed)
	{
		return _baseMaxSpeed * Mathf.Lerp(1f, itemGrabHeavySpeedMultiplier, ItemWeightLerp());
	}

	private Vector3 ItemGrabWeightImpulse(Vector3 _velocityChange)
	{
		//IL_0073: Unknown result type (might be due to invalid IL or missing references)
		//IL_0075: Unknown result type (might be due to invalid IL or missing references)
		//IL_0081: Unknown result type (might be due to invalid IL or missing references)
		//IL_008c: Unknown result type (might be due to invalid IL or missing references)
		Rigidbody rb = itemReactObject.rb;
		float num = (ItemNegativeState(currentState) ? itemGrabAngryStrengthMultiplier : 1f);
		if (ItemMeleeAttackState(currentState))
		{
			num *= itemMeleeStrengthMultiplier;
		}
		float num2 = Mathf.Clamp01(itemGrabFollowStrength * num * Time.fixedDeltaTime);
		float num3 = itemGrabMaxAcceleration * num * Mathf.Lerp(1f, itemGrabHeavyForceMultiplier, ItemWeightLerp());
		return Vector3.ClampMagnitude(_velocityChange * num2, num3 * Time.fixedDeltaTime) * rb.mass;
	}

	[PunRPC]
	private void ItemTossSoundRPC(Vector3 _pos, PhotonMessageInfo _info = default(PhotonMessageInfo))
	{
		//IL_0000: Unknown result type (might be due to invalid IL or missing references)
		//IL_000f: Unknown result type (might be due to invalid IL or missing references)
		if (SemiFunc.MasterOnlyRPC(_info))
		{
			itemTossSound.Play(_pos);
		}
	}

	private bool ItemVerdictPositiveGet()
	{
		if (!SemiFunc.IsMasterClientOrSingleplayer())
		{
			return false;
		}
		if (!ItemTargetValid())
		{
			return false;
		}
		if (!ItemDiscountTargetValid(itemReactObject))
		{
			return false;
		}
		ShopKeeperItemReaction orAdd = ShopKeeperItemReaction.GetOrAdd(((Component)itemReactObject).gameObject);
		bool flag = Random.Range(0, 3) == 0;
		ItemShownSet(itemReactObject, orAdd.TimesShownGet() + 1, !flag);
		return flag;
	}

	private void ItemShownSet(PhysGrabObject _physGrabObject, int _timesShown, bool _disliked)
	{
		ItemShownSetLogic(_physGrabObject, _timesShown, _disliked);
		if (SemiFunc.IsMultiplayer())
		{
			photonView.RPC("ItemShownSetRPC", (RpcTarget)1, new object[3]
			{
				_physGrabObject.photonView.ViewID,
				_timesShown,
				_disliked
			});
		}
		ItemReactionSnapshotSend();
	}

	[PunRPC]
	private void ItemShownSetRPC(int _photonViewID, int _timesShown, bool _disliked, PhotonMessageInfo _info = default(PhotonMessageInfo))
	{
		//IL_0000: Unknown result type (might be due to invalid IL or missing references)
		if (!SemiFunc.MasterOnlyRPC(_info))
		{
			return;
		}
		PhotonView val = PhotonView.Find(_photonViewID);
		if (Object.op_Implicit((Object)(object)val))
		{
			PhysGrabObject component = ((Component)val).GetComponent<PhysGrabObject>();
			if (Object.op_Implicit((Object)(object)component))
			{
				ItemShownSetLogic(component, _timesShown, _disliked);
			}
		}
	}

	private void ItemShownSetLogic(PhysGrabObject _physGrabObject, int _timesShown, bool _disliked)
	{
		ShopKeeperItemReaction orAdd = ShopKeeperItemReaction.GetOrAdd(((Component)_physGrabObject).gameObject);
		orAdd.TimesShownSet(_timesShown);
		if (_disliked)
		{
			orAdd.RejectedSet();
		}
	}

	private void ItemReactionSnapshotSend()
	{
		if (!SemiFunc.IsMasterClientOrSingleplayer() || !SemiFunc.IsMultiplayer() || !PhotonNetwork.InRoom)
		{
			return;
		}
		ShopKeeperItemReaction[] array = Object.FindObjectsByType<ShopKeeperItemReaction>((FindObjectsSortMode)0);
		List<int> list = new List<int>();
		List<int> list2 = new List<int>();
		List<int> list3 = new List<int>();
		List<int> list4 = new List<int>();
		ShopKeeperItemReaction[] array2 = array;
		foreach (ShopKeeperItemReaction shopKeeperItemReaction in array2)
		{
			if (Object.op_Implicit((Object)(object)shopKeeperItemReaction))
			{
				PhysGrabObject component = ((Component)shopKeeperItemReaction).GetComponent<PhysGrabObject>();
				if (Object.op_Implicit((Object)(object)component) && Object.op_Implicit((Object)(object)component.photonView) && component.photonView.ViewID > 0)
				{
					ItemAttributes component2 = ((Component)component).GetComponent<ItemAttributes>();
					list.Add(component.photonView.ViewID);
					list2.Add(shopKeeperItemReaction.TimesShownGet());
					list3.Add((int)shopKeeperItemReaction.StateGet());
					list4.Add(Object.op_Implicit((Object)(object)component2) ? component2.value : int.MinValue);
				}
			}
		}
		int num = (Object.op_Implicit((Object)(object)ShopManager.instance) ? ShopManager.instance.totalCost : 0);
		PhotonNetwork.RemoveBufferedRPCs(photonView.ViewID, "ItemReactionSnapshotRPC", (int[])null);
		photonView.RPC("ItemReactionSnapshotRPC", (RpcTarget)3, new object[5]
		{
			list.ToArray(),
			list2.ToArray(),
			list3.ToArray(),
			list4.ToArray(),
			num
		});
	}

	[PunRPC]
	private void ItemReactionSnapshotRPC(int[] _viewIDs, int[] _timesShown, int[] _states, int[] _values, int _shopTotalCost, PhotonMessageInfo _info = default(PhotonMessageInfo))
	{
		//IL_0000: Unknown result type (might be due to invalid IL or missing references)
		if (!SemiFunc.MasterOnlyRPC(_info) || SemiFunc.IsMasterClientOrSingleplayer())
		{
			return;
		}
		itemReactionSnapshotViewIDs = _viewIDs;
		itemReactionSnapshotTimesShown = _timesShown;
		itemReactionSnapshotStates = _states;
		itemReactionSnapshotValues = _values;
		itemReactionSnapshotShopTotalCost = _shopTotalCost;
		itemReactionSnapshotRetryTimer = 0f;
		itemReactionSnapshotRetryTimeoutTimer = 5f;
		itemReactionSnapshotPendingViewIDs.Clear();
		if (_viewIDs != null)
		{
			foreach (int num in _viewIDs)
			{
				if (num > 0)
				{
					itemReactionSnapshotPendingViewIDs.Add(num);
				}
			}
		}
		ItemReactionSnapshotApply();
	}

	private void ItemReactionSnapshotApply()
	{
		if (itemReactionSnapshotViewIDs == null || itemReactionSnapshotTimesShown == null || itemReactionSnapshotStates == null || itemReactionSnapshotValues == null)
		{
			return;
		}
		if (Object.op_Implicit((Object)(object)ShopManager.instance) && itemReactionSnapshotShopTotalCost != int.MinValue)
		{
			ShopManager.instance.totalCost = itemReactionSnapshotShopTotalCost;
			itemReactionSnapshotShopTotalCost = int.MinValue;
		}
		int num = Mathf.Min(itemReactionSnapshotViewIDs.Length, Mathf.Min(itemReactionSnapshotTimesShown.Length, Mathf.Min(itemReactionSnapshotStates.Length, itemReactionSnapshotValues.Length)));
		for (int i = 0; i < num; i++)
		{
			int num2 = itemReactionSnapshotViewIDs[i];
			if (!itemReactionSnapshotPendingViewIDs.Contains(num2))
			{
				continue;
			}
			PhotonView val = PhotonView.Find(num2);
			if (!Object.op_Implicit((Object)(object)val))
			{
				continue;
			}
			PhysGrabObject physGrabObject = ((Component)val).GetComponent<PhysGrabObject>();
			if (!Object.op_Implicit((Object)(object)physGrabObject))
			{
				physGrabObject = ((Component)val).GetComponentInParent<PhysGrabObject>();
			}
			if (!Object.op_Implicit((Object)(object)physGrabObject))
			{
				physGrabObject = ((Component)val).GetComponentInChildren<PhysGrabObject>();
			}
			if (Object.op_Implicit((Object)(object)physGrabObject))
			{
				ShopKeeperItemReaction orAdd = ShopKeeperItemReaction.GetOrAdd(((Component)physGrabObject).gameObject);
				orAdd.TimesShownSet(itemReactionSnapshotTimesShown[i]);
				if (itemReactionSnapshotStates[i] >= 0 && itemReactionSnapshotStates[i] <= 2)
				{
					orAdd.StateSet((ShopKeeperItemReaction.State)itemReactionSnapshotStates[i]);
				}
				ItemAttributes component = ((Component)physGrabObject).GetComponent<ItemAttributes>();
				if (Object.op_Implicit((Object)(object)component) && itemReactionSnapshotValues[i] != int.MinValue)
				{
					component.value = itemReactionSnapshotValues[i];
				}
				itemReactionSnapshotPendingViewIDs.Remove(num2);
			}
		}
	}

	private void ItemReactionSnapshotTick()
	{
		if (itemReactionSnapshotPendingViewIDs.Count == 0 && itemReactionSnapshotShopTotalCost == int.MinValue)
		{
			return;
		}
		itemReactionSnapshotRetryTimeoutTimer -= Time.deltaTime;
		if (itemReactionSnapshotRetryTimeoutTimer <= 0f)
		{
			itemReactionSnapshotPendingViewIDs.Clear();
			itemReactionSnapshotShopTotalCost = int.MinValue;
			return;
		}
		itemReactionSnapshotRetryTimer -= Time.deltaTime;
		if (!(itemReactionSnapshotRetryTimer > 0f))
		{
			itemReactionSnapshotRetryTimer = 0.5f;
			ItemReactionSnapshotApply();
		}
	}

	private void ItemDiscountApply()
	{
		//IL_00b3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b8: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c1: Unknown result type (might be due to invalid IL or missing references)
		//IL_00fd: Unknown result type (might be due to invalid IL or missing references)
		if (!SemiFunc.IsMasterClientOrSingleplayer() || !ItemTargetValid() || !ItemDiscountTargetValid(itemReactObject))
		{
			return;
		}
		ItemAttributes component = ((Component)itemReactObject).GetComponent<ItemAttributes>();
		if (!Object.op_Implicit((Object)(object)component) || !component.shopItem)
		{
			return;
		}
		float num = Mathf.Clamp01(Mathf.Min(itemLikeDiscountRange.x, itemLikeDiscountRange.y));
		float num2 = Mathf.Clamp01(Mathf.Max(itemLikeDiscountRange.x, itemLikeDiscountRange.y));
		float discount = Random.Range(num, num2);
		int minimumValue = Mathf.CeilToInt((float)Mathf.Max(0, itemLikeDiscountMinimumValue) / 1000f);
		int num3 = component.ValueDiscount(discount, minimumValue);
		if (num3 > 0)
		{
			Vector3 centerPoint = itemReactObject.centerPoint;
			ItemDiscountLogic(itemReactObject, centerPoint, num3);
			if (SemiFunc.IsMultiplayer())
			{
				photonView.RPC("ItemDiscountRPC", (RpcTarget)1, new object[3]
				{
					itemReactObject.photonView.ViewID,
					centerPoint,
					num3
				});
			}
			ItemReactionSnapshotSend();
		}
	}

	[PunRPC]
	private void ItemDiscountRPC(int _photonViewID, Vector3 _position, int _valueLost, PhotonMessageInfo _info = default(PhotonMessageInfo))
	{
		//IL_0000: Unknown result type (might be due to invalid IL or missing references)
		//IL_002b: Unknown result type (might be due to invalid IL or missing references)
		if (!SemiFunc.MasterOnlyRPC(_info))
		{
			return;
		}
		PhotonView val = PhotonView.Find(_photonViewID);
		if (Object.op_Implicit((Object)(object)val))
		{
			PhysGrabObject component = ((Component)val).GetComponent<PhysGrabObject>();
			if (Object.op_Implicit((Object)(object)component))
			{
				ItemDiscountLogic(component, _position, _valueLost);
			}
		}
	}

	private void ItemDiscountLogic(PhysGrabObject _physGrabObject, Vector3 _position, int _valueLost)
	{
		//IL_0021: Unknown result type (might be due to invalid IL or missing references)
		ShopKeeperItemReaction.GetOrAdd(((Component)_physGrabObject).gameObject).DiscountSet();
		if (Object.op_Implicit((Object)(object)WorldSpaceUIParent.instance))
		{
			WorldSpaceUIParent.instance.ValueLostCreate(_position, _valueLost, WorldSpaceUIValueLost.Style.Discount);
		}
	}

	private void ItemDislikeAffectApply(PhysGrabObject _physGrabObject)
	{
		if (!SemiFunc.IsMasterClientOrSingleplayer() || !Object.op_Implicit((Object)(object)_physGrabObject))
		{
			return;
		}
		if (SemiFunc.IsMultiplayer())
		{
			if (Object.op_Implicit((Object)(object)PunManager.instance))
			{
				int num = PunManager.instance.SemiAffectNetworkIDGet();
				double num2 = PhotonNetwork.Time + (double)itemDislikeAffectTime;
				string text = itemDislikeAffectPrefab.ResourcePath ?? string.Empty;
				photonView.RPC("ItemDislikeAffectApplyRPC", (RpcTarget)0, new object[5]
				{
					_physGrabObject.photonView.ViewID,
					itemDislikeAffectTime,
					num,
					num2,
					text
				});
			}
		}
		else
		{
			ItemDislikeAffectApplyLogic(_physGrabObject, itemDislikeAffectTime, 0, 0.0, string.Empty);
		}
	}

	[PunRPC]
	private void ItemDislikeAffectApplyRPC(int _photonViewID, float _affectTime, int _affectID, double _endTime, string _resourcePath, PhotonMessageInfo _info = default(PhotonMessageInfo))
	{
		//IL_0000: Unknown result type (might be due to invalid IL or missing references)
		if (!SemiFunc.MasterOnlyRPC(_info))
		{
			return;
		}
		PhotonView val = PhotonView.Find(_photonViewID);
		if (Object.op_Implicit((Object)(object)val))
		{
			PhysGrabObject physGrabObject = ((Component)val).GetComponent<PhysGrabObject>();
			if (!Object.op_Implicit((Object)(object)physGrabObject))
			{
				physGrabObject = ((Component)val).GetComponentInParent<PhysGrabObject>();
			}
			if (!Object.op_Implicit((Object)(object)physGrabObject))
			{
				physGrabObject = ((Component)val).GetComponentInChildren<PhysGrabObject>();
			}
			if (Object.op_Implicit((Object)(object)physGrabObject))
			{
				ItemDislikeAffectApplyLogic(physGrabObject, _affectTime, _affectID, _endTime, _resourcePath);
			}
		}
	}

	private void ItemDislikeAffectApplyLogic(PhysGrabObject _physGrabObject, float _affectTime, int _affectID, double _endTime, string _resourcePath)
	{
		//IL_004a: Unknown result type (might be due to invalid IL or missing references)
		//IL_004f: Unknown result type (might be due to invalid IL or missing references)
		if (itemDislikeAffectPrefab != null && !((Object)(object)itemDislikeAffectPrefab.Prefab == (Object)null))
		{
			ShopKeeperItemReaction.GetOrAdd(((Component)_physGrabObject).gameObject).RejectedSet();
			if (SemiFunc.IsMasterClientOrSingleplayer())
			{
				_physGrabObject.impactHappenedTimer = 0f;
			}
			GameObject val = Object.Instantiate<GameObject>(itemDislikeAffectPrefab.Prefab, _physGrabObject.centerPoint, Quaternion.identity);
			SemiAffect component = val.GetComponent<SemiAffect>();
			if (!Object.op_Implicit((Object)(object)component))
			{
				Object.Destroy((Object)(object)val);
			}
			else if (SemiFunc.IsMultiplayer())
			{
				component.Setup(_physGrabObject.photonView.ViewID, _affectTime, _affectID, _endTime, _resourcePath);
			}
			else
			{
				component.SetupSingleplayer(((Component)_physGrabObject).transform, _physGrabObject, _affectTime);
			}
		}
	}

	private int GetRandomEmojiIndex(string[] _type)
	{
		int num = Random.Range(0, emojiTypes[emojiTypes.IndexOf(_type)].Length);
		int num2 = emojiTypes.IndexOf(_type);
		if (emojiTypes[num2].Length > 1 && prevTypeIndex == num2 && prevEmojiIndex == num)
		{
			num = ((emojiTypes[emojiTypes.IndexOf(_type)].Length - 1 <= num) ? (num - 1) : (num + 1));
		}
		return num;
	}

	private void DisplayEmoji(string _emoji = null)
	{
		string text = ((_emoji == null) ? string.Empty : ("<sprite name=" + _emoji + ">"));
		bool flag = text != currentDisplayedEmoji;
		currentDisplayedEmoji = text;
		((TMP_Text)textMesh).text = text;
		if (flag && _emoji != null)
		{
			TriggerEmojiScreenGlitch();
		}
	}

	private void TriggerEmojiScreenGlitch()
	{
		//IL_004e: Unknown result type (might be due to invalid IL or missing references)
		//IL_00bd: Unknown result type (might be due to invalid IL or missing references)
		if ((!Object.op_Implicit((Object)(object)playerTarget) || !playerTarget.isLocal || !SemiFunc.Photosensitivity()) && Object.op_Implicit((Object)(object)emojiScreenGlitch))
		{
			if (emojiScreenGlitchTimer <= 0f)
			{
				soundEmojiGlitch.Play(emojiScreenGlitch.transform.position);
			}
			emojiScreenGlitchTimer = 0.2f;
			emojiScreenGlitch.SetActive(true);
			if (Object.op_Implicit((Object)(object)textMesh))
			{
				((Behaviour)textMesh).enabled = false;
			}
			MeshRenderer component = emojiScreenGlitch.GetComponent<MeshRenderer>();
			if (Object.op_Implicit((Object)(object)component))
			{
				((Renderer)component).material.SetColor("_EmissionColor", emojiScreenGlitchColor);
			}
		}
	}

	private void EmojiScreenGlitchLogic()
	{
		//IL_003e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0043: Unknown result type (might be due to invalid IL or missing references)
		//IL_0065: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b2: Unknown result type (might be due to invalid IL or missing references)
		if (!Object.op_Implicit((Object)(object)emojiScreenGlitch) || emojiScreenGlitchTimer <= 0f)
		{
			return;
		}
		MeshRenderer component = emojiScreenGlitch.GetComponent<MeshRenderer>();
		if (Object.op_Implicit((Object)(object)component))
		{
			Vector2 textureOffset = ((Renderer)component).material.GetTextureOffset("_MainTex");
			textureOffset.y += Time.deltaTime * 15f;
			((Renderer)component).material.SetTextureOffset("_MainTex", textureOffset);
			emojiScreenGlitchScaleTimer -= Time.deltaTime;
			if (emojiScreenGlitchScaleTimer <= 0f)
			{
				emojiScreenGlitchScaleTimer = 1f / 30f;
				float num = Random.Range(0.1f, 1f);
				((Renderer)component).material.SetTextureScale("_MainTex", new Vector2(num, num));
			}
		}
		emojiScreenGlitchTimer -= Time.deltaTime;
		if (emojiScreenGlitchTimer <= 0f)
		{
			emojiScreenGlitch.SetActive(false);
			if (Object.op_Implicit((Object)(object)textMesh))
			{
				((Behaviour)textMesh).enabled = true;
			}
		}
	}

	private void LookAtPlayer()
	{
		//IL_004f: Unknown result type (might be due to invalid IL or missing references)
		//IL_005a: Unknown result type (might be due to invalid IL or missing references)
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0064: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b8: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c8: Unknown result type (might be due to invalid IL or missing references)
		//IL_00cd: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d2: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f7: Unknown result type (might be due to invalid IL or missing references)
		//IL_007f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0080: Unknown result type (might be due to invalid IL or missing references)
		//IL_0085: Unknown result type (might be due to invalid IL or missing references)
		//IL_0092: Unknown result type (might be due to invalid IL or missing references)
		//IL_0097: Unknown result type (might be due to invalid IL or missing references)
		//IL_009c: Unknown result type (might be due to invalid IL or missing references)
		//IL_009d: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a2: Unknown result type (might be due to invalid IL or missing references)
		if (Object.op_Implicit((Object)(object)playerTarget) && Object.op_Implicit((Object)(object)playerTarget.PlayerVisionTarget) && Object.op_Implicit((Object)(object)playerTarget.PlayerVisionTarget.VisionTransform))
		{
			Vector3 val = playerTarget.PlayerVisionTarget.VisionTransform.position - aimHorizontal.position;
			val.y = 0f;
			if (val.sqrMagnitude > 0.0001f)
			{
				Quaternion val2 = Quaternion.LookRotation(val);
				rotationTargetY = Quaternion.Inverse(aimHorizontal.parent.rotation) * val2;
			}
			rotationTargetX = Quaternion.LookRotation(playerTarget.PlayerVisionTarget.VisionTransform.position - aimVertical.position);
			rotationTargetX.eulerAngles = new Vector3(rotationTargetX.eulerAngles.x, 0f, 0f);
		}
	}

	private void LookAtItem()
	{
		//IL_0016: Unknown result type (might be due to invalid IL or missing references)
		//IL_0021: Unknown result type (might be due to invalid IL or missing references)
		//IL_0026: Unknown result type (might be due to invalid IL or missing references)
		//IL_002b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0075: Unknown result type (might be due to invalid IL or missing references)
		//IL_0080: Unknown result type (might be due to invalid IL or missing references)
		//IL_0085: Unknown result type (might be due to invalid IL or missing references)
		//IL_008a: Unknown result type (might be due to invalid IL or missing references)
		//IL_008f: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a0: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b4: Unknown result type (might be due to invalid IL or missing references)
		//IL_0046: Unknown result type (might be due to invalid IL or missing references)
		//IL_0047: Unknown result type (might be due to invalid IL or missing references)
		//IL_004c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0059: Unknown result type (might be due to invalid IL or missing references)
		//IL_005e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0063: Unknown result type (might be due to invalid IL or missing references)
		//IL_0064: Unknown result type (might be due to invalid IL or missing references)
		//IL_0069: Unknown result type (might be due to invalid IL or missing references)
		if (Object.op_Implicit((Object)(object)itemTarget))
		{
			Vector3 val = itemTarget.position - aimHorizontal.position;
			val.y = 0f;
			if (val.sqrMagnitude > 0.0001f)
			{
				Quaternion val2 = Quaternion.LookRotation(val);
				rotationTargetY = Quaternion.Inverse(aimHorizontal.parent.rotation) * val2;
			}
			rotationTargetX = Quaternion.LookRotation(itemTarget.position - aimVertical.position);
			rotationTargetX.eulerAngles = new Vector3(rotationTargetX.eulerAngles.x, 0f, 0f);
		}
	}

	private void UpdateGunCogTarget()
	{
		//IL_0047: Unknown result type (might be due to invalid IL or missing references)
		//IL_0052: Unknown result type (might be due to invalid IL or missing references)
		//IL_0057: Unknown result type (might be due to invalid IL or missing references)
		//IL_005c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_0069: Unknown result type (might be due to invalid IL or missing references)
		//IL_006e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0073: Unknown result type (might be due to invalid IL or missing references)
		//IL_0076: Unknown result type (might be due to invalid IL or missing references)
		//IL_009d: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a2: Unknown result type (might be due to invalid IL or missing references)
		if (Object.op_Implicit((Object)(object)playerTarget) && Object.op_Implicit((Object)(object)playerTarget.PlayerVisionTarget) && Object.op_Implicit((Object)(object)playerTarget.PlayerVisionTarget.VisionTransform))
		{
			Vector3 val = playerTarget.PlayerVisionTarget.VisionTransform.position - gunCog.position;
			Quaternion val2 = Quaternion.LookRotation(gunCog.parent.InverseTransformDirection(val));
			float num = val2.eulerAngles.x;
			if (num > 180f)
			{
				num -= 360f;
			}
			gunCogTarget = Quaternion.Euler(num, 0f, 0f);
		}
	}

	private void IdleScan()
	{
		float angleY = Random.Range(-90f, 90f);
		float angleX = Random.Range(-10f, 45f);
		SetRandomScanRotation(angleY, angleX);
	}

	private void NearestPlayerAsTarget()
	{
		//IL_0016: Unknown result type (might be due to invalid IL or missing references)
		//IL_002f: Unknown result type (might be due to invalid IL or missing references)
		if (!SemiFunc.IsMasterClientOrSingleplayer())
		{
			return;
		}
		playerTarget = SemiFunc.PlayerGetNearestPlayerAvatarWithinRange(20f, ((Component)this).transform.position, doRaycastCheck: true, LayerMask.op_Implicit(LayerMask.GetMask(new string[1] { "Default" })));
		if (Object.op_Implicit((Object)(object)playerTarget) && (Object)(object)playerTarget != (Object)(object)prevPlayerTarget)
		{
			prevPlayerTarget = playerTarget;
			if (SemiFunc.IsMultiplayer())
			{
				photonView.RPC("UpdatePlayerTargetRPC", (RpcTarget)1, new object[1] { playerTarget.photonView.ViewID });
			}
		}
	}

	private void SensorBreakers()
	{
		//IL_0043: Unknown result type (might be due to invalid IL or missing references)
		//IL_0049: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b9: Unknown result type (might be due to invalid IL or missing references)
		if (SmallSensorTimer > 0f)
		{
			SmallSensorTimer -= Time.deltaTime;
		}
		else
		{
			if (SemiFunc.IsMultiplayer())
			{
				photonView.RPC("SmallSensorBreakerRPC", (RpcTarget)0, Array.Empty<object>());
			}
			else
			{
				SmallSensorBreakerRPC();
			}
			SmallSensorTimer = Random.Range(5f, 20f);
		}
		if (BigSensorTimer > 0f)
		{
			BigSensorTimer -= Time.deltaTime;
		}
		else if (beamFromSensorTimer <= 0f)
		{
			if (SemiFunc.IsMultiplayer())
			{
				photonView.RPC("BigSensorBreakerRPC", (RpcTarget)0, Array.Empty<object>());
			}
			else
			{
				BigSensorBreakerRPC();
			}
			BigSensorTimer = Random.Range(5f, 20f);
		}
	}

	private void LineRendererLogic()
	{
		if (lineRendererActive)
		{
			lineRenderer.widthMultiplier = lineRendererWidthCurve.Evaluate(lineRendererLerp);
			lineRendererLerp += Time.deltaTime * 5f;
			if (lineRendererLerp >= 1f)
			{
				((Component)lineRenderer).gameObject.SetActive(false);
				((Component)linerendererSmall).gameObject.SetActive(false);
				lineRendererActive = false;
			}
		}
	}

	private void HurtColliderTimer()
	{
		if (hurtColliderTimer > 0f)
		{
			hurtColliderTimer -= Time.deltaTime;
			if (hurtColliderTimer <= 0f)
			{
				((Component)hurtCollider).gameObject.SetActive(false);
			}
		}
	}

	private bool PlayerTargetValid()
	{
		if (!Object.op_Implicit((Object)(object)playerTarget))
		{
			return false;
		}
		if (playerTarget.isDisabled)
		{
			return false;
		}
		if (playerTarget.deadSet)
		{
			return false;
		}
		if (playerTarget.spectating)
		{
			return false;
		}
		if (!((Component)playerTarget).gameObject.activeInHierarchy)
		{
			return false;
		}
		return true;
	}

	private Vector3 PlayerTargetCenterPos()
	{
		//IL_000d: Unknown result type (might be due to invalid IL or missing references)
		//IL_009c: Unknown result type (might be due to invalid IL or missing references)
		//IL_004c: Unknown result type (might be due to invalid IL or missing references)
		//IL_008b: Unknown result type (might be due to invalid IL or missing references)
		if (!Object.op_Implicit((Object)(object)playerTarget))
		{
			return Vector3.zero;
		}
		if (Object.op_Implicit((Object)(object)playerTarget.tumble) && Object.op_Implicit((Object)(object)playerTarget.tumble.physGrabObject))
		{
			return playerTarget.tumble.physGrabObject.centerPoint;
		}
		if (Object.op_Implicit((Object)(object)playerTarget.PlayerVisionTarget) && Object.op_Implicit((Object)(object)playerTarget.PlayerVisionTarget.VisionTransform))
		{
			return playerTarget.PlayerVisionTarget.VisionTransform.position;
		}
		return ((Component)playerTarget).transform.position;
	}

	private void ScanBeamOverride(Vector3 _target)
	{
		//IL_000b: Unknown result type (might be due to invalid IL or missing references)
		//IL_000c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0019: Unknown result type (might be due to invalid IL or missing references)
		//IL_001a: Unknown result type (might be due to invalid IL or missing references)
		scanBeamOverrideTimer = 0.1f;
		if (_target != Vector3.zero)
		{
			scanBeamOverrideTarget = _target;
		}
		scanBeamOverrideActive = true;
	}

	private void GrabBeamOverride(Vector3 _target)
	{
		//IL_000b: Unknown result type (might be due to invalid IL or missing references)
		//IL_000c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0019: Unknown result type (might be due to invalid IL or missing references)
		//IL_001a: Unknown result type (might be due to invalid IL or missing references)
		grabBeamOverrideTimer = 0.1f;
		if (_target != Vector3.zero)
		{
			grabBeamOverrideTarget = _target;
		}
		grabBeamOverrideActive = true;
		grabBeamReleaseSoundPlayed = false;
	}

	private void BeamOverridePing()
	{
		//IL_001d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0022: Unknown result type (might be due to invalid IL or missing references)
		//IL_0030: Unknown result type (might be due to invalid IL or missing references)
		//IL_006b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0070: Unknown result type (might be due to invalid IL or missing references)
		//IL_0071: Unknown result type (might be due to invalid IL or missing references)
		//IL_0072: Unknown result type (might be due to invalid IL or missing references)
		//IL_007f: Unknown result type (might be due to invalid IL or missing references)
		if ((currentState == State.SeeRuckusPlayer || currentState == State.SeeWarnPlayer) && PlayerTargetValid() && scanLightAimTarget != Vector3.zero)
		{
			ScanBeamOverride(scanLightAimTarget);
		}
		if ((currentState == State.GrabRuckusPlayer || currentState == State.JudgeRuckusPlayer || currentState == State.WarnGrabPlayer || currentState == State.WarnTellOff) && PlayerTargetValid())
		{
			Vector3 val = PlayerTargetCenterPos();
			if (val != Vector3.zero)
			{
				GrabBeamOverride(val);
			}
		}
	}

	private void BeamOverrideTick()
	{
		//IL_003f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0044: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d4: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d9: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a0: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a5: Unknown result type (might be due to invalid IL or missing references)
		//IL_00bf: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b7: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c4: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c6: Unknown result type (might be due to invalid IL or missing references)
		if (scanBeamOverrideTimer > 0f)
		{
			scanBeamOverrideTimer -= Time.deltaTime;
			if (scanBeamOverrideTimer <= 0f)
			{
				scanBeamOverrideTimer = 0f;
				scanBeamOverrideActive = false;
				scanBeamOverrideTarget = Vector3.zero;
			}
		}
		if (!(grabBeamOverrideTimer > 0f))
		{
			return;
		}
		grabBeamOverrideTimer -= Time.deltaTime;
		if (grabBeamOverrideTimer <= 0f)
		{
			grabBeamOverrideTimer = 0f;
			if (grabBeamOverrideActive && currentState != State.Shoot && currentState != State.JudgeRuckusPlayer)
			{
				Vector3 pos = ((grabBeamOverrideTarget != Vector3.zero) ? grabBeamOverrideTarget : gunTipBigTransform.position);
				PlayReleaseSoundOnce(pos);
			}
			grabBeamOverrideActive = false;
			grabBeamOverrideTarget = Vector3.zero;
		}
	}

	private void PlayReleaseSoundOnce(Vector3 _pos)
	{
		//IL_0041: Unknown result type (might be due to invalid IL or missing references)
		//IL_0044: Unknown result type (might be due to invalid IL or missing references)
		//IL_004a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0033: Unknown result type (might be due to invalid IL or missing references)
		if (grabBeamReleaseSoundPlayed)
		{
			return;
		}
		grabBeamReleaseSoundPlayed = true;
		if (SemiFunc.IsMasterClientOrSingleplayer())
		{
			if (SemiFunc.IsMultiplayer())
			{
				photonView.RPC("ReleaseSoundRPC", (RpcTarget)0, new object[1] { _pos });
			}
			else
			{
				ReleaseSoundRPC(_pos);
			}
		}
	}

	private void PlayGrabSound(Vector3 _pos)
	{
		//IL_0029: Unknown result type (might be due to invalid IL or missing references)
		//IL_002c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0032: Unknown result type (might be due to invalid IL or missing references)
		//IL_001b: Unknown result type (might be due to invalid IL or missing references)
		if (SemiFunc.IsMultiplayer())
		{
			photonView.RPC("GrabSoundRPC", (RpcTarget)0, new object[1] { _pos });
		}
		else
		{
			GrabSoundRPC(_pos);
		}
	}

	[PunRPC]
	private void ReleaseSoundRPC(Vector3 _pos, PhotonMessageInfo _info = default(PhotonMessageInfo))
	{
		//IL_0000: Unknown result type (might be due to invalid IL or missing references)
		//IL_000f: Unknown result type (might be due to invalid IL or missing references)
		if (SemiFunc.MasterOnlyRPC(_info))
		{
			releaseSound.Play(_pos);
		}
	}

	[PunRPC]
	private void GrabSoundRPC(Vector3 _pos, PhotonMessageInfo _info = default(PhotonMessageInfo))
	{
		//IL_0000: Unknown result type (might be due to invalid IL or missing references)
		//IL_000f: Unknown result type (might be due to invalid IL or missing references)
		if (SemiFunc.MasterOnlyRPC(_info))
		{
			grabSound.Play(_pos);
		}
	}

	private void BeamFromSensor()
	{
		beamFromSensorTimer = 0.1f;
	}

	private void BeamFromSensorTick()
	{
		if (beamFromSensorTimer > 0f)
		{
			beamFromSensorTimer -= Time.deltaTime;
		}
	}

	private void LineBetweenTwoPointsLogic()
	{
		//IL_0085: Unknown result type (might be due to invalid IL or missing references)
		//IL_008b: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c6: Unknown result type (might be due to invalid IL or missing references)
		//IL_00cc: Unknown result type (might be due to invalid IL or missing references)
		//IL_0099: Unknown result type (might be due to invalid IL or missing references)
		//IL_009e: Unknown result type (might be due to invalid IL or missing references)
		//IL_00aa: Unknown result type (might be due to invalid IL or missing references)
		//IL_01f6: Unknown result type (might be due to invalid IL or missing references)
		//IL_01ee: Unknown result type (might be due to invalid IL or missing references)
		//IL_007a: Unknown result type (might be due to invalid IL or missing references)
		//IL_007f: Unknown result type (might be due to invalid IL or missing references)
		//IL_01fb: Unknown result type (might be due to invalid IL or missing references)
		//IL_01fe: Unknown result type (might be due to invalid IL or missing references)
		//IL_0203: Unknown result type (might be due to invalid IL or missing references)
		//IL_0222: Unknown result type (might be due to invalid IL or missing references)
		//IL_0227: Unknown result type (might be due to invalid IL or missing references)
		//IL_020d: Unknown result type (might be due to invalid IL or missing references)
		//IL_020f: Unknown result type (might be due to invalid IL or missing references)
		//IL_021a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0245: Unknown result type (might be due to invalid IL or missing references)
		//IL_024b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0150: Unknown result type (might be due to invalid IL or missing references)
		//IL_0155: Unknown result type (might be due to invalid IL or missing references)
		//IL_015c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0161: Unknown result type (might be due to invalid IL or missing references)
		//IL_0183: Unknown result type (might be due to invalid IL or missing references)
		//IL_0188: Unknown result type (might be due to invalid IL or missing references)
		//IL_0168: Unknown result type (might be due to invalid IL or missing references)
		//IL_016d: Unknown result type (might be due to invalid IL or missing references)
		//IL_01a4: Unknown result type (might be due to invalid IL or missing references)
		//IL_01a9: Unknown result type (might be due to invalid IL or missing references)
		//IL_0191: Unknown result type (might be due to invalid IL or missing references)
		//IL_0192: Unknown result type (might be due to invalid IL or missing references)
		//IL_019d: Unknown result type (might be due to invalid IL or missing references)
		//IL_017c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0174: Unknown result type (might be due to invalid IL or missing references)
		//IL_01ca: Unknown result type (might be due to invalid IL or missing references)
		//IL_01d0: Unknown result type (might be due to invalid IL or missing references)
		//IL_0181: Unknown result type (might be due to invalid IL or missing references)
		if (!Object.op_Implicit((Object)(object)lineBetweenTwoPoints) || !Object.op_Implicit((Object)(object)lineStartPoint))
		{
			return;
		}
		if (itemDenyBeamTimer > 0f)
		{
			itemDenyBeamTimer = Mathf.Max(0f, itemDenyBeamTimer - Time.deltaTime);
			if (Object.op_Implicit((Object)(object)itemDenyBeamTarget) && !itemDenyBeamTarget.dead && ((Component)itemDenyBeamTarget).gameObject.activeInHierarchy)
			{
				itemDenyBeamPosition = itemDenyBeamTarget.centerPoint;
			}
			if (lineColorCurrent != itemDenyBeamColor)
			{
				lineColorCurrent = itemDenyBeamColor;
				lineBetweenTwoPoints.SetColor(itemDenyBeamColor);
			}
			BeamFromSensor();
			lineBetweenTwoPoints.DrawLineAnimated(lineStartPoint.position, itemDenyBeamPosition);
			if (itemDenyBeamTimer <= 0f)
			{
				itemDenyBeamTarget = null;
			}
		}
		else if (grabBeamOverrideActive)
		{
			bool flag = currentState == State.WarnGrabPlayer || currentState == State.WarnTellOff;
			bool flag2 = currentState == State.ScanObject || currentState == State.Verdict;
			bool num = currentState == State.PositiveGrab || currentState == State.PositivePlay;
			bool flag3 = ItemNegativeState(currentState);
			Color val;
			if (num)
			{
				val = itemBeamColorPositive;
			}
			else if (flag3)
			{
				val = itemBeamColorNegative;
			}
			else if (flag2)
			{
				val = itemBeamColorHoldScan;
			}
			else
			{
				val = (flag ? lineColorWarning : lineColorGrab);
			}
			if (lineColorCurrent != val)
			{
				lineColorCurrent = val;
				lineBetweenTwoPoints.SetColor(val);
			}
			if (grabBeamOverrideTarget != Vector3.zero)
			{
				BeamFromSensor();
				lineBetweenTwoPoints.DrawLineAnimated(lineStartPoint.position, grabBeamOverrideTarget);
			}
		}
		else if (scanBeamOverrideActive)
		{
			Color val2 = ((currentState == State.SeeWarnPlayer) ? lineColorWarning : lineColorSee);
			if (lineColorCurrent != val2)
			{
				lineColorCurrent = val2;
				lineBetweenTwoPoints.SetColor(val2);
			}
			if (scanBeamOverrideTarget != Vector3.zero)
			{
				BeamFromSensor();
				lineBetweenTwoPoints.DrawLineAnimated(lineStartPoint.position, scanBeamOverrideTarget);
			}
		}
	}

	private void PlayerEyesOverrideLogic()
	{
		//IL_0026: Unknown result type (might be due to invalid IL or missing references)
		//IL_001e: Unknown result type (might be due to invalid IL or missing references)
		//IL_002b: Unknown result type (might be due to invalid IL or missing references)
		//IL_004c: Unknown result type (might be due to invalid IL or missing references)
		//IL_003f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0051: Unknown result type (might be due to invalid IL or missing references)
		//IL_007b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0086: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e2: Unknown result type (might be due to invalid IL or missing references)
		//IL_00cd: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b1: Unknown result type (might be due to invalid IL or missing references)
		//IL_01c7: Unknown result type (might be due to invalid IL or missing references)
		//IL_0175: Unknown result type (might be due to invalid IL or missing references)
		//IL_017a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0166: Unknown result type (might be due to invalid IL or missing references)
		//IL_016b: Unknown result type (might be due to invalid IL or missing references)
		//IL_014a: Unknown result type (might be due to invalid IL or missing references)
		//IL_014f: Unknown result type (might be due to invalid IL or missing references)
		//IL_01f9: Unknown result type (might be due to invalid IL or missing references)
		//IL_0181: Unknown result type (might be due to invalid IL or missing references)
		if (!IsReactiveOrAggressiveState())
		{
			return;
		}
		bool flag = IsGrabbingPlayerState() && PlayerTargetValid();
		Vector3 position = (flag ? PlayerTargetCenterPos() : Vector3.zero);
		Vector3 position2 = (Object.op_Implicit((Object)(object)shopkeeperFacePoint) ? shopkeeperFacePoint.position : ((Component)this).transform.position);
		foreach (PlayerAvatar item in SemiFunc.PlayerGetList())
		{
			if (Object.op_Implicit((Object)(object)item) && !(Vector3.Distance(((Component)item).transform.position, ((Component)this).transform.position) > 15f))
			{
				if (flag && (Object)(object)item == (Object)(object)playerTarget)
				{
					SemiFunc.PlayerEyesOverride(item, gunTipBigTransform.position, 0.1f, ((Component)this).gameObject);
				}
				else if (flag)
				{
					SemiFunc.PlayerEyesOverride(item, position, 0.1f, ((Component)this).gameObject);
				}
				else
				{
					SemiFunc.PlayerEyesOverride(item, position2, 0.1f, ((Component)this).gameObject);
				}
			}
		}
		if (PlayerTargetValid() && playerTarget.isLocal)
		{
			if (currentState == State.WarnTellOff)
			{
				Vector3 position3;
				if (warnTellOffOnEmojiScreen && Object.op_Implicit((Object)(object)lookAtEmojiHereTransform))
				{
					position3 = lookAtEmojiHereTransform.position;
				}
				else
				{
					position3 = ((!Object.op_Implicit((Object)(object)shopkeeperFacePoint)) ? gunTipBigTransform.position : shopkeeperFacePoint.position);
				}
				CameraAim.Instance.AimTargetSet(position3, 0.1f, 5f, ((Component)this).gameObject, 100);
			}
			else if ((currentState == State.GrabRuckusPlayer || currentState == State.WarnGrabPlayer) && Object.op_Implicit((Object)(object)shopkeeperFacePoint))
			{
				CameraAim.Instance.AimTargetSet(shopkeeperFacePoint.position, 0.1f, 5f, ((Component)this).gameObject, 100);
			}
			else if (currentState == State.JudgeRuckusPlayer)
			{
				CameraAim.Instance.AimTargetSet(gunTipBigTransform.position, 0.1f, 5f, ((Component)this).gameObject, 100);
			}
		}
	}

	private bool IsReactiveOrAggressiveState()
	{
		if (currentState != State.Hurt && currentState != State.Shock && currentState != State.Flash && currentState != State.Aim && currentState != State.Shoot && currentState != State.WaitForRuckusPlayer && currentState != State.SeeRuckusPlayer && currentState != State.SeeWarnPlayer && currentState != State.GrabRuckusPlayer && currentState != State.JudgeRuckusPlayer && currentState != State.AngryObservation && currentState != State.WarnGrabPlayer)
		{
			return currentState == State.WarnTellOff;
		}
		return true;
	}

	private bool IsGrabbingPlayerState()
	{
		if (currentState != State.GrabRuckusPlayer && currentState != State.JudgeRuckusPlayer && currentState != State.WarnGrabPlayer)
		{
			return currentState == State.WarnTellOff;
		}
		return true;
	}

	private void GrabLoopLogic()
	{
		//IL_001a: Unknown result type (might be due to invalid IL or missing references)
		//IL_001f: Unknown result type (might be due to invalid IL or missing references)
		//IL_003e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0036: Unknown result type (might be due to invalid IL or missing references)
		//IL_0043: Unknown result type (might be due to invalid IL or missing references)
		//IL_00de: Unknown result type (might be due to invalid IL or missing references)
		//IL_0060: Unknown result type (might be due to invalid IL or missing references)
		//IL_0065: Unknown result type (might be due to invalid IL or missing references)
		//IL_0101: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b6: Unknown result type (might be due to invalid IL or missing references)
		//IL_0113: Unknown result type (might be due to invalid IL or missing references)
		//IL_0114: Unknown result type (might be due to invalid IL or missing references)
		//IL_0115: Unknown result type (might be due to invalid IL or missing references)
		//IL_010e: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d2: Unknown result type (might be due to invalid IL or missing references)
		//IL_00cd: Unknown result type (might be due to invalid IL or missing references)
		if (!Object.op_Implicit((Object)(object)grabLoopSource))
		{
			return;
		}
		if (grabBeamOverrideActive)
		{
			Vector3 val = ((grabBeamOverrideTarget != Vector3.zero) ? grabBeamOverrideTarget : ((Component)grabLoopSource).transform.position);
			if (ItemControlState(currentState))
			{
				if (ItemTargetValid())
				{
					val = itemReactObject.centerPoint;
				}
			}
			else if (Object.op_Implicit((Object)(object)playerTarget))
			{
				val = ((playerTarget.isTumbling && Object.op_Implicit((Object)(object)playerTarget.tumble) && Object.op_Implicit((Object)(object)playerTarget.tumble.rb)) ? playerTarget.tumble.rb.position : ((Component)playerTarget).transform.position);
			}
			((Component)grabLoopSource).transform.position = val;
			Vector3 val2 = ((currentState == State.JudgeRuckusPlayer && Object.op_Implicit((Object)(object)playerPoint2)) ? playerPoint2.position : playerPoint.position);
			float num = Mathf.Clamp01(Vector3.Distance(val, val2) / grabInitialDistance);
			float pitchMultiplier = Mathf.Lerp(grabLoopPitchMax, grabLoopPitchMin, num);
			grabLoop.PlayLoop(playing: true, 10f, 10f, pitchMultiplier);
		}
		else
		{
			grabLoop.PlayLoop(playing: false, 10f, 10f);
		}
	}

	private void JudgeChargeLogic()
	{
		//IL_0146: Unknown result type (might be due to invalid IL or missing references)
		//IL_014c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0157: Unknown result type (might be due to invalid IL or missing references)
		//IL_02bd: Unknown result type (might be due to invalid IL or missing references)
		//IL_02c2: Unknown result type (might be due to invalid IL or missing references)
		//IL_02c9: Unknown result type (might be due to invalid IL or missing references)
		//IL_02ce: Unknown result type (might be due to invalid IL or missing references)
		//IL_02a1: Unknown result type (might be due to invalid IL or missing references)
		//IL_0260: Unknown result type (might be due to invalid IL or missing references)
		//IL_0272: Unknown result type (might be due to invalid IL or missing references)
		//IL_0362: Unknown result type (might be due to invalid IL or missing references)
		//IL_0373: Unknown result type (might be due to invalid IL or missing references)
		//IL_0378: Unknown result type (might be due to invalid IL or missing references)
		//IL_037d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0384: Unknown result type (might be due to invalid IL or missing references)
		//IL_0395: Unknown result type (might be due to invalid IL or missing references)
		//IL_039a: Unknown result type (might be due to invalid IL or missing references)
		//IL_039f: Unknown result type (might be due to invalid IL or missing references)
		//IL_02e9: Unknown result type (might be due to invalid IL or missing references)
		//IL_02ee: Unknown result type (might be due to invalid IL or missing references)
		bool flag = currentState == State.JudgeRuckusPlayer;
		bool flag2 = currentState == State.Shoot;
		bool flag3 = currentState == State.GrabRuckusPlayer;
		if (flag)
		{
			float num = Mathf.Clamp01((Time.time - currentStateEnterTime) / 1.5f);
			judgeCharge = judgeChargeCurve.Evaluate(num);
			judgeChargeAtShoot = judgeCharge;
			judgeReleaseActive = false;
			judgeReleaseTimer = 0f;
		}
		else if (flag2 && (judgeReleaseActive || judgeCharge > 0f))
		{
			if (!judgeReleaseActive)
			{
				judgeReleaseActive = true;
				judgeReleaseTimer = 0f;
				judgeChargeAtShoot = judgeCharge;
			}
			judgeReleaseTimer += Time.deltaTime;
			float num2 = Mathf.Clamp01(judgeReleaseTimer / 0.2f);
			judgeCharge = Mathf.Lerp(judgeChargeAtShoot, 0f, num2);
			if (num2 >= 1f)
			{
				judgeCharge = 0f;
				judgeReleaseActive = false;
			}
		}
		else
		{
			judgeCharge = 0f;
			judgeReleaseActive = false;
			judgeReleaseTimer = 0f;
		}
		if (Object.op_Implicit((Object)(object)gunBarrelMaterial))
		{
			gunBarrelMaterial.SetColor("_EmissionColor", Color.Lerp(Color.black, gunBarrelEmissionCharged, judgeCharge));
		}
		if (Object.op_Implicit((Object)(object)barrelChargeLight))
		{
			float num3 = judgeCharge * barrelChargeLightMaxIntensity;
			if (num3 > 0.001f)
			{
				if (!((Behaviour)barrelChargeLight).enabled)
				{
					((Behaviour)barrelChargeLight).enabled = true;
				}
				barrelChargeLight.intensity = num3;
			}
			else
			{
				barrelChargeLight.intensity = 0f;
				if (((Behaviour)barrelChargeLight).enabled)
				{
					((Behaviour)barrelChargeLight).enabled = false;
				}
			}
		}
		float pitchMultiplier = Mathf.Lerp(judgeBuildUpPitchMin, judgeBuildUpPitchMax, judgeCharge);
		float volumeMultiplier = Mathf.Lerp(judgeBuildUpVolumeMin, judgeBuildUpVolumeMax, judgeCharge);
		judgeBuildUpLoop.PlayLoop(judgeCharge > 0.001f, 10f, 10f, pitchMultiplier, volumeMultiplier);
		if (Object.op_Implicit((Object)(object)judgeChargeParticles))
		{
			if (flag)
			{
				if (!judgeChargeParticles.isPlaying)
				{
					judgeChargeParticles.Play();
				}
				((Component)judgeChargeParticles).transform.localScale = Vector3.one * (judgeCharge * judgeChargeParticlesMaxScale);
			}
			else
			{
				if (judgeChargeParticles.isPlaying)
				{
					judgeChargeParticles.Stop();
				}
				((Component)judgeChargeParticles).transform.localScale = Vector3.zero;
			}
		}
		if ((flag | flag2) || (flag3 && grabReached))
		{
			rotationTargetX = frozenAimTargetX;
			rotationTargetY = frozenAimTargetY;
		}
		else if (currentState == State.WarnTellOff && warnTellOffAimFrozen)
		{
			rotationTargetY = frozenAimTargetY;
		}
		if (judgeCharge > 0.001f)
		{
			float num4 = judgeCharge * judgeGunShakeMaxAngle;
			float num5 = (Mathf.PerlinNoise(Time.time * judgeGunShakeSpeed, 0f) - 0.5f) * 2f * num4;
			float num6 = (Mathf.PerlinNoise(0f, Time.time * judgeGunShakeSpeed) - 0.5f) * 2f * num4;
			rotationTargetX *= Quaternion.Euler(num5, 0f, 0f);
			rotationTargetY *= Quaternion.Euler(0f, num6, 0f);
		}
	}

	private void ScanLightLogic()
	{
		//IL_0177: Unknown result type (might be due to invalid IL or missing references)
		//IL_017c: Unknown result type (might be due to invalid IL or missing references)
		//IL_023c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0241: Unknown result type (might be due to invalid IL or missing references)
		//IL_0264: Unknown result type (might be due to invalid IL or missing references)
		//IL_0269: Unknown result type (might be due to invalid IL or missing references)
		//IL_024f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0254: Unknown result type (might be due to invalid IL or missing references)
		//IL_01cf: Unknown result type (might be due to invalid IL or missing references)
		//IL_01d4: Unknown result type (might be due to invalid IL or missing references)
		//IL_0277: Unknown result type (might be due to invalid IL or missing references)
		//IL_027c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0227: Unknown result type (might be due to invalid IL or missing references)
		//IL_022c: Unknown result type (might be due to invalid IL or missing references)
		//IL_03d3: Unknown result type (might be due to invalid IL or missing references)
		//IL_03d8: Unknown result type (might be due to invalid IL or missing references)
		//IL_03df: Unknown result type (might be due to invalid IL or missing references)
		//IL_03e4: Unknown result type (might be due to invalid IL or missing references)
		//IL_03ed: Unknown result type (might be due to invalid IL or missing references)
		//IL_03f2: Unknown result type (might be due to invalid IL or missing references)
		//IL_040e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0413: Unknown result type (might be due to invalid IL or missing references)
		//IL_0420: Unknown result type (might be due to invalid IL or missing references)
		//IL_03fb: Unknown result type (might be due to invalid IL or missing references)
		//IL_0400: Unknown result type (might be due to invalid IL or missing references)
		//IL_0489: Unknown result type (might be due to invalid IL or missing references)
		//IL_048e: Unknown result type (might be due to invalid IL or missing references)
		//IL_049b: Unknown result type (might be due to invalid IL or missing references)
		//IL_04ab: Unknown result type (might be due to invalid IL or missing references)
		//IL_04b0: Unknown result type (might be due to invalid IL or missing references)
		//IL_04b5: Unknown result type (might be due to invalid IL or missing references)
		//IL_04e4: Unknown result type (might be due to invalid IL or missing references)
		//IL_04ee: Unknown result type (might be due to invalid IL or missing references)
		//IL_04c6: Unknown result type (might be due to invalid IL or missing references)
		//IL_04c8: Unknown result type (might be due to invalid IL or missing references)
		//IL_04cd: Unknown result type (might be due to invalid IL or missing references)
		if (!Object.op_Implicit((Object)(object)scanLight))
		{
			return;
		}
		if (itemReactionLightTimer > 0f)
		{
			ItemReactionLightLogic();
			return;
		}
		bool flag = currentState == State.AngryObservation;
		bool flag2 = grabBeamOverrideActive && currentState == State.WarnGrabPlayer;
		bool flag3 = grabBeamOverrideActive && currentState == State.WarnTellOff;
		bool flag4 = scanBeamOverrideActive && currentState == State.SeeWarnPlayer;
		bool flag5 = (currentState == State.NoticeItem || currentState == State.ScanObject) && ItemTargetValid();
		bool flag6 = ItemNegativeState(currentState) && ItemTargetValid();
		bool num = scanBeamOverrideActive && !flag;
		bool flag7 = grabBeamOverrideActive && currentState == State.GrabRuckusPlayer;
		bool flag8 = grabBeamOverrideActive && currentState == State.JudgeRuckusPlayer;
		bool flag9 = flag2 | flag3 | flag4;
		bool flag10 = !flag9 && (grabBeamOverrideActive | flag | flag6);
		float num2 = (flag8 ? Mathf.Max(0f, 1.5f - (Time.time - currentStateEnterTime)) : 0f);
		bool flag11 = flag8 && num2 > 0f && num2 <= judgeLightOutroTriggerTime;
		bool flag12 = ((num | flag7) || (flag8 && !flag11)) | flag | flag2 | flag3 | flag5 | flag6;
		if (flag5 | flag6)
		{
			scanLightAimTarget = itemReactObject.centerPoint;
		}
		else if ((flag | flag2 | flag3) && PlayerTargetValid() && Object.op_Implicit((Object)(object)playerTarget.PlayerVisionTarget) && Object.op_Implicit((Object)(object)playerTarget.PlayerVisionTarget.VisionTransform))
		{
			scanLightAimTarget = playerTarget.PlayerVisionTarget.VisionTransform.position;
		}
		else if ((flag7 | flag8) && PlayerTargetValid() && Object.op_Implicit((Object)(object)playerTarget.PlayerVisionTarget) && Object.op_Implicit((Object)(object)playerTarget.PlayerVisionTarget.VisionTransform))
		{
			scanLightAimTarget = playerTarget.PlayerVisionTarget.VisionTransform.position;
		}
		else if (grabBeamOverrideActive && grabBeamOverrideTarget != Vector3.zero)
		{
			scanLightAimTarget = grabBeamOverrideTarget;
		}
		else if (scanBeamOverrideActive && scanBeamOverrideTarget != Vector3.zero)
		{
			scanLightAimTarget = scanBeamOverrideTarget;
		}
		if (flag12 && !scanLightOn)
		{
			scanLightOn = true;
			scanLightInTimer = 0f;
			scanLightOutTimer = 0.2f;
			((Behaviour)scanLight).enabled = true;
		}
		else if (!flag12 && scanLightOn)
		{
			scanLightOn = false;
			scanLightOutTimer = 0f;
		}
		float num3;
		if (scanLightInTimer < 0.2f)
		{
			scanLightInTimer += Time.deltaTime;
			num3 = scanLightInCurve.Evaluate(Mathf.Clamp01(scanLightInTimer / 0.2f));
		}
		else if (scanLightOutTimer < 0.2f)
		{
			scanLightOutTimer += Time.deltaTime;
			num3 = 1f - scanLightOutCurve.Evaluate(Mathf.Clamp01(scanLightOutTimer / 0.2f));
		}
		else
		{
			num3 = (scanLightOn ? 1f : 0f);
		}
		if (num3 <= 0f && !scanLightOn)
		{
			if (((Behaviour)scanLight).enabled)
			{
				((Behaviour)scanLight).enabled = false;
			}
		}
		else if (num3 > 0f && !((Behaviour)scanLight).enabled)
		{
			((Behaviour)scanLight).enabled = true;
		}
		scanLight.intensity = scanLightIntensityOriginal * num3;
		Color val = scanLightColorSee;
		if (flag5)
		{
			val = itemBeamColorScan;
		}
		else if (flag9)
		{
			val = scanLightColorWarning;
		}
		else if (flag10)
		{
			val = scanLightColorGrab;
		}
		scanLight.color = Color.Lerp(scanLight.color, val, Time.deltaTime * 15f);
		float num4 = 0f;
		if (flag8)
		{
			float num5 = Mathf.Clamp01((Time.time - currentStateEnterTime) / 1.5f);
			num4 = scanLightJudgeCurve.Evaluate(num5);
		}
		scanLight.spotAngle = Mathf.Lerp(scanLightSpotAngleOriginal, scanLightSpotAngleJudge, num4);
		if (((Behaviour)scanLight).enabled && scanLightAimTarget != Vector3.zero)
		{
			Vector3 val2 = scanLightAimTarget - ((Component)scanLight).transform.position;
			if (val2.sqrMagnitude > 0.0001f)
			{
				scanLightRotationTarget = Quaternion.LookRotation(val2);
			}
			((Component)scanLight).transform.rotation = SemiFunc.SpringQuaternionGet(scanLightSpring, scanLightRotationTarget);
		}
	}

	private void ItemReactionLightLogic()
	{
		//IL_00ab: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c8: Unknown result type (might be due to invalid IL or missing references)
		//IL_00cd: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e8: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ed: Unknown result type (might be due to invalid IL or missing references)
		//IL_0044: Unknown result type (might be due to invalid IL or missing references)
		//IL_0049: Unknown result type (might be due to invalid IL or missing references)
		//IL_011a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0124: Unknown result type (might be due to invalid IL or missing references)
		//IL_00fd: Unknown result type (might be due to invalid IL or missing references)
		//IL_00fe: Unknown result type (might be due to invalid IL or missing references)
		//IL_0103: Unknown result type (might be due to invalid IL or missing references)
		itemReactionLightTimer = Mathf.Max(0f, itemReactionLightTimer - Time.deltaTime);
		if (!Object.op_Implicit((Object)(object)itemReactionFlashLight))
		{
			itemReactionLightTimer = 0f;
			return;
		}
		if (ItemTargetValid())
		{
			itemReactionLightTarget = itemReactObject.centerPoint;
		}
		float num = Mathf.Max(0.01f, itemReactionLightDuration);
		float num2 = Mathf.SmoothStep(0f, 1f, itemReactionLightTimer / num);
		((Behaviour)itemReactionFlashLight).enabled = num2 > 0f;
		itemReactionFlashLight.intensity = scanLightIntensityOriginal * itemReactionLightIntensityMultiplier * num2;
		itemReactionFlashLight.color = itemReactionLightColor;
		itemReactionFlashLight.spotAngle = scanLightSpotAngleOriginal;
		scanLightAimTarget = itemReactionLightTarget;
		Vector3 val = scanLightAimTarget - ((Component)itemReactionFlashLight).transform.position;
		if (val.sqrMagnitude > 0.0001f)
		{
			scanLightRotationTarget = Quaternion.LookRotation(val);
		}
		((Component)itemReactionFlashLight).transform.rotation = SemiFunc.SpringQuaternionGet(scanLightSpring, scanLightRotationTarget);
	}

	private void FixedUpdate()
	{
		DragPlayerLogic();
		DragItemLogic();
		ItemDenyPhysics();
		HeadPushPhysics();
	}

	private void HeadPushSetup()
	{
		//IL_0013: Unknown result type (might be due to invalid IL or missing references)
		//IL_0019: Expected Obj, but got Unknown
		if (Object.op_Implicit((Object)(object)shopkeeperFacePoint))
		{
			GameObject val = new GameObject("Head Push");
			val.transform.SetParent(shopkeeperFacePoint, false);
			headPushCollider = val.AddComponent<SphereCollider>();
			((Collider)headPushCollider).enabled = false;
		}
	}

	private void HeadPushPhysics()
	{
		//IL_005b: Unknown result type (might be due to invalid IL or missing references)
		//IL_006c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0071: Unknown result type (might be due to invalid IL or missing references)
		//IL_0076: Unknown result type (might be due to invalid IL or missing references)
		//IL_007d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0082: Unknown result type (might be due to invalid IL or missing references)
		//IL_0091: Unknown result type (might be due to invalid IL or missing references)
		//IL_009f: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ad: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c0: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c8: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f1: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f9: Unknown result type (might be due to invalid IL or missing references)
		//IL_01ed: Unknown result type (might be due to invalid IL or missing references)
		//IL_01f9: Unknown result type (might be due to invalid IL or missing references)
		//IL_0205: Unknown result type (might be due to invalid IL or missing references)
		//IL_0210: Unknown result type (might be due to invalid IL or missing references)
		//IL_0243: Unknown result type (might be due to invalid IL or missing references)
		//IL_0248: Unknown result type (might be due to invalid IL or missing references)
		//IL_028b: Unknown result type (might be due to invalid IL or missing references)
		//IL_028f: Unknown result type (might be due to invalid IL or missing references)
		if (!SemiFunc.IsMasterClientOrSingleplayer() || headPushRadius <= 0f || headPushAcceleration <= 0f || headPushSpeed <= 0f)
		{
			return;
		}
		SphereCollider val = headPushCollider;
		if (!Object.op_Implicit((Object)(object)val) || !((Component)val).gameObject.activeInHierarchy)
		{
			return;
		}
		val.radius = headPushRadius;
		val.center = headPushOffset;
		Vector3 val2 = ((Component)val).transform.TransformPoint(val.center);
		Vector3 lossyScale = ((Component)val).transform.lossyScale;
		float num = val.radius * Mathf.Max(new float[3]
		{
			Mathf.Abs(lossyScale.x),
			Mathf.Abs(lossyScale.y),
			Mathf.Abs(lossyScale.z)
		});
		int num2;
		for (num2 = Physics.OverlapSphereNonAlloc(val2, num, headPushColliders, LayerMask.op_Implicit(SemiFunc.LayerMaskGetPhysGrabObject()), (QueryTriggerInteraction)1); num2 == headPushColliders.Length; num2 = Physics.OverlapSphereNonAlloc(val2, num, headPushColliders, LayerMask.op_Implicit(SemiFunc.LayerMaskGetPhysGrabObject()), (QueryTriggerInteraction)1))
		{
			Array.Resize(ref headPushColliders, headPushColliders.Length * 2);
		}
		headPushRigidbodies.Clear();
		Vector3 val4 = default;
		float num3 = default;
		for (int i = 0; i < num2; i++)
		{
			Collider val3 = headPushColliders[i];
			headPushColliders[i] = null;
			if (!Object.op_Implicit((Object)(object)val3))
			{
				continue;
			}
			Rigidbody attachedRigidbody = val3.attachedRigidbody;
			if (!Object.op_Implicit((Object)(object)attachedRigidbody) || attachedRigidbody.isKinematic || headPushRigidbodies.Contains(attachedRigidbody))
			{
				continue;
			}
			PhysGrabObject component = ((Component)attachedRigidbody).GetComponent<PhysGrabObject>();
			if (Object.op_Implicit((Object)(object)component) && !component.dead && !component.isPlayer && !component.isEnemy && (!((Object)(object)component == (Object)(object)itemReactObject) || (!ItemControlState(currentState) && currentState != State.DenyItem)) && Physics.ComputePenetration(val3, ((Component)val3).transform.position, ((Component)val3).transform.rotation, (Collider)(object)val, ((Component)val).transform.position, ((Component)val).transform.rotation, ref val4, ref num3))
			{
				headPushRigidbodies.Add(attachedRigidbody);
				float num4 = Mathf.Clamp(Mathf.Min(headPushSpeed, num3 / Time.fixedDeltaTime) - Vector3.Dot(attachedRigidbody.linearVelocity, val4), 0f, headPushAcceleration * Time.fixedDeltaTime);
				if (!(num4 <= 0f))
				{
					component.OverrideIndestructible();
					component.OverrideBreakEffects(0.1f);
					attachedRigidbody.AddForce(val4 * num4, (ForceMode)2);
				}
			}
		}
		headPushRigidbodies.Clear();
	}

	private void DragPlayerLogic()
	{
		//IL_019b: Unknown result type (might be due to invalid IL or missing references)
		//IL_01a0: Unknown result type (might be due to invalid IL or missing references)
		//IL_01a3: Unknown result type (might be due to invalid IL or missing references)
		//IL_01a8: Unknown result type (might be due to invalid IL or missing references)
		//IL_01ab: Unknown result type (might be due to invalid IL or missing references)
		//IL_01b5: Unknown result type (might be due to invalid IL or missing references)
		//IL_01ba: Unknown result type (might be due to invalid IL or missing references)
		//IL_01bd: Unknown result type (might be due to invalid IL or missing references)
		//IL_01c0: Unknown result type (might be due to invalid IL or missing references)
		//IL_0203: Unknown result type (might be due to invalid IL or missing references)
		//IL_0214: Unknown result type (might be due to invalid IL or missing references)
		//IL_0219: Unknown result type (might be due to invalid IL or missing references)
		//IL_021e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0221: Unknown result type (might be due to invalid IL or missing references)
		//IL_0226: Unknown result type (might be due to invalid IL or missing references)
		//IL_0229: Unknown result type (might be due to invalid IL or missing references)
		//IL_0233: Unknown result type (might be due to invalid IL or missing references)
		//IL_0238: Unknown result type (might be due to invalid IL or missing references)
		//IL_023b: Unknown result type (might be due to invalid IL or missing references)
		//IL_023e: Unknown result type (might be due to invalid IL or missing references)
		//IL_077e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0783: Unknown result type (might be due to invalid IL or missing references)
		//IL_0785: Unknown result type (might be due to invalid IL or missing references)
		//IL_078a: Unknown result type (might be due to invalid IL or missing references)
		//IL_03bc: Unknown result type (might be due to invalid IL or missing references)
		//IL_03c1: Unknown result type (might be due to invalid IL or missing references)
		//IL_03c4: Unknown result type (might be due to invalid IL or missing references)
		//IL_03c9: Unknown result type (might be due to invalid IL or missing references)
		//IL_03cc: Unknown result type (might be due to invalid IL or missing references)
		//IL_03d6: Unknown result type (might be due to invalid IL or missing references)
		//IL_03db: Unknown result type (might be due to invalid IL or missing references)
		//IL_03de: Unknown result type (might be due to invalid IL or missing references)
		//IL_03e1: Unknown result type (might be due to invalid IL or missing references)
		//IL_07db: Unknown result type (might be due to invalid IL or missing references)
		//IL_07dd: Unknown result type (might be due to invalid IL or missing references)
		//IL_07b5: Unknown result type (might be due to invalid IL or missing references)
		//IL_07b7: Unknown result type (might be due to invalid IL or missing references)
		//IL_07ba: Unknown result type (might be due to invalid IL or missing references)
		//IL_07c4: Unknown result type (might be due to invalid IL or missing references)
		//IL_07c9: Unknown result type (might be due to invalid IL or missing references)
		//IL_07cc: Unknown result type (might be due to invalid IL or missing references)
		//IL_07cf: Unknown result type (might be due to invalid IL or missing references)
		//IL_0428: Unknown result type (might be due to invalid IL or missing references)
		//IL_0636: Unknown result type (might be due to invalid IL or missing references)
		//IL_063c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0641: Unknown result type (might be due to invalid IL or missing references)
		//IL_0646: Unknown result type (might be due to invalid IL or missing references)
		//IL_064a: Unknown result type (might be due to invalid IL or missing references)
		//IL_064f: Unknown result type (might be due to invalid IL or missing references)
		//IL_042d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0430: Unknown result type (might be due to invalid IL or missing references)
		//IL_0435: Unknown result type (might be due to invalid IL or missing references)
		//IL_0438: Unknown result type (might be due to invalid IL or missing references)
		//IL_0442: Unknown result type (might be due to invalid IL or missing references)
		//IL_0447: Unknown result type (might be due to invalid IL or missing references)
		//IL_044a: Unknown result type (might be due to invalid IL or missing references)
		//IL_044d: Unknown result type (might be due to invalid IL or missing references)
		//IL_041b: Unknown result type (might be due to invalid IL or missing references)
		//IL_040e: Unknown result type (might be due to invalid IL or missing references)
		//IL_087f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0881: Unknown result type (might be due to invalid IL or missing references)
		//IL_0883: Unknown result type (might be due to invalid IL or missing references)
		//IL_0888: Unknown result type (might be due to invalid IL or missing references)
		//IL_088c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0891: Unknown result type (might be due to invalid IL or missing references)
		//IL_0899: Unknown result type (might be due to invalid IL or missing references)
		//IL_08a1: Unknown result type (might be due to invalid IL or missing references)
		//IL_08ab: Unknown result type (might be due to invalid IL or missing references)
		//IL_08b0: Unknown result type (might be due to invalid IL or missing references)
		//IL_08b3: Unknown result type (might be due to invalid IL or missing references)
		//IL_08bb: Unknown result type (might be due to invalid IL or missing references)
		//IL_08c1: Unknown result type (might be due to invalid IL or missing references)
		//IL_08cc: Unknown result type (might be due to invalid IL or missing references)
		//IL_08ce: Unknown result type (might be due to invalid IL or missing references)
		//IL_08d1: Unknown result type (might be due to invalid IL or missing references)
		//IL_08db: Unknown result type (might be due to invalid IL or missing references)
		//IL_08e0: Unknown result type (might be due to invalid IL or missing references)
		//IL_08e3: Unknown result type (might be due to invalid IL or missing references)
		//IL_08e6: Unknown result type (might be due to invalid IL or missing references)
		//IL_0831: Unknown result type (might be due to invalid IL or missing references)
		//IL_068d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0698: Unknown result type (might be due to invalid IL or missing references)
		//IL_069d: Unknown result type (might be due to invalid IL or missing references)
		//IL_06a2: Unknown result type (might be due to invalid IL or missing references)
		//IL_06a6: Unknown result type (might be due to invalid IL or missing references)
		//IL_06ab: Unknown result type (might be due to invalid IL or missing references)
		//IL_0667: Unknown result type (might be due to invalid IL or missing references)
		//IL_066e: Unknown result type (might be due to invalid IL or missing references)
		//IL_065f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0664: Unknown result type (might be due to invalid IL or missing references)
		//IL_04a2: Unknown result type (might be due to invalid IL or missing references)
		//IL_06c2: Unknown result type (might be due to invalid IL or missing references)
		//IL_06c9: Unknown result type (might be due to invalid IL or missing references)
		//IL_06ce: Unknown result type (might be due to invalid IL or missing references)
		//IL_06d8: Unknown result type (might be due to invalid IL or missing references)
		//IL_06dd: Unknown result type (might be due to invalid IL or missing references)
		//IL_06e2: Unknown result type (might be due to invalid IL or missing references)
		//IL_06e5: Unknown result type (might be due to invalid IL or missing references)
		//IL_06f0: Unknown result type (might be due to invalid IL or missing references)
		//IL_0703: Unknown result type (might be due to invalid IL or missing references)
		//IL_0708: Unknown result type (might be due to invalid IL or missing references)
		//IL_06bb: Unknown result type (might be due to invalid IL or missing references)
		//IL_06c0: Unknown result type (might be due to invalid IL or missing references)
		//IL_04a7: Unknown result type (might be due to invalid IL or missing references)
		//IL_0495: Unknown result type (might be due to invalid IL or missing references)
		//IL_0488: Unknown result type (might be due to invalid IL or missing references)
		//IL_09ac: Unknown result type (might be due to invalid IL or missing references)
		//IL_09b7: Unknown result type (might be due to invalid IL or missing references)
		//IL_0907: Unknown result type (might be due to invalid IL or missing references)
		//IL_090f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0914: Unknown result type (might be due to invalid IL or missing references)
		//IL_0919: Unknown result type (might be due to invalid IL or missing references)
		//IL_091d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0922: Unknown result type (might be due to invalid IL or missing references)
		//IL_0735: Unknown result type (might be due to invalid IL or missing references)
		//IL_0739: Unknown result type (might be due to invalid IL or missing references)
		//IL_073f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0725: Unknown result type (might be due to invalid IL or missing references)
		//IL_04c0: Unknown result type (might be due to invalid IL or missing references)
		//IL_04b6: Unknown result type (might be due to invalid IL or missing references)
		//IL_02be: Unknown result type (might be due to invalid IL or missing references)
		//IL_02b7: Unknown result type (might be due to invalid IL or missing references)
		//IL_093e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0943: Unknown result type (might be due to invalid IL or missing references)
		//IL_0945: Unknown result type (might be due to invalid IL or missing references)
		//IL_094a: Unknown result type (might be due to invalid IL or missing references)
		//IL_094e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0953: Unknown result type (might be due to invalid IL or missing references)
		//IL_0932: Unknown result type (might be due to invalid IL or missing references)
		//IL_0937: Unknown result type (might be due to invalid IL or missing references)
		//IL_093c: Unknown result type (might be due to invalid IL or missing references)
		//IL_04c5: Unknown result type (might be due to invalid IL or missing references)
		//IL_02c3: Unknown result type (might be due to invalid IL or missing references)
		//IL_096b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0973: Unknown result type (might be due to invalid IL or missing references)
		//IL_097f: Unknown result type (might be due to invalid IL or missing references)
		//IL_098a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0996: Unknown result type (might be due to invalid IL or missing references)
		//IL_099e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0963: Unknown result type (might be due to invalid IL or missing references)
		//IL_0968: Unknown result type (might be due to invalid IL or missing references)
		//IL_02e5: Unknown result type (might be due to invalid IL or missing references)
		//IL_02d8: Unknown result type (might be due to invalid IL or missing references)
		//IL_0530: Unknown result type (might be due to invalid IL or missing references)
		//IL_0532: Unknown result type (might be due to invalid IL or missing references)
		//IL_0536: Unknown result type (might be due to invalid IL or missing references)
		//IL_053b: Unknown result type (might be due to invalid IL or missing references)
		//IL_053e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0543: Unknown result type (might be due to invalid IL or missing references)
		//IL_0546: Unknown result type (might be due to invalid IL or missing references)
		//IL_0550: Unknown result type (might be due to invalid IL or missing references)
		//IL_0555: Unknown result type (might be due to invalid IL or missing references)
		//IL_0558: Unknown result type (might be due to invalid IL or missing references)
		//IL_02ea: Unknown result type (might be due to invalid IL or missing references)
		//IL_02ed: Unknown result type (might be due to invalid IL or missing references)
		//IL_02f2: Unknown result type (might be due to invalid IL or missing references)
		//IL_02f4: Unknown result type (might be due to invalid IL or missing references)
		//IL_02f9: Unknown result type (might be due to invalid IL or missing references)
		//IL_0324: Unknown result type (might be due to invalid IL or missing references)
		//IL_0329: Unknown result type (might be due to invalid IL or missing references)
		//IL_032c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0337: Unknown result type (might be due to invalid IL or missing references)
		//IL_033e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0343: Unknown result type (might be due to invalid IL or missing references)
		//IL_034a: Unknown result type (might be due to invalid IL or missing references)
		//IL_034f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0365: Unknown result type (might be due to invalid IL or missing references)
		//IL_036a: Unknown result type (might be due to invalid IL or missing references)
		//IL_031b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0320: Unknown result type (might be due to invalid IL or missing references)
		//IL_0397: Unknown result type (might be due to invalid IL or missing references)
		//IL_039b: Unknown result type (might be due to invalid IL or missing references)
		//IL_03a1: Unknown result type (might be due to invalid IL or missing references)
		//IL_0387: Unknown result type (might be due to invalid IL or missing references)
		//IL_05ce: Unknown result type (might be due to invalid IL or missing references)
		//IL_05d3: Unknown result type (might be due to invalid IL or missing references)
		//IL_0592: Unknown result type (might be due to invalid IL or missing references)
		//IL_0598: Unknown result type (might be due to invalid IL or missing references)
		//IL_0618: Unknown result type (might be due to invalid IL or missing references)
		//IL_061c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0622: Unknown result type (might be due to invalid IL or missing references)
		//IL_0609: Unknown result type (might be due to invalid IL or missing references)
		if ((currentState != State.GrabRuckusPlayer && currentState != State.JudgeRuckusPlayer && currentState != State.WarnGrabPlayer && currentState != State.WarnTellOff) || !PlayerTargetValid())
		{
			return;
		}
		if (playerTarget.isLocal)
		{
			playerTarget.physGrabber.OverrideDisableSpecialGrabPowers();
		}
		if (!SemiFunc.IsMasterClientOrSingleplayer() || !Object.op_Implicit((Object)(object)playerTarget.tumble) || !Object.op_Implicit((Object)(object)playerTarget.tumble.rb))
		{
			return;
		}
		if (!playerTarget.isTumbling)
		{
			playerTarget.tumble.TumbleRequest(_isTumbling: true, _playerInput: false);
			return;
		}
		Rigidbody rb = playerTarget.tumble.rb;
		playerTarget.tumble.TumbleOverrideTime(0.5f);
		float num = 1f;
		PhysGrabObject physGrabObject = playerTarget.tumble.physGrabObject;
		if (Object.op_Implicit((Object)(object)physGrabObject) && physGrabObject.massOriginal > 0f)
		{
			num = Mathf.Clamp01(rb.mass / physGrabObject.massOriginal);
		}
		Vector3 val11;
		if (currentState == State.WarnTellOff)
		{
			if (stateImpulse)
			{
				return;
			}
			playerTarget.tumble.OverrideLookAtCamera(0.1f);
			float num2 = warnTellOffStareBeforeDuration;
			float num3 = num2 + warnTellOffShakeDuration;
			float num4 = num3 + warnTellOffStareAfterDuration;
			float num5 = num4 + warnTellOffLectureDuration;
			float num6 = num5 + warnTellOffBonkDuration;
			float num7 = num6 + 0.18f;
			float num8 = num7 + 0.22f - stateTimer;
			if (num8 < num2)
			{
				Vector3 position = playerPoint.position;
				Vector3 val = SemiFunc.PhysFollowPosition(rb.position, position, rb.linearVelocity, 6f);
				rb.AddForce(val * num, (ForceMode)1);
			}
			else if (num8 < num3)
			{
				float num9 = num8 - num2;
				float num10 = Mathf.Sin(num9 * 6f * MathF.PI * 2f) * 0.3f;
				Vector3 targetPosition = playerPoint.position + new Vector3(0f, num10, 0f);
				Vector3 val2 = SemiFunc.PhysFollowPosition(rb.position, targetPosition, rb.linearVelocity, 15f);
				rb.AddForce(val2 * num, (ForceMode)1);
				float num11 = num10 - warnTellOffShakePrevY;
				warnTellOffShakePrevY = num10;
				if (warnTellOffShakeReleaseEnabled && !warnTellOffShakeReleaseFired && warnTellOffShakeEntered && num9 >= 0.5f && num9 >= warnTellOffShakeReleaseTime && Mathf.Abs(num11) > 0.0001f)
				{
					warnTellOffShakeReleaseFired = true;
					Vector3 val3 = ((num11 > 0f) ? Vector3.up : Vector3.down);
					Vector3 val4 = (Object.op_Implicit((Object)(object)shopkeeperFacePoint) ? shopkeeperFacePoint.position : ((Component)this).transform.position);
					Vector3 val5 = rb.position - val4;
					val5.y = 0f;
					if (val5.sqrMagnitude < 0.001f)
					{
						val5 = ((Component)this).transform.forward;
					}
					val5 = val5.normalized;
					rb.linearVelocity = Vector3.zero;
					rb.AddForce(val3 * 15f + val5 * 8f, (ForceMode)2);
					Vector3 position2 = ((Component)playerTarget).transform.position;
					if (SemiFunc.IsMultiplayer())
					{
						photonView.RPC("ThrowSoundAtRPC", (RpcTarget)0, new object[1] { position2 });
					}
					else
					{
						ThrowSoundAtRPC(position2);
					}
					UpdateState(State.Observe);
				}
			}
			else if (num8 < num4)
			{
				Vector3 position3 = playerPoint.position;
				Vector3 val6 = SemiFunc.PhysFollowPosition(rb.position, position3, rb.linearVelocity, 6f);
				rb.AddForce(val6 * num, (ForceMode)1);
			}
			else if (num8 < num5)
			{
				Vector3 targetPosition2;
				if (Object.op_Implicit((Object)(object)emojiForcePosition))
				{
					targetPosition2 = emojiForcePosition.position;
				}
				else
				{
					targetPosition2 = (Object.op_Implicit((Object)(object)shopkeeperFacePoint) ? shopkeeperFacePoint.position : rb.position);
				}
				Vector3 val7 = SemiFunc.PhysFollowPosition(rb.position, targetPosition2, rb.linearVelocity, 6f);
				rb.AddForce(val7 * num, (ForceMode)1);
			}
			else if (warnTellOffBonkActive && num8 < num6)
			{
				Vector3 val8;
				if (Object.op_Implicit((Object)(object)emojiForcePosition))
				{
					val8 = emojiForcePosition.position;
				}
				else
				{
					val8 = (Object.op_Implicit((Object)(object)shopkeeperFacePoint) ? shopkeeperFacePoint.position : rb.position);
				}
				Vector3 val9 = (Object.op_Implicit((Object)(object)lookAtEmojiHereTransform) ? lookAtEmojiHereTransform.position : val8);
				float[] array = warnTellOffBonkPatterns[warnTellOffBonkPatternIndex];
				float num12 = num8 - num5;
				float num13 = 0f;
				int num14 = -1;
				for (int i = 0; i < array.Length; i++)
				{
					float num15 = num12 - array[i];
					if (num15 >= 0f && num15 < 0.13f)
					{
						num13 = Mathf.Sin(num15 / 0.13f * MathF.PI);
						num14 = i;
						break;
					}
				}
				Vector3 targetPosition3 = Vector3.Lerp(val8, val9, num13);
				Vector3 val10 = SemiFunc.PhysFollowPosition(rb.position, targetPosition3, rb.linearVelocity, 40f);
				rb.AddForce(val10, (ForceMode)2);
				while (warnTellOffBonksApplied < array.Length && num12 >= array[warnTellOffBonksApplied])
				{
					warnTellOffBonksApplied++;
					if (SemiFunc.IsMultiplayer())
					{
						photonView.RPC("BigSensorBreakerRPC", (RpcTarget)0, Array.Empty<object>());
					}
					else
					{
						BigSensorBreakerRPC();
					}
				}
				if (num14 >= 0 && num14 >= warnTellOffBonkSoundsPlayed && Vector3.Distance(rb.position, val9) <= 0.2f)
				{
					warnTellOffBonkSoundsPlayed = num14 + 1;
					if (SemiFunc.IsMultiplayer())
					{
						photonView.RPC("BonkLandRPC", (RpcTarget)0, new object[1] { val9 });
					}
					else
					{
						BonkLandRPC(val9);
					}
				}
			}
			else if (num8 < num7)
			{
				val11 = ((Component)this).transform.position - rb.position;
				Vector3 val12 = val11.normalized;
				if (val12.sqrMagnitude < 0.001f)
				{
					val12 = Vector3.forward;
				}
				rb.AddForce(val12 * 14f, (ForceMode)5);
			}
			else if (!warnTellOffThrowApplied)
			{
				warnTellOffThrowApplied = true;
				val11 = rb.position - ((Component)this).transform.position;
				Vector3 val13 = val11.normalized;
				if (val13.sqrMagnitude < 0.001f)
				{
					val13 = Vector3.forward;
				}
				Vector3 val14 = val13 * 22f + Vector3.up * 7f;
				rb.linearVelocity = Vector3.zero;
				rb.AddForce(val14, (ForceMode)2);
				Vector3 position4 = ((Component)playerTarget).transform.position;
				if (SemiFunc.IsMultiplayer())
				{
					photonView.RPC("ThrowSoundAtRPC", (RpcTarget)0, new object[1] { position4 });
				}
				else
				{
					ThrowSoundAtRPC(position4);
				}
				UpdateState(State.Observe);
			}
			return;
		}
		Transform val15 = (Object.op_Implicit((Object)(object)playerPoint2) ? playerPoint2 : playerPoint);
		Transform val16 = ((currentState == State.JudgeRuckusPlayer) ? val15 : playerPoint);
		Vector3 position5 = rb.position;
		Vector3 position6 = val16.position;
		if (currentState == State.JudgeRuckusPlayer)
		{
			playerTarget.tumble.OverrideLookAtCamera(0.1f);
			Vector3 val17 = SemiFunc.PhysFollowPosition(position5, position6, rb.linearVelocity, 5f);
			rb.AddForce(val17 * num, (ForceMode)1);
			return;
		}
		float num16 = Vector3.Distance(position5, position6);
		bool flag = num16 < stuckPrevDistance - 0.001f;
		if (!stuckActive)
		{
			if (flag)
			{
				stuckNotClosingTimer = 0f;
			}
			else
			{
				stuckNotClosingTimer += Time.fixedDeltaTime;
				if (stuckNotClosingTimer >= 0.5f)
				{
					EnterStuckPushPhase(position5);
				}
			}
		}
		else
		{
			stuckPhaseTimer -= Time.fixedDeltaTime;
			if (stuckPhaseTimer <= 0f)
			{
				if (stuckPhaseDislodge)
				{
					ExitStuckPhase();
				}
				else
				{
					EnterDislodgePhase();
				}
			}
		}
		stuckPrevDistance = num16;
		if (!stuckActive)
		{
			val11 = position6 - position5;
			Vector3 normalized = val11.normalized;
			Vector3 val18 = SemiFunc.PhysFollowDirection(((Component)rb).transform, normalized, rb, 10f) * 2f;
			rb.AddTorque(val18 / rb.mass * num, (ForceMode)0);
			Vector3 val19 = SemiFunc.PhysFollowPosition(position5, position6, rb.linearVelocity, 5f);
			rb.AddForce(val19 * num, (ForceMode)1);
		}
		if (!stuckActive)
		{
			return;
		}
		if (stuckPhaseDislodge)
		{
			val11 = position5 - ((Component)this).transform.position;
			Vector3 val20 = val11.normalized;
			if (val20.sqrMagnitude < 0.001f)
			{
				val20 = -Vector3.forward;
			}
			val11 = Vector3.Cross(Vector3.up, val20);
			Vector3 val21 = val11.normalized;
			if (val21.sqrMagnitude < 0.001f)
			{
				val21 = Vector3.right;
			}
			rb.AddForce(val20 * dislodgeBackwardForce, (ForceMode)0);
			rb.AddForce(Vector3.up * dislodgeUpForce, (ForceMode)0);
			rb.AddTorque(val21 * dislodgeTorqueForce, (ForceMode)0);
		}
		else
		{
			rb.AddForce(stuckPushDirection * stuckPushForce, (ForceMode)0);
		}
	}

	private void EnterStuckPushPhase(Vector3 _currentPosition)
	{
		//IL_001a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0021: Unknown result type (might be due to invalid IL or missing references)
		//IL_0026: Unknown result type (might be due to invalid IL or missing references)
		//IL_002b: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0033: Unknown result type (might be due to invalid IL or missing references)
		//IL_0048: Unknown result type (might be due to invalid IL or missing references)
		//IL_0049: Unknown result type (might be due to invalid IL or missing references)
		//IL_004e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0053: Unknown result type (might be due to invalid IL or missing references)
		//IL_0056: Unknown result type (might be due to invalid IL or missing references)
		//IL_005b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0042: Unknown result type (might be due to invalid IL or missing references)
		//IL_0047: Unknown result type (might be due to invalid IL or missing references)
		//IL_0090: Unknown result type (might be due to invalid IL or missing references)
		//IL_0091: Unknown result type (might be due to invalid IL or missing references)
		//IL_0096: Unknown result type (might be due to invalid IL or missing references)
		//IL_0097: Unknown result type (might be due to invalid IL or missing references)
		//IL_009c: Unknown result type (might be due to invalid IL or missing references)
		//IL_006a: Unknown result type (might be due to invalid IL or missing references)
		//IL_006b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0070: Unknown result type (might be due to invalid IL or missing references)
		//IL_0075: Unknown result type (might be due to invalid IL or missing references)
		//IL_0078: Unknown result type (might be due to invalid IL or missing references)
		//IL_007d: Unknown result type (might be due to invalid IL or missing references)
		stuckActive = true;
		stuckPhaseDislodge = false;
		stuckPhaseTimer = stuckPhaseDuration;
		Vector3 val = _currentPosition - ((Component)this).transform.position;
		Vector3 val2 = val.normalized;
		if (val2.sqrMagnitude < 0.001f)
		{
			val2 = Vector3.forward;
		}
		val = Vector3.Cross(val2, Vector3.up);
		Vector3 normalized = val.normalized;
		if (normalized.sqrMagnitude < 0.001f)
		{
			val = Vector3.Cross(val2, Vector3.right);
			normalized = val.normalized;
		}
		float num = Random.Range(0f, 360f);
		stuckPushDirection = Quaternion.AngleAxis(num, val2) * normalized;
	}

	private void EnterDislodgePhase()
	{
		stuckActive = true;
		stuckPhaseDislodge = true;
		stuckPhaseTimer = stuckPhaseDuration;
	}

	private void ExitStuckPhase()
	{
		stuckActive = false;
		stuckPhaseDislodge = false;
		stuckPhaseTimer = 0f;
		stuckNotClosingTimer = 0f;
	}

	private void PlayLine(int index, int type = 0)
	{
		//IL_0036: Unknown result type (might be due to invalid IL or missing references)
		//IL_003c: Unknown result type (might be due to invalid IL or missing references)
		if (SemiFunc.IsMultiplayer())
		{
			photonView.RPC("PlayLineRPC", (RpcTarget)0, new object[2] { index, type });
		}
		else
		{
			PlayLineRPC(index, type);
		}
	}

	private void SetRandomScanRotation(float _angleY, float _angleX)
	{
		//IL_0036: Unknown result type (might be due to invalid IL or missing references)
		//IL_003c: Unknown result type (might be due to invalid IL or missing references)
		if (SemiFunc.IsMultiplayer())
		{
			photonView.RPC("SetRandomScanRotationRPC", (RpcTarget)0, new object[2] { _angleY, _angleX });
		}
		else
		{
			SetRandomScanRotationRPC(_angleY, _angleX);
		}
	}

	private void FreezeAim(Quaternion _aimX, Quaternion _aimY)
	{
		//IL_0002: Unknown result type (might be due to invalid IL or missing references)
		//IL_0007: Unknown result type (might be due to invalid IL or missing references)
		//IL_000a: Unknown result type (might be due to invalid IL or missing references)
		//IL_000f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0042: Unknown result type (might be due to invalid IL or missing references)
		//IL_0043: Unknown result type (might be due to invalid IL or missing references)
		//IL_0046: Unknown result type (might be due to invalid IL or missing references)
		//IL_004c: Unknown result type (might be due to invalid IL or missing references)
		//IL_002b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0034: Unknown result type (might be due to invalid IL or missing references)
		Vector3 eulerAngles = _aimX.eulerAngles;
		Vector3 eulerAngles2 = _aimY.eulerAngles;
		if (SemiFunc.IsMultiplayer())
		{
			photonView.RPC("FreezeAimRPC", (RpcTarget)0, new object[2] { eulerAngles, eulerAngles2 });
		}
		else
		{
			FreezeAimRPC(eulerAngles, eulerAngles2);
		}
	}

	private void ShowNewEmoji(string[] _type)
	{
		//IL_0059: Unknown result type (might be due to invalid IL or missing references)
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		int num = emojiTypes.IndexOf(_type);
		int randomEmojiIndex = GetRandomEmojiIndex(_type);
		prevTypeIndex = num;
		prevEmojiIndex = randomEmojiIndex;
		if (SemiFunc.IsMultiplayer())
		{
			photonView.RPC("ShowNewEmojiRPC", (RpcTarget)0, new object[2] { num, randomEmojiIndex });
		}
		else
		{
			ShowNewEmojiRPC(num, randomEmojiIndex);
		}
	}

	public void ShootAtPlayer(PlayerAvatar _player)
	{
		//IL_00be: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c9: Unknown result type (might be due to invalid IL or missing references)
		if (SemiFunc.IsMasterClientOrSingleplayer() && Object.op_Implicit((Object)(object)_player) && !InItemReactionFlow() && currentState != State.Sleeping && currentState != State.WakeUp && !InRuckusFlow())
		{
			if ((currentState == State.WarnGrabPlayer || currentState == State.WarnTellOff) && PlayerTargetValid() && (Object)(object)playerTarget != (Object)(object)_player)
			{
				ThrowCurrentTargetAway();
			}
			playerTarget = _player;
			prevPlayerTarget = _player;
			if (SemiFunc.IsMultiplayer() && Object.op_Implicit((Object)(object)_player.photonView))
			{
				photonView.RPC("UpdatePlayerTargetRPC", (RpcTarget)1, new object[1] { _player.photonView.ViewID });
			}
			ruckusTarget = true;
			if (Vector3.Distance(((Component)this).transform.position, ((Component)_player).transform.position) > ruckusWaitDistance)
			{
				UpdateState(State.WaitForRuckusPlayer);
			}
			else
			{
				UpdateState(State.SeeRuckusPlayer);
			}
		}
	}

	private void ThrowCurrentTargetAway()
	{
		//IL_004c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0057: Unknown result type (might be due to invalid IL or missing references)
		//IL_005c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0061: Unknown result type (might be due to invalid IL or missing references)
		//IL_0064: Unknown result type (might be due to invalid IL or missing references)
		//IL_0069: Unknown result type (might be due to invalid IL or missing references)
		//IL_007e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0084: Unknown result type (might be due to invalid IL or missing references)
		//IL_0089: Unknown result type (might be due to invalid IL or missing references)
		//IL_0093: Unknown result type (might be due to invalid IL or missing references)
		//IL_0098: Unknown result type (might be due to invalid IL or missing references)
		//IL_009d: Unknown result type (might be due to invalid IL or missing references)
		//IL_009f: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a9: Unknown result type (might be due to invalid IL or missing references)
		//IL_00bb: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c0: Unknown result type (might be due to invalid IL or missing references)
		//IL_0078: Unknown result type (might be due to invalid IL or missing references)
		//IL_007d: Unknown result type (might be due to invalid IL or missing references)
		//IL_00eb: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ee: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f4: Unknown result type (might be due to invalid IL or missing references)
		//IL_00dc: Unknown result type (might be due to invalid IL or missing references)
		if (SemiFunc.IsMasterClientOrSingleplayer() && PlayerTargetValid() && Object.op_Implicit((Object)(object)playerTarget.tumble) && Object.op_Implicit((Object)(object)playerTarget.tumble.rb))
		{
			Rigidbody rb = playerTarget.tumble.rb;
			Vector3 val = rb.position - ((Component)this).transform.position;
			Vector3 val2 = val.normalized;
			if (val2.sqrMagnitude < 0.001f)
			{
				val2 = Vector3.forward;
			}
			Vector3 val3 = val2 * 22f + Vector3.up * 7f;
			rb.linearVelocity = Vector3.zero;
			rb.AddForce(val3, (ForceMode)2);
			Vector3 position = ((Component)playerTarget).transform.position;
			if (SemiFunc.IsMultiplayer())
			{
				photonView.RPC("ThrowSoundAtRPC", (RpcTarget)0, new object[1] { position });
			}
			else
			{
				ThrowSoundAtRPC(position);
			}
			ForceClearGrabBeamOverride(_playRelease: true);
		}
	}

	[PunRPC]
	private void ThrowSoundAtRPC(Vector3 _pos, PhotonMessageInfo _info = default(PhotonMessageInfo))
	{
		//IL_0000: Unknown result type (might be due to invalid IL or missing references)
		//IL_000f: Unknown result type (might be due to invalid IL or missing references)
		if (SemiFunc.MasterOnlyRPC(_info))
		{
			throwPlayerSound.Play(_pos);
		}
	}

	public void PlayerDamagedPlayer(PlayerAvatar _attacker, PlayerAvatar _victim, int _damage, bool _tumbled, bool _killed, bool _forceRuckus = false)
	{
		if (!SemiFunc.IsMasterClientOrSingleplayer() || !Object.op_Implicit((Object)(object)_attacker) || !Object.op_Implicit((Object)(object)_victim) || (Object)(object)_attacker == (Object)(object)_victim)
		{
			return;
		}
		if (_killed && InWarnFlow() && (Object)(object)playerTarget == (Object)(object)_attacker)
		{
			ShootAtPlayer(_attacker);
			return;
		}
		bool num = _tumbled || _victim.isTumbling;
		PlayerRuckusRecord playerRuckusRecord = RuckusRecordGet(_attacker, _victim);
		if (_damage > 0)
		{
			playerRuckusRecord.damageAccumulated += _damage;
		}
		playerRuckusRecord.hitCount++;
		if (num)
		{
			playerRuckusRecord.tumbleCount++;
		}
		playerRuckusRecord.cooldownTimer = 6f;
		AddRuckusScore(_attacker, 15f);
		if (_damage > 0)
		{
			AddRuckusScore(_attacker, (float)_damage * 5f);
		}
		if (num)
		{
			AddRuckusScore(_attacker, 50f);
		}
		bool flag = false;
		if (_forceRuckus)
		{
			flag = true;
		}
		else if (_killed)
		{
			flag = true;
		}
		else if (playerRuckusRecord.damageAccumulated >= 20f)
		{
			flag = true;
		}
		else if (playerRuckusRecord.hitCount >= 3)
		{
			flag = true;
		}
		if (flag)
		{
			RuckusRecordForget(_attacker);
			AddRuckusScore(_attacker, 200f);
		}
		else if ((playerRuckusRecord.hitCount >= 2 || playerRuckusRecord.damageAccumulated >= 13.200001f) && !playerRuckusRecord.angryTriggered)
		{
			playerRuckusRecord.angryTriggered = true;
			TriggerAngryObservation(_attacker);
		}
	}

	public void PlayerShotGun(PlayerAvatar _shooter)
	{
		if (SemiFunc.IsMasterClientOrSingleplayer() && Object.op_Implicit((Object)(object)_shooter))
		{
			AddRuckusScore(_shooter, 100f);
		}
	}

	public void PlayerActivatedExplosive(PlayerAvatar _player)
	{
		if (SemiFunc.IsMasterClientOrSingleplayer() && Object.op_Implicit((Object)(object)_player))
		{
			AddRuckusScore(_player, 200f);
		}
	}

	public void PlayerActivatedMine(PlayerAvatar _player)
	{
		if (SemiFunc.IsMasterClientOrSingleplayer() && Object.op_Implicit((Object)(object)_player))
		{
			AddRuckusScore(_player, 100f);
		}
	}

	public void PlayerExplosiveDetonated(PlayerAvatar _player)
	{
		if (SemiFunc.IsMasterClientOrSingleplayer() && Object.op_Implicit((Object)(object)_player))
		{
			AddRuckusScore(_player, 200f);
		}
	}

	public void PlayerStaffCast(PlayerAvatar _player)
	{
		if (SemiFunc.IsMasterClientOrSingleplayer() && Object.op_Implicit((Object)(object)_player))
		{
			AddRuckusScore(_player, 200f);
		}
	}

	public void PlayerMeleeHitPhysObject(PlayerAvatar _player)
	{
		if (SemiFunc.IsMasterClientOrSingleplayer() && Object.op_Implicit((Object)(object)_player))
		{
			AddRuckusScore(_player, 100f);
		}
	}

	public void PlayerDriftingTick(PlayerAvatar _driver)
	{
		if (SemiFunc.IsMasterClientOrSingleplayer() && Object.op_Implicit((Object)(object)_driver))
		{
			AddRuckusScore(_driver, 50f * Time.deltaTime);
		}
	}

	public void PlayerLaserTick(PlayerAvatar _player)
	{
		if (SemiFunc.IsMasterClientOrSingleplayer() && Object.op_Implicit((Object)(object)_player))
		{
			AddRuckusScore(_player, 100f * Time.deltaTime);
		}
	}

	public void PlayerVehicleImpactHitPlayer(PlayerAvatar _driver, PlayerAvatar _victim)
	{
		if (SemiFunc.IsMasterClientOrSingleplayer() && Object.op_Implicit((Object)(object)_driver) && Object.op_Implicit((Object)(object)_victim) && !((Object)(object)_driver == (Object)(object)_victim))
		{
			PlayerRuckusRecord playerRuckusRecord = RuckusRecordGet(_driver, _victim);
			playerRuckusRecord.hitCount++;
			if (_victim.isTumbling)
			{
				playerRuckusRecord.tumbleCount++;
			}
			playerRuckusRecord.cooldownTimer = 6f;
			AddRuckusScore(_driver, 100f);
			if (playerRuckusRecord.damageAccumulated >= 20f || playerRuckusRecord.hitCount >= 3)
			{
				RuckusRecordForget(_driver);
				AddRuckusScore(_driver, 200f);
			}
			else if ((playerRuckusRecord.hitCount >= 2 || playerRuckusRecord.damageAccumulated >= 13.200001f) && !playerRuckusRecord.angryTriggered)
			{
				playerRuckusRecord.angryTriggered = true;
				TriggerAngryObservation(_driver);
			}
		}
	}

	public void PlayerPhysObjectHitPlayer(PlayerAvatar _attacker, PlayerAvatar _victim, int _damage, bool _killed)
	{
		if (!SemiFunc.IsMasterClientOrSingleplayer() || !Object.op_Implicit((Object)(object)_attacker) || !Object.op_Implicit((Object)(object)_victim) || (Object)(object)_attacker == (Object)(object)_victim)
		{
			return;
		}
		if (_killed && InWarnFlow() && (Object)(object)playerTarget == (Object)(object)_attacker)
		{
			ShootAtPlayer(_attacker);
			return;
		}
		bool isTumbling = _victim.isTumbling;
		PlayerRuckusRecord playerRuckusRecord = RuckusRecordGet(_attacker, _victim);
		if (_damage > 0)
		{
			playerRuckusRecord.damageAccumulated += _damage;
		}
		playerRuckusRecord.hitCount++;
		if (isTumbling)
		{
			playerRuckusRecord.tumbleCount++;
		}
		playerRuckusRecord.cooldownTimer = 6f;
		AddRuckusScore(_attacker, 150f);
		if (_killed || playerRuckusRecord.damageAccumulated >= 20f || playerRuckusRecord.hitCount >= 3)
		{
			RuckusRecordForget(_attacker);
			AddRuckusScore(_attacker, 200f);
		}
		else if ((playerRuckusRecord.hitCount >= 2 || playerRuckusRecord.damageAccumulated >= 13.200001f) && !playerRuckusRecord.angryTriggered)
		{
			playerRuckusRecord.angryTriggered = true;
			TriggerAngryObservation(_attacker);
		}
	}

	public void PlayerCarryThrust(PlayerAvatar _carrier, PlayerAvatar _victim)
	{
		if (!SemiFunc.IsMasterClientOrSingleplayer() || !Object.op_Implicit((Object)(object)_carrier) || !Object.op_Implicit((Object)(object)_victim) || (Object)(object)_carrier == (Object)(object)_victim)
		{
			return;
		}
		PlayerCarryThrustRecord playerCarryThrustRecord = CarryThrustRecordGet(_carrier, _victim);
		playerCarryThrustRecord.thrustCount++;
		playerCarryThrustRecord.windowTimer = 12f;
		AddRuckusScore(_carrier, 40f);
		if (playerCarryThrustRecord.thrustCount >= 6)
		{
			bool flag = false;
			if (Object.op_Implicit((Object)(object)_victim.tumble) && Object.op_Implicit((Object)(object)_victim.tumble.physGrabObject))
			{
				foreach (PhysGrabber item in _victim.tumble.physGrabObject.playerGrabbing)
				{
					if (Object.op_Implicit((Object)(object)item) && (Object)(object)item.playerAvatar == (Object)(object)_carrier)
					{
						flag = true;
						break;
					}
				}
			}
			if (flag)
			{
				CarryThrustRecordForget(_carrier);
				AddRuckusScore(_carrier, 200f);
			}
			else
			{
				CarryThrustRecordForget(_carrier);
			}
		}
		else if (playerCarryThrustRecord.thrustCount >= 5 && !playerCarryThrustRecord.angryTriggered)
		{
			playerCarryThrustRecord.angryTriggered = true;
			TriggerAngryObservation(_carrier);
		}
	}

	private PlayerRuckusRecord RuckusRecordGet(PlayerAvatar _attacker, PlayerAvatar _victim)
	{
		if (!ruckusRecords.TryGetValue(_attacker, out var value))
		{
			value = new List<PlayerRuckusRecord>();
			ruckusRecords[_attacker] = value;
		}
		foreach (PlayerRuckusRecord item in value)
		{
			if ((Object)(object)item.victim == (Object)(object)_victim)
			{
				return item;
			}
		}
		PlayerRuckusRecord playerRuckusRecord = new PlayerRuckusRecord();
		playerRuckusRecord.victim = _victim;
		value.Add(playerRuckusRecord);
		return playerRuckusRecord;
	}

	private void RuckusRecordForget(PlayerAvatar _attacker)
	{
		if (ruckusRecords.ContainsKey(_attacker))
		{
			ruckusRecords.Remove(_attacker);
		}
	}

	private PlayerCarryThrustRecord CarryThrustRecordGet(PlayerAvatar _carrier, PlayerAvatar _victim)
	{
		if (!carryThrustRecords.TryGetValue(_carrier, out var value))
		{
			value = new List<PlayerCarryThrustRecord>();
			carryThrustRecords[_carrier] = value;
		}
		foreach (PlayerCarryThrustRecord item in value)
		{
			if ((Object)(object)item.victim == (Object)(object)_victim)
			{
				return item;
			}
		}
		PlayerCarryThrustRecord playerCarryThrustRecord = new PlayerCarryThrustRecord();
		playerCarryThrustRecord.victim = _victim;
		value.Add(playerCarryThrustRecord);
		return playerCarryThrustRecord;
	}

	private void CarryThrustRecordForget(PlayerAvatar _carrier)
	{
		if (carryThrustRecords.ContainsKey(_carrier))
		{
			carryThrustRecords.Remove(_carrier);
		}
	}

	private void AddRuckusScore(PlayerAvatar _player, float _amount)
	{
		if (!Object.op_Implicit((Object)(object)_player) || _amount <= 0f || ((InRuckusFlow() || InWarnFlow()) && (Object)(object)playerTarget == (Object)(object)_player))
		{
			return;
		}
		if (!ruckusScores.TryGetValue(_player, out var value))
		{
			value = new PlayerRuckusScoreRecord();
			value.player = _player;
			ruckusScores[_player] = value;
		}
		value.score += _amount;
		if (currentState == State.Sleeping)
		{
			value.score = Mathf.Min(value.score, 500f);
		}
		bool flag = !InRuckusFlow() && !InItemReactionFlow() && currentState != State.Sleeping && currentState != State.WakeUp;
		if (value.angryThresholdIndex < angryScoreThresholds.Length)
		{
			if (flag && value.score >= angryScoreThresholds[value.angryThresholdIndex] && Time.time - value.lastWarnedTime > 5f)
			{
				while (value.angryThresholdIndex < angryScoreThresholds.Length && value.score >= angryScoreThresholds[value.angryThresholdIndex])
				{
					value.angryThresholdIndex++;
				}
				value.lastWarnedTime = Time.time;
				WarnPlayer(_player);
			}
		}
		else if (flag && value.score >= 1000f)
		{
			ruckusPunishFromScoreCache.Add(_player);
			value.score = 800f;
			ShootAtPlayer(_player);
		}
	}

	private void ClampRuckusScoresForSleep()
	{
		foreach (KeyValuePair<PlayerAvatar, PlayerRuckusScoreRecord> ruckusScore in ruckusScores)
		{
			PlayerRuckusScoreRecord value = ruckusScore.Value;
			if (value.score > 500f)
			{
				value.score = 500f;
			}
		}
	}

	private void ExcusePendingWarningsOnWake()
	{
		foreach (KeyValuePair<PlayerAvatar, PlayerRuckusScoreRecord> ruckusScore in ruckusScores)
		{
			PlayerRuckusScoreRecord value = ruckusScore.Value;
			while (value.angryThresholdIndex < angryScoreThresholds.Length && value.score >= angryScoreThresholds[value.angryThresholdIndex])
			{
				value.angryThresholdIndex++;
			}
		}
	}

	private void CheckPendingRuckusActions()
	{
		if (!SemiFunc.IsMasterClientOrSingleplayer() || currentState != State.Observe || ruckusScores.Count == 0)
		{
			return;
		}
		PlayerAvatar playerAvatar = null;
		float num = -1f;
		PlayerAvatar playerAvatar2 = null;
		float num2 = -1f;
		foreach (KeyValuePair<PlayerAvatar, PlayerRuckusScoreRecord> ruckusScore in ruckusScores)
		{
			PlayerRuckusScoreRecord value = ruckusScore.Value;
			PlayerAvatar player = value.player;
			if (!Object.op_Implicit((Object)(object)player) || player.deadSet || player.isDisabled || player.spectating || !((Component)player).gameObject.activeInHierarchy)
			{
				continue;
			}
			if (value.angryThresholdIndex < angryScoreThresholds.Length)
			{
				if (value.score >= angryScoreThresholds[value.angryThresholdIndex] && Time.time - value.lastWarnedTime > 5f && value.score > num)
				{
					playerAvatar = player;
					num = value.score;
				}
			}
			else if (value.score >= 1000f && value.score > num2)
			{
				playerAvatar2 = player;
				num2 = value.score;
			}
		}
		if (Object.op_Implicit((Object)(object)playerAvatar))
		{
			PlayerRuckusScoreRecord playerRuckusScoreRecord = ruckusScores[playerAvatar];
			while (playerRuckusScoreRecord.angryThresholdIndex < angryScoreThresholds.Length && playerRuckusScoreRecord.score >= angryScoreThresholds[playerRuckusScoreRecord.angryThresholdIndex])
			{
				playerRuckusScoreRecord.angryThresholdIndex++;
			}
			playerRuckusScoreRecord.lastWarnedTime = Time.time;
			WarnPlayer(playerAvatar);
		}
		else if (Object.op_Implicit((Object)(object)playerAvatar2))
		{
			PlayerRuckusScoreRecord playerRuckusScoreRecord2 = ruckusScores[playerAvatar2];
			ruckusPunishFromScoreCache.Add(playerAvatar2);
			playerRuckusScoreRecord2.score = 800f;
			ShootAtPlayer(playerAvatar2);
		}
	}

	private void ResolveRuckusPunishment(PlayerAvatar _player)
	{
		if (_player != null && ruckusPunishFromScoreCache.Remove(_player) && ruckusScores.TryGetValue(_player, out var value))
		{
			value.score = 800f;
		}
	}

	private void ResolveRuckusPunishmentFailed(PlayerAvatar _player)
	{
		if (_player != null && ruckusPunishFromScoreCache.Remove(_player) && ruckusScores.TryGetValue(_player, out var value))
		{
			value.score = Mathf.Max(0f, 950f);
		}
	}

	private void RuckusRecordTick()
	{
		if (ruckusRecords.Count > 0)
		{
			ruckusRecordKeyCache.Clear();
			foreach (KeyValuePair<PlayerAvatar, List<PlayerRuckusRecord>> ruckusRecord in ruckusRecords)
			{
				ruckusRecordKeyCache.Add(ruckusRecord.Key);
			}
			foreach (PlayerAvatar item in ruckusRecordKeyCache)
			{
				List<PlayerRuckusRecord> list = ruckusRecords[item];
				for (int num = list.Count - 1; num >= 0; num--)
				{
					list[num].cooldownTimer -= Time.deltaTime;
					if (list[num].cooldownTimer <= 0f)
					{
						list.RemoveAt(num);
					}
				}
				if (list.Count == 0)
				{
					ruckusRecords.Remove(item);
				}
			}
		}
		if (carryThrustRecords.Count <= 0)
		{
			return;
		}
		ruckusRecordKeyCache.Clear();
		foreach (KeyValuePair<PlayerAvatar, List<PlayerCarryThrustRecord>> carryThrustRecord in carryThrustRecords)
		{
			ruckusRecordKeyCache.Add(carryThrustRecord.Key);
		}
		foreach (PlayerAvatar item2 in ruckusRecordKeyCache)
		{
			List<PlayerCarryThrustRecord> list2 = carryThrustRecords[item2];
			for (int num2 = list2.Count - 1; num2 >= 0; num2--)
			{
				list2[num2].windowTimer -= Time.deltaTime;
				if (list2[num2].windowTimer <= 0f)
				{
					list2.RemoveAt(num2);
				}
			}
			if (list2.Count == 0)
			{
				carryThrustRecords.Remove(item2);
			}
		}
	}

	public void WakeUpOrSleepLogic()
	{
		//IL_0082: Unknown result type (might be due to invalid IL or missing references)
		//IL_0088: Unknown result type (might be due to invalid IL or missing references)
		//IL_0054: Unknown result type (might be due to invalid IL or missing references)
		//IL_005a: Unknown result type (might be due to invalid IL or missing references)
		if (onOffCooldown > 0f || InRuckusFlow() || InItemReactionFlow())
		{
			return;
		}
		onOffCooldown = 0.5f;
		if (currentState == State.Sleeping)
		{
			if (SemiFunc.IsMultiplayer())
			{
				photonView.RPC("WakeUpRPC", (RpcTarget)0, Array.Empty<object>());
			}
			else
			{
				WakeUpRPC();
			}
		}
		else if (SemiFunc.IsMultiplayer())
		{
			photonView.RPC("SleepRPC", (RpcTarget)0, Array.Empty<object>());
		}
		else
		{
			SleepRPC();
		}
	}

	[PunRPC]
	private void ShootRPC(Vector3 _hitPosition, PhotonMessageInfo _info = default(PhotonMessageInfo))
	{
		//IL_0000: Unknown result type (might be due to invalid IL or missing references)
		//IL_0009: Unknown result type (might be due to invalid IL or missing references)
		//IL_0010: Unknown result type (might be due to invalid IL or missing references)
		//IL_0015: Unknown result type (might be due to invalid IL or missing references)
		//IL_001a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0039: Unknown result type (might be due to invalid IL or missing references)
		//IL_0050: Unknown result type (might be due to invalid IL or missing references)
		//IL_0057: Unknown result type (might be due to invalid IL or missing references)
		//IL_0061: Unknown result type (might be due to invalid IL or missing references)
		//IL_0066: Unknown result type (might be due to invalid IL or missing references)
		//IL_0077: Unknown result type (might be due to invalid IL or missing references)
		//IL_007a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0084: Unknown result type (might be due to invalid IL or missing references)
		//IL_0089: Unknown result type (might be due to invalid IL or missing references)
		//IL_009a: Unknown result type (might be due to invalid IL or missing references)
		//IL_00be: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d5: Unknown result type (might be due to invalid IL or missing references)
		//IL_00dc: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e6: Unknown result type (might be due to invalid IL or missing references)
		//IL_00eb: Unknown result type (might be due to invalid IL or missing references)
		//IL_00fc: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ff: Unknown result type (might be due to invalid IL or missing references)
		//IL_0109: Unknown result type (might be due to invalid IL or missing references)
		//IL_010e: Unknown result type (might be due to invalid IL or missing references)
		//IL_011f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0142: Unknown result type (might be due to invalid IL or missing references)
		//IL_0159: Unknown result type (might be due to invalid IL or missing references)
		//IL_015e: Unknown result type (might be due to invalid IL or missing references)
		//IL_018b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0190: Unknown result type (might be due to invalid IL or missing references)
		//IL_0195: Unknown result type (might be due to invalid IL or missing references)
		//IL_01c2: Unknown result type (might be due to invalid IL or missing references)
		//IL_01d8: Unknown result type (might be due to invalid IL or missing references)
		//IL_0221: Unknown result type (might be due to invalid IL or missing references)
		//IL_0237: Unknown result type (might be due to invalid IL or missing references)
		//IL_027a: Unknown result type (might be due to invalid IL or missing references)
		//IL_028c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0366: Unknown result type (might be due to invalid IL or missing references)
		//IL_0394: Unknown result type (might be due to invalid IL or missing references)
		//IL_03bc: Unknown result type (might be due to invalid IL or missing references)
		//IL_03e0: Unknown result type (might be due to invalid IL or missing references)
		//IL_03f7: Unknown result type (might be due to invalid IL or missing references)
		//IL_0422: Unknown result type (might be due to invalid IL or missing references)
		//IL_0447: Unknown result type (might be due to invalid IL or missing references)
		if (!SemiFunc.MasterOnlyRPC(_info))
		{
			return;
		}
		Vector3 val = _hitPosition - gunTipBigTransform.position;
		((Component)lineRenderer).gameObject.SetActive(true);
		lineRenderer.SetPosition(0, gunTipBigTransform.position);
		lineRenderer.SetPosition(1, gunTipBigTransform.position + val.normalized * 0.5f);
		lineRenderer.SetPosition(2, _hitPosition - val.normalized * 0.5f);
		lineRenderer.SetPosition(3, _hitPosition);
		((Component)linerendererSmall).gameObject.SetActive(true);
		linerendererSmall.SetPosition(0, gunTipSmallTransform.position);
		linerendererSmall.SetPosition(1, gunTipSmallTransform.position + val.normalized * 0.5f);
		linerendererSmall.SetPosition(2, _hitPosition - val.normalized * 0.5f);
		linerendererSmall.SetPosition(3, _hitPosition);
		lineRendererActive = true;
		lineRendererLerp = 0f;
		((Component)hurtCollider).transform.position = _hitPosition;
		((Component)hurtCollider).transform.rotation = Quaternion.LookRotation(gunTipBigTransform.forward);
		hurtCollider.hasCustomRaycastPosition = true;
		hurtCollider.customRaycastPosition = ((Component)hurtCollider).transform.InverseTransformPoint(gunTipBigTransform.position);
		((Component)hurtCollider).gameObject.SetActive(true);
		hurtColliderTimer = 0.25f;
		shootEffectTransform.position = gunTipBigTransform.position;
		shootEffectTransform.rotation = gunTipBigTransform.rotation;
		foreach (ParticleSystem shootEffect in shootEffects)
		{
			shootEffect.Play();
		}
		shootEffectSmallTransform.position = gunTipSmallTransform.position;
		shootEffectSmallTransform.rotation = gunTipSmallTransform.rotation;
		foreach (ParticleSystem item in shootEffectsSmall)
		{
			item.Play();
		}
		hitEffectTransform.position = _hitPosition;
		hitEffectTransform.rotation = gunTipBigTransform.rotation;
		foreach (ParticleSystem hitEffect in hitEffects)
		{
			hitEffect.Play();
		}
		shootLightActive = true;
		hitLightActive = true;
		((Behaviour)shootLight.lightComponent).enabled = true;
		shootLight.lightComponent.intensity = shootLightIntensity;
		shootLight.originalIntensity = shootLightIntensity;
		((Behaviour)hitLight.lightComponent).enabled = true;
		hitLight.lightComponent.intensity = hitLightIntensity;
		hitLight.originalIntensity = hitLightIntensity;
		GameDirector.instance.CameraShake.ShakeDistance(5f, 3f, 15f, gunTipBigTransform.position, 0.5f);
		GameDirector.instance.CameraImpact.ShakeDistance(8f, 3f, 15f, gunTipBigTransform.position, 0.05f);
		GameDirector.instance.CameraShake.ShakeDistance(3f, 3f, 10f, _hitPosition, 0.5f);
		GameDirector.instance.CameraImpact.ShakeDistance(3f, 3f, 10f, _hitPosition, 0.05f);
		soundShoot.Play(gunTipBigTransform.position);
		soundShootGlobal.Play(gunTipBigTransform.position);
		soundHit.Play(_hitPosition);
	}

	[PunRPC]
	private void PlayLineRPC(int index, int type, PhotonMessageInfo _info = default(PhotonMessageInfo))
	{
		//IL_0000: Unknown result type (might be due to invalid IL or missing references)
		//IL_0091: Unknown result type (might be due to invalid IL or missing references)
		if (SemiFunc.MasterOnlyRPC(_info))
		{
			List<AudioClip> list = type switch
			{
				1 => voiceBoxSoundClipsAngry, 
				2 => voiceBoxSoundClipsSee, 
				3 => voiceBoxSoundClipsGrab, 
				4 => voiceBoxSoundClipsJudge, 
				_ => voiceBoxSoundClips, 
			};
			if (list != null && list.Count != 0 && index >= 0 && index < list.Count)
			{
				AudioClip[] sounds = new AudioClip[1] { list[index] };
				voiceBoxSound.Sounds = sounds;
				voiceBoxSound.Play(VoiceBox.position);
			}
		}
	}

	[PunRPC]
	private void SetRandomScanRotationRPC(float _angleY, float _angleX, PhotonMessageInfo _info = default(PhotonMessageInfo))
	{
		//IL_0000: Unknown result type (might be due to invalid IL or missing references)
		//IL_0015: Unknown result type (might be due to invalid IL or missing references)
		//IL_001a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0030: Unknown result type (might be due to invalid IL or missing references)
		if (SemiFunc.MasterOnlyRPC(_info))
		{
			rotationTargetY = Quaternion.Euler(0f, _angleY, 0f);
			rotationTargetX.eulerAngles = new Vector3(_angleX, 0f, 0f);
		}
	}

	[PunRPC]
	private void FreezeAimRPC(Vector3 _eulerX, Vector3 _eulerY, PhotonMessageInfo _info = default(PhotonMessageInfo))
	{
		//IL_0000: Unknown result type (might be due to invalid IL or missing references)
		//IL_000a: Unknown result type (might be due to invalid IL or missing references)
		//IL_000b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0010: Unknown result type (might be due to invalid IL or missing references)
		//IL_0016: Unknown result type (might be due to invalid IL or missing references)
		//IL_0017: Unknown result type (might be due to invalid IL or missing references)
		//IL_001c: Unknown result type (might be due to invalid IL or missing references)
		if (SemiFunc.MasterOnlyRPC(_info))
		{
			frozenAimTargetX = Quaternion.Euler(_eulerX);
			frozenAimTargetY = Quaternion.Euler(_eulerY);
		}
	}

	[PunRPC]
	private void ShowNewEmojiRPC(int _typeIndex, int _emojiIndex, PhotonMessageInfo _info = default(PhotonMessageInfo))
	{
		//IL_0000: Unknown result type (might be due to invalid IL or missing references)
		if (SemiFunc.MasterOnlyRPC(_info))
		{
			DisplayEmoji(emojiTypes[_typeIndex][_emojiIndex]);
		}
	}

	[PunRPC]
	private void FlashRPC(PhotonMessageInfo _info = default(PhotonMessageInfo))
	{
		//IL_0000: Unknown result type (might be due to invalid IL or missing references)
		//IL_003d: Unknown result type (might be due to invalid IL or missing references)
		//IL_006b: Unknown result type (might be due to invalid IL or missing references)
		if (SemiFunc.MasterOnlyRPC(_info))
		{
			flashActive = true;
			BigSensorActive = true;
			SmallSensorActive = true;
			GameDirector.instance.CameraShake.ShakeDistance(3f, 3f, 15f, ((Component)this).transform.position, 0.1f);
			GameDirector.instance.CameraImpact.ShakeDistance(3f, 3f, 15f, ((Component)this).transform.position, 0.05f);
		}
	}

	[PunRPC]
	private void SmallSensorBreakerRPC(PhotonMessageInfo _info = default(PhotonMessageInfo))
	{
		//IL_0000: Unknown result type (might be due to invalid IL or missing references)
		if (SemiFunc.MasterOnlyRPC(_info))
		{
			SmallSensorActive = true;
		}
	}

	[PunRPC]
	private void BigSensorBreakerRPC(PhotonMessageInfo _info = default(PhotonMessageInfo))
	{
		//IL_0000: Unknown result type (might be due to invalid IL or missing references)
		if (SemiFunc.MasterOnlyRPC(_info))
		{
			BigSensorActive = true;
		}
	}

	[PunRPC]
	private void BonkLandRPC(Vector3 _bonkTarget, PhotonMessageInfo _info = default(PhotonMessageInfo))
	{
		//IL_0000: Unknown result type (might be due to invalid IL or missing references)
		//IL_000f: Unknown result type (might be due to invalid IL or missing references)
		if (!SemiFunc.MasterOnlyRPC(_info))
		{
			return;
		}
		bonkSound.Play(_bonkTarget);
		if (Object.op_Implicit((Object)(object)screenBonkParticles))
		{
			screenBonkParticles.Play();
		}
		if (Object.op_Implicit((Object)(object)playerTarget) && playerTarget.isLocal && !SemiFunc.Photosensitivity())
		{
			if (Object.op_Implicit((Object)(object)CameraGlitch.Instance))
			{
				CameraGlitch.Instance.PlayShort();
			}
			if (Object.op_Implicit((Object)(object)GameDirector.instance) && Object.op_Implicit((Object)(object)GameDirector.instance.CameraShake))
			{
				GameDirector.instance.CameraShake.Shake(2f, 0.2f);
			}
			if (Object.op_Implicit((Object)(object)GameDirector.instance) && Object.op_Implicit((Object)(object)GameDirector.instance.CameraImpact))
			{
				GameDirector.instance.CameraImpact.Shake(3f, 0.15f);
			}
		}
	}

	[PunRPC]
	private void WarnTellOffOnEmojiScreenRPC(bool _on, PhotonMessageInfo _info = default(PhotonMessageInfo))
	{
		//IL_0000: Unknown result type (might be due to invalid IL or missing references)
		if (SemiFunc.MasterOnlyRPC(_info))
		{
			warnTellOffOnEmojiScreen = _on;
		}
	}

	[PunRPC]
	private void WarnTellOffAimFrozenRPC(bool _frozen, PhotonMessageInfo _info = default(PhotonMessageInfo))
	{
		//IL_0000: Unknown result type (might be due to invalid IL or missing references)
		if (SemiFunc.MasterOnlyRPC(_info))
		{
			warnTellOffAimFrozen = _frozen;
		}
	}

	[PunRPC]
	private void ShakeSoundStartRPC(int _photonViewID, PhotonMessageInfo _info = default(PhotonMessageInfo))
	{
		//IL_0000: Unknown result type (might be due to invalid IL or missing references)
		if (!SemiFunc.MasterOnlyRPC(_info))
		{
			return;
		}
		Rigidbody target = null;
		foreach (PlayerAvatar item in SemiFunc.PlayerGetList())
		{
			if (Object.op_Implicit((Object)(object)item) && Object.op_Implicit((Object)(object)item.photonView) && item.photonView.ViewID == _photonViewID)
			{
				if (Object.op_Implicit((Object)(object)item.tumble))
				{
					target = item.tumble.rb;
				}
				break;
			}
		}
		ShakeSoundTargetSet(target);
	}

	private void ShakeSoundItemStart(PhysGrabObject _physGrabObject)
	{
		if (!Object.op_Implicit((Object)(object)_physGrabObject) || !Object.op_Implicit((Object)(object)_physGrabObject.rb))
		{
			return;
		}
		if (SemiFunc.IsMultiplayer())
		{
			if (Object.op_Implicit((Object)(object)_physGrabObject.photonView) && _physGrabObject.photonView.ViewID != 0)
			{
				photonView.RPC("ShakeSoundItemStartRPC", (RpcTarget)0, new object[1] { _physGrabObject.photonView.ViewID });
			}
		}
		else
		{
			ShakeSoundTargetSet(_physGrabObject.rb);
		}
	}

	[PunRPC]
	private void ShakeSoundItemStartRPC(int _photonViewID, PhotonMessageInfo _info = default(PhotonMessageInfo))
	{
		//IL_0000: Unknown result type (might be due to invalid IL or missing references)
		if (!SemiFunc.MasterOnlyRPC(_info))
		{
			return;
		}
		PhotonView val = PhotonView.Find(_photonViewID);
		if (Object.op_Implicit((Object)(object)val))
		{
			PhysGrabObject component = ((Component)val).GetComponent<PhysGrabObject>();
			if (Object.op_Implicit((Object)(object)component))
			{
				ShakeSoundTargetSet(component.rb);
			}
		}
	}

	private void ShakeSoundTargetSet(Rigidbody _target)
	{
		//IL_004d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0075: Unknown result type (might be due to invalid IL or missing references)
		shakeSoundTarget = _target;
		shakeSoundActive = (Object)(object)shakeSoundTarget != (Object)null;
		shakeSoundSampleReady = false;
		shakeSoundGoingUp = true;
		shakeSoundCooldown = 0f;
		shakeSoundPrevY = (Object.op_Implicit((Object)(object)shakeSoundTarget) ? shakeSoundTarget.position.y : 0f);
		if (Object.op_Implicit((Object)(object)shakeSoundTarget))
		{
			shakePlayerSound.Play(shakeSoundTarget.position);
		}
	}

	[PunRPC]
	private void ShakeSoundEndRPC(PhotonMessageInfo _info = default(PhotonMessageInfo))
	{
		//IL_0000: Unknown result type (might be due to invalid IL or missing references)
		if (SemiFunc.MasterOnlyRPC(_info))
		{
			shakeSoundActive = false;
			shakeSoundTarget = null;
		}
	}

	private void ShakeSoundLocalLogic()
	{
		//IL_004a: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b0: Unknown result type (might be due to invalid IL or missing references)
		if (shakeSoundCooldown > 0f)
		{
			shakeSoundCooldown -= Time.deltaTime;
		}
		if (!shakeSoundActive)
		{
			return;
		}
		if (!Object.op_Implicit((Object)(object)shakeSoundTarget))
		{
			shakeSoundActive = false;
			shakeSoundTarget = null;
			return;
		}
		float y = shakeSoundTarget.position.y;
		float num = y - shakeSoundPrevY;
		if (shakeSoundSampleReady)
		{
			bool flag = num > 0f;
			if (Mathf.Abs(num) > 0.0001f && flag != shakeSoundGoingUp && shakeSoundCooldown <= 0f)
			{
				shakeSoundGoingUp = flag;
				shakeSoundCooldown = 0.05f;
				shakePlayerSound.Play(shakeSoundTarget.position);
			}
		}
		else
		{
			shakeSoundSampleReady = true;
		}
		shakeSoundPrevY = y;
	}

	[PunRPC]
	private void UpdateStateRPC(State _state, int _playerTargetViewID, int _itemTargetViewID, int _itemReactPlayerViewID, int _scanSeed, double _stateStartTime, int _discountAttempts, Vector2 _scanAim, PhotonMessageInfo _info = default(PhotonMessageInfo))
	{
		//IL_0000: Unknown result type (might be due to invalid IL or missing references)
		//IL_003f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0041: Unknown result type (might be due to invalid IL or missing references)
		//IL_00aa: Unknown result type (might be due to invalid IL or missing references)
		//IL_0109: Unknown result type (might be due to invalid IL or missing references)
		//IL_0143: Unknown result type (might be due to invalid IL or missing references)
		if (SemiFunc.MasterOnlyRPC(_info))
		{
			if (currentState != _state)
			{
				OnLeavingStateVisualCleanup(currentState, _state);
			}
			networkPlayerTargetViewID = _playerTargetViewID;
			networkItemTargetViewID = _itemTargetViewID;
			networkItemReactPlayerViewID = _itemReactPlayerViewID;
			itemScanSeed = _scanSeed;
			itemScanAim = _scanAim;
			currentStateNetworkStartTime = _stateStartTime;
			itemDiscountAttempts = Mathf.Clamp(_discountAttempts, 0, 3);
			float num = (SemiFunc.IsMultiplayer() ? Mathf.Max(0f, (float)(PhotonNetwork.Time - _stateStartTime)) : 0f);
			currentStateEnterTime = Time.time - num;
			if (_state == State.Hurt)
			{
				sparks.Play();
				hurtSound.Play(((Component)this).transform.position);
				AudioClip val = voiceBoxSoundClipsHurt[Random.Range(0, voiceBoxSoundClipsHurt.Count)];
				AudioClip[] sounds = new AudioClip[1] { val };
				voiceBoxSound.Sounds = sounds;
				voiceBoxSound.Play(VoiceBox.position);
				VoiceBoxSoundTime = Time.time;
			}
			if (_state == State.Shock)
			{
				shockWaveBuildUpSound.Play(((Component)this).transform.position);
			}
			if (_state == State.SeeRuckusPlayer || _state == State.SeeWarnPlayer)
			{
				seeRayTimer = 0f;
				seeRayIndex = 0;
			}
			bool flag = InItemReactionFlow();
			bool flag2 = ItemReactionState(_state);
			if (flag && !flag2)
			{
				itemReactObject = null;
				itemReactPlayer = null;
				itemTarget = null;
				ItemMeleeReferencesClear();
				itemScanCurrentCollider = null;
				itemScanColliders.Clear();
			}
			currentState = _state;
			if (_state == State.ScanObject)
			{
				itemScanPresentationSeed = int.MinValue;
			}
			networkTargetRetryTimer = 0f;
			NetworkTargetsResolveTick();
		}
	}

	private void ForceClearGrabBeamOverride(bool _playRelease)
	{
		//IL_004a: Unknown result type (might be due to invalid IL or missing references)
		//IL_004f: Unknown result type (might be due to invalid IL or missing references)
		//IL_000b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0010: Unknown result type (might be due to invalid IL or missing references)
		//IL_002a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0022: Unknown result type (might be due to invalid IL or missing references)
		//IL_002f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0031: Unknown result type (might be due to invalid IL or missing references)
		if (grabBeamOverrideActive & _playRelease)
		{
			Vector3 pos = ((grabBeamOverrideTarget != Vector3.zero) ? grabBeamOverrideTarget : gunTipBigTransform.position);
			PlayReleaseSoundOnce(pos);
		}
		grabBeamOverrideTimer = 0f;
		grabBeamOverrideActive = false;
		grabBeamOverrideTarget = Vector3.zero;
		grabBeamReleaseSoundPlayed = false;
	}

	[PunRPC]
	private void UpdatePlayerTargetRPC(int _photonViewID, PhotonMessageInfo _info = default(PhotonMessageInfo))
	{
		//IL_0000: Unknown result type (might be due to invalid IL or missing references)
		if (!SemiFunc.MasterOnlyRPC(_info))
		{
			return;
		}
		foreach (PlayerAvatar item in SemiFunc.PlayerGetList())
		{
			if (item.photonView.ViewID == _photonViewID)
			{
				playerTarget = item;
				break;
			}
		}
	}

	[PunRPC]
	private void WakeUpRPC(PhotonMessageInfo _info = default(PhotonMessageInfo))
	{
		//IL_0000: Unknown result type (might be due to invalid IL or missing references)
		//IL_003b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0075: Unknown result type (might be due to invalid IL or missing references)
		//IL_007a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0090: Unknown result type (might be due to invalid IL or missing references)
		//IL_00da: Unknown result type (might be due to invalid IL or missing references)
		//IL_0108: Unknown result type (might be due to invalid IL or missing references)
		if (SemiFunc.MasterOnlyRPC(_info) && !InRuckusFlow() && !InItemReactionFlow())
		{
			ExcusePendingWarningsOnWake();
			skipPendingRuckusOnNextObserve = true;
			UpdateState(State.WakeUp);
			powerOn.Play(((Component)this).transform.position);
			onOffSwitchTurningOff = false;
			onOffSwitchEval = 0f;
			onOffSwitchActive = true;
			onOffSwitchEmissionTarget = onOffSwitchEmissionColor;
			onOffSwitchSoundOn.Play(OnOffSwitch.transform.position);
			onOffSwitchLight.SetActive(true);
			GameDirector.instance.CameraShake.ShakeDistance(2f, 3f, 10f, ((Component)this).transform.position, 0.4f);
			GameDirector.instance.CameraImpact.ShakeDistance(1f, 3f, 10f, ((Component)this).transform.position, 0.1f);
		}
	}

	[PunRPC]
	private void SleepRPC(PhotonMessageInfo _info = default(PhotonMessageInfo))
	{
		//IL_0000: Unknown result type (might be due to invalid IL or missing references)
		//IL_0034: Unknown result type (might be due to invalid IL or missing references)
		//IL_006e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0078: Unknown result type (might be due to invalid IL or missing references)
		//IL_007d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0093: Unknown result type (might be due to invalid IL or missing references)
		//IL_00bf: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c4: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ca: Unknown result type (might be due to invalid IL or missing references)
		//IL_00cf: Unknown result type (might be due to invalid IL or missing references)
		//IL_010b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0139: Unknown result type (might be due to invalid IL or missing references)
		if (SemiFunc.MasterOnlyRPC(_info) && !InRuckusFlow() && !InItemReactionFlow())
		{
			ClampRuckusScoresForSleep();
			UpdateState(State.Sleeping);
			powerDown.Play(((Component)this).transform.position);
			onOffSwitchTurningOff = true;
			onOffSwitchEval = 0f;
			onOffSwitchActive = true;
			onOffSwitchEmissionTarget = onOffSwitchEmissionColor * 0.1f;
			onOffSwitchSoundOff.Play(OnOffSwitch.transform.position);
			onOffSwitchLight.SetActive(false);
			rotationTargetY = Quaternion.identity;
			rotationTargetX = Quaternion.identity;
			if (voiceBoxSource.isPlaying)
			{
				voiceBoxSource.Stop();
			}
			GameDirector.instance.CameraShake.ShakeDistance(2f, 3f, 10f, ((Component)this).transform.position, 0.4f);
			GameDirector.instance.CameraImpact.ShakeDistance(1f, 3f, 10f, ((Component)this).transform.position, 0.1f);
		}
	}

	[PunRPC]
	private void SetSkullActiveRPC(PhotonMessageInfo _info = default(PhotonMessageInfo))
	{
		//IL_0000: Unknown result type (might be due to invalid IL or missing references)
		if (SemiFunc.MasterOnlyRPC(_info))
		{
			skeletonSkull.SetActive(true);
		}
	}

	[PunRPC]
	private void InstantiateShockWaveRPC(PhotonMessageInfo _info = default(PhotonMessageInfo))
	{
		//IL_0000: Unknown result type (might be due to invalid IL or missing references)
		//IL_001a: Unknown result type (might be due to invalid IL or missing references)
		//IL_001f: Unknown result type (might be due to invalid IL or missing references)
		if (SemiFunc.MasterOnlyRPC(_info))
		{
			Object.Instantiate<GameObject>(shockWave, ((Component)awakeCollider).transform.position, Quaternion.identity);
		}
	}

	private void ActivateSleepCollider()
	{
		//IL_0029: Unknown result type (might be due to invalid IL or missing references)
		//IL_002f: Unknown result type (might be due to invalid IL or missing references)
		if (!sleepColliderActive)
		{
			if (SemiFunc.IsMultiplayer())
			{
				photonView.RPC("UpdateSleepColliderRPC", (RpcTarget)0, Array.Empty<object>());
			}
			else
			{
				UpdateSleepColliderRPC();
			}
		}
	}

	[PunRPC]
	private void UpdateSleepColliderRPC(PhotonMessageInfo _info = default(PhotonMessageInfo))
	{
		//IL_0000: Unknown result type (might be due to invalid IL or missing references)
		//IL_0039: Unknown result type (might be due to invalid IL or missing references)
		if (SemiFunc.MasterOnlyRPC(_info))
		{
			((Collider)awakeCollider).enabled = false;
			sleepColliderActive = true;
			((Collider)sleepCollider).enabled = true;
			detectionSphere.position = ((Component)sleepCollider).transform.position;
		}
	}

	private void ActivateAwakeCollider()
	{
		//IL_0029: Unknown result type (might be due to invalid IL or missing references)
		//IL_002f: Unknown result type (might be due to invalid IL or missing references)
		if (sleepColliderActive)
		{
			if (SemiFunc.IsMultiplayer())
			{
				photonView.RPC("UpdateAwakeColliderRPC", (RpcTarget)0, Array.Empty<object>());
			}
			else
			{
				UpdateAwakeColliderRPC();
			}
		}
	}

	[PunRPC]
	private void UpdateAwakeColliderRPC(PhotonMessageInfo _info = default(PhotonMessageInfo))
	{
		//IL_0000: Unknown result type (might be due to invalid IL or missing references)
		//IL_0039: Unknown result type (might be due to invalid IL or missing references)
		if (SemiFunc.MasterOnlyRPC(_info))
		{
			sleepColliderActive = false;
			((Collider)sleepCollider).enabled = false;
			((Collider)awakeCollider).enabled = true;
			detectionSphere.position = ((Component)awakeCollider).transform.position;
		}
	}

	public ShopKeeper()
	{
		//IL_001b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0020: Unknown result type (might be due to invalid IL or missing references)
		//IL_0071: Unknown result type (might be due to invalid IL or missing references)
		//IL_0076: Unknown result type (might be due to invalid IL or missing references)
		//IL_007c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0081: Unknown result type (might be due to invalid IL or missing references)
		//IL_0092: Unknown result type (might be due to invalid IL or missing references)
		//IL_0097: Unknown result type (might be due to invalid IL or missing references)
		//IL_0119: Unknown result type (might be due to invalid IL or missing references)
		//IL_011e: Unknown result type (might be due to invalid IL or missing references)
		//IL_01b2: Unknown result type (might be due to invalid IL or missing references)
		//IL_01b7: Unknown result type (might be due to invalid IL or missing references)
		//IL_01f8: Unknown result type (might be due to invalid IL or missing references)
		//IL_01fd: Unknown result type (might be due to invalid IL or missing references)
		//IL_0219: Unknown result type (might be due to invalid IL or missing references)
		//IL_021e: Unknown result type (might be due to invalid IL or missing references)
		//IL_03f6: Unknown result type (might be due to invalid IL or missing references)
		//IL_03fb: Unknown result type (might be due to invalid IL or missing references)
		//IL_0410: Unknown result type (might be due to invalid IL or missing references)
		//IL_0415: Unknown result type (might be due to invalid IL or missing references)
		//IL_041b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0420: Unknown result type (might be due to invalid IL or missing references)
		//IL_0440: Unknown result type (might be due to invalid IL or missing references)
		//IL_0445: Unknown result type (might be due to invalid IL or missing references)
		//IL_044b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0450: Unknown result type (might be due to invalid IL or missing references)
		//IL_04e5: Unknown result type (might be due to invalid IL or missing references)
		//IL_04ea: Unknown result type (might be due to invalid IL or missing references)
		//IL_04f0: Unknown result type (might be due to invalid IL or missing references)
		//IL_04f5: Unknown result type (might be due to invalid IL or missing references)
		//IL_0511: Unknown result type (might be due to invalid IL or missing references)
		//IL_0516: Unknown result type (might be due to invalid IL or missing references)
		//IL_051c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0521: Unknown result type (might be due to invalid IL or missing references)
		//IL_0527: Unknown result type (might be due to invalid IL or missing references)
		//IL_052c: Unknown result type (might be due to invalid IL or missing references)
		//IL_086b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0870: Unknown result type (might be due to invalid IL or missing references)
		//IL_0876: Unknown result type (might be due to invalid IL or missing references)
		//IL_087b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0890: Unknown result type (might be due to invalid IL or missing references)
		//IL_0895: Unknown result type (might be due to invalid IL or missing references)
		//IL_08b1: Unknown result type (might be due to invalid IL or missing references)
		//IL_08b6: Unknown result type (might be due to invalid IL or missing references)
		//IL_08c7: Unknown result type (might be due to invalid IL or missing references)
		//IL_08cc: Unknown result type (might be due to invalid IL or missing references)
		//IL_08d2: Unknown result type (might be due to invalid IL or missing references)
		//IL_08d7: Unknown result type (might be due to invalid IL or missing references)
		//IL_08ec: Unknown result type (might be due to invalid IL or missing references)
		//IL_08f1: Unknown result type (might be due to invalid IL or missing references)
		//IL_08f7: Unknown result type (might be due to invalid IL or missing references)
		//IL_08fc: Unknown result type (might be due to invalid IL or missing references)
	}
}
