using TMPro;
using UnityEngine;

public class HealthUI : SemiUI
{
	private TextMeshProUGUI Text;

	private PlayerHealth playerHealth;

	private bool setup = true;

	public static HealthUI instance;

	private int playerHealthValue;

	private int playerHealthPrevious;

	private TextMeshProUGUI textMaxHealth;

	private Vector3 maxHealthBasePosition;

	[RuntimeInitializeOnLoadMethod(/*Could not decode attribute arguments.*/)]
	private static void RuntimeInitializeOnLoad()
	{
		instance = null;
	}

	protected override void Start()
	{
		//IL_003f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0044: Unknown result type (might be due to invalid IL or missing references)
		base.Start();
		Text = ((Component)this).GetComponent<TextMeshProUGUI>();
		instance = this;
		textMaxHealth = ((Component)((Component)this).transform.Find("HealthMax")).GetComponent<TextMeshProUGUI>();
		maxHealthBasePosition = ((TMP_Text)textMaxHealth).transform.localPosition;
	}

	protected override void Update()
	{
		//IL_0047: Unknown result type (might be due to invalid IL or missing references)
		//IL_004c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0062: Unknown result type (might be due to invalid IL or missing references)
		//IL_005b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0060: Unknown result type (might be due to invalid IL or missing references)
		//IL_0118: Unknown result type (might be due to invalid IL or missing references)
		//IL_0128: Unknown result type (might be due to invalid IL or missing references)
		//IL_012d: Unknown result type (might be due to invalid IL or missing references)
		base.Update();
		if (Object.op_Implicit((Object)(object)playerHealth))
		{
			playerHealthValue = playerHealth.health;
			if (playerHealthValue != playerHealthPrevious)
			{
				SemiUISpringShakeY(20f, 10f, 0.3f);
				Color color = Color.white;
				if (playerHealthValue < playerHealthPrevious)
				{
					color = Color.red;
				}
				SemiUITextFlashColor(color, 0.2f);
				SemiUISpringScale(0.3f, 5f, 0.2f);
				playerHealthPrevious = playerHealthValue;
			}
		}
		if (setup)
		{
			if (LevelGenerator.Instance.Generated)
			{
				playerHealth = PlayerController.instance.playerAvatarScript.playerHealth;
				setup = false;
			}
		}
		else
		{
			((TMP_Text)Text).text = playerHealthValue.ToString();
			float num = ((((TMP_Text)Text).text.Length > 3) ? ((float)(((TMP_Text)Text).text.Length - 3) * 20f) : 0f);
			((TMP_Text)textMaxHealth).transform.localPosition = maxHealthBasePosition + new Vector3(num, 0f, 0f);
			((TMP_Text)textMaxHealth).text = "<b><color=#008b20>/</color></b>" + playerHealth.maxHealth;
		}
	}
}
