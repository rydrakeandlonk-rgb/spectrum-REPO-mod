using UnityEngine;

public class PlayerAvatarRightArm : MonoBehaviour
{
	public PlayerAvatar playerAvatar;

	public Transform rightArmTransform;

	public Transform rightArmParentTransform;

	public MapToolController mapToolController;

	public PhysGrabBeam physGrabBeam;

	public AnimationCurve poseCurve;

	public float poseSpeed;

	private float poseLerp;

	internal Vector3 poseNew;

	private Vector3 poseOld;

	private Vector3 poseCurrent;

	[Space]
	public Vector3 basePose;

	public Vector3 mapPose;

	public Vector3 grabberPose;

	private float grabberPoseOverrideTimer;

	private float headRotation;

	public Transform grabberTransform;

	public Transform grabberTransformTarget;

	[Space]
	public Material grabberMaterial;

	public Material grabberMaterialHeal;

	[Space]
	public Transform grabberOrb;

	public GameObject[] grabberOrbSpheres;

	[Space]
	public Light grabberLight;

	public Color grabberLightColor;

	public Color grabberLightColorHeal;

	private float grabberLightIntensity;

	private bool grabberHealing;

	[Space]
	public Transform grabberAimTarget;

	[Space]
	public SpringQuaternion grabberSteerSpring;

	public SpringQuaternion grabberClawSpring;

	public SpringFloat grabberReachSpring;

	internal float grabberReachResult;

	private float grabberReachTimer;

	private float grabberReachTarget;

	private float grabberReachPrevious;

	internal float grabberReachDifference;

	private float grabberReachDifferenceTimer;

	[Space]
	public Transform grabberClawParent;

	public Transform[] grabberClawChildren;

	public AnimationCurve grabberClawHideCurve;

	public AnimationCurve grabberClawChildCurve;

	private float grabberClawLerp;

	private float grabberClawChildLerp;

	private bool grabberClawHidden;

	private float grabberClawRotation;

	private float deltaTime;

	private PlayerAvatarVisuals playerAvatarVisuals;

	internal float forceBasePoseTimer;

	private void Start()
	{
		//IL_002c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0031: Unknown result type (might be due to invalid IL or missing references)
		playerAvatarVisuals = ((Component)this).GetComponent<PlayerAvatarVisuals>();
		grabberLightIntensity = grabberLight.intensity;
		if (playerAvatarVisuals.isMenuAvatar)
		{
			poseCurrent = basePose;
		}
	}

	private void Update()
	{
		//IL_012e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0113: Unknown result type (might be due to invalid IL or missing references)
		//IL_008b: Unknown result type (might be due to invalid IL or missing references)
		deltaTime = playerAvatarVisuals.deltaTime;
		if (!Object.op_Implicit((Object)(object)playerAvatar) || !playerAvatar.playerHealth.hurtFreeze)
		{
			if (forceBasePoseTimer <= 0f && Object.op_Implicit((Object)(object)playerAvatar) && !playerAvatar.playerAvatarVisuals.animInCrawl && !playerAvatar.playerAvatarVisuals.animTumbling && Object.op_Implicit((Object)(object)mapToolController) && mapToolController.Active)
			{
				SetPose(mapPose);
				HeadAnimate(_active: true);
				AnimatePose();
			}
			else if ((Object.op_Implicit((Object)(object)playerAvatar) && playerAvatar.physGrabber.physGrabBeamActive && Object.op_Implicit((Object)(object)mapToolController) && !mapToolController.Active) || (Object.op_Implicit((Object)(object)playerAvatarVisuals.playerAvatarMenu) && playerAvatarVisuals.playerAvatarMenu.physGrabBeamActive) || grabberPoseOverrideTimer > 0f)
			{
				SetPose(grabberPose);
				HeadAnimate(_active: false);
				AnimatePose();
			}
			else
			{
				SetPose(basePose);
				HeadAnimate(_active: false);
				AnimatePose();
			}
			if (forceBasePoseTimer > 0f)
			{
				forceBasePoseTimer -= deltaTime;
			}
			GrabberLogic();
		}
	}

	private void HeadAnimate(bool _active)
	{
		//IL_002d: Unknown result type (might be due to invalid IL or missing references)
		if (_active && Object.op_Implicit((Object)(object)playerAvatar) && !playerAvatar.rotationDisabled)
		{
			float num = playerAvatar.localCamera.GetOverrideTransform().eulerAngles.x;
			if (num > 90f)
			{
				num -= 360f;
			}
			headRotation = Mathf.Lerp(headRotation, num * 0.5f, 20f * deltaTime);
		}
		else
		{
			headRotation = Mathf.Lerp(headRotation, 0f, 20f * deltaTime);
		}
	}

	private void AnimatePose()
	{
		//IL_007d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0029: Unknown result type (might be due to invalid IL or missing references)
		//IL_002f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0045: Unknown result type (might be due to invalid IL or missing references)
		//IL_004a: Unknown result type (might be due to invalid IL or missing references)
		if (poseLerp < 1f)
		{
			poseLerp += poseSpeed * deltaTime;
			poseCurrent = Vector3.LerpUnclamped(poseOld, poseNew, poseCurve.Evaluate(poseLerp));
		}
		rightArmTransform.localEulerAngles = new Vector3(poseCurrent.x, poseCurrent.y + headRotation, poseCurrent.z);
	}

	private void SetPose(Vector3 _poseNew)
	{
		//IL_0001: Unknown result type (might be due to invalid IL or missing references)
		//IL_0006: Unknown result type (might be due to invalid IL or missing references)
		//IL_0010: Unknown result type (might be due to invalid IL or missing references)
		//IL_0015: Unknown result type (might be due to invalid IL or missing references)
		//IL_001b: Unknown result type (might be due to invalid IL or missing references)
		//IL_001c: Unknown result type (might be due to invalid IL or missing references)
		if (poseNew != _poseNew)
		{
			poseOld = poseCurrent;
			poseNew = _poseNew;
			poseLerp = 0f;
		}
	}

	private void GrabberClawLogic()
	{
		//IL_0136: Unknown result type (might be due to invalid IL or missing references)
		//IL_014a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0160: Unknown result type (might be due to invalid IL or missing references)
		//IL_0165: Unknown result type (might be due to invalid IL or missing references)
		//IL_0172: Unknown result type (might be due to invalid IL or missing references)
		//IL_0173: Unknown result type (might be due to invalid IL or missing references)
		//IL_01e7: Unknown result type (might be due to invalid IL or missing references)
		//IL_01fd: Unknown result type (might be due to invalid IL or missing references)
		//IL_021d: Unknown result type (might be due to invalid IL or missing references)
		//IL_022d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0232: Unknown result type (might be due to invalid IL or missing references)
		//IL_023c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0252: Unknown result type (might be due to invalid IL or missing references)
		if ((Object.op_Implicit((Object)(object)playerAvatar) && playerAvatar.physGrabber.physGrabBeamActive) || (Object.op_Implicit((Object)(object)playerAvatarVisuals.playerAvatarMenu) && playerAvatarVisuals.playerAvatarMenu.physGrabBeamActive) || grabberPoseOverrideTimer > 0f)
		{
			if (grabberClawHidden)
			{
				grabberClawHidden = false;
				((Component)grabberClawParent).gameObject.SetActive(true);
			}
			grabberClawLerp = Mathf.Clamp01(grabberClawLerp + 3f * deltaTime);
		}
		else if (!grabberClawHidden)
		{
			if (grabberClawLerp <= 0f)
			{
				grabberClawHidden = true;
				((Component)grabberClawParent).gameObject.SetActive(false);
				grabberClawRotation = 0f;
			}
			grabberClawLerp = Mathf.Clamp01(grabberClawLerp - 3f * deltaTime);
		}
		if (!grabberClawHidden)
		{
			grabberClawChildLerp = Mathf.Clamp01(grabberClawChildLerp + 1f * deltaTime);
			if (grabberClawChildLerp >= 1f)
			{
				grabberClawChildLerp = 0f;
			}
			Vector3 val = Vector3.LerpUnclamped(new Vector3(60f, 0f, 0f), new Vector3(80f, 0f, 0f), grabberClawChildCurve.Evaluate(grabberClawChildLerp));
			for (int i = 0; i < grabberClawChildren.Length; i++)
			{
				grabberClawChildren[i].localRotation = Quaternion.Euler(val);
			}
			float num = Mathf.LerpUnclamped(500f, 200f, grabberClawChildCurve.Evaluate(grabberClawChildLerp));
			grabberClawRotation += num * deltaTime;
			if (grabberClawRotation > 360f)
			{
				grabberClawRotation -= 360f;
			}
			grabberClawParent.localScale = Vector3.one * grabberClawHideCurve.Evaluate(grabberClawLerp);
			grabberClawParent.localRotation = Quaternion.Euler(0f, 0f, grabberClawRotation);
			grabberOrb.localScale = Vector3.Lerp(Vector3.one, Vector3.one * 1.2f, grabberClawChildCurve.Evaluate(grabberClawChildLerp));
			grabberLight.intensity = Mathf.Lerp(0f, grabberLightIntensity, grabberClawHideCurve.Evaluate(grabberClawLerp));
		}
	}

	private void GrabberLogic()
	{
		//IL_0032: Unknown result type (might be due to invalid IL or missing references)
		//IL_0048: Unknown result type (might be due to invalid IL or missing references)
		//IL_0064: Unknown result type (might be due to invalid IL or missing references)
		//IL_006f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0079: Unknown result type (might be due to invalid IL or missing references)
		//IL_007e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0085: Unknown result type (might be due to invalid IL or missing references)
		//IL_008a: Unknown result type (might be due to invalid IL or missing references)
		//IL_01b5: Unknown result type (might be due to invalid IL or missing references)
		//IL_01c7: Unknown result type (might be due to invalid IL or missing references)
		//IL_01ce: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d6: Unknown result type (might be due to invalid IL or missing references)
		//IL_00db: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ed: Unknown result type (might be due to invalid IL or missing references)
		//IL_0103: Unknown result type (might be due to invalid IL or missing references)
		//IL_0308: Unknown result type (might be due to invalid IL or missing references)
		//IL_0126: Unknown result type (might be due to invalid IL or missing references)
		//IL_0140: Unknown result type (might be due to invalid IL or missing references)
		//IL_0150: Unknown result type (might be due to invalid IL or missing references)
		//IL_0160: Unknown result type (might be due to invalid IL or missing references)
		//IL_0170: Unknown result type (might be due to invalid IL or missing references)
		//IL_0177: Unknown result type (might be due to invalid IL or missing references)
		//IL_0188: Unknown result type (might be due to invalid IL or missing references)
		//IL_01a9: Unknown result type (might be due to invalid IL or missing references)
		//IL_01ae: Unknown result type (might be due to invalid IL or missing references)
		//IL_0394: Unknown result type (might be due to invalid IL or missing references)
		//IL_0343: Unknown result type (might be due to invalid IL or missing references)
		GrabberClawLogic();
		if (grabberPoseOverrideTimer > 0f)
		{
			grabberPoseOverrideTimer -= deltaTime;
		}
		grabberTransform.position = grabberTransformTarget.position;
		grabberTransform.localScale = grabberTransformTarget.localScale;
		grabberTransform.rotation = SemiFunc.SpringQuaternionGet(grabberClawSpring, grabberTransformTarget.rotation, deltaTime);
		Quaternion targetRotation = Quaternion.identity;
		Quaternion localRotation = rightArmParentTransform.localRotation;
		if (Object.op_Implicit((Object)(object)playerAvatar) && playerAvatar.physGrabber.physGrabBeamActive && Object.op_Implicit((Object)(object)mapToolController) && !mapToolController.Active)
		{
			Vector3 position = grabberAimTarget.position;
			grabberAimTarget.position = physGrabBeam.PhysGrabPointPuller.position;
			float num = 0f;
			if (grabberAimTarget.localPosition.x < -1f)
			{
				num = 1f;
			}
			grabberAimTarget.localPosition = new Vector3(Mathf.Max(grabberAimTarget.localPosition.x, 0.2f), grabberAimTarget.localPosition.y, Mathf.Max(grabberAimTarget.localPosition.z, num));
			grabberAimTarget.position = Vector3.Lerp(position, grabberAimTarget.position, 30f * deltaTime);
			rightArmParentTransform.LookAt(grabberAimTarget);
			targetRotation = rightArmParentTransform.localRotation;
		}
		rightArmParentTransform.localRotation = localRotation;
		rightArmParentTransform.localRotation = SemiFunc.SpringQuaternionGet(grabberSteerSpring, targetRotation, deltaTime);
		grabberReachDifferenceTimer += deltaTime;
		if (grabberReachDifferenceTimer > 1f)
		{
			grabberReachDifference = 0f;
			grabberReachDifferenceTimer = 0f;
		}
		if (Object.op_Implicit((Object)(object)playerAvatar))
		{
			grabberReachDifference += grabberReachPrevious - playerAvatar.physGrabber.pullerDistance;
			grabberReachPrevious = playerAvatar.physGrabber.pullerDistance;
		}
		if (Mathf.Abs(grabberReachDifference) > 1f)
		{
			if (grabberReachDifference < 0f)
			{
				grabberReachTarget = 0.2f;
			}
			else
			{
				grabberReachTarget = -0.2f;
			}
			grabberReachTimer = 0.25f;
			grabberReachDifference = 0f;
		}
		else
		{
			grabberReachTimer -= deltaTime;
			if (grabberReachTimer <= 0f)
			{
				grabberReachTarget = 0f;
			}
		}
		grabberReachResult = SemiFunc.SpringFloatGet(grabberReachSpring, grabberReachTarget, deltaTime);
		rightArmParentTransform.localScale = new Vector3(1f, 1f, 1f + grabberReachResult);
		if (Object.op_Implicit((Object)(object)playerAvatar) && playerAvatar.physGrabber.healing)
		{
			if (!grabberHealing)
			{
				grabberLight.color = grabberLightColorHeal;
				GameObject[] array = grabberOrbSpheres;
				for (int i = 0; i < array.Length; i++)
				{
					array[i].GetComponent<Renderer>().material = grabberMaterialHeal;
				}
				grabberHealing = true;
			}
		}
		else if (grabberHealing)
		{
			grabberLight.color = grabberLightColor;
			GameObject[] array = grabberOrbSpheres;
			for (int i = 0; i < array.Length; i++)
			{
				array[i].GetComponent<Renderer>().material = grabberMaterial;
			}
			grabberHealing = false;
		}
	}

	public void GrabberPoseOverride(float _time = 0.1f)
	{
		grabberPoseOverrideTimer = _time;
	}
}
