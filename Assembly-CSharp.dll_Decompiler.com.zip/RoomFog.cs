using UnityEngine;

[CreateAssetMenu(fileName = "Room Fog - _____", menuName = "Level/Room Fog", order = 0)]
public class RoomFog : ScriptableObject
{
	public Level importSettingsFromLevel;

	[Space]
	public Color fogColor = Color.black;

	public float fogStartDistance;

	public float fogEndDistance = 15f;

	public void OnValidate()
	{
		//IL_001d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0022: Unknown result type (might be due to invalid IL or missing references)
		if (!SemiFunc.OnValidateCheck() && (Object)(object)importSettingsFromLevel != (Object)null)
		{
			fogColor = importSettingsFromLevel.FogColor;
			fogStartDistance = importSettingsFromLevel.FogStartDistance;
			fogEndDistance = importSettingsFromLevel.FogEndDistance;
			importSettingsFromLevel = null;
		}
	}

	public RoomFog()
	{
		//IL_0001: Unknown result type (might be due to invalid IL or missing references)
		//IL_0006: Unknown result type (might be due to invalid IL or missing references)
	}
}
