using System;
using UnityEngine;

[Serializable]
public class ShakeAnimation
{
	public float multiplier = 1f;

	public float updateFrequency = 0.02f;

	[Space]
	public float speedMin = 40f;

	public float speedMax = 80f;

	private float updateTimer;

	private float amount;

	private float decrease;

	internal float lerp = 1f;

	private float speed;

	private float oldValue;

	private float newValue;

	internal float result;

	public void Set(float _amount, float _decrease)
	{
		amount = _amount + _decrease;
		decrease = _decrease;
	}

	public float Get()
	{
		return result;
	}

	public bool IsActive()
	{
		if (amount > 0f && lerp < 1f)
		{
			return true;
		}
		return false;
	}

	public void SetAdditive(float _amount, float _decrease)
	{
		amount += _amount;
		decrease = _decrease;
	}

	public void UpdateShake()
	{
		if (updateTimer <= 0f)
		{
			updateTimer = updateFrequency;
			if (lerp >= 1f)
			{
				if (amount > 0f)
				{
					amount -= decrease;
					amount = Mathf.Max(0f, amount);
					oldValue = newValue;
					newValue = Random.Range(0f - amount, amount);
					speed = Random.Range(speedMin, speedMax);
					lerp = 0f;
				}
			}
			else
			{
				lerp += Time.deltaTime * speed;
				result = Mathf.Lerp(oldValue, newValue, AssetManager.instance.animationCurveEaseInOut.Evaluate(lerp)) * multiplier;
			}
		}
		else
		{
			updateTimer -= Time.deltaTime;
		}
	}
}
