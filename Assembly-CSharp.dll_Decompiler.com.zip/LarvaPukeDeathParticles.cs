using System;
using System.Collections.Generic;
using UnityEngine;

public class LarvaPukeDeathParticles : MonoBehaviour
{
	[Serializable]
	public class Emitter
	{
		public ParticleSystem particles;

		public int particleCount;
	}

	public List<Emitter> emitters = new List<Emitter>();

	public List<ParticleSystem> authoredEmitters = new List<ParticleSystem>();

	public float destroyTime = 5f;

	public void Burst(Vector3 _position, Vector3 _upHint)
	{
		//IL_0000: Unknown result type (might be due to invalid IL or missing references)
		//IL_0001: Unknown result type (might be due to invalid IL or missing references)
		//IL_0006: Unknown result type (might be due to invalid IL or missing references)
		//IL_000b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0033: Unknown result type (might be due to invalid IL or missing references)
		//IL_0034: Unknown result type (might be due to invalid IL or missing references)
		//IL_003b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0040: Unknown result type (might be due to invalid IL or missing references)
		//IL_001a: Unknown result type (might be due to invalid IL or missing references)
		//IL_001f: Unknown result type (might be due to invalid IL or missing references)
		Vector3 val = Vector3.ProjectOnPlane(_upHint, Vector3.up);
		if (val.sqrMagnitude <= 0.001f)
		{
			val = Vector3.forward;
		}
		((Component)this).transform.SetParent((Transform)null, true);
		((Component)this).transform.SetPositionAndRotation(_position, Quaternion.LookRotation(Vector3.up, val.normalized));
		((Component)this).gameObject.SetActive(true);
		foreach (Emitter emitter in emitters)
		{
			if (emitter != null && Object.op_Implicit((Object)(object)emitter.particles) && emitter.particleCount > 0)
			{
				emitter.particles.Clear(false);
				emitter.particles.Play(false);
				emitter.particles.Emit(emitter.particleCount);
			}
		}
		foreach (ParticleSystem authoredEmitter in authoredEmitters)
		{
			if (Object.op_Implicit((Object)(object)authoredEmitter))
			{
				authoredEmitter.Clear(false);
				authoredEmitter.Play(false);
			}
		}
		Object.Destroy((Object)(object)((Component)this).gameObject, Mathf.Max(0.1f, destroyTime));
	}
}
