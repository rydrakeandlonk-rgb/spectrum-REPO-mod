using System.Collections.Generic;
using UnityEngine;

[CreateAssetMenu(fileName = "Version - ", menuName = "Other/Version", order = 0)]
public class Version : ScriptableObject
{
	public enum VersionTypes
	{
		Default,
		ContentLocked,
		ReleaseCandidate
	}

	public string title = "v0.0.0";

	public VersionTypes versionType;

	public string discordRole = "@";

	[TextArea(0, 10)]
	public List<string> newList = new List<string>();

	[TextArea(0, 10)]
	public List<string> changesList = new List<string>();

	[TextArea(0, 10)]
	public List<string> balancingList = new List<string>();

	[TextArea(0, 10)]
	public List<string> fixList = new List<string>();

	private void Discord()
	{
		string text = discordRole;
		text = text + "\n# ''R.E.P.O. " + title + "'' is now live! :taxman_laugh:";
		if (newList.Count > 0)
		{
			text += "\n\n";
			text += "## NEW";
			foreach (string @new in newList)
			{
				text = text + "\n> - " + @new;
			}
		}
		if (changesList.Count > 0)
		{
			text += "\n\n";
			text += "## CHANGES";
			foreach (string changes in changesList)
			{
				text = text + "\n> - " + changes;
			}
		}
		if (balancingList.Count > 0)
		{
			text += "\n\n";
			text += "## BALANCING";
			foreach (string balancing in balancingList)
			{
				text = text + "\n> - " + balancing;
			}
		}
		if (fixList.Count > 0)
		{
			text += "\n\n";
			text += "## FIXES";
			foreach (string fix in fixList)
			{
				text = text + "\n> - " + fix;
			}
		}
		text += "\n\n";
		string text2 = text;
		text = text2 + versionType switch
		{
			VersionTypes.ReleaseCandidate => "# __This build is a **RELEASE CANDIDATE** so please help us find any **critical bugs**! :taxman_smile:__", 
			VersionTypes.ContentLocked => "# __This update is now **CONTENT LOCKED** so please help us fix the last bugs and balancing issues! :taxman_smile:__", 
			_ => "# __Thanks for helping us test! :taxman_smile:__", 
		};
		GUIUtility.systemCopyBuffer = text;
	}

	private void Steam()
	{
		string text = "[hr][/hr]";
		text += "[b][list]";
		if (newList.Count > 0)
		{
			text += "\n[*][url=#NEW]NEW[/url]";
		}
		if (changesList.Count > 0)
		{
			text += "\n[*][url=#CHANGES]CHANGES[/url]";
		}
		if (balancingList.Count > 0)
		{
			text += "\n[*][url=#BALANCING]BALANCING[/url]";
		}
		if (fixList.Count > 0)
		{
			text += "\n[*][url=#FIXES]FIXES[/url]";
		}
		text += "[/list][/b]";
		string text2 = "[hr][/hr]\n";
		if (newList.Count > 0)
		{
			text = text + text2 + "[h2=NEW]NEW[/h2][list]";
			foreach (string @new in newList)
			{
				text = text + "\n[*]" + @new;
			}
			text += "[/list]";
			if (text2 == "[hr][/hr]\n")
			{
				text2 = "\n[hr][/hr]";
			}
		}
		if (changesList.Count > 0)
		{
			text = text + text2 + "[h2=CHANGES]CHANGES[/h2][list]";
			foreach (string changes in changesList)
			{
				text = text + "\n[*]" + changes;
			}
			text += "[/list]";
			if (text2 == "[hr][/hr]\n")
			{
				text2 = "\n[hr][/hr]";
			}
		}
		if (balancingList.Count > 0)
		{
			text = text + text2 + "[h2=BALANCING]BALANCING[/h2][list]";
			foreach (string balancing in balancingList)
			{
				text = text + "\n[*]" + balancing;
			}
			text += "[/list]";
			if (text2 == "[hr][/hr]\n")
			{
				text2 = "\n[hr][/hr]";
			}
		}
		if (fixList.Count > 0)
		{
			text = text + text2 + "[h2=FIXES]FIXES[/h2][list]";
			foreach (string fix in fixList)
			{
				text = text + "\n[*]" + fix;
			}
			text += "[/list]";
			if (text2 == "[hr][/hr]\n")
			{
				text2 = "\n[hr][/hr]";
			}
		}
		text += "\n[hr][/hr]";
		GUIUtility.systemCopyBuffer = text;
	}

	private void Notepad()
	{
		string text = "";
		if (newList.Count > 0)
		{
			text += "NEW";
			foreach (string @new in newList)
			{
				text = text + "\n- " + @new;
			}
		}
		if (changesList.Count > 0)
		{
			text += "\n\n";
			text += "CHANGES";
			foreach (string changes in changesList)
			{
				text = text + "\n- " + changes;
			}
		}
		if (balancingList.Count > 0)
		{
			text += "\n\n";
			text += "BALANCING";
			foreach (string balancing in balancingList)
			{
				text = text + "\n- " + balancing;
			}
		}
		if (fixList.Count > 0)
		{
			text += "\n\n";
			text += "FIXES";
			foreach (string fix in fixList)
			{
				text = text + "\n- " + fix;
			}
		}
		GUIUtility.systemCopyBuffer = text;
	}

	private void ClearAll()
	{
		newList.Clear();
		changesList.Clear();
		balancingList.Clear();
		fixList.Clear();
	}
}
