using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;
using UnityEngine.Events;
using UnityEngine.UI;

public class MenuPage : MonoBehaviour
{
	public enum PageState
	{
		Opening,
		Active,
		Closing,
		Inactive,
		Activating,
		Closed
	}

	public string menuHeaderName;

	public MenuPageIndex menuPageIndex;

	private Vector2 originalPosition;

	internal RectTransform rectTransform;

	private Vector2 animateAwayPosition = new Vector2(0f, 0f);

	private Vector2 targetPosition;

	internal float bottomElementYPos;

	internal List<MenuSelectableElement> selectableElements = new List<MenuSelectableElement>();

	public TextMeshProUGUI menuHeader;

	internal bool pageIsOnTopOfOtherPage;

	internal MenuPage pageUnderThisPage;

	internal string menuIDBeforeInactive;

	internal bool pageActive;

	private float pageActiveTimer;

	internal bool popUpAnimation;

	internal MenuSelectionBox selectionBox;

	private float stateTimer;

	internal bool addedPageOnTop;

	internal MenuPage parentPage;

	public bool disableIntroAnimation;

	public bool disableOutroAnimation;

	public bool disableIntroEffect;

	public bool disableOutroEffect;

	internal List<MenuSettingElement> settingElements = new List<MenuSettingElement>();

	internal int currentActiveSettingElement = -1;

	private float activeSettingElementTimer;

	public UnityEvent onPageEnd;

	internal int scrollBoxes;

	internal PlayerAvatarMenu playerAvatarMenu;

	internal int interactionPriority;

	private CanvasGroup interactionGroup;

	internal bool interactionBlocked;

	private bool stateStart = true;

	internal PageState currentPageState;

	internal bool isInteractable { get; private set; } = true;

	internal void SetInteractable(bool _interactable)
	{
		isInteractable = _interactable;
		if (Object.op_Implicit((Object)(object)interactionGroup))
		{
			interactionGroup.blocksRaycasts = _interactable;
			interactionGroup.interactable = _interactable;
		}
	}

	private void Awake()
	{
		selectionBox = ((Component)this).GetComponentInChildren<MenuSelectionBox>();
		rectTransform = ((Component)this).GetComponent<RectTransform>();
		interactionGroup = ((Component)this).GetComponent<CanvasGroup>();
		if (!Object.op_Implicit((Object)(object)interactionGroup))
		{
			interactionGroup = ((Component)this).gameObject.AddComponent<CanvasGroup>();
		}
	}

	private void Start()
	{
		//IL_0007: Unknown result type (might be due to invalid IL or missing references)
		//IL_000c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0011: Unknown result type (might be due to invalid IL or missing references)
		//IL_0033: Unknown result type (might be due to invalid IL or missing references)
		//IL_0038: Unknown result type (might be due to invalid IL or missing references)
		//IL_0041: Unknown result type (might be due to invalid IL or missing references)
		//IL_0046: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0072: Unknown result type (might be due to invalid IL or missing references)
		//IL_007b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0080: Unknown result type (might be due to invalid IL or missing references)
		originalPosition = Vector2.op_Implicit(((Transform)rectTransform).localPosition);
		float x = originalPosition.x;
		float y = originalPosition.y;
		Rect rect = rectTransform.rect;
		animateAwayPosition = new Vector2(x, y - rect.height);
		RectTransform val = rectTransform;
		float x2 = originalPosition.x;
		float y2 = originalPosition.y;
		rect = rectTransform.rect;
		((Transform)val).localPosition = Vector2.op_Implicit(new Vector2(x2, y2 + rect.height));
		MenuManager.instance.PageAdd(this);
		((MonoBehaviour)this).StartCoroutine(LateStart());
	}

	private IEnumerator LateStart()
	{
		yield return null;
		if (!Object.op_Implicit((Object)(object)parentPage))
		{
			parentPage = this;
		}
	}

	private void Update()
	{
		if (pageActiveTimer <= 0f)
		{
			pageActive = false;
		}
		if (pageActiveTimer > 0f)
		{
			pageActive = true;
			pageActiveTimer -= Time.deltaTime;
		}
		switch (currentPageState)
		{
		case PageState.Opening:
			StateOpening();
			stateStart = false;
			break;
		case PageState.Active:
			StateActive();
			stateStart = false;
			break;
		case PageState.Closing:
			StateClosing();
			stateStart = false;
			break;
		case PageState.Inactive:
			StateInactive();
			stateStart = false;
			break;
		case PageState.Activating:
			StateActivating();
			stateStart = false;
			break;
		}
		if (activeSettingElementTimer > 0f)
		{
			activeSettingElementTimer -= Time.deltaTime;
			if (activeSettingElementTimer <= 0f)
			{
				currentActiveSettingElement = -1;
			}
		}
	}

	private void OnEnable()
	{
		ResetPage();
	}

	public void ResetPage()
	{
		//IL_0030: Unknown result type (might be due to invalid IL or missing references)
		//IL_0035: Unknown result type (might be due to invalid IL or missing references)
		//IL_003e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0043: Unknown result type (might be due to invalid IL or missing references)
		if (Object.op_Implicit((Object)(object)rectTransform))
		{
			RectTransform val = rectTransform;
			float x = originalPosition.x;
			float y = originalPosition.y;
			Rect rect = rectTransform.rect;
			((Transform)val).localPosition = Vector2.op_Implicit(new Vector2(x, y + rect.height));
		}
	}

	public void PageStateSet(PageState pageState)
	{
		if (pageState == PageState.Inactive && currentPageState != PageState.Inactive && Object.op_Implicit((Object)(object)MenuManager.instance))
		{
			menuIDBeforeInactive = MenuManager.instance.lastHoverMenuID;
		}
		stateTimer = 0f;
		currentPageState = pageState;
		stateStart = true;
	}

	private void StateOpening()
	{
		//IL_004d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0052: Unknown result type (might be due to invalid IL or missing references)
		//IL_0058: Unknown result type (might be due to invalid IL or missing references)
		//IL_008a: Unknown result type (might be due to invalid IL or missing references)
		//IL_008f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0095: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a1: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a6: Unknown result type (might be due to invalid IL or missing references)
		if (stateStart)
		{
			if (!disableIntroEffect)
			{
				if (!popUpAnimation)
				{
					MenuManager.instance.MenuEffectPageIntro();
				}
				else
				{
					MenuManager.instance.MenuEffectPopUpOpen();
				}
			}
			LockAndHide();
		}
		if (!addedPageOnTop)
		{
			MenuSelectionBox.instance.firstSelection = true;
		}
		if (Vector2.Distance(Vector2.op_Implicit(((Transform)rectTransform).localPosition), originalPosition) < 0.8f)
		{
			PageStateSet(PageState.Active);
		}
		if (!disableIntroAnimation)
		{
			float deltaTime = Time.deltaTime;
			((Transform)rectTransform).localPosition = Vector2.op_Implicit(Vector2.Lerp(Vector2.op_Implicit(((Transform)rectTransform).localPosition), originalPosition, 40f * deltaTime));
		}
		LockAndHide();
	}

	private void StateActive()
	{
		//IL_0035: Unknown result type (might be due to invalid IL or missing references)
		//IL_003a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0017: Unknown result type (might be due to invalid IL or missing references)
		//IL_001c: Unknown result type (might be due to invalid IL or missing references)
		if (stateStart && !disableIntroAnimation)
		{
			((Transform)rectTransform).localPosition = Vector2.op_Implicit(originalPosition);
		}
		if (!disableIntroAnimation)
		{
			((Transform)rectTransform).localPosition = Vector2.op_Implicit(originalPosition);
		}
		PageAddedOnTopLogic();
		MenuSelectionBox instance = MenuSelectionBox.instance;
		if (!Object.op_Implicit((Object)(object)instance) || (Object)(object)instance != (Object)(object)selectionBox)
		{
			selectionBox.Reinstate();
		}
		LockAndHide();
		if (MenuManager.instance.currentMenuPageIndex != menuPageIndex)
		{
			PageStateSet(PageState.Inactive);
		}
		pageActive = true;
		pageActiveTimer = 0.1f;
	}

	public bool SettingElementActiveCheckFree(int index)
	{
		if (currentActiveSettingElement != -1)
		{
			return currentActiveSettingElement == index;
		}
		return true;
	}

	private void StateClosing()
	{
		//IL_0062: Unknown result type (might be due to invalid IL or missing references)
		//IL_0067: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b1: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b6: Unknown result type (might be due to invalid IL or missing references)
		//IL_00bc: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c8: Unknown result type (might be due to invalid IL or missing references)
		//IL_00cd: Unknown result type (might be due to invalid IL or missing references)
		LockAndHide();
		if (stateStart)
		{
			if (!disableOutroEffect)
			{
				if (!popUpAnimation)
				{
					MenuManager.instance.MenuEffectPageOutro();
				}
				else
				{
					MenuManager.instance.MenuEffectPopUpClose();
				}
			}
			if ((Object)(object)MenuManager.instance.currentMenuPage == (Object)(object)this)
			{
				MenuManager.instance.currentMenuPage = null;
				MenuManager.instance.PageRemove(this);
			}
		}
		if (Vector2.Distance(Vector2.op_Implicit(((Transform)rectTransform).localPosition), animateAwayPosition) < 0.8f)
		{
			onPageEnd.Invoke();
			MenuManager.instance.PageRemove(this);
			Object.Destroy((Object)(object)((Component)this).gameObject);
		}
		float deltaTime = Time.deltaTime;
		((Transform)rectTransform).localPosition = Vector2.op_Implicit(Vector2.Lerp(Vector2.op_Implicit(((Transform)rectTransform).localPosition), animateAwayPosition, 40f * deltaTime));
	}

	private void StateInactive()
	{
		_ = stateStart;
		if (MenuManager.instance.currentMenuPageIndex == menuPageIndex)
		{
			PageStateSet(PageState.Active);
		}
	}

	private void PageAddedOnTopLogic()
	{
		if (currentPageState == PageState.Opening || currentPageState == PageState.Closing || !addedPageOnTop)
		{
			return;
		}
		if (Object.op_Implicit((Object)(object)parentPage))
		{
			if (currentPageState != parentPage.currentPageState)
			{
				PageStateSet(parentPage.currentPageState);
			}
		}
		else if (currentPageState != PageState.Closing)
		{
			PageStateSet(PageState.Closing);
		}
	}

	private void StateActivating()
	{
		_ = stateStart;
		if (stateTimer > 0.1f)
		{
			PageStateSet(PageState.Active);
		}
		stateTimer += Time.deltaTime;
	}

	public void SettingElementActiveSet(int index)
	{
		if (currentActiveSettingElement == -1)
		{
			currentActiveSettingElement = index;
		}
		activeSettingElementTimer = 0.1f;
	}

	public void FocusFirstSelectableForGamepad()
	{
		//IL_0079: Unknown result type (might be due to invalid IL or missing references)
		//IL_0089: Unknown result type (might be due to invalid IL or missing references)
		if (!Object.op_Implicit((Object)(object)MenuManager.instance) || (SemiFunc.InputMode() != InputModes.Gamepad && !MenuManager.instance.isKeyboardNavigating))
		{
			return;
		}
		MenuScrollBox componentInChildren = ((Component)this).GetComponentInChildren<MenuScrollBox>();
		MenuSelectableElement menuSelectableElement = (Object.op_Implicit((Object)(object)componentInChildren) ? componentInChildren.GetTopmostVisibleSelectable() : null);
		if ((Object)(object)menuSelectableElement == (Object)null)
		{
			foreach (MenuSelectableElement selectableElement in selectableElements)
			{
				if (Object.op_Implicit((Object)(object)selectableElement) && ((Selectable)selectableElement).IsInteractable() && ((Object)(object)menuSelectableElement == (Object)null || ((Transform)selectableElement.rectTransform).position.y > ((Transform)menuSelectableElement.rectTransform).position.y))
				{
					menuSelectableElement = selectableElement;
				}
			}
		}
		if ((Object)(object)menuSelectableElement != (Object)null)
		{
			MenuManager.instance.lastHoverMenuID = menuSelectableElement.menuID;
		}
	}

	public void WireVerticalNavigation(float rowEpsilon = 2f)
	{
		//IL_0050: Unknown result type (might be due to invalid IL or missing references)
		//IL_0129: Unknown result type (might be due to invalid IL or missing references)
		//IL_012e: Unknown result type (might be due to invalid IL or missing references)
		//IL_015e: Unknown result type (might be due to invalid IL or missing references)
		List<List<MenuSelectableElement>> list = new List<List<MenuSelectableElement>>();
		foreach (MenuSelectableElement selectableElement in selectableElements)
		{
			if (Object.op_Implicit((Object)(object)selectableElement) && ((Selectable)selectableElement).IsInteractable())
			{
				float y = ((Transform)selectableElement.rectTransform).position.y;
				List<MenuSelectableElement> list2 = list.Find((List<MenuSelectableElement> r) =>
				{
					//IL_000c: Unknown result type (might be due to invalid IL or missing references)
					return Mathf.Abs(((Transform)r[0].rectTransform).position.y - y) <= rowEpsilon;
				});
				if (list2 == null)
				{
					list2 = new List<MenuSelectableElement>();
					list.Add(list2);
				}
				list2.Add(selectableElement);
			}
		}
		if (list.Count < 1)
		{
			return;
		}
		list.Sort((List<MenuSelectableElement> a, List<MenuSelectableElement> b) =>
		{
			//IL_000c: Unknown result type (might be due to invalid IL or missing references)
			//IL_0011: Unknown result type (might be due to invalid IL or missing references)
			//IL_0025: Unknown result type (might be due to invalid IL or missing references)
			return ((Transform)b[0].rectTransform).position.y.CompareTo(((Transform)a[0].rectTransform).position.y);
		});
		for (int num = 0; num < list.Count; num++)
		{
			List<MenuSelectableElement> list3 = list[num];
			List<MenuSelectableElement> list4 = ((num > 0) ? list[num - 1] : null);
			List<MenuSelectableElement> list5 = ((num < list.Count - 1) ? list[num + 1] : null);
			foreach (MenuSelectableElement item in list3)
			{
				Navigation navigation = ((Selectable)item).navigation;
				if (list4 != null)
				{
					navigation.selectOnUp = (Selectable)(object)ClosestByX(list4, item);
				}
				navigation.selectOnDown = (Selectable)(object)((list5 != null) ? ClosestByX(list5, item) : item);
				((Selectable)item).navigation = navigation;
			}
		}
	}

	public static void WireColumnCrossNavigation(MenuPage leftPage, MenuPage rightPage, MenuSelectableElement rightToLeftTarget = null)
	{
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0077: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c4: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c9: Unknown result type (might be due to invalid IL or missing references)
		//IL_0119: Unknown result type (might be due to invalid IL or missing references)
		//IL_011e: Unknown result type (might be due to invalid IL or missing references)
		//IL_012b: Unknown result type (might be due to invalid IL or missing references)
		if (!Object.op_Implicit((Object)(object)leftPage) || !Object.op_Implicit((Object)(object)rightPage) || leftPage.selectableElements.Count == 0 || rightPage.selectableElements.Count == 0)
		{
			return;
		}
		foreach (MenuSelectableElement selectableElement in leftPage.selectableElements)
		{
			if (Object.op_Implicit((Object)(object)selectableElement) && ((Selectable)selectableElement).IsInteractable())
			{
				MenuSelectableElement menuSelectableElement = ClosestByY(rightPage.selectableElements, selectableElement);
				if (Object.op_Implicit((Object)(object)menuSelectableElement))
				{
					Navigation navigation = ((Selectable)selectableElement).navigation;
					navigation.selectOnRight = (Selectable)(object)menuSelectableElement;
					((Selectable)selectableElement).navigation = navigation;
				}
			}
		}
		foreach (MenuSelectableElement selectableElement2 in rightPage.selectableElements)
		{
			if (!Object.op_Implicit((Object)(object)selectableElement2) || !((Selectable)selectableElement2).IsInteractable())
			{
				continue;
			}
			Navigation navigation2 = ((Selectable)selectableElement2).navigation;
			if (!(navigation2.selectOnLeft is MenuSelectableElement item) || !rightPage.selectableElements.Contains(item))
			{
				MenuSelectableElement menuSelectableElement2 = ((Object.op_Implicit((Object)(object)rightToLeftTarget) && ((Selectable)rightToLeftTarget).IsInteractable()) ? rightToLeftTarget : ClosestByY(leftPage.selectableElements, selectableElement2));
				if (Object.op_Implicit((Object)(object)menuSelectableElement2))
				{
					Navigation navigation3 = ((Selectable)selectableElement2).navigation;
					navigation3.selectOnLeft = (Selectable)(object)menuSelectableElement2;
					((Selectable)selectableElement2).navigation = navigation3;
				}
			}
		}
	}

	private static MenuSelectableElement ClosestByX(List<MenuSelectableElement> row, MenuSelectableElement reference)
	{
		//IL_002f: Unknown result type (might be due to invalid IL or missing references)
		//IL_003f: Unknown result type (might be due to invalid IL or missing references)
		MenuSelectableElement result = null;
		float num = float.MaxValue;
		foreach (MenuSelectableElement item in row)
		{
			if (Object.op_Implicit((Object)(object)item) && ((Selectable)item).IsInteractable())
			{
				float num2 = Mathf.Abs(((Transform)item.rectTransform).position.x - ((Transform)reference.rectTransform).position.x);
				if (num2 < num)
				{
					num = num2;
					result = item;
				}
			}
		}
		return result;
	}

	private static MenuSelectableElement ClosestByY(List<MenuSelectableElement> candidates, MenuSelectableElement reference)
	{
		//IL_002f: Unknown result type (might be due to invalid IL or missing references)
		//IL_003f: Unknown result type (might be due to invalid IL or missing references)
		MenuSelectableElement result = null;
		float num = float.MaxValue;
		foreach (MenuSelectableElement candidate in candidates)
		{
			if (Object.op_Implicit((Object)(object)candidate) && ((Selectable)candidate).IsInteractable())
			{
				float num2 = Mathf.Abs(((Transform)candidate.rectTransform).position.y - ((Transform)reference.rectTransform).position.y);
				if (num2 < num)
				{
					num = num2;
					result = candidate;
				}
			}
		}
		return result;
	}

	private void LockAndHide()
	{
		SemiFunc.UIHideAim();
		SemiFunc.UIHideEnergy();
		SemiFunc.UIHideGoal();
		SemiFunc.UIHideHealth();
		SemiFunc.UIHideOvercharge();
		SemiFunc.UIHideInventory();
		SemiFunc.UIHideHaul();
		SemiFunc.UIHideCurrency();
		SemiFunc.UIHideShopCost();
		SemiFunc.UIHideTumble();
		SemiFunc.UIHideWorldSpace();
		SemiFunc.UIHideValuableDiscover();
		SemiFunc.CameraOverrideStopAim();
	}

	public MenuPage()
	{
		//IL_000b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0010: Unknown result type (might be due to invalid IL or missing references)
	}
}
