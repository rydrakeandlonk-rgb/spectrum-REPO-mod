using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PropLightFlickering : MonoBehaviour
{
	private static readonly int EmissionColor = Shader.PropertyToID("_EmissionColor");

	[Space]
	public float restDurationMin = 8f;

	public float restDurationMax = 20f;

	public float burstDurationMin = 0.5f;

	public float burstDurationMax = 3f;

	public List<AnimationCurve> intensityCurves = new List<AnimationCurve>();

	public List<Sound> burstSounds = new List<Sound>();

	[Space]
	public Sound flickOffSound;

	public Sound flickOnSound;

	public float flickSoundThreshold = 0.5f;

	public float flickSoundBuffer = 0.2f;

	[Space]
	public List<Light> syncedLights = new List<Light>();

	public List<MeshRenderer> syncedRenderers = new List<MeshRenderer>();

	internal Light lightComponent;

	internal PropLight propLight;

	internal List<float> syncedBaseIntensities = new List<float>();

	internal List<Material> syncedMaterials = new List<Material>();

	internal List<Color> syncedBaseEmissions = new List<Color>();

	internal int flickeringIndex;

	private float current = 1f;

	private bool flickSoundOn = true;

	private float flickSoundTime;

	private Coroutine burstRoutine;

	private void Awake()
	{
		//IL_008b: Unknown result type (might be due to invalid IL or missing references)
		lightComponent = ((Component)this).GetComponent<Light>();
		propLight = ((Component)this).GetComponent<PropLight>();
		foreach (Light syncedLight in syncedLights)
		{
			syncedBaseIntensities.Add(syncedLight.intensity);
		}
		foreach (MeshRenderer syncedRenderer in syncedRenderers)
		{
			Material material = ((Renderer)syncedRenderer).material;
			syncedMaterials.Add(material);
			syncedBaseEmissions.Add(material.GetColor(EmissionColor));
		}
	}

	private void OnDisable()
	{
		if (burstRoutine != null)
		{
			BurstStop(_resetIntensity: false);
		}
	}

	public void BurstStart(float _duration, int _curveIndex)
	{
		if (((Behaviour)this).isActiveAndEnabled && ((Behaviour)propLight).enabled && !propLight.turnedOff && !(propLight.fadeEndTime > Time.time) && !SemiFunc.Photosensitivity())
		{
			((MonoBehaviour)this).StopAllCoroutines();
			LightManager.instance.flickeringLightsFlickering[flickeringIndex] = true;
			flickSoundOn = true;
			burstRoutine = ((MonoBehaviour)this).StartCoroutine(BurstRoutine(_duration, _curveIndex));
		}
	}

	private IEnumerator BurstRoutine(float _duration, int _curveIndex)
	{
		AnimationCurve _curve = intensityCurves[_curveIndex];
		Keyframe val = _curve[_curve.length - 1];
		float _curveLength = val.time;
		float _burstTimer = _duration;
		float _curveTimer = 0f;
		while (_burstTimer > 0f)
		{
			_burstTimer -= Time.deltaTime;
			_curveTimer += Time.deltaTime;
			current = _curve.Evaluate((_curveLength > 0f) ? Mathf.Repeat(_curveTimer, _curveLength) : 0f);
			if (current < 0f)
			{
				current = 0f;
			}
			ApplyIntensity();
			FlickSoundUpdate();
			yield return null;
		}
		while (current < 0.999f)
		{
			current = Mathf.Lerp(current, 1f, Time.deltaTime * 10f);
			ApplyIntensity();
			FlickSoundUpdate();
			yield return null;
		}
		current = 1f;
		ApplyIntensity();
		burstRoutine = null;
		LightManager.instance.flickeringLightsFlickering[flickeringIndex] = false;
	}

	internal void BurstStop(bool _resetIntensity)
	{
		//IL_0096: Unknown result type (might be due to invalid IL or missing references)
		((MonoBehaviour)this).StopAllCoroutines();
		burstRoutine = null;
		LightManager.instance.flickeringLightsFlickering[flickeringIndex] = false;
		current = 1f;
		if (_resetIntensity)
		{
			lightComponent.intensity = propLight.originalIntensity;
		}
		for (int i = 0; i < syncedLights.Count; i++)
		{
			syncedLights[i].intensity = syncedBaseIntensities[i];
		}
		for (int j = 0; j < syncedMaterials.Count; j++)
		{
			syncedMaterials[j].SetColor(EmissionColor, syncedBaseEmissions[j]);
		}
	}

	internal void TurnOff()
	{
		//IL_0032: Unknown result type (might be due to invalid IL or missing references)
		for (int i = 0; i < syncedBaseIntensities.Count; i++)
		{
			syncedBaseIntensities[i] = 0f;
		}
		for (int j = 0; j < syncedBaseEmissions.Count; j++)
		{
			syncedBaseEmissions[j] = Color.black;
		}
		BurstStop(_resetIntensity: false);
		lightComponent.intensity = 0f;
		((Behaviour)this).enabled = false;
	}

	private void FlickSoundUpdate()
	{
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		bool flag = current >= flickSoundThreshold;
		if (flag != flickSoundOn && !(Time.time - flickSoundTime < flickSoundBuffer))
		{
			flickSoundOn = flag;
			flickSoundTime = Time.time;
			(flag ? flickOnSound : flickOffSound)?.Play(((Component)this).transform.position);
		}
	}

	private void ApplyIntensity()
	{
		//IL_0073: Unknown result type (might be due to invalid IL or missing references)
		//IL_007e: Unknown result type (might be due to invalid IL or missing references)
		lightComponent.intensity = propLight.originalIntensity * current;
		for (int i = 0; i < syncedLights.Count; i++)
		{
			syncedLights[i].intensity = syncedBaseIntensities[i] * current;
		}
		for (int j = 0; j < syncedMaterials.Count; j++)
		{
			syncedMaterials[j].SetColor(EmissionColor, syncedBaseEmissions[j] * current);
		}
	}
}
