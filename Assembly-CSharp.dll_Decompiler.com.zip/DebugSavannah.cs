using UnityEngine;

public class DebugSavannah : MonoBehaviour
{
}
