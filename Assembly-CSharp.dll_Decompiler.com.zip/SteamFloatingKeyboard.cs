using System;
using System.Reflection;
using System.Runtime.InteropServices;
using Steamworks;
using UnityEngine;

public static class SteamFloatingKeyboard
{
	public enum Mode
	{
		SingleLine,
		MultipleLines,
		Email,
		Numeric
	}

	private const string lib = "steam_api64";

	private static bool dismissedCallbackInstalled;

	public static bool IsOpen { get; private set; }

	[DllImport("steam_api64", CallingConvention = CallingConvention.Cdecl)]
	private static extern IntPtr SteamAPI_SteamUtils_v010();

	[DllImport("steam_api64", CallingConvention = CallingConvention.Cdecl)]
	[return: MarshalAs(UnmanagedType.I1)]
	private static extern bool SteamAPI_ISteamUtils_ShowFloatingGamepadTextInput(IntPtr _self, Mode _mode, int _x, int _y, int _width, int _height);

	[DllImport("steam_api64", CallingConvention = CallingConvention.Cdecl)]
	[return: MarshalAs(UnmanagedType.I1)]
	private static extern bool SteamAPI_ISteamUtils_DismissFloatingGamepadTextInput(IntPtr _self);

	[RuntimeInitializeOnLoadMethod(/*Could not decode attribute arguments.*/)]
	private static void RuntimeInitializeOnLoad()
	{
		IsOpen = false;
		dismissedCallbackInstalled = false;
	}

	private static bool DismissedCallbackInstall()
	{
		if (dismissedCallbackInstalled)
		{
			return true;
		}
		try
		{
			Assembly assembly = typeof(SteamClient).Assembly;
			Type type = assembly.GetType("Steamworks.Data.FloatingGamepadTextInputDismissed_t");
			MethodInfo methodInfo = assembly.GetType("Steamworks.Dispatch")?.GetMethod("Install", BindingFlags.Static | BindingFlags.Public | BindingFlags.NonPublic);
			if (type == null || methodInfo == null)
			{
				return false;
			}
			MethodInfo method = typeof(SteamFloatingKeyboard).GetMethod("Dismissed", BindingFlags.Static | BindingFlags.NonPublic).MakeGenericMethod(type);
			Delegate obj = Delegate.CreateDelegate(typeof(Action<>).MakeGenericType(type), method);
			methodInfo.MakeGenericMethod(type).Invoke(null, new object[2] { obj, false });
			dismissedCallbackInstalled = true;
		}
		catch (Exception ex)
		{
			Debug.LogWarning((object)("SteamFloatingKeyboard: dismissed callback install failed, " + ex.Message));
		}
		return dismissedCallbackInstalled;
	}

	private static void Dismissed<T>(T _data)
	{
		IsOpen = false;
	}

	public static bool Show(Mode _mode, Rect _field)
	{
		if (!SteamClient.IsValid)
		{
			return false;
		}
		if (!DismissedCallbackInstall())
		{
			return false;
		}
		try
		{
			IntPtr intPtr = SteamAPI_SteamUtils_v010();
			if (intPtr == IntPtr.Zero)
			{
				return false;
			}
			float num = (float)Screen.height - _field.yMax;
			IsOpen = SteamAPI_ISteamUtils_ShowFloatingGamepadTextInput(intPtr, _mode, (int)_field.x, (int)num, (int)_field.width, (int)_field.height);
			return IsOpen;
		}
		catch (Exception ex)
		{
			Debug.LogWarning((object)("SteamFloatingKeyboard: " + ex.Message));
			return false;
		}
	}

	public static void Dismiss()
	{
		IsOpen = false;
		if (!SteamClient.IsValid)
		{
			return;
		}
		try
		{
			IntPtr intPtr = SteamAPI_SteamUtils_v010();
			if (intPtr != IntPtr.Zero)
			{
				SteamAPI_ISteamUtils_DismissFloatingGamepadTextInput(intPtr);
			}
		}
		catch (Exception)
		{
		}
	}
}
