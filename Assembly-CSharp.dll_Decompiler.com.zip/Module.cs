using System;
using Photon.Pun;
using UnityEngine;

public class Module : MonoBehaviour
{
	public enum Type
	{
		Normal,
		Passage,
		DeadEnd,
		Extraction,
		Special,
		Mega,
		StartRoom
	}

	public enum Status
	{
		WIP,
		Finalized
	}

	public Status status;

	public SemiFunc.User moduleOwner;

	[Space]
	public Type type;

	[Space(20f)]
	private PhotonView photonView;

	private Color colorPositive = Color.green;

	private Color colorNegative = new Color(1f, 0.74f, 0.61f);

	public bool wallsInside;

	[Space]
	public bool wallsMap;

	public bool levelPointsEntrance;

	[Space]
	public bool levelPointsWaypoints;

	[Space]
	public bool levelPointsRoomVolume;

	[Space]
	public bool levelPointsNavmesh;

	[Space]
	public bool levelPointsConnected;

	public bool lightsMax;

	[Space]
	public bool lightsPrefab;

	public bool roomVolumeDoors;

	[Space]
	public bool roomVolumeHeight;

	[Space]
	public bool roomVolumeSpace;

	public bool navmeshConnected;

	[Space]
	public bool navmeshPitfalls;

	public bool valuablesAllTypes;

	[Space]
	public bool valuablesMaxed;

	[Space]
	public bool valuablesSwitch;

	[Space]
	public bool valuablesSwitchNavmesh;

	[Space]
	public bool valuablesTest;

	public bool ModulePropSwitchSetup;

	[Space]
	public bool ModulePropSwitchNavmesh;

	internal bool ConnectingTop;

	internal bool ConnectingTopRight;

	internal bool ConnectingTopLeft;

	internal bool ConnectingRight;

	internal bool ConnectingRightTop;

	internal bool ConnectingRightBot;

	internal bool ConnectingBottom;

	internal bool ConnectingBottomRight;

	internal bool ConnectingBottomLeft;

	internal bool ConnectingLeft;

	internal bool ConnectingLeftTop;

	internal bool ConnectingLeftBot;

	[Space]
	internal bool SetupDone;

	internal bool First;

	[Space]
	internal int GridX;

	internal int GridY;

	public bool Explored;

	internal bool StartRoom;

	private void Awake()
	{
		photonView = ((Component)this).GetComponent<PhotonView>();
		photonView.ObservedComponents.Clear();
	}

	private void Start()
	{
		if (Object.op_Implicit((Object)(object)((Component)this).GetComponent<StartRoom>()))
		{
			StartRoom = true;
		}
		else
		{
			((Component)this).transform.parent = LevelGenerator.Instance.LevelParent.transform;
		}
	}

	internal Color GetStatusColor()
	{
		//IL_001d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0022: Unknown result type (might be due to invalid IL or missing references)
		//IL_0034: Unknown result type (might be due to invalid IL or missing references)
		//IL_0039: Unknown result type (might be due to invalid IL or missing references)
		//IL_003f: Unknown result type (might be due to invalid IL or missing references)
		return status switch
		{
			Status.WIP => Color32.op_Implicit(new Color32(byte.MaxValue, (byte)16, (byte)0, byte.MaxValue)), 
			Status.Finalized => Color32.op_Implicit(new Color32((byte)0, byte.MaxValue, (byte)2, byte.MaxValue)), 
			_ => Color.white, 
		};
	}

	private void OnDrawGizmos()
	{
		//IL_0039: Unknown result type (might be due to invalid IL or missing references)
		//IL_0049: Unknown result type (might be due to invalid IL or missing references)
		//IL_0124: Unknown result type (might be due to invalid IL or missing references)
		//IL_013d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0160: Unknown result type (might be due to invalid IL or missing references)
		//IL_0178: Unknown result type (might be due to invalid IL or missing references)
		//IL_019b: Unknown result type (might be due to invalid IL or missing references)
		//IL_01b5: Unknown result type (might be due to invalid IL or missing references)
		//IL_01d7: Unknown result type (might be due to invalid IL or missing references)
		//IL_01f0: Unknown result type (might be due to invalid IL or missing references)
		//IL_0071: Unknown result type (might be due to invalid IL or missing references)
		//IL_0087: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a8: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c2: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e2: Unknown result type (might be due to invalid IL or missing references)
		//IL_00fb: Unknown result type (might be due to invalid IL or missing references)
		//IL_0213: Unknown result type (might be due to invalid IL or missing references)
		//IL_0235: Unknown result type (might be due to invalid IL or missing references)
		//IL_0249: Unknown result type (might be due to invalid IL or missing references)
		//IL_027e: Unknown result type (might be due to invalid IL or missing references)
		//IL_029c: Unknown result type (might be due to invalid IL or missing references)
		//IL_02c5: Unknown result type (might be due to invalid IL or missing references)
		//IL_02e4: Unknown result type (might be due to invalid IL or missing references)
		//IL_030d: Unknown result type (might be due to invalid IL or missing references)
		//IL_032c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0356: Unknown result type (might be due to invalid IL or missing references)
		//IL_0376: Unknown result type (might be due to invalid IL or missing references)
		//IL_039e: Unknown result type (might be due to invalid IL or missing references)
		//IL_03bc: Unknown result type (might be due to invalid IL or missing references)
		//IL_03e5: Unknown result type (might be due to invalid IL or missing references)
		//IL_0404: Unknown result type (might be due to invalid IL or missing references)
		//IL_042d: Unknown result type (might be due to invalid IL or missing references)
		//IL_044c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0476: Unknown result type (might be due to invalid IL or missing references)
		//IL_0496: Unknown result type (might be due to invalid IL or missing references)
		//IL_0500: Unknown result type (might be due to invalid IL or missing references)
		//IL_0517: Unknown result type (might be due to invalid IL or missing references)
		//IL_04c9: Unknown result type (might be due to invalid IL or missing references)
		//IL_04df: Unknown result type (might be due to invalid IL or missing references)
		//IL_0552: Unknown result type (might be due to invalid IL or missing references)
		//IL_0568: Unknown result type (might be due to invalid IL or missing references)
		//IL_05a4: Unknown result type (might be due to invalid IL or missing references)
		//IL_05bb: Unknown result type (might be due to invalid IL or missing references)
		float num = LevelGenerator.TileSize;
		if (type == Type.Mega)
		{
			num *= 2f;
		}
		float num2 = LevelGenerator.ModuleWidth * num;
		_ = LevelGenerator.ModuleHeight;
		Gizmos.color = new Color(1f, 1f, 1f, 0.3f);
		Gizmos.matrix = ((Component)this).transform.localToWorldMatrix;
		if (type == Type.StartRoom)
		{
			SemiFunc.DrawLine(new Vector3((0f - num2) / 2f, 0f, 0f), new Vector3(num2 / 2f, 0f, 0f), 2f);
			SemiFunc.DrawLine(new Vector3((0f - num2) / 2f, 0f, 0f), new Vector3((0f - num2) / 2f, 0f, (0f - num2) / 2f), 2f);
			SemiFunc.DrawLine(new Vector3(num2 / 2f, 0f, 0f), new Vector3(num2 / 2f, 0f, (0f - num2) / 2f), 2f);
		}
		else
		{
			SemiFunc.DrawLine(new Vector3((0f - num2) / 2f, 0f, (0f - num2) / 2f), new Vector3(num2 / 2f, 0f, (0f - num2) / 2f), 2f);
			SemiFunc.DrawLine(new Vector3((0f - num2) / 2f, 0f, num2 / 2f), new Vector3(num2 / 2f, 0f, num2 / 2f), 2f);
			SemiFunc.DrawLine(new Vector3((0f - num2) / 2f, 0f, num2 / 2f), new Vector3((0f - num2) / 2f, 0f, (0f - num2) / 2f), 2f);
			SemiFunc.DrawLine(new Vector3(num2 / 2f, 0f, num2 / 2f), new Vector3(num2 / 2f, 0f, (0f - num2) / 2f), 2f);
		}
		Gizmos.color = new Color(1f, 1f, 1f, 0.75f);
		if (type == Type.StartRoom)
		{
			SemiFunc.DrawLine(new Vector3(1f, 0f, 0f), new Vector3(-1f, 0f, 0f), 4f);
			return;
		}
		if (type == Type.Mega)
		{
			SemiFunc.DrawLine(new Vector3(num2 * 0.25f + 1f, 0f, num2 / 2f), new Vector3(num2 * 0.25f - 1f, 0f, num2 / 2f), 4f);
			SemiFunc.DrawLine(new Vector3((0f - num2) * 0.25f + 1f, 0f, num2 / 2f), new Vector3((0f - num2) * 0.25f - 1f, 0f, num2 / 2f), 4f);
			SemiFunc.DrawLine(new Vector3(num2 * 0.25f + 1f, 0f, (0f - num2) / 2f), new Vector3(num2 * 0.25f - 1f, 0f, (0f - num2) / 2f), 4f);
			SemiFunc.DrawLine(new Vector3((0f - num2) * 0.25f + 1f, 0f, (0f - num2) / 2f), new Vector3((0f - num2) * 0.25f - 1f, 0f, (0f - num2) / 2f), 4f);
			SemiFunc.DrawLine(new Vector3(num2 / 2f, 0f, num2 * 0.25f + 1f), new Vector3(num2 / 2f, 0f, num2 * 0.25f - 1f), 4f);
			SemiFunc.DrawLine(new Vector3(num2 / 2f, 0f, (0f - num2) * 0.25f + 1f), new Vector3(num2 / 2f, 0f, (0f - num2) * 0.25f - 1f), 4f);
			SemiFunc.DrawLine(new Vector3((0f - num2) / 2f, 0f, num2 * 0.25f + 1f), new Vector3((0f - num2) / 2f, 0f, num2 * 0.25f - 1f), 4f);
			SemiFunc.DrawLine(new Vector3((0f - num2) / 2f, 0f, (0f - num2) * 0.25f + 1f), new Vector3((0f - num2) / 2f, 0f, (0f - num2) * 0.25f - 1f), 4f);
			return;
		}
		if (type != Type.DeadEnd && type != Type.Extraction)
		{
			SemiFunc.DrawLine(new Vector3(1f, 0f, num2 / 2f), new Vector3(-1f, 0f, num2 / 2f), 4f);
		}
		SemiFunc.DrawLine(new Vector3(1f, 0f, (0f - num2) / 2f), new Vector3(-1f, 0f, (0f - num2) / 2f), 4f);
		if (type != Type.Passage && type != Type.DeadEnd && type != Type.Extraction)
		{
			SemiFunc.DrawLine(new Vector3(num2 / 2f, 0f, 1f), new Vector3(num2 / 2f, 0f, -1f), 4f);
		}
		if (type != Type.Passage && type != Type.DeadEnd && type != Type.Extraction)
		{
			SemiFunc.DrawLine(new Vector3((0f - num2) / 2f, 0f, 1f), new Vector3((0f - num2) / 2f, 0f, -1f), 4f);
		}
	}

	private void ResetChecklist()
	{
		wallsInside = false;
		wallsMap = false;
		levelPointsEntrance = false;
		levelPointsWaypoints = false;
		levelPointsRoomVolume = false;
		levelPointsNavmesh = false;
		levelPointsConnected = false;
		lightsMax = false;
		lightsPrefab = false;
		roomVolumeDoors = false;
		roomVolumeHeight = false;
		roomVolumeSpace = false;
		navmeshConnected = false;
		navmeshPitfalls = false;
		valuablesAllTypes = false;
		valuablesMaxed = false;
		valuablesSwitch = false;
		valuablesSwitchNavmesh = false;
		valuablesTest = false;
		ModulePropSwitchSetup = false;
		ModulePropSwitchNavmesh = false;
	}

	private void SetAllChecklist()
	{
		wallsInside = true;
		wallsMap = true;
		levelPointsEntrance = true;
		levelPointsWaypoints = true;
		levelPointsRoomVolume = true;
		levelPointsNavmesh = true;
		levelPointsConnected = true;
		lightsMax = true;
		lightsPrefab = true;
		roomVolumeDoors = true;
		roomVolumeHeight = true;
		roomVolumeSpace = true;
		navmeshConnected = true;
		navmeshPitfalls = true;
		valuablesAllTypes = true;
		valuablesMaxed = true;
		valuablesSwitch = true;
		valuablesSwitchNavmesh = true;
		valuablesTest = true;
		ModulePropSwitchSetup = true;
		ModulePropSwitchNavmesh = true;
	}

	public void ModuleConnectionSet(bool _top, bool _bottom, bool _right, bool _left, bool _first)
	{
		//IL_0058: Unknown result type (might be due to invalid IL or missing references)
		//IL_005e: Unknown result type (might be due to invalid IL or missing references)
		if (SemiFunc.IsMultiplayer())
		{
			photonView.RPC("ModuleConnectionSetRPC", (RpcTarget)0, new object[5] { _top, _bottom, _right, _left, _first });
		}
		else
		{
			ModuleConnectionSetRPC(_top, _bottom, _right, _left, _first);
		}
	}

	[PunRPC]
	private void ModuleConnectionSetRPC(bool _top, bool _bottom, bool _right, bool _left, bool _first, PhotonMessageInfo _info = default(PhotonMessageInfo))
	{
		//IL_0000: Unknown result type (might be due to invalid IL or missing references)
		if (SemiFunc.MasterOnlyRPC(_info))
		{
			ConnectingTop = _top;
			ConnectingBottom = _bottom;
			ConnectingRight = _right;
			ConnectingLeft = _left;
			First = _first;
			ConnectionSetup();
		}
	}

	public void ModuleConnectionSetMega(bool _topRight, bool _topLeft, bool _rightTop, bool _rightBot, bool _botRight, bool _botLeft, bool _leftTop, bool _leftBot, bool _first)
	{
		//IL_0089: Unknown result type (might be due to invalid IL or missing references)
		//IL_008f: Unknown result type (might be due to invalid IL or missing references)
		if (SemiFunc.IsMultiplayer())
		{
			photonView.RPC("ModuleConnectionSetMegaRPC", (RpcTarget)0, new object[9] { _topRight, _topLeft, _rightTop, _rightBot, _botRight, _botLeft, _leftTop, _leftBot, _first });
		}
		else
		{
			ModuleConnectionSetMegaRPC(_topRight, _topLeft, _rightTop, _rightBot, _botRight, _botLeft, _leftTop, _leftBot, _first);
		}
	}

	[PunRPC]
	private void ModuleConnectionSetMegaRPC(bool _topRight, bool _topLeft, bool _rightTop, bool _rightBot, bool _botRight, bool _botLeft, bool _leftTop, bool _leftBot, bool _first, PhotonMessageInfo _info = default(PhotonMessageInfo))
	{
		//IL_0000: Unknown result type (might be due to invalid IL or missing references)
		if (SemiFunc.MasterOnlyRPC(_info))
		{
			ConnectingTopRight = _topRight;
			ConnectingTopLeft = _topLeft;
			ConnectingRightTop = _rightTop;
			ConnectingRightBot = _rightBot;
			ConnectingBottomRight = _botRight;
			ConnectingBottomLeft = _botLeft;
			ConnectingLeftTop = _leftTop;
			ConnectingLeftBot = _leftBot;
			First = _first;
			ConnectionSetup();
		}
	}

	private void ConnectionSetup()
	{
		SetupDone = true;
		ModulePropSwitch[] componentsInChildren = ((Component)this).GetComponentsInChildren<ModulePropSwitch>();
		foreach (ModulePropSwitch modulePropSwitch in componentsInChildren)
		{
			modulePropSwitch.Module = this;
			try
			{
				modulePropSwitch.Setup();
			}
			catch (Exception ex)
			{
				Debug.LogError((object)("prop switch " + ((Object)modulePropSwitch).name + " in module " + SemiFunc.ModuleNameGet(((Component)this).transform) + " broke during setup... the exception below shows where... the module still counts as loaded"), (Object)(object)modulePropSwitch);
				Debug.LogException(ex, (Object)(object)modulePropSwitch);
			}
		}
		LevelGenerator.Instance.ModulesSpawned++;
		if (!SemiFunc.IsMasterClientOrSingleplayer())
		{
			return;
		}
		CustomConnectionObject[] componentsInChildren2 = ((Component)this).GetComponentsInChildren<CustomConnectionObject>();
		foreach (CustomConnectionObject customConnectionObject in componentsInChildren2)
		{
			if (((Component)customConnectionObject).gameObject.activeInHierarchy)
			{
				customConnectionObject.Setup();
			}
		}
	}

	public Module()
	{
		//IL_0001: Unknown result type (might be due to invalid IL or missing references)
		//IL_0006: Unknown result type (might be due to invalid IL or missing references)
		//IL_001b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0020: Unknown result type (might be due to invalid IL or missing references)
	}
}
