using Photon.Pun;
using TMPro;
using UnityEngine;
using UnityEngine.Rendering;

public class MapToolController : MonoBehaviour
{
	public static MapToolController instance;

	internal bool Active;

	private bool ActivePrev;

	internal PhotonView photonView;

	public PlayerAvatar PlayerAvatar;

	[Space]
	public Transform FollowTransform;

	public Transform FollowTransformClient;

	[Space]
	public Transform ControllerTransform;

	public Transform VisualTransform;

	public Transform PlayerLookTarget;

	public Transform HideTransform;

	[Space]
	private float DisplayJointAngleDiff;

	private float DisplayJointAnglePreviousX;

	[Space]
	public float MoveMultiplier = 0.5f;

	public float FadeAmount = 0.5f;

	public float BobMultiplier = 0.1f;

	[Space]
	public Sound SoundStart;

	public Sound SoundStop;

	public Sound SoundLoop;

	[Space]
	public MeshRenderer ledMesh;

	private Material ledMaterial;

	private Color ledEmissionOriginal;

	private Color ledFlickerColor;

	private float ledFlickerTimer;

	private float ledBlinkTimer;

	private bool ledBlinkOn;

	private bool ledFlickerActive;

	[Space]
	public MeshRenderer DisplayMesh;

	public Material DisplayMaterial;

	public Material DisplayMaterialClient;

	[Space]
	public MeshRenderer StickMesh;

	public MeshRenderer MainUnitMesh;

	public GameObject LocalShadowsParent;

	[Space]
	public AnimationCurve IntroCurve;

	public float IntroSpeed;

	public AnimationCurve OutroCurve;

	public float OutroSpeed;

	internal float HideLerp;

	private float HideScale;

	[Space]
	public Transform displaySpringTransform;

	public Transform displaySpringTransformTarget;

	public SpringQuaternion displaySpring;

	[Space]
	public Transform mainSpringTransform;

	public Transform mainSpringTransformTarget;

	public SpringQuaternion mainSpring;

	private bool mapToggled;

	[RuntimeInitializeOnLoadMethod(/*Could not decode attribute arguments.*/)]
	private static void RuntimeInitializeOnLoad()
	{
		instance = null;
	}

	private void Awake()
	{
		photonView = ((Component)this).GetComponent<PhotonView>();
	}

	private void Start()
	{
		//IL_002e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0033: Unknown result type (might be due to invalid IL or missing references)
		//IL_008a: Unknown result type (might be due to invalid IL or missing references)
		//IL_009f: Unknown result type (might be due to invalid IL or missing references)
		((Component)VisualTransform).gameObject.SetActive(false);
		ledMaterial = ((Renderer)ledMesh).material;
		ledEmissionOriginal = ledMaterial.GetColor("_EmissionColor");
		SoundsSetup();
		if (!GameManager.Multiplayer() || photonView.IsMine)
		{
			instance = this;
			((Renderer)DisplayMesh).material = DisplayMaterial;
			((Component)this).transform.parent.parent = FollowTransform;
			((Component)this).transform.parent.localPosition = Vector3.zero;
			((Component)this).transform.parent.localRotation = Quaternion.identity;
		}
		else
		{
			((Renderer)DisplayMesh).material = DisplayMaterialClient;
			Transform[] componentsInChildren = ((Component)VisualTransform).GetComponentsInChildren<Transform>();
			for (int i = 0; i < componentsInChildren.Length; i++)
			{
				((Component)componentsInChildren[i]).gameObject.layer = LayerMask.NameToLayer("Triggers");
			}
		}
	}

	public void LedFlicker(Color _color, float _time)
	{
		//IL_0001: Unknown result type (might be due to invalid IL or missing references)
		//IL_0002: Unknown result type (might be due to invalid IL or missing references)
		ledFlickerColor = _color;
		ledFlickerTimer = _time;
	}

	private void LedFlickerTick()
	{
		//IL_0021: Unknown result type (might be due to invalid IL or missing references)
		//IL_008b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0095: Unknown result type (might be due to invalid IL or missing references)
		//IL_0083: Unknown result type (might be due to invalid IL or missing references)
		if (ledFlickerTimer <= 0f && ledFlickerActive)
		{
			ledMaterial.SetColor("_EmissionColor", ledEmissionOriginal);
			ledFlickerActive = false;
		}
		if (ledFlickerTimer > 0f)
		{
			ledFlickerActive = true;
			if (ledBlinkTimer <= 0f)
			{
				ledBlinkTimer = 0.05f;
				ledBlinkOn = !ledBlinkOn;
				ledMaterial.SetColor("_EmissionColor", ledBlinkOn ? (ledFlickerColor * 2f) : Color.black);
			}
			else
			{
				ledBlinkTimer -= Time.deltaTime;
			}
			ledFlickerTimer -= Time.deltaTime;
		}
	}

	private void Update()
	{
		//IL_0267: Unknown result type (might be due to invalid IL or missing references)
		//IL_0213: Unknown result type (might be due to invalid IL or missing references)
		//IL_0303: Unknown result type (might be due to invalid IL or missing references)
		//IL_0313: Unknown result type (might be due to invalid IL or missing references)
		//IL_0329: Unknown result type (might be due to invalid IL or missing references)
		//IL_0459: Unknown result type (might be due to invalid IL or missing references)
		//IL_045e: Unknown result type (might be due to invalid IL or missing references)
		//IL_048a: Unknown result type (might be due to invalid IL or missing references)
		//IL_04a5: Unknown result type (might be due to invalid IL or missing references)
		//IL_04b5: Unknown result type (might be due to invalid IL or missing references)
		//IL_04ba: Unknown result type (might be due to invalid IL or missing references)
		//IL_04cd: Unknown result type (might be due to invalid IL or missing references)
		//IL_04d7: Unknown result type (might be due to invalid IL or missing references)
		//IL_0533: Unknown result type (might be due to invalid IL or missing references)
		//IL_0538: Unknown result type (might be due to invalid IL or missing references)
		//IL_053f: Unknown result type (might be due to invalid IL or missing references)
		//IL_054f: Unknown result type (might be due to invalid IL or missing references)
		//IL_056f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0574: Unknown result type (might be due to invalid IL or missing references)
		//IL_057b: Unknown result type (might be due to invalid IL or missing references)
		//IL_058b: Unknown result type (might be due to invalid IL or missing references)
		//IL_05a7: Unknown result type (might be due to invalid IL or missing references)
		//IL_05b1: Unknown result type (might be due to invalid IL or missing references)
		//IL_04ee: Unknown result type (might be due to invalid IL or missing references)
		//IL_0503: Unknown result type (might be due to invalid IL or missing references)
		//IL_0513: Unknown result type (might be due to invalid IL or missing references)
		//IL_05d3: Unknown result type (might be due to invalid IL or missing references)
		//IL_060b: Unknown result type (might be due to invalid IL or missing references)
		LedFlickerTick();
		bool flag = !GameManager.Multiplayer() || photonView.IsMine;
		if (flag)
		{
			if (!PlayerAvatar.isDisabled && !CameraAim.Instance.AimTargetActive && !SemiFunc.MenuLevel() && SemiFunc.NoTextInputsActive())
			{
				if (InputManager.instance.InputToggleGet(InputKey.Map))
				{
					if (SemiFunc.InputDown(InputKey.Map))
					{
						mapToggled = !mapToggled;
					}
				}
				else
				{
					mapToggled = false;
				}
				if ((SemiFunc.InputHold(InputKey.Map) || mapToggled || Map.Instance.debugActive) && !PlayerController.instance.sprinting)
				{
					if (HideLerp >= 1f)
					{
						Active = true;
					}
				}
				else
				{
					mapToggled = false;
					if (HideLerp <= 0f)
					{
						Active = false;
					}
				}
			}
			else
			{
				Active = false;
			}
			if (Active)
			{
				StatsUI.instance.Show();
				LevelUI.instance.Show();
				ItemInfoUI.instance.Hide();
				ItemInfoExtraUI.instance.Hide();
				if (((TMP_Text)MissionUI.instance.Text).text != "")
				{
					MissionUI.instance.Show();
				}
			}
		}
		if (Active != ActivePrev)
		{
			PlayerAvatar.playerAvatarVisuals.HeadTiltImpulse(250f);
			ActivePrev = Active;
			if (GameManager.Multiplayer() && photonView.IsMine)
			{
				photonView.RPC("SetActiveRPC", (RpcTarget)1, new object[1] { Active });
			}
			if (Active)
			{
				if (flag)
				{
					GameDirector.instance.CameraShake.Shake(2f, 0.1f);
					Map.Instance.ActiveSet(active: true);
					ToggleLocalShadows(PlayerAvatar.playerAvatarVisuals.showSelfOverrideTimer <= 0f);
				}
				((Component)VisualTransform).gameObject.SetActive(true);
				SoundStart.Play(((Component)this).transform.position);
			}
			else
			{
				if (flag)
				{
					GameDirector.instance.CameraShake.Shake(2f, 0.1f);
					Map.Instance.ActiveSet(active: false);
				}
				SoundStop.Play(((Component)this).transform.position);
			}
		}
		float num = 90f;
		if (!flag)
		{
			num = 0f;
		}
		float num2 = 1f;
		if (!flag)
		{
			num2 = 2f;
		}
		if (Active)
		{
			if (HideLerp > 0f)
			{
				HideLerp -= Time.deltaTime * IntroSpeed * num2;
			}
			HideScale = Mathf.LerpUnclamped(1f, 0f, IntroCurve.Evaluate(HideLerp));
			HideTransform.localRotation = Quaternion.Slerp(Quaternion.identity, Quaternion.Euler(num, 0f, 0f), IntroCurve.Evaluate(HideLerp));
		}
		else
		{
			if (HideLerp < 1f)
			{
				HideLerp += Time.deltaTime * OutroSpeed * num2;
				if (HideLerp > 1f)
				{
					((Component)VisualTransform).gameObject.SetActive(false);
					ToggleLocalShadows(_enabled: false);
				}
			}
			HideScale = Mathf.LerpUnclamped(1f, 0f, OutroCurve.Evaluate(HideLerp));
		}
		if (flag && Active)
		{
			SemiFunc.UIHideWorldSpace();
			PlayerController.instance.MoveMult(MoveMultiplier, 0.1f);
			CameraBob.Instance.SetMultiplier(BobMultiplier, 0.1f);
			CameraZoom.Instance.OverrideZoomSet(50f, 0.05f, 2f, 2f, ((Component)this).gameObject, 100);
			CameraNoise.Instance.Override(0.025f, 0.25f);
			if (PlayerAvatar.playerAvatarVisuals.showSelfOverrideTimer <= 0f)
			{
				CameraTopFade.Instance.Set(FadeAmount, 0.1f);
				Aim.instance.SetState(Aim.State.Hidden);
			}
		}
		Vector3 val = Vector3.one;
		if (!flag || PlayerAvatar.playerAvatarVisuals.showSelfOverrideTimer > 0f)
		{
			((Component)this).transform.parent.position = FollowTransformClient.position;
			((Component)this).transform.parent.rotation = FollowTransformClient.rotation;
			val = FollowTransformClient.localScale;
			mainSpringTransform.rotation = SemiFunc.SpringQuaternionGet(mainSpring, mainSpringTransformTarget.rotation);
		}
		else
		{
			((Component)this).transform.parent.localPosition = Vector3.zero;
			((Component)this).transform.parent.localRotation = Quaternion.identity;
			mainSpringTransform.localRotation = Quaternion.identity;
		}
		((Component)this).transform.parent.localScale = Vector3.Lerp(((Component)this).transform.parent.localScale, val * HideScale, Time.deltaTime * 20f);
		LocalShadowsParent.transform.localScale = Vector3.Lerp(LocalShadowsParent.transform.localScale, val * HideScale, Time.deltaTime * 20f);
		displaySpringTransform.rotation = SemiFunc.SpringQuaternionGet(displaySpring, displaySpringTransformTarget.rotation);
		if (Active)
		{
			DisplayJointAngleDiff = (DisplayJointAnglePreviousX - displaySpringTransform.localRotation.x) * 50f;
			DisplayJointAngleDiff = Mathf.Clamp(DisplayJointAngleDiff, -0.1f, 0.1f);
			DisplayJointAnglePreviousX = displaySpringTransform.localRotation.x;
			SoundLoop.LoopPitch = Mathf.Lerp(SoundLoop.LoopPitch, 1f - DisplayJointAngleDiff, Time.deltaTime * 10f);
		}
		SoundLoop.PlayLoop(Active, 5f, 5f);
	}

	[PunRPC]
	public void SetActiveRPC(bool active, PhotonMessageInfo _info = default(PhotonMessageInfo))
	{
		//IL_0000: Unknown result type (might be due to invalid IL or missing references)
		if (SemiFunc.OwnerOnlyRPC(_info, photonView))
		{
			Active = active;
		}
	}

	public void SoundsSetup()
	{
		SoundSetup(SoundStart);
		SoundSetup(SoundStop);
		SoundSetup(SoundLoop);
	}

	private void SoundSetup(Sound _sound)
	{
		_sound.StoreDefault();
		if ((!SemiFunc.IsMultiplayer() || photonView.IsMine) && PlayerAvatar.playerAvatarVisuals.showSelfOverrideTimer <= 0f)
		{
			_sound.Volume = _sound.VolumeDefault;
			_sound.VolumeRandom = _sound.VolumeRandomDefault;
			_sound.SpatialBlend = 0f;
		}
		else
		{
			_sound.Volume = _sound.VolumeDefault * 0.3f;
			_sound.VolumeRandom = _sound.VolumeRandomDefault * 0.3f;
			_sound.SpatialBlend = 1f;
		}
	}

	public void ToggleLocalShadows(bool _enabled)
	{
		//IL_0021: Unknown result type (might be due to invalid IL or missing references)
		//IL_0028: Unknown result type (might be due to invalid IL or missing references)
		//IL_0034: Unknown result type (might be due to invalid IL or missing references)
		if (!(!Active & _enabled))
		{
			LocalShadowsParent.SetActive(_enabled);
			ShadowCastingMode shadowCastingMode = (ShadowCastingMode)(!_enabled);
			((Renderer)StickMesh).shadowCastingMode = shadowCastingMode;
			((Renderer)MainUnitMesh).shadowCastingMode = shadowCastingMode;
		}
	}
}
