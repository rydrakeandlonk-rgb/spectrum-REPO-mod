using System;
using System.Collections.Generic;
using UnityEngine;

[RequireComponent(typeof(LineRenderer))]
public class PhysGrabBeam : MonoBehaviour
{
	public PlayerAvatar playerAvatar;

	public Transform PhysGrabPointOrigin;

	public Transform PhysGrabPointOriginClient;

	public Transform PhysGrabPointOriginLocal;

	public bool mirrorClient;

	public PhysGrabBeam mirrorSource;

	public Transform PhysGrabPoint;

	public Transform PhysGrabPointPuller;

	public Material greenScreenMaterial;

	private Material originalMaterial;

	[HideInInspector]
	public Vector3 physGrabPointPullerSmoothPosition;

	public float CurveStrength = 1f;

	public int CurveResolution = 20;

	public LineRenderer lineRendererOverCharge;

	[Header("Texture Scrolling")]
	public Vector2 scrollSpeed = new Vector2(5f, 0f);

	[HideInInspector]
	public Vector2 originalScrollSpeed;

	public LineRenderer lineRenderer;

	[HideInInspector]
	public Material lineMaterial;

	private Material lineMaterialOverCharge;

	private Vector3[] curvePointsOverChargeOffsets;

	public Transform overchargeImpact;

	private List<ParticleSystem> overchargeParticles = new List<ParticleSystem>();

	public Sound soundOverchargeImpact;

	private Color overChargeColorOriginal;

	private Color overrideBeamEffectColor;

	private float overrideBeamEffectStrength;

	private float overrideBeamEffectTimer;

	private bool overrideBeamEffectActive;

	[Header("Grab Disable")]
	public ParticleSystem grabDisableLoopParticle;

	public Light grabDisableLoopLight;

	public Transform grabDisableZapImpact;

	public Sound soundGrabDisableZap;

	public Sound soundGrabberOff;

	private List<ParticleSystem> grabDisableZapParticles = new List<ParticleSystem>();

	private float grabDisableLoopLightOriginalIntensity;

	private bool grabDisableLoopActive;

	private void Start()
	{
		//IL_0077: Unknown result type (might be due to invalid IL or missing references)
		//IL_007c: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c0: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c5: Unknown result type (might be due to invalid IL or missing references)
		//IL_016f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0174: Unknown result type (might be due to invalid IL or missing references)
		if (!Object.op_Implicit((Object)(object)PhysGrabPointOriginLocal))
		{
			PhysGrabPointOriginLocal = PhysGrabPointOrigin;
		}
		if (!playerAvatar.isLocal)
		{
			PhysGrabPointOrigin = PhysGrabPointOriginClient;
		}
		if (mirrorClient)
		{
			PhysGrabPointOrigin = PhysGrabPointOriginClient;
			int layer = LayerMask.NameToLayer("MirrorReflection");
			Transform[] componentsInChildren = ((Component)this).GetComponentsInChildren<Transform>(true);
			for (int i = 0; i < componentsInChildren.Length; i++)
			{
				((Component)componentsInChildren[i]).gameObject.layer = layer;
			}
		}
		originalScrollSpeed = scrollSpeed;
		originalMaterial = ((Renderer)lineRenderer).material;
		lineMaterial = ((Renderer)lineRenderer).material;
		lineMaterialOverCharge = ((Renderer)lineRendererOverCharge).material;
		overChargeColorOriginal = lineMaterialOverCharge.GetColor("_Color");
		overchargeParticles.AddRange(((Component)overchargeImpact).GetComponentsInChildren<ParticleSystem>());
		overchargeImpact.parent = ((Component)playerAvatar).transform.parent;
		((Renderer)lineRenderer).enabled = false;
		if (Object.op_Implicit((Object)(object)grabDisableZapImpact))
		{
			grabDisableZapParticles.AddRange(((Component)grabDisableZapImpact).GetComponentsInChildren<ParticleSystem>());
			grabDisableZapImpact.parent = ((Component)playerAvatar).transform.parent;
		}
		if (Object.op_Implicit((Object)(object)grabDisableLoopParticle))
		{
			((Component)grabDisableLoopParticle).transform.SetParent(PhysGrabPointOrigin, false);
			EmissionModule emission = grabDisableLoopParticle.emission;
			emission.enabled = false;
			if (grabDisableLoopParticle.isPlaying)
			{
				grabDisableLoopParticle.Stop(true, (ParticleSystemStopBehavior)1);
			}
		}
		if (Object.op_Implicit((Object)(object)grabDisableLoopLight))
		{
			((Component)grabDisableLoopLight).transform.SetParent(PhysGrabPointOrigin, false);
			grabDisableLoopLightOriginalIntensity = grabDisableLoopLight.intensity;
			if (grabDisableLoopLightOriginalIntensity <= 0f)
			{
				grabDisableLoopLightOriginalIntensity = 1f;
			}
			((Behaviour)grabDisableLoopLight).enabled = false;
		}
		grabDisableLoopActive = false;
	}

	private void LateUpdate()
	{
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0064: Unknown result type (might be due to invalid IL or missing references)
		//IL_0070: Unknown result type (might be due to invalid IL or missing references)
		//IL_0075: Unknown result type (might be due to invalid IL or missing references)
		if (mirrorClient && Object.op_Implicit((Object)(object)mirrorSource))
		{
			((Renderer)lineRenderer).enabled = ((Renderer)mirrorSource.lineRenderer).enabled;
			PhysGrabPoint = mirrorSource.PhysGrabPoint;
			PhysGrabPointPuller = mirrorSource.PhysGrabPointPuller;
			physGrabPointPullerSmoothPosition = mirrorSource.physGrabPointPullerSmoothPosition;
			overrideBeamEffectColor = mirrorSource.overrideBeamEffectColor;
			overrideBeamEffectStrength = mirrorSource.overrideBeamEffectStrength;
			overrideBeamEffectTimer = mirrorSource.overrideBeamEffectTimer;
			MirrorMaterialsSync();
		}
		if (!mirrorClient)
		{
			OverrideBeamEffectTick();
		}
		if (!((Renderer)lineRenderer).enabled)
		{
			if (((Renderer)lineRendererOverCharge).enabled)
			{
				((Renderer)lineRendererOverCharge).enabled = false;
			}
			return;
		}
		DrawCurve();
		if (!mirrorClient)
		{
			ScrollTexture();
		}
	}

	private void MirrorMaterialsSync()
	{
		if ((Object)(object)((Renderer)lineRenderer).sharedMaterial != (Object)(object)((Renderer)mirrorSource.lineRenderer).sharedMaterial)
		{
			((Renderer)lineRenderer).sharedMaterial = ((Renderer)mirrorSource.lineRenderer).sharedMaterial;
		}
		if ((Object)(object)((Renderer)lineRendererOverCharge).sharedMaterial != (Object)(object)((Renderer)mirrorSource.lineRendererOverCharge).sharedMaterial)
		{
			((Renderer)lineRendererOverCharge).sharedMaterial = ((Renderer)mirrorSource.lineRendererOverCharge).sharedMaterial;
		}
	}

	public void OverrideBeamEffect(Color _color, float _strength)
	{
		//IL_0001: Unknown result type (might be due to invalid IL or missing references)
		//IL_0002: Unknown result type (might be due to invalid IL or missing references)
		overrideBeamEffectColor = _color;
		overrideBeamEffectStrength = _strength;
		overrideBeamEffectTimer = 0.1f;
	}

	private void OverrideBeamEffectTick()
	{
		//IL_0021: Unknown result type (might be due to invalid IL or missing references)
		//IL_0070: Unknown result type (might be due to invalid IL or missing references)
		//IL_0052: Unknown result type (might be due to invalid IL or missing references)
		//IL_0058: Unknown result type (might be due to invalid IL or missing references)
		if (overrideBeamEffectTimer <= 0f && overrideBeamEffectActive)
		{
			lineMaterialOverCharge.SetColor("_Color", overChargeColorOriginal);
			overrideBeamEffectActive = false;
		}
		if (overrideBeamEffectTimer > 0f)
		{
			if (!overrideBeamEffectActive || lineMaterialOverCharge.GetColor("_Color") != overrideBeamEffectColor)
			{
				lineMaterialOverCharge.SetColor("_Color", overrideBeamEffectColor);
				overrideBeamEffectActive = true;
			}
			overrideBeamEffectTimer -= Time.deltaTime;
		}
	}

	private void PlayAllOverchargeParticles()
	{
		foreach (ParticleSystem overchargeParticle in overchargeParticles)
		{
			overchargeParticle.Play();
		}
	}

	public void GrabDisableLoopActive(bool _active)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_0029: Unknown result type (might be due to invalid IL or missing references)
		if (grabDisableLoopActive == _active)
		{
			return;
		}
		grabDisableLoopActive = _active;
		if (Object.op_Implicit((Object)(object)grabDisableLoopParticle))
		{
			EmissionModule emission = grabDisableLoopParticle.emission;
			emission.enabled = _active;
			if (_active && !grabDisableLoopParticle.isPlaying)
			{
				grabDisableLoopParticle.Play();
			}
			if (!_active)
			{
				grabDisableLoopParticle.Stop(true, (ParticleSystemStopBehavior)1);
			}
		}
		if (Object.op_Implicit((Object)(object)grabDisableLoopLight))
		{
			((Behaviour)grabDisableLoopLight).enabled = _active;
			if (_active)
			{
				grabDisableLoopLight.intensity = grabDisableLoopLightOriginalIntensity;
			}
		}
	}

	public void GrabDisableZap(Vector3 _position)
	{
		//IL_0052: Unknown result type (might be due to invalid IL or missing references)
		//IL_0073: Unknown result type (might be due to invalid IL or missing references)
		//IL_0013: Unknown result type (might be due to invalid IL or missing references)
		if (Object.op_Implicit((Object)(object)grabDisableZapImpact))
		{
			grabDisableZapImpact.position = _position;
			foreach (ParticleSystem grabDisableZapParticle in grabDisableZapParticles)
			{
				grabDisableZapParticle.Play();
			}
		}
		soundGrabDisableZap.Play(_position);
		soundGrabberOff.Play(_position);
	}

	private void OnEnable()
	{
		//IL_0007: Unknown result type (might be due to invalid IL or missing references)
		//IL_000c: Unknown result type (might be due to invalid IL or missing references)
		physGrabPointPullerSmoothPosition = PhysGrabPointPuller.position;
		if (Object.op_Implicit((Object)(object)VideoGreenScreen.instance))
		{
			lineMaterial = greenScreenMaterial;
			((Renderer)((Component)this).GetComponent<LineRenderer>()).material = greenScreenMaterial;
		}
	}

	private void OnDisable()
	{
		lineMaterial = originalMaterial;
		if (Object.op_Implicit((Object)(object)lineRenderer))
		{
			((Renderer)lineRenderer).material = originalMaterial;
		}
	}

	public void OverChargeLaunchPlayer()
	{
		//IL_004c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0051: Unknown result type (might be due to invalid IL or missing references)
		//IL_005b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0060: Unknown result type (might be due to invalid IL or missing references)
		//IL_0061: Unknown result type (might be due to invalid IL or missing references)
		//IL_0062: Unknown result type (might be due to invalid IL or missing references)
		//IL_006c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0071: Unknown result type (might be due to invalid IL or missing references)
		//IL_0076: Unknown result type (might be due to invalid IL or missing references)
		//IL_007d: Unknown result type (might be due to invalid IL or missing references)
		//IL_007e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0094: Unknown result type (might be due to invalid IL or missing references)
		//IL_0142: Unknown result type (might be due to invalid IL or missing references)
		//IL_00cb: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d1: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f1: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f6: Unknown result type (might be due to invalid IL or missing references)
		//IL_0100: Unknown result type (might be due to invalid IL or missing references)
		if (playerAvatar.isLocal)
		{
			CameraGlitch.Instance.PlayLong();
			PhysGrabber.instance.physGrabBeamOverChargeFloat = 0.5f;
			playerAvatar.physGrabber.ReleaseObject(-1);
		}
		Vector3 val = -playerAvatar.localCamera.GetOverrideTransform().forward * 0.14f;
		val += Vector3.up * 0.7f;
		overchargeImpact.rotation = Quaternion.LookRotation(val);
		overchargeImpact.position = PhysGrabPointOrigin.position;
		if (playerAvatar.isLocal)
		{
			playerAvatar.tumble.TumbleRequest(_isTumbling: true, _playerInput: false);
			playerAvatar.tumble.TumbleForce(val * 25f);
			playerAvatar.tumble.TumbleTorque(-((Component)playerAvatar).transform.forward * 45f);
			playerAvatar.tumble.TumbleOverrideTime(2.2f);
			playerAvatar.tumble.ImpactHurtSet(3f, 20);
		}
		soundOverchargeImpact.Play(overchargeImpact.position);
		PlayAllOverchargeParticles();
		curvePointsOverChargeOffsets = new Vector3[CurveResolution];
	}

	private void DrawCurve()
	{
		//IL_010c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0111: Unknown result type (might be due to invalid IL or missing references)
		//IL_0115: Unknown result type (might be due to invalid IL or missing references)
		//IL_011a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0127: Unknown result type (might be due to invalid IL or missing references)
		//IL_012c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0132: Unknown result type (might be due to invalid IL or missing references)
		//IL_013d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0142: Unknown result type (might be due to invalid IL or missing references)
		//IL_0289: Unknown result type (might be due to invalid IL or missing references)
		//IL_028e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0296: Unknown result type (might be due to invalid IL or missing references)
		//IL_029b: Unknown result type (might be due to invalid IL or missing references)
		//IL_02a0: Unknown result type (might be due to invalid IL or missing references)
		//IL_01fd: Unknown result type (might be due to invalid IL or missing references)
		//IL_0208: Unknown result type (might be due to invalid IL or missing references)
		//IL_020f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0214: Unknown result type (might be due to invalid IL or missing references)
		//IL_0219: Unknown result type (might be due to invalid IL or missing references)
		//IL_0237: Unknown result type (might be due to invalid IL or missing references)
		//IL_0241: Unknown result type (might be due to invalid IL or missing references)
		//IL_0246: Unknown result type (might be due to invalid IL or missing references)
		//IL_0248: Unknown result type (might be due to invalid IL or missing references)
		//IL_0257: Unknown result type (might be due to invalid IL or missing references)
		//IL_025c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0267: Unknown result type (might be due to invalid IL or missing references)
		//IL_026c: Unknown result type (might be due to invalid IL or missing references)
		//IL_026e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0273: Unknown result type (might be due to invalid IL or missing references)
		//IL_01a9: Unknown result type (might be due to invalid IL or missing references)
		//IL_01ae: Unknown result type (might be due to invalid IL or missing references)
		//IL_02b7: Unknown result type (might be due to invalid IL or missing references)
		//IL_02bc: Unknown result type (might be due to invalid IL or missing references)
		//IL_02d1: Unknown result type (might be due to invalid IL or missing references)
		//IL_02d6: Unknown result type (might be due to invalid IL or missing references)
		//IL_02e6: Unknown result type (might be due to invalid IL or missing references)
		//IL_02eb: Unknown result type (might be due to invalid IL or missing references)
		//IL_02fa: Unknown result type (might be due to invalid IL or missing references)
		//IL_0307: Unknown result type (might be due to invalid IL or missing references)
		//IL_030c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0311: Unknown result type (might be due to invalid IL or missing references)
		if (!Object.op_Implicit((Object)(object)PhysGrabPointPuller) || !Object.op_Implicit((Object)(object)PhysGrabPointOrigin) || !Object.op_Implicit((Object)(object)PhysGrabPoint))
		{
			return;
		}
		bool flag = false;
		float num = (float)(int)playerAvatar.physGrabber.physGrabBeamOverCharge / 2f;
		bool flag2 = num > 0.05f && Object.op_Implicit((Object)(object)playerAvatar.physGrabber.grabbedPhysGrabObject) && playerAvatar.physGrabber.grabbedPhysGrabObject.isEnemy;
		if (overrideBeamEffectTimer > 0f)
		{
			num = Mathf.Max(num, overrideBeamEffectStrength * 100f);
			flag2 = true;
		}
		if (!flag2)
		{
			if (((Renderer)lineRendererOverCharge).enabled)
			{
				((Renderer)lineRendererOverCharge).enabled = false;
			}
		}
		else
		{
			if (!((Renderer)lineRendererOverCharge).enabled)
			{
				((Renderer)lineRendererOverCharge).enabled = true;
			}
			flag = true;
			lineRendererOverCharge.widthMultiplier = 0.5f * (num / 100f);
		}
		Vector3[] array = new Vector3[CurveResolution];
		Vector3[] array2 = new Vector3[CurveResolution];
		Vector3 position = PhysGrabPointPuller.position;
		physGrabPointPullerSmoothPosition = Vector3.Lerp(physGrabPointPullerSmoothPosition, position, Time.deltaTime * 10f);
		Vector3 p = physGrabPointPullerSmoothPosition * CurveStrength;
		if (flag && SemiFunc.PerSecond(15f, (Object)(object)this))
		{
			float num2 = num / 100f;
			curvePointsOverChargeOffsets = new Vector3[CurveResolution];
			float num3 = 0.1f + 0.2f * num2;
			for (int i = 0; i < CurveResolution; i++)
			{
				curvePointsOverChargeOffsets[i] = new Vector3(Random.Range(0f - num3, num3), Random.Range(0f - num3, num3), Random.Range(0f - num3, num3));
			}
		}
		for (int j = 0; j < CurveResolution; j++)
		{
			float num4 = (float)j / ((float)CurveResolution - 1f);
			if (playerAvatar.physGrabber.grabState == PhysGrabber.GrabState.Climb)
			{
				array[j] = Vector3.Lerp(PhysGrabPointOrigin.position, PhysGrabPoint.position, num4);
				Vector3 val = Vector3.up * Mathf.Sin(Time.time * 10f + num4 * 4f) * 0.1f;
				val *= Mathf.Sin(num4 * MathF.PI);
				ref Vector3 reference = ref array[j];
				reference += val;
				continue;
			}
			array[j] = CalculateBezierPoint(num4, PhysGrabPointOrigin.position, p, PhysGrabPoint.position);
			if (flag && curvePointsOverChargeOffsets != null)
			{
				array2[j] = array[j];
				curvePointsOverChargeOffsets[j] = Vector3.Lerp(curvePointsOverChargeOffsets[j], Vector3.zero, Time.deltaTime * 30f);
				ref Vector3 reference2 = ref array2[j];
				reference2 += curvePointsOverChargeOffsets[j];
			}
		}
		lineRenderer.positionCount = CurveResolution;
		lineRenderer.SetPositions(array);
		if (flag)
		{
			lineRendererOverCharge.positionCount = CurveResolution;
			lineRendererOverCharge.SetPositions(array2);
		}
	}

	private Vector3 CalculateBezierPoint(float t, Vector3 p0, Vector3 p1, Vector3 p2)
	{
		//IL_0011: Unknown result type (might be due to invalid IL or missing references)
		//IL_0012: Unknown result type (might be due to invalid IL or missing references)
		//IL_0026: Unknown result type (might be due to invalid IL or missing references)
		//IL_0027: Unknown result type (might be due to invalid IL or missing references)
		//IL_002c: Unknown result type (might be due to invalid IL or missing references)
		//IL_003c: Unknown result type (might be due to invalid IL or missing references)
		//IL_003e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0043: Unknown result type (might be due to invalid IL or missing references)
		return Mathf.Pow(1f - t, 2f) * p0 + 2f * (1f - t) * t * p1 + Mathf.Pow(t, 2f) * p2;
	}

	private void ScrollTexture()
	{
		//IL_004c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0030: Unknown result type (might be due to invalid IL or missing references)
		//IL_005c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0061: Unknown result type (might be due to invalid IL or missing references)
		//IL_0066: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0086: Unknown result type (might be due to invalid IL or missing references)
		if (Object.op_Implicit((Object)(object)lineMaterial))
		{
			if (playerAvatar.physGrabber.colorState == 1)
			{
				lineMaterial.mainTextureScale = new Vector2(-1f, 1f);
			}
			else
			{
				lineMaterial.mainTextureScale = new Vector2(1f, 1f);
			}
			Vector2 mainTextureOffset = Time.time * scrollSpeed;
			lineMaterial.mainTextureOffset = mainTextureOffset;
			if (((Renderer)lineRendererOverCharge).enabled)
			{
				lineMaterialOverCharge.mainTextureOffset = mainTextureOffset;
			}
		}
	}

	public PhysGrabBeam()
	{
		//IL_001e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0023: Unknown result type (might be due to invalid IL or missing references)
	}
}
