using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class RoomVolumeCheck : MonoBehaviour
{
	public List<RoomVolume> CurrentRooms;

	public bool Continuous = true;

	internal float PauseCheckTimer;

	private LayerMask Mask;

	[Space]
	public bool DebugCheckPosition;

	public Vector3 CheckPosition = Vector3.one;

	public Vector3 currentSize = Vector3.one;

	internal bool inTruck;

	internal bool inTruckPrevious;

	internal bool inExtractionPoint;

	private bool checkActive;

	private bool wasInRoom;

	private PlayerAvatar player;

	private ValuableObject valuableObject;

	private bool gizmoIsCapsule;

	private Matrix4x4 gizmoBoxMatrix;

	private Vector3 gizmoCapsulePoint0;

	private Vector3 gizmoCapsulePoint1;

	private float gizmoCapsuleRadius;

	private void Awake()
	{
		//IL_002c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0031: Unknown result type (might be due to invalid IL or missing references)
		player = ((Component)this).GetComponentInParent<PlayerAvatar>();
		valuableObject = ((Component)this).GetComponent<ValuableObject>();
		Mask = LayerMask.op_Implicit(LayerMask.GetMask(new string[1] { "RoomVolume" }));
		CheckStart();
	}

	private void OnEnable()
	{
		CheckStart();
	}

	private void OnDisable()
	{
		checkActive = false;
		((MonoBehaviour)this).StopAllCoroutines();
	}

	public void CheckSet()
	{
		//IL_006a: Unknown result type (might be due to invalid IL or missing references)
		//IL_006f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0071: Unknown result type (might be due to invalid IL or missing references)
		//IL_0073: Unknown result type (might be due to invalid IL or missing references)
		//IL_0092: Unknown result type (might be due to invalid IL or missing references)
		//IL_009d: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a8: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ad: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b2: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b4: Unknown result type (might be due to invalid IL or missing references)
		//IL_00bb: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c0: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c8: Unknown result type (might be due to invalid IL or missing references)
		//IL_00cd: Unknown result type (might be due to invalid IL or missing references)
		//IL_00cf: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d1: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d6: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ee: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f0: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f2: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f9: Unknown result type (might be due to invalid IL or missing references)
		//IL_00fe: Unknown result type (might be due to invalid IL or missing references)
		//IL_0103: Unknown result type (might be due to invalid IL or missing references)
		//IL_0085: Unknown result type (might be due to invalid IL or missing references)
		//IL_008a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0034: Unknown result type (might be due to invalid IL or missing references)
		//IL_0035: Unknown result type (might be due to invalid IL or missing references)
		//IL_0038: Unknown result type (might be due to invalid IL or missing references)
		//IL_0050: Unknown result type (might be due to invalid IL or missing references)
		//IL_0051: Unknown result type (might be due to invalid IL or missing references)
		//IL_0057: Unknown result type (might be due to invalid IL or missing references)
		//IL_0058: Unknown result type (might be due to invalid IL or missing references)
		//IL_02e0: Unknown result type (might be due to invalid IL or missing references)
		//IL_0349: Unknown result type (might be due to invalid IL or missing references)
		//IL_034e: Unknown result type (might be due to invalid IL or missing references)
		//IL_025a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0269: Unknown result type (might be due to invalid IL or missing references)
		inTruck = false;
		inExtractionPoint = false;
		CurrentRooms.Clear();
		Collider[] array;
		if (Object.op_Implicit((Object)(object)player) && TryGetPlayerCapsule(out var point, out var point2, out var radius))
		{
			array = Physics.OverlapCapsule(point, point2, radius, LayerMask.op_Implicit(Mask));
			gizmoIsCapsule = true;
			gizmoCapsulePoint0 = point;
			gizmoCapsulePoint1 = point2;
			gizmoCapsuleRadius = radius;
		}
		else
		{
			Vector3 localScale = currentSize;
			if (localScale == Vector3.zero)
			{
				localScale = ((Component)this).transform.localScale;
			}
			Vector3 val = ((Component)this).transform.position + ((Component)this).transform.rotation * CheckPosition;
			Vector3 val2 = localScale / 2f;
			Quaternion rotation = ((Component)this).transform.rotation;
			array = Physics.OverlapBox(val, val2, rotation, LayerMask.op_Implicit(Mask));
			gizmoIsCapsule = false;
			gizmoBoxMatrix = Matrix4x4.TRS(val, rotation, val2 * 2f);
		}
		Collider[] array2 = array;
		foreach (Collider val3 in array2)
		{
			RoomVolume roomVolume = ((Component)((Component)val3).transform).GetComponent<RoomVolume>();
			if (!Object.op_Implicit((Object)(object)roomVolume))
			{
				roomVolume = ((Component)((Component)val3).transform).GetComponentInParent<RoomVolume>();
			}
			if (!CurrentRooms.Contains(roomVolume))
			{
				CurrentRooms.Add(roomVolume);
			}
			if (roomVolume.Truck)
			{
				inTruck = true;
			}
			if (roomVolume.Extraction)
			{
				inExtractionPoint = true;
			}
		}
		if (Object.op_Implicit((Object)(object)player))
		{
			if (CurrentRooms.Count > 0)
			{
				bool flag = true;
				MapModule mapModule = CurrentRooms[0].MapModule;
				foreach (RoomVolume currentRoom in CurrentRooms)
				{
					if ((Object)(object)mapModule != (Object)(object)currentRoom.MapModule)
					{
						flag = false;
						break;
					}
				}
				if (flag && CurrentRooms[0].SetExplored() && Object.op_Implicit((Object)(object)player) && player.isLocal && Object.op_Implicit((Object)(object)TruckSafetySpawnPoint.instance))
				{
					float num = Vector3.Distance(player.playerTransform.position, ((Component)TruckSafetySpawnPoint.instance).transform.position) / 20f;
					ProgressionManager.instance.roundPointsScouting += 100f * num;
				}
			}
			else if (Debug.isDebugBuild && wasInRoom && Object.op_Implicit((Object)(object)player) && player.isLocal)
			{
				string text = "Player: Not in RoomVolume: ";
				if (SemiFunc.GetModuleAtPosition(player.playerTransform.position, out var module, out var localPosition))
				{
					text = text + "\n     Module Name: " + ((module != null) ? ((Object)module).name : null);
					text = text + "\n     Local Position: " + ((object)localPosition/*cast due to constrained. prefix*/).ToString();
				}
				else
				{
					text += "\n     Module Name: N/A";
					text = text + "\n     Position: " + ((object)player.playerTransform.position/*cast due to constrained. prefix*/).ToString();
				}
				Debug.LogError((object)(text + "\n"), (Object)(object)(((module != null) ? ((Component)module).gameObject : null) ?? ((Component)this).gameObject));
			}
		}
		wasInRoom = CurrentRooms.Count > 0;
		TutorialExtractionReminderLogic();
	}

	private bool TryGetPlayerCapsule(out Vector3 point0, out Vector3 point1, out float radius)
	{
		//IL_0001: Unknown result type (might be due to invalid IL or missing references)
		//IL_0008: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c6: Unknown result type (might be due to invalid IL or missing references)
		point0 = default;
		point1 = default;
		radius = 0f;
		CapsuleCollider val = null;
		if (player.isTumbling && Object.op_Implicit((Object)(object)player.tumble))
		{
			Collider[] colliders = player.tumble.colliders;
			foreach (Collider obj in colliders)
			{
				CapsuleCollider val2 = (CapsuleCollider)(object)((obj is CapsuleCollider) ? obj : null);
				if (val2 != null)
				{
					val = val2;
					break;
				}
			}
		}
		else if (player.isLocal && Object.op_Implicit((Object)(object)PlayerController.instance))
		{
			Collider col = PlayerController.instance.col;
			val = (CapsuleCollider)(object)((col is CapsuleCollider) ? col : null);
		}
		else if (Object.op_Implicit((Object)(object)player.playerAvatarCollision))
		{
			val = player.playerAvatarCollision.Collider;
		}
		if (!Object.op_Implicit((Object)(object)val))
		{
			return false;
		}
		SemiFunc.CapsuleColliderGetWorldPoints(val, ((Component)val).transform.position, out point0, out point1, out radius);
		return true;
	}

	private IEnumerator Check()
	{
		while (!LevelGenerator.Instance.Generated)
		{
			yield return (object)new WaitForSeconds(0.1f);
		}
		yield return (object)new WaitForSeconds(0.5f);
		while (true)
		{
			if (PauseCheckTimer > 0f)
			{
				PauseCheckTimer -= 0.5f;
				yield return (object)new WaitForSeconds(0.5f);
				continue;
			}
			CheckSet();
			if (Continuous)
			{
				if (Object.op_Implicit((Object)(object)player))
				{
					yield return (object)new WaitForSeconds(0.1f);
				}
				else
				{
					yield return (object)new WaitForSeconds(0.5f);
				}
				continue;
			}
			break;
		}
	}

	private void CheckStart()
	{
		if (!checkActive)
		{
			checkActive = true;
			((MonoBehaviour)this).StartCoroutine(Check());
		}
	}

	private void TutorialExtractionReminderLogic()
	{
		if (inTruckPrevious != inTruck)
		{
			inTruckPrevious = inTruck;
			if (inTruck && TutorialDirector.instance.extractionReminderActive && Object.op_Implicit((Object)(object)valuableObject))
			{
				TutorialDirector.instance.ExtractionReminderValuable(valuableObject);
			}
		}
	}

	private void OnDrawGizmosSelected()
	{
		//IL_001d: Unknown result type (might be due to invalid IL or missing references)
		//IL_002f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0034: Unknown result type (might be due to invalid IL or missing references)
		//IL_0035: Unknown result type (might be due to invalid IL or missing references)
		//IL_0036: Unknown result type (might be due to invalid IL or missing references)
		//IL_01d1: Unknown result type (might be due to invalid IL or missing references)
		//IL_01db: Unknown result type (might be due to invalid IL or missing references)
		//IL_01e0: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b7: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c2: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e4: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e9: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f4: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f9: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ff: Unknown result type (might be due to invalid IL or missing references)
		//IL_0104: Unknown result type (might be due to invalid IL or missing references)
		//IL_010f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0114: Unknown result type (might be due to invalid IL or missing references)
		//IL_011f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0124: Unknown result type (might be due to invalid IL or missing references)
		//IL_012f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0134: Unknown result type (might be due to invalid IL or missing references)
		//IL_013a: Unknown result type (might be due to invalid IL or missing references)
		//IL_013f: Unknown result type (might be due to invalid IL or missing references)
		//IL_014a: Unknown result type (might be due to invalid IL or missing references)
		//IL_014f: Unknown result type (might be due to invalid IL or missing references)
		//IL_015a: Unknown result type (might be due to invalid IL or missing references)
		//IL_015f: Unknown result type (might be due to invalid IL or missing references)
		//IL_016a: Unknown result type (might be due to invalid IL or missing references)
		//IL_016f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0175: Unknown result type (might be due to invalid IL or missing references)
		//IL_017a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0185: Unknown result type (might be due to invalid IL or missing references)
		//IL_018a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0195: Unknown result type (might be due to invalid IL or missing references)
		//IL_019a: Unknown result type (might be due to invalid IL or missing references)
		//IL_01a5: Unknown result type (might be due to invalid IL or missing references)
		//IL_01aa: Unknown result type (might be due to invalid IL or missing references)
		//IL_01b0: Unknown result type (might be due to invalid IL or missing references)
		//IL_01b5: Unknown result type (might be due to invalid IL or missing references)
		//IL_01c0: Unknown result type (might be due to invalid IL or missing references)
		//IL_01c5: Unknown result type (might be due to invalid IL or missing references)
		//IL_0054: Unknown result type (might be due to invalid IL or missing references)
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0065: Unknown result type (might be due to invalid IL or missing references)
		//IL_006a: Unknown result type (might be due to invalid IL or missing references)
		//IL_006f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0074: Unknown result type (might be due to invalid IL or missing references)
		//IL_0075: Unknown result type (might be due to invalid IL or missing references)
		//IL_007b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0080: Unknown result type (might be due to invalid IL or missing references)
		//IL_0087: Unknown result type (might be due to invalid IL or missing references)
		//IL_008c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0095: Unknown result type (might be due to invalid IL or missing references)
		//IL_0096: Unknown result type (might be due to invalid IL or missing references)
		//IL_0097: Unknown result type (might be due to invalid IL or missing references)
		//IL_009d: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a2: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a7: Unknown result type (might be due to invalid IL or missing references)
		//IL_0048: Unknown result type (might be due to invalid IL or missing references)
		//IL_004d: Unknown result type (might be due to invalid IL or missing references)
		if (!DebugCheckPosition)
		{
			return;
		}
		Gizmos.color = new Color(1f, 0f, 0.79f, 1f);
		if (!Application.isPlaying)
		{
			Vector3 localScale = currentSize;
			if (localScale == Vector3.zero)
			{
				localScale = ((Component)this).transform.localScale;
			}
			Vector3 val = ((Component)this).transform.position + ((Component)this).transform.rotation * CheckPosition;
			Vector3 val2 = localScale / 2f;
			Quaternion rotation = ((Component)this).transform.rotation;
			gizmoIsCapsule = false;
			gizmoBoxMatrix = Matrix4x4.TRS(val, rotation, val2 * 2f);
		}
		if (gizmoIsCapsule)
		{
			Gizmos.matrix = Matrix4x4.identity;
			Gizmos.DrawWireSphere(gizmoCapsulePoint0, gizmoCapsuleRadius);
			Gizmos.DrawWireSphere(gizmoCapsulePoint1, gizmoCapsuleRadius);
			Gizmos.DrawLine(gizmoCapsulePoint0 + Vector3.forward * gizmoCapsuleRadius, gizmoCapsulePoint1 + Vector3.forward * gizmoCapsuleRadius);
			Gizmos.DrawLine(gizmoCapsulePoint0 - Vector3.forward * gizmoCapsuleRadius, gizmoCapsulePoint1 - Vector3.forward * gizmoCapsuleRadius);
			Gizmos.DrawLine(gizmoCapsulePoint0 + Vector3.right * gizmoCapsuleRadius, gizmoCapsulePoint1 + Vector3.right * gizmoCapsuleRadius);
			Gizmos.DrawLine(gizmoCapsulePoint0 - Vector3.right * gizmoCapsuleRadius, gizmoCapsulePoint1 - Vector3.right * gizmoCapsuleRadius);
		}
		else
		{
			Gizmos.matrix = gizmoBoxMatrix;
			Gizmos.DrawWireCube(Vector3.zero, Vector3.one);
		}
	}

	public RoomVolumeCheck()
	{
		//IL_0008: Unknown result type (might be due to invalid IL or missing references)
		//IL_000d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0013: Unknown result type (might be due to invalid IL or missing references)
		//IL_0018: Unknown result type (might be due to invalid IL or missing references)
	}
}
