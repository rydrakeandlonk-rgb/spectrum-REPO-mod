using UnityEngine;

[CreateAssetMenu(fileName = "Room Ambient Light - _____", menuName = "Level/Room Ambient Light", order = 0)]
public class RoomAmbientLight : ScriptableObject
{
	public Level importSettingsFromLevel;

	[Space]
	public bool shopActivateFlashlight;

	[Space]
	public Color color;

	public Color colorAdaptation;

	public void OnValidate()
	{
		//IL_001d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0022: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0033: Unknown result type (might be due to invalid IL or missing references)
		if (!SemiFunc.OnValidateCheck() && (Object)(object)importSettingsFromLevel != (Object)null)
		{
			color = importSettingsFromLevel.AmbientColor;
			colorAdaptation = importSettingsFromLevel.AmbientColorAdaptation;
			importSettingsFromLevel = null;
		}
	}
}
