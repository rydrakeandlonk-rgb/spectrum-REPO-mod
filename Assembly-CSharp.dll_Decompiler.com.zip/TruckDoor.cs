using System.Collections;
using UnityEngine;

public class TruckDoor : MonoBehaviour
{
	public Sound doorLoopStart;

	public Sound doorLoopEnd;

	public Sound doorSound;

	private float startYPosition;

	private bool fullyOpen;

	private float doorEval;

	public AnimationCurve doorCurve;

	public LocalizedAsset localizedFocusShopIntro;

	public Transform doorMesh;

	private float doorDelay = 2f;

	private bool doorOpen;

	private ExtractionPoint extractionPointNearest;

	private float playerInTruckCheckTimer;

	private bool timeToCheck;

	private bool introActivationDone;

	private void Start()
	{
		//IL_0012: Unknown result type (might be due to invalid IL or missing references)
		playerInTruckCheckTimer = 2f;
		startYPosition = ((Component)this).transform.position.y;
		((MonoBehaviour)this).StartCoroutine(DelayedStart());
		LocalizationManager.instance.AddLocalizationChangedCallback(ShowShopFocusText);
	}

	private void OnDestroy()
	{
		LocalizationManager.instance.RemoveLocalizationChangedCallback(ShowShopFocusText);
	}

	private IEnumerator DelayedStart()
	{
		while (!SemiFunc.LevelGenDone())
		{
			yield return (object)new WaitForSeconds(0.3f);
		}
		while (!Object.op_Implicit((Object)(object)extractionPointNearest))
		{
			yield return (object)new WaitForSeconds(0.1f);
			extractionPointNearest = SemiFunc.ExtractionPointGetNearest(((Component)this).transform.position);
		}
		timeToCheck = true;
	}

	private void Update()
	{
		//IL_01be: Unknown result type (might be due to invalid IL or missing references)
		//IL_01d9: Unknown result type (might be due to invalid IL or missing references)
		//IL_0204: Unknown result type (might be due to invalid IL or missing references)
		//IL_014b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0169: Unknown result type (might be due to invalid IL or missing references)
		//IL_0173: Unknown result type (might be due to invalid IL or missing references)
		//IL_00db: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f6: Unknown result type (might be due to invalid IL or missing references)
		if (timeToCheck)
		{
			if (playerInTruckCheckTimer > 0f)
			{
				playerInTruckCheckTimer -= Time.deltaTime;
			}
			else
			{
				playerInTruckCheckTimer = 0.5f;
				if (!introActivationDone && !SemiFunc.PlayersAllInTruck())
				{
					introActivationDone = true;
					if (!TutorialDirector.instance.tutorialActive)
					{
						extractionPointNearest.ActivateTheFirstExtractionPointAutomaticallyWhenAPlayerLeaveTruck();
					}
				}
			}
		}
		if (doorDelay > 0f && SemiFunc.LevelGenDone())
		{
			doorDelay -= Time.deltaTime;
		}
		if (doorDelay <= 0f && doorEval < 1f)
		{
			if (!doorOpen)
			{
				doorOpen = true;
				ShowShopFocusText();
				GameDirector.instance.CameraImpact.ShakeDistance(3f, 3f, 8f, ((Component)this).transform.position, 0.1f);
				doorLoopStart.Play(((Component)this).transform.position);
			}
			float num = doorCurve.Evaluate(doorEval);
			doorEval += 1.5f * Time.deltaTime;
			((Component)this).transform.position = new Vector3(((Component)this).transform.position.x, startYPosition + 2.5f * num, ((Component)this).transform.position.z);
		}
		if (doorEval >= 1f && !fullyOpen)
		{
			fullyOpen = true;
			GameDirector.instance.CameraImpact.ShakeDistance(5f, 3f, 8f, ((Component)this).transform.position, 0.1f);
			doorLoopEnd.Play(((Component)this).transform.position);
			doorSound.Play(((Component)this).transform.position);
		}
	}

	private void ShowShopFocusText()
	{
		//IL_0023: Unknown result type (might be due to invalid IL or missing references)
		//IL_002d: Unknown result type (might be due to invalid IL or missing references)
		if (SemiFunc.RunIsShop())
		{
			SemiFunc.UIFocusText(localizedFocusShopIntro?.GetLocalizedString() ?? "Buy stuff in the shop", Color.white, AssetManager.instance.colorYellow);
		}
	}
}
