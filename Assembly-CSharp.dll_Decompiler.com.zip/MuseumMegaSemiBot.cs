using System;
using System.Collections.Generic;
using Photon.Pun;
using Strobotnik.Klattersynth;
using UnityEngine;
using UnityEngine.Audio;

public class MuseumMegaSemiBot : MonoBehaviour
{
	public enum State
	{
		Dormant,
		WakeUp,
		GreenLightStart,
		GreenLight,
		GreenLightEnding,
		RedLight,
		GrabStart,
		GrabPullIn,
		GrabGotoLaunchPose,
		GrabLaunch,
		RedLightToGreenLight,
		Shutdown
	}

	[Serializable]
	public class MegaBotPosePart
	{
		public string partName;

		public Transform bone;

		[Range(0f, 1f)]
		public float pitchWeight;

		[Range(0f, 1f)]
		public float yawWeight;

		public float noiseMaxDegrees = 3f;

		internal Quaternion startRotation;

		internal Quaternion targetRotation;

		internal float delayTimer;

		internal float duration = 0.2f;

		internal float progress = 1f;

		internal bool started;

		internal bool playsEndSound;
	}

	public class MegaBotMoveTracker
	{
		public PhysGrabObject physObject;

		public PlayerAvatar player;

		public EnemyParent enemyParent;

		public float movedTime;

		public float moveWindowTimer;

		public Vector3 lastPosition;

		public Quaternion lastRotation;

		public bool lastTumbling;

		public bool lastCrouching;

		public bool lastCrawling;
	}

	public class MegaBotSparkJoint
	{
		public Transform joint;

		public Quaternion previousLocalRotation;
	}

	public class MegaBotArmPose
	{
		public Quaternion startRotation = Quaternion.identity;

		public Quaternion poseCurrent = Quaternion.identity;

		public Quaternion poseOld = Quaternion.identity;

		public Quaternion poseNew = Quaternion.identity;

		public float lerp = 1f;

		public float duration = 0.2f;

		public MegaBotArmPose()
		{
			//IL_0001: Unknown result type (might be due to invalid IL or missing references)
			//IL_0006: Unknown result type (might be due to invalid IL or missing references)
			//IL_000c: Unknown result type (might be due to invalid IL or missing references)
			//IL_0011: Unknown result type (might be due to invalid IL or missing references)
			//IL_0017: Unknown result type (might be due to invalid IL or missing references)
			//IL_001c: Unknown result type (might be due to invalid IL or missing references)
			//IL_0022: Unknown result type (might be due to invalid IL or missing references)
			//IL_0027: Unknown result type (might be due to invalid IL or missing references)
		}
	}

	public class MegaBotEye
	{
		public Transform bone;

		public Quaternion animFrom = Quaternion.identity;

		public Quaternion animTo = Quaternion.identity;

		public float animLerp = 1f;

		public float animDuration = 0.2f;

		public float cooldownTimer;

		public bool endSoundPlayed = true;

		public MegaBotEye()
		{
			//IL_0001: Unknown result type (might be due to invalid IL or missing references)
			//IL_0006: Unknown result type (might be due to invalid IL or missing references)
			//IL_000c: Unknown result type (might be due to invalid IL or missing references)
			//IL_0011: Unknown result type (might be due to invalid IL or missing references)
		}
	}

	public class MegaBotShakeCenter
	{
		public Transform transform;

		public SpringVector3 spring = new SpringVector3();

		public Vector3 baseLocalPosition;

		public Vector3 previousPosition;

		public Vector3 fakeVelocity;

		public SpringVector3 rotationSpring = new SpringVector3();

		public Quaternion baseLocalRotation;

		public Quaternion previousParentRotation;

		public Vector3 fakeAngularVelocity;

		public bool nested;

		public float vibrationSeed;
	}

	[Serializable]
	public class MegaBotFoliageSwaySettings
	{
		public SpringVector3 springSettings = new SpringVector3
		{
			speed = 8f,
			damping = 0.2f
		};

		public float velocityInfluence = 0.05f;

		public float rotationMax = 30f;

		public float eventScale = 10f;

		public float turbulenceAmount = 300f;

		public float turbulenceFrequency = 2f;

		public float turbulenceSpeedMax = 2.5f;

		public float turbulenceResponse = 4f;

		public static MegaBotFoliageSwaySettings SmallDefaults()
		{
			return new MegaBotFoliageSwaySettings
			{
				springSettings = new SpringVector3
				{
					speed = 10f,
					damping = 0.12f
				},
				velocityInfluence = 0.06f,
				rotationMax = 35f,
				eventScale = 14f,
				turbulenceAmount = 500f,
				turbulenceFrequency = 3f,
				turbulenceSpeedMax = 2f,
				turbulenceResponse = 5f
			};
		}

		public static MegaBotFoliageSwaySettings MediumDefaults()
		{
			return new MegaBotFoliageSwaySettings
			{
				springSettings = new SpringVector3
				{
					speed = 7f,
					damping = 0.18f
				},
				velocityInfluence = 0.045f,
				rotationMax = 25f,
				eventScale = 10f,
				turbulenceAmount = 300f,
				turbulenceFrequency = 2f,
				turbulenceSpeedMax = 2.5f,
				turbulenceResponse = 4f
			};
		}

		public static MegaBotFoliageSwaySettings RigidDefaults()
		{
			return new MegaBotFoliageSwaySettings
			{
				springSettings = new SpringVector3
				{
					speed = 18f,
					damping = 0.1f
				},
				velocityInfluence = 0.02f,
				rotationMax = 10f,
				eventScale = 5f,
				turbulenceAmount = 120f,
				turbulenceFrequency = 4f,
				turbulenceSpeedMax = 3.5f,
				turbulenceResponse = 6f
			};
		}
	}

	public class MegaBotFoliageSwayPart
	{
		public Transform transform;

		public MegaBotFoliageSwaySettings settings;

		public Quaternion baseLocalRotation;

		public Vector3 tipLocalPosition;

		public Vector3 previousTipPosition;

		public Vector3 fakeTipVelocity;

		public float turbulenceStrength;

		public SpringVector3 rotationSpring = new SpringVector3();
	}

	private enum PlatformMoveState
	{
		Idle,
		Ramp,
		Rotate,
		Settle
	}

	public State currentState;

	private bool stateStart = true;

	private float stateTimer;

	private float stateTimerMax = 1f;

	private PhotonView photonView;

	public List<Transform> activationBoxes = new List<Transform>();

	public Transform eyeVisionTransform;

	public float targetRange = 25f;

	public float recentActivityGraceTime = 3f;

	private float recentActivityTimer;

	private List<RoomVolume> botRoomVolumes = new List<RoomVolume>();

	private bool botRoomVolumesWarned;

	private LayerMask roomVolumeMask;

	public float greenLightDurationMin = 1f;

	public float greenLightDurationMax = 6f;

	public float redLightDurationMin = 1f;

	public float redLightDurationMax = 6f;

	public float poseLockMin = 0.5f;

	public float poseLockMax = 2f;

	public List<MegaBotPosePart> poseParts = new List<MegaBotPosePart>();

	public AnimationCurve poseCurve = AnimationCurve.EaseInOut(0f, 0f, 1f, 1f);

	public float poseDurationMin = 0.15f;

	public float poseDurationMax = 0.25f;

	public float posePartDelayMax = 0.1f;

	public float posePitchClamp = 60f;

	public float dormantNeckPitch = 35f;

	public float redLightNeckPitch = 25f;

	private float poseLockTimer;

	private bool poseStartSoundPlayed = true;

	private bool poseEndSoundPlayed = true;

	private float poseMovingLoopTimer;

	public Transform platformTransform;

	public float platformRotateSpeed = 90f;

	public AnimationCurve platformStartCurve = AnimationCurve.EaseInOut(0f, 0f, 1f, 1f);

	public AnimationCurve platformSettleCurve = AnimationCurve.EaseInOut(0f, 1f, 1f, 0f);

	public float platformRampDurationMin = 0.15f;

	public float platformRampDurationMax = 0.25f;

	public float platformSettleWobbleDegrees = 1.5f;

	public float platformGreenSpinSpeed = 45f;

	public float platformRedSpinSpeed = 90f;

	public float platformYawSyncSnapAngle = 2f;

	public float platformYawSyncCorrectSpeed = 90f;

	public float platformYawSyncCatchUpMultiplier = 8f;

	private PlatformMoveState platformMoveState;

	private float platformYawCurrent;

	private float platformYawTarget;

	private float platformRampTimer;

	private float platformRampDuration = 0.2f;

	private float platformSettleTimer;

	private float platformSettleDuration = 0.2f;

	private float platformLoopTimer;

	private float platformSpinTimer;

	private float platformYawSyncOffset;

	private float platformSpinDirection = 1f;

	private float platformSpinSpeedCurrent = 45f;

	private bool platformSpinActive;

	private float greenSpinDirection = 1f;

	public Renderer eyeLeftRenderer;

	public Renderer eyeRightRenderer;

	public Light eyeLight;

	public Color eyeColorGreen = Color.green;

	public Color eyeColorYellow = Color.yellow;

	public Color eyeColorRed = Color.red;

	public float eyeEmissionIntensity = 2f;

	public float eyeLightIntensityMax = 3f;

	public Color eyeColorOff = new Color(1f, 0.25f, 0f);

	public float eyeOffGlow = 0.06f;

	public float eyeOffFire = 0.25f;

	public SpringFloat eyeIrisSpring = new SpringFloat
	{
		speed = 14f,
		damping = 0.35f
	};

	public float eyeIrisScaleGreen = 1f;

	public float eyeIrisScaleYellow = 0.75f;

	public float eyeIrisScaleRed = 0.45f;

	public float eyeCountdownIrisPunch = 0.3f;

	public float eyeFireScaleGreen = 0.25f;

	public float eyeFireScaleYellow = 1f;

	public float eyeFireScaleRed = 3f;

	public float eyeFireLerpSpeed = 4f;

	public AnimationCurve eyeFlickerOnCurve = AnimationCurve.EaseInOut(0f, 0f, 1f, 1f);

	public AnimationCurve eyeFlickerOffCurve = AnimationCurve.EaseInOut(0f, 0f, 1f, 1f);

	public float eyeFlickerDuration = 0.4f;

	public float eyeFlickerSoundFrequency = 60f;

	public AnimationCurve eyeFlickerSoundCurve = AnimationCurve.EaseInOut(0f, 1f, 1f, 0f);

	public AnimationCurve eyeCountdownPulseCurve = AnimationCurve.EaseInOut(0f, 1f, 1f, 0f);

	public float eyeCountdownPulseAmount = 1.5f;

	public float eyeCountdownPulseDuration = 0.35f;

	private static readonly int eyeColorID = Shader.PropertyToID("_EyeColor");

	private static readonly int irisGlowID = Shader.PropertyToID("_IrisGlow");

	private static readonly int apertureSizeID = Shader.PropertyToID("_ApertureSize");

	private static readonly int fireIntensityID = Shader.PropertyToID("_FireIntensity");

	private static readonly int grimeShiftID = Shader.PropertyToID("_GrimeShift");

	private static readonly int fireColorID = Shader.PropertyToID("_FireColor");

	private static readonly int tubeColorID = Shader.PropertyToID("_TubeColor");

	public int foliageBakeResolution = 1024;

	public float foliageWindWorldScale = 0.35f;

	public MegaBotFoliageSwaySettings foliageSwaySmall = MegaBotFoliageSwaySettings.SmallDefaults();

	public MegaBotFoliageSwaySettings foliageSwayMedium = MegaBotFoliageSwaySettings.MediumDefaults();

	public MegaBotFoliageSwaySettings foliageSwayRigid = MegaBotFoliageSwaySettings.RigidDefaults();

	private List<MegaBotFoliageSwayPart> foliageSwayParts = new List<MegaBotFoliageSwayPart>();

	private static readonly int foliageMatrixID = Shader.PropertyToID("_MegaBotFoliageMatrix");

	private static readonly int foliageBakedMaskID = Shader.PropertyToID("_FoliageBakedMask");

	private MegaSemibotFoliageSphere[] foliageSpheres = new MegaSemibotFoliageSphere[0];

	private Transform foliageAnchor;

	private bool hasFoliage;

	private List<Material> eyeMaterials = new List<Material>();

	private Color eyeColorCurrent;

	private float eyeIrisSizeBase = 0.55f;

	private float eyeFireIntensityBase = 2f;

	private Color eyeFireColorBase = new Color(1f, 0.35f, 0.05f);

	private Color eyeFireColorCurrent;

	private Color eyeFireColorTarget;

	private Color eyeTubeColorBase = new Color(0.02f, 0.02f, 0.02f);

	private Color eyeTubeColorCurrent;

	private Color eyeTubeColorTarget;

	private Color eyeAppliedTubeColor;

	private Color eyeAppliedColor;

	private Color eyeAppliedFireColor;

	private float eyeAppliedGlow = -1f;

	private float eyeAppliedIrisSize;

	private float eyeAppliedFireIntensity;

	private float eyeAppliedMultiplier;

	private float eyeIrisScaleCurrent = 1f;

	private float eyeFireScaleCurrent = 1f;

	private float eyeFireCurrent;

	private bool eyesOn;

	private float eyeFlickerOnTimer = -1f;

	private float eyeFlickerOffTimer = -1f;

	private float eyeFlickerSoundTimer;

	private float eyeCountdownPulseTimer = -1f;

	public Transform eyeLeftTransform;

	public Transform eyeRightTransform;

	public float eyeConeClamp = 50f;

	public float eyePitchClamp = 30f;

	public float eyeYawClamp = 30f;

	public float eyeRetargetAngle = 8f;

	public float eyeNoiseDegrees = 2f;

	public float eyeFrequencyMultiplier = 3f;

	private List<MegaBotEye> lookEyes = new List<MegaBotEye>();

	private Vector3 lookTargetPosition;

	private bool lookTargetActive;

	public Transform jawTopTransform;

	public Transform jawBottomTransform;

	public float mouthOpenAngleMax = 25f;

	public float mouthRetargetAmount = 0.15f;

	private Quaternion jawTopStartRotation;

	public Speech ttsSpeech;

	public int ttsVoiceFrequency = 100;

	public float ttsMouthLoudnessMultiplier = 4f;

	public float ttsGreenIntervalMin = 2.5f;

	public float ttsGreenIntervalMax = 5f;

	public float ttsRedIntervalMin = 1.5f;

	public float ttsRedIntervalMax = 3f;

	public List<string> ttsPhrasesGreen = new List<string> { "moving allowed", "dance", "run", "move your body", "keep moving", "faster", "twirl", "go go go", "entertain me", "wiggle" };

	public List<string> ttsPhrasesRed = new List<string> { "stop", "no moving", "freeze", "stand still", "do not move", "not one step", "stay" };

	private float ttsPhraseTimer;

	private bool hasTTS;

	private AudioSource ttsAudioSource;

	private float[] ttsAudioSpectrum = new float[1024];

	private float ttsTalkOpenTarget;

	private float mouthMoveTimer;

	private float mouthMoveIntensity;

	private float mouthAnimFrom;

	private float mouthAnimTo;

	private float mouthAnimLerp = 1f;

	private float mouthAnimDuration = 0.2f;

	private float mouthCooldownTimer;

	private bool mouthEndSoundPlayed = true;

	public Transform grabberAimTransform;

	public Transform grabberHoldTransform;

	public Transform grabberBeamOriginTransform;

	public Transform grabberClawRootTransform;

	public float grabberSpinSpeed = 360f;

	public Transform armAimTransform;

	public Transform armPoseTransform;

	public Vector3 armGrabPoseEuler = new Vector3(-70f, 0f, 0f);

	public Vector3 armAimOffsetEuler;

	public SpringFloat armReachSpring = new SpringFloat
	{
		speed = 15f,
		damping = 0.4f
	};

	public float armReachStretch = 0.25f;

	public ParticleSystem particlesGrabBuildUp;

	public float grabberAlignedAngle = 15f;

	public float grabBuildUpForceStartTime = 1.5f;

	public float grabBuildUpDuration = 0.5f;

	public float grabFaceAngle = 15f;

	public float grabFaceForceTime = 2f;

	public float grabCloseDistance = 1.2f;

	public float launchSpeed = 25f;

	public float launchPitchUpMax = 45f;

	public float launchPitchDownMax = 20f;

	public PrefabRef bounceAffectPrefab;

	public float bounceAffectTimeMin = 3f;

	public float bounceAffectTimeMax = 6f;

	private Vector3 armAimPoint;

	private Quaternion grabberSpinStartRotation = Quaternion.identity;

	private float grabberSpinAngle;

	private bool grabberSpinActive;

	private float grabberSpinSettleTimer;

	private float grabberSpinSettleDuration;

	private float grabBuildUpTimer;

	private bool grabBuildUpStarted;

	private Vector3 launchDirection = Vector3.forward;

	private Quaternion armAimStartRotation = Quaternion.identity;

	private bool armAimCaptured;

	private State armAimCapturedState;

	private Quaternion armAimFrom = Quaternion.identity;

	private Quaternion armAimTo = Quaternion.identity;

	private float armAimLerp = 1f;

	private float armAimAnimDuration = 0.2f;

	private bool armAimEndSoundPlayed = true;

	private MegaBotArmPose armPoseRight = new MegaBotArmPose();

	private EnemyParent targetEnemyParent;

	public LineBetweenTwoPoints grabBeam;

	public Transform eyeLeftBeamOrigin;

	public Transform eyeRightBeamOrigin;

	public float screenShakeDistanceMin = 8f;

	public float screenShakeDistanceMax = 35f;

	public float screenShakePlatformRumble = 0.4f;

	public float screenShakeBeamRumble = 0.3f;

	public List<Transform> shakeParents = new List<Transform>();

	public SpringVector3 shakeSpringSettings = new SpringVector3
	{
		speed = 45f,
		damping = 0.25f
	};

	public float shakeVelocityInfluence = 0.15f;

	public float shakeOffsetMax = 0.5f;

	public SpringVector3 shakeRotationSpringSettings = new SpringVector3
	{
		speed = 45f,
		damping = 0.25f
	};

	public float shakeRotationInfluence = 0.03f;

	public float shakeRotationMax = 25f;

	public float shakeRotationEventScale = 10f;

	public float shakeVibrationAmount = 0.02f;

	public float shakeVibrationRotationAmount = 0.75f;

	public float shakeVibrationFrequency = 25f;

	public float shakeVibrationFullAngularSpeed = 90f;

	public float shakeVibrationResponse = 4f;

	private List<MegaBotShakeCenter> shakeCenters = new List<MegaBotShakeCenter>();

	private float shakeVibrationStrength;

	private float shakeVibrationYawPrevious;

	public ParticleSystem particleMetalSparks;

	public float sparkRateMax = 250f;

	public float sparkPlatformRadius = 2f;

	public float sparkFullAngularSpeed = 90f;

	private List<MegaBotSparkJoint> sparkJoints = new List<MegaBotSparkJoint>();

	private EmissionModule sparkEmission;

	private bool hasSparks;

	private float sparkPlatformYawPrevious;

	public ParticleSystem particleDust;

	public float dustRateMax = 40f;

	public float dustFullAngularSpeed = 90f;

	[Range(0f, 1f)]
	public float dustHeightFraction = 0.5f;

	private List<MegaBotSparkJoint> dustJoints = new List<MegaBotSparkJoint>();

	private EmissionModule dustEmission;

	private bool hasDust;

	public float playerTurnAngleThreshold = 20f;

	public float playerMoveDistanceThreshold = 0.1f;

	public float playerMoveWindowTime = 0.5f;

	public float physMoveSpeedThreshold = 0.3f;

	public float enemyMoveTriggerTime = 1f;

	public float physMoveTriggerTime = 2f;

	public int enemyGrabCountMin = 3;

	public int enemyGrabCountMax = 6;

	public float enemyGrabCooldownTime = 300f;

	private List<MegaBotMoveTracker> moveTrackers = new List<MegaBotMoveTracker>();

	private int enemyGrabsRemaining;

	private float enemyGrabCooldownTimer;

	public float pullForceMaxSpeed = 5f;

	public float stuckPhaseDuration = 1f;

	public float stuckPushForce = 6f;

	public float dislodgeBackwardForce = 8f;

	public float dislodgeUpForce = 6f;

	private bool stuckActive;

	private bool stuckPhaseDislodge;

	private float stuckPhaseTimer;

	private float stuckNotClosingTimer;

	private float stuckPrevDistance = float.MaxValue;

	private Vector3 stuckPushDirection;

	public Sound soundSqueak;

	public Transform audioPositionTransform;

	public Sound soundStartMove;

	public Sound soundEndMove;

	public Sound soundEyeStartMove;

	public Sound soundEyeEndMove;

	public Sound soundMovingLoop;

	public Sound soundPlatformStartMove;

	public Sound soundPlatformEndMove;

	public Sound soundPlatformRotatingLoop;

	public Sound soundWakeUp;

	public Sound soundEyeFlicker;

	public Sound soundGreenLight;

	public Sound soundThree;

	public Sound soundTwo;

	public Sound soundOne;

	public Sound soundEvilGrab;

	public Sound soundBuildUp;

	public Sound soundBeamGrab;

	public Sound soundBeamGrabLoop;

	public Sound soundLaunch;

	public Sound soundGoBackToGreenLight;

	public Sound soundShutDown;

	private float beamGrabLoopTimer;

	private PhysGrabObject targetPhysObject;

	private PlayerAvatar targetPlayer;

	private bool targetWasPlayer;

	private int countdownIndex;

	private LayerMask levelObstructMask;

	private readonly RaycastHit[] visionRaycastHits = new RaycastHit[16];

	private bool hasPlatform;

	private bool hasJaw;

	private bool hasGrabber;

	private bool hasEyeLight;

	private bool hasArm;

	private bool hasClaw;

	private void Awake()
	{
		//IL_0020: Unknown result type (might be due to invalid IL or missing references)
		//IL_0025: Unknown result type (might be due to invalid IL or missing references)
		//IL_003e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0043: Unknown result type (might be due to invalid IL or missing references)
		//IL_0081: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d2: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d7: Unknown result type (might be due to invalid IL or missing references)
		//IL_013a: Unknown result type (might be due to invalid IL or missing references)
		//IL_013f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0150: Unknown result type (might be due to invalid IL or missing references)
		//IL_0155: Unknown result type (might be due to invalid IL or missing references)
		//IL_0166: Unknown result type (might be due to invalid IL or missing references)
		//IL_016b: Unknown result type (might be due to invalid IL or missing references)
		//IL_017c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0181: Unknown result type (might be due to invalid IL or missing references)
		//IL_01a6: Unknown result type (might be due to invalid IL or missing references)
		//IL_01ab: Unknown result type (might be due to invalid IL or missing references)
		//IL_027b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0350: Unknown result type (might be due to invalid IL or missing references)
		//IL_0355: Unknown result type (might be due to invalid IL or missing references)
		//IL_035c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0361: Unknown result type (might be due to invalid IL or missing references)
		//IL_0368: Unknown result type (might be due to invalid IL or missing references)
		//IL_036d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0374: Unknown result type (might be due to invalid IL or missing references)
		//IL_0379: Unknown result type (might be due to invalid IL or missing references)
		//IL_030a: Unknown result type (might be due to invalid IL or missing references)
		//IL_030f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0326: Unknown result type (might be due to invalid IL or missing references)
		//IL_032b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0411: Unknown result type (might be due to invalid IL or missing references)
		//IL_0416: Unknown result type (might be due to invalid IL or missing references)
		//IL_0466: Unknown result type (might be due to invalid IL or missing references)
		//IL_046b: Unknown result type (might be due to invalid IL or missing references)
		photonView = ((Component)this).GetComponent<PhotonView>();
		levelObstructMask = LayerMask.op_Implicit(LayerMask.GetMask(new string[1] { "Default" }));
		roomVolumeMask = LayerMask.op_Implicit(LayerMask.GetMask(new string[1] { "RoomVolume" }));
		if (!Object.op_Implicit((Object)(object)eyeVisionTransform))
		{
			eyeVisionTransform = ((Component)this).transform;
		}
		hasPlatform = Object.op_Implicit((Object)(object)platformTransform);
		if (hasPlatform)
		{
			platformYawCurrent = platformTransform.localEulerAngles.y;
			platformYawTarget = platformYawCurrent;
		}
		hasJaw = Object.op_Implicit((Object)(object)jawTopTransform) && Object.op_Implicit((Object)(object)jawBottomTransform);
		if (hasJaw)
		{
			JawDriversBuild();
			jawTopStartRotation = jawTopTransform.localRotation;
		}
		hasGrabber = Object.op_Implicit((Object)(object)grabberAimTransform) && Object.op_Implicit((Object)(object)grabberHoldTransform) && Object.op_Implicit((Object)(object)grabberBeamOriginTransform);
		hasArm = Object.op_Implicit((Object)(object)armAimTransform) && Object.op_Implicit((Object)(object)armPoseTransform);
		if (hasArm)
		{
			armAimStartRotation = armAimTransform.localRotation;
			armPoseRight.startRotation = armPoseTransform.localRotation;
			armPoseRight.poseCurrent = armPoseRight.startRotation;
			armPoseRight.poseNew = armPoseRight.startRotation;
		}
		hasClaw = Object.op_Implicit((Object)(object)grabberClawRootTransform);
		if (hasClaw)
		{
			grabberSpinStartRotation = grabberClawRootTransform.localRotation;
		}
		if (!Object.op_Implicit((Object)(object)audioPositionTransform))
		{
			audioPositionTransform = eyeVisionTransform;
		}
		if (!Object.op_Implicit((Object)(object)ttsSpeech))
		{
			TTSMouthCreate();
		}
		hasTTS = Object.op_Implicit((Object)(object)ttsSpeech);
		if (hasTTS)
		{
			ttsAudioSource = ((Component)ttsSpeech).GetComponentInParent<AudioSource>();
		}
		if (Object.op_Implicit((Object)(object)eyeLeftRenderer))
		{
			eyeMaterials.Add(eyeLeftRenderer.material);
		}
		if (Object.op_Implicit((Object)(object)eyeRightRenderer))
		{
			eyeMaterials.Add(eyeRightRenderer.material);
		}
		for (int i = 0; i < eyeMaterials.Count; i++)
		{
			eyeMaterials[i].SetVector(grimeShiftID, new Vector4((float)i * 0.53f, (float)i * 0.31f, 0f, 0f));
		}
		if (eyeMaterials.Count > 0)
		{
			if (eyeMaterials[0].HasProperty(apertureSizeID))
			{
				eyeIrisSizeBase = eyeMaterials[0].GetFloat(apertureSizeID);
				eyeFireIntensityBase = eyeMaterials[0].GetFloat(fireIntensityID);
				eyeFireColorBase = eyeMaterials[0].GetColor(fireColorID);
				eyeTubeColorBase = eyeMaterials[0].GetColor(tubeColorID);
			}
			else
			{
				Debug.LogWarning((object)"mega semibot: eye material is not the mega semibot eyes shader, iris animation is gonna do nothing", (Object)(object)this);
			}
		}
		eyeIrisSpring.lastPosition = eyeIrisSizeBase;
		eyeFireColorCurrent = eyeFireColorBase;
		eyeFireColorTarget = eyeFireColorBase;
		eyeTubeColorCurrent = eyeTubeColorBase;
		eyeTubeColorTarget = eyeTubeColorBase;
		hasEyeLight = Object.op_Implicit((Object)(object)eyeLight);
		if (hasEyeLight)
		{
			((Component)eyeLight).gameObject.SetActive(true);
		}
		poseParts.RemoveAll((MegaBotPosePart _part) => !Object.op_Implicit((Object)(object)_part.bone) || (Object)(object)_part.bone == (Object)(object)eyeLeftTransform || (Object)(object)_part.bone == (Object)(object)eyeRightTransform);
		activationBoxes.RemoveAll((Transform _box) => !Object.op_Implicit((Object)(object)_box));
		LookEyesBuild();
		hasSparks = Object.op_Implicit((Object)(object)particleMetalSparks);
		if (hasSparks)
		{
			sparkEmission = particleMetalSparks.emission;
			particleMetalSparks.Stop(true, (ParticleSystemStopBehavior)1);
			SparkJointsBuild();
		}
		sparkPlatformYawPrevious = platformYawCurrent;
		shakeVibrationYawPrevious = platformYawCurrent;
		hasDust = Object.op_Implicit((Object)(object)particleDust);
		if (hasDust)
		{
			dustEmission = particleDust.emission;
			particleDust.Stop(true, (ParticleSystemStopBehavior)1);
			DustJointsBuild();
		}
		ShakeCentersBuild();
		FoliageSpheresBuild();
		FoliageSwayPartsBuild();
		MissingSetupWarnings();
	}

	private void Start()
	{
		FoliageSpheresRemove();
	}

	private void Update()
	{
		StateMachine();
		PoseTick();
		PoseLockTick();
		EyeLookTick();
		PlatformTick();
		EyesTick();
		EyeFlickerSoundTick();
		TTSMouthLogic();
		MouthTick();
		GrabberSpinTick();
		ArmPoseTick();
		ArmAimTick();
		ArmReachTick();
		SparkTick();
		DustTick();
		ShakeTick();
		FoliageSwayTick();
		GrabBuildUpParticlesStopLogic();
		PlayLoopSoundLogic();
		BotRoomVolumesFetchLogic();
		RecentActivitySenseLogic();
		EnemyGrabCooldownTick();
		FoliageAnchorTick();
		if (stateTimer <= stateTimerMax)
		{
			stateTimer += Time.deltaTime;
		}
	}

	private void FixedUpdate()
	{
		GrabPullPhysicsLogic();
	}

	private void OnDestroy()
	{
		foreach (Material eyeMaterial in eyeMaterials)
		{
			if (Object.op_Implicit((Object)(object)eyeMaterial))
			{
				Object.Destroy((Object)(object)eyeMaterial);
			}
		}
	}

	private void StateDormant()
	{
		if (stateStart)
		{
			stateStart = false;
			stateTimerMax = 0f;
			EyesOffInstant();
			PoseNeutralApply(dormantNeckPitch);
		}
		if (SemiFunc.IsMasterClientOrSingleplayer() && SemiFunc.PerSecond(5f, (Object)(object)this) && AnyPlayerInActivationBox())
		{
			StateSet(State.WakeUp);
		}
	}

	private void StateWakeUp()
	{
		//IL_005b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0083: Unknown result type (might be due to invalid IL or missing references)
		//IL_009e: Unknown result type (might be due to invalid IL or missing references)
		if (stateStart)
		{
			stateStart = false;
			stateTimerMax = 1.2f;
			stateTimer = 0f;
			soundWakeUp.Play(audioPositionTransform);
			PoseNeutralApply(0f);
			EyesFlickerOn(eyeColorGreen, eyeIrisScaleGreen, eyeFireScaleGreen);
			ShakeAll(0.125f);
			ScreenShakeImpact(eyeVisionTransform.position, 2f, 0.2f);
			ScreenShake(eyeVisionTransform.position, 1.5f, 0.5f);
		}
		if (SemiFunc.IsMasterClientOrSingleplayer() && stateTimer >= stateTimerMax)
		{
			StateSet(State.GreenLightStart);
		}
	}

	private void StateGreenLightStart()
	{
		//IL_0050: Unknown result type (might be due to invalid IL or missing references)
		//IL_007d: Unknown result type (might be due to invalid IL or missing references)
		if (stateStart)
		{
			stateStart = false;
			stateTimerMax = 0.6f;
			stateTimer = 0f;
			soundGreenLight.Play(audioPositionTransform);
			EyesColorSet(eyeColorGreen, eyeIrisScaleGreen, eyeFireScaleGreen);
			MouthMove(0.4f, 0.5f);
			ScreenShakeImpact(eyeVisionTransform.position, 0.5f, 0.1f);
		}
		if (SemiFunc.IsMasterClientOrSingleplayer() && stateTimer >= stateTimerMax)
		{
			StateSet(State.GreenLight);
		}
	}

	private void StateGreenLight()
	{
		if (stateStart)
		{
			stateStart = false;
			if (SemiFunc.IsMasterClientOrSingleplayer())
			{
				stateTimerMax = Random.Range(greenLightDurationMin, greenLightDurationMax);
			}
			stateTimer = 0f;
			greenSpinDirection = 0f - greenSpinDirection;
			PoseNeutralApply(0f);
			if (SemiFunc.IsMasterClientOrSingleplayer())
			{
				if (ttsPhrasesGreen.Count > 0)
				{
					TTSSay(ttsPhrasesGreen[0]);
				}
				ttsPhraseTimer = Random.Range(ttsGreenIntervalMin, ttsGreenIntervalMax);
			}
		}
		PlatformSpin(greenSpinDirection, platformGreenSpinSpeed);
		GreenLightEyesLogic();
		if (SemiFunc.IsMasterClientOrSingleplayer())
		{
			TTSPhraseLogic(ttsPhrasesGreen, ttsGreenIntervalMin, ttsGreenIntervalMax);
			if (stateTimer >= stateTimerMax)
			{
				StateSet(State.GreenLightEnding);
			}
		}
	}

	private void StateGreenLightEnding()
	{
		//IL_002e: Unknown result type (might be due to invalid IL or missing references)
		if (stateStart)
		{
			stateStart = false;
			stateTimerMax = 3f;
			stateTimer = 0f;
			countdownIndex = 0;
			EyesColorSet(eyeColorYellow, eyeIrisScaleYellow, eyeFireScaleYellow);
		}
		CountdownLogic();
		PlatformSpin(greenSpinDirection, platformGreenSpinSpeed);
		GreenLightEyesLogic();
		if (SemiFunc.IsMasterClientOrSingleplayer() && stateTimer >= stateTimerMax)
		{
			StateSet(State.RedLight);
		}
	}

	private void StateRedLight()
	{
		//IL_003d: Unknown result type (might be due to invalid IL or missing references)
		if (stateStart)
		{
			stateStart = false;
			if (SemiFunc.IsMasterClientOrSingleplayer())
			{
				stateTimerMax = Random.Range(redLightDurationMin, redLightDurationMax);
			}
			stateTimer = 0f;
			EyesColorSet(eyeColorRed, eyeIrisScaleRed, eyeFireScaleRed);
			PoseNeutralApply(redLightNeckPitch);
			if (SemiFunc.IsMasterClientOrSingleplayer())
			{
				MoveTrackersBuild();
				if (ttsPhrasesRed.Count > 0)
				{
					TTSSay(ttsPhrasesRed[0]);
				}
				ttsPhraseTimer = Random.Range(ttsRedIntervalMin, ttsRedIntervalMax);
			}
		}
		PlatformSpin(greenSpinDirection, platformRedSpinSpeed);
		if (!SemiFunc.IsMasterClientOrSingleplayer())
		{
			return;
		}
		MoveTrackersAdoptPlayersLogic();
		MoveTrackersLogic();
		if (currentState == State.RedLight)
		{
			TTSPhraseLogic(ttsPhrasesRed, ttsRedIntervalMin, ttsRedIntervalMax);
			if (stateTimer >= stateTimerMax)
			{
				StateSet(State.RedLightToGreenLight);
			}
		}
	}

	private void StateGrabStart()
	{
		//IL_008d: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a8: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f3: Unknown result type (might be due to invalid IL or missing references)
		//IL_0118: Unknown result type (might be due to invalid IL or missing references)
		if (stateStart)
		{
			stateStart = false;
			stateTimerMax = 5f;
			stateTimer = 0f;
			grabBuildUpStarted = false;
			grabBuildUpTimer = 0f;
			poseLockTimer = 0f;
			soundEvilGrab.Play(audioPositionTransform);
			MouthMove(1f, 0.8f);
			ShakeAll(0.2f);
			ScreenShakeImpact(eyeVisionTransform.position, 2f, 0.2f);
			ScreenShake(eyeVisionTransform.position, 1.5f, 0.4f);
		}
		if (!hasGrabber)
		{
			if (SemiFunc.IsMasterClientOrSingleplayer())
			{
				StateSet(State.RedLightToGreenLight);
			}
			return;
		}
		if (!TargetValid())
		{
			if (SemiFunc.IsMasterClientOrSingleplayer())
			{
				StateSet(State.RedLightToGreenLight);
			}
			return;
		}
		ArmAimPointSet(targetPhysObject.centerPoint);
		GrabBuildUpLogic();
		if (SemiFunc.IsMasterClientOrSingleplayer())
		{
			GrabTargetStunLogic();
			PoseSet(targetPhysObject.centerPoint, 0.5f);
			if (grabBuildUpStarted && grabBuildUpTimer >= grabBuildUpDuration && (FacingTargetEnough() || stateTimer >= grabFaceForceTime))
			{
				StateSet(State.GrabPullIn);
			}
			else if (stateTimer >= stateTimerMax)
			{
				StateSet(State.RedLightToGreenLight);
			}
		}
	}

	private void StateGrabPullIn()
	{
		//IL_0058: Unknown result type (might be due to invalid IL or missing references)
		//IL_008b: Unknown result type (might be due to invalid IL or missing references)
		//IL_00af: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ba: Unknown result type (might be due to invalid IL or missing references)
		if (stateStart)
		{
			stateStart = false;
			stateTimerMax = 12f;
			stateTimer = 0f;
			StuckReset();
			soundBeamGrab.Play(grabberBeamOriginTransform);
			ScreenShakeImpact(grabberBeamOriginTransform.position, 1f, 0.1f);
		}
		if (!TargetValid())
		{
			if (SemiFunc.IsMasterClientOrSingleplayer())
			{
				StateSet(State.RedLightToGreenLight);
			}
			return;
		}
		ArmAimPointSet(targetPhysObject.centerPoint);
		BeamGrabLoop();
		if (SemiFunc.IsMasterClientOrSingleplayer())
		{
			GrabTargetStunLogic();
			if (Vector3.Distance(targetPhysObject.centerPoint, grabberHoldTransform.position) <= grabCloseDistance)
			{
				StateSet(State.GrabGotoLaunchPose);
			}
			else if (stateTimer >= stateTimerMax)
			{
				StateSet(State.RedLightToGreenLight);
			}
		}
	}

	private void StateGrabGotoLaunchPose()
	{
		//IL_0051: Unknown result type (might be due to invalid IL or missing references)
		//IL_0057: Unknown result type (might be due to invalid IL or missing references)
		//IL_0061: Unknown result type (might be due to invalid IL or missing references)
		//IL_0066: Unknown result type (might be due to invalid IL or missing references)
		//IL_008b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0091: Unknown result type (might be due to invalid IL or missing references)
		//IL_009b: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a0: Unknown result type (might be due to invalid IL or missing references)
		if (stateStart)
		{
			stateStart = false;
			stateTimerMax = 4f;
			stateTimer = 0f;
			if (SemiFunc.IsMasterClientOrSingleplayer())
			{
				LaunchDirectionPick();
			}
		}
		if (!TargetValid())
		{
			if (SemiFunc.IsMasterClientOrSingleplayer())
			{
				StateSet(State.RedLightToGreenLight);
			}
			return;
		}
		ArmAimPointSet(grabberBeamOriginTransform.position + launchDirection * 10f);
		BeamGrabLoop();
		if (SemiFunc.IsMasterClientOrSingleplayer())
		{
			GrabTargetStunLogic();
			PoseSet(eyeVisionTransform.position + launchDirection * 10f, 0.5f);
			if ((ArmAimAligned() && platformMoveState == PlatformMoveState.Idle) || stateTimer >= stateTimerMax)
			{
				StateSet(State.GrabLaunch);
			}
		}
	}

	private void StateGrabLaunch()
	{
		//IL_0070: Unknown result type (might be due to invalid IL or missing references)
		//IL_008b: Unknown result type (might be due to invalid IL or missing references)
		if (stateStart)
		{
			stateStart = false;
			stateTimerMax = 0.5f;
			stateTimer = 0f;
			soundLaunch.Play(grabberBeamOriginTransform);
			MouthMove(1f, 0.5f);
			ShakeAll(0.3f);
			ScreenShakeImpact(grabberBeamOriginTransform.position, 3f, 0.25f);
			ScreenShake(grabberBeamOriginTransform.position, 2f, 0.5f);
			if (SemiFunc.IsMasterClientOrSingleplayer() && TargetValid())
			{
				LaunchTarget();
			}
		}
		if (SemiFunc.IsMasterClientOrSingleplayer() && stateTimer >= stateTimerMax)
		{
			StateSet(State.RedLightToGreenLight);
		}
	}

	private void StateRedLightToGreenLight()
	{
		if (stateStart)
		{
			stateStart = false;
			stateTimerMax = 1.5f;
			stateTimer = 0f;
			soundGoBackToGreenLight.Play(audioPositionTransform);
			PoseNeutralApply(0f);
			TargetClearLocal();
		}
		if (SemiFunc.IsMasterClientOrSingleplayer() && stateTimer >= stateTimerMax)
		{
			if (recentActivityTimer > 0f)
			{
				StateSet(State.GreenLightStart);
			}
			else
			{
				StateSet(State.Shutdown);
			}
		}
	}

	private void StateShutdown()
	{
		//IL_0066: Unknown result type (might be due to invalid IL or missing references)
		//IL_0081: Unknown result type (might be due to invalid IL or missing references)
		if (stateStart)
		{
			stateStart = false;
			stateTimerMax = 1.2f;
			stateTimer = 0f;
			soundShutDown.Play(audioPositionTransform);
			EyesFlickerOff();
			PoseNeutralApply(0f);
			ScreenShakeImpact(eyeVisionTransform.position, 1.5f, 0.2f);
			ScreenShake(eyeVisionTransform.position, 1f, 0.5f);
		}
		if (SemiFunc.IsMasterClientOrSingleplayer() && stateTimer >= stateTimerMax)
		{
			StateSet(State.Dormant);
		}
	}

	private void StateMachine()
	{
		switch (currentState)
		{
		case State.Dormant:
			StateDormant();
			break;
		case State.WakeUp:
			StateWakeUp();
			break;
		case State.GreenLightStart:
			StateGreenLightStart();
			break;
		case State.GreenLight:
			StateGreenLight();
			break;
		case State.GreenLightEnding:
			StateGreenLightEnding();
			break;
		case State.RedLight:
			StateRedLight();
			break;
		case State.GrabStart:
			StateGrabStart();
			break;
		case State.GrabPullIn:
			StateGrabPullIn();
			break;
		case State.GrabGotoLaunchPose:
			StateGrabGotoLaunchPose();
			break;
		case State.GrabLaunch:
			StateGrabLaunch();
			break;
		case State.RedLightToGreenLight:
			StateRedLightToGreenLight();
			break;
		case State.Shutdown:
			StateShutdown();
			break;
		}
	}

	public void StateSet(State _newState)
	{
		//IL_003f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0045: Unknown result type (might be due to invalid IL or missing references)
		if (currentState != _newState && SemiFunc.IsMasterClientOrSingleplayer())
		{
			if (CanRPC())
			{
				photonView.RPC("StateSetRPC", (RpcTarget)0, new object[1] { (int)_newState });
			}
			else
			{
				StateSetRPC((int)_newState);
			}
		}
	}

	private void MissingSetupWarnings()
	{
		if (!Object.op_Implicit((Object)(object)photonView))
		{
			Debug.LogWarning((object)"mega semibot: no photonview, rpcs run locally only", (Object)(object)this);
		}
		if (!hasPlatform)
		{
			Debug.LogWarning((object)"mega semibot: no platform transform, platform rotation off", (Object)(object)this);
		}
		if (!hasJaw)
		{
			Debug.LogWarning((object)"mega semibot: jaw transforms missing, mouth off", (Object)(object)this);
		}
		if (!hasTTS)
		{
			Debug.LogWarning((object)"mega semibot: tts mouth creation failed, no voice", (Object)(object)this);
		}
		if (!hasGrabber)
		{
			Debug.LogWarning((object)"mega semibot: grabber refs missing, grabbing off", (Object)(object)this);
		}
		if (!hasArm)
		{
			Debug.LogWarning((object)"mega semibot: arm refs missing, arm aiming off", (Object)(object)this);
		}
		if (!hasClaw)
		{
			Debug.LogWarning((object)"mega semibot: no grabber claw root, hand spin off", (Object)(object)this);
		}
		if (!hasSparks)
		{
			Debug.LogWarning((object)"mega semibot: no metal sparks particle assigned, sparks off", (Object)(object)this);
		}
		if (!hasDust)
		{
			Debug.LogWarning((object)"mega semibot: no dust particle assigned, falling dust off", (Object)(object)this);
		}
		if (hasDust && dustJoints.Count == 0)
		{
			Debug.LogWarning((object)"mega semibot: no joints made it past the dust height cutoff, lower dust height fraction", (Object)(object)this);
		}
		if (shakeCenters.Count == 0)
		{
			Debug.LogWarning((object)"mega semibot: shake parents list is empty, press create shake parents on the prefab and save it", (Object)(object)this);
		}
		if (!hasEyeLight)
		{
			Debug.LogWarning((object)"mega semibot: no eye light assigned", (Object)(object)this);
		}
		if (eyeMaterials.Count == 0)
		{
			Debug.LogWarning((object)"mega semibot: no eye renderers, eye shader animation off", (Object)(object)this);
		}
		if (activationBoxes.Count == 0)
		{
			Debug.LogWarning((object)"mega semibot: no activation boxes, falling back to range checks", (Object)(object)this);
		}
		if (poseParts.Count == 0)
		{
			Debug.LogWarning((object)"mega semibot: no pose parts with bones, posing off", (Object)(object)this);
		}
		if (lookEyes.Count == 0)
		{
			Debug.LogWarning((object)"mega semibot: eye transforms missing, eye look off", (Object)(object)this);
		}
		if (!bounceAffectPrefab.IsValid())
		{
			Debug.LogWarning((object)"mega semibot: no bounce affect prefab, launch skips the bounce", (Object)(object)this);
		}
		if (foliageSwayParts.Count == 0)
		{
			Debug.LogWarning((object)"mega semibot: no foilage small/medium/rigid transforms found, foliage sway off", (Object)(object)this);
		}
		FoliageBakeWarning();
	}

	private bool CanRPC()
	{
		if (SemiFunc.IsMultiplayer())
		{
			return Object.op_Implicit((Object)(object)photonView);
		}
		return false;
	}

	private bool PointInActivationBox(Vector3 _worldPosition)
	{
		//IL_0013: Unknown result type (might be due to invalid IL or missing references)
		//IL_0018: Unknown result type (might be due to invalid IL or missing references)
		//IL_003f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0040: Unknown result type (might be due to invalid IL or missing references)
		//IL_0045: Unknown result type (might be due to invalid IL or missing references)
		//IL_0046: Unknown result type (might be due to invalid IL or missing references)
		//IL_0058: Unknown result type (might be due to invalid IL or missing references)
		//IL_006a: Unknown result type (might be due to invalid IL or missing references)
		if (activationBoxes.Count == 0)
		{
			return Vector3.Distance(eyeVisionTransform.position, _worldPosition) <= targetRange;
		}
		foreach (Transform activationBox in activationBoxes)
		{
			Vector3 val = activationBox.InverseTransformPoint(_worldPosition);
			if (Mathf.Abs(val.x) <= 0.5f && Mathf.Abs(val.y) <= 0.5f && Mathf.Abs(val.z) <= 0.5f)
			{
				return true;
			}
		}
		return false;
	}

	private bool PlayerInActivationBox(PlayerAvatar _player)
	{
		//IL_0007: Unknown result type (might be due to invalid IL or missing references)
		//IL_0021: Unknown result type (might be due to invalid IL or missing references)
		if (PointInActivationBox(((Component)_player).transform.position))
		{
			return true;
		}
		return PointInActivationBox(_player.PlayerVisionTarget.VisionTransform.position);
	}

	private bool AnyPlayerInActivationBox()
	{
		foreach (PlayerAvatar item in SemiFunc.PlayerGetList())
		{
			if (!item.isDisabled && PlayerInActivationBox(item))
			{
				return true;
			}
		}
		return false;
	}

	private void BotRoomVolumesFetchLogic()
	{
		//IL_002b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0030: Unknown result type (might be due to invalid IL or missing references)
		//IL_0035: Unknown result type (might be due to invalid IL or missing references)
		//IL_0040: Unknown result type (might be due to invalid IL or missing references)
		if (botRoomVolumes.Count > 0 || !SemiFunc.LevelGenDone() || !SemiFunc.PerSecond(1f, (Object)(object)this))
		{
			return;
		}
		Collider[] array = Physics.OverlapSphere(((Component)this).transform.position + Vector3.up, 1f, LayerMask.op_Implicit(roomVolumeMask));
		foreach (Collider val in array)
		{
			RoomVolume roomVolume = ((Component)val).GetComponent<RoomVolume>();
			if (!Object.op_Implicit((Object)(object)roomVolume))
			{
				roomVolume = ((Component)val).GetComponentInParent<RoomVolume>();
			}
			if (Object.op_Implicit((Object)(object)roomVolume) && !botRoomVolumes.Contains(roomVolume))
			{
				botRoomVolumes.Add(roomVolume);
			}
		}
		if (botRoomVolumes.Count == 0 && !botRoomVolumesWarned)
		{
			botRoomVolumesWarned = true;
			Debug.LogWarning((object)"mega semibot: found no room volume at my position, sticking to the activation box for everything", (Object)(object)this);
		}
	}

	private bool PlayerInBotRoom(PlayerAvatar _player)
	{
		if (botRoomVolumes.Count == 0)
		{
			return PlayerInActivationBox(_player);
		}
		foreach (RoomVolume currentRoom in _player.RoomVolumeCheck.CurrentRooms)
		{
			if (botRoomVolumes.Contains(currentRoom))
			{
				return true;
			}
		}
		return false;
	}

	private bool AnyPlayerInBotRoom()
	{
		foreach (PlayerAvatar item in SemiFunc.PlayerGetList())
		{
			if (!item.isDisabled && PlayerInBotRoom(item))
			{
				return true;
			}
		}
		return false;
	}

	private void RecentActivitySenseLogic()
	{
		if (SemiFunc.IsMasterClientOrSingleplayer() && currentState != State.Dormant)
		{
			if (recentActivityTimer > 0f)
			{
				recentActivityTimer -= Time.deltaTime;
			}
			if (SemiFunc.PerSecond(5f, (Object)(object)this) && AnyPlayerInBotRoom())
			{
				recentActivityTimer = recentActivityGraceTime;
			}
		}
	}

	private void FoliageSpheresBuild()
	{
		foliageSpheres = ((Component)this).GetComponentsInChildren<MegaSemibotFoliageSphere>(true);
		hasFoliage = foliageSpheres.Length != 0;
		foliageAnchor = (Object.op_Implicit((Object)(object)platformTransform) ? platformTransform : ((Component)this).transform);
	}

	private void FoliageSpheresRemove()
	{
		MegaSemibotFoliageSphere[] array = foliageSpheres;
		for (int i = 0; i < array.Length; i++)
		{
			Object.Destroy((Object)(object)((Component)array[i]).gameObject);
		}
		foliageSpheres = new MegaSemibotFoliageSphere[0];
		hasFoliage = false;
	}

	private void FoliageAnchorTick()
	{
		//IL_000b: Unknown result type (might be due to invalid IL or missing references)
		Shader.SetGlobalMatrix(foliageMatrixID, foliageAnchor.worldToLocalMatrix);
	}

	private List<MeshRenderer> BodyRenderersGet()
	{
		List<MeshRenderer> list = new List<MeshRenderer>();
		MeshRenderer[] componentsInChildren = ((Component)this).GetComponentsInChildren<MeshRenderer>(true);
		foreach (MeshRenderer val in componentsInChildren)
		{
			if (Object.op_Implicit((Object)(object)((Renderer)val).sharedMaterial))
			{
				string name = ((Object)((Renderer)val).sharedMaterial.shader).name;
				if (name == "SemiWork/Mega Semibot Layered" || name == "SemiWork/Mega Semibot Platform")
				{
					list.Add(val);
				}
			}
		}
		return list;
	}

	private List<Material> FoliageMaterialsGet()
	{
		List<Material> list = new List<Material>();
		foreach (MeshRenderer item in BodyRenderersGet())
		{
			if (!list.Contains(((Renderer)item).sharedMaterial))
			{
				list.Add(((Renderer)item).sharedMaterial);
			}
		}
		return list;
	}

	private void FoliageBakeWarning()
	{
		foreach (Material item in FoliageMaterialsGet())
		{
			if (item.IsKeywordEnabled("_FOLIAGE_ON") && !Object.op_Implicit((Object)(object)item.GetTexture(foliageBakedMaskID)))
			{
				Debug.LogWarning((object)("mega semibot: foliage is on but " + ((Object)item).name + " has no baked mask, press bake foliage on the prefab"), (Object)(object)this);
			}
		}
	}

	private Vector3 VisionOriginGet()
	{
		//IL_0046: Unknown result type (might be due to invalid IL or missing references)
		//IL_0020: Unknown result type (might be due to invalid IL or missing references)
		//IL_002b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0030: Unknown result type (might be due to invalid IL or missing references)
		//IL_003a: Unknown result type (might be due to invalid IL or missing references)
		if (Object.op_Implicit((Object)(object)eyeLeftBeamOrigin) && Object.op_Implicit((Object)(object)eyeRightBeamOrigin))
		{
			return (eyeLeftBeamOrigin.position + eyeRightBeamOrigin.position) * 0.5f;
		}
		return eyeVisionTransform.position;
	}

	private bool VisionBlocked(Vector3 _targetPosition)
	{
		//IL_0001: Unknown result type (might be due to invalid IL or missing references)
		//IL_0006: Unknown result type (might be due to invalid IL or missing references)
		//IL_0007: Unknown result type (might be due to invalid IL or missing references)
		//IL_0008: Unknown result type (might be due to invalid IL or missing references)
		//IL_0009: Unknown result type (might be due to invalid IL or missing references)
		//IL_000e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0021: Unknown result type (might be due to invalid IL or missing references)
		//IL_0022: Unknown result type (might be due to invalid IL or missing references)
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_0031: Unknown result type (might be due to invalid IL or missing references)
		Vector3 val = VisionOriginGet();
		Vector3 val2 = _targetPosition - val;
		float magnitude = val2.magnitude;
		if (magnitude < 0.001f)
		{
			return false;
		}
		int num = Physics.RaycastNonAlloc(val, val2 / magnitude, visionRaycastHits, magnitude, LayerMask.op_Implicit(levelObstructMask), (QueryTriggerInteraction)1);
		for (int i = 0; i < num; i++)
		{
			if (!((Component)visionRaycastHits[i].collider).transform.IsChildOf(((Component)this).transform))
			{
				return true;
			}
		}
		return false;
	}

	private void PoseSet(Vector3 _lookPoint, float _lockTime)
	{
		//IL_0049: Unknown result type (might be due to invalid IL or missing references)
		//IL_004d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0053: Unknown result type (might be due to invalid IL or missing references)
		//IL_0032: Unknown result type (might be due to invalid IL or missing references)
		if (SemiFunc.IsMasterClientOrSingleplayer() && !(poseLockTimer > 0f))
		{
			if (CanRPC())
			{
				photonView.RPC("PoseSetRPC", (RpcTarget)0, new object[2] { _lookPoint, _lockTime });
			}
			else
			{
				PoseSetRPC(_lookPoint, _lockTime);
			}
		}
	}

	private void PoseApply(Vector3 _lookPoint, float _lockTime)
	{
		//IL_0000: Unknown result type (might be due to invalid IL or missing references)
		//IL_0007: Unknown result type (might be due to invalid IL or missing references)
		//IL_000c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0011: Unknown result type (might be due to invalid IL or missing references)
		//IL_0012: Unknown result type (might be due to invalid IL or missing references)
		//IL_0056: Unknown result type (might be due to invalid IL or missing references)
		//IL_005b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0060: Unknown result type (might be due to invalid IL or missing references)
		//IL_0061: Unknown result type (might be due to invalid IL or missing references)
		//IL_0067: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ba: Unknown result type (might be due to invalid IL or missing references)
		//IL_00bb: Unknown result type (might be due to invalid IL or missing references)
		//IL_0048: Unknown result type (might be due to invalid IL or missing references)
		//IL_003b: Unknown result type (might be due to invalid IL or missing references)
		//IL_004d: Unknown result type (might be due to invalid IL or missing references)
		Vector3 val2;
		Vector3 val = (val2 = _lookPoint - eyeVisionTransform.position);
		val2.y = 0f;
		if (val2.sqrMagnitude < 0.001f)
		{
			val2 = (hasPlatform ? platformTransform.forward : ((Component)this).transform.forward);
		}
		Vector3 val3 = ((Component)this).transform.InverseTransformDirection(val2.normalized);
		float yaw = Mathf.Atan2(val3.x, val3.z) * 57.29578f;
		float num = (0f - Mathf.Atan2(val.y, val2.magnitude)) * 57.29578f;
		num = Mathf.Clamp(num, 0f - posePitchClamp, posePitchClamp);
		PlatformYawTargetSet(yaw);
		PosePartsSet(num, 0f);
		lookTargetPosition = _lookPoint;
		lookTargetActive = true;
		poseLockTimer = posePartDelayMax + poseDurationMax + _lockTime;
		soundSqueak.Play(audioPositionTransform);
	}

	private void PoseNeutralApply(float _pitch)
	{
		PosePartsSet(_pitch, 0f);
		lookTargetActive = false;
		poseLockTimer = posePartDelayMax + poseDurationMax;
	}

	private void PosePartsSet(float _pitch, float _yaw)
	{
		//IL_0028: Unknown result type (might be due to invalid IL or missing references)
		//IL_002d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0076: Unknown result type (might be due to invalid IL or missing references)
		//IL_007b: Unknown result type (might be due to invalid IL or missing references)
		float num = 0f;
		MegaBotPosePart megaBotPosePart = null;
		foreach (MegaBotPosePart posePart in poseParts)
		{
			posePart.startRotation = posePart.bone.localRotation;
			float num2 = Random.Range(0f - posePart.noiseMaxDegrees, posePart.noiseMaxDegrees);
			float num3 = Random.Range(0f - posePart.noiseMaxDegrees, posePart.noiseMaxDegrees);
			posePart.targetRotation = Quaternion.Euler(_pitch * posePart.pitchWeight + num2, _yaw * posePart.yawWeight + num3, 0f);
			posePart.delayTimer = Random.Range(0f, posePartDelayMax);
			posePart.duration = Random.Range(poseDurationMin, poseDurationMax);
			posePart.progress = 0f;
			posePart.started = false;
			posePart.playsEndSound = false;
			float num4 = posePart.delayTimer + posePart.duration;
			if (num4 > num)
			{
				num = num4;
				megaBotPosePart = posePart;
			}
		}
		if (megaBotPosePart != null)
		{
			megaBotPosePart.playsEndSound = true;
		}
		poseStartSoundPlayed = false;
		poseEndSoundPlayed = false;
	}

	private void PoseTick()
	{
		//IL_009e: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a4: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ba: Unknown result type (might be due to invalid IL or missing references)
		//IL_0115: Unknown result type (might be due to invalid IL or missing references)
		bool flag = false;
		foreach (MegaBotPosePart posePart in poseParts)
		{
			if (posePart.progress >= 1f)
			{
				continue;
			}
			flag = true;
			if (posePart.delayTimer > 0f)
			{
				posePart.delayTimer -= Time.deltaTime;
				continue;
			}
			if (!posePart.started)
			{
				posePart.started = true;
				PoseFirstMoverSound();
			}
			posePart.progress += Time.deltaTime / posePart.duration;
			if (posePart.progress > 1f)
			{
				posePart.progress = 1f;
			}
			posePart.bone.localRotation = Quaternion.SlerpUnclamped(posePart.startRotation, posePart.targetRotation, poseCurve.Evaluate(posePart.progress));
			if (posePart.playsEndSound && !poseEndSoundPlayed && posePart.progress >= 0.8f)
			{
				poseEndSoundPlayed = true;
				soundEndMove.Play(audioPositionTransform);
				ScreenShakeImpact(eyeVisionTransform.position, 0.75f, 0.1f);
			}
		}
		if (flag)
		{
			poseMovingLoopTimer = 0.1f;
		}
	}

	private void PoseFirstMoverSound()
	{
		if (!poseStartSoundPlayed)
		{
			poseStartSoundPlayed = true;
			soundStartMove.Play(audioPositionTransform);
		}
	}

	private void PoseLockTick()
	{
		if (poseLockTimer > 0f)
		{
			poseLockTimer -= Time.deltaTime;
		}
	}

	private void PlatformYawTargetSet(float _yaw)
	{
		if (!hasPlatform)
		{
			return;
		}
		if (platformSpinActive)
		{
			platformSpinActive = false;
			platformSpinTimer = 0f;
		}
		if (Mathf.Abs(Mathf.DeltaAngle(platformYawCurrent, _yaw)) < 1f)
		{
			platformYawTarget = _yaw;
			return;
		}
		platformYawTarget = _yaw;
		if (platformMoveState == PlatformMoveState.Idle || platformMoveState == PlatformMoveState.Settle)
		{
			platformMoveState = PlatformMoveState.Ramp;
			platformRampTimer = 0f;
			platformRampDuration = Random.Range(platformRampDurationMin, platformRampDurationMax);
			soundPlatformStartMove.Play(platformTransform);
			PlatformYawSyncSend();
		}
	}

	private void PlatformYawSyncSend()
	{
		if (SemiFunc.IsMasterClientOrSingleplayer() && CanRPC())
		{
			photonView.RPC("PlatformYawSyncRPC", (RpcTarget)1, new object[1] { platformYawCurrent });
		}
	}

	private void PlatformSpin(float _direction, float _speed)
	{
		platformSpinDirection = _direction;
		platformSpinSpeedCurrent = _speed;
		platformSpinTimer = 0.1f;
	}

	private void PlatformSpinTick()
	{
		//IL_00d0: Unknown result type (might be due to invalid IL or missing references)
		//IL_0102: Unknown result type (might be due to invalid IL or missing references)
		if (platformSpinTimer <= 0f && platformSpinActive)
		{
			platformSpinActive = false;
			platformYawTarget = platformYawCurrent;
			PlatformSettleStart();
		}
		if (platformSpinTimer > 0f)
		{
			if (!platformSpinActive)
			{
				platformSpinActive = true;
				platformMoveState = PlatformMoveState.Rotate;
				soundPlatformStartMove.Play(platformTransform);
				PlatformYawSyncSend();
			}
			platformSpinTimer -= Time.deltaTime;
			platformYawCurrent += platformSpinDirection * platformSpinSpeedCurrent * Time.deltaTime;
			platformYawTarget = platformYawCurrent;
			platformLoopTimer = 0.2f;
			ScreenShake(platformTransform.position, screenShakePlatformRumble, 0.1f);
			platformTransform.localRotation = Quaternion.Euler(0f, platformYawCurrent + platformYawSyncOffset, 0f);
		}
	}

	private void PlatformYawSyncOffsetTick()
	{
		if (platformYawSyncOffset != 0f)
		{
			float num = Mathf.Max(platformYawSyncCorrectSpeed, Mathf.Abs(platformYawSyncOffset) * platformYawSyncCatchUpMultiplier);
			platformYawSyncOffset = Mathf.MoveTowards(platformYawSyncOffset, 0f, num * Time.deltaTime);
		}
	}

	private void PlatformTick()
	{
		//IL_0153: Unknown result type (might be due to invalid IL or missing references)
		if (!hasPlatform)
		{
			return;
		}
		PlatformYawSyncOffsetTick();
		PlatformSpinTick();
		if (platformSpinActive)
		{
			return;
		}
		float num = 0f;
		switch (platformMoveState)
		{
		case PlatformMoveState.Ramp:
		{
			platformRampTimer += Time.deltaTime;
			float speedMultiplier = platformStartCurve.Evaluate(Mathf.Clamp01(platformRampTimer / platformRampDuration));
			PlatformRotateStep(speedMultiplier);
			if (platformRampTimer >= platformRampDuration)
			{
				platformMoveState = PlatformMoveState.Rotate;
			}
			if (PlatformReachedTarget())
			{
				PlatformSettleStart();
			}
			break;
		}
		case PlatformMoveState.Rotate:
			PlatformRotateStep(1f);
			if (PlatformReachedTarget())
			{
				PlatformSettleStart();
			}
			break;
		case PlatformMoveState.Settle:
		{
			platformSettleTimer += Time.deltaTime;
			float num2 = Mathf.Clamp01(platformSettleTimer / platformSettleDuration);
			num = platformSettleCurve.Evaluate(num2) * platformSettleWobbleDegrees * Mathf.Sin(num2 * MathF.PI * 4f);
			if (platformSettleTimer >= platformSettleDuration)
			{
				platformMoveState = PlatformMoveState.Idle;
				platformYawCurrent = platformYawTarget;
				num = 0f;
			}
			break;
		}
		}
		platformTransform.localRotation = Quaternion.Euler(0f, platformYawCurrent + num + platformYawSyncOffset, 0f);
	}

	private void PlatformRotateStep(float _speedMultiplier)
	{
		//IL_0054: Unknown result type (might be due to invalid IL or missing references)
		float num = platformYawCurrent;
		platformYawCurrent = Mathf.MoveTowardsAngle(platformYawCurrent, platformYawTarget, platformRotateSpeed * _speedMultiplier * Time.deltaTime);
		if (Mathf.Abs(Mathf.DeltaAngle(num, platformYawCurrent)) > 0.01f)
		{
			platformLoopTimer = 0.2f;
			ScreenShake(platformTransform.position, screenShakePlatformRumble, 0.1f);
		}
	}

	private bool PlatformReachedTarget()
	{
		return Mathf.Abs(Mathf.DeltaAngle(platformYawCurrent, platformYawTarget)) < 0.5f;
	}

	private void PlatformSettleStart()
	{
		//IL_0061: Unknown result type (might be due to invalid IL or missing references)
		//IL_007c: Unknown result type (might be due to invalid IL or missing references)
		platformMoveState = PlatformMoveState.Settle;
		platformSettleTimer = 0f;
		platformSettleDuration = Random.Range(platformRampDurationMin, platformRampDurationMax);
		soundPlatformEndMove.Play(platformTransform);
		ShakeAll(0.075f);
		ScreenShakeImpact(platformTransform.position, 1.5f, 0.15f);
		ScreenShake(platformTransform.position, 1f, 0.3f);
	}

	private void EyesFlickerOn(Color _color, float _irisScale, float _fireScale)
	{
		//IL_0001: Unknown result type (might be due to invalid IL or missing references)
		//IL_0002: Unknown result type (might be due to invalid IL or missing references)
		//IL_0018: Unknown result type (might be due to invalid IL or missing references)
		//IL_001d: Unknown result type (might be due to invalid IL or missing references)
		//IL_001e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0023: Unknown result type (might be due to invalid IL or missing references)
		//IL_002b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0030: Unknown result type (might be due to invalid IL or missing references)
		//IL_0031: Unknown result type (might be due to invalid IL or missing references)
		//IL_0036: Unknown result type (might be due to invalid IL or missing references)
		eyeColorCurrent = _color;
		eyeIrisScaleCurrent = _irisScale;
		eyeFireScaleCurrent = _fireScale;
		eyeFireColorTarget = StateTintedColor(eyeFireColorBase, _color);
		eyeTubeColorTarget = StateTintedColor(eyeTubeColorBase, _color);
		eyesOn = true;
		eyeFlickerOnTimer = 0f;
		eyeFlickerOffTimer = -1f;
		eyeFlickerSoundTimer = 0f;
	}

	private void EyesFlickerOff()
	{
		eyesOn = false;
		eyeFlickerOffTimer = 0f;
		eyeFlickerOnTimer = -1f;
		eyeFlickerSoundTimer = 0f;
	}

	private void EyesColorSet(Color _color, float _irisScale, float _fireScale)
	{
		//IL_0001: Unknown result type (might be due to invalid IL or missing references)
		//IL_0002: Unknown result type (might be due to invalid IL or missing references)
		//IL_0018: Unknown result type (might be due to invalid IL or missing references)
		//IL_001d: Unknown result type (might be due to invalid IL or missing references)
		//IL_001e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0023: Unknown result type (might be due to invalid IL or missing references)
		//IL_002b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0030: Unknown result type (might be due to invalid IL or missing references)
		//IL_0031: Unknown result type (might be due to invalid IL or missing references)
		//IL_0036: Unknown result type (might be due to invalid IL or missing references)
		eyeColorCurrent = _color;
		eyeIrisScaleCurrent = _irisScale;
		eyeFireScaleCurrent = _fireScale;
		eyeFireColorTarget = StateTintedColor(eyeFireColorBase, _color);
		eyeTubeColorTarget = StateTintedColor(eyeTubeColorBase, _color);
		eyesOn = true;
	}

	private Color StateTintedColor(Color _baseColor, Color _stateColor)
	{
		//IL_0000: Unknown result type (might be due to invalid IL or missing references)
		//IL_000d: Unknown result type (might be due to invalid IL or missing references)
		//IL_001d: Unknown result type (might be due to invalid IL or missing references)
		//IL_003c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0041: Unknown result type (might be due to invalid IL or missing references)
		//IL_0045: Unknown result type (might be due to invalid IL or missing references)
		//IL_0050: Unknown result type (might be due to invalid IL or missing references)
		float num = default;
		float num2 = default;
		float num3 = default;
		Color.RGBToHSV(_baseColor, ref num, ref num2, ref num3);
		float num4 = default;
		float num5 = default;
		float num6 = default;
		Color.RGBToHSV(eyeColorGreen, ref num4, ref num5, ref num6);
		float num7 = default;
		Color.RGBToHSV(_stateColor, ref num7, ref num6, ref num5);
		Color result = Color.HSVToRGB(Mathf.Repeat(num + num7 - num4, 1f), num2, num3, true);
		result.a = _baseColor.a;
		return result;
	}

	private void EyesOffInstant()
	{
		eyesOn = false;
		eyeFlickerOnTimer = -1f;
		eyeFlickerOffTimer = -1f;
	}

	private void EyeCountdownPulse()
	{
		eyeCountdownPulseTimer = 0f;
	}

	private void EyesTick()
	{
		//IL_018e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0194: Unknown result type (might be due to invalid IL or missing references)
		//IL_01a5: Unknown result type (might be due to invalid IL or missing references)
		//IL_01aa: Unknown result type (might be due to invalid IL or missing references)
		//IL_01b1: Unknown result type (might be due to invalid IL or missing references)
		//IL_01b7: Unknown result type (might be due to invalid IL or missing references)
		//IL_01c8: Unknown result type (might be due to invalid IL or missing references)
		//IL_01cd: Unknown result type (might be due to invalid IL or missing references)
		//IL_01e1: Unknown result type (might be due to invalid IL or missing references)
		//IL_01e7: Unknown result type (might be due to invalid IL or missing references)
		//IL_01ee: Unknown result type (might be due to invalid IL or missing references)
		//IL_01f3: Unknown result type (might be due to invalid IL or missing references)
		//IL_01f6: Unknown result type (might be due to invalid IL or missing references)
		//IL_01fc: Unknown result type (might be due to invalid IL or missing references)
		//IL_0203: Unknown result type (might be due to invalid IL or missing references)
		//IL_0208: Unknown result type (might be due to invalid IL or missing references)
		//IL_023e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0240: Unknown result type (might be due to invalid IL or missing references)
		float num = (eyesOn ? 1f : 0f);
		if (eyeFlickerOnTimer >= 0f)
		{
			eyeFlickerOnTimer += Time.deltaTime;
			float num2 = Mathf.Clamp01(eyeFlickerOnTimer / eyeFlickerDuration);
			num = eyeFlickerOnCurve.Evaluate(num2);
			if (num2 >= 1f)
			{
				eyeFlickerOnTimer = -1f;
			}
		}
		else if (eyeFlickerOffTimer >= 0f)
		{
			eyeFlickerOffTimer += Time.deltaTime;
			float num3 = Mathf.Clamp01(eyeFlickerOffTimer / eyeFlickerDuration);
			num = 1f - eyeFlickerOffCurve.Evaluate(num3);
			if (num3 >= 1f)
			{
				eyeFlickerOffTimer = -1f;
			}
		}
		float num4 = 0f;
		if (eyeCountdownPulseTimer >= 0f)
		{
			eyeCountdownPulseTimer += Time.deltaTime;
			float num5 = Mathf.Clamp01(eyeCountdownPulseTimer / eyeCountdownPulseDuration);
			num4 = eyeCountdownPulseCurve.Evaluate(num5);
			num *= 1f + num4 * eyeCountdownPulseAmount;
			if (num5 >= 1f)
			{
				eyeCountdownPulseTimer = -1f;
			}
		}
		float targetFloat = eyeIrisSizeBase * eyeIrisScaleCurrent * (1f - num4 * eyeCountdownIrisPunch);
		float irisSize = SemiFunc.SpringFloatGet(eyeIrisSpring, targetFloat);
		eyeFireCurrent = Mathf.Lerp(eyeFireCurrent, eyeFireIntensityBase * eyeFireScaleCurrent, Time.deltaTime * eyeFireLerpSpeed);
		eyeFireColorCurrent = Color.Lerp(eyeFireColorCurrent, eyeFireColorTarget, Time.deltaTime * eyeFireLerpSpeed);
		eyeTubeColorCurrent = Color.Lerp(eyeTubeColorCurrent, eyeTubeColorTarget, Time.deltaTime * eyeFireLerpSpeed);
		float num6 = 1f - Mathf.Clamp01(num);
		Color eyeColor = Color.Lerp(eyeColorCurrent, eyeColorOff, num6);
		Color fireColor = Color.Lerp(eyeFireColorCurrent, eyeColorOff, num6);
		float glow = Mathf.LinearToGammaSpace(Mathf.Lerp(eyeEmissionIntensity * num, eyeOffGlow, num6));
		float fireIntensity = Mathf.Lerp(eyeFireCurrent * num, eyeOffFire, num6);
		EyesApply(eyeColor, fireColor, glow, irisSize, fireIntensity, num);
	}

	private void EyesApply(Color _eyeColor, Color _fireColor, float _glow, float _irisSize, float _fireIntensity, float _multiplier)
	{
		//IL_0000: Unknown result type (might be due to invalid IL or missing references)
		//IL_0002: Unknown result type (might be due to invalid IL or missing references)
		//IL_000e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0010: Unknown result type (might be due to invalid IL or missing references)
		//IL_001d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0023: Unknown result type (might be due to invalid IL or missing references)
		//IL_0089: Unknown result type (might be due to invalid IL or missing references)
		//IL_008a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0090: Unknown result type (might be due to invalid IL or missing references)
		//IL_0091: Unknown result type (might be due to invalid IL or missing references)
		//IL_0098: Unknown result type (might be due to invalid IL or missing references)
		//IL_009d: Unknown result type (might be due to invalid IL or missing references)
		//IL_00dc: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e8: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f5: Unknown result type (might be due to invalid IL or missing references)
		//IL_014b: Unknown result type (might be due to invalid IL or missing references)
		if (_eyeColor == eyeAppliedColor && _fireColor == eyeAppliedFireColor && eyeTubeColorCurrent == eyeAppliedTubeColor && Mathf.Abs(_glow - eyeAppliedGlow) < 0.001f && Mathf.Abs(_irisSize - eyeAppliedIrisSize) < 0.001f && Mathf.Abs(_fireIntensity - eyeAppliedFireIntensity) < 0.001f && Mathf.Abs(_multiplier - eyeAppliedMultiplier) < 0.001f)
		{
			return;
		}
		eyeAppliedColor = _eyeColor;
		eyeAppliedFireColor = _fireColor;
		eyeAppliedTubeColor = eyeTubeColorCurrent;
		eyeAppliedGlow = _glow;
		eyeAppliedIrisSize = _irisSize;
		eyeAppliedFireIntensity = _fireIntensity;
		eyeAppliedMultiplier = _multiplier;
		foreach (Material eyeMaterial in eyeMaterials)
		{
			eyeMaterial.SetColor(eyeColorID, _eyeColor);
			eyeMaterial.SetColor(fireColorID, _fireColor);
			eyeMaterial.SetColor(tubeColorID, eyeTubeColorCurrent);
			eyeMaterial.SetFloat(irisGlowID, _glow);
			eyeMaterial.SetFloat(apertureSizeID, _irisSize);
			eyeMaterial.SetFloat(fireIntensityID, _fireIntensity);
		}
		if (hasEyeLight)
		{
			eyeLight.color = _eyeColor;
			eyeLight.intensity = eyeLightIntensityMax * _multiplier;
			((Behaviour)eyeLight).enabled = _multiplier > 0.01f;
		}
	}

	private void EyeFlickerSoundTick()
	{
		if (!(eyeFlickerOnTimer >= 0f) && !(eyeFlickerOffTimer >= 0f))
		{
			eyeFlickerSoundTimer = 0f;
			return;
		}
		float num = ((eyeFlickerOnTimer >= 0f) ? eyeFlickerOnTimer : eyeFlickerOffTimer);
		float num2 = eyeFlickerSoundFrequency * eyeFlickerSoundCurve.Evaluate(Mathf.Clamp01(num / eyeFlickerDuration));
		if (num2 <= 0f)
		{
			eyeFlickerSoundTimer = 0f;
			return;
		}
		eyeFlickerSoundTimer -= Time.deltaTime;
		while (eyeFlickerSoundTimer <= 0f)
		{
			eyeFlickerSoundTimer += 1f / num2;
			soundEyeFlicker.Play(eyeVisionTransform);
		}
	}

	private void JawDriversBuild()
	{
		jawTopTransform = jawTopTransform.parent;
	}

	private void MouthMove(float _intensity, float _time)
	{
		mouthMoveIntensity = _intensity;
		mouthMoveTimer = _time;
	}

	private void MouthTick()
	{
		//IL_005e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0076: Unknown result type (might be due to invalid IL or missing references)
		//IL_007b: Unknown result type (might be due to invalid IL or missing references)
		if (hasJaw)
		{
			if (mouthMoveTimer > 0f)
			{
				mouthMoveTimer -= Time.deltaTime;
			}
			MouthAnimateTick();
			MouthRetargetTick();
			float num = Mathf.Lerp(mouthAnimFrom, mouthAnimTo, poseCurve.Evaluate(mouthAnimLerp));
			jawTopTransform.localRotation = jawTopStartRotation * Quaternion.Euler((0f - num) * mouthOpenAngleMax, 0f, 0f);
		}
	}

	private void MouthAnimateTick()
	{
		if (!(mouthAnimLerp >= 1f))
		{
			mouthAnimLerp += Time.deltaTime / mouthAnimDuration;
			if (mouthAnimLerp > 1f)
			{
				mouthAnimLerp = 1f;
			}
			if (!mouthEndSoundPlayed && mouthAnimLerp >= 0.8f)
			{
				mouthEndSoundPlayed = true;
				soundEndMove.Play(jawBottomTransform);
			}
		}
	}

	private void MouthRetargetTick()
	{
		if (mouthAnimLerp < 1f)
		{
			return;
		}
		if (mouthCooldownTimer > 0f)
		{
			mouthCooldownTimer -= Time.deltaTime;
			return;
		}
		float num = MouthDesiredOpenGet();
		if (!(Mathf.Abs(num - mouthAnimTo) <= mouthRetargetAmount))
		{
			mouthAnimFrom = mouthAnimTo;
			mouthAnimTo = num;
			mouthAnimLerp = 0f;
			mouthAnimDuration = Random.Range(poseDurationMin, poseDurationMax);
			mouthEndSoundPlayed = false;
			mouthCooldownTimer = Random.Range(poseLockMin, poseLockMax) / eyeFrequencyMultiplier;
			soundStartMove.Play(jawBottomTransform);
		}
	}

	private float MouthDesiredOpenGet()
	{
		float num = ttsTalkOpenTarget;
		if (mouthMoveTimer > 0f)
		{
			float num2 = Random.Range(0.2f, 1f) * mouthMoveIntensity;
			if (num2 > num)
			{
				num = num2;
			}
		}
		return num;
	}

	private void TTSSay(string _phrase)
	{
		//IL_0039: Unknown result type (might be due to invalid IL or missing references)
		//IL_003f: Unknown result type (might be due to invalid IL or missing references)
		if (SemiFunc.IsMasterClientOrSingleplayer() && !string.IsNullOrEmpty(_phrase))
		{
			if (CanRPC())
			{
				photonView.RPC("TTSSayRPC", (RpcTarget)0, new object[1] { _phrase });
			}
			else
			{
				TTSSayRPC(_phrase);
			}
		}
	}

	private void TTSSpeakLocal(string _phrase)
	{
		if (!hasTTS)
		{
			return;
		}
		string localeCode = "en-US";
		int num = -1;
		switch (_phrase)
		{
		case "three":
			num = 2;
			break;
		case "two":
			num = 1;
			break;
		case "one":
			num = 0;
			break;
		}
		int num2 = ttsPhrasesGreen.IndexOf(_phrase);
		if (num2 >= 0)
		{
			_phrase = ScriptedTTS.GetLine(ScriptedTTS.Group.MuseumGreen, num2, _phrase, out localeCode);
		}
		else
		{
			num2 = ttsPhrasesRed.IndexOf(_phrase);
			if (num2 >= 0)
			{
				_phrase = ScriptedTTS.GetLine(ScriptedTTS.Group.MuseumRed, num2, _phrase, out localeCode);
			}
		}
		if (num >= 0)
		{
			_phrase = ScriptedTTS.GetLine(ScriptedTTS.Group.MuseumCountdown, num, _phrase, out localeCode);
		}
		ttsSpeech.stop(allScheduled: true);
		string speechText = TTSFormatting.GetSpeechText(_phrase, localeCode);
		if (!string.IsNullOrWhiteSpace(speechText))
		{
			ttsSpeech.speak(ttsVoiceFrequency, (VoicingSource)0, speechText, bracketsAsPhonemes: true, _phrase);
		}
	}

	private void TTSPhraseLogic(List<string> _phrases, float _intervalMin, float _intervalMax)
	{
		if (_phrases.Count != 0)
		{
			if (ttsPhraseTimer > 0f)
			{
				ttsPhraseTimer -= Time.deltaTime;
				return;
			}
			ttsPhraseTimer = Random.Range(_intervalMin, _intervalMax);
			TTSSay(_phrases[Random.Range(0, _phrases.Count)]);
		}
	}

	private void TTSMouthLogic()
	{
		ttsTalkOpenTarget = 0f;
		if (hasTTS && Object.op_Implicit((Object)(object)ttsAudioSource) && ttsAudioSource.isPlaying)
		{
			ttsAudioSource.GetSpectrumData(ttsAudioSpectrum, 0, (FFTWindow)5);
			float num = Mathf.Max(ttsAudioSpectrum) * 2f;
			if (!(num <= 0.005f))
			{
				ttsTalkOpenTarget = Mathf.Clamp01(num * ttsMouthLoudnessMultiplier);
			}
		}
	}

	private void TTSMouthCreate()
	{
		//IL_0026: Unknown result type (might be due to invalid IL or missing references)
		//IL_002c: Expected Obj, but got Unknown
		//IL_0066: Unknown result type (might be due to invalid IL or missing references)
		//IL_0071: Unknown result type (might be due to invalid IL or missing references)
		//IL_0076: Unknown result type (might be due to invalid IL or missing references)
		//IL_0080: Unknown result type (might be due to invalid IL or missing references)
		Transform val = (Object.op_Implicit((Object)(object)jawBottomTransform) ? jawBottomTransform.parent : ((Component)this).transform);
		GameObject val2 = new GameObject("TTS Mouth");
		val2.SetActive(false);
		val2.transform.SetParent(val, false);
		if (Object.op_Implicit((Object)(object)jawTopTransform) && Object.op_Implicit((Object)(object)jawBottomTransform))
		{
			val2.transform.position = (jawTopTransform.position + jawBottomTransform.position) * 0.5f;
		}
		AudioSource val3 = val2.AddComponent<AudioSource>();
		val3.playOnAwake = false;
		val3.spatialBlend = 1f;
		val3.dopplerLevel = 0f;
		val3.priority = 0;
		val3.minDistance = 12f;
		val3.maxDistance = 50f;
		val3.rolloffMode = (AudioRolloffMode)1;
		val3.outputAudioMixerGroup = TTSMixerGroupGet();
		AudioEchoFilter val4 = val2.AddComponent<AudioEchoFilter>();
		val4.delay = 180f;
		val4.decayRatio = 0.35f;
		val4.wetMix = 0.45f;
		val4.dryMix = 1f;
		AudioLowPassLogic audioLowPassLogic = val2.AddComponent<AudioLowPassLogic>();
		audioLowPassLogic.ForceStart = true;
		audioLowPassLogic.AlwaysActive = true;
		val2.GetComponent<AudioLowPassFilter>().cutoffFrequency = 22000f;
		ttsSpeech = val2.AddComponent<Speech>();
		ttsSpeech.voiceBaseFrequency = ttsVoiceFrequency;
		ttsSpeech.msPerSpeechFrame = 12;
		val2.SetActive(true);
	}

	private AudioMixerGroup TTSMixerGroupGet()
	{
		GameObject val = Resources.Load<GameObject>("TTS");
		if (Object.op_Implicit((Object)(object)val))
		{
			return val.GetComponent<AudioSource>().outputAudioMixerGroup;
		}
		Debug.LogWarning((object)"mega semibot: could not load the player tts prefab, tts source has no mixer group", (Object)(object)this);
		return null;
	}

	private void GreenLightEyesLogic()
	{
		//IL_0042: Unknown result type (might be due to invalid IL or missing references)
		//IL_004d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0098: Unknown result type (might be due to invalid IL or missing references)
		//IL_009d: Unknown result type (might be due to invalid IL or missing references)
		if (!SemiFunc.PerSecond(5f, (Object)(object)this))
		{
			return;
		}
		PlayerAvatar playerAvatar = null;
		float num = 0f;
		foreach (PlayerAvatar item in SemiFunc.PlayerGetList())
		{
			if (!item.isDisabled && PlayerInBotRoom(item))
			{
				float num2 = Vector3.Distance(eyeVisionTransform.position, ((Component)item).transform.position);
				if (!Object.op_Implicit((Object)(object)playerAvatar) || num2 < num)
				{
					playerAvatar = item;
					num = num2;
				}
			}
		}
		if (Object.op_Implicit((Object)(object)playerAvatar))
		{
			lookTargetPosition = playerAvatar.PlayerVisionTarget.VisionTransform.position;
			lookTargetActive = true;
		}
		else
		{
			lookTargetActive = false;
		}
	}

	private void CountdownLogic()
	{
		if (countdownIndex == 0 && stateTimer >= 0f)
		{
			CountdownStep(soundThree, "three");
		}
		if (countdownIndex == 1 && stateTimer >= 1f)
		{
			CountdownStep(soundTwo, "two");
		}
		if (countdownIndex == 2 && stateTimer >= 2f)
		{
			CountdownStep(soundOne, "one");
		}
	}

	private void CountdownStep(Sound _countSound, string _countWord)
	{
		//IL_005e: Unknown result type (might be due to invalid IL or missing references)
		countdownIndex++;
		_countSound.Play(audioPositionTransform);
		TTSSpeakLocal(_countWord);
		EyeCountdownPulse();
		MouthMove(1f, 0.4f);
		ShakeAll(0.1f);
		ScreenShakeImpact(eyeVisionTransform.position, 1f, 0.1f);
	}

	private void MoveTrackersBuild()
	{
		//IL_0101: Unknown result type (might be due to invalid IL or missing references)
		//IL_0109: Unknown result type (might be due to invalid IL or missing references)
		//IL_010f: Unknown result type (might be due to invalid IL or missing references)
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0064: Unknown result type (might be due to invalid IL or missing references)
		//IL_0070: Unknown result type (might be due to invalid IL or missing references)
		//IL_0075: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ad: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b2: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c8: Unknown result type (might be due to invalid IL or missing references)
		//IL_0158: Unknown result type (might be due to invalid IL or missing references)
		//IL_015d: Unknown result type (might be due to invalid IL or missing references)
		moveTrackers.Clear();
		foreach (PlayerAvatar item in SemiFunc.PlayerGetList())
		{
			if (!item.isDisabled && PlayerInBotRoom(item))
			{
				MegaBotMoveTracker megaBotMoveTracker = new MegaBotMoveTracker();
				megaBotMoveTracker.player = item;
				megaBotMoveTracker.physObject = item.tumble.physGrabObject;
				megaBotMoveTracker.lastPosition = ((Component)item).transform.position;
				megaBotMoveTracker.lastRotation = ((Component)item).transform.rotation;
				megaBotMoveTracker.lastTumbling = item.isTumbling;
				megaBotMoveTracker.lastCrouching = item.isCrouching;
				megaBotMoveTracker.lastCrawling = item.isCrawling;
				if (item.isTumbling)
				{
					megaBotMoveTracker.lastPosition = megaBotMoveTracker.physObject.centerPoint;
					megaBotMoveTracker.lastRotation = ((Component)megaBotMoveTracker.physObject).transform.rotation;
				}
				moveTrackers.Add(megaBotMoveTracker);
			}
		}
		foreach (PhysGrabObject item2 in SemiFunc.PhysGrabObjectGetAllWithinRange(targetRange, eyeVisionTransform.position))
		{
			if (Object.op_Implicit((Object)(object)item2.rb) && !Object.op_Implicit((Object)(object)((Component)item2).GetComponentInParent<PlayerTumble>()))
			{
				MegaBotMoveTracker megaBotMoveTracker2 = new MegaBotMoveTracker();
				megaBotMoveTracker2.physObject = item2;
				megaBotMoveTracker2.lastPosition = item2.centerPoint;
				if (item2.isEnemy)
				{
					megaBotMoveTracker2.enemyParent = ((Component)item2).GetComponentInParent<EnemyParent>();
				}
				moveTrackers.Add(megaBotMoveTracker2);
			}
		}
	}

	private void MoveTrackersAdoptPlayersLogic()
	{
		if (!SemiFunc.PerSecond(5f, (Object)(object)this))
		{
			return;
		}
		foreach (PlayerAvatar item in SemiFunc.PlayerGetList())
		{
			if (!item.isDisabled && PlayerInBotRoom(item) && !MoveTrackerForPlayerExists(item))
			{
				MegaBotMoveTracker megaBotMoveTracker = new MegaBotMoveTracker();
				megaBotMoveTracker.player = item;
				megaBotMoveTracker.physObject = item.tumble.physGrabObject;
				TrackerPlayerReseed(megaBotMoveTracker);
				moveTrackers.Add(megaBotMoveTracker);
			}
		}
	}

	private bool MoveTrackerForPlayerExists(PlayerAvatar _player)
	{
		foreach (MegaBotMoveTracker moveTracker in moveTrackers)
		{
			if ((Object)(object)moveTracker.player == (Object)(object)_player)
			{
				return true;
			}
		}
		return false;
	}

	private void MoveTrackersLogic()
	{
		//IL_007f: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c5: Unknown result type (might be due to invalid IL or missing references)
		MegaBotMoveTracker megaBotMoveTracker = null;
		MegaBotMoveTracker megaBotMoveTracker2 = null;
		MegaBotMoveTracker megaBotMoveTracker3 = null;
		foreach (MegaBotMoveTracker moveTracker in moveTrackers)
		{
			if ((Object.op_Implicit((Object)(object)moveTracker.player) && moveTracker.player.isDisabled) || (!Object.op_Implicit((Object)(object)moveTracker.player) && !Object.op_Implicit((Object)(object)moveTracker.physObject)))
			{
				continue;
			}
			if (Object.op_Implicit((Object)(object)moveTracker.player))
			{
				if (VisionBlocked(moveTracker.player.PlayerVisionTarget.VisionTransform.position))
				{
					TrackerPlayerReseed(moveTracker);
				}
				else if (TrackerPlayerMoving(moveTracker) && megaBotMoveTracker == null)
				{
					megaBotMoveTracker = moveTracker;
				}
				continue;
			}
			if (!TrackerPhysObjectMoving(moveTracker) || VisionBlocked(moveTracker.physObject.centerPoint))
			{
				moveTracker.movedTime = 0f;
				continue;
			}
			moveTracker.movedTime += Time.deltaTime;
			if (moveTracker.physObject.isEnemy)
			{
				if (EnemyGrabAllowed() && EnemyParentAlive(moveTracker.enemyParent) && moveTracker.movedTime >= enemyMoveTriggerTime && megaBotMoveTracker2 == null)
				{
					megaBotMoveTracker2 = moveTracker;
				}
			}
			else if (moveTracker.movedTime >= physMoveTriggerTime && megaBotMoveTracker3 == null)
			{
				megaBotMoveTracker3 = moveTracker;
			}
		}
		MegaBotMoveTracker megaBotMoveTracker4 = megaBotMoveTracker;
		if (megaBotMoveTracker4 == null)
		{
			megaBotMoveTracker4 = megaBotMoveTracker2;
		}
		if (megaBotMoveTracker4 == null)
		{
			megaBotMoveTracker4 = megaBotMoveTracker3;
		}
		if (megaBotMoveTracker4 != null && hasGrabber)
		{
			TargetSet(megaBotMoveTracker4.physObject, megaBotMoveTracker4.player);
			StateSet(State.GrabStart);
		}
	}

	private bool TrackerPlayerMoving(MegaBotMoveTracker _tracker)
	{
		//IL_000d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0012: Unknown result type (might be due to invalid IL or missing references)
		//IL_0019: Unknown result type (might be due to invalid IL or missing references)
		//IL_001e: Unknown result type (might be due to invalid IL or missing references)
		//IL_003a: Unknown result type (might be due to invalid IL or missing references)
		//IL_003f: Unknown result type (might be due to invalid IL or missing references)
		//IL_004b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0050: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b8: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ba: Unknown result type (might be due to invalid IL or missing references)
		//IL_00bf: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c4: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ce: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d3: Unknown result type (might be due to invalid IL or missing references)
		//IL_011b: Unknown result type (might be due to invalid IL or missing references)
		//IL_011c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0122: Unknown result type (might be due to invalid IL or missing references)
		//IL_0123: Unknown result type (might be due to invalid IL or missing references)
		PlayerAvatar player = _tracker.player;
		Vector3 val = ((Component)player).transform.position;
		Quaternion rotation = ((Component)player).transform.rotation;
		if (player.isTumbling && Object.op_Implicit((Object)(object)_tracker.physObject))
		{
			val = _tracker.physObject.centerPoint;
			rotation = ((Component)_tracker.physObject).transform.rotation;
		}
		if (player.isTumbling != _tracker.lastTumbling)
		{
			TrackerPlayerReseed(_tracker);
			return false;
		}
		if (player.isMoving && !player.isTumbling)
		{
			return true;
		}
		bool num = player.isCrouching != _tracker.lastCrouching || player.isCrawling != _tracker.lastCrawling;
		_tracker.lastCrouching = player.isCrouching;
		_tracker.lastCrawling = player.isCrawling;
		if (num)
		{
			return true;
		}
		Vector3 val2 = val - _tracker.lastPosition;
		float magnitude = val2.magnitude;
		float num2 = Quaternion.Angle(_tracker.lastRotation, rotation);
		if (magnitude > playerMoveDistanceThreshold)
		{
			return true;
		}
		if (num2 > playerTurnAngleThreshold)
		{
			return true;
		}
		_tracker.moveWindowTimer += Time.deltaTime;
		if (_tracker.moveWindowTimer >= playerMoveWindowTime)
		{
			_tracker.moveWindowTimer = 0f;
			_tracker.lastPosition = val;
			_tracker.lastRotation = rotation;
		}
		return false;
	}

	private void TrackerPlayerReseed(MegaBotMoveTracker _tracker)
	{
		//IL_000e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0013: Unknown result type (might be due to invalid IL or missing references)
		//IL_001f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_0045: Unknown result type (might be due to invalid IL or missing references)
		//IL_004a: Unknown result type (might be due to invalid IL or missing references)
		//IL_005b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0060: Unknown result type (might be due to invalid IL or missing references)
		PlayerAvatar player = _tracker.player;
		_tracker.lastPosition = ((Component)player).transform.position;
		_tracker.lastRotation = ((Component)player).transform.rotation;
		if (player.isTumbling && Object.op_Implicit((Object)(object)_tracker.physObject))
		{
			_tracker.lastPosition = _tracker.physObject.centerPoint;
			_tracker.lastRotation = ((Component)_tracker.physObject).transform.rotation;
		}
		_tracker.lastTumbling = player.isTumbling;
		_tracker.lastCrouching = player.isCrouching;
		_tracker.lastCrawling = player.isCrawling;
		_tracker.moveWindowTimer = 0f;
		_tracker.movedTime = 0f;
	}

	private bool TrackerPhysObjectMoving(MegaBotMoveTracker _tracker)
	{
		//IL_0006: Unknown result type (might be due to invalid IL or missing references)
		//IL_000b: Unknown result type (might be due to invalid IL or missing references)
		//IL_000c: Unknown result type (might be due to invalid IL or missing references)
		//IL_000e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0013: Unknown result type (might be due to invalid IL or missing references)
		//IL_0018: Unknown result type (might be due to invalid IL or missing references)
		//IL_0027: Unknown result type (might be due to invalid IL or missing references)
		//IL_0028: Unknown result type (might be due to invalid IL or missing references)
		Vector3 centerPoint = _tracker.physObject.centerPoint;
		Vector3 val = centerPoint - _tracker.lastPosition;
		float num = val.magnitude / Time.deltaTime;
		_tracker.lastPosition = centerPoint;
		return num > physMoveSpeedThreshold;
	}

	private void LookEyesBuild()
	{
		LookEyeAdd(eyeLeftTransform);
		LookEyeAdd(eyeRightTransform);
	}

	private void LookEyeAdd(Transform _eyeBone)
	{
		if (Object.op_Implicit((Object)(object)_eyeBone))
		{
			MegaBotEye megaBotEye = new MegaBotEye();
			megaBotEye.bone = _eyeBone;
			megaBotEye.cooldownTimer = Random.Range(0f, poseLockMax / eyeFrequencyMultiplier);
			lookEyes.Add(megaBotEye);
		}
	}

	private void EyeLookTick()
	{
		foreach (MegaBotEye lookEye in lookEyes)
		{
			EyeAnimateTick(lookEye);
			EyeRetargetTick(lookEye);
		}
	}

	private void EyeAnimateTick(MegaBotEye _eye)
	{
		//IL_0046: Unknown result type (might be due to invalid IL or missing references)
		//IL_004c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0062: Unknown result type (might be due to invalid IL or missing references)
		if (!(_eye.animLerp >= 1f))
		{
			_eye.animLerp += Time.deltaTime / _eye.animDuration;
			if (_eye.animLerp > 1f)
			{
				_eye.animLerp = 1f;
			}
			_eye.bone.localRotation = Quaternion.SlerpUnclamped(_eye.animFrom, _eye.animTo, poseCurve.Evaluate(_eye.animLerp));
			if (!_eye.endSoundPlayed && _eye.animLerp >= 0.8f)
			{
				_eye.endSoundPlayed = true;
				soundEyeEndMove.Play(_eye.bone);
			}
		}
	}

	private void EyeRetargetTick(MegaBotEye _eye)
	{
		//IL_0035: Unknown result type (might be due to invalid IL or missing references)
		//IL_003a: Unknown result type (might be due to invalid IL or missing references)
		//IL_003c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0041: Unknown result type (might be due to invalid IL or missing references)
		//IL_0057: Unknown result type (might be due to invalid IL or missing references)
		//IL_005c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0062: Unknown result type (might be due to invalid IL or missing references)
		//IL_0063: Unknown result type (might be due to invalid IL or missing references)
		if (_eye.animLerp < 1f)
		{
			return;
		}
		if (_eye.cooldownTimer > 0f)
		{
			_eye.cooldownTimer -= Time.deltaTime;
			return;
		}
		Quaternion val = EyeLookRotationGet(_eye.bone);
		if (!(Quaternion.Angle(_eye.animTo, val) <= eyeRetargetAngle))
		{
			_eye.animFrom = _eye.bone.localRotation;
			_eye.animTo = val;
			_eye.animLerp = 0f;
			_eye.animDuration = Random.Range(poseDurationMin, poseDurationMax);
			_eye.endSoundPlayed = false;
			_eye.cooldownTimer = Random.Range(poseLockMin, poseLockMax) / eyeFrequencyMultiplier;
			soundEyeStartMove.Play(_eye.bone);
		}
	}

	private Quaternion EyeLookRotationGet(Transform _eyeBone)
	{
		//IL_000f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0015: Unknown result type (might be due to invalid IL or missing references)
		//IL_001a: Unknown result type (might be due to invalid IL or missing references)
		//IL_001f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0008: Unknown result type (might be due to invalid IL or missing references)
		//IL_0034: Unknown result type (might be due to invalid IL or missing references)
		//IL_003b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0046: Unknown result type (might be due to invalid IL or missing references)
		//IL_004b: Unknown result type (might be due to invalid IL or missing references)
		//IL_004c: Unknown result type (might be due to invalid IL or missing references)
		//IL_004d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0052: Unknown result type (might be due to invalid IL or missing references)
		//IL_0059: Unknown result type (might be due to invalid IL or missing references)
		//IL_005e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0063: Unknown result type (might be due to invalid IL or missing references)
		//IL_0064: Unknown result type (might be due to invalid IL or missing references)
		//IL_0069: Unknown result type (might be due to invalid IL or missing references)
		//IL_006c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0071: Unknown result type (might be due to invalid IL or missing references)
		//IL_0072: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Unknown result type (might be due to invalid IL or missing references)
		//IL_008f: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ac: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d7: Unknown result type (might be due to invalid IL or missing references)
		//IL_010b: Unknown result type (might be due to invalid IL or missing references)
		if (!lookTargetActive)
		{
			return Quaternion.identity;
		}
		Vector3 val = lookTargetPosition - _eyeBone.position;
		if (val.sqrMagnitude < 0.001f)
		{
			return Quaternion.identity;
		}
		val = SemiFunc.ClampDirection(val, _eyeBone.parent.forward, eyeConeClamp);
		Quaternion val2 = Quaternion.LookRotation(val);
		Quaternion val3 = Quaternion.Inverse(_eyeBone.parent.rotation) * val2;
		Vector3 eulerAngles = val3.eulerAngles;
		if (eulerAngles.x > 180f)
		{
			eulerAngles.x -= 360f;
		}
		if (eulerAngles.y > 180f)
		{
			eulerAngles.y -= 360f;
		}
		float num = Mathf.Clamp(eulerAngles.x + Random.Range(0f - eyeNoiseDegrees, eyeNoiseDegrees), 0f - eyePitchClamp, eyePitchClamp);
		float num2 = Mathf.Clamp(eulerAngles.y + Random.Range(0f - eyeNoiseDegrees, eyeNoiseDegrees), 0f - eyeYawClamp, eyeYawClamp);
		return Quaternion.Euler(num, num2, 0f);
	}

	private void ShakeCentersBuild()
	{
		//IL_0030: Unknown result type (might be due to invalid IL or missing references)
		//IL_0035: Unknown result type (might be due to invalid IL or missing references)
		//IL_003c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0041: Unknown result type (might be due to invalid IL or missing references)
		//IL_0048: Unknown result type (might be due to invalid IL or missing references)
		//IL_004d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0059: Unknown result type (might be due to invalid IL or missing references)
		//IL_005e: Unknown result type (might be due to invalid IL or missing references)
		foreach (Transform shakeParent in shakeParents)
		{
			if (Object.op_Implicit((Object)(object)shakeParent))
			{
				MegaBotShakeCenter megaBotShakeCenter = new MegaBotShakeCenter();
				megaBotShakeCenter.transform = shakeParent;
				megaBotShakeCenter.baseLocalPosition = shakeParent.localPosition;
				megaBotShakeCenter.previousPosition = shakeParent.position;
				megaBotShakeCenter.baseLocalRotation = shakeParent.localRotation;
				megaBotShakeCenter.previousParentRotation = shakeParent.parent.rotation;
				megaBotShakeCenter.nested = ShakeCenterIsNested(shakeParent);
				megaBotShakeCenter.vibrationSeed = Random.Range(0f, 1000f);
				shakeCenters.Add(megaBotShakeCenter);
			}
		}
	}

	private bool ShakeCenterIsNested(Transform _shakeParent)
	{
		Transform parent = _shakeParent.parent;
		while (Object.op_Implicit((Object)(object)parent))
		{
			if (shakeParents.Contains(parent))
			{
				return true;
			}
			parent = parent.parent;
		}
		return false;
	}

	private void ShakeTick()
	{
		if (Time.deltaTime <= 0f)
		{
			return;
		}
		ShakeVibrationStrengthTick();
		foreach (MegaBotShakeCenter shakeCenter in shakeCenters)
		{
			ShakeCenterPositionTick(shakeCenter);
			ShakeCenterRotationTick(shakeCenter);
		}
	}

	private void ShakeVibrationStrengthTick()
	{
		//IL_000f: Unknown result type (might be due to invalid IL or missing references)
		if (hasPlatform)
		{
			float y = platformTransform.localEulerAngles.y;
			float num = Mathf.DeltaAngle(shakeVibrationYawPrevious, y);
			shakeVibrationYawPrevious = y;
			float num2 = Mathf.Clamp01(Mathf.Abs(num) / Time.deltaTime / Mathf.Max(shakeVibrationFullAngularSpeed, 0.01f));
			shakeVibrationStrength = Mathf.Lerp(shakeVibrationStrength, num2, Time.deltaTime * shakeVibrationResponse);
		}
	}

	private Vector3 ShakeVibrationSampleGet(float _seed)
	{
		//IL_0040: Unknown result type (might be due to invalid IL or missing references)
		//IL_004a: Unknown result type (might be due to invalid IL or missing references)
		float num = Time.time * shakeVibrationFrequency;
		return new Vector3(Mathf.PerlinNoise(num, _seed) - 0.5f, Mathf.PerlinNoise(num, _seed + 17.3f) - 0.5f, Mathf.PerlinNoise(num, _seed + 39.7f) - 0.5f) * 2f;
	}

	private Vector3 ShakeCenterVibrationPositionGet(MegaBotShakeCenter _center)
	{
		//IL_001a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0025: Unknown result type (might be due to invalid IL or missing references)
		//IL_0030: Unknown result type (might be due to invalid IL or missing references)
		//IL_000d: Unknown result type (might be due to invalid IL or missing references)
		if (shakeVibrationStrength < 0.01f)
		{
			return Vector3.zero;
		}
		return ShakeVibrationSampleGet(_center.vibrationSeed) * shakeVibrationAmount * shakeVibrationStrength;
	}

	private Vector3 ShakeCenterVibrationRotationGet(MegaBotShakeCenter _center)
	{
		//IL_0020: Unknown result type (might be due to invalid IL or missing references)
		//IL_002b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0036: Unknown result type (might be due to invalid IL or missing references)
		//IL_000d: Unknown result type (might be due to invalid IL or missing references)
		if (shakeVibrationStrength < 0.01f)
		{
			return Vector3.zero;
		}
		return ShakeVibrationSampleGet(_center.vibrationSeed + 63.1f) * shakeVibrationRotationAmount * shakeVibrationStrength;
	}

	private void ShakeCenterPositionTick(MegaBotShakeCenter _center)
	{
		//IL_000c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0011: Unknown result type (might be due to invalid IL or missing references)
		//IL_0016: Unknown result type (might be due to invalid IL or missing references)
		//IL_0017: Unknown result type (might be due to invalid IL or missing references)
		//IL_0019: Unknown result type (might be due to invalid IL or missing references)
		//IL_001e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0028: Unknown result type (might be due to invalid IL or missing references)
		//IL_002d: Unknown result type (might be due to invalid IL or missing references)
		//IL_002f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0030: Unknown result type (might be due to invalid IL or missing references)
		//IL_0035: Unknown result type (might be due to invalid IL or missing references)
		//IL_0037: Unknown result type (might be due to invalid IL or missing references)
		//IL_003c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0041: Unknown result type (might be due to invalid IL or missing references)
		//IL_0043: Unknown result type (might be due to invalid IL or missing references)
		//IL_0044: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00cd: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d2: Unknown result type (might be due to invalid IL or missing references)
		//IL_0109: Unknown result type (might be due to invalid IL or missing references)
		//IL_0119: Unknown result type (might be due to invalid IL or missing references)
		//IL_011c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0121: Unknown result type (might be due to invalid IL or missing references)
		//IL_0126: Unknown result type (might be due to invalid IL or missing references)
		//IL_012b: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e9: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f0: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f5: Unknown result type (might be due to invalid IL or missing references)
		//IL_00fc: Unknown result type (might be due to invalid IL or missing references)
		//IL_00fd: Unknown result type (might be due to invalid IL or missing references)
		//IL_0066: Unknown result type (might be due to invalid IL or missing references)
		//IL_006b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0072: Unknown result type (might be due to invalid IL or missing references)
		//IL_0082: Unknown result type (might be due to invalid IL or missing references)
		//IL_0087: Unknown result type (might be due to invalid IL or missing references)
		//IL_008c: Unknown result type (might be due to invalid IL or missing references)
		Vector3 val = _center.transform.parent.TransformPoint(_center.baseLocalPosition);
		Vector3 val2 = (val - _center.previousPosition) / Time.deltaTime;
		_center.previousPosition = val;
		Vector3 val3 = val2 - _center.fakeVelocity;
		_center.fakeVelocity = val2;
		if (!_center.nested && val3.sqrMagnitude > 0.0001f)
		{
			SpringVector3 spring = _center.spring;
			spring.springVelocity -= val3 * shakeVelocityInfluence * shakeSpringSettings.speed;
		}
		_center.spring.speed = shakeSpringSettings.speed;
		_center.spring.damping = shakeSpringSettings.damping;
		Vector3 val4 = SemiFunc.SpringVector3Get(_center.spring, Vector3.zero);
		if (val4.sqrMagnitude > shakeOffsetMax * shakeOffsetMax)
		{
			val4 = Vector3.ClampMagnitude(val4, shakeOffsetMax);
			_center.spring.lastPosition = val4;
		}
		_center.transform.localPosition = _center.baseLocalPosition + _center.transform.parent.InverseTransformVector(val4 + ShakeCenterVibrationPositionGet(_center));
	}

	private void ShakeCenterRotationTick(MegaBotShakeCenter _center)
	{
		//IL_000b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0010: Unknown result type (might be due to invalid IL or missing references)
		//IL_0011: Unknown result type (might be due to invalid IL or missing references)
		//IL_0013: Unknown result type (might be due to invalid IL or missing references)
		//IL_0018: Unknown result type (might be due to invalid IL or missing references)
		//IL_001d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0022: Unknown result type (might be due to invalid IL or missing references)
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_0025: Unknown result type (might be due to invalid IL or missing references)
		//IL_0045: Unknown result type (might be due to invalid IL or missing references)
		//IL_004d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0052: Unknown result type (might be due to invalid IL or missing references)
		//IL_0054: Unknown result type (might be due to invalid IL or missing references)
		//IL_0057: Unknown result type (might be due to invalid IL or missing references)
		//IL_005c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0061: Unknown result type (might be due to invalid IL or missing references)
		//IL_0064: Unknown result type (might be due to invalid IL or missing references)
		//IL_0066: Unknown result type (might be due to invalid IL or missing references)
		//IL_00fa: Unknown result type (might be due to invalid IL or missing references)
		//IL_0104: Unknown result type (might be due to invalid IL or missing references)
		//IL_0109: Unknown result type (might be due to invalid IL or missing references)
		//IL_0144: Unknown result type (might be due to invalid IL or missing references)
		//IL_0149: Unknown result type (might be due to invalid IL or missing references)
		//IL_014d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0152: Unknown result type (might be due to invalid IL or missing references)
		//IL_0157: Unknown result type (might be due to invalid IL or missing references)
		//IL_015c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0121: Unknown result type (might be due to invalid IL or missing references)
		//IL_0129: Unknown result type (might be due to invalid IL or missing references)
		//IL_012e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0136: Unknown result type (might be due to invalid IL or missing references)
		//IL_0138: Unknown result type (might be due to invalid IL or missing references)
		//IL_008c: Unknown result type (might be due to invalid IL or missing references)
		//IL_008e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0093: Unknown result type (might be due to invalid IL or missing references)
		//IL_009c: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a1: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a9: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b9: Unknown result type (might be due to invalid IL or missing references)
		//IL_00be: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c3: Unknown result type (might be due to invalid IL or missing references)
		Quaternion rotation = _center.transform.parent.rotation;
		Quaternion val = rotation * Quaternion.Inverse(_center.previousParentRotation);
		_center.previousParentRotation = rotation;
		float num = default;
		Vector3 val2 = default;
		val.ToAngleAxis(ref num, ref val2);
		if (num > 180f)
		{
			num -= 360f;
		}
		Vector3 val3 = val2 * (num / Time.deltaTime);
		Vector3 val4 = val3 - _center.fakeAngularVelocity;
		_center.fakeAngularVelocity = val3;
		if (!_center.nested && val4.sqrMagnitude > 0.01f)
		{
			Vector3 val5 = _center.transform.parent.InverseTransformDirection(val4);
			SpringVector3 rotationSpring = _center.rotationSpring;
			rotationSpring.springVelocity -= val5 * shakeRotationInfluence * shakeRotationSpringSettings.speed;
		}
		_center.rotationSpring.speed = shakeRotationSpringSettings.speed;
		_center.rotationSpring.damping = shakeRotationSpringSettings.damping;
		Vector3 val6 = SemiFunc.SpringVector3Get(_center.rotationSpring, Vector3.zero);
		if (val6.sqrMagnitude > shakeRotationMax * shakeRotationMax)
		{
			val6 = Vector3.ClampMagnitude(val6, shakeRotationMax);
			_center.rotationSpring.lastPosition = val6;
		}
		_center.transform.localRotation = _center.baseLocalRotation * Quaternion.Euler(val6 + ShakeCenterVibrationRotationGet(_center));
	}

	private void ScreenShake(Vector3 _position, float _strength, float _duration)
	{
		//IL_0000: Unknown result type (might be due to invalid IL or missing references)
		SemiFunc.CameraShakeDistance(_position, _strength, _duration, screenShakeDistanceMin, screenShakeDistanceMax);
	}

	private void ScreenShakeImpact(Vector3 _position, float _strength, float _duration)
	{
		//IL_0000: Unknown result type (might be due to invalid IL or missing references)
		SemiFunc.CameraShakeImpactDistance(_position, _strength, _duration, screenShakeDistanceMin, screenShakeDistanceMax);
	}

	public void ShakeAll(float _amount)
	{
		//IL_001c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0021: Unknown result type (might be due to invalid IL or missing references)
		//IL_0027: Unknown result type (might be due to invalid IL or missing references)
		//IL_0037: Unknown result type (might be due to invalid IL or missing references)
		//IL_003c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0041: Unknown result type (might be due to invalid IL or missing references)
		//IL_004c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0051: Unknown result type (might be due to invalid IL or missing references)
		//IL_0057: Unknown result type (might be due to invalid IL or missing references)
		//IL_0062: Unknown result type (might be due to invalid IL or missing references)
		//IL_0072: Unknown result type (might be due to invalid IL or missing references)
		//IL_0077: Unknown result type (might be due to invalid IL or missing references)
		//IL_007c: Unknown result type (might be due to invalid IL or missing references)
		foreach (MegaBotShakeCenter shakeCenter in shakeCenters)
		{
			SpringVector3 spring = shakeCenter.spring;
			spring.springVelocity += Random.insideUnitSphere * _amount * shakeSpringSettings.speed;
			SpringVector3 rotationSpring = shakeCenter.rotationSpring;
			rotationSpring.springVelocity += Random.insideUnitSphere * _amount * shakeRotationEventScale * shakeRotationSpringSettings.speed;
		}
		FoliageSwayKick(_amount);
	}

	private void FoliageSwayPartsBuild()
	{
		//IL_003a: Unknown result type (might be due to invalid IL or missing references)
		//IL_003f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0048: Unknown result type (might be due to invalid IL or missing references)
		//IL_004d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0057: Unknown result type (might be due to invalid IL or missing references)
		//IL_005c: Unknown result type (might be due to invalid IL or missing references)
		Transform[] componentsInChildren = ((Component)this).GetComponentsInChildren<Transform>(true);
		foreach (Transform val in componentsInChildren)
		{
			MegaBotFoliageSwaySettings megaBotFoliageSwaySettings = FoliageSwaySettingsGet(((Object)val).name);
			if (megaBotFoliageSwaySettings != null)
			{
				MegaBotFoliageSwayPart megaBotFoliageSwayPart = new MegaBotFoliageSwayPart();
				megaBotFoliageSwayPart.transform = val;
				megaBotFoliageSwayPart.settings = megaBotFoliageSwaySettings;
				megaBotFoliageSwayPart.baseLocalRotation = val.localRotation;
				megaBotFoliageSwayPart.tipLocalPosition = FoliageSwayTipLocalGet(val);
				megaBotFoliageSwayPart.previousTipPosition = FoliageSwayBaseTipPositionGet(megaBotFoliageSwayPart);
				foliageSwayParts.Add(megaBotFoliageSwayPart);
			}
		}
	}

	private MegaBotFoliageSwaySettings FoliageSwaySettingsGet(string _transformName)
	{
		if (_transformName.StartsWith("Foilage Small"))
		{
			return foliageSwaySmall;
		}
		if (_transformName.StartsWith("Foilage Medium"))
		{
			return foliageSwayMedium;
		}
		if (_transformName.StartsWith("Foilage Rigid"))
		{
			return foliageSwayRigid;
		}
		return null;
	}

	private Vector3 FoliageSwayTipLocalGet(Transform _foliage)
	{
		//IL_005d: Unknown result type (might be due to invalid IL or missing references)
		//IL_002d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0032: Unknown result type (might be due to invalid IL or missing references)
		Transform[] componentsInChildren = ((Component)_foliage).GetComponentsInChildren<Transform>(true);
		foreach (Transform val in componentsInChildren)
		{
			if (!((Object)(object)val == (Object)(object)_foliage) && ((Object)val).name.StartsWith("Foilage Tip"))
			{
				return _foliage.InverseTransformPoint(val.position);
			}
		}
		Debug.LogWarning((object)("mega semibot: " + ((Object)_foliage).name + " has no foilage tip child, swaying around a fake 1m lever"), (Object)(object)_foliage);
		return Vector3.up;
	}

	private Vector3 FoliageSwayBaseTipPositionGet(MegaBotFoliageSwayPart _part)
	{
		//IL_0006: Unknown result type (might be due to invalid IL or missing references)
		//IL_000c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0017: Unknown result type (might be due to invalid IL or missing references)
		//IL_001d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0022: Unknown result type (might be due to invalid IL or missing references)
		//IL_0027: Unknown result type (might be due to invalid IL or missing references)
		//IL_002c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0031: Unknown result type (might be due to invalid IL or missing references)
		//IL_003d: Unknown result type (might be due to invalid IL or missing references)
		//IL_003e: Unknown result type (might be due to invalid IL or missing references)
		Vector3 val = _part.transform.localPosition + _part.baseLocalRotation * Vector3.Scale(_part.transform.localScale, _part.tipLocalPosition);
		return _part.transform.parent.TransformPoint(val);
	}

	private void FoliageSwayTick()
	{
		if (Time.deltaTime <= 0f)
		{
			return;
		}
		foreach (MegaBotFoliageSwayPart foliageSwayPart in foliageSwayParts)
		{
			FoliageSwayPartTick(foliageSwayPart);
		}
	}

	private void FoliageSwayPartTick(MegaBotFoliageSwayPart _part)
	{
		//IL_0002: Unknown result type (might be due to invalid IL or missing references)
		//IL_0007: Unknown result type (might be due to invalid IL or missing references)
		//IL_0008: Unknown result type (might be due to invalid IL or missing references)
		//IL_000a: Unknown result type (might be due to invalid IL or missing references)
		//IL_000f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0019: Unknown result type (might be due to invalid IL or missing references)
		//IL_001e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0020: Unknown result type (might be due to invalid IL or missing references)
		//IL_0021: Unknown result type (might be due to invalid IL or missing references)
		//IL_0026: Unknown result type (might be due to invalid IL or missing references)
		//IL_0028: Unknown result type (might be due to invalid IL or missing references)
		//IL_002d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0032: Unknown result type (might be due to invalid IL or missing references)
		//IL_0034: Unknown result type (might be due to invalid IL or missing references)
		//IL_0035: Unknown result type (might be due to invalid IL or missing references)
		//IL_004b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0050: Unknown result type (might be due to invalid IL or missing references)
		//IL_0055: Unknown result type (might be due to invalid IL or missing references)
		//IL_0056: Unknown result type (might be due to invalid IL or missing references)
		//IL_0057: Unknown result type (might be due to invalid IL or missing references)
		//IL_0058: Unknown result type (might be due to invalid IL or missing references)
		//IL_005d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0072: Unknown result type (might be due to invalid IL or missing references)
		//IL_0076: Unknown result type (might be due to invalid IL or missing references)
		//IL_007b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0088: Unknown result type (might be due to invalid IL or missing references)
		//IL_008e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0093: Unknown result type (might be due to invalid IL or missing references)
		//IL_0098: Unknown result type (might be due to invalid IL or missing references)
		//IL_009d: Unknown result type (might be due to invalid IL or missing references)
		//IL_010e: Unknown result type (might be due to invalid IL or missing references)
		//IL_010f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0110: Unknown result type (might be due to invalid IL or missing references)
		//IL_0112: Unknown result type (might be due to invalid IL or missing references)
		//IL_0155: Unknown result type (might be due to invalid IL or missing references)
		//IL_015f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0164: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ad: Unknown result type (might be due to invalid IL or missing references)
		//IL_00af: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b0: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b7: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c1: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c6: Unknown result type (might be due to invalid IL or missing references)
		//IL_00cf: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d4: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d6: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d8: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e8: Unknown result type (might be due to invalid IL or missing references)
		//IL_00fd: Unknown result type (might be due to invalid IL or missing references)
		//IL_0102: Unknown result type (might be due to invalid IL or missing references)
		//IL_0107: Unknown result type (might be due to invalid IL or missing references)
		//IL_01ae: Unknown result type (might be due to invalid IL or missing references)
		//IL_01b3: Unknown result type (might be due to invalid IL or missing references)
		//IL_01b5: Unknown result type (might be due to invalid IL or missing references)
		//IL_01ba: Unknown result type (might be due to invalid IL or missing references)
		//IL_0186: Unknown result type (might be due to invalid IL or missing references)
		//IL_0193: Unknown result type (might be due to invalid IL or missing references)
		//IL_0198: Unknown result type (might be due to invalid IL or missing references)
		//IL_01a0: Unknown result type (might be due to invalid IL or missing references)
		//IL_01a2: Unknown result type (might be due to invalid IL or missing references)
		Vector3 val = FoliageSwayBaseTipPositionGet(_part);
		Vector3 val2 = (val - _part.previousTipPosition) / Time.deltaTime;
		_part.previousTipPosition = val;
		Vector3 val3 = val2 - _part.fakeTipVelocity;
		_part.fakeTipVelocity = val2;
		Vector3 val4 = _part.transform.parent.TransformPoint(_part.transform.localPosition);
		Vector3 val5 = val - val4;
		float num = Mathf.Max(val5.magnitude, 0.01f);
		Vector3 val6 = val5 / num;
		Quaternion val7 = Quaternion.Inverse(_part.transform.parent.rotation * _part.baseLocalRotation);
		if (val3.sqrMagnitude > 0.0001f)
		{
			Vector3 val8 = Vector3.Cross(val6, val3) / num * 57.29578f;
			SpringVector3 rotationSpring = _part.rotationSpring;
			rotationSpring.springVelocity -= val7 * val8 * _part.settings.velocityInfluence * _part.settings.springSettings.speed;
		}
		FoliageSwayTurbulenceTick(_part, val2, val, val6, val7);
		_part.rotationSpring.speed = _part.settings.springSettings.speed;
		_part.rotationSpring.damping = _part.settings.springSettings.damping;
		Vector3 val9 = SemiFunc.SpringVector3Get(_part.rotationSpring, Vector3.zero);
		if (val9.sqrMagnitude > _part.settings.rotationMax * _part.settings.rotationMax)
		{
			val9 = Vector3.ClampMagnitude(val9, _part.settings.rotationMax);
			_part.rotationSpring.lastPosition = val9;
		}
		_part.transform.localRotation = _part.baseLocalRotation * Quaternion.Euler(val9);
	}

	private void FoliageSwayTurbulenceTick(MegaBotFoliageSwayPart _part, Vector3 _tipVelocity, Vector3 _tipPosition, Vector3 _leverDirection, Quaternion _worldToOffsetSpace)
	{
		//IL_0055: Unknown result type (might be due to invalid IL or missing references)
		//IL_0061: Unknown result type (might be due to invalid IL or missing references)
		//IL_0066: Unknown result type (might be due to invalid IL or missing references)
		//IL_0067: Unknown result type (might be due to invalid IL or missing references)
		//IL_0069: Unknown result type (might be due to invalid IL or missing references)
		//IL_006a: Unknown result type (might be due to invalid IL or missing references)
		//IL_006f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0077: Unknown result type (might be due to invalid IL or missing references)
		//IL_007c: Unknown result type (might be due to invalid IL or missing references)
		//IL_007e: Unknown result type (might be due to invalid IL or missing references)
		//IL_007f: Unknown result type (might be due to invalid IL or missing references)
		//IL_008f: Unknown result type (might be due to invalid IL or missing references)
		//IL_009a: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a4: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a9: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ae: Unknown result type (might be due to invalid IL or missing references)
		float num = Mathf.Clamp01(_tipVelocity.magnitude / Mathf.Max(_part.settings.turbulenceSpeedMax, 0.01f));
		_part.turbulenceStrength = Mathf.Lerp(_part.turbulenceStrength, num, Time.deltaTime * _part.settings.turbulenceResponse);
		if (!(_part.turbulenceStrength < 0.01f))
		{
			Vector3 val = FoliageWindSample(_tipPosition, _part.settings.turbulenceFrequency);
			Vector3 val2 = Vector3.Cross(_leverDirection, val);
			SpringVector3 rotationSpring = _part.rotationSpring;
			rotationSpring.springVelocity += _worldToOffsetSpace * val2 * _part.settings.turbulenceAmount * _part.turbulenceStrength * Time.deltaTime;
		}
	}

	private Vector3 FoliageWindSample(Vector3 _worldPosition, float _frequency)
	{
		//IL_0008: Unknown result type (might be due to invalid IL or missing references)
		//IL_0016: Unknown result type (might be due to invalid IL or missing references)
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_0065: Unknown result type (might be due to invalid IL or missing references)
		//IL_006f: Unknown result type (might be due to invalid IL or missing references)
		float num = Time.time * _frequency;
		float num2 = _worldPosition.x * foliageWindWorldScale;
		float num3 = _worldPosition.y * foliageWindWorldScale;
		float num4 = _worldPosition.z * foliageWindWorldScale;
		return new Vector3(Mathf.PerlinNoise(num3 + num, num4 - num) - 0.5f, Mathf.PerlinNoise(num4 + num, num2 - num) - 0.5f, Mathf.PerlinNoise(num2 + num, num3 - num) - 0.5f) * 2f;
	}

	private void FoliageSwayKick(float _amount)
	{
		//IL_001d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0022: Unknown result type (might be due to invalid IL or missing references)
		//IL_0028: Unknown result type (might be due to invalid IL or missing references)
		//IL_0038: Unknown result type (might be due to invalid IL or missing references)
		//IL_004d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0052: Unknown result type (might be due to invalid IL or missing references)
		//IL_0057: Unknown result type (might be due to invalid IL or missing references)
		foreach (MegaBotFoliageSwayPart foliageSwayPart in foliageSwayParts)
		{
			SpringVector3 rotationSpring = foliageSwayPart.rotationSpring;
			rotationSpring.springVelocity += Random.insideUnitSphere * _amount * foliageSwayPart.settings.eventScale * foliageSwayPart.settings.springSettings.speed;
		}
	}

	private void SparkJointsBuild()
	{
		foreach (MegaBotPosePart posePart in poseParts)
		{
			SparkJointAdd(posePart.bone);
		}
		if (hasJaw)
		{
			SparkJointAdd(jawTopTransform);
		}
		if (hasArm)
		{
			SparkJointAdd(armAimTransform);
		}
	}

	private void SparkJointAdd(Transform _joint)
	{
		//IL_000f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0014: Unknown result type (might be due to invalid IL or missing references)
		MegaBotSparkJoint megaBotSparkJoint = new MegaBotSparkJoint();
		megaBotSparkJoint.joint = _joint;
		megaBotSparkJoint.previousLocalRotation = _joint.localRotation;
		sparkJoints.Add(megaBotSparkJoint);
	}

	private void SparkTick()
	{
		//IL_001c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0021: Unknown result type (might be due to invalid IL or missing references)
		//IL_0022: Unknown result type (might be due to invalid IL or missing references)
		//IL_0027: Unknown result type (might be due to invalid IL or missing references)
		//IL_0042: Unknown result type (might be due to invalid IL or missing references)
		//IL_0043: Unknown result type (might be due to invalid IL or missing references)
		if (hasSparks && !(Time.deltaTime <= 0f))
		{
			float _rate = 0f;
			Vector3 _position = Vector3.zero;
			Vector3 _direction = Vector3.forward;
			SparkCheckPlatform(ref _rate, ref _position, ref _direction);
			SparkCheckJoints(ref _rate, ref _position, ref _direction);
			SparkApply(_rate, _position, _direction);
		}
	}

	private void SparkCheckPlatform(ref float _rate, ref Vector3 _position, ref Vector3 _direction)
	{
		//IL_004c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0051: Unknown result type (might be due to invalid IL or missing references)
		//IL_0052: Unknown result type (might be due to invalid IL or missing references)
		//IL_0057: Unknown result type (might be due to invalid IL or missing references)
		//IL_0058: Unknown result type (might be due to invalid IL or missing references)
		//IL_005d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0061: Unknown result type (might be due to invalid IL or missing references)
		//IL_006c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0071: Unknown result type (might be due to invalid IL or missing references)
		//IL_0079: Unknown result type (might be due to invalid IL or missing references)
		//IL_007e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0085: Unknown result type (might be due to invalid IL or missing references)
		//IL_008a: Unknown result type (might be due to invalid IL or missing references)
		//IL_008f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0095: Unknown result type (might be due to invalid IL or missing references)
		//IL_0096: Unknown result type (might be due to invalid IL or missing references)
		//IL_009b: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a5: Unknown result type (might be due to invalid IL or missing references)
		//IL_00aa: Unknown result type (might be due to invalid IL or missing references)
		//IL_00af: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b8: Unknown result type (might be due to invalid IL or missing references)
		if (hasPlatform)
		{
			float num = Mathf.DeltaAngle(sparkPlatformYawPrevious, platformYawCurrent);
			sparkPlatformYawPrevious = platformYawCurrent;
			float num2 = Mathf.Clamp01(Mathf.Abs(num) / Time.deltaTime / sparkFullAngularSpeed);
			if (!(num2 <= _rate))
			{
				Vector3 forward = platformTransform.forward;
				Vector3 val = Vector3.Cross(Vector3.up, forward);
				Vector3 val2 = val.normalized * Mathf.Sign(num);
				_position = platformTransform.position + forward * sparkPlatformRadius;
				val = -val2 + Vector3.up * 0.4f;
				_direction = val.normalized;
				_rate = num2;
			}
		}
	}

	private void SparkCheckJoints(ref float _rate, ref Vector3 _position, ref Vector3 _direction)
	{
		//IL_001f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_0026: Unknown result type (might be due to invalid IL or missing references)
		//IL_002b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0031: Unknown result type (might be due to invalid IL or missing references)
		//IL_0033: Unknown result type (might be due to invalid IL or missing references)
		//IL_0038: Unknown result type (might be due to invalid IL or missing references)
		//IL_003d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0042: Unknown result type (might be due to invalid IL or missing references)
		//IL_0044: Unknown result type (might be due to invalid IL or missing references)
		//IL_0045: Unknown result type (might be due to invalid IL or missing references)
		//IL_007d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0082: Unknown result type (might be due to invalid IL or missing references)
		//IL_0084: Unknown result type (might be due to invalid IL or missing references)
		//IL_008f: Unknown result type (might be due to invalid IL or missing references)
		//IL_009a: Unknown result type (might be due to invalid IL or missing references)
		//IL_009f: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a4: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d4: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d6: Unknown result type (might be due to invalid IL or missing references)
		//IL_00db: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c6: Unknown result type (might be due to invalid IL or missing references)
		//IL_00cb: Unknown result type (might be due to invalid IL or missing references)
		//IL_0106: Unknown result type (might be due to invalid IL or missing references)
		//IL_010b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0111: Unknown result type (might be due to invalid IL or missing references)
		//IL_0113: Unknown result type (might be due to invalid IL or missing references)
		//IL_0118: Unknown result type (might be due to invalid IL or missing references)
		//IL_0122: Unknown result type (might be due to invalid IL or missing references)
		//IL_0127: Unknown result type (might be due to invalid IL or missing references)
		//IL_012c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0130: Unknown result type (might be due to invalid IL or missing references)
		//IL_0135: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f1: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f6: Unknown result type (might be due to invalid IL or missing references)
		float num3 = default;
		Vector3 val2 = default;
		foreach (MegaBotSparkJoint sparkJoint in sparkJoints)
		{
			Quaternion localRotation = sparkJoint.joint.localRotation;
			float num = Quaternion.Angle(sparkJoint.previousLocalRotation, localRotation);
			Quaternion val = localRotation * Quaternion.Inverse(sparkJoint.previousLocalRotation);
			sparkJoint.previousLocalRotation = localRotation;
			float num2 = Mathf.Clamp01(num / Time.deltaTime / sparkFullAngularSpeed);
			if (!(num2 <= _rate))
			{
				val.ToAngleAxis(ref num3, ref val2);
				Vector3 val3 = sparkJoint.joint.parent.rotation * val2;
				Vector3 val4 = sparkJoint.joint.position - ((Component)this).transform.position;
				val4.y = 0f;
				if (val4.sqrMagnitude < 0.001f)
				{
					val4 = ((Component)this).transform.forward;
				}
				val4.Normalize();
				Vector3 val5 = Vector3.Cross(val3, val4);
				if (val5.sqrMagnitude < 0.001f)
				{
					val5 = sparkJoint.joint.forward;
				}
				val5.Normalize();
				_position = sparkJoint.joint.position;
				Vector3 val6 = -val5 + Vector3.up * 0.2f;
				_direction = val6.normalized;
				_rate = num2;
			}
		}
	}

	private void SparkApply(float _rate01, Vector3 _position, Vector3 _direction)
	{
		//IL_000e: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Unknown result type (might be due to invalid IL or missing references)
		//IL_003f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0040: Unknown result type (might be due to invalid IL or missing references)
		sparkEmission.rateOverTime = MinMaxCurve.op_Implicit(_rate01 * sparkRateMax);
		bool flag = _rate01 > 0.02f;
		if (flag)
		{
			((Component)particleMetalSparks).transform.position = _position;
			((Component)particleMetalSparks).transform.rotation = Quaternion.LookRotation(_direction);
		}
		if (flag && !particleMetalSparks.isPlaying)
		{
			particleMetalSparks.Play(true);
		}
		if (!flag && particleMetalSparks.isPlaying)
		{
			particleMetalSparks.Stop(true, (ParticleSystemStopBehavior)1);
		}
	}

	private void DustJointsBuild()
	{
		//IL_009e: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00eb: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f0: Unknown result type (might be due to invalid IL or missing references)
		//IL_0118: Unknown result type (might be due to invalid IL or missing references)
		//IL_011d: Unknown result type (might be due to invalid IL or missing references)
		List<Transform> list = new List<Transform>();
		foreach (MegaBotPosePart posePart in poseParts)
		{
			list.Add(posePart.bone);
		}
		if (hasJaw)
		{
			list.Add(jawTopTransform);
		}
		if (hasArm)
		{
			list.Add(armAimTransform);
		}
		if (hasGrabber)
		{
			list.Add(grabberAimTransform);
		}
		float num = 0f;
		foreach (Transform item in list)
		{
			float y = ((Component)this).transform.InverseTransformPoint(item.position).y;
			if (y > num)
			{
				num = y;
			}
		}
		foreach (Transform item2 in list)
		{
			if (!(((Component)this).transform.InverseTransformPoint(item2.position).y < num * dustHeightFraction))
			{
				MegaBotSparkJoint megaBotSparkJoint = new MegaBotSparkJoint();
				megaBotSparkJoint.joint = item2;
				megaBotSparkJoint.previousLocalRotation = item2.localRotation;
				dustJoints.Add(megaBotSparkJoint);
			}
		}
	}

	private void DustTick()
	{
		//IL_001c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0021: Unknown result type (might be due to invalid IL or missing references)
		//IL_003e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0043: Unknown result type (might be due to invalid IL or missing references)
		//IL_0046: Unknown result type (might be due to invalid IL or missing references)
		//IL_004b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0055: Unknown result type (might be due to invalid IL or missing references)
		//IL_0057: Unknown result type (might be due to invalid IL or missing references)
		//IL_0080: Unknown result type (might be due to invalid IL or missing references)
		//IL_0085: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a1: Unknown result type (might be due to invalid IL or missing references)
		if (!hasDust || Time.deltaTime <= 0f)
		{
			return;
		}
		float num = 0f;
		Vector3 position = Vector3.zero;
		foreach (MegaBotSparkJoint dustJoint in dustJoints)
		{
			Quaternion localRotation = dustJoint.joint.localRotation;
			float num2 = Quaternion.Angle(dustJoint.previousLocalRotation, localRotation);
			dustJoint.previousLocalRotation = localRotation;
			float num3 = Mathf.Clamp01(num2 / Time.deltaTime / dustFullAngularSpeed);
			if (!(num3 <= num))
			{
				num = num3;
				position = dustJoint.joint.position;
			}
		}
		DustApply(num, position);
	}

	private void DustApply(float _rate01, Vector3 _position)
	{
		//IL_000e: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Unknown result type (might be due to invalid IL or missing references)
		dustEmission.rateOverTime = MinMaxCurve.op_Implicit(_rate01 * dustRateMax);
		bool flag = _rate01 > 0.02f;
		if (flag)
		{
			((Component)particleDust).transform.position = _position;
		}
		if (flag && !particleDust.isPlaying)
		{
			particleDust.Play(true);
		}
		if (!flag && particleDust.isPlaying)
		{
			particleDust.Stop(true, (ParticleSystemStopBehavior)1);
		}
	}

	private void TargetSet(PhysGrabObject _physObject, PlayerAvatar _player)
	{
		if (SemiFunc.IsMasterClientOrSingleplayer())
		{
			if (CanRPC())
			{
				int num = (Object.op_Implicit((Object)(object)_player) ? _player.photonView.ViewID : _physObject.photonView.ViewID);
				photonView.RPC("TargetSetRPC", (RpcTarget)0, new object[2]
				{
					num,
					(Object)(object)_player != (Object)null
				});
			}
			else
			{
				targetPhysObject = _physObject;
				targetPlayer = _player;
				targetWasPlayer = Object.op_Implicit((Object)(object)_player);
				TargetEnemyParentResolve();
			}
		}
	}

	private void TargetEnemyParentResolve()
	{
		targetEnemyParent = null;
		if (Object.op_Implicit((Object)(object)targetPhysObject) && targetPhysObject.isEnemy)
		{
			targetEnemyParent = ((Component)targetPhysObject).GetComponentInParent<EnemyParent>();
		}
	}

	private void GrabTargetStunLogic()
	{
		if (SemiFunc.IsMasterClientOrSingleplayer() && EnemyParentAlive(targetEnemyParent))
		{
			targetEnemyParent.Enemy.StateStunned.Set(1f);
		}
	}

	private void TargetClearLocal()
	{
		targetPhysObject = null;
		targetPlayer = null;
		targetEnemyParent = null;
		targetWasPlayer = false;
	}

	private bool TargetValid()
	{
		if (!Object.op_Implicit((Object)(object)targetPhysObject))
		{
			return false;
		}
		if (targetWasPlayer && !Object.op_Implicit((Object)(object)targetPlayer))
		{
			return false;
		}
		if (Object.op_Implicit((Object)(object)targetPlayer) && targetPlayer.isDisabled)
		{
			return false;
		}
		if (Object.op_Implicit((Object)(object)targetEnemyParent) && !EnemyParentAlive(targetEnemyParent))
		{
			return false;
		}
		return true;
	}

	private bool EnemyGrabAllowed()
	{
		return enemyGrabsRemaining > 0;
	}

	private void EnemyGrabSpend()
	{
		enemyGrabsRemaining--;
		if (enemyGrabsRemaining <= 0)
		{
			enemyGrabCooldownTimer = enemyGrabCooldownTime;
		}
	}

	private void EnemyGrabCooldownTick()
	{
		if (SemiFunc.IsMasterClientOrSingleplayer() && enemyGrabsRemaining <= 0)
		{
			if (enemyGrabCooldownTimer <= 0f)
			{
				enemyGrabsRemaining = Random.Range(enemyGrabCountMin, enemyGrabCountMax + 1);
			}
			if (enemyGrabCooldownTimer > 0f)
			{
				enemyGrabCooldownTimer -= Time.deltaTime;
			}
		}
	}

	private bool EnemyParentAlive(EnemyParent _enemyParent)
	{
		if (!Object.op_Implicit((Object)(object)_enemyParent))
		{
			return false;
		}
		if (!_enemyParent.Spawned)
		{
			return false;
		}
		if (!Object.op_Implicit((Object)(object)_enemyParent.Enemy))
		{
			return false;
		}
		if (_enemyParent.Enemy.HasHealth && _enemyParent.Enemy.Health.dead)
		{
			return false;
		}
		return true;
	}

	private void ArmAimPointSet(Vector3 _worldPoint)
	{
		//IL_0001: Unknown result type (might be due to invalid IL or missing references)
		//IL_0002: Unknown result type (might be due to invalid IL or missing references)
		armAimPoint = _worldPoint;
	}

	private bool GrabArmActive()
	{
		if (currentState != State.GrabStart && currentState != State.GrabPullIn && currentState != State.GrabGotoLaunchPose)
		{
			return false;
		}
		return TargetValid();
	}

	private bool FacingTargetEnough()
	{
		//IL_001a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0025: Unknown result type (might be due to invalid IL or missing references)
		//IL_002a: Unknown result type (might be due to invalid IL or missing references)
		//IL_002f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0054: Unknown result type (might be due to invalid IL or missing references)
		//IL_0059: Unknown result type (might be due to invalid IL or missing references)
		//IL_005e: Unknown result type (might be due to invalid IL or missing references)
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0065: Unknown result type (might be due to invalid IL or missing references)
		if (!TargetValid())
		{
			return false;
		}
		if (!hasPlatform)
		{
			return true;
		}
		Vector3 val = targetPhysObject.centerPoint - eyeVisionTransform.position;
		val.y = 0f;
		if (val.sqrMagnitude < 0.001f)
		{
			return true;
		}
		Vector3 val2 = ((Component)this).transform.InverseTransformDirection(val.normalized);
		float num = Mathf.Atan2(val2.x, val2.z) * 57.29578f;
		return Mathf.Abs(Mathf.DeltaAngle(platformYawCurrent, num)) <= grabFaceAngle;
	}

	private bool GrabBeamActive()
	{
		if (currentState != State.GrabPullIn && currentState != State.GrabGotoLaunchPose)
		{
			return false;
		}
		return TargetValid();
	}

	private void GrabberSpinTick()
	{
		//IL_0049: Unknown result type (might be due to invalid IL or missing references)
		//IL_005e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0063: Unknown result type (might be due to invalid IL or missing references)
		if (!hasClaw)
		{
			return;
		}
		if (ArmExtendedActive())
		{
			if (!grabberSpinActive)
			{
				GrabberSpinStart();
			}
			grabberSpinAngle = Mathf.Repeat(grabberSpinAngle + grabberSpinSpeed * Time.deltaTime, 360f);
			grabberClawRootTransform.localRotation = grabberSpinStartRotation * Quaternion.Euler(0f, 0f, grabberSpinAngle);
		}
		else
		{
			if (grabberSpinActive)
			{
				GrabberSpinStop();
			}
			GrabberSpinSettleTick();
		}
	}

	private void GrabberSpinStart()
	{
		//IL_003f: Unknown result type (might be due to invalid IL or missing references)
		grabberSpinActive = true;
		soundStartMove.Play(grabberClawRootTransform);
		ShakeAll(0.075f);
		ScreenShakeImpact(grabberClawRootTransform.position, 0.75f, 0.1f);
	}

	private void GrabberSpinStop()
	{
		//IL_0061: Unknown result type (might be due to invalid IL or missing references)
		grabberSpinActive = false;
		grabberSpinSettleTimer = 0f;
		grabberSpinSettleDuration = Random.Range(platformRampDurationMin, platformRampDurationMax);
		soundEndMove.Play(grabberClawRootTransform);
		ShakeAll(0.075f);
		ScreenShakeImpact(grabberClawRootTransform.position, 0.75f, 0.1f);
	}

	private void GrabberSpinSettleTick()
	{
		//IL_0070: Unknown result type (might be due to invalid IL or missing references)
		//IL_0087: Unknown result type (might be due to invalid IL or missing references)
		//IL_008c: Unknown result type (might be due to invalid IL or missing references)
		if (!(grabberSpinSettleTimer >= grabberSpinSettleDuration))
		{
			grabberSpinSettleTimer += Time.deltaTime;
			float num = Mathf.Clamp01(grabberSpinSettleTimer / grabberSpinSettleDuration);
			float num2 = platformSettleCurve.Evaluate(num) * platformSettleWobbleDegrees * Mathf.Sin(num * MathF.PI * 4f);
			if (num >= 1f)
			{
				num2 = 0f;
			}
			grabberClawRootTransform.localRotation = grabberSpinStartRotation * Quaternion.Euler(0f, 0f, grabberSpinAngle + num2);
		}
	}

	private void ArmPoseTick()
	{
		//IL_000f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0014: Unknown result type (might be due to invalid IL or missing references)
		//IL_001d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0022: Unknown result type (might be due to invalid IL or missing references)
		//IL_0044: Unknown result type (might be due to invalid IL or missing references)
		//IL_002c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0031: Unknown result type (might be due to invalid IL or missing references)
		//IL_0036: Unknown result type (might be due to invalid IL or missing references)
		if (hasArm)
		{
			Quaternion targetRotation = armPoseRight.startRotation;
			if (ArmExtendedActive())
			{
				targetRotation = Quaternion.identity;
			}
			if (armAimCaptured)
			{
				targetRotation = Quaternion.Euler(armGrabPoseEuler);
			}
			ArmPoseAnimate(armPoseRight, armPoseTransform, targetRotation);
		}
	}

	private void ArmPoseAnimate(MegaBotArmPose _armPose, Transform _bone, Quaternion _targetRotation)
	{
		//IL_0001: Unknown result type (might be due to invalid IL or missing references)
		//IL_0006: Unknown result type (might be due to invalid IL or missing references)
		//IL_0010: Unknown result type (might be due to invalid IL or missing references)
		//IL_0015: Unknown result type (might be due to invalid IL or missing references)
		//IL_001b: Unknown result type (might be due to invalid IL or missing references)
		//IL_001c: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ab: Unknown result type (might be due to invalid IL or missing references)
		//IL_0083: Unknown result type (might be due to invalid IL or missing references)
		//IL_0089: Unknown result type (might be due to invalid IL or missing references)
		//IL_009f: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a4: Unknown result type (might be due to invalid IL or missing references)
		if (_armPose.poseNew != _targetRotation)
		{
			_armPose.poseOld = _armPose.poseCurrent;
			_armPose.poseNew = _targetRotation;
			_armPose.lerp = 0f;
			_armPose.duration = Random.Range(poseDurationMin, poseDurationMax);
		}
		if (_armPose.lerp < 1f)
		{
			_armPose.lerp += Time.deltaTime / _armPose.duration;
			if (_armPose.lerp > 1f)
			{
				_armPose.lerp = 1f;
			}
			_armPose.poseCurrent = Quaternion.SlerpUnclamped(_armPose.poseOld, _armPose.poseNew, poseCurve.Evaluate(_armPose.lerp));
		}
		_bone.localRotation = _armPose.poseCurrent;
	}

	private bool ArmExtendedActive()
	{
		if (currentState == State.RedLight)
		{
			return true;
		}
		if (currentState != State.GrabStart && currentState != State.GrabPullIn && currentState != State.GrabGotoLaunchPose)
		{
			return currentState == State.GrabLaunch;
		}
		return true;
	}

	private void ArmAimTick()
	{
		//IL_0064: Unknown result type (might be due to invalid IL or missing references)
		//IL_0047: Unknown result type (might be due to invalid IL or missing references)
		if (!hasArm)
		{
			return;
		}
		if (GrabArmActive())
		{
			if (platformMoveState == PlatformMoveState.Idle && (!armAimCaptured || armAimCapturedState != currentState))
			{
				armAimCaptured = true;
				armAimCapturedState = currentState;
				ArmAimAnimationStart(ArmAimYawRotationGet());
			}
		}
		else if (armAimCaptured)
		{
			armAimCaptured = false;
			ArmAimAnimationStart(armAimStartRotation);
		}
		ArmAimAnimationTick();
	}

	private void ArmAimAnimationStart(Quaternion _toRotation)
	{
		//IL_0007: Unknown result type (might be due to invalid IL or missing references)
		//IL_000c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0012: Unknown result type (might be due to invalid IL or missing references)
		//IL_0013: Unknown result type (might be due to invalid IL or missing references)
		armAimFrom = armAimTransform.localRotation;
		armAimTo = _toRotation;
		armAimLerp = 0f;
		armAimAnimDuration = Random.Range(poseDurationMin, poseDurationMax);
		armAimEndSoundPlayed = false;
		soundSqueak.Play(armAimTransform);
		soundStartMove.Play(armAimTransform);
	}

	private void ArmAimAnimationTick()
	{
		//IL_0046: Unknown result type (might be due to invalid IL or missing references)
		//IL_004c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0062: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c0: Unknown result type (might be due to invalid IL or missing references)
		if (!(armAimLerp >= 1f))
		{
			armAimLerp += Time.deltaTime / armAimAnimDuration;
			if (armAimLerp > 1f)
			{
				armAimLerp = 1f;
			}
			armAimTransform.localRotation = Quaternion.SlerpUnclamped(armAimFrom, armAimTo, poseCurve.Evaluate(armAimLerp));
			poseMovingLoopTimer = 0.1f;
			if (!armAimEndSoundPlayed && armAimLerp >= 0.8f)
			{
				armAimEndSoundPlayed = true;
				soundEndMove.Play(armAimTransform);
				ScreenShakeImpact(armAimTransform.position, 0.75f, 0.1f);
			}
		}
	}

	private Quaternion ArmAimYawRotationGet()
	{
		//IL_0001: Unknown result type (might be due to invalid IL or missing references)
		//IL_000c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0011: Unknown result type (might be due to invalid IL or missing references)
		//IL_0016: Unknown result type (might be due to invalid IL or missing references)
		//IL_0045: Unknown result type (might be due to invalid IL or missing references)
		//IL_004a: Unknown result type (might be due to invalid IL or missing references)
		//IL_004f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0050: Unknown result type (might be due to invalid IL or missing references)
		//IL_0056: Unknown result type (might be due to invalid IL or missing references)
		//IL_0069: Unknown result type (might be due to invalid IL or missing references)
		//IL_0085: Unknown result type (might be due to invalid IL or missing references)
		//IL_008a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0032: Unknown result type (might be due to invalid IL or missing references)
		Vector3 val = armAimPoint - armAimTransform.position;
		val.y = 0f;
		if (val.sqrMagnitude < 0.001f)
		{
			return armAimStartRotation;
		}
		Vector3 val2 = armAimTransform.parent.InverseTransformDirection(val.normalized);
		float num = Mathf.Atan2(val2.x, val2.z) * 57.29578f;
		return armAimStartRotation * Quaternion.Euler(0f, num + armAimOffsetEuler.y, 0f);
	}

	private void ArmReachTick()
	{
		//IL_0048: Unknown result type (might be due to invalid IL or missing references)
		if (hasArm)
		{
			float targetFloat = (GrabBeamActive() ? armReachStretch : 0f);
			float num = SemiFunc.SpringFloatGet(armReachSpring, targetFloat);
			armAimTransform.localScale = new Vector3(1f, 1f, 1f + num);
		}
	}

	private bool ArmAimAligned()
	{
		if (!hasArm)
		{
			return true;
		}
		if (!GrabArmActive())
		{
			return false;
		}
		if (armAimCaptured && armAimLerp >= 1f)
		{
			return armPoseRight.lerp >= 1f;
		}
		return false;
	}

	private void GrabBuildUpLogic()
	{
		if (!grabBuildUpStarted)
		{
			if (ArmAimAligned() || (stateTimer >= grabBuildUpForceStartTime && platformMoveState == PlatformMoveState.Idle))
			{
				grabBuildUpStarted = true;
				grabBuildUpTimer = 0f;
				soundBuildUp.Play(grabberBeamOriginTransform);
				if (Object.op_Implicit((Object)(object)particlesGrabBuildUp))
				{
					particlesGrabBuildUp.Play(true);
				}
			}
		}
		else
		{
			grabBuildUpTimer += Time.deltaTime;
		}
	}

	private void BeamGrabLoop()
	{
		//IL_0012: Unknown result type (might be due to invalid IL or missing references)
		//IL_0044: Unknown result type (might be due to invalid IL or missing references)
		//IL_005a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0065: Unknown result type (might be due to invalid IL or missing references)
		beamGrabLoopTimer = 0.1f;
		ScreenShake(grabberBeamOriginTransform.position, screenShakeBeamRumble, 0.1f);
		if (Object.op_Implicit((Object)(object)grabBeam) && TargetValid())
		{
			grabBeam.SetColor(eyeColorRed);
			grabBeam.DrawLineAnimated(grabberBeamOriginTransform.position, targetPhysObject.centerPoint);
		}
	}

	private void GrabBuildUpParticlesStopLogic()
	{
		if (currentState != State.GrabStart && currentState != State.GrabPullIn && currentState != State.GrabGotoLaunchPose && Object.op_Implicit((Object)(object)particlesGrabBuildUp) && particlesGrabBuildUp.isPlaying)
		{
			particlesGrabBuildUp.Stop(true, (ParticleSystemStopBehavior)1);
		}
	}

	private void GrabPullPhysicsLogic()
	{
		//IL_00f0: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f5: Unknown result type (might be due to invalid IL or missing references)
		//IL_00fc: Unknown result type (might be due to invalid IL or missing references)
		//IL_0101: Unknown result type (might be due to invalid IL or missing references)
		//IL_0141: Unknown result type (might be due to invalid IL or missing references)
		//IL_0142: Unknown result type (might be due to invalid IL or missing references)
		//IL_011b: Unknown result type (might be due to invalid IL or missing references)
		//IL_011c: Unknown result type (might be due to invalid IL or missing references)
		//IL_011e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0129: Unknown result type (might be due to invalid IL or missing references)
		//IL_012e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0131: Unknown result type (might be due to invalid IL or missing references)
		//IL_0134: Unknown result type (might be due to invalid IL or missing references)
		//IL_0150: Unknown result type (might be due to invalid IL or missing references)
		//IL_0151: Unknown result type (might be due to invalid IL or missing references)
		//IL_0153: Unknown result type (might be due to invalid IL or missing references)
		//IL_015e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0163: Unknown result type (might be due to invalid IL or missing references)
		//IL_0166: Unknown result type (might be due to invalid IL or missing references)
		//IL_0169: Unknown result type (might be due to invalid IL or missing references)
		//IL_01ce: Unknown result type (might be due to invalid IL or missing references)
		//IL_01d9: Unknown result type (might be due to invalid IL or missing references)
		//IL_0184: Unknown result type (might be due to invalid IL or missing references)
		//IL_018b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0190: Unknown result type (might be due to invalid IL or missing references)
		//IL_0195: Unknown result type (might be due to invalid IL or missing references)
		//IL_0199: Unknown result type (might be due to invalid IL or missing references)
		//IL_019e: Unknown result type (might be due to invalid IL or missing references)
		//IL_01a1: Unknown result type (might be due to invalid IL or missing references)
		//IL_01a9: Unknown result type (might be due to invalid IL or missing references)
		//IL_01b5: Unknown result type (might be due to invalid IL or missing references)
		//IL_01c0: Unknown result type (might be due to invalid IL or missing references)
		if ((currentState != State.GrabPullIn && currentState != State.GrabGotoLaunchPose) || !hasGrabber || !TargetValid())
		{
			return;
		}
		if (Object.op_Implicit((Object)(object)targetPlayer) && targetPlayer.isLocal)
		{
			targetPlayer.physGrabber.OverrideDisableSpecialGrabPowers();
		}
		if (!SemiFunc.IsMasterClientOrSingleplayer())
		{
			return;
		}
		if (Object.op_Implicit((Object)(object)targetPlayer) && !targetPlayer.isTumbling)
		{
			targetPlayer.tumble.TumbleRequest(_isTumbling: true, _playerInput: false);
			return;
		}
		Rigidbody rb = targetPhysObject.rb;
		if (!Object.op_Implicit((Object)(object)rb))
		{
			return;
		}
		if (Object.op_Implicit((Object)(object)targetPlayer))
		{
			targetPlayer.tumble.TumbleOverrideTime(0.5f);
		}
		float num = 1f;
		if (targetPhysObject.massOriginal > 0f)
		{
			num = Mathf.Clamp01(rb.mass / targetPhysObject.massOriginal);
		}
		Vector3 position = rb.position;
		Vector3 position2 = grabberHoldTransform.position;
		if (currentState == State.GrabGotoLaunchPose)
		{
			targetPhysObject.OverrideZeroGravity();
			Vector3 val = SemiFunc.PhysFollowPosition(position, position2, rb.linearVelocity, pullForceMaxSpeed);
			rb.AddForce(val * num, (ForceMode)1);
			return;
		}
		StuckLogic(position, position2);
		if (!stuckActive)
		{
			Vector3 val2 = SemiFunc.PhysFollowPosition(position, position2, rb.linearVelocity, pullForceMaxSpeed);
			rb.AddForce(val2 * num, (ForceMode)1);
		}
		if (stuckActive)
		{
			if (stuckPhaseDislodge)
			{
				Vector3 val3 = position - grabberHoldTransform.position;
				Vector3 normalized = val3.normalized;
				rb.AddForce(normalized * dislodgeBackwardForce, (ForceMode)0);
				rb.AddForce(Vector3.up * dislodgeUpForce, (ForceMode)0);
			}
			else
			{
				rb.AddForce(stuckPushDirection * stuckPushForce, (ForceMode)0);
			}
		}
	}

	private void StuckLogic(Vector3 _currentPosition, Vector3 _targetPosition)
	{
		//IL_0000: Unknown result type (might be due to invalid IL or missing references)
		//IL_0001: Unknown result type (might be due to invalid IL or missing references)
		//IL_0075: Unknown result type (might be due to invalid IL or missing references)
		//IL_007c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0081: Unknown result type (might be due to invalid IL or missing references)
		//IL_0086: Unknown result type (might be due to invalid IL or missing references)
		//IL_008a: Unknown result type (might be due to invalid IL or missing references)
		//IL_008f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0090: Unknown result type (might be due to invalid IL or missing references)
		//IL_0091: Unknown result type (might be due to invalid IL or missing references)
		//IL_0096: Unknown result type (might be due to invalid IL or missing references)
		//IL_009b: Unknown result type (might be due to invalid IL or missing references)
		//IL_009f: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a4: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b5: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b6: Unknown result type (might be due to invalid IL or missing references)
		//IL_00bb: Unknown result type (might be due to invalid IL or missing references)
		//IL_00bc: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c1: Unknown result type (might be due to invalid IL or missing references)
		float num = Vector3.Distance(_currentPosition, _targetPosition);
		bool flag = num < stuckPrevDistance - 0.001f;
		stuckPrevDistance = num;
		if (!stuckActive)
		{
			if (flag)
			{
				stuckNotClosingTimer = 0f;
				return;
			}
			stuckNotClosingTimer += Time.fixedDeltaTime;
			if (stuckNotClosingTimer >= 0.5f)
			{
				stuckActive = true;
				stuckPhaseDislodge = false;
				stuckPhaseTimer = stuckPhaseDuration;
				Vector3 val = _currentPosition - grabberHoldTransform.position;
				Vector3 normalized = val.normalized;
				val = Vector3.Cross(normalized, Vector3.up);
				Vector3 normalized2 = val.normalized;
				stuckPushDirection = Quaternion.AngleAxis(Random.Range(0f, 360f), normalized) * normalized2;
			}
			return;
		}
		stuckPhaseTimer -= Time.fixedDeltaTime;
		if (stuckPhaseTimer <= 0f)
		{
			if (stuckPhaseDislodge)
			{
				StuckReset();
				return;
			}
			stuckPhaseDislodge = true;
			stuckPhaseTimer = stuckPhaseDuration;
		}
	}

	private void StuckReset()
	{
		stuckActive = false;
		stuckPhaseDislodge = false;
		stuckPhaseTimer = 0f;
		stuckNotClosingTimer = 0f;
		stuckPrevDistance = float.MaxValue;
	}

	private void LaunchDirectionPick()
	{
		//IL_0028: Unknown result type (might be due to invalid IL or missing references)
		//IL_002d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0032: Unknown result type (might be due to invalid IL or missing references)
		//IL_0037: Unknown result type (might be due to invalid IL or missing references)
		//IL_0062: Unknown result type (might be due to invalid IL or missing references)
		//IL_0065: Unknown result type (might be due to invalid IL or missing references)
		//IL_006b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0054: Unknown result type (might be due to invalid IL or missing references)
		float num = Random.Range(0f, 360f);
		Vector3 val = Quaternion.Euler(Random.Range(0f - launchPitchUpMax, launchPitchDownMax), num, 0f) * Vector3.forward;
		if (CanRPC())
		{
			photonView.RPC("LaunchDirectionRPC", (RpcTarget)0, new object[1] { val });
		}
		else
		{
			LaunchDirectionRPC(val);
		}
	}

	private void LaunchTarget()
	{
		//IL_0038: Unknown result type (might be due to invalid IL or missing references)
		//IL_0044: Unknown result type (might be due to invalid IL or missing references)
		//IL_004f: Unknown result type (might be due to invalid IL or missing references)
		if (Object.op_Implicit((Object)(object)targetEnemyParent))
		{
			EnemyGrabSpend();
		}
		targetPhysObject.OverrideIndestructible(1f);
		Rigidbody rb = targetPhysObject.rb;
		if (Object.op_Implicit((Object)(object)rb))
		{
			rb.linearVelocity = Vector3.zero;
			rb.AddForce(launchDirection * launchSpeed, (ForceMode)2);
		}
		BounceAffectSpawn();
	}

	private void BounceAffectSpawn()
	{
		//IL_00bb: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c0: Unknown result type (might be due to invalid IL or missing references)
		float num = Random.Range(bounceAffectTimeMin, bounceAffectTimeMax);
		if (Object.op_Implicit((Object)(object)targetEnemyParent))
		{
			targetEnemyParent.Enemy.StateStunned.Set(num);
		}
		if (!bounceAffectPrefab.IsValid())
		{
			return;
		}
		if (CanRPC())
		{
			int num2 = (Object.op_Implicit((Object)(object)targetPlayer) ? targetPlayer.photonView.ViewID : targetPhysObject.photonView.ViewID);
			photonView.RPC("BounceAffectRPC", (RpcTarget)0, new object[2] { num2, num });
		}
		else
		{
			SemiAffect component = Object.Instantiate<GameObject>(bounceAffectPrefab.Prefab, ((Component)targetPhysObject).transform.position, Quaternion.identity).GetComponent<SemiAffect>();
			if (Object.op_Implicit((Object)(object)targetPlayer))
			{
				component.SetupSingleplayer(((Component)targetPlayer).transform, targetPlayer.tumble.physGrabObject, num, targetPlayer);
			}
			else
			{
				component.SetupSingleplayer(((Component)targetPhysObject).transform, targetPhysObject, num);
			}
		}
	}

	private void PlayLoopSoundLogic()
	{
		soundMovingLoop.PlayLoop(poseMovingLoopTimer > 0f, 8f, 5f);
		soundPlatformRotatingLoop.PlayLoop(platformLoopTimer > 0f, 8f, 5f);
		soundBeamGrabLoop.PlayLoop(beamGrabLoopTimer > 0f, 4f, 2f);
		if (poseMovingLoopTimer > 0f)
		{
			poseMovingLoopTimer -= Time.deltaTime;
		}
		if (platformLoopTimer > 0f)
		{
			platformLoopTimer -= Time.deltaTime;
		}
		if (beamGrabLoopTimer > 0f)
		{
			beamGrabLoopTimer -= Time.deltaTime;
		}
	}

	[PunRPC]
	private void StateSetRPC(int _newState, PhotonMessageInfo _info = default(PhotonMessageInfo))
	{
		//IL_0000: Unknown result type (might be due to invalid IL or missing references)
		if (SemiFunc.MasterOnlyRPC(_info))
		{
			if (currentState != (State)_newState)
			{
				stateStart = true;
				currentState = (State)_newState;
			}
		}
	}

	[PunRPC]
	private void PoseSetRPC(Vector3 _lookPoint, float _lockTime, PhotonMessageInfo _info = default(PhotonMessageInfo))
	{
		//IL_0000: Unknown result type (might be due to invalid IL or missing references)
		//IL_000a: Unknown result type (might be due to invalid IL or missing references)
		if (SemiFunc.MasterOnlyRPC(_info))
		{
			PoseApply(_lookPoint, _lockTime);
		}
	}

	[PunRPC]
	private void TargetSetRPC(int _viewID, bool _isPlayer, PhotonMessageInfo _info = default(PhotonMessageInfo))
	{
		//IL_0000: Unknown result type (might be due to invalid IL or missing references)
		if (!SemiFunc.MasterOnlyRPC(_info))
		{
			return;
		}
		targetPhysObject = null;
		if (_isPlayer)
		{
			targetPlayer = SemiFunc.PlayerAvatarGetFromPhotonID(_viewID);
			if (Object.op_Implicit((Object)(object)targetPlayer))
			{
				targetPhysObject = targetPlayer.tumble.physGrabObject;
			}
			targetEnemyParent = null;
			targetWasPlayer = true;
			return;
		}
		targetPlayer = null;
		targetWasPlayer = false;
		PhotonView val = PhotonView.Find(_viewID);
		if (Object.op_Implicit((Object)(object)val))
		{
			targetPhysObject = ((Component)val).GetComponentInParent<PhysGrabObject>();
		}
		TargetEnemyParentResolve();
	}

	[PunRPC]
	private void LaunchDirectionRPC(Vector3 _direction, PhotonMessageInfo _info = default(PhotonMessageInfo))
	{
		//IL_0000: Unknown result type (might be due to invalid IL or missing references)
		//IL_000c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0011: Unknown result type (might be due to invalid IL or missing references)
		if (SemiFunc.MasterOnlyRPC(_info))
		{
			launchDirection = _direction.normalized;
		}
	}

	[PunRPC]
	private void PlatformYawSyncRPC(float _yaw, PhotonMessageInfo _info = default(PhotonMessageInfo))
	{
		//IL_0000: Unknown result type (might be due to invalid IL or missing references)
		if (SemiFunc.MasterOnlyRPC(_info) && !SemiFunc.IsMasterClientOrSingleplayer())
		{
			float num = Mathf.DeltaAngle(platformYawCurrent, _yaw);
			platformYawCurrent = _yaw;
			sparkPlatformYawPrevious = _yaw;
			if (Mathf.Abs(num) < platformYawSyncSnapAngle)
			{
				shakeVibrationYawPrevious = _yaw;
			}
			else
			{
				platformYawSyncOffset += 0f - num;
			}
		}
	}

	[PunRPC]
	private void TTSSayRPC(string _phrase, PhotonMessageInfo _info = default(PhotonMessageInfo))
	{
		//IL_0000: Unknown result type (might be due to invalid IL or missing references)
		if (SemiFunc.MasterOnlyRPC(_info))
		{
			TTSSpeakLocal(_phrase);
		}
	}

	[PunRPC]
	private void BounceAffectRPC(int _viewID, float _affectTime, PhotonMessageInfo _info = default(PhotonMessageInfo))
	{
		//IL_0000: Unknown result type (might be due to invalid IL or missing references)
		//IL_002a: Unknown result type (might be due to invalid IL or missing references)
		//IL_002f: Unknown result type (might be due to invalid IL or missing references)
		if (SemiFunc.MasterOnlyRPC(_info))
		{
			PhotonView val = PhotonView.Find(_viewID);
			if (Object.op_Implicit((Object)(object)val))
			{
				Object.Instantiate<GameObject>(bounceAffectPrefab.Prefab, ((Component)val).transform.position, Quaternion.identity).GetComponent<SemiAffect>().Setup(_viewID, _affectTime);
			}
		}
	}

	public MuseumMegaSemiBot()
	{
		//IL_01d3: Unknown result type (might be due to invalid IL or missing references)
		//IL_01d8: Unknown result type (might be due to invalid IL or missing references)
		//IL_01de: Unknown result type (might be due to invalid IL or missing references)
		//IL_01e3: Unknown result type (might be due to invalid IL or missing references)
		//IL_01e9: Unknown result type (might be due to invalid IL or missing references)
		//IL_01ee: Unknown result type (might be due to invalid IL or missing references)
		//IL_0219: Unknown result type (might be due to invalid IL or missing references)
		//IL_021e: Unknown result type (might be due to invalid IL or missing references)
		//IL_03d9: Unknown result type (might be due to invalid IL or missing references)
		//IL_03de: Unknown result type (might be due to invalid IL or missing references)
		//IL_03f3: Unknown result type (might be due to invalid IL or missing references)
		//IL_03f8: Unknown result type (might be due to invalid IL or missing references)
		//IL_05fa: Unknown result type (might be due to invalid IL or missing references)
		//IL_05ff: Unknown result type (might be due to invalid IL or missing references)
		//IL_06aa: Unknown result type (might be due to invalid IL or missing references)
		//IL_06af: Unknown result type (might be due to invalid IL or missing references)
		//IL_06b5: Unknown result type (might be due to invalid IL or missing references)
		//IL_06ba: Unknown result type (might be due to invalid IL or missing references)
		//IL_06c0: Unknown result type (might be due to invalid IL or missing references)
		//IL_06c5: Unknown result type (might be due to invalid IL or missing references)
		//IL_06cb: Unknown result type (might be due to invalid IL or missing references)
		//IL_06d0: Unknown result type (might be due to invalid IL or missing references)
		//IL_06d6: Unknown result type (might be due to invalid IL or missing references)
		//IL_06db: Unknown result type (might be due to invalid IL or missing references)
	}
}
