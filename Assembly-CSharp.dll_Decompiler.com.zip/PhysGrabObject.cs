using System;
using System.Collections;
using System.Collections.Generic;
using Photon.Pun;
using UnityEngine;

public class PhysGrabObject : MonoBehaviour, IPunObservable
{
	public bool clientNonKinematic;

	public bool overrideTagsAndLayers = true;

	[Tooltip("Only affects objects with item/valuable volumes smaller than 0.5")]
	public bool ignoreGrabPointCentering;

	internal PhotonView photonView;

	internal PhotonTransformView photonTransformView;

	[HideInInspector]
	public Rigidbody rb;

	private bool isMaster;

	internal RoomVolumeCheck roomVolumeCheck;

	internal PhysGrabObjectImpactDetector impactDetector;

	private bool hasImpactDetector;

	internal Vector3 targetPos;

	private float distance;

	internal Quaternion targetRot;

	private float angle;

	internal Vector3 grabDisplacementCurrent;

	[HideInInspector]
	public bool dead;

	[HideInInspector]
	public bool grabbed;

	[HideInInspector]
	public bool grabbedLocal;

	public bool lookedUponWhileGrabbed = true;

	public List<PhysGrabber> playerGrabbing = new List<PhysGrabber>();

	[HideInInspector]
	public bool spawned;

	internal PlayerAvatar lastPlayerGrabbing;

	internal float grabbedTimer;

	[HideInInspector]
	public bool lightBreakImpulse;

	[HideInInspector]
	public bool mediumBreakImpulse;

	[HideInInspector]
	public bool heavyBreakImpulse;

	[HideInInspector]
	public bool lightImpactImpulse;

	[HideInInspector]
	public bool mediumImpactImpulse;

	[HideInInspector]
	public bool heavyImpactImpulse;

	[HideInInspector]
	public float enemyInteractTimer;

	private float networkTrackerOverrideTimer;

	private readonly List<Collider> networkBoundsColliders = new List<Collider>();

	private readonly List<Renderer> networkBoundsRenderers = new List<Renderer>();

	internal float angularDragOriginal;

	internal float dragOriginal;

	private ValuableObject valuableObject;

	internal bool isValuable;

	internal bool isEnemy;

	internal EnemyRigidbody enemyRigidbody;

	internal bool isPlayer;

	internal bool isMelee;

	internal bool isNonValuable;

	internal NotValuableObject notValuableObject;

	internal bool isKinematic;

	[HideInInspector]
	public float massOriginal;

	private List<(Vector3 position, double timestamp)> positionBuffer = new List<(Vector3, double)>();

	private List<(Quaternion rotation, double timestamp)> rotationBuffer = new List<(Quaternion, double)>();

	private float gradualLerp;

	private Vector3 prevTargetPos;

	private Quaternion prevTargetRot;

	internal Vector3 rbVelocity = Vector3.zero;

	internal Vector3 rbAngularVelocity = Vector3.zero;

	internal Vector3 rbVelocityBeforeImpact = Vector3.zero;

	internal Vector3 currentPosition;

	internal Quaternion currentRotation;

	private bool hasHinge;

	private PhysGrabHinge hinge;

	internal float timerZeroGravity;

	private float timerAlterDrag;

	private float alterDragValue;

	private float timerAlterAngularDrag;

	private float alterAngularDragValue;

	private float timerAlterMass;

	private float alterMassValue;

	private float timerAlterMaterial;

	private float timerAlterDeactivate = -123f;

	private float overrideFragilityTimer;

	internal float overrideDisableBreakEffectsTimer;

	private bool isActive = true;

	private PhysicsMaterial alterMaterialPrevious;

	private PhysicsMaterial alterMaterialCurrent;

	[HideInInspector]
	public Vector3 midPoint;

	[HideInInspector]
	public Vector3 midPointOffset;

	private Vector3 grabRotation;

	private bool isHidden;

	internal float grabDisableTimer;

	internal float droneTargetDisableTimer;

	internal bool heldByLocalPlayer;

	private CollisionDetectionMode previousCollisionDetectionMode;

	private Camera mainCamera;

	private float timerAlterIndestructible;

	internal Transform forceGrabPoint;

	private MapCustom mapCustom;

	private bool hasMapCustom;

	private bool isCart;

	private PhysGrabCart physGrabCart;

	[HideInInspector]
	public List<Transform> colliders = new List<Transform>();

	[HideInInspector]
	public Vector3 centerPoint;

	public Vector3 camRelForward;

	public Vector3 camRelUp;

	internal bool frozen;

	private float frozenTimer;

	private Vector3 frozenPosition;

	private Quaternion frozenRotation;

	private Vector3 frozenVelocity;

	private Vector3 frozenAngularVelocity;

	private Vector3 frozenForce;

	private Vector3 frozenTorque;

	private float overrideDragGoDownTimer;

	private float overrideAngularDragGoDownTimer;

	private float overrideMassGoDownTimer;

	internal float impactHappenedTimer;

	internal float impactLightTimer;

	internal float impactMediumTimer;

	internal float impactHeavyTimer;

	internal float breakLightTimer;

	internal float breakMediumTimer;

	internal float breakHeavyTimer;

	internal bool hasNeverBeenGrabbed = true;

	[HideInInspector]
	public Vector3 boundingBox;

	internal Vector3 spawnTorque = Vector3.zero;

	private float smoothRotationDelta;

	private bool rbIsSleepingPrevious;

	private float overrideTorqueStrengthX = 1f;

	private float overrideTorqueStrengthXTimer;

	private float overrideTorqueStrengthY = 1f;

	private float overrideTorqueStrengthYTimer;

	private float overrideTorqueStrengthZ = 1f;

	private float overrideTorqueStrengthZTimer;

	private float overrideTorqueStrength = 1f;

	private float overrideTorqueStrengthTimer;

	private float overrideGrabStrength = 1f;

	private float overrideGrabStrengthTimer;

	private float overrideGrabRelativeVerticalPosition;

	private float overrideGrabRelativeVerticalPositionTimer;

	private float overrideGrabRelativeHorizontalPosition;

	private float overrideGrabRelativeHorizontalPositionTimer;

	internal bool physRidingDisabled;

	private float overrideMinTorqueStrength;

	private float overrideMinTorqueStrengthTimer;

	private float overrideMinGrabStrength;

	private float overrideMinGrabStrengthTimer;

	private bool overrideExtraGrabStrengthDisable;

	private float overrideExtraGrabStrengthDisableTimer;

	private bool overrideExtraTorqueStrengthDisable;

	private float overrideExtraTorqueStrengthDisableTimer;

	private float overrideKinematicTimer = -1234f;

	internal bool isRotating;

	private float isRotatingTimer;

	private float itemHeightY;

	private float itemWidthX;

	private float itemLengthZ;

	private float overrideKnockOutOfGrabDisableTimer;

	internal bool overrideKnockOutOfGrabDisable;

	internal bool isGun;

	internal GameObject deathPitEffect;

	internal float deathPitEffectDisableTimer;

	private float overrideGrabForceZeroTimer;

	private bool isGrabForceZero;

	internal bool hasValuableDiscoverCustom;

	internal ValuableDiscoverCustom valuableDiscoverCustom;

	private void Awake()
	{
		//IL_0033: Unknown result type (might be due to invalid IL or missing references)
		//IL_0143: Unknown result type (might be due to invalid IL or missing references)
		object[] instantiationData = ((Component)this).GetComponent<PhotonView>().InstantiationData;
		if (instantiationData != null && instantiationData.Length >= 3)
		{
			((Component)this).transform.localScale = new Vector3((float)instantiationData[0], (float)instantiationData[1], (float)instantiationData[2]);
		}
		photonTransformView = ((Component)this).GetComponent<PhotonTransformView>();
		if (!Object.op_Implicit((Object)(object)photonTransformView))
		{
			Debug.LogError((object)("No Photon Transform View found on " + ((Object)((Component)this).gameObject).name));
		}
		else
		{
			photonTransformView.networkThrottleDivisorGet = NetworkThrottleDivisorGet;
		}
		isPlayer = Object.op_Implicit((Object)(object)((Component)this).GetComponent<PlayerTumble>());
		if (isPlayer && Object.op_Implicit((Object)(object)photonTransformView))
		{
			photonTransformView.PlayerTumbleSetup();
		}
		physGrabCart = ((Component)this).GetComponent<PhysGrabCart>();
		isCart = Object.op_Implicit((Object)(object)physGrabCart);
		forceGrabPoint = ((Component)this).transform.Find("Force Grab Point");
		rb = ((Component)this).GetComponent<Rigidbody>();
		if (massOriginal == 0f)
		{
			massOriginal = rb.mass;
		}
		rb.isKinematic = true;
		Transform val = ((Component)this).transform.Find("Center of Mass");
		if (Object.op_Implicit((Object)(object)val))
		{
			rb.centerOfMass = val.localPosition;
		}
		rb.interpolation = (RigidbodyInterpolation)1;
		angularDragOriginal = rb.angularDamping;
		dragOriginal = rb.linearDamping;
		impactDetector = ((Component)this).GetComponent<PhysGrabObjectImpactDetector>();
		if (Object.op_Implicit((Object)(object)impactDetector))
		{
			hasImpactDetector = true;
		}
		valuableObject = ((Component)this).GetComponent<ValuableObject>();
		if (Object.op_Implicit((Object)(object)valuableObject))
		{
			isValuable = true;
		}
		if (isValuable)
		{
			rb.collisionDetectionMode = (CollisionDetectionMode)0;
		}
		else
		{
			rb.collisionDetectionMode = (CollisionDetectionMode)2;
		}
		mapCustom = ((Component)this).GetComponent<MapCustom>();
		if (Object.op_Implicit((Object)(object)mapCustom))
		{
			hasMapCustom = true;
		}
		Transform[] componentsInParent = ((Component)this).GetComponentsInParent<Transform>();
		foreach (Transform val2 in componentsInParent)
		{
			if (((Object)val2).name.Contains("debug") || ((Object)val2).name.Contains("Debug"))
			{
				spawned = true;
			}
		}
	}

	public void TurnXYZ(Quaternion turnX, Quaternion turnY, Quaternion turnZ)
	{
		//IL_0000: Unknown result type (might be due to invalid IL or missing references)
		//IL_0001: Unknown result type (might be due to invalid IL or missing references)
		//IL_0006: Unknown result type (might be due to invalid IL or missing references)
		//IL_000b: Unknown result type (might be due to invalid IL or missing references)
		//IL_000c: Unknown result type (might be due to invalid IL or missing references)
		//IL_000d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0012: Unknown result type (might be due to invalid IL or missing references)
		//IL_0017: Unknown result type (might be due to invalid IL or missing references)
		//IL_0018: Unknown result type (might be due to invalid IL or missing references)
		//IL_0019: Unknown result type (might be due to invalid IL or missing references)
		//IL_001a: Unknown result type (might be due to invalid IL or missing references)
		//IL_001f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0020: Unknown result type (might be due to invalid IL or missing references)
		//IL_0021: Unknown result type (might be due to invalid IL or missing references)
		//IL_0022: Unknown result type (might be due to invalid IL or missing references)
		//IL_0027: Unknown result type (might be due to invalid IL or missing references)
		//IL_003e: Unknown result type (might be due to invalid IL or missing references)
		//IL_003f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0040: Unknown result type (might be due to invalid IL or missing references)
		//IL_0045: Unknown result type (might be due to invalid IL or missing references)
		//IL_004a: Unknown result type (might be due to invalid IL or missing references)
		//IL_004b: Unknown result type (might be due to invalid IL or missing references)
		//IL_004c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0051: Unknown result type (might be due to invalid IL or missing references)
		Vector3 val = turnY * Vector3.forward;
		Vector3 val2 = turnY * Vector3.up;
		val = turnZ * val;
		val2 = turnZ * val2;
		foreach (PhysGrabber item in playerGrabbing)
		{
			item.cameraRelativeGrabbedForward = turnX * val;
			item.cameraRelativeGrabbedUp = turnX * val2;
		}
	}

	public void TorqueToTarget(PhysGrabber player, Quaternion target, float strength, float dampen)
	{
		//IL_000e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0013: Unknown result type (might be due to invalid IL or missing references)
		//IL_001a: Unknown result type (might be due to invalid IL or missing references)
		//IL_001f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0026: Unknown result type (might be due to invalid IL or missing references)
		//IL_002b: Unknown result type (might be due to invalid IL or missing references)
		//IL_002c: Unknown result type (might be due to invalid IL or missing references)
		//IL_002d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0032: Unknown result type (might be due to invalid IL or missing references)
		//IL_0037: Unknown result type (might be due to invalid IL or missing references)
		//IL_0038: Unknown result type (might be due to invalid IL or missing references)
		//IL_0039: Unknown result type (might be due to invalid IL or missing references)
		//IL_003e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0043: Unknown result type (might be due to invalid IL or missing references)
		//IL_0046: Unknown result type (might be due to invalid IL or missing references)
		//IL_0048: Unknown result type (might be due to invalid IL or missing references)
		//IL_004e: Unknown result type (might be due to invalid IL or missing references)
		//IL_004f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0054: Unknown result type (might be due to invalid IL or missing references)
		//IL_0055: Unknown result type (might be due to invalid IL or missing references)
		//IL_0056: Unknown result type (might be due to invalid IL or missing references)
		//IL_005b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0098: Unknown result type (might be due to invalid IL or missing references)
		//IL_0099: Unknown result type (might be due to invalid IL or missing references)
		//IL_009b: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a0: Unknown result type (might be due to invalid IL or missing references)
		//IL_006b: Unknown result type (might be due to invalid IL or missing references)
		//IL_006c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0074: Unknown result type (might be due to invalid IL or missing references)
		//IL_0077: Unknown result type (might be due to invalid IL or missing references)
		//IL_008d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0092: Unknown result type (might be due to invalid IL or missing references)
		//IL_0097: Unknown result type (might be due to invalid IL or missing references)
		//IL_00de: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ea: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ef: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f0: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f6: Unknown result type (might be due to invalid IL or missing references)
		//IL_00fb: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ff: Unknown result type (might be due to invalid IL or missing references)
		//IL_0104: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b0: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b1: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ba: Unknown result type (might be due to invalid IL or missing references)
		//IL_00bd: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d8: Unknown result type (might be due to invalid IL or missing references)
		//IL_00dd: Unknown result type (might be due to invalid IL or missing references)
		//IL_0117: Unknown result type (might be due to invalid IL or missing references)
		//IL_011d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0122: Unknown result type (might be due to invalid IL or missing references)
		//IL_016d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0172: Unknown result type (might be due to invalid IL or missing references)
		//IL_0184: Unknown result type (might be due to invalid IL or missing references)
		//IL_0189: Unknown result type (might be due to invalid IL or missing references)
		//IL_01b5: Unknown result type (might be due to invalid IL or missing references)
		//IL_01b7: Unknown result type (might be due to invalid IL or missing references)
		//IL_01bc: Unknown result type (might be due to invalid IL or missing references)
		//IL_01bd: Unknown result type (might be due to invalid IL or missing references)
		//IL_01c0: Unknown result type (might be due to invalid IL or missing references)
		//IL_01c5: Unknown result type (might be due to invalid IL or missing references)
		//IL_01c6: Unknown result type (might be due to invalid IL or missing references)
		//IL_01c9: Unknown result type (might be due to invalid IL or missing references)
		//IL_01ce: Unknown result type (might be due to invalid IL or missing references)
		//IL_01d6: Unknown result type (might be due to invalid IL or missing references)
		if (!rb.isKinematic)
		{
			Vector3 val = Vector3.zero;
			Vector3 forward = ((Component)this).transform.forward;
			Vector3 up = ((Component)this).transform.up;
			Vector3 val2 = target * Vector3.forward;
			Vector3 val3 = (player.cameraRelativeGrabbedUp = target * Vector3.up);
			player.cameraRelativeGrabbedForward = val2;
			Vector3 val4 = Vector3.Cross(forward, val2);
			if (val4.sqrMagnitude > 1E-08f)
			{
				float num = Vector3.Angle(forward, val2);
				val += val4.normalized * Mathf.Clamp(num, 0f, 60f);
			}
			Vector3 val5 = Vector3.Cross(up, val3);
			if (val5.sqrMagnitude > 1E-08f)
			{
				float num2 = Vector3.Angle(up, val3);
				val += val5.normalized * Mathf.Clamp(num2, 0f, 60f);
			}
			val *= rb.mass;
			Vector3 val6 = Vector3.ClampMagnitude(val, 60f);
			val = val6.normalized;
			if (rb.mass < 1f)
			{
				val *= 0.75f;
			}
			if (rb.linearDamping == 0f)
			{
				rb.linearDamping = 0.05f;
			}
			if (rb.angularDamping == 0f)
			{
				rb.angularDamping = 0.05f;
			}
			float num3 = Vector3.Angle(((Component)this).transform.forward, val2) / 180f;
			float num4 = Vector3.Angle(((Component)this).transform.up, val3) / 180f;
			float num5 = Mathf.Clamp01(rb.mass);
			float num6 = (num3 + num4) * dampen * num5;
			val *= strength;
			val *= num6;
			Vector3 val7 = val * num5;
			rb.AddTorque(val7, (ForceMode)1);
		}
	}

	private void Start()
	{
		//IL_00bf: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c4: Unknown result type (might be due to invalid IL or missing references)
		//IL_00cb: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d7: Unknown result type (might be due to invalid IL or missing references)
		//IL_00dc: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e1: Unknown result type (might be due to invalid IL or missing references)
		//IL_0133: Unknown result type (might be due to invalid IL or missing references)
		//IL_0145: Unknown result type (might be due to invalid IL or missing references)
		//IL_0157: Unknown result type (might be due to invalid IL or missing references)
		//IL_016c: Unknown result type (might be due to invalid IL or missing references)
		//IL_019d: Unknown result type (might be due to invalid IL or missing references)
		//IL_01a2: Unknown result type (might be due to invalid IL or missing references)
		//IL_0178: Unknown result type (might be due to invalid IL or missing references)
		//IL_017d: Unknown result type (might be due to invalid IL or missing references)
		//IL_018b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0190: Unknown result type (might be due to invalid IL or missing references)
		//IL_0195: Unknown result type (might be due to invalid IL or missing references)
		//IL_011a: Unknown result type (might be due to invalid IL or missing references)
		//IL_011f: Unknown result type (might be due to invalid IL or missing references)
		//IL_010c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0246: Unknown result type (might be due to invalid IL or missing references)
		//IL_024b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0257: Unknown result type (might be due to invalid IL or missing references)
		//IL_025c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0268: Unknown result type (might be due to invalid IL or missing references)
		//IL_026d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0279: Unknown result type (might be due to invalid IL or missing references)
		//IL_027e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0303: Unknown result type (might be due to invalid IL or missing references)
		//IL_030a: Expected Obj, but got Unknown
		if (!SemiFunc.IsMultiplayer() && Object.op_Implicit((Object)(object)photonTransformView))
		{
			((Behaviour)photonTransformView).enabled = false;
			photonTransformView = null;
		}
		mainCamera = Camera.main;
		enemyRigidbody = ((Component)this).GetComponent<EnemyRigidbody>();
		if (Object.op_Implicit((Object)(object)enemyRigidbody))
		{
			isEnemy = true;
		}
		isMelee = Object.op_Implicit((Object)(object)((Component)this).GetComponent<ItemMelee>());
		isGun = Object.op_Implicit((Object)(object)((Component)this).GetComponent<ItemGun>());
		if (!isEnemy)
		{
			notValuableObject = ((Component)this).GetComponent<NotValuableObject>();
			isNonValuable = Object.op_Implicit((Object)(object)notValuableObject);
		}
		valuableDiscoverCustom = ((Component)this).GetComponent<ValuableDiscoverCustom>();
		if (Object.op_Implicit((Object)(object)valuableDiscoverCustom))
		{
			hasValuableDiscoverCustom = true;
		}
		Quaternion rotation = ((Component)this).transform.rotation;
		((Component)this).transform.rotation = Quaternion.identity;
		Bounds val = new Bounds(Vector3.zero, Vector3.zero);
		Collider[] componentsInChildren = ((Component)this).GetComponentsInChildren<Collider>();
		bool flag = false;
		Collider[] array = componentsInChildren;
		foreach (Collider val2 in array)
		{
			if (!val2.isTrigger)
			{
				if (flag)
				{
					val.Encapsulate(val2.bounds);
					continue;
				}
				val = val2.bounds;
				flag = true;
			}
		}
		itemHeightY = val.size.y;
		itemWidthX = val.size.x;
		itemLengthZ = val.size.z;
		((Component)this).transform.rotation = rotation;
		if (flag)
		{
			boundingBox = val.size;
			midPointOffset = ((Component)this).transform.InverseTransformPoint(val.center);
		}
		else
		{
			boundingBox = Vector3.one;
			Debug.LogWarning((object)"No colliders found on the object or its children!");
		}
		int num = 0;
		PhysGrabObjectCollider[] componentsInChildren2 = ((Component)this).GetComponentsInChildren<PhysGrabObjectCollider>();
		foreach (PhysGrabObjectCollider physGrabObjectCollider in componentsInChildren2)
		{
			colliders.Add(((Component)physGrabObjectCollider).transform);
			physGrabObjectCollider.colliderID = num;
			num++;
		}
		roomVolumeCheck = ((Component)this).GetComponent<RoomVolumeCheck>();
		photonView = ((Component)this).GetComponent<PhotonView>();
		hinge = ((Component)this).GetComponent<PhysGrabHinge>();
		if (Object.op_Implicit((Object)(object)hinge))
		{
			hasHinge = true;
		}
		if (GameManager.instance.gameMode == 1)
		{
			if (PhotonNetwork.IsMasterClient)
			{
				prevTargetPos = ((Component)this).transform.position;
				prevTargetRot = ((Component)this).transform.rotation;
				targetPos = ((Component)this).transform.position;
				targetRot = ((Component)this).transform.rotation;
				isMaster = true;
			}
			if (PhotonNetwork.IsMasterClient && spawned)
			{
				photonView.TransferOwnership(PhotonNetwork.MasterClient);
			}
		}
		if (!GameManager.Multiplayer() || PhotonNetwork.IsMasterClient)
		{
			if (!Object.op_Implicit((Object)(object)((Component)this).GetComponent<EnemyRigidbody>()))
			{
				((MonoBehaviour)this).StartCoroutine(EnableRigidbody());
			}
		}
		else
		{
			rb.collisionDetectionMode = (CollisionDetectionMode)0;
		}
		if (!overrideTagsAndLayers)
		{
			return;
		}
		foreach (Transform item in ((Component)this).transform)
		{
			Transform val3 = item;
			if (!((Component)val3).CompareTag("Cart") && !((Component)val3).CompareTag("Grab Area") && !((Component)val3).CompareTag("Wall"))
			{
				if (((Component)val3).gameObject.layer != LayerMask.NameToLayer("PlayerOnlyCollision") && ((Component)val3).gameObject.layer != LayerMask.NameToLayer("Triggers"))
				{
					((Component)val3).gameObject.tag = "Phys Grab Object";
				}
				if (((Component)val3).gameObject.layer != LayerMask.NameToLayer("IgnorePhysGrab") && ((Component)val3).gameObject.layer != LayerMask.NameToLayer("CollisionCheck") && ((Component)val3).gameObject.layer != LayerMask.NameToLayer("CartWheels") && ((Component)val3).gameObject.layer != LayerMask.NameToLayer("PhysGrabObjectHinge") && ((Component)val3).gameObject.layer != LayerMask.NameToLayer("PhysGrabObjectCart") && ((Component)val3).gameObject.layer != LayerMask.NameToLayer("Triggers") && ((Component)val3).gameObject.layer != LayerMask.NameToLayer("PlayerOnlyCollision"))
				{
					((Component)val3).gameObject.layer = LayerMask.NameToLayer("PhysGrabObject");
				}
			}
		}
	}

	public void OverrideFragility(float multiplier)
	{
		if (Object.op_Implicit((Object)(object)impactDetector) && isValuable)
		{
			overrideFragilityTimer = 0.1f;
			impactDetector.fragilityMultiplier = multiplier;
		}
	}

	private void OverrideVariousTick()
	{
		if (overrideKnockOutOfGrabDisableTimer <= 0f)
		{
			overrideKnockOutOfGrabDisable = false;
		}
		if (overrideKnockOutOfGrabDisableTimer > 0f)
		{
			overrideKnockOutOfGrabDisableTimer -= Time.deltaTime;
		}
	}

	private void OverrideTimersTick()
	{
		//IL_0020: Unknown result type (might be due to invalid IL or missing references)
		if (timerAlterDeactivate > 0f)
		{
			if (isActive)
			{
				((Component)this).transform.position = AssetManager.instance.physDisabledPosition;
			}
			isActive = false;
			rb.detectCollisions = false;
			rb.isKinematic = true;
			timerAlterDeactivate -= Time.fixedDeltaTime;
		}
		else if (timerAlterDeactivate != -123f)
		{
			OverrideDeactivateReset();
		}
		if (Object.op_Implicit((Object)(object)mapCustom) && hasMapCustom && !isActive)
		{
			mapCustom.Hide();
		}
		OverrideGrabRelativePositionTick();
		OverrideKinematicLogic();
		if (timerAlterMaterial <= 0f && timerAlterMaterial != -123f)
		{
			foreach (Transform collider in colliders)
			{
				if (Object.op_Implicit((Object)(object)collider))
				{
					((Component)collider).GetComponent<Collider>().material = SemiFunc.PhysicMaterialPhysGrabObject();
				}
				else
				{
					colliders.Remove(collider);
				}
			}
			timerAlterMaterial = -123f;
			alterMaterialCurrent = null;
		}
		if (timerAlterMaterial > 0f)
		{
			timerAlterMaterial -= Time.deltaTime;
		}
		if (!SemiFunc.IsMasterClientOrSingleplayer())
		{
			return;
		}
		OverrideVariousTick();
		OverrideStrengthTick();
		if (overrideMassGoDownTimer > 0f)
		{
			overrideMassGoDownTimer -= Time.deltaTime;
		}
		if (timerAlterMass <= 0f && timerAlterMass != -123f)
		{
			if (massOriginal == 0f)
			{
				massOriginal = rb.mass;
			}
			ResetMass();
		}
		if (timerAlterMass > 0f)
		{
			rb.mass = alterMassValue;
			timerAlterMass -= Time.deltaTime;
		}
		if (Object.op_Implicit((Object)(object)impactDetector))
		{
			if (overrideFragilityTimer > 0f)
			{
				overrideFragilityTimer -= Time.deltaTime;
			}
			else if (overrideFragilityTimer != -123f)
			{
				impactDetector.fragilityMultiplier = 1f;
				overrideFragilityTimer = -123f;
			}
		}
		if (overrideAngularDragGoDownTimer > 0f)
		{
			overrideAngularDragGoDownTimer -= Time.deltaTime;
		}
		if (timerAlterAngularDrag > 0f)
		{
			rb.angularDamping = alterAngularDragValue;
			timerAlterAngularDrag -= Time.deltaTime;
		}
		else if (timerAlterAngularDrag != -123f)
		{
			rb.angularDamping = angularDragOriginal;
			timerAlterAngularDrag = -123f;
			alterAngularDragValue = 0f;
		}
		if (overrideDragGoDownTimer > 0f)
		{
			overrideDragGoDownTimer -= Time.deltaTime;
		}
		if (timerAlterDrag > 0f)
		{
			rb.linearDamping = alterDragValue;
			timerAlterDrag -= Time.deltaTime;
		}
		else if (timerAlterDrag != -123f)
		{
			rb.linearDamping = dragOriginal;
			timerAlterDrag = -123f;
			alterDragValue = 0f;
		}
		if (timerAlterIndestructible > 0f)
		{
			if (Object.op_Implicit((Object)(object)impactDetector))
			{
				impactDetector.isIndestructible = true;
			}
			timerAlterIndestructible -= Time.deltaTime;
		}
		else if (timerAlterIndestructible != -123f)
		{
			ResetIndestructible();
		}
		if (timerZeroGravity > 0f)
		{
			rb.useGravity = false;
			timerZeroGravity -= Time.deltaTime;
		}
		else if (timerZeroGravity != -123f)
		{
			rb.useGravity = true;
			timerZeroGravity = -123f;
		}
		if ((hasHinge && !hinge.dead && !hinge.broken) || !rb.useGravity)
		{
			return;
		}
		if (grabbed)
		{
			if (timerAlterAngularDrag <= 0f)
			{
				rb.angularDamping = 0.5f;
			}
			if (timerAlterDrag <= 0f)
			{
				rb.linearDamping = 0.5f;
			}
		}
		else
		{
			if (timerAlterAngularDrag <= 0f)
			{
				rb.angularDamping = angularDragOriginal;
			}
			if (timerAlterDrag <= 0f)
			{
				rb.linearDamping = dragOriginal;
			}
		}
	}

	private IEnumerator EnableRigidbody()
	{
		while (!LevelGenerator.Instance.Generated)
		{
			yield return (object)new WaitForSeconds(0.1f);
		}
		yield return (object)new WaitForSeconds(0.1f);
		spawned = true;
		rb.isKinematic = false;
		if (spawnTorque != Vector3.zero)
		{
			rb.AddTorque(spawnTorque, (ForceMode)1);
		}
	}

	private void TickImpactTimers()
	{
		//IL_0028: Unknown result type (might be due to invalid IL or missing references)
		//IL_002d: Unknown result type (might be due to invalid IL or missing references)
		if (impactHappenedTimer > 0f)
		{
			impactHappenedTimer -= Time.fixedDeltaTime;
		}
		else
		{
			rbVelocityBeforeImpact = rb.linearVelocity;
		}
		if (impactLightTimer > 0f)
		{
			impactLightTimer -= Time.fixedDeltaTime;
		}
		if (impactMediumTimer > 0f)
		{
			impactMediumTimer -= Time.fixedDeltaTime;
		}
		if (impactHeavyTimer > 0f)
		{
			impactHeavyTimer -= Time.fixedDeltaTime;
		}
		if (breakLightTimer > 0f)
		{
			breakLightTimer -= Time.fixedDeltaTime;
		}
		if (breakMediumTimer > 0f)
		{
			breakMediumTimer -= Time.fixedDeltaTime;
		}
		if (breakHeavyTimer > 0f)
		{
			breakHeavyTimer -= Time.fixedDeltaTime;
		}
	}

	public void OverrideMinTorqueStrength(float value, float time = 0.1f)
	{
		overrideMinTorqueStrengthTimer = time;
		overrideMinTorqueStrength = value;
	}

	public void OverrideMinGrabStrength(float value, float time = 0.1f)
	{
		overrideMinGrabStrengthTimer = time;
		overrideMinGrabStrength = value;
	}

	public void OverrideGrabStrength(float value, float time = 0.1f)
	{
		overrideGrabStrengthTimer = time;
		overrideGrabStrength = value;
	}

	public void OverrideTorqueStrengthX(float value, float time = 0.1f)
	{
		overrideTorqueStrengthXTimer = time;
		overrideTorqueStrengthX = value;
	}

	public void OverrideTorqueStrengthY(float value, float time = 0.1f)
	{
		overrideTorqueStrengthYTimer = time;
		overrideTorqueStrengthY = value;
	}

	public void OverrideTorqueStrengthZ(float value, float time = 0.1f)
	{
		overrideTorqueStrengthZTimer = time;
		overrideTorqueStrengthZ = value;
	}

	public void OverrideTorqueStrength(float value, float time = 0.1f)
	{
		overrideTorqueStrengthTimer = time;
		overrideTorqueStrength = value;
	}

	public void OverrideExtraGrabStrengthDisable(float time = 0.1f)
	{
		overrideExtraGrabStrengthDisableTimer = time;
		overrideExtraGrabStrengthDisable = true;
	}

	public void OverrideExtraTorqueStrengthDisable(float time = 0.1f)
	{
		overrideExtraTorqueStrengthDisableTimer = time;
		overrideExtraTorqueStrengthDisable = true;
	}

	public void OverrideKnockOutOfGrabDisable(float time = 0.1f)
	{
		overrideKnockOutOfGrabDisableTimer = time;
		overrideKnockOutOfGrabDisable = true;
	}

	public void OverrideStrengthTick()
	{
		if (overrideTorqueStrengthXTimer <= 0f)
		{
			overrideTorqueStrengthX = 1f;
		}
		if (overrideTorqueStrengthXTimer > 0f)
		{
			overrideTorqueStrengthXTimer -= Time.deltaTime;
		}
		if (overrideTorqueStrengthYTimer <= 0f)
		{
			overrideTorqueStrengthY = 1f;
		}
		if (overrideTorqueStrengthYTimer > 0f)
		{
			overrideTorqueStrengthYTimer -= Time.deltaTime;
		}
		if (overrideTorqueStrengthZTimer <= 0f)
		{
			overrideTorqueStrengthZ = 1f;
		}
		if (overrideTorqueStrengthZTimer > 0f)
		{
			overrideTorqueStrengthZTimer -= Time.deltaTime;
		}
		if (overrideTorqueStrengthTimer <= 0f)
		{
			overrideTorqueStrength = 1f;
		}
		if (overrideTorqueStrengthTimer > 0f)
		{
			overrideTorqueStrengthTimer -= Time.deltaTime;
		}
		if (overrideGrabStrengthTimer <= 0f)
		{
			overrideGrabStrength = 1f;
		}
		if (overrideGrabStrengthTimer > 0f)
		{
			overrideGrabStrengthTimer -= Time.deltaTime;
		}
		if (overrideMinTorqueStrengthTimer <= 0f)
		{
			overrideMinTorqueStrength = 0f;
		}
		if (overrideMinTorqueStrengthTimer > 0f)
		{
			overrideMinTorqueStrengthTimer -= Time.deltaTime;
		}
		if (overrideMinGrabStrengthTimer <= 0f)
		{
			overrideMinGrabStrength = 0f;
		}
		if (overrideMinGrabStrengthTimer > 0f)
		{
			overrideMinGrabStrengthTimer -= Time.deltaTime;
		}
		if (overrideExtraGrabStrengthDisableTimer <= 0f)
		{
			overrideExtraGrabStrengthDisable = false;
		}
		if (overrideExtraGrabStrengthDisableTimer > 0f)
		{
			overrideExtraGrabStrengthDisable = true;
			overrideExtraGrabStrengthDisableTimer -= Time.deltaTime;
		}
		if (overrideExtraTorqueStrengthDisableTimer <= 0f)
		{
			overrideExtraTorqueStrengthDisable = false;
		}
		if (overrideExtraTorqueStrengthDisableTimer > 0f)
		{
			overrideExtraTorqueStrengthDisable = true;
			overrideExtraTorqueStrengthDisableTimer -= Time.deltaTime;
		}
	}

	public void OverrideKinematic(float _time = 0.1f)
	{
		if (_time == 0f)
		{
			overrideKinematicTimer = 0f;
			rb.isKinematic = false;
		}
		else
		{
			overrideKinematicTimer = _time;
			rb.isKinematic = true;
		}
	}

	private void OverrideKinematicLogic()
	{
		if (overrideKinematicTimer > 0f)
		{
			overrideKinematicTimer -= Time.deltaTime;
		}
		else if (overrideKinematicTimer != -1234f)
		{
			overrideKinematicTimer = -1234f;
			if (timerAlterDeactivate <= 0f)
			{
				rb.isKinematic = false;
			}
		}
	}

	private void FixedUpdate()
	{
		//IL_0161: Unknown result type (might be due to invalid IL or missing references)
		//IL_0172: Unknown result type (might be due to invalid IL or missing references)
		//IL_001e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_0029: Unknown result type (might be due to invalid IL or missing references)
		//IL_0033: Unknown result type (might be due to invalid IL or missing references)
		//IL_0038: Unknown result type (might be due to invalid IL or missing references)
		//IL_003d: Unknown result type (might be due to invalid IL or missing references)
		//IL_01cf: Unknown result type (might be due to invalid IL or missing references)
		//IL_01e1: Unknown result type (might be due to invalid IL or missing references)
		//IL_01f3: Unknown result type (might be due to invalid IL or missing references)
		//IL_0205: Unknown result type (might be due to invalid IL or missing references)
		//IL_0211: Unknown result type (might be due to invalid IL or missing references)
		//IL_0216: Unknown result type (might be due to invalid IL or missing references)
		//IL_021c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0221: Unknown result type (might be due to invalid IL or missing references)
		//IL_018f: Unknown result type (might be due to invalid IL or missing references)
		//IL_019a: Unknown result type (might be due to invalid IL or missing references)
		//IL_019f: Unknown result type (might be due to invalid IL or missing references)
		//IL_01aa: Unknown result type (might be due to invalid IL or missing references)
		//IL_01b5: Unknown result type (might be due to invalid IL or missing references)
		//IL_01ba: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a5: Unknown result type (might be due to invalid IL or missing references)
		//IL_00aa: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b6: Unknown result type (might be due to invalid IL or missing references)
		//IL_00bb: Unknown result type (might be due to invalid IL or missing references)
		//IL_0055: Unknown result type (might be due to invalid IL or missing references)
		//IL_005a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0248: Unknown result type (might be due to invalid IL or missing references)
		//IL_024d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0259: Unknown result type (might be due to invalid IL or missing references)
		//IL_025e: Unknown result type (might be due to invalid IL or missing references)
		//IL_00eb: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f0: Unknown result type (might be due to invalid IL or missing references)
		//IL_008b: Unknown result type (might be due to invalid IL or missing references)
		//IL_006f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0075: Invalid comparison between Unknown and I4
		//IL_0115: Unknown result type (might be due to invalid IL or missing references)
		//IL_011a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0103: Unknown result type (might be due to invalid IL or missing references)
		//IL_0105: Unknown result type (might be due to invalid IL or missing references)
		//IL_012e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0131: Unknown result type (might be due to invalid IL or missing references)
		TickImpactTimers();
		if (SemiFunc.IsMasterClientOrSingleplayer())
		{
			if (!rb.IsSleeping())
			{
				Debug.DrawLine(midPoint, midPoint + Vector3.up * 5f, Color.red);
			}
			if (isValuable)
			{
				Vector3 linearVelocity = rb.linearVelocity;
				if (linearVelocity.magnitude > 5f)
				{
					if ((int)rb.collisionDetectionMode != 2)
					{
						rb.collisionDetectionMode = (CollisionDetectionMode)2;
					}
				}
				else if ((int)rb.collisionDetectionMode != 0)
				{
					rb.collisionDetectionMode = (CollisionDetectionMode)0;
				}
			}
			rbVelocity = rb.linearVelocity;
			rbAngularVelocity = rb.angularVelocity;
			isKinematic = rb.isKinematic;
			if (!isKinematic)
			{
				float num = 40f;
				float num2 = 30f;
				Vector3 linearVelocity2 = rb.linearVelocity;
				if (linearVelocity2.sqrMagnitude > num * num)
				{
					rb.linearVelocity = Vector3.ClampMagnitude(linearVelocity2, num);
				}
				Vector3 angularVelocity = rb.angularVelocity;
				if (angularVelocity.sqrMagnitude > num2 * num2)
				{
					rb.angularVelocity = Vector3.ClampMagnitude(angularVelocity, num2);
				}
			}
		}
		if (frozenTimer > 0f)
		{
			frozenTimer -= Time.fixedDeltaTime;
			rb.MovePosition(frozenPosition);
			rb.MoveRotation(frozenRotation);
			if (!rb.isKinematic)
			{
				rb.linearVelocity = Vector3.zero;
				rbVelocity = Vector3.zero;
				rb.angularVelocity = Vector3.zero;
				rbAngularVelocity = Vector3.zero;
			}
			return;
		}
		if (frozen)
		{
			rb.AddForce(frozenVelocity, (ForceMode)2);
			rb.AddTorque(frozenAngularVelocity, (ForceMode)2);
			rb.AddForce(frozenForce, (ForceMode)1);
			rb.AddTorque(frozenTorque, (ForceMode)1);
			frozenForce = Vector3.zero;
			frozenTorque = Vector3.zero;
			frozen = false;
			return;
		}
		if (GameManager.instance.gameMode == 0 || PhotonNetwork.IsMasterClient)
		{
			rbVelocity = rb.linearVelocity;
			rbAngularVelocity = rb.angularVelocity;
		}
		if (playerGrabbing.Count > 0)
		{
			if (hasNeverBeenGrabbed)
			{
				OverrideIndestructible(0.5f);
				hasNeverBeenGrabbed = false;
			}
			grabbed = true;
			heldByLocalPlayer = false;
			if (GameManager.Multiplayer())
			{
				foreach (PhysGrabber item in playerGrabbing)
				{
					if (Object.op_Implicit((Object)(object)item) && item.photonView.IsMine)
					{
						heldByLocalPlayer = true;
					}
				}
			}
			else
			{
				heldByLocalPlayer = true;
			}
		}
		else
		{
			heldByLocalPlayer = false;
			grabbed = false;
		}
		PhysicsGrabbingManipulation();
	}

	private void PhysicsGrabbingManipulation()
	{
		//IL_002b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0030: Unknown result type (might be due to invalid IL or missing references)
		//IL_0031: Unknown result type (might be due to invalid IL or missing references)
		//IL_0036: Unknown result type (might be due to invalid IL or missing references)
		//IL_0037: Unknown result type (might be due to invalid IL or missing references)
		//IL_003c: Unknown result type (might be due to invalid IL or missing references)
		//IL_003e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0043: Unknown result type (might be due to invalid IL or missing references)
		//IL_0048: Unknown result type (might be due to invalid IL or missing references)
		//IL_004d: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e0: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e5: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ef: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f4: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f9: Unknown result type (might be due to invalid IL or missing references)
		//IL_011a: Unknown result type (might be due to invalid IL or missing references)
		//IL_011f: Unknown result type (might be due to invalid IL or missing references)
		//IL_012c: Unknown result type (might be due to invalid IL or missing references)
		//IL_012e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0133: Unknown result type (might be due to invalid IL or missing references)
		//IL_0771: Unknown result type (might be due to invalid IL or missing references)
		//IL_077b: Unknown result type (might be due to invalid IL or missing references)
		//IL_072b: Unknown result type (might be due to invalid IL or missing references)
		//IL_072c: Unknown result type (might be due to invalid IL or missing references)
		//IL_072d: Unknown result type (might be due to invalid IL or missing references)
		//IL_072e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0733: Unknown result type (might be due to invalid IL or missing references)
		//IL_073a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0748: Unknown result type (might be due to invalid IL or missing references)
		//IL_0752: Unknown result type (might be due to invalid IL or missing references)
		//IL_016f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0174: Unknown result type (might be due to invalid IL or missing references)
		//IL_0198: Unknown result type (might be due to invalid IL or missing references)
		//IL_019d: Unknown result type (might be due to invalid IL or missing references)
		//IL_019f: Unknown result type (might be due to invalid IL or missing references)
		//IL_01a1: Unknown result type (might be due to invalid IL or missing references)
		//IL_01a9: Unknown result type (might be due to invalid IL or missing references)
		//IL_01ae: Unknown result type (might be due to invalid IL or missing references)
		//IL_01b3: Unknown result type (might be due to invalid IL or missing references)
		//IL_01e1: Unknown result type (might be due to invalid IL or missing references)
		//IL_01ea: Unknown result type (might be due to invalid IL or missing references)
		//IL_01ef: Unknown result type (might be due to invalid IL or missing references)
		//IL_01f6: Unknown result type (might be due to invalid IL or missing references)
		//IL_0200: Unknown result type (might be due to invalid IL or missing references)
		//IL_0205: Unknown result type (might be due to invalid IL or missing references)
		//IL_0207: Unknown result type (might be due to invalid IL or missing references)
		//IL_020b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0210: Unknown result type (might be due to invalid IL or missing references)
		//IL_021f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0224: Unknown result type (might be due to invalid IL or missing references)
		//IL_0229: Unknown result type (might be due to invalid IL or missing references)
		//IL_022b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0234: Unknown result type (might be due to invalid IL or missing references)
		//IL_0239: Unknown result type (might be due to invalid IL or missing references)
		//IL_0242: Unknown result type (might be due to invalid IL or missing references)
		//IL_0247: Unknown result type (might be due to invalid IL or missing references)
		//IL_024e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0258: Unknown result type (might be due to invalid IL or missing references)
		//IL_025f: Unknown result type (might be due to invalid IL or missing references)
		//IL_01c4: Unknown result type (might be due to invalid IL or missing references)
		//IL_01c9: Unknown result type (might be due to invalid IL or missing references)
		//IL_01cb: Unknown result type (might be due to invalid IL or missing references)
		//IL_01cd: Unknown result type (might be due to invalid IL or missing references)
		//IL_01d5: Unknown result type (might be due to invalid IL or missing references)
		//IL_01da: Unknown result type (might be due to invalid IL or missing references)
		//IL_01df: Unknown result type (might be due to invalid IL or missing references)
		//IL_02e4: Unknown result type (might be due to invalid IL or missing references)
		//IL_02e9: Unknown result type (might be due to invalid IL or missing references)
		//IL_02ed: Unknown result type (might be due to invalid IL or missing references)
		//IL_02f2: Unknown result type (might be due to invalid IL or missing references)
		//IL_02f7: Unknown result type (might be due to invalid IL or missing references)
		//IL_030d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0319: Unknown result type (might be due to invalid IL or missing references)
		//IL_031e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0342: Unknown result type (might be due to invalid IL or missing references)
		//IL_0349: Unknown result type (might be due to invalid IL or missing references)
		//IL_034e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0379: Unknown result type (might be due to invalid IL or missing references)
		//IL_03ca: Unknown result type (might be due to invalid IL or missing references)
		//IL_03d3: Unknown result type (might be due to invalid IL or missing references)
		//IL_03ef: Unknown result type (might be due to invalid IL or missing references)
		//IL_03f3: Unknown result type (might be due to invalid IL or missing references)
		//IL_03f8: Unknown result type (might be due to invalid IL or missing references)
		//IL_03b0: Unknown result type (might be due to invalid IL or missing references)
		//IL_0465: Unknown result type (might be due to invalid IL or missing references)
		//IL_046a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0471: Unknown result type (might be due to invalid IL or missing references)
		//IL_0476: Unknown result type (might be due to invalid IL or missing references)
		//IL_047a: Unknown result type (might be due to invalid IL or missing references)
		//IL_047c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0491: Unknown result type (might be due to invalid IL or missing references)
		//IL_0496: Unknown result type (might be due to invalid IL or missing references)
		//IL_049b: Unknown result type (might be due to invalid IL or missing references)
		//IL_044e: Unknown result type (might be due to invalid IL or missing references)
		//IL_045c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0461: Unknown result type (might be due to invalid IL or missing references)
		//IL_04f8: Unknown result type (might be due to invalid IL or missing references)
		//IL_0500: Unknown result type (might be due to invalid IL or missing references)
		//IL_050b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0510: Unknown result type (might be due to invalid IL or missing references)
		//IL_0515: Unknown result type (might be due to invalid IL or missing references)
		//IL_0522: Unknown result type (might be due to invalid IL or missing references)
		//IL_0527: Unknown result type (might be due to invalid IL or missing references)
		//IL_052c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0531: Unknown result type (might be due to invalid IL or missing references)
		//IL_0538: Unknown result type (might be due to invalid IL or missing references)
		//IL_0545: Unknown result type (might be due to invalid IL or missing references)
		//IL_0551: Unknown result type (might be due to invalid IL or missing references)
		//IL_055c: Unknown result type (might be due to invalid IL or missing references)
		//IL_055d: Unknown result type (might be due to invalid IL or missing references)
		//IL_055f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0564: Unknown result type (might be due to invalid IL or missing references)
		//IL_058c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0593: Unknown result type (might be due to invalid IL or missing references)
		//IL_0598: Unknown result type (might be due to invalid IL or missing references)
		//IL_059d: Unknown result type (might be due to invalid IL or missing references)
		//IL_05a1: Unknown result type (might be due to invalid IL or missing references)
		//IL_05a5: Unknown result type (might be due to invalid IL or missing references)
		//IL_05aa: Unknown result type (might be due to invalid IL or missing references)
		//IL_05af: Unknown result type (might be due to invalid IL or missing references)
		//IL_05b4: Unknown result type (might be due to invalid IL or missing references)
		//IL_05b8: Unknown result type (might be due to invalid IL or missing references)
		//IL_05bc: Unknown result type (might be due to invalid IL or missing references)
		//IL_05c1: Unknown result type (might be due to invalid IL or missing references)
		//IL_05c6: Unknown result type (might be due to invalid IL or missing references)
		//IL_05cb: Unknown result type (might be due to invalid IL or missing references)
		//IL_05cd: Unknown result type (might be due to invalid IL or missing references)
		//IL_05cf: Unknown result type (might be due to invalid IL or missing references)
		//IL_05d1: Unknown result type (might be due to invalid IL or missing references)
		//IL_05dc: Unknown result type (might be due to invalid IL or missing references)
		//IL_05e1: Unknown result type (might be due to invalid IL or missing references)
		//IL_05e6: Unknown result type (might be due to invalid IL or missing references)
		//IL_05eb: Unknown result type (might be due to invalid IL or missing references)
		//IL_05ef: Unknown result type (might be due to invalid IL or missing references)
		//IL_05f6: Unknown result type (might be due to invalid IL or missing references)
		//IL_05fd: Unknown result type (might be due to invalid IL or missing references)
		//IL_0604: Unknown result type (might be due to invalid IL or missing references)
		//IL_04c4: Unknown result type (might be due to invalid IL or missing references)
		//IL_04c6: Unknown result type (might be due to invalid IL or missing references)
		//IL_04e1: Unknown result type (might be due to invalid IL or missing references)
		//IL_04ed: Unknown result type (might be due to invalid IL or missing references)
		//IL_0663: Unknown result type (might be due to invalid IL or missing references)
		//IL_0668: Unknown result type (might be due to invalid IL or missing references)
		//IL_066a: Unknown result type (might be due to invalid IL or missing references)
		//IL_066c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0671: Unknown result type (might be due to invalid IL or missing references)
		//IL_0675: Unknown result type (might be due to invalid IL or missing references)
		//IL_067a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0681: Unknown result type (might be due to invalid IL or missing references)
		//IL_0686: Unknown result type (might be due to invalid IL or missing references)
		//IL_068a: Unknown result type (might be due to invalid IL or missing references)
		//IL_068c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0622: Unknown result type (might be due to invalid IL or missing references)
		//IL_0636: Unknown result type (might be due to invalid IL or missing references)
		//IL_0637: Unknown result type (might be due to invalid IL or missing references)
		//IL_063b: Unknown result type (might be due to invalid IL or missing references)
		//IL_064f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0654: Unknown result type (might be due to invalid IL or missing references)
		//IL_0659: Unknown result type (might be due to invalid IL or missing references)
		//IL_06a1: Unknown result type (might be due to invalid IL or missing references)
		//IL_06a6: Unknown result type (might be due to invalid IL or missing references)
		//IL_06ab: Unknown result type (might be due to invalid IL or missing references)
		//IL_06d7: Unknown result type (might be due to invalid IL or missing references)
		//IL_06d8: Unknown result type (might be due to invalid IL or missing references)
		//IL_06da: Unknown result type (might be due to invalid IL or missing references)
		//IL_06df: Unknown result type (might be due to invalid IL or missing references)
		//IL_06b5: Unknown result type (might be due to invalid IL or missing references)
		//IL_06b6: Unknown result type (might be due to invalid IL or missing references)
		//IL_06ca: Unknown result type (might be due to invalid IL or missing references)
		//IL_06cf: Unknown result type (might be due to invalid IL or missing references)
		//IL_06d4: Unknown result type (might be due to invalid IL or missing references)
		if (isGrabForceZero || (GameManager.Multiplayer() && !isMaster) || rb.isKinematic)
		{
			return;
		}
		Vector3 val = Vector3.zero;
		Vector3 val2 = Vector3.zero;
		Vector3 val3 = Vector3.zero;
		grabDisplacementCurrent = Vector3.zero;
		Vector3 val4 = Vector3.zero;
		playerGrabbing.RemoveAll((PhysGrabber p) => !Object.op_Implicit((Object)(object)p) || !Object.op_Implicit((Object)(object)p.playerAvatar));
		int count = playerGrabbing.Count;
		float mass = rb.mass;
		BoxCollider val5 = (isCart ? ((Component)physGrabCart.inCart).GetComponent<BoxCollider>() : null);
		foreach (PhysGrabber item in playerGrabbing)
		{
			float num = item.forceMax;
			Vector3 val6 = ((Component)item.playerAvatar).transform.position + Vector3.up * 0.25f;
			if (item.playerAvatar.isTumbling)
			{
				val6 = item.playerAvatar.tumble.physGrabObject.centerPoint;
			}
			bool flag = Object.op_Implicit((Object)(object)val5) && Vector3.Distance(((Collider)val5).ClosestPoint(val6), val6) < 0.01f;
			if (flag)
			{
				num *= 0.25f;
			}
			item.grabbedPhysGrabObject = this;
			if (item.physGrabForcesDisabledTimer > 0f)
			{
				continue;
			}
			Vector3 val7 = item.physGrabPointPullerPosition;
			Transform overrideTransform = item.playerAvatar.localCamera.GetOverrideTransform();
			if (overrideGrabRelativeVerticalPositionTimer != 0f)
			{
				Vector3 up = overrideTransform.up;
				val7 += up * overrideGrabRelativeVerticalPosition;
			}
			if (overrideGrabRelativeHorizontalPositionTimer != 0f)
			{
				Vector3 right = overrideTransform.right;
				val7 += right * overrideGrabRelativeHorizontalPosition;
			}
			Vector3 val8 = Vector3.ClampMagnitude(val7 - item.physGrabPoint.position, num) * 10f;
			val8 = Vector3.ClampMagnitude(val8, num);
			Vector3 pointVelocity = rb.GetPointVelocity(item.physGrabPoint.position);
			Vector3 val9 = Vector3.ClampMagnitude(val8 * item.springConstant - pointVelocity * item.dampingConstant, num) * 2f / mass;
			float num2 = item.grabStrength;
			if (item.playerAvatar.isTumbling)
			{
				num2 = 1f;
			}
			if (overrideExtraGrabStrengthDisable)
			{
				num2 = 1f;
			}
			if (overrideMinGrabStrengthTimer > 0f)
			{
				num2 = Mathf.Max(num2, overrideMinGrabStrength + num2 / 5f);
			}
			if (overrideGrabStrengthTimer > 0f)
			{
				num2 = overrideGrabStrength;
			}
			if (item.overrideGrabStrength != -1f)
			{
				num2 = item.overrideGrabStrength;
			}
			grabDisplacementCurrent += val8 * num2;
			num2 = GrabStrengthGet(num2, 30f);
			Vector3 val10 = val9 * num2 * item.forceConstant;
			if (hasHinge && !hinge.dead && !hinge.broken)
			{
				val10 *= 2f;
			}
			foreach (PhysGrabObject physGrabObject in item.playerAvatar.physObjectStander.physGrabObjects)
			{
				if ((Object)(object)physGrabObject == (Object)(object)this && val10.y > 0f)
				{
					val10.y = 0f;
				}
			}
			if (flag && val10.y > 0f)
			{
				val10.y = 0f;
			}
			float num3 = Mathf.Min(Vector3.Distance(val7, item.physGrabPoint.position) * 10f, 1f);
			val10 *= num3;
			if (!isMelee && !isGun)
			{
				float num4 = 2f * num2 * item.forceConstant * num3 / mass;
				if (hasHinge && !hinge.dead && !hinge.broken)
				{
					num4 *= 2f;
				}
				val10 *= GrabForceScaleGet(item, num4, count);
			}
			Vector3 val11 = Vector3.Lerp(item.currentGrabForce, val10, 0.8f);
			item.currentGrabForce = val10;
			if (isMelee || isGun)
			{
				val11 /= (float)count;
			}
			if (isPlayer && item.playerAvatar.isTumbling)
			{
				item.playerAvatar.tumble.rb.AddForceAtPosition(-val11 * item.playerAvatar.tumble.rb.mass, item.physGrabPoint.position, (ForceMode)0);
			}
			val3 += Vector3.Cross(item.physGrabPoint.position - rb.worldCenterOfMass, val11 * rb.mass);
			rb.AddForceAtPosition(val11 * rb.mass, item.physGrabPoint.position, (ForceMode)0);
			val4 += val10;
			if (!hasHinge || hinge.dead || hinge.broken)
			{
				Quaternion val12 = item.GamepadMeleeRotationGet() * item.physRotation;
				Vector3 val13 = overrideTransform.TransformDirection(val12 * item.cameraRelativeGrabbedForward);
				Vector3 val14 = overrideTransform.TransformDirection(val12 * item.cameraRelativeGrabbedUp);
				Quaternion val15 = Quaternion.LookRotation(val13, val14) * Quaternion.Inverse(rb.rotation);
				Vector3 val16 = new Vector3(val15.x, val15.y, val15.z);
				float magnitude = val16.magnitude;
				if (magnitude > 0f)
				{
					float num5 = 2f * Mathf.Atan2(magnitude, Mathf.Abs(val15.w));
					val2 += val16 * (num5 * Mathf.Sign(val15.w) / (magnitude * (float)count));
				}
				Vector3 val17 = GrabTorqueGet(item, ((Component)this).transform.rotation, val13, val14);
				Vector3 val18 = Vector3.Lerp(item.currentTorqueForce, val17, 0.9f);
				item.currentTorqueForce = val17;
				if (isMelee || isGun)
				{
					val18 /= (float)count;
				}
				val = ((!isRotating) ? (val + val18) : (val + val18 * (item.mouseTurningVelocity.magnitude / 100f)));
			}
		}
		if (val.magnitude > 0f)
		{
			if (isCart)
			{
				val.z = 0f;
				val.x = 0f;
			}
			val = GrabTorqueStableGet(val, val2, val3);
			rb.AddTorque(val, (ForceMode)5);
			Rigidbody val19 = rb;
			val19.angularVelocity *= 0.8f;
		}
		if (val4.magnitude > 0f)
		{
			Rigidbody val20 = rb;
			val20.linearVelocity *= 0.98f;
		}
	}

	internal Vector3 GrabTorqueGet(PhysGrabber player, Quaternion rotation, Vector3 worldForward, Vector3 worldUp)
	{
		//IL_000c: Unknown result type (might be due to invalid IL or missing references)
		//IL_000d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0012: Unknown result type (might be due to invalid IL or missing references)
		//IL_0017: Unknown result type (might be due to invalid IL or missing references)
		//IL_0018: Unknown result type (might be due to invalid IL or missing references)
		//IL_0019: Unknown result type (might be due to invalid IL or missing references)
		//IL_001e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0023: Unknown result type (might be due to invalid IL or missing references)
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_0029: Unknown result type (might be due to invalid IL or missing references)
		//IL_0032: Unknown result type (might be due to invalid IL or missing references)
		//IL_0033: Unknown result type (might be due to invalid IL or missing references)
		//IL_0034: Unknown result type (might be due to invalid IL or missing references)
		//IL_0039: Unknown result type (might be due to invalid IL or missing references)
		//IL_0074: Unknown result type (might be due to invalid IL or missing references)
		//IL_0075: Unknown result type (might be due to invalid IL or missing references)
		//IL_0077: Unknown result type (might be due to invalid IL or missing references)
		//IL_007c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0049: Unknown result type (might be due to invalid IL or missing references)
		//IL_004a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0053: Unknown result type (might be due to invalid IL or missing references)
		//IL_0058: Unknown result type (might be due to invalid IL or missing references)
		//IL_0059: Unknown result type (might be due to invalid IL or missing references)
		//IL_0069: Unknown result type (might be due to invalid IL or missing references)
		//IL_006e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0073: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b8: Unknown result type (might be due to invalid IL or missing references)
		//IL_00be: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c7: Unknown result type (might be due to invalid IL or missing references)
		//IL_00cc: Unknown result type (might be due to invalid IL or missing references)
		//IL_00cd: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d4: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d9: Unknown result type (might be due to invalid IL or missing references)
		//IL_008c: Unknown result type (might be due to invalid IL or missing references)
		//IL_008d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0096: Unknown result type (might be due to invalid IL or missing references)
		//IL_009b: Unknown result type (might be due to invalid IL or missing references)
		//IL_009c: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ad: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b2: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b7: Unknown result type (might be due to invalid IL or missing references)
		//IL_016d: Unknown result type (might be due to invalid IL or missing references)
		//IL_016e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0173: Unknown result type (might be due to invalid IL or missing references)
		//IL_0178: Unknown result type (might be due to invalid IL or missing references)
		//IL_0184: Unknown result type (might be due to invalid IL or missing references)
		//IL_0185: Unknown result type (might be due to invalid IL or missing references)
		//IL_018a: Unknown result type (might be due to invalid IL or missing references)
		//IL_018f: Unknown result type (might be due to invalid IL or missing references)
		//IL_01a3: Unknown result type (might be due to invalid IL or missing references)
		//IL_01b5: Unknown result type (might be due to invalid IL or missing references)
		//IL_01ba: Unknown result type (might be due to invalid IL or missing references)
		//IL_01bb: Unknown result type (might be due to invalid IL or missing references)
		//IL_01bc: Unknown result type (might be due to invalid IL or missing references)
		//IL_01be: Unknown result type (might be due to invalid IL or missing references)
		//IL_01c3: Unknown result type (might be due to invalid IL or missing references)
		//IL_01c5: Unknown result type (might be due to invalid IL or missing references)
		//IL_01c6: Unknown result type (might be due to invalid IL or missing references)
		//IL_01cb: Unknown result type (might be due to invalid IL or missing references)
		//IL_01cc: Unknown result type (might be due to invalid IL or missing references)
		//IL_01d1: Unknown result type (might be due to invalid IL or missing references)
		//IL_014a: Unknown result type (might be due to invalid IL or missing references)
		//IL_014d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0152: Unknown result type (might be due to invalid IL or missing references)
		//IL_0242: Unknown result type (might be due to invalid IL or missing references)
		//IL_0243: Unknown result type (might be due to invalid IL or missing references)
		//IL_0245: Unknown result type (might be due to invalid IL or missing references)
		//IL_024a: Unknown result type (might be due to invalid IL or missing references)
		//IL_024b: Unknown result type (might be due to invalid IL or missing references)
		//IL_024e: Unknown result type (might be due to invalid IL or missing references)
		//IL_02ce: Unknown result type (might be due to invalid IL or missing references)
		//IL_02d0: Unknown result type (might be due to invalid IL or missing references)
		//IL_02d1: Unknown result type (might be due to invalid IL or missing references)
		//IL_02d6: Unknown result type (might be due to invalid IL or missing references)
		//IL_02db: Unknown result type (might be due to invalid IL or missing references)
		//IL_02df: Unknown result type (might be due to invalid IL or missing references)
		//IL_02e6: Unknown result type (might be due to invalid IL or missing references)
		//IL_02ed: Unknown result type (might be due to invalid IL or missing references)
		//IL_02f4: Unknown result type (might be due to invalid IL or missing references)
		//IL_0305: Unknown result type (might be due to invalid IL or missing references)
		//IL_033b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0342: Unknown result type (might be due to invalid IL or missing references)
		//IL_0347: Unknown result type (might be due to invalid IL or missing references)
		//IL_03f5: Unknown result type (might be due to invalid IL or missing references)
		//IL_03ff: Unknown result type (might be due to invalid IL or missing references)
		//IL_0404: Unknown result type (might be due to invalid IL or missing references)
		//IL_0438: Unknown result type (might be due to invalid IL or missing references)
		//IL_03ea: Unknown result type (might be due to invalid IL or missing references)
		//IL_03ee: Unknown result type (might be due to invalid IL or missing references)
		//IL_03f3: Unknown result type (might be due to invalid IL or missing references)
		//IL_042a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0431: Unknown result type (might be due to invalid IL or missing references)
		//IL_0436: Unknown result type (might be due to invalid IL or missing references)
		float mass = rb.mass;
		Vector3 val = rotation * Vector3.forward;
		Vector3 val2 = rotation * Vector3.up;
		Vector3 val3 = Vector3.zero;
		float num = player.grabStrength;
		Vector3 val4 = Vector3.Cross(val, worldForward);
		if (val4.sqrMagnitude > 0f)
		{
			val3 += val4 / val4.magnitude * Mathf.Min(GrabAngleGet(val, worldForward), 60f);
		}
		Vector3 val5 = Vector3.Cross(val2, worldUp);
		if (val5.sqrMagnitude > 0f)
		{
			val3 += val5 / val5.magnitude * Mathf.Min(GrabAngleGet(val2, worldUp), 60f);
		}
		Vector3 val6 = Vector3.ClampMagnitude(val3, 60f);
		val3 = val6.normalized;
		val3 *= overrideTorqueStrength;
		if (player.mouseTurningVelocity.magnitude > 0.1f && massOriginal > 1f)
		{
			float num2 = Mathf.Max(mass, 0.1f);
			float num3 = 2f / num2;
			float num4 = 1f + boundingBox.magnitude;
			num3 += num4;
			if (num3 < 1f)
			{
				num3 = 1f;
			}
			if (num3 > 10f)
			{
				num3 = 10f;
			}
			val3 *= num3;
		}
		float num5 = Mathf.Clamp01(mass);
		if (mass > 1f)
		{
			num5 *= 0.9f;
		}
		float num6 = GrabAngleGet(rotation * Vector3.forward, worldForward) / 180f;
		float num7 = GrabAngleGet(rotation * Vector3.up, worldUp) / 180f;
		float num8 = num6 + num7;
		val3 *= num8 * 15f * num5 * Time.fixedDeltaTime;
		Quaternion val7 = Quaternion.LookRotation(worldForward, worldUp);
		Vector3 val8 = Quaternion.Inverse(rotation) * val3;
		float num9 = overrideTorqueStrengthX;
		float num10 = overrideTorqueStrengthY;
		float num11 = overrideTorqueStrengthZ;
		if (num9 > 1f)
		{
			num9 *= num8;
		}
		if (num10 > 1f)
		{
			num10 *= num8;
		}
		if (num11 > 1f)
		{
			num11 *= num8;
		}
		val8.x *= num9;
		val8.y *= num10;
		val8.z *= num11;
		val3 = rotation * val8;
		Vector3 val9 = val3 * num5;
		if (overrideExtraTorqueStrengthDisable)
		{
			num = 1f;
		}
		if (player.playerAvatar.isTumbling)
		{
			num = 1f;
		}
		if (overrideMinTorqueStrengthTimer > 0f)
		{
			num = Mathf.Max(num, overrideMinTorqueStrength + num / 5f);
		}
		if (num < overrideTorqueStrength)
		{
			num = overrideTorqueStrength;
		}
		num = GrabStrengthGet(num, float.PositiveInfinity);
		if (isRotating)
		{
			num *= 5f;
		}
		Quaternion val10 = val7 * Quaternion.Inverse(rotation);
		Vector3 val11 = new Vector3(val10.x, val10.y, val10.z);
		float num12 = Mathf.Min(2f * Mathf.Atan2(val11.magnitude, Mathf.Abs(val10.w)) * 57.29578f / 30f, 1f);
		float num13 = num + 10f;
		Vector3 val12 = val9 * num13 * num12;
		float num14 = Mathf.Max(mass * 30f, 1f);
		num14 = num14 / 7f * mass * 6f;
		num14 /= 1f + num;
		if (!isMelee)
		{
			float num15 = itemHeightY * itemHeightY;
			if (num15 > 10f)
			{
				num15 *= 2.5f;
			}
			float num16 = itemWidthX * itemWidthX;
			float num17 = itemLengthZ * itemLengthZ;
			float num18 = (num15 + num16 + num17) * 4f;
			float num19 = 1f + num18;
			num19 /= 1f + num;
			val12 /= num19;
		}
		val12 *= 6500f / num14;
		if (impactDetector.isEnemy && !impactDetector.enemyRigidbody.enemy.IsStunned())
		{
			val12 *= 0.25f;
		}
		return val12;
	}

	private float GrabStrengthGet(float strength, float dividerLimit)
	{
		float num = ((rb.mass < 2f) ? 7f : 20f);
		float num2 = 1f + num * 0.5f;
		for (int i = 0; i < 3; i++)
		{
			float num3 = 1f / (1f + num2);
			float num4 = num2 - 1f + num3 * num3 - num * 0.5f;
			num2 -= num4 / (1f - 2f * num3 * num3 * num3);
		}
		float num5 = Mathf.Min(strength, num2);
		float num6 = Mathf.Min((num5 - 1f) / num, 0.9f);
		float num7 = Mathf.Lerp(num5, num5 / (1f + num5), num6);
		float num8 = Mathf.Min((strength - 1f) / num, 0.9f);
		float num9 = Mathf.Lerp(strength, strength / (1f + Mathf.Min(strength, dividerLimit)), num8);
		return Mathf.Max(num7, num9);
	}

	private static float GrabAngleGet(Vector3 from, Vector3 to)
	{
		//IL_0000: Unknown result type (might be due to invalid IL or missing references)
		//IL_0001: Unknown result type (might be due to invalid IL or missing references)
		//IL_0002: Unknown result type (might be due to invalid IL or missing references)
		//IL_0007: Unknown result type (might be due to invalid IL or missing references)
		//IL_000f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0010: Unknown result type (might be due to invalid IL or missing references)
		Vector3 val = Vector3.Cross(from, to);
		return Mathf.Atan2(val.magnitude, Vector3.Dot(from, to)) * 57.29578f;
	}

	private float GrabForceScaleGet(PhysGrabber player, float gain, int grabbers)
	{
		//IL_0006: Unknown result type (might be due to invalid IL or missing references)
		//IL_0011: Unknown result type (might be due to invalid IL or missing references)
		//IL_0016: Unknown result type (might be due to invalid IL or missing references)
		//IL_001b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0026: Unknown result type (might be due to invalid IL or missing references)
		//IL_0031: Unknown result type (might be due to invalid IL or missing references)
		//IL_0036: Unknown result type (might be due to invalid IL or missing references)
		//IL_003b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0040: Unknown result type (might be due to invalid IL or missing references)
		//IL_0047: Unknown result type (might be due to invalid IL or missing references)
		//IL_004c: Unknown result type (might be due to invalid IL or missing references)
		//IL_004f: Unknown result type (might be due to invalid IL or missing references)
		//IL_006e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0075: Unknown result type (might be due to invalid IL or missing references)
		//IL_0094: Unknown result type (might be due to invalid IL or missing references)
		//IL_009b: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ba: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c1: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c6: Unknown result type (might be due to invalid IL or missing references)
		//IL_00cc: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00da: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e0: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e7: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ef: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f5: Unknown result type (might be due to invalid IL or missing references)
		//IL_00fc: Unknown result type (might be due to invalid IL or missing references)
		//IL_0103: Unknown result type (might be due to invalid IL or missing references)
		//IL_0109: Unknown result type (might be due to invalid IL or missing references)
		//IL_0110: Unknown result type (might be due to invalid IL or missing references)
		//IL_0119: Unknown result type (might be due to invalid IL or missing references)
		//IL_011f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0126: Unknown result type (might be due to invalid IL or missing references)
		//IL_012d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0133: Unknown result type (might be due to invalid IL or missing references)
		//IL_013a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0144: Unknown result type (might be due to invalid IL or missing references)
		//IL_014a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0151: Unknown result type (might be due to invalid IL or missing references)
		//IL_015a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0160: Unknown result type (might be due to invalid IL or missing references)
		//IL_0167: Unknown result type (might be due to invalid IL or missing references)
		//IL_0170: Unknown result type (might be due to invalid IL or missing references)
		//IL_0176: Unknown result type (might be due to invalid IL or missing references)
		//IL_017d: Unknown result type (might be due to invalid IL or missing references)
		Vector3 val = Quaternion.Inverse(rb.rotation * rb.inertiaTensorRotation) * (player.physGrabPoint.position - rb.worldCenterOfMass);
		Vector3 inertiaTensor = rb.inertiaTensor;
		Vector3 val2 = new Vector3((inertiaTensor.x > 0f) ? (rb.mass / inertiaTensor.x) : 0f, (inertiaTensor.y > 0f) ? (rb.mass / inertiaTensor.y) : 0f, (inertiaTensor.z > 0f) ? (rb.mass / inertiaTensor.z) : 0f);
		float num = val.y * val.y * val2.z + val.z * val.z * val2.y;
		float num2 = val.x * val.x * val2.z + val.z * val.z * val2.x;
		float num3 = val.x * val.x * val2.y + val.y * val.y * val2.x;
		float num4 = val.x * val.y * val2.z;
		float num5 = val.x * val.z * val2.y;
		float num6 = val.y * val.z * val2.x;
		float num7 = num + num2 + num3;
		float num8 = num * num + num2 * num2 + num3 * num3 + 2f * (num4 * num4 + num5 * num5 + num6 * num6);
		float num9 = 1f + 0.5f * (num7 + Mathf.Sqrt(Mathf.Max(0f, 2f * num8 - num7 * num7)));
		float fixedDeltaTime = Time.fixedDeltaTime;
		float num10 = gain * num9 * (float)grabbers * (player.dampingConstant * fixedDeltaTime + player.springConstant * 20f * fixedDeltaTime * fixedDeltaTime);
		return 1f / Mathf.Max(1f, num10);
	}

	private Vector3 GrabTorqueStableGet(Vector3 torque, Vector3 rotationError, Vector3 pullTorque)
	{
		//IL_0027: Unknown result type (might be due to invalid IL or missing references)
		//IL_003b: Unknown result type (might be due to invalid IL or missing references)
		//IL_003d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0042: Unknown result type (might be due to invalid IL or missing references)
		//IL_0048: Unknown result type (might be due to invalid IL or missing references)
		//IL_0049: Unknown result type (might be due to invalid IL or missing references)
		//IL_005c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0067: Unknown result type (might be due to invalid IL or missing references)
		//IL_006c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0071: Unknown result type (might be due to invalid IL or missing references)
		//IL_0072: Unknown result type (might be due to invalid IL or missing references)
		//IL_0077: Unknown result type (might be due to invalid IL or missing references)
		//IL_0078: Unknown result type (might be due to invalid IL or missing references)
		//IL_007d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0085: Unknown result type (might be due to invalid IL or missing references)
		//IL_008a: Unknown result type (might be due to invalid IL or missing references)
		//IL_008c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0039: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a1: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a8: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b0: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c5: Unknown result type (might be due to invalid IL or missing references)
		//IL_00cc: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d4: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e9: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f0: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f8: Unknown result type (might be due to invalid IL or missing references)
		//IL_00fd: Unknown result type (might be due to invalid IL or missing references)
		//IL_0102: Unknown result type (might be due to invalid IL or missing references)
		//IL_012a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0134: Unknown result type (might be due to invalid IL or missing references)
		//IL_0139: Unknown result type (might be due to invalid IL or missing references)
		//IL_013c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0141: Unknown result type (might be due to invalid IL or missing references)
		//IL_0147: Unknown result type (might be due to invalid IL or missing references)
		//IL_014c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0154: Unknown result type (might be due to invalid IL or missing references)
		//IL_0159: Unknown result type (might be due to invalid IL or missing references)
		//IL_015e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0164: Unknown result type (might be due to invalid IL or missing references)
		//IL_0169: Unknown result type (might be due to invalid IL or missing references)
		//IL_016e: Unknown result type (might be due to invalid IL or missing references)
		//IL_01bb: Unknown result type (might be due to invalid IL or missing references)
		//IL_01c2: Unknown result type (might be due to invalid IL or missing references)
		//IL_01c7: Unknown result type (might be due to invalid IL or missing references)
		//IL_01c9: Unknown result type (might be due to invalid IL or missing references)
		//IL_01ce: Unknown result type (might be due to invalid IL or missing references)
		//IL_01db: Unknown result type (might be due to invalid IL or missing references)
		//IL_01e0: Unknown result type (might be due to invalid IL or missing references)
		//IL_0202: Unknown result type (might be due to invalid IL or missing references)
		float fixedDeltaTime = Time.fixedDeltaTime;
		float num = Mathf.Clamp01(1f - rb.angularDamping * fixedDeltaTime);
		if (num <= 0.0001f)
		{
			return torque;
		}
		float magnitude = torque.magnitude;
		if (magnitude <= 0.0001f)
		{
			return torque;
		}
		Vector3 val = torque / magnitude;
		float num2 = Mathf.Max(0f, Vector3.Dot(rotationError, val));
		Quaternion val2 = rb.rotation * rb.inertiaTensorRotation;
		Vector3 val3 = Quaternion.Inverse(val2) * pullTorque;
		Vector3 inertiaTensor = rb.inertiaTensor;
		Vector3 val4 = val2 * new Vector3((inertiaTensor.x > 0f) ? (val3.x / inertiaTensor.x) : 0f, (inertiaTensor.y > 0f) ? (val3.y / inertiaTensor.y) : 0f, (inertiaTensor.z > 0f) ? (val3.z / inertiaTensor.z) : 0f);
		float num3 = 2f * magnitude / Mathf.Max(num2, 0.0001f);
		float num4 = num3 * fixedDeltaTime * fixedDeltaTime * num;
		Vector3 val5 = (rb.angularVelocity * 0.8f + val4 * fixedDeltaTime) * num;
		Vector3 val6 = Quaternion.Inverse(rb.rotation) * (val5 * (num3 * fixedDeltaTime));
		if (overrideTorqueStrengthX == 0f)
		{
			val6.x = 0f;
		}
		if (overrideTorqueStrengthY == 0f)
		{
			val6.y = 0f;
		}
		if (overrideTorqueStrengthZ == 0f)
		{
			val6.z = 0f;
		}
		Vector3 result = (torque - rb.rotation * val6) / (1f + num4);
		if (isCart)
		{
			result.x = 0f;
			result.z = 0f;
		}
		return result;
	}

	public void OverrideGrabVerticalPosition(float pos)
	{
		overrideGrabRelativeVerticalPosition = pos;
		overrideGrabRelativeVerticalPositionTimer = 0.1f;
	}

	public void OverrideGrabHorizontalPosition(float pos)
	{
		overrideGrabRelativeHorizontalPosition = pos;
		overrideGrabRelativeHorizontalPositionTimer = 0.1f;
	}

	private void OverrideGrabRelativePositionTick()
	{
		if (overrideGrabRelativeHorizontalPositionTimer <= 0f)
		{
			overrideGrabRelativeHorizontalPosition = 0f;
		}
		if (overrideGrabRelativeHorizontalPositionTimer > 0f)
		{
			overrideGrabRelativeHorizontalPositionTimer -= Time.deltaTime;
		}
		if (overrideGrabRelativeVerticalPositionTimer <= 0f)
		{
			overrideGrabRelativeVerticalPosition = 0f;
		}
		if (overrideGrabRelativeVerticalPositionTimer > 0f)
		{
			overrideGrabRelativeVerticalPositionTimer -= Time.deltaTime;
		}
	}

	public void OverrideZeroGravity(float time = 0.1f)
	{
		timerZeroGravity = time;
	}

	public void OverrideDrag(float value, float time = 0.1f)
	{
		timerAlterDrag = time;
		if (alterDragValue <= value)
		{
			alterDragValue = value;
			overrideDragGoDownTimer = 0.1f;
		}
		else if (overrideDragGoDownTimer <= 0f)
		{
			alterDragValue = value;
		}
	}

	public void OverrideAngularDrag(float value, float time = 0.1f)
	{
		timerAlterAngularDrag = time;
		if (alterAngularDragValue <= value)
		{
			alterAngularDragValue = value;
			overrideAngularDragGoDownTimer = 0.1f;
		}
		else if (overrideAngularDragGoDownTimer <= 0f)
		{
			alterAngularDragValue = value;
		}
	}

	public void OverrideIndestructible(float time = 0.1f)
	{
		timerAlterIndestructible = time;
	}

	public void OverrideDeactivate(float time = 0.1f)
	{
		//IL_0020: Unknown result type (might be due to invalid IL or missing references)
		//IL_002a: Unknown result type (might be due to invalid IL or missing references)
		//IL_003c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0041: Unknown result type (might be due to invalid IL or missing references)
		timerAlterDeactivate = time;
		rb.isKinematic = true;
		if (SemiFunc.IsMasterClientOrSingleplayer() && ((Component)this).transform.position != AssetManager.instance.physDisabledPosition)
		{
			Teleport(AssetManager.instance.physDisabledPosition, Quaternion.identity);
		}
	}

	public void OverrideDeactivateReset()
	{
		isActive = true;
		rb.detectCollisions = true;
		if (spawned)
		{
			rb.isKinematic = false;
		}
		timerAlterDeactivate = -123f;
	}

	public void OverrideBreakEffects(float _time)
	{
		overrideDisableBreakEffectsTimer = _time;
	}

	public void OverrideMaterial(PhysicsMaterial material, float time = 0.1f)
	{
		if ((Object)(object)alterMaterialCurrent != (Object)(object)alterMaterialPrevious || (Object)(object)alterMaterialCurrent == (Object)null)
		{
			alterMaterialPrevious = alterMaterialCurrent;
			foreach (Transform collider in colliders)
			{
				if (Object.op_Implicit((Object)(object)collider))
				{
					Collider component = ((Component)collider).GetComponent<Collider>();
					if (Object.op_Implicit((Object)(object)component))
					{
						component.material = material;
					}
				}
				else
				{
					colliders.Remove(collider);
				}
			}
		}
		alterMaterialCurrent = material;
		timerAlterMaterial = time;
	}

	public void ResetIndestructible()
	{
		if (Object.op_Implicit((Object)(object)impactDetector))
		{
			impactDetector.isIndestructible = false;
		}
		timerAlterIndestructible = -123f;
	}

	public void SetPositionLogic(Vector3 _position, Quaternion _rotation)
	{
		//IL_0007: Unknown result type (might be due to invalid IL or missing references)
		//IL_000d: Unknown result type (might be due to invalid IL or missing references)
		//IL_006a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0076: Unknown result type (might be due to invalid IL or missing references)
		//IL_0082: Unknown result type (might be due to invalid IL or missing references)
		//IL_008e: Unknown result type (might be due to invalid IL or missing references)
		//IL_005c: Unknown result type (might be due to invalid IL or missing references)
		//IL_005d: Unknown result type (might be due to invalid IL or missing references)
		if (SemiFunc.IsMasterClientOrSingleplayer() && _position == AssetManager.instance.physDisabledPosition)
		{
			ItemDrone[] array = Object.FindObjectsByType<ItemDrone>((FindObjectsSortMode)0);
			foreach (ItemDrone itemDrone in array)
			{
				if (itemDrone.magnetActive && !((Object)(object)itemDrone.magnetTargetPhysGrabObject != (Object)(object)this))
				{
					itemDrone.MagnetActiveToggle(toggleBool: false);
				}
			}
		}
		if (SemiFunc.IsMultiplayer())
		{
			photonTransformView.Teleport(_position, _rotation);
			return;
		}
		((Component)this).transform.position = _position;
		((Component)this).transform.rotation = _rotation;
		rb.position = _position;
		rb.rotation = _rotation;
	}

	[PunRPC]
	private void SetPositionRPC(Vector3 position, Quaternion rotation, PhotonMessageInfo _info = default(PhotonMessageInfo))
	{
		//IL_0040: Unknown result type (might be due to invalid IL or missing references)
		//IL_0049: Unknown result type (might be due to invalid IL or missing references)
		//IL_0056: Unknown result type (might be due to invalid IL or missing references)
		//IL_002c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0063: Unknown result type (might be due to invalid IL or missing references)
		//IL_0070: Unknown result type (might be due to invalid IL or missing references)
		//IL_007d: Unknown result type (might be due to invalid IL or missing references)
		//IL_008a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0097: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a6: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a7: Unknown result type (might be due to invalid IL or missing references)
		if (!SemiFunc.IsMasterClientOrSingleplayer())
		{
			return;
		}
		if (isPlayer)
		{
			PlayerTumble component = ((Component)this).GetComponent<PlayerTumble>();
			if (!Object.op_Implicit((Object)(object)component) || !Object.op_Implicit((Object)(object)component.playerAvatar) || !SemiFunc.MasterAndOwnerOnlyRPC(_info, component.playerAvatar.photonView))
			{
				return;
			}
		}
		else if (!SemiFunc.MasterOnlyRPC(_info))
		{
			return;
		}
		if (float.IsFinite(position.x) && float.IsFinite(position.y) && float.IsFinite(position.z) && float.IsFinite(rotation.x) && float.IsFinite(rotation.y) && float.IsFinite(rotation.z) && float.IsFinite(rotation.w))
		{
			SetPositionLogic(position, rotation);
		}
	}

	public void Teleport(Vector3 position, Quaternion rotation)
	{
		//IL_0071: Unknown result type (might be due to invalid IL or missing references)
		//IL_0072: Unknown result type (might be due to invalid IL or missing references)
		//IL_005a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0063: Unknown result type (might be due to invalid IL or missing references)
		if (SemiFunc.IsMultiplayer() && !SemiFunc.IsMasterClient())
		{
			if (isPlayer)
			{
				PlayerTumble component = ((Component)this).GetComponent<PlayerTumble>();
				if (Object.op_Implicit((Object)(object)component) && Object.op_Implicit((Object)(object)component.playerAvatar) && component.playerAvatar.photonView.IsMine)
				{
					photonView.RPC("SetPositionRPC", (RpcTarget)2, new object[2] { position, rotation });
				}
			}
		}
		else
		{
			SetPositionLogic(position, rotation);
		}
	}

	public void OverrideMass(float value, float time = 0.1f)
	{
		timerAlterMass = time;
		if (alterMassValue <= value)
		{
			alterMassValue = value;
			overrideMassGoDownTimer = 0.1f;
		}
		else if (overrideMassGoDownTimer <= 0f)
		{
			alterMassValue = value;
		}
	}

	public void DeathPitEffectCreate()
	{
		//IL_002f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0035: Unknown result type (might be due to invalid IL or missing references)
		if (!(deathPitEffectDisableTimer > 0f))
		{
			if (SemiFunc.IsMultiplayer())
			{
				photonView.RPC("DeathPitEffectCreateRPC", (RpcTarget)0, Array.Empty<object>());
			}
			else
			{
				DeathPitEffectCreateRPC();
			}
		}
	}

	[PunRPC]
	private void DeathPitEffectCreateRPC(PhotonMessageInfo _info = default(PhotonMessageInfo))
	{
		//IL_0000: Unknown result type (might be due to invalid IL or missing references)
		//IL_008b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0096: Unknown result type (might be due to invalid IL or missing references)
		//IL_0073: Unknown result type (might be due to invalid IL or missing references)
		if (!SemiFunc.MasterOnlyRPC(_info))
		{
			return;
		}
		if (!Object.op_Implicit((Object)(object)deathPitEffect) || deathPitEffect.GetComponent<DeathPitSaveEffect>().timeCurrent <= 0f)
		{
			if (isEnemy)
			{
				deathPitEffect = Object.Instantiate<GameObject>(AssetManager.instance.deathPitSaveEffect, ((Component)enemyRigidbody).transform);
				deathPitEffect.transform.position = enemyRigidbody.enemy.CenterTransform.position;
			}
			else
			{
				deathPitEffect = Object.Instantiate<GameObject>(AssetManager.instance.deathPitSaveEffect, centerPoint, ((Component)this).transform.rotation, ((Component)this).transform);
			}
			deathPitEffect.GetComponent<DeathPitSaveEffect>().Setup(this);
		}
		else
		{
			deathPitEffect.GetComponent<DeathPitSaveEffect>().Reset();
		}
	}

	public void DisableDeathPitEffect(float _time)
	{
		deathPitEffectDisableTimer = _time;
	}

	private void DeathPitEffectUnparent()
	{
		if (Object.op_Implicit((Object)(object)deathPitEffect))
		{
			deathPitEffect.transform.parent = null;
			DeathPitSaveEffect component = deathPitEffect.GetComponent<DeathPitSaveEffect>();
			component.timeCurrent = 0f;
			((Behaviour)component).enabled = true;
		}
	}

	public void ResetMass()
	{
		rb.mass = massOriginal;
		timerAlterMass = -123f;
		alterMassValue = 0f;
	}

	internal bool GrabHoldRotationTryGet(PhysGrabber player, Quaternion rotation, Vector3 grabPosition, out Quaternion holdRotation)
	{
		//IL_0002: Unknown result type (might be due to invalid IL or missing references)
		//IL_0003: Unknown result type (might be due to invalid IL or missing references)
		//IL_004e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0055: Unknown result type (might be due to invalid IL or missing references)
		//IL_005a: Unknown result type (might be due to invalid IL or missing references)
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_006f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0086: Unknown result type (might be due to invalid IL or missing references)
		//IL_008b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0090: Unknown result type (might be due to invalid IL or missing references)
		//IL_0091: Unknown result type (might be due to invalid IL or missing references)
		//IL_0098: Unknown result type (might be due to invalid IL or missing references)
		//IL_009d: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a2: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a8: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a9: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ae: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b5: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ba: Unknown result type (might be due to invalid IL or missing references)
		//IL_00bb: Unknown result type (might be due to invalid IL or missing references)
		//IL_00cf: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d5: Unknown result type (might be due to invalid IL or missing references)
		//IL_00dc: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f0: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f6: Unknown result type (might be due to invalid IL or missing references)
		//IL_00fd: Unknown result type (might be due to invalid IL or missing references)
		//IL_0111: Unknown result type (might be due to invalid IL or missing references)
		//IL_0117: Unknown result type (might be due to invalid IL or missing references)
		//IL_011e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0123: Unknown result type (might be due to invalid IL or missing references)
		//IL_0128: Unknown result type (might be due to invalid IL or missing references)
		//IL_013b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0145: Unknown result type (might be due to invalid IL or missing references)
		//IL_014a: Unknown result type (might be due to invalid IL or missing references)
		//IL_014c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0151: Unknown result type (might be due to invalid IL or missing references)
		//IL_0166: Unknown result type (might be due to invalid IL or missing references)
		//IL_0167: Unknown result type (might be due to invalid IL or missing references)
		//IL_0169: Unknown result type (might be due to invalid IL or missing references)
		//IL_016e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0170: Unknown result type (might be due to invalid IL or missing references)
		//IL_0171: Unknown result type (might be due to invalid IL or missing references)
		//IL_0173: Unknown result type (might be due to invalid IL or missing references)
		//IL_0178: Unknown result type (might be due to invalid IL or missing references)
		//IL_018e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0190: Unknown result type (might be due to invalid IL or missing references)
		//IL_0324: Unknown result type (might be due to invalid IL or missing references)
		//IL_0326: Unknown result type (might be due to invalid IL or missing references)
		//IL_032b: Unknown result type (might be due to invalid IL or missing references)
		//IL_032c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0331: Unknown result type (might be due to invalid IL or missing references)
		//IL_01a5: Unknown result type (might be due to invalid IL or missing references)
		//IL_01a6: Unknown result type (might be due to invalid IL or missing references)
		//IL_01a8: Unknown result type (might be due to invalid IL or missing references)
		//IL_01b2: Unknown result type (might be due to invalid IL or missing references)
		//IL_01b7: Unknown result type (might be due to invalid IL or missing references)
		//IL_01bc: Unknown result type (might be due to invalid IL or missing references)
		//IL_01c1: Unknown result type (might be due to invalid IL or missing references)
		//IL_01c3: Unknown result type (might be due to invalid IL or missing references)
		//IL_01cd: Unknown result type (might be due to invalid IL or missing references)
		//IL_01d2: Unknown result type (might be due to invalid IL or missing references)
		//IL_01d6: Unknown result type (might be due to invalid IL or missing references)
		//IL_01d7: Unknown result type (might be due to invalid IL or missing references)
		//IL_01d9: Unknown result type (might be due to invalid IL or missing references)
		//IL_01e3: Unknown result type (might be due to invalid IL or missing references)
		//IL_01e8: Unknown result type (might be due to invalid IL or missing references)
		//IL_01ed: Unknown result type (might be due to invalid IL or missing references)
		//IL_01f2: Unknown result type (might be due to invalid IL or missing references)
		//IL_01f4: Unknown result type (might be due to invalid IL or missing references)
		//IL_01fe: Unknown result type (might be due to invalid IL or missing references)
		//IL_0203: Unknown result type (might be due to invalid IL or missing references)
		//IL_0207: Unknown result type (might be due to invalid IL or missing references)
		//IL_0208: Unknown result type (might be due to invalid IL or missing references)
		//IL_020a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0214: Unknown result type (might be due to invalid IL or missing references)
		//IL_0219: Unknown result type (might be due to invalid IL or missing references)
		//IL_021e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0223: Unknown result type (might be due to invalid IL or missing references)
		//IL_0225: Unknown result type (might be due to invalid IL or missing references)
		//IL_022f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0234: Unknown result type (might be due to invalid IL or missing references)
		//IL_0236: Unknown result type (might be due to invalid IL or missing references)
		//IL_0238: Unknown result type (might be due to invalid IL or missing references)
		//IL_023a: Unknown result type (might be due to invalid IL or missing references)
		//IL_023f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0241: Unknown result type (might be due to invalid IL or missing references)
		//IL_0243: Unknown result type (might be due to invalid IL or missing references)
		//IL_025d: Unknown result type (might be due to invalid IL or missing references)
		//IL_025f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0266: Unknown result type (might be due to invalid IL or missing references)
		//IL_0268: Unknown result type (might be due to invalid IL or missing references)
		//IL_026a: Unknown result type (might be due to invalid IL or missing references)
		//IL_026c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0276: Unknown result type (might be due to invalid IL or missing references)
		//IL_0278: Unknown result type (might be due to invalid IL or missing references)
		//IL_027a: Unknown result type (might be due to invalid IL or missing references)
		//IL_027c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0286: Unknown result type (might be due to invalid IL or missing references)
		//IL_028d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0292: Unknown result type (might be due to invalid IL or missing references)
		//IL_0299: Unknown result type (might be due to invalid IL or missing references)
		//IL_029b: Unknown result type (might be due to invalid IL or missing references)
		//IL_029d: Unknown result type (might be due to invalid IL or missing references)
		//IL_02a7: Unknown result type (might be due to invalid IL or missing references)
		//IL_02ac: Unknown result type (might be due to invalid IL or missing references)
		//IL_02ae: Unknown result type (might be due to invalid IL or missing references)
		//IL_02b1: Unknown result type (might be due to invalid IL or missing references)
		//IL_02b2: Unknown result type (might be due to invalid IL or missing references)
		//IL_02b4: Unknown result type (might be due to invalid IL or missing references)
		//IL_02b9: Unknown result type (might be due to invalid IL or missing references)
		//IL_02be: Unknown result type (might be due to invalid IL or missing references)
		//IL_02d6: Unknown result type (might be due to invalid IL or missing references)
		//IL_02dd: Unknown result type (might be due to invalid IL or missing references)
		//IL_02e2: Unknown result type (might be due to invalid IL or missing references)
		//IL_02d0: Unknown result type (might be due to invalid IL or missing references)
		//IL_02d2: Unknown result type (might be due to invalid IL or missing references)
		holdRotation = rotation;
		if (!rb.useGravity || !Object.op_Implicit((Object)(object)player.physGrabPoint) || isCart || (hasHinge && !hinge.dead && !hinge.broken))
		{
			return true;
		}
		Vector3 val = Vector3.Cross(grabPosition - rb.worldCenterOfMass, Physics.gravity * rb.mass / (float)Mathf.Max(1, playerGrabbing.Count));
		Quaternion val2 = rotation * rb.inertiaTensorRotation;
		Vector3 val3 = Quaternion.Inverse(val2) * val;
		Vector3 inertiaTensor = rb.inertiaTensor;
		Vector3 val4 = val2 * new Vector3((inertiaTensor.x > 0f) ? (val3.x / inertiaTensor.x) : 0f, (inertiaTensor.y > 0f) ? (val3.y / inertiaTensor.y) : 0f, (inertiaTensor.z > 0f) ? (val3.z / inertiaTensor.z) : 0f);
		if (val4.sqrMagnitude < 0.0001f)
		{
			return true;
		}
		Vector3 val5 = val4.normalized * 2f;
		Vector3 val6 = Vector3.zero;
		float sqrMagnitude = val4.sqrMagnitude;
		for (int i = 0; i < 12; i++)
		{
			Vector3 val7 = GrabHoldTorqueGet(player, rotation, val5);
			Vector3 val8 = val4 - val7;
			if (val8.sqrMagnitude < sqrMagnitude)
			{
				sqrMagnitude = val8.sqrMagnitude;
				val6 = val5;
			}
			if (val8.sqrMagnitude < 0.0001f)
			{
				break;
			}
			Vector3 val9 = (GrabHoldTorqueGet(player, rotation, val5 + Vector3.right * 0.1f) - val7) * 10f;
			Vector3 val10 = (GrabHoldTorqueGet(player, rotation, val5 + Vector3.up * 0.1f) - val7) * 10f;
			Vector3 val11 = (GrabHoldTorqueGet(player, rotation, val5 + Vector3.forward * 0.1f) - val7) * 10f;
			Vector3 val12 = Vector3.Cross(val10, val11);
			float num = Vector3.Dot(val9, val12);
			if (Mathf.Abs(num) < 0.0001f)
			{
				break;
			}
			Vector3 val13 = new Vector3(Vector3.Dot(val8, val12), Vector3.Dot(val9, Vector3.Cross(val8, val11)), Vector3.Dot(val9, Vector3.Cross(val10, val8))) / num;
			for (int j = 0; j < 6; j++)
			{
				Vector3 val14 = Vector3.ClampMagnitude(val5 + val13, 25f);
				Vector3 val15 = val4 - GrabHoldTorqueGet(player, rotation, val14);
				if (val15.sqrMagnitude < val8.sqrMagnitude)
				{
					val5 = val14;
					break;
				}
				val13 *= 0.5f;
			}
		}
		if (sqrMagnitude > Mathf.Max(0.0001f, val4.sqrMagnitude * 0.0025f))
		{
			return false;
		}
		holdRotation = Quaternion.AngleAxis(val6.magnitude, val6) * rotation;
		return true;
	}

	private Vector3 GrabHoldTorqueGet(PhysGrabber player, Quaternion rotation, Vector3 correction)
	{
		//IL_0007: Unknown result type (might be due to invalid IL or missing references)
		//IL_0008: Unknown result type (might be due to invalid IL or missing references)
		//IL_000d: Unknown result type (might be due to invalid IL or missing references)
		//IL_000e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0013: Unknown result type (might be due to invalid IL or missing references)
		//IL_0016: Unknown result type (might be due to invalid IL or missing references)
		//IL_0017: Unknown result type (might be due to invalid IL or missing references)
		//IL_0018: Unknown result type (might be due to invalid IL or missing references)
		//IL_001d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0022: Unknown result type (might be due to invalid IL or missing references)
		//IL_0023: Unknown result type (might be due to invalid IL or missing references)
		//IL_0028: Unknown result type (might be due to invalid IL or missing references)
		//IL_002d: Unknown result type (might be due to invalid IL or missing references)
		Quaternion val = Quaternion.AngleAxis(correction.magnitude, correction) * rotation;
		return GrabTorqueGet(player, rotation, val * Vector3.forward, val * Vector3.up);
	}

	internal void RotationRelease()
	{
		isRotating = false;
		isRotatingTimer = 0f;
	}

	private void IsRotatingTimer()
	{
		if (isRotatingTimer <= 0f)
		{
			isRotating = false;
		}
		if (isRotatingTimer > 0f)
		{
			isRotatingTimer -= Time.deltaTime;
		}
	}

	private void ClientVelocitySync()
	{
		//IL_001d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0022: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0033: Unknown result type (might be due to invalid IL or missing references)
		if (!SemiFunc.IsMasterClientOrSingleplayer() && Object.op_Implicit((Object)(object)photonTransformView))
		{
			rbVelocity = photonTransformView.receivedVelocity;
			rbAngularVelocity = photonTransformView.receivedAngularVelocity;
			isKinematic = photonTransformView.receivedRigidbodyKinematic;
			if (Object.op_Implicit((Object)(object)impactDetector))
			{
				impactDetector.isSliding = photonTransformView.receivedSliding;
			}
		}
	}

	public void NetworkTrackerOverride(float _time = 0.3f)
	{
		networkTrackerOverrideTimer = Mathf.Max(networkTrackerOverrideTimer, _time);
	}

	private bool NetworkBoundsAdd(Bounds _addBounds, ref Bounds _bounds, ref bool _hasBounds)
	{
		//IL_0002: Unknown result type (might be due to invalid IL or missing references)
		//IL_0015: Unknown result type (might be due to invalid IL or missing references)
		//IL_0028: Unknown result type (might be due to invalid IL or missing references)
		//IL_003b: Unknown result type (might be due to invalid IL or missing references)
		//IL_004e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0061: Unknown result type (might be due to invalid IL or missing references)
		//IL_0082: Unknown result type (might be due to invalid IL or missing references)
		//IL_0083: Unknown result type (might be due to invalid IL or missing references)
		//IL_0079: Unknown result type (might be due to invalid IL or missing references)
		if (!float.IsFinite(_addBounds.center.x) || !float.IsFinite(_addBounds.center.y) || !float.IsFinite(_addBounds.center.z) || !float.IsFinite(_addBounds.extents.x) || !float.IsFinite(_addBounds.extents.y) || !float.IsFinite(_addBounds.extents.z))
		{
			return false;
		}
		if (_hasBounds)
		{
			_bounds.Encapsulate(_addBounds);
		}
		else
		{
			_bounds = _addBounds;
			_hasBounds = true;
		}
		return true;
	}

	private bool NetworkBoundsGet(out Vector3 _center, out float _radius)
	{
		//IL_0007: Unknown result type (might be due to invalid IL or missing references)
		//IL_000c: Unknown result type (might be due to invalid IL or missing references)
		//IL_001a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0077: Unknown result type (might be due to invalid IL or missing references)
		//IL_0131: Unknown result type (might be due to invalid IL or missing references)
		//IL_0136: Unknown result type (might be due to invalid IL or missing references)
		//IL_013e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0143: Unknown result type (might be due to invalid IL or missing references)
		//IL_00fb: Unknown result type (might be due to invalid IL or missing references)
		_center = ((Component)this).transform.position;
		_radius = 0f;
		Bounds _bounds = default;
		bool _hasBounds = false;
		networkBoundsColliders.Clear();
		((Component)this).GetComponentsInChildren<Collider>(false, networkBoundsColliders);
		foreach (Collider networkBoundsCollider in networkBoundsColliders)
		{
			if (Object.op_Implicit((Object)(object)networkBoundsCollider) && networkBoundsCollider.enabled && ((Component)networkBoundsCollider).gameObject.activeInHierarchy && !networkBoundsCollider.isTrigger && !NetworkBoundsAdd(networkBoundsCollider.bounds, ref _bounds, ref _hasBounds))
			{
				return false;
			}
		}
		networkBoundsRenderers.Clear();
		((Component)this).GetComponentsInChildren<Renderer>(false, networkBoundsRenderers);
		foreach (Renderer networkBoundsRenderer in networkBoundsRenderers)
		{
			if (Object.op_Implicit((Object)(object)networkBoundsRenderer) && networkBoundsRenderer.enabled && ((Component)networkBoundsRenderer).gameObject.activeInHierarchy && !NetworkBoundsAdd(networkBoundsRenderer.bounds, ref _bounds, ref _hasBounds))
			{
				return false;
			}
		}
		if (!_hasBounds)
		{
			return false;
		}
		_center = _bounds.center;
		Vector3 extents = _bounds.extents;
		_radius = extents.magnitude;
		if (float.IsFinite(_center.x) && float.IsFinite(_center.y) && float.IsFinite(_center.z) && float.IsFinite(_radius))
		{
			return _radius >= 0f;
		}
		return false;
	}

	private bool NetworkGrabActiveGet()
	{
		if (grabbed || grabbedLocal || playerGrabbing.Count > 0)
		{
			return true;
		}
		if (!Object.op_Implicit((Object)(object)GameDirector.instance) || GameDirector.instance.PlayerList == null)
		{
			return false;
		}
		foreach (PlayerAvatar player in GameDirector.instance.PlayerList)
		{
			PhysGrabber physGrabber = (Object.op_Implicit((Object)(object)player) ? player.physGrabber : null);
			if (Object.op_Implicit((Object)(object)physGrabber) && physGrabber.grabbed && (Object)(object)physGrabber.grabbedPhysGrabObject == (Object)(object)this)
			{
				return true;
			}
		}
		return false;
	}

	private void NetworkThrottleTick()
	{
		if (SemiFunc.IsMultiplayer() && PhotonNetwork.IsMasterClient && Object.op_Implicit((Object)(object)photonTransformView))
		{
			photonTransformView.networkSliding = Object.op_Implicit((Object)(object)impactDetector) && impactDetector.isSliding;
			if (networkTrackerOverrideTimer > 0f)
			{
				networkTrackerOverrideTimer = Mathf.Max(0f, networkTrackerOverrideTimer - Time.deltaTime);
			}
		}
	}

	private int NetworkThrottleDivisorGet()
	{
		//IL_00cb: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ee: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b4: Unknown result type (might be due to invalid IL or missing references)
		if (!Object.op_Implicit((Object)(object)this) || !((Behaviour)this).isActiveAndEnabled || !SemiFunc.IsMultiplayer() || !PhotonNetwork.IsMasterClient)
		{
			return 1;
		}
		if (!Object.op_Implicit((Object)(object)photonTransformView) || isPlayer || isEnemy || NetworkGrabActiveGet())
		{
			return 1;
		}
		SemiFunc.NetworkThrottleSendViewpointsTick();
		if (!SemiFunc.NetworkThrottleReady())
		{
			return 1;
		}
		if (enemyInteractTimer > 0f || (Object.op_Implicit((Object)(object)valuableObject) && valuableObject.discovered) || hasMapCustom || (hasValuableDiscoverCustom && valuableDiscoverCustom.hasCustomMap) || networkTrackerOverrideTimer > 0f || photonTransformView.InterestGroupOverrideActive() || SemiFunc.NetworkInterestExtractionExempt(centerPoint))
		{
			return 1;
		}
		if (SemiFunc.NetworkThrottleDivisor(((Component)this).transform.position, _physObject: true) == 1)
		{
			return 1;
		}
		if (!NetworkBoundsGet(out var _center, out var _radius))
		{
			return 1;
		}
		return SemiFunc.NetworkThrottleDivisor(_center, _physObject: true, _radius);
	}

	private void Update()
	{
		//IL_0093: Unknown result type (might be due to invalid IL or missing references)
		//IL_0098: Unknown result type (might be due to invalid IL or missing references)
		//IL_009d: Unknown result type (might be due to invalid IL or missing references)
		//IL_039f: Unknown result type (might be due to invalid IL or missing references)
		//IL_03a4: Unknown result type (might be due to invalid IL or missing references)
		//IL_03b6: Unknown result type (might be due to invalid IL or missing references)
		//IL_0190: Unknown result type (might be due to invalid IL or missing references)
		//IL_01b5: Unknown result type (might be due to invalid IL or missing references)
		//IL_01da: Unknown result type (might be due to invalid IL or missing references)
		//IL_03f8: Unknown result type (might be due to invalid IL or missing references)
		//IL_0407: Unknown result type (might be due to invalid IL or missing references)
		//IL_020a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0264: Unknown result type (might be due to invalid IL or missing references)
		//IL_0228: Unknown result type (might be due to invalid IL or missing references)
		//IL_02b9: Unknown result type (might be due to invalid IL or missing references)
		//IL_027d: Unknown result type (might be due to invalid IL or missing references)
		//IL_02d2: Unknown result type (might be due to invalid IL or missing references)
		ClientVelocitySync();
		NetworkThrottleTick();
		if (grabbed)
		{
			for (int i = 0; i < playerGrabbing.Count; i++)
			{
				if (playerGrabbing[i].isRotating)
				{
					isRotating = true;
					isRotatingTimer = 0.1f;
				}
				if (!Object.op_Implicit((Object)(object)playerGrabbing[i]) || !playerGrabbing[i].grabbed)
				{
					playerGrabbing.RemoveAt(i);
					i--;
				}
			}
		}
		IsRotatingTimer();
		midPoint = ((Component)this).transform.TransformPoint(midPointOffset);
		OverrideTimersTick();
		OverrideGrabForceZeroTick();
		if (playerGrabbing.Count > 0)
		{
			lastPlayerGrabbing = playerGrabbing[playerGrabbing.Count - 1].playerAvatar;
			grabbedTimer = 3f;
		}
		else if (Object.op_Implicit((Object)(object)lastPlayerGrabbing))
		{
			grabbedTimer -= Time.deltaTime;
			if (grabbedTimer <= 0f)
			{
				lastPlayerGrabbing = null;
			}
		}
		if (SemiFunc.IsMasterClientOrSingleplayer())
		{
			if (enemyInteractTimer > 0f)
			{
				enemyInteractTimer -= Time.deltaTime;
				if (playerGrabbing.Count > 0)
				{
					enemyInteractTimer = 0f;
				}
			}
			if (hasImpactDetector && !impactDetector.isIndestructible)
			{
				if (heavyImpactImpulse)
				{
					impactDetector.ImpactHeavy(150f, centerPoint);
					heavyImpactImpulse = false;
				}
				if (mediumImpactImpulse)
				{
					impactDetector.ImpactMedium(80f, centerPoint);
					mediumImpactImpulse = false;
				}
				if (lightImpactImpulse)
				{
					impactDetector.ImpactLight(20f, centerPoint);
					lightImpactImpulse = false;
				}
				if (heavyBreakImpulse)
				{
					if (isValuable || isNonValuable)
					{
						impactDetector.BreakHeavy(centerPoint);
					}
					else
					{
						impactDetector.Break(0f, centerPoint, impactDetector.breakLevelHeavy);
					}
					heavyBreakImpulse = false;
				}
				if (mediumBreakImpulse)
				{
					if (isValuable || isNonValuable)
					{
						impactDetector.BreakMedium(centerPoint);
					}
					else
					{
						impactDetector.Break(0f, centerPoint, impactDetector.breakLevelMedium);
					}
					mediumBreakImpulse = false;
				}
				if (lightBreakImpulse)
				{
					if (isValuable || isNonValuable)
					{
						impactDetector.BreakLight(centerPoint);
					}
					else
					{
						impactDetector.Break(0f, centerPoint, impactDetector.breakLevelLight);
					}
					lightBreakImpulse = false;
				}
			}
			else
			{
				lightBreakImpulse = false;
				mediumBreakImpulse = false;
				heavyBreakImpulse = false;
			}
			if (overrideDisableBreakEffectsTimer > 0f)
			{
				overrideDisableBreakEffectsTimer -= Time.deltaTime;
			}
			if (dead && playerGrabbing.Count == 0)
			{
				DestroyPhysGrabObject();
			}
		}
		if (grabDisableTimer > 0f)
		{
			grabDisableTimer -= Time.deltaTime;
		}
		if (droneTargetDisableTimer > 0f)
		{
			droneTargetDisableTimer -= Time.deltaTime;
		}
		if (deathPitEffectDisableTimer > 0f)
		{
			deathPitEffectDisableTimer -= Time.deltaTime;
		}
		centerPoint = midPoint;
		if (!SemiFunc.IsMasterClientOrSingleplayer() || !(((Component)this).transform.position.y < -50f))
		{
			return;
		}
		if (impactDetector.destroyDisable)
		{
			if (impactDetector.destroyDisableTeleport && Object.op_Implicit((Object)(object)TruckSafetySpawnPoint.instance))
			{
				Teleport(((Component)TruckSafetySpawnPoint.instance).transform.position, ((Component)TruckSafetySpawnPoint.instance).transform.rotation);
			}
		}
		else
		{
			impactDetector.DestroyObject();
		}
	}

	public void EnemyInteractTimeSet()
	{
		enemyInteractTimer = 10f;
	}

	internal void FreezeForcesReset()
	{
		//IL_0013: Unknown result type (might be due to invalid IL or missing references)
		//IL_0018: Unknown result type (might be due to invalid IL or missing references)
		//IL_001e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0023: Unknown result type (might be due to invalid IL or missing references)
		//IL_0029: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0034: Unknown result type (might be due to invalid IL or missing references)
		//IL_0039: Unknown result type (might be due to invalid IL or missing references)
		frozenTimer = 0f;
		frozen = false;
		frozenVelocity = Vector3.zero;
		frozenAngularVelocity = Vector3.zero;
		frozenForce = Vector3.zero;
		frozenTorque = Vector3.zero;
	}

	public void FreezeForces(float _time, Vector3 _force, Vector3 _torque)
	{
		//IL_008d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0092: Unknown result type (might be due to invalid IL or missing references)
		//IL_0093: Unknown result type (might be due to invalid IL or missing references)
		//IL_0098: Unknown result type (might be due to invalid IL or missing references)
		//IL_009f: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a4: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a5: Unknown result type (might be due to invalid IL or missing references)
		//IL_00aa: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b5: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c5: Unknown result type (might be due to invalid IL or missing references)
		//IL_0031: Unknown result type (might be due to invalid IL or missing references)
		//IL_0036: Unknown result type (might be due to invalid IL or missing references)
		//IL_0042: Unknown result type (might be due to invalid IL or missing references)
		//IL_0047: Unknown result type (might be due to invalid IL or missing references)
		//IL_0053: Unknown result type (might be due to invalid IL or missing references)
		//IL_0058: Unknown result type (might be due to invalid IL or missing references)
		//IL_0064: Unknown result type (might be due to invalid IL or missing references)
		//IL_0069: Unknown result type (might be due to invalid IL or missing references)
		//IL_006f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0074: Unknown result type (might be due to invalid IL or missing references)
		//IL_007a: Unknown result type (might be due to invalid IL or missing references)
		//IL_007f: Unknown result type (might be due to invalid IL or missing references)
		if (Object.op_Implicit((Object)(object)rb) && !rb.isKinematic)
		{
			frozenTimer = _time;
			if (!frozen)
			{
				frozenPosition = ((Component)this).transform.position;
				frozenRotation = ((Component)this).transform.rotation;
				frozenVelocity = rb.linearVelocity;
				frozenAngularVelocity = rb.angularVelocity;
				frozenForce = Vector3.zero;
				frozenTorque = Vector3.zero;
				frozen = true;
			}
			frozenForce += _force;
			frozenTorque += _torque;
			rb.linearVelocity = Vector3.zero;
			rb.angularVelocity = Vector3.zero;
		}
	}

	private void OnDestroy()
	{
		if (Object.op_Implicit((Object)(object)photonTransformView))
		{
			photonTransformView.networkThrottleDivisorGet = null;
			photonTransformView.ThrottleDivisorSet(1);
		}
		if (RoundDirector.instance.dollarHaulList.Contains(((Component)this).gameObject))
		{
			RoundDirector.instance.dollarHaulList.Remove(((Component)this).gameObject);
		}
		DeathPitEffectUnparent();
	}

	public void DestroyPhysGrabObject()
	{
		if (GameManager.instance.gameMode == 0)
		{
			Object.Destroy((Object)(object)((Component)this).gameObject);
		}
		else if (photonView.ViewID != 0 && PhotonNetwork.IsMasterClient)
		{
			if (photonView.ViewID == photonView.InstantiationId && photonView.IsMine)
			{
				PhotonNetwork.Destroy(((Component)this).gameObject);
			}
			else
			{
				photonView.RPC("DestroyPhysGrabObjectRPC", (RpcTarget)0, Array.Empty<object>());
			}
		}
	}

	[PunRPC]
	private void DestroyPhysGrabObjectRPC(PhotonMessageInfo _info = default(PhotonMessageInfo))
	{
		//IL_0000: Unknown result type (might be due to invalid IL or missing references)
		if (SemiFunc.MasterOnlyRPC(_info))
		{
			Object.Destroy((Object)(object)((Component)this).gameObject);
		}
	}

	private void OnDisable()
	{
		RoundDirector.instance.PhysGrabObjectRemove(this);
	}

	private void OnEnable()
	{
		RoundDirector.instance.PhysGrabObjectAdd(this);
	}

	public void GrabStarted(PhysGrabber player)
	{
		if (grabbedLocal)
		{
			return;
		}
		grabbedLocal = true;
		if (GameManager.instance.gameMode == 0)
		{
			if (!playerGrabbing.Contains(player))
			{
				playerGrabbing.Add(player);
				ExtractionHalloweenContact extractionHalloweenContact = default;
				if (SemiFunc.GameEventIsHalloween() && ((Component)this).TryGetComponent<ExtractionHalloweenContact>(ref extractionHalloweenContact))
				{
					extractionHalloweenContact.InteractionRegister();
				}
			}
		}
		else
		{
			photonView.RPC("GrabStartedRPC", (RpcTarget)2, new object[1] { player.photonView.ViewID });
		}
	}

	public void GrabEnded(PhysGrabber player)
	{
		if (!grabbedLocal)
		{
			return;
		}
		grabbedLocal = false;
		if (GameManager.instance.gameMode == 0)
		{
			Throw(player);
			if (playerGrabbing.Contains(player))
			{
				playerGrabbing.Remove(player);
			}
		}
		else
		{
			photonView.RPC("GrabEndedRPC", (RpcTarget)2, new object[1] { player.photonView.ViewID });
		}
	}

	public void GrabLink(int playerPhotonID, int colliderID, Vector3 point, Vector3 cameraRelativeGrabbedForward, Vector3 cameraRelativeGrabbedUp, int _grabRevision)
	{
		//IL_0034: Unknown result type (might be due to invalid IL or missing references)
		//IL_003d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0047: Unknown result type (might be due to invalid IL or missing references)
		if (photonView.ViewID != 0)
		{
			photonView.RPC("GrabLinkRPC", (RpcTarget)0, new object[6] { playerPhotonID, colliderID, point, cameraRelativeGrabbedForward, cameraRelativeGrabbedUp, _grabRevision });
		}
	}

	[PunRPC]
	private void GrabLinkRPC(int playerPhotonID, int colliderID, Vector3 point, Vector3 cameraRelativeGrabbedForward, Vector3 cameraRelativeGrabbedUp, int _grabRevision, PhotonMessageInfo _info = default(PhotonMessageInfo))
	{
		//IL_001f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0086: Unknown result type (might be due to invalid IL or missing references)
		//IL_0093: Unknown result type (might be due to invalid IL or missing references)
		//IL_0094: Unknown result type (might be due to invalid IL or missing references)
		//IL_0099: Unknown result type (might be due to invalid IL or missing references)
		//IL_0050: Unknown result type (might be due to invalid IL or missing references)
		//IL_0051: Unknown result type (might be due to invalid IL or missing references)
		//IL_005c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0063: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0073: Unknown result type (might be due to invalid IL or missing references)
		//IL_015f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0164: Unknown result type (might be due to invalid IL or missing references)
		//IL_0169: Unknown result type (might be due to invalid IL or missing references)
		//IL_0176: Unknown result type (might be due to invalid IL or missing references)
		//IL_017b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0180: Unknown result type (might be due to invalid IL or missing references)
		//IL_0192: Unknown result type (might be due to invalid IL or missing references)
		//IL_0197: Unknown result type (might be due to invalid IL or missing references)
		//IL_019c: Unknown result type (might be due to invalid IL or missing references)
		//IL_01ae: Unknown result type (might be due to invalid IL or missing references)
		//IL_01b3: Unknown result type (might be due to invalid IL or missing references)
		//IL_01b8: Unknown result type (might be due to invalid IL or missing references)
		//IL_012f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0134: Unknown result type (might be due to invalid IL or missing references)
		//IL_0139: Unknown result type (might be due to invalid IL or missing references)
		//IL_0146: Unknown result type (might be due to invalid IL or missing references)
		//IL_014b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0150: Unknown result type (might be due to invalid IL or missing references)
		//IL_01c4: Unknown result type (might be due to invalid IL or missing references)
		//IL_01c9: Unknown result type (might be due to invalid IL or missing references)
		//IL_01d5: Unknown result type (might be due to invalid IL or missing references)
		//IL_01da: Unknown result type (might be due to invalid IL or missing references)
		//IL_01fa: Unknown result type (might be due to invalid IL or missing references)
		//IL_01ff: Unknown result type (might be due to invalid IL or missing references)
		//IL_021d: Unknown result type (might be due to invalid IL or missing references)
		PhotonView val = PhotonView.Find(playerPhotonID);
		if (!Object.op_Implicit((Object)(object)val))
		{
			return;
		}
		PhysGrabber component = ((Component)val).GetComponent<PhysGrabber>();
		if (Object.op_Implicit((Object)(object)component) && SemiFunc.OwnerOnlyRPC(_info, component.photonView) && _grabRevision > 0)
		{
			if (!component.isLocal && component.grabRevision != _grabRevision)
			{
				component.physGrabPointPullerPosition = point;
				component.physGrabPointPuller.position = point;
				component.currentGrabForce = Vector3.zero;
				component.currentTorqueForce = Vector3.zero;
			}
			component.grabRevision = _grabRevision;
			component.physGrabPoint.position = point;
			component.localGrabPosition = ((Component)this).transform.InverseTransformPoint(point);
			component.grabbedObjectTransform = ((Component)this).transform;
			component.grabbedPhysGrabObjectColliderID = colliderID;
			Transform val2 = FindColliderFromID(colliderID);
			component.grabbedPhysGrabObjectCollider = ((val2 != null) ? ((Component)val2).GetComponent<Collider>() : null);
			component.prevGrabbed = component.grabbed;
			component.grabbed = true;
			component.grabbedObject = rb;
			component.grabbedPhysGrabObject = this;
			if (Object.op_Implicit((Object)(object)photonTransformView))
			{
				photonTransformView.ThrottleDivisorSet(1);
			}
			Transform overrideTransform = component.playerAvatar.localCamera.GetOverrideTransform();
			if (playerGrabbing.Count != 0)
			{
				component.cameraRelativeGrabbedForward = overrideTransform.InverseTransformDirection(((Component)this).transform.forward);
				component.cameraRelativeGrabbedUp = overrideTransform.InverseTransformDirection(((Component)this).transform.up);
			}
			else
			{
				component.cameraRelativeGrabbedForward = overrideTransform.InverseTransformDirection(((Component)this).transform.forward);
				component.cameraRelativeGrabbedUp = overrideTransform.InverseTransformDirection(((Component)this).transform.up);
				camRelForward = ((Component)this).transform.InverseTransformDirection(((Component)this).transform.forward);
				camRelUp = ((Component)this).transform.InverseTransformDirection(((Component)this).transform.up);
			}
			component.cameraRelativeGrabbedForward = component.cameraRelativeGrabbedForward.normalized;
			component.cameraRelativeGrabbedUp = component.cameraRelativeGrabbedUp.normalized;
			if (component.photonView.IsMine && photonView.ViewID != 0)
			{
				Vector3 localGrabPosition = component.localGrabPosition;
				photonView.RPC("GrabPointSyncRPC", (RpcTarget)0, new object[2] { playerPhotonID, localGrabPosition });
			}
		}
	}

	[PunRPC]
	private void GrabPointSyncRPC(int playerPhotonID, Vector3 localPointInBox, PhotonMessageInfo _info = default(PhotonMessageInfo))
	{
		//IL_001b: Unknown result type (might be due to invalid IL or missing references)
		//IL_002b: Unknown result type (might be due to invalid IL or missing references)
		//IL_002c: Unknown result type (might be due to invalid IL or missing references)
		PhotonView val = PhotonView.Find(playerPhotonID);
		PhysGrabber physGrabber = ((val != null) ? ((Component)val).GetComponent<PhysGrabber>() : null);
		if (Object.op_Implicit((Object)(object)physGrabber) && SemiFunc.OwnerOnlyRPC(_info, physGrabber.photonView))
		{
			physGrabber.localGrabPosition = localPointInBox;
		}
	}

	[PunRPC]
	private void GrabStartedRPC(int playerPhotonID, PhotonMessageInfo _info = default(PhotonMessageInfo))
	{
		//IL_001b: Unknown result type (might be due to invalid IL or missing references)
		PhotonView val = PhotonView.Find(playerPhotonID);
		PhysGrabber physGrabber = ((val != null) ? ((Component)val).GetComponent<PhysGrabber>() : null);
		if (Object.op_Implicit((Object)(object)physGrabber) && SemiFunc.OwnerOnlyRPC(_info, physGrabber.photonView) && !playerGrabbing.Contains(physGrabber))
		{
			photonView.RPC("GrabPlayerAddRPC", (RpcTarget)0, new object[1] { playerPhotonID });
		}
	}

	[PunRPC]
	private void GrabPlayerAddRPC(int photonViewID, PhotonMessageInfo _info = default(PhotonMessageInfo))
	{
		//IL_0000: Unknown result type (might be due to invalid IL or missing references)
		if (!SemiFunc.MasterOnlyRPC(_info))
		{
			return;
		}
		PhotonView val = PhotonView.Find(photonViewID);
		PhysGrabber physGrabber = ((val != null) ? ((Component)val).GetComponent<PhysGrabber>() : null);
		if (Object.op_Implicit((Object)(object)physGrabber))
		{
			playerGrabbing.Add(physGrabber);
			ExtractionHalloweenContact extractionHalloweenContact = default;
			if (SemiFunc.GameEventIsHalloween() && ((Component)this).TryGetComponent<ExtractionHalloweenContact>(ref extractionHalloweenContact))
			{
				extractionHalloweenContact.InteractionRegister();
			}
			if (Object.op_Implicit((Object)(object)photonTransformView))
			{
				photonTransformView.ThrottleDivisorSet(1);
			}
		}
	}

	[PunRPC]
	private void GrabPlayerRemoveRPC(int photonViewID, PhotonMessageInfo _info = default(PhotonMessageInfo))
	{
		//IL_0000: Unknown result type (might be due to invalid IL or missing references)
		if (SemiFunc.MasterOnlyRPC(_info))
		{
			PhotonView val = PhotonView.Find(photonViewID);
			PhysGrabber physGrabber = ((val != null) ? ((Component)val).GetComponent<PhysGrabber>() : null);
			if (Object.op_Implicit((Object)(object)physGrabber))
			{
				playerGrabbing.Remove(physGrabber);
			}
		}
	}

	private void Throw(PhysGrabber player)
	{
		//IL_001d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0028: Unknown result type (might be due to invalid IL or missing references)
		//IL_002d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0038: Unknown result type (might be due to invalid IL or missing references)
		//IL_003e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0043: Unknown result type (might be due to invalid IL or missing references)
		//IL_0044: Unknown result type (might be due to invalid IL or missing references)
		//IL_0051: Unknown result type (might be due to invalid IL or missing references)
		//IL_0056: Unknown result type (might be due to invalid IL or missing references)
		//IL_005d: Unknown result type (might be due to invalid IL or missing references)
		float num = Mathf.Max(rb.mass * 1.5f, 1f);
		Vector3 val = Vector3.ClampMagnitude(player.physGrabPointPullerPosition - player.physGrabPoint.position, player.forceMax) * num;
		val *= 0.5f + player.throwStrength;
		rb.AddForce(val, (ForceMode)1);
	}

	[PunRPC]
	private void GrabEndedRPC(int playerPhotonID, PhotonMessageInfo _info = default(PhotonMessageInfo))
	{
		//IL_001b: Unknown result type (might be due to invalid IL or missing references)
		PhotonView val = PhotonView.Find(playerPhotonID);
		PhysGrabber physGrabber = ((val != null) ? ((Component)val).GetComponent<PhysGrabber>() : null);
		if (Object.op_Implicit((Object)(object)physGrabber) && SemiFunc.OwnerOnlyRPC(_info, physGrabber.photonView))
		{
			Throw(physGrabber);
			physGrabber.prevGrabbed = physGrabber.grabbed;
			physGrabber.grabbed = false;
			if (playerGrabbing.Contains(physGrabber))
			{
				photonView.RPC("GrabPlayerRemoveRPC", (RpcTarget)0, new object[1] { playerPhotonID });
			}
		}
	}

	public void PhysRidingDisabledSet(bool _state)
	{
		//IL_000b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0011: Unknown result type (might be due to invalid IL or missing references)
		if (!SemiFunc.IsMultiplayer())
		{
			PhysRidingDisabledRPC(_state);
			return;
		}
		photonView.RPC("PhysRidingDisabledRPC", (RpcTarget)0, new object[1] { _state });
	}

	[PunRPC]
	private void PhysRidingDisabledRPC(bool _state, PhotonMessageInfo _info = default(PhotonMessageInfo))
	{
		//IL_0000: Unknown result type (might be due to invalid IL or missing references)
		if (SemiFunc.MasterOnlyRPC(_info))
		{
			physRidingDisabled = _state;
		}
	}

	public void OnPhotonSerializeView(PhotonStream _stream, PhotonMessageInfo _info)
	{
	}

	public Transform FindColliderFromID(int colliderID)
	{
		foreach (Transform collider in colliders)
		{
			if (((Component)collider).GetComponent<PhysGrabObjectCollider>().colliderID == colliderID)
			{
				return collider;
			}
		}
		return null;
	}

	public void OverrideGrabForceZero()
	{
		isGrabForceZero = true;
		overrideGrabForceZeroTimer = 0.1f;
	}

	public void OverrideGrabDisable(float _time = 0.1f)
	{
		grabDisableTimer = _time;
	}

	public void OverrideDroneTargetDisable(float _time = 0.1f)
	{
		droneTargetDisableTimer = _time;
	}

	private void OverrideGrabForceZeroTick()
	{
		if (overrideGrabForceZeroTimer <= 0f)
		{
			isGrabForceZero = false;
		}
		if (overrideGrabForceZeroTimer > 0f)
		{
			overrideGrabForceZeroTimer -= Time.deltaTime;
		}
	}

	public PhysGrabObject()
	{
		//IL_0046: Unknown result type (might be due to invalid IL or missing references)
		//IL_004b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0051: Unknown result type (might be due to invalid IL or missing references)
		//IL_0056: Unknown result type (might be due to invalid IL or missing references)
		//IL_005c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0061: Unknown result type (might be due to invalid IL or missing references)
		//IL_008b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0090: Unknown result type (might be due to invalid IL or missing references)
	}
}
