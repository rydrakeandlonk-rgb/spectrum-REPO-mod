using System;
using System.Collections.Generic;
using Platforms;
using UnityEngine;
using UnityEngine.Events;
using WebSocketSharp;

public class LocalizationChangedEvent : MonoBehaviour
{
	[Serializable]
	public class PlatformLocalizedAsset
	{
		public PlatformManager.PlatformType platformType;

		public LocalizedAsset localizedAsset;
	}

	public LocalizedAsset localizedAsset;

	public List<PlatformLocalizedAsset> platformLocalizedAssets = new List<PlatformLocalizedAsset>();

	public UnityEvent<string> onLocalizationChanged;

	public UnityEvent<bool> onTextDirectionalityChanged;

	public bool localizedAssetRequired = true;

	private void Start()
	{
		LocalizationManager.instance.AddLocalizationChangedEvent(this);
		OnLocaleChange();
	}

	private void OnDestroy()
	{
		if (Object.op_Implicit((Object)(object)LocalizationManager.instance))
		{
			LocalizationManager.instance.RemoveLocalizationChangedEvent(this);
		}
	}

	public void OnLocaleChange()
	{
		LocalizedAsset localizedAsset = GetLocalizedAsset();
		string text = localizedAsset?.GetLocalizedString();
		bool flag = false;
		if (Object.op_Implicit((Object)(object)localizedAsset))
		{
			flag = localizedAsset.IsRightToLeft();
		}
		else if (Object.op_Implicit((Object)(object)LocalizationManager.instance.ActiveLocale))
		{
			flag = LocalizationManager.instance.ActiveLocale.RightToLeft;
		}
		if (Ext.IsNullOrEmpty(text) && localizedAssetRequired)
		{
			SemiLogger.LogDev("Localization missing for: " + ((Object)((Component)this).gameObject).name, ((Component)this).gameObject);
			return;
		}
		onLocalizationChanged?.Invoke(text);
		onTextDirectionalityChanged?.Invoke(flag);
	}

	public LocalizedAsset GetLocalizedAsset()
	{
		if (!Object.op_Implicit((Object)(object)PlatformManager.instance))
		{
			return localizedAsset;
		}
		PlatformManager.PlatformType _platformType = PlatformManager.instance.GetPlatformType();
		PlatformLocalizedAsset platformLocalizedAsset = platformLocalizedAssets.Find((PlatformLocalizedAsset x) => x.platformType == _platformType);
		if (platformLocalizedAsset == null || !Object.op_Implicit((Object)(object)platformLocalizedAsset.localizedAsset))
		{
			return localizedAsset;
		}
		return platformLocalizedAsset.localizedAsset;
	}
}
