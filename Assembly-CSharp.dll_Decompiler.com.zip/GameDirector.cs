using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Audio;
using UnityEngine.UI;

public class GameDirector : MonoBehaviour
{
	public enum gameState
	{
		Load,
		Start,
		Main,
		Outro,
		Result,
		End,
		EndWait,
		Death
	}

	public static GameDirector instance;

	public gameState currentState = gameState.Start;

	public bool LevelCompleted;

	public bool LevelCompletedDone;

	[Header("Debug")]
	public float TimeScale = 1f;

	[Space(15f)]
	public bool RandomSeed;

	public int Seed;

	[Space(15f)]
	[Header("Audio")]
	public AudioMixerSnapshot volumeOff;

	public AudioMixerSnapshot volumeOn;

	public AudioMixerSnapshot volumeCutsceneOnly;

	public Sound SoundIntro;

	public Sound SoundIntroRun;

	public Sound SoundOutro;

	public Sound SoundOutroRun;

	public Sound SoundDeath;

	[Space(15f)]
	[Header("Enemy")]
	public bool LevelEnemyChasing;

	[Space(15f)]
	[Header("Other")]
	public Camera MainCamera;

	[HideInInspector]
	public Transform MainCameraParent;

	public RenderTexture MainRenderTexture;

	[Space(15f)]
	public AnimNoise camNoise;

	private float gameStateTimer;

	private bool gameStateStartImpulse = true;

	[Space(15f)]
	public GameObject cameraPosition;

	public Animator cameraTargetAnimator;

	public CameraShake CameraShake;

	public CameraShake CameraImpact;

	public CameraBob CameraBob;

	[Space(15f)]
	public int InitialCleaningSpots;

	public List<PlayerAvatar> PlayerList = new List<PlayerAvatar>();

	internal List<PlayerDeathSpot> PlayerDeathSpots = new List<PlayerDeathSpot>();

	public bool DisableInput;

	private float DisableInputTimer;

	private float disableEscMenuTimer;

	internal bool outroStart;

	private float deathFreezeTime = 0.2f;

	private float deathFreezeTimer;

	private float timer1FPS;

	private float timer5FPS;

	private float timer15FPS;

	private float timer20FPS;

	private float timer30FPS;

	private float timer60FPS;

	private const float INTERVAL_1FPS = 1f;

	private const float INTERVAL_5FPS = 0.2f;

	private const float INTERVAL_15FPS = 1f / 15f;

	private const float INTERVAL_20FPS = 0.05f;

	private const float INTERVAL_30FPS = 1f / 30f;

	private const float INTERVAL_60FPS = 1f / 60f;

	internal bool fpsImpulse1;

	internal bool fpsImpulse5;

	internal bool fpsImpulse15;

	internal bool fpsImpulse20;

	internal bool fpsImpulse30;

	internal bool fpsImpulse60;

	internal bool greenScreenActive;

	public GameObject greenScreenPrefab;

	[RuntimeInitializeOnLoadMethod(/*Could not decode attribute arguments.*/)]
	private static void RuntimeInitializeOnLoad()
	{
		instance = null;
	}

	private void Awake()
	{
		MainCamera = Camera.main;
		MainCameraParent = ((Component)MainCamera).transform.parent;
		instance = this;
		currentState = gameState.Load;
	}

	private void Start()
	{
		RunManager.instance.GameDirectorStart();
	}

	private void gameStateLoad()
	{
		//IL_0022: Unknown result type (might be due to invalid IL or missing references)
		if (gameStateStartImpulse)
		{
			cameraPosition.transform.localRotation = Quaternion.Euler(60f, 0f, 0f);
			AudioManager.instance.SetSoundSnapshot(AudioManager.SoundSnapshot.Off, 0f);
			gameStateStartImpulse = false;
		}
	}

	private void gameStateStart()
	{
		//IL_0120: Unknown result type (might be due to invalid IL or missing references)
		//IL_0152: Unknown result type (might be due to invalid IL or missing references)
		if (!LevelGenerator.Instance.Generated)
		{
			return;
		}
		if (gameStateStartImpulse)
		{
			AudioManager.instance.SetSoundSnapshot(AudioManager.SoundSnapshot.CutsceneOnly, 0.1f);
			gameStateTimer = 0.5f;
			LoadingUI.instance.LevelAnimationStart();
			gameStateStartImpulse = false;
			return;
		}
		Level level = LevelGenerator.Instance.Level;
		if (SemiFunc.RunIsLevel(level) || SemiFunc.IsCurrentLevel(level, RunManager.instance.levelTutorial) || SemiFunc.IsLevelShop(level) || SemiFunc.IsLevelArena(level))
		{
			if (LoadingUI.instance.levelAnimationCompleted)
			{
				gameStateTimer -= Time.deltaTime;
			}
		}
		else
		{
			gameStateTimer -= Time.deltaTime;
		}
		if (gameStateTimer <= 0f)
		{
			LoadingUI.instance.StopLoading();
			if (SemiFunc.RunIsLobbyMenu())
			{
				AudioManager.instance.SetSoundSnapshot(AudioManager.SoundSnapshot.Spectate, 0.1f);
			}
			else
			{
				AudioManager.instance.SetSoundSnapshot(AudioManager.SoundSnapshot.On, 0.1f);
			}
			MusicManager.Instance.MusicMixerOff.TransitionTo(0f);
			MusicManager.Instance.MusicMixerOn.TransitionTo(0.1f);
			SoundIntro.Play(((Component)this).transform.position);
			if (!SemiFunc.MenuLevel())
			{
				SoundIntroRun.Play(((Component)this).transform.position);
			}
			MoonUI.instance.Check();
			currentState = gameState.Main;
			gameStateStartImpulse = true;
			gameStateTimer = 0f;
		}
	}

	private void gameStateMain()
	{
	}

	private void gameStateOutro()
	{
		//IL_0045: Unknown result type (might be due to invalid IL or missing references)
		//IL_0077: Unknown result type (might be due to invalid IL or missing references)
		if (gameStateStartImpulse)
		{
			CosmeticTokenUI.instance.ReparentResultScreen();
			AudioManager.instance.SetSoundSnapshot(AudioManager.SoundSnapshot.CutsceneOnly, 0.25f);
			MusicManager.Instance.MusicMixerScareOnly.TransitionTo(0.25f);
			SoundOutro.Play(((Component)this).transform.position);
			if (!SemiFunc.MenuLevel())
			{
				SoundOutroRun.Play(((Component)this).transform.position);
			}
			if (ResultScreenUI.instance.skip || ResultScreenUI.instance.debugSkip)
			{
				gameStateTimer = 1f;
			}
			else
			{
				gameStateTimer = 0.1f;
			}
			gameStateStartImpulse = false;
			HUD.instance.Hide();
			{
				foreach (PlayerAvatar player in PlayerList)
				{
					if (Object.op_Implicit((Object)(object)player.voiceChat))
					{
						player.voiceChat.ToggleMixer(_lobby: true);
					}
				}
				return;
			}
		}
		gameStateTimer -= Time.deltaTime;
		if (gameStateTimer <= 0f)
		{
			currentState = gameState.Result;
			gameStateStartImpulse = true;
			gameStateTimer = 0f;
		}
	}

	private void gameStateResult()
	{
	}

	private void gameStateEnd()
	{
		if (gameStateStartImpulse)
		{
			AudioManager.instance.SetSoundSnapshot(AudioManager.SoundSnapshot.Off, 0.5f);
			if (Object.op_Implicit((Object)(object)PlayerController.instance.playerAvatarScript))
			{
				PlayerController.instance.playerAvatarScript.SetDisabled();
			}
			LoadingUI.instance.StartLoading();
			gameStateTimer = 0.5f;
			gameStateStartImpulse = false;
			return;
		}
		gameStateTimer -= Time.deltaTime;
		if (gameStateTimer <= 0f)
		{
			if (Object.op_Implicit((Object)(object)PlayerController.instance.playerAvatarScript))
			{
				PlayerController.instance.playerAvatarScript.OutroDone();
			}
			else if (Object.op_Implicit((Object)(object)NetworkManager.instance) && NetworkManager.instance.leavePhotonRoom)
			{
				Debug.LogWarning((object)"the local player avatar is missing at the end of the level... leaving to the menu without it");
				NetworkManager.instance.LeavePhotonRoom();
			}
			currentState = gameState.EndWait;
		}
	}

	private void gameStateDeath()
	{
		//IL_004c: Unknown result type (might be due to invalid IL or missing references)
		SemiFunc.UIShowSpectate();
		SemiFunc.UIHideHealth();
		SemiFunc.UIHideOvercharge();
		SemiFunc.UIHideEnergy();
		SemiFunc.UIHideInventory();
		SemiFunc.UIHideAim();
		if (gameStateStartImpulse)
		{
			gameStateTimer = 0.5f;
			deathFreezeTimer = deathFreezeTime;
			SoundDeath.Play(((Component)this).transform.position);
			HUD.instance.Hide();
			RenderTextureMain.instance.ChangeResolution(RenderTextureMain.instance.textureWidthOriginal * 0.2f, RenderTextureMain.instance.textureHeightOriginal * 0.2f, gameStateTimer);
			gameStateStartImpulse = false;
			return;
		}
		if (deathFreezeTimer > 0f)
		{
			deathFreezeTimer -= Time.deltaTime;
			if (deathFreezeTimer <= 0f)
			{
				AudioManager.instance.SetSoundSnapshot(AudioManager.SoundSnapshot.CutsceneOnly, 0.1f);
				RenderTextureMain.instance.Shake(gameStateTimer);
				RenderTextureMain.instance.ChangeSize(1.25f, 1.25f, gameStateTimer);
				CameraFreeze.Freeze(gameStateTimer + 0.1f);
			}
		}
		gameStateTimer -= Time.deltaTime;
		if (gameStateTimer <= 0f)
		{
			AudioManager.instance.SetSoundSnapshot(AudioManager.SoundSnapshot.Spectate, 0.1f);
			HUD.instance.Show();
			RenderTextureMain.instance.Shake(0f);
			RenderTextureMain.instance.sizeResetTimer = 0f;
			RenderTextureMain.instance.textureResetTimer = 0f;
			CameraFreeze.Freeze(0f);
			PlayerController.instance.playerAvatarScript.SetSpectate();
			currentState = gameState.Main;
		}
	}

	private void Update()
	{
		SemiFunc.NetworkThrottleViewpointsTick();
		SemiFunc.NetworkTrafficStatsTick();
		if (SemiFunc.InputDown(InputKey.Menu) && !SemiFunc.MenuLevel() && !ChatManager.instance.chatActive && disableEscMenuTimer <= 0f)
		{
			if (SemiFunc.InputDown(InputKey.Back) && ChatManager.instance.StateIsActive())
			{
				return;
			}
			if (!Object.op_Implicit((Object)(object)MenuManager.instance.currentMenuPage))
			{
				MenuManager.instance.PageOpen(MenuPageIndex.Escape);
			}
			else if (MenuManager.instance.currentMenuPage.menuPageIndex == MenuPageIndex.Escape && MenuManager.instance.currentMenuPage.isInteractable && MenuManager.instance.currentMenuPage.currentPageState != MenuPage.PageState.Closing)
			{
				MenuManager.instance.PageCloseAll();
			}
		}
		disableEscMenuTimer -= Time.deltaTime;
		if (outroStart)
		{
			OutroStart();
		}
		if (currentState == gameState.Load)
		{
			gameStateLoad();
		}
		else if (currentState == gameState.Start)
		{
			gameStateStart();
		}
		else if (currentState == gameState.Main)
		{
			gameStateMain();
		}
		else if (currentState == gameState.Outro)
		{
			gameStateOutro();
		}
		else if (currentState == gameState.Result)
		{
			gameStateResult();
		}
		else if (currentState == gameState.End)
		{
			gameStateEnd();
		}
		else if (currentState == gameState.Death)
		{
			gameStateDeath();
		}
		if (DisableInput)
		{
			DisableInputTimer -= Time.deltaTime;
			if (DisableInputTimer <= 0f)
			{
				DisableInput = false;
			}
		}
	}

	public void OutroStart()
	{
		//IL_002d: Unknown result type (might be due to invalid IL or missing references)
		outroStart = true;
		if (currentState == gameState.Main)
		{
			currentState = gameState.Outro;
			if (Object.op_Implicit((Object)(object)FadeOverlay.Instance))
			{
				((Graphic)FadeOverlay.Instance.Image).color = Color.black;
			}
			gameStateStartImpulse = true;
			gameStateTimer = 0f;
		}
	}

	public void DeathStart()
	{
		currentState = gameState.Death;
		gameStateStartImpulse = true;
		gameStateTimer = 0f;
	}

	public void Revive()
	{
		currentState = gameState.Main;
		gameStateStartImpulse = true;
		gameStateTimer = 0f;
	}

	public void CommandSetFPS(int _fps)
	{
		Application.targetFrameRate = _fps;
	}

	public void CommandRecordingDirectorToggle()
	{
		CommandRecordingDirectorSet(!Object.op_Implicit((Object)(object)RecordingDirector.instance));
	}

	public RecordingDirector CommandRecordingDirectorSet(bool active)
	{
		RecordingDirector recordingDirector = RecordingDirector.instance;
		if (!active)
		{
			if (Object.op_Implicit((Object)(object)recordingDirector))
			{
				((Behaviour)recordingDirector).enabled = false;
				Object.Destroy((Object)(object)((Component)recordingDirector).gameObject);
			}
			RecordingDirector.instance = null;
			if (Object.op_Implicit((Object)(object)FlashlightController.Instance))
			{
				FlashlightController.Instance.hideFlashlight = false;
			}
			return null;
		}
		if (Object.op_Implicit((Object)(object)recordingDirector))
		{
			return recordingDirector;
		}
		GameObject val = Resources.Load<GameObject>("Recording Director");
		if (!Object.op_Implicit((Object)(object)val))
		{
			return null;
		}
		GameObject val2 = Object.Instantiate<GameObject>(val);
		recordingDirector = val2.GetComponent<RecordingDirector>();
		if (!Object.op_Implicit((Object)(object)recordingDirector))
		{
			Object.Destroy((Object)(object)val2);
			return null;
		}
		RecordingDirector.instance = recordingDirector;
		return recordingDirector;
	}

	public void CommandGreenScreenToggle()
	{
		CommandGreenScreenSet(!greenScreenActive);
	}

	public VideoGreenScreen CommandGreenScreenSet(bool active)
	{
		VideoGreenScreen component = VideoGreenScreen.instance;
		if (!active)
		{
			if (Object.op_Implicit((Object)(object)component))
			{
				((Behaviour)component).enabled = false;
				Object.Destroy((Object)(object)((Component)component).gameObject);
			}
			VideoGreenScreen.instance = null;
			if (Object.op_Implicit((Object)(object)HurtVignette.instance))
			{
				((Component)HurtVignette.instance).gameObject.SetActive(true);
			}
			greenScreenActive = false;
			return null;
		}
		if (!Object.op_Implicit((Object)(object)component))
		{
			if (!Object.op_Implicit((Object)(object)greenScreenPrefab))
			{
				return null;
			}
			GameObject val = Object.Instantiate<GameObject>(greenScreenPrefab);
			component = val.GetComponent<VideoGreenScreen>();
			if (!Object.op_Implicit((Object)(object)component))
			{
				Object.Destroy((Object)(object)val);
				return null;
			}
			VideoGreenScreen.instance = component;
		}
		if (Object.op_Implicit((Object)(object)HurtVignette.instance))
		{
			((Component)HurtVignette.instance).gameObject.SetActive(false);
		}
		greenScreenActive = true;
		return component;
	}

	public void SetDisableInput(float time)
	{
		DisableInput = true;
		DisableInputTimer = time;
	}

	public void SetDisableEscMenu(float _time)
	{
		disableEscMenuTimer = _time;
	}

	public void SetStart()
	{
		if (currentState < gameState.Outro)
		{
			gameStateStartImpulse = true;
			currentState = gameState.Start;
			if (Object.op_Implicit((Object)(object)NetworkManager.instance) && Object.op_Implicit((Object)(object)LoadingUI.instance))
			{
				NetworkManager.instance.loadingScreenTimer = 10f;
			}
		}
	}

	private void LateUpdate()
	{
		FPSImpulses();
	}

	private void FPSImpulses()
	{
		float deltaTime = Time.deltaTime;
		fpsImpulse1 = false;
		fpsImpulse5 = false;
		fpsImpulse15 = false;
		fpsImpulse20 = false;
		fpsImpulse30 = false;
		fpsImpulse60 = false;
		timer1FPS += deltaTime;
		timer5FPS += deltaTime;
		timer15FPS += deltaTime;
		timer20FPS += deltaTime;
		timer30FPS += deltaTime;
		timer60FPS += deltaTime;
		while (timer1FPS >= 1f)
		{
			fpsImpulse1 = true;
			timer1FPS--;
		}
		while (timer5FPS >= 0.2f)
		{
			fpsImpulse5 = true;
			timer5FPS -= 0.2f;
		}
		while (timer15FPS >= 1f / 15f)
		{
			fpsImpulse15 = true;
			timer15FPS -= 1f / 15f;
		}
		while (timer20FPS >= 0.05f)
		{
			fpsImpulse20 = true;
			timer20FPS -= 0.05f;
		}
		while (timer30FPS >= 1f / 30f)
		{
			fpsImpulse30 = true;
			timer30FPS -= 1f / 30f;
		}
		while (timer60FPS >= 1f / 60f)
		{
			fpsImpulse60 = true;
			timer60FPS -= 1f / 60f;
		}
	}
}
