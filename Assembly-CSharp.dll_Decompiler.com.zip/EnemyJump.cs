using System.Collections;
using Photon.Pun;
using UnityEngine;

[RequireComponent(typeof(EnemyGrounded))]
public class EnemyJump : MonoBehaviour
{
	public enum Type
	{
		None,
		Surface,
		Stuck,
		Gap
	}

	public Enemy enemy;

	internal bool jumping;

	internal bool jumpingDelay;

	internal bool landDelay;

	internal float jumpCooldown;

	internal float timeSinceJumped;

	internal Type jumpingType;

	[Space]
	public bool warpAgentOnLand;

	[Space]
	public bool surfaceJump = true;

	public float surfaceJumpForceUp = 5f;

	public float surfaceJumpForceSide = 2f;

	private bool surfaceJumpImpulse;

	private Vector3 surfaceJumpDirection;

	private float surfaceJumpDisableTimer;

	private float surfaceJumpOverrideTimer;

	private float surfaceJumpOverrideUp;

	private float surfaceJumpOverrideSide;

	public float surfaceJumpDelay;

	private float surfaceJumpDelayTimer;

	public float surfaceLandDelay;

	private float surfaceLandDelayTimer;

	[Space]
	public bool stuckJump;

	private float stuckJumpDisableTimer;

	private float cartJumpTimer;

	private float cartJumpCooldown;

	public int stuckJumpCount = 5;

	public float stuckJumpForceUp = 5f;

	public float stuckJumpForceSide = 2f;

	internal bool stuckJumpImpulse;

	private Vector3 stuckJumpImpulseDirection;

	private float stuckJumpOverrideTimer;

	private float stuckJumpOverrideUp;

	private float stuckJumpOverrideSide;

	public float stuckJumpDelay;

	private float stuckJumpDelayTimer;

	public float stuckLandDelay;

	private float stuckLandDelayTimer;

	[Space]
	public bool gapJump;

	public float gapJumpForceUp = 5f;

	public float gapJumpForceForward = 5f;

	internal bool gapJumpImpulse;

	private float snatcherGapJumpDisableTimer;

	private float gapJumpOverrideTimer;

	private float gapJumpOverrideUp;

	private float gapJumpOverrideForward;

	private Vector3 gapJumpLandPosition;

	public float gapJumpDelay;

	private float gapJumpDelayTimer;

	public float gapLandDelay;

	private float gapLandDelayTimer;

	private bool gapCheckerActive;

	private EnemySnatcher snatcher;

	private EnemySnatcherSuspension snatcherSuspension;

	private float snatcherLandingPendingTimer;

	private float snatcherLandingContactTimer;

	private WaitForSeconds gapCheckerWait;

	private void Awake()
	{
		//IL_0006: Unknown result type (might be due to invalid IL or missing references)
		//IL_0010: Expected Obj, but got Unknown
		gapCheckerWait = new WaitForSeconds(0.2f);
		enemy.Jump = this;
		enemy.HasJump = true;
		snatcher = ((Component)enemy).GetComponent<EnemySnatcher>();
		if (gapJump && !gapCheckerActive)
		{
			((MonoBehaviour)this).StartCoroutine(GapChecker());
			gapCheckerActive = true;
		}
	}

	private void Start()
	{
		if (!enemy.HasRigidbody)
		{
			Debug.LogError((object)("EnemyJump: No Rigidbody found on " + ((Object)enemy).name));
			stuckJump = false;
		}
	}

	private void OnDisable()
	{
		((MonoBehaviour)this).StopAllCoroutines();
		gapCheckerActive = false;
	}

	private void OnEnable()
	{
		if (gapJump && !gapCheckerActive)
		{
			((MonoBehaviour)this).StartCoroutine(GapChecker());
			gapCheckerActive = true;
		}
	}

	public void StuckReset()
	{
		stuckJumpImpulse = false;
	}

	internal void SnatcherRuntimeReset()
	{
		//IL_003a: Unknown result type (might be due to invalid IL or missing references)
		//IL_003f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0079: Unknown result type (might be due to invalid IL or missing references)
		//IL_007e: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ce: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d3: Unknown result type (might be due to invalid IL or missing references)
		jumping = false;
		jumpingDelay = false;
		landDelay = false;
		jumpCooldown = 0f;
		timeSinceJumped = 0f;
		jumpingType = Type.None;
		surfaceJumpImpulse = false;
		surfaceJumpDirection = Vector3.zero;
		surfaceJumpDisableTimer = 0f;
		surfaceJumpOverrideTimer = 0f;
		surfaceJumpDelayTimer = surfaceJumpDelay;
		surfaceLandDelayTimer = 0f;
		stuckJumpImpulse = false;
		stuckJumpImpulseDirection = Vector3.zero;
		stuckJumpDisableTimer = 0f;
		stuckJumpOverrideTimer = 0f;
		stuckJumpDelayTimer = stuckJumpDelay;
		stuckLandDelayTimer = 0f;
		cartJumpTimer = 0f;
		cartJumpCooldown = 0f;
		gapJumpImpulse = false;
		gapJumpLandPosition = Vector3.zero;
		snatcherGapJumpDisableTimer = 0f;
		gapJumpOverrideTimer = 0f;
		gapJumpDelayTimer = gapJumpDelay;
		gapLandDelayTimer = 0f;
		snatcherLandingPendingTimer = 0f;
		snatcherLandingContactTimer = 0f;
	}

	internal void SnatcherPendingJumpReset()
	{
		//IL_0016: Unknown result type (might be due to invalid IL or missing references)
		//IL_001b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0021: Unknown result type (might be due to invalid IL or missing references)
		//IL_0026: Unknown result type (might be due to invalid IL or missing references)
		//IL_002c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0031: Unknown result type (might be due to invalid IL or missing references)
		surfaceJumpImpulse = false;
		stuckJumpImpulse = false;
		gapJumpImpulse = false;
		surfaceJumpDirection = Vector3.zero;
		stuckJumpImpulseDirection = Vector3.zero;
		gapJumpLandPosition = Vector3.zero;
		surfaceJumpDelayTimer = surfaceJumpDelay;
		stuckJumpDelayTimer = stuckJumpDelay;
		gapJumpDelayTimer = gapJumpDelay;
		if (jumpingDelay)
		{
			JumpingDelaySet(_jumpingDelay: false, Type.None);
		}
	}

	private void SnatcherPendingJumpConsume()
	{
		//IL_0001: Unknown result type (might be due to invalid IL or missing references)
		//IL_0006: Unknown result type (might be due to invalid IL or missing references)
		//IL_000e: Unknown result type (might be due to invalid IL or missing references)
		//IL_000f: Unknown result type (might be due to invalid IL or missing references)
		Vector3 val = gapJumpLandPosition;
		SnatcherPendingJumpReset();
		gapJumpLandPosition = val;
	}

	internal void SnatcherLandingConsume()
	{
		if (SemiFunc.IsMasterClientOrSingleplayer())
		{
			SnatcherPendingJumpConsume();
			if (jumping)
			{
				JumpingSet(_jumping: false, Type.None);
			}
			gapLandDelayTimer = 0f;
			surfaceLandDelayTimer = 0f;
			stuckLandDelayTimer = 0f;
			if (landDelay)
			{
				LandDelaySet(_landDelay: false);
			}
			jumpCooldown = Mathf.Max(jumpCooldown, 0.25f);
		}
	}

	internal void SnatcherLandingComplete()
	{
		//IL_0025: Unknown result type (might be due to invalid IL or missing references)
		//IL_002a: Unknown result type (might be due to invalid IL or missing references)
		if (SemiFunc.IsMasterClientOrSingleplayer())
		{
			SnatcherLandingConsume();
			snatcherLandingPendingTimer = 0f;
			snatcherLandingContactTimer = 0f;
			gapJumpLandPosition = Vector3.zero;
		}
	}

	internal void SnatcherLandingAcknowledge()
	{
		if (SemiFunc.IsMasterClientOrSingleplayer())
		{
			snatcherLandingPendingTimer = 0f;
		}
	}

	internal void SnatcherLandingRearm()
	{
		if (SemiFunc.IsMasterClientOrSingleplayer())
		{
			SnatcherPendingJumpConsume();
			gapLandDelayTimer = 0f;
			surfaceLandDelayTimer = 0f;
			stuckLandDelayTimer = 0f;
			if (landDelay)
			{
				LandDelaySet(_landDelay: false);
			}
			snatcherLandingPendingTimer = 0f;
			snatcherLandingContactTimer = 0f;
			enemy.Grounded.grounded = false;
			if (!jumping)
			{
				JumpingSet(_jumping: true, jumpingType);
			}
		}
	}

	internal bool SnatcherLandingPending()
	{
		return snatcherLandingPendingTimer > 0f;
	}

	internal float SnatcherJumpDelayDuration()
	{
		if (jumpingType == Type.Gap)
		{
			return gapJumpDelay;
		}
		if (jumpingType == Type.Stuck)
		{
			return stuckJumpDelay;
		}
		if (jumpingType == Type.Surface)
		{
			return surfaceJumpDelay;
		}
		return 0f;
	}

	internal Vector3 SnatcherJumpTargetPosition()
	{
		//IL_0020: Unknown result type (might be due to invalid IL or missing references)
		//IL_003c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0037: Unknown result type (might be due to invalid IL or missing references)
		//IL_0047: Unknown result type (might be due to invalid IL or missing references)
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0057: Unknown result type (might be due to invalid IL or missing references)
		//IL_0064: Unknown result type (might be due to invalid IL or missing references)
		//IL_00aa: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ad: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b7: Unknown result type (might be due to invalid IL or missing references)
		//IL_00bc: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a4: Unknown result type (might be due to invalid IL or missing references)
		//IL_0092: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a9: Unknown result type (might be due to invalid IL or missing references)
		Vector3 val = ((Object.op_Implicit((Object)(object)enemy) && enemy.HasRigidbody) ? ((Component)enemy.Rigidbody).transform.position : ((Component)this).transform.position);
		if (jumpingType == Type.Gap)
		{
			return gapJumpLandPosition;
		}
		Vector3 val2 = ((jumpingType == Type.Surface) ? surfaceJumpDirection : stuckJumpImpulseDirection);
		val2.y = 0f;
		if (val2.sqrMagnitude <= 0.0001f)
		{
			val2 = (Object.op_Implicit((Object)(object)enemy) ? ((Component)enemy).transform.forward : ((Component)this).transform.forward);
		}
		return val + val2.normalized * 3f;
	}

	internal float SnatcherJumpDelayProgress()
	{
		float num = SnatcherJumpDelayDuration();
		if (num <= 0f)
		{
			return 1f;
		}
		float num2 = 0f;
		if (jumpingType == Type.Gap)
		{
			num2 = gapJumpDelayTimer;
		}
		else if (jumpingType == Type.Stuck)
		{
			num2 = stuckJumpDelayTimer;
		}
		else if (jumpingType == Type.Surface)
		{
			num2 = surfaceJumpDelayTimer;
		}
		return Mathf.Clamp01(1f - num2 / num);
	}

	public void SurfaceJumpTrigger(Vector3 _direction)
	{
		//IL_0010: Unknown result type (might be due to invalid IL or missing references)
		//IL_0011: Unknown result type (might be due to invalid IL or missing references)
		if (!jumping)
		{
			surfaceJumpImpulse = true;
			surfaceJumpDirection = _direction;
		}
	}

	public void SurfaceJumpDisable(float _time)
	{
		surfaceJumpImpulse = false;
		surfaceJumpDisableTimer = _time;
	}

	public void StuckTrigger(Vector3 _direction)
	{
		//IL_0010: Unknown result type (might be due to invalid IL or missing references)
		//IL_0011: Unknown result type (might be due to invalid IL or missing references)
		if (!jumping)
		{
			stuckJumpImpulse = true;
			stuckJumpImpulseDirection = _direction;
		}
	}

	public void StuckDisable(float _time)
	{
		stuckJumpDisableTimer = _time;
	}

	internal void SnatcherGapDisable(float _time)
	{
		snatcherGapJumpDisableTimer = _time;
		gapJumpImpulse = false;
	}

	private IEnumerator GapChecker()
	{
		gapCheckerActive = true;
		while (true)
		{
			if (SemiFunc.IsMasterClientOrSingleplayer() && enemy.Grounded.grounded && enemy.NavMeshAgent.HasPath() && !enemy.NavMeshAgent.IsStopped() && enemy.Rigidbody.velocity.magnitude >= 0.05f)
			{
				int num = 8;
				float num2 = 0.5f;
				float num3 = 2f;
				Vector3 normalized = enemy.Rigidbody.velocity.normalized;
				normalized.y = 0f;
				Vector3 val = enemy.Rigidbody.physGrabObject.centerPoint + normalized * num2;
				bool flag = false;
				for (int i = 0; i < num; i++)
				{
					if (Physics.Raycast(val, Vector3.down * 0.25f, num3, LayerMask.op_Implicit(SemiFunc.LayerMaskGetVisionObstruct())))
					{
						if (flag && !gapJumpImpulse)
						{
							gapJumpLandPosition = val + normalized * num2 * 0.5f;
							gapJumpImpulse = true;
						}
					}
					else if (i < 2)
					{
						flag = true;
					}
					val += normalized * num2;
				}
			}
			yield return gapCheckerWait;
		}
	}

	private void FixedUpdate()
	{
		//IL_01e3: Unknown result type (might be due to invalid IL or missing references)
		//IL_01f8: Unknown result type (might be due to invalid IL or missing references)
		//IL_01fd: Unknown result type (might be due to invalid IL or missing references)
		//IL_0202: Unknown result type (might be due to invalid IL or missing references)
		//IL_0206: Unknown result type (might be due to invalid IL or missing references)
		//IL_020c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0211: Unknown result type (might be due to invalid IL or missing references)
		//IL_021f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0221: Unknown result type (might be due to invalid IL or missing references)
		//IL_0227: Unknown result type (might be due to invalid IL or missing references)
		//IL_022c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0231: Unknown result type (might be due to invalid IL or missing references)
		//IL_0253: Unknown result type (might be due to invalid IL or missing references)
		//IL_0267: Unknown result type (might be due to invalid IL or missing references)
		//IL_015d: Unknown result type (might be due to invalid IL or missing references)
		//IL_096b: Unknown result type (might be due to invalid IL or missing references)
		//IL_08b3: Unknown result type (might be due to invalid IL or missing references)
		//IL_0a16: Unknown result type (might be due to invalid IL or missing references)
		//IL_0758: Unknown result type (might be due to invalid IL or missing references)
		//IL_075f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0764: Unknown result type (might be due to invalid IL or missing references)
		//IL_0792: Unknown result type (might be due to invalid IL or missing references)
		//IL_0794: Unknown result type (might be due to invalid IL or missing references)
		//IL_079b: Unknown result type (might be due to invalid IL or missing references)
		//IL_07a0: Unknown result type (might be due to invalid IL or missing references)
		//IL_0494: Unknown result type (might be due to invalid IL or missing references)
		//IL_0499: Unknown result type (might be due to invalid IL or missing references)
		//IL_0517: Unknown result type (might be due to invalid IL or missing references)
		//IL_051e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0523: Unknown result type (might be due to invalid IL or missing references)
		//IL_0531: Unknown result type (might be due to invalid IL or missing references)
		//IL_0533: Unknown result type (might be due to invalid IL or missing references)
		//IL_053a: Unknown result type (might be due to invalid IL or missing references)
		//IL_053f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0544: Unknown result type (might be due to invalid IL or missing references)
		//IL_0547: Unknown result type (might be due to invalid IL or missing references)
		//IL_054c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0571: Unknown result type (might be due to invalid IL or missing references)
		//IL_04b1: Unknown result type (might be due to invalid IL or missing references)
		//IL_04c6: Unknown result type (might be due to invalid IL or missing references)
		//IL_04cb: Unknown result type (might be due to invalid IL or missing references)
		//IL_04d0: Unknown result type (might be due to invalid IL or missing references)
		//IL_04f9: Unknown result type (might be due to invalid IL or missing references)
		//IL_04fe: Unknown result type (might be due to invalid IL or missing references)
		//IL_0502: Unknown result type (might be due to invalid IL or missing references)
		//IL_0507: Unknown result type (might be due to invalid IL or missing references)
		//IL_050c: Unknown result type (might be due to invalid IL or missing references)
		if (!jumping)
		{
			timeSinceJumped += Time.fixedDeltaTime;
		}
		else
		{
			timeSinceJumped = 0f;
		}
		if (GameManager.Multiplayer() && !PhotonNetwork.IsMasterClient)
		{
			return;
		}
		if (snatcherLandingPendingTimer > 0f)
		{
			snatcherLandingPendingTimer = Mathf.Max(0f, snatcherLandingPendingTimer - Time.fixedDeltaTime);
		}
		bool flag = false;
		Type type = Type.Surface;
		if (enemy.Rigidbody.grabbed || enemy.IsStunned() || enemy.TeleportedTimer > 0f)
		{
			SnatcherLandingComplete();
			return;
		}
		if (snatcherGapJumpDisableTimer > 0f)
		{
			snatcherGapJumpDisableTimer -= Time.fixedDeltaTime;
			gapJumpImpulse = false;
		}
		float num = gapJumpForceUp;
		float num2 = gapJumpForceForward;
		if (gapJumpOverrideTimer > 0f)
		{
			num = gapJumpOverrideUp;
			num2 = gapJumpOverrideForward;
			gapJumpOverrideTimer -= Time.fixedDeltaTime;
		}
		if (gapJumpImpulse && !jumping && jumpCooldown <= 0f)
		{
			if (gapJumpDelayTimer > 0f)
			{
				JumpingDelaySet(_jumpingDelay: true, Type.Gap);
				if (warpAgentOnLand)
				{
					enemy.NavMeshAgent.Warp(((Component)enemy.Rigidbody).transform.position, _force: true);
				}
				enemy.NavMeshAgent.Stop(0.1f);
				enemy.Rigidbody.OverrideFollowPosition(0.1f, 0f);
				enemy.Rigidbody.OverrideColliderMaterialStunned(0.1f);
				gapJumpDelayTimer -= Time.fixedDeltaTime;
			}
			else
			{
				enemy.Rigidbody.DisableFollowPosition(0.25f, 10f);
				Vector3 val = gapJumpLandPosition - ((Component)enemy.Rigidbody).transform.position;
				Vector3 val2 = val.normalized * num2;
				val2.y = 0f;
				val2 += Vector3.up * num;
				enemy.Rigidbody.JumpImpulse();
				enemy.Rigidbody.rb.AddForce(val2, (ForceMode)1);
				enemy.NavMeshAgent.Warp(gapJumpLandPosition, _force: true);
				gapJumpImpulse = false;
				stuckJumpImpulse = false;
				flag = true;
				type = Type.Gap;
			}
		}
		else if (gapJumpDelayTimer != gapJumpDelay)
		{
			gapJumpDelayTimer = gapJumpDelay;
			if (jumpingDelay && jumpingType == Type.Gap)
			{
				JumpingDelaySet(_jumpingDelay: false, Type.Gap);
			}
		}
		if (stuckJump && !Object.op_Implicit((Object)(object)snatcher))
		{
			float num3 = stuckJumpForceUp;
			float num4 = stuckJumpForceSide;
			if (stuckJumpOverrideTimer > 0f)
			{
				num3 = stuckJumpOverrideUp;
				num4 = stuckJumpOverrideSide;
				stuckJumpOverrideTimer -= Time.fixedDeltaTime;
			}
			if (enemy.TeleportedTimer > 0f)
			{
				StuckDisable(0.5f);
			}
			if (stuckJumpDisableTimer > 0f)
			{
				stuckJumpDisableTimer -= Time.fixedDeltaTime;
				stuckJumpImpulse = false;
			}
			else
			{
				if (cartJumpTimer > 0f && enemy.Rigidbody.touchingCartTimer > 0f && cartJumpCooldown <= 0f)
				{
					stuckJumpImpulse = true;
					cartJumpCooldown = 2f;
				}
				if (enemy.StuckCount >= stuckJumpCount)
				{
					stuckJumpImpulse = true;
					enemy.StuckCount = 0;
				}
				bool flag2 = jumpingDelay && jumpingType == Type.Stuck;
				if (!flag && stuckJumpImpulse && (enemy.Grounded.grounded | flag2) && !jumping && jumpCooldown <= 0f)
				{
					if (stuckJumpDelayTimer > 0f)
					{
						JumpingDelaySet(_jumpingDelay: true, Type.Stuck);
						enemy.NavMeshAgent.Stop(0.1f);
						enemy.Rigidbody.OverrideFollowPosition(0.1f, 0f);
						enemy.Rigidbody.OverrideColliderMaterialStunned(0.1f);
						stuckJumpDelayTimer -= Time.fixedDeltaTime;
					}
					else
					{
						if (stuckJumpImpulseDirection == Vector3.zero)
						{
							stuckJumpImpulseDirection = ((Component)enemy).transform.position - ((Component)enemy.Rigidbody).transform.position;
							if (Random.Range(0, 2) == 0)
							{
								enemy.Rigidbody.DisableFollowPosition(1f, 10f);
								Vector2 insideUnitCircle = Random.insideUnitCircle;
								stuckJumpImpulseDirection = Vector2.op_Implicit(insideUnitCircle.normalized);
							}
						}
						Vector3 val3 = stuckJumpImpulseDirection.normalized * num4;
						val3.y = 0f;
						val3 += Vector3.up * num3;
						stuckJumpImpulseDirection = Vector3.zero;
						enemy.Rigidbody.JumpImpulse();
						enemy.Rigidbody.rb.AddForce(val3, (ForceMode)1);
						enemy.Rigidbody.DisableFollowPosition(0.25f, 10f);
						stuckJumpImpulse = false;
						flag = true;
						type = Type.Stuck;
					}
				}
				else if (stuckJumpDelayTimer != stuckJumpDelay)
				{
					stuckJumpDelayTimer = stuckJumpDelay;
					if (jumpingDelay && jumpingType == Type.Stuck)
					{
						JumpingDelaySet(_jumpingDelay: false, Type.Stuck);
					}
				}
			}
			if (cartJumpCooldown > 0f)
			{
				cartJumpCooldown -= Time.fixedDeltaTime;
			}
			if (cartJumpTimer > 0f)
			{
				cartJumpTimer -= Time.fixedDeltaTime;
			}
		}
		if (surfaceJump)
		{
			bool flag3 = jumpingDelay && jumpingType == Type.Surface;
			if (!flag && surfaceJumpImpulse && (enemy.Grounded.grounded | flag3) && !jumping && jumpCooldown <= 0f && surfaceJumpDisableTimer <= 0f)
			{
				float num5 = surfaceJumpForceUp;
				float num6 = surfaceJumpForceSide;
				if (surfaceJumpOverrideTimer > 0f)
				{
					num5 = surfaceJumpOverrideUp;
					num6 = surfaceJumpOverrideSide;
				}
				if (surfaceJumpDelayTimer > 0f)
				{
					JumpingDelaySet(_jumpingDelay: true, Type.Surface);
					enemy.NavMeshAgent.Stop(0.1f);
					enemy.Rigidbody.OverrideFollowPosition(0.1f, 0f);
					enemy.Rigidbody.OverrideColliderMaterialStunned(0.1f);
					surfaceJumpDelayTimer -= Time.fixedDeltaTime;
				}
				else
				{
					enemy.Rigidbody.DisableFollowPosition(0.2f, 20f);
					enemy.NavMeshAgent.Stop(0.3f);
					Vector3 val4 = surfaceJumpDirection * num6;
					val4.y = 0f;
					enemy.Rigidbody.JumpImpulse();
					enemy.Rigidbody.rb.AddForce(val4 + Vector3.up * num5, (ForceMode)1);
					surfaceJumpImpulse = false;
					stuckJumpImpulse = false;
					flag = true;
					type = Type.Surface;
				}
			}
			else if (surfaceJumpDelayTimer != surfaceJumpDelay)
			{
				surfaceJumpDelayTimer = surfaceJumpDelay;
				if (jumpingDelay && jumpingType == Type.Surface)
				{
					JumpingDelaySet(_jumpingDelay: false, Type.Surface);
				}
			}
			if (surfaceJumpOverrideTimer > 0f)
			{
				surfaceJumpOverrideTimer -= Time.fixedDeltaTime;
			}
			if (surfaceJumpDisableTimer > 0f)
			{
				surfaceJumpDisableTimer -= Time.fixedDeltaTime;
			}
		}
		bool flag4 = LandingContactLogic();
		if (!jumping)
		{
			if (flag)
			{
				JumpingDelaySet(_jumpingDelay: false, type);
				JumpingSet(_jumping: true, type);
				LandDelaySet(_landDelay: false);
				enemy.Grounded.GroundedDisable(0.1f);
			}
		}
		else if (flag4)
		{
			if (warpAgentOnLand && !enemy.NavMeshAgent.IsDisabled())
			{
				enemy.NavMeshAgent.Warp(((Component)enemy.Rigidbody).transform.position);
			}
			if (jumpingType == Type.Gap && gapLandDelay > 0f)
			{
				LandDelaySet(_landDelay: true);
				gapLandDelayTimer = gapLandDelay;
			}
			if (jumpingType == Type.Surface && surfaceLandDelay > 0f)
			{
				LandDelaySet(_landDelay: true);
				surfaceLandDelayTimer = surfaceLandDelay;
			}
			if (jumpingType == Type.Stuck && stuckLandDelay > 0f)
			{
				LandDelaySet(_landDelay: true);
				stuckLandDelayTimer = stuckLandDelay;
			}
			JumpingDelaySet(_jumpingDelay: false, Type.None);
			JumpingSet(_jumping: false, Type.None);
			jumpCooldown = 0.25f;
		}
		else if (jumpingType == Type.Gap)
		{
			enemy.NavMeshAgent.Warp(gapJumpLandPosition, _force: true);
		}
		if (jumpCooldown > 0f)
		{
			jumpCooldown -= Time.fixedDeltaTime;
			jumpCooldown = Mathf.Max(jumpCooldown, 0f);
			enemy.StuckCount = 0;
			surfaceJumpImpulse = false;
			stuckJumpImpulse = false;
			gapJumpImpulse = false;
		}
		if (gapLandDelayTimer > 0f || surfaceLandDelayTimer > 0f || stuckLandDelayTimer > 0f)
		{
			if (warpAgentOnLand)
			{
				enemy.NavMeshAgent.Warp(((Component)enemy.Rigidbody).transform.position, _force: true);
			}
			enemy.NavMeshAgent.Stop(0.1f);
			enemy.Rigidbody.OverrideFollowPosition(0.1f, 0f);
			enemy.Rigidbody.OverrideColliderMaterialStunned(0.1f);
		}
		if (gapLandDelayTimer > 0f)
		{
			gapLandDelayTimer -= Time.fixedDeltaTime;
			if (gapLandDelayTimer <= 0f)
			{
				LandDelaySet(_landDelay: false);
			}
		}
		if (surfaceLandDelayTimer > 0f)
		{
			surfaceLandDelayTimer -= Time.fixedDeltaTime;
			if (surfaceLandDelayTimer <= 0f)
			{
				LandDelaySet(_landDelay: false);
			}
		}
		if (stuckLandDelayTimer > 0f)
		{
			stuckLandDelayTimer -= Time.fixedDeltaTime;
			if (stuckLandDelayTimer <= 0f)
			{
				LandDelaySet(_landDelay: false);
			}
		}
	}

	private bool LandingContactLogic()
	{
		//IL_0010: Unknown result type (might be due to invalid IL or missing references)
		float y = enemy.Rigidbody.rb.linearVelocity.y;
		float distance = Mathf.Max(0.02f, (0f - y) * Time.fixedDeltaTime + 0.03f);
		EnemySnatcherSuspension enemySnatcherSuspension = SnatcherSuspension();
		bool flag = Object.op_Implicit((Object)(object)enemySnatcherSuspension) && enemySnatcherSuspension.JumpLandingSupportConfigured();
		bool flag2 = false;
		if (jumping)
		{
			if (flag)
			{
				flag2 = enemySnatcherSuspension.JumpLandingSupport();
			}
			else
			{
				flag2 = enemy.Grounded.grounded;
				if (!flag2 && y <= 0f)
				{
					flag2 = enemy.Grounded.GroundedSweep(distance);
				}
			}
		}
		if (flag2)
		{
			snatcherLandingContactTimer += Time.fixedDeltaTime;
		}
		else
		{
			snatcherLandingContactTimer = 0f;
		}
		int num;
		if (flag2)
		{
			if (flag)
			{
				num = ((snatcherLandingContactTimer >= 0.04f) ? 1 : 0);
				if (num == 0)
				{
					goto IL_0100;
				}
			}
			else
			{
				num = 1;
			}
			snatcherLandingPendingTimer = Mathf.Max(snatcherLandingPendingTimer, 2f);
			enemy.Grounded.grounded = true;
		}
		else
		{
			num = 0;
		}
		goto IL_0100;
		IL_0100:
		return (byte)num != 0;
	}

	private EnemySnatcherSuspension SnatcherSuspension()
	{
		if (!Object.op_Implicit((Object)(object)snatcherSuspension) && Object.op_Implicit((Object)(object)enemy) && enemy.HasRigidbody)
		{
			snatcherSuspension = ((Component)enemy.Rigidbody).GetComponent<EnemySnatcherSuspension>();
		}
		return snatcherSuspension;
	}

	public void JumpingSet(bool _jumping, Type _type)
	{
		//IL_007b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0081: Unknown result type (might be due to invalid IL or missing references)
		if (_jumping != jumping && SemiFunc.IsMasterClientOrSingleplayer())
		{
			if (_jumping)
			{
				enemy.Grounded.grounded = false;
				snatcherLandingPendingTimer = 0f;
				snatcherLandingContactTimer = 0f;
			}
			if (SemiFunc.IsMultiplayer())
			{
				enemy.Rigidbody.photonView.RPC("JumpingSetRPC", (RpcTarget)0, new object[2] { _jumping, _type });
			}
			else
			{
				JumpingSetRPC(_jumping, _type);
			}
		}
	}

	public void JumpingDelaySet(bool _jumpingDelay, Type _type)
	{
		//IL_0051: Unknown result type (might be due to invalid IL or missing references)
		//IL_0057: Unknown result type (might be due to invalid IL or missing references)
		if (jumpingDelay != _jumpingDelay && SemiFunc.IsMasterClientOrSingleplayer())
		{
			if (SemiFunc.IsMultiplayer())
			{
				enemy.Rigidbody.photonView.RPC("JumpingDelaySetRPC", (RpcTarget)0, new object[2] { _jumpingDelay, _type });
			}
			else
			{
				JumpingDelaySetRPC(_jumpingDelay, _type);
			}
		}
	}

	public void LandDelaySet(bool _landDelay)
	{
		if (landDelay != _landDelay && SemiFunc.IsMasterClientOrSingleplayer())
		{
			landDelay = _landDelay;
			if (SemiFunc.IsMultiplayer())
			{
				enemy.Rigidbody.photonView.RPC("LandDelaySetRPC", (RpcTarget)1, new object[1] { landDelay });
			}
		}
	}

	public void CartJump(float _time)
	{
		if (!Object.op_Implicit((Object)(object)snatcher))
		{
			cartJumpTimer = _time;
		}
	}

	public void GapJumpOverride(float _time, float _up, float _forward)
	{
		gapJumpOverrideTimer = _time;
		gapJumpOverrideUp = _up;
		gapJumpOverrideForward = _forward;
	}

	public void StuckJumpOverride(float _time, float _up, float _side)
	{
		stuckJumpOverrideTimer = _time;
		stuckJumpOverrideUp = _up;
		stuckJumpOverrideSide = _side;
	}

	public void SurfaceJumpOverride(float _time, float _up, float _side)
	{
		surfaceJumpOverrideTimer = _time;
		surfaceJumpOverrideUp = _up;
		surfaceJumpOverrideSide = _side;
	}

	[PunRPC]
	private void JumpingSetRPC(bool _jumping, Type _type, PhotonMessageInfo _info = default(PhotonMessageInfo))
	{
		//IL_0000: Unknown result type (might be due to invalid IL or missing references)
		if (SemiFunc.MasterOnlyRPC(_info))
		{
			if (_type != Type.None)
			{
				jumpingType = _type;
			}
			jumping = _jumping;
		}
	}

	[PunRPC]
	private void JumpingDelaySetRPC(bool _jumpingDelay, Type _type, PhotonMessageInfo _info = default(PhotonMessageInfo))
	{
		//IL_0000: Unknown result type (might be due to invalid IL or missing references)
		if (SemiFunc.MasterOnlyRPC(_info))
		{
			if (_type != Type.None)
			{
				jumpingType = _type;
			}
			jumpingDelay = _jumpingDelay;
		}
	}

	[PunRPC]
	private void LandDelaySetRPC(bool _landDelay, PhotonMessageInfo _info = default(PhotonMessageInfo))
	{
		//IL_0000: Unknown result type (might be due to invalid IL or missing references)
		if (SemiFunc.MasterOnlyRPC(_info))
		{
			landDelay = _landDelay;
		}
	}
}
