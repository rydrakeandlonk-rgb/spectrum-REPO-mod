using System.Collections;
using UnityEngine;
using UnityEngine.AI;

public class NotValuableObject : MonoBehaviour
{
	public PhysAttribute physAttributePreset;

	public PhysAudio audioPreset;

	public Durability durabilityPreset;

	public Gradient particleColors;

	[Range(0.5f, 3f)]
	public float audioPresetPitch = 1f;

	private NavMeshObstacle navMeshObstacle;

	private PhysGrabObject physGrabObject;

	private Rigidbody rb;

	[Space]
	public bool hasHealth;

	internal int healthCurrent;

	public int healthMax;

	[Space]
	public bool healthDestroy = true;

	[Space]
	public int healthLossOnBreakLight;

	public int healthLossOnBreakMedium;

	public int healthLossOnBreakHeavy;

	private void Start()
	{
		physGrabObject = ((Component)this).GetComponent<PhysGrabObject>();
		navMeshObstacle = ((Component)this).GetComponent<NavMeshObstacle>();
		if (Object.op_Implicit((Object)(object)navMeshObstacle))
		{
			Debug.LogError((object)(((Object)((Component)this).gameObject).name + " has a NavMeshObstacle component. Please remove it."), (Object)(object)((Component)this).gameObject);
		}
		((MonoBehaviour)this).StartCoroutine(EnableRigidbody());
		rb = ((Component)this).GetComponent<Rigidbody>();
		if (Object.op_Implicit((Object)(object)physAttributePreset))
		{
			if (Object.op_Implicit((Object)(object)rb))
			{
				rb.mass = physAttributePreset.mass;
			}
			if (Object.op_Implicit((Object)(object)physGrabObject))
			{
				physGrabObject.massOriginal = physAttributePreset.mass;
			}
		}
		else if (Object.op_Implicit((Object)(object)rb) || Object.op_Implicit((Object)(object)physGrabObject))
		{
			Debug.LogError((object)(((Object)((Component)this).gameObject).name + " is missing a PhysAttributePreset."), (Object)(object)((Component)this).gameObject);
		}
		if (hasHealth)
		{
			healthCurrent = healthMax;
		}
	}

	public void Impact(PhysGrabObjectImpactDetector.ImpactState _impactState)
	{
		switch (_impactState)
		{
		case PhysGrabObjectImpactDetector.ImpactState.Light:
			healthCurrent -= healthLossOnBreakLight;
			break;
		case PhysGrabObjectImpactDetector.ImpactState.Medium:
			healthCurrent -= healthLossOnBreakMedium;
			break;
		case PhysGrabObjectImpactDetector.ImpactState.Heavy:
			healthCurrent -= healthLossOnBreakHeavy;
			break;
		}
		if (healthCurrent <= 0 && healthDestroy)
		{
			physGrabObject.impactDetector.DestroyObject();
		}
	}

	private IEnumerator EnableRigidbody()
	{
		while (!LevelGenerator.Instance.Generated)
		{
			yield return (object)new WaitForSeconds(0.1f);
		}
		PhysGrabObject component = ((Component)this).GetComponent<PhysGrabObject>();
		if (!Object.op_Implicit((Object)(object)component))
		{
			yield return (object)new WaitForSeconds(0.5f);
			yield return (object)new WaitForFixedUpdate();
		}
		else
		{
			component.spawned = true;
		}
	}
}
