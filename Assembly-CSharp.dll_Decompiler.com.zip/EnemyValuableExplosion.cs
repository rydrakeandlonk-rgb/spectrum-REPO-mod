using UnityEngine;

public class EnemyValuableExplosion : MonoBehaviour
{
	public enum Size
	{
		Small,
		Medium,
		Big
	}

	public Size size = Size.Medium;

	public Sound explosionSoundSmall;

	public Sound explosionSoundSmallGlobal;

	public Sound explosionSoundMedium;

	public Sound explosionSoundMediumGlobal;

	public Sound explosionSoundBig;

	public Sound explosionSoundBigGlobal;

	private void Start()
	{
		//IL_0017: Unknown result type (might be due to invalid IL or missing references)
		//IL_0042: Unknown result type (might be due to invalid IL or missing references)
		//IL_0080: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ae: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d6: Unknown result type (might be due to invalid IL or missing references)
		//IL_0101: Unknown result type (might be due to invalid IL or missing references)
		//IL_013f: Unknown result type (might be due to invalid IL or missing references)
		//IL_016d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0195: Unknown result type (might be due to invalid IL or missing references)
		//IL_01c0: Unknown result type (might be due to invalid IL or missing references)
		//IL_01fe: Unknown result type (might be due to invalid IL or missing references)
		//IL_022c: Unknown result type (might be due to invalid IL or missing references)
		if (size == Size.Small)
		{
			explosionSoundSmall.Play(((Component)this).transform.position);
			explosionSoundSmallGlobal.Play(((Component)this).transform.position);
			GameDirector.instance.CameraImpact.ShakeDistance(3f, 3f, 6f, ((Component)this).transform.position, 0.2f);
			GameDirector.instance.CameraShake.ShakeDistance(3f, 3f, 6f, ((Component)this).transform.position, 0.5f);
		}
		else if (size == Size.Medium)
		{
			explosionSoundMedium.Play(((Component)this).transform.position);
			explosionSoundMediumGlobal.Play(((Component)this).transform.position);
			GameDirector.instance.CameraImpact.ShakeDistance(10f, 4f, 8f, ((Component)this).transform.position, 0.2f);
			GameDirector.instance.CameraShake.ShakeDistance(6f, 4f, 8f, ((Component)this).transform.position, 0.5f);
		}
		else if (size == Size.Big)
		{
			explosionSoundBig.Play(((Component)this).transform.position);
			explosionSoundBigGlobal.Play(((Component)this).transform.position);
			GameDirector.instance.CameraImpact.ShakeDistance(18f, 6f, 12f, ((Component)this).transform.position, 0.2f);
			GameDirector.instance.CameraShake.ShakeDistance(10f, 6f, 12f, ((Component)this).transform.position, 0.5f);
		}
	}
}
