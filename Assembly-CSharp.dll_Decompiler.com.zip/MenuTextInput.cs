using Platforms;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

public class MenuTextInput : MonoBehaviour
{
	public TextMeshProUGUI textMain;

	public TextMeshProUGUI textCursor;

	private SemiUI textUI;

	[Space]
	public bool upperOnly;

	public bool disallowSpaces;

	public int maxLength = 60;

	[Space]
	public bool obscureText;

	public char obscureChar = '*';

	[Space]
	public string gamepadTextInputDescription = "";

	private GamepadTextInput gamepadTextInput;

	internal string textCurrent = "";

	private string textPrevious = "";

	private float tooLongDenyCooldown;

	private MenuElementHover menuElementHover;

	internal MenuSelectableElement menuSelectableElement { get; private set; }

	private void Awake()
	{
		menuSelectableElement = ((Component)this).GetComponent<MenuSelectableElement>();
		if (!Object.op_Implicit((Object)(object)menuSelectableElement))
		{
			menuSelectableElement = ((Component)this).gameObject.AddComponent<MenuSelectableElement>();
		}
		menuElementHover = ((Component)this).GetComponent<MenuElementHover>();
		if (!Object.op_Implicit((Object)(object)menuElementHover))
		{
			menuElementHover = ((Component)this).gameObject.AddComponent<MenuElementHover>();
		}
		gamepadTextInput = new GamepadTextInput((string _text) =>
		{
			textCurrent = _text;
		});
	}

	private void Start()
	{
		textUI = ((Component)this).GetComponentInChildren<SemiUI>();
		MenuManager.instance.lastHoverMenuID = menuSelectableElement.menuID;
	}

	private void OnDisable()
	{
		gamepadTextInput.Close();
	}

	private void Update()
	{
		//IL_01b5: Unknown result type (might be due to invalid IL or missing references)
		//IL_027e: Unknown result type (might be due to invalid IL or missing references)
		tooLongDenyCooldown -= Time.deltaTime;
		MenuManager.instance.TextInputActive();
		bool flag = !MenuManager.instance.isKeyboardNavigating;
		if (((Selectable)menuSelectableElement).interactable != flag)
		{
			((Selectable)menuSelectableElement).interactable = flag;
		}
		gamepadTextInput.Update();
		if (!gamepadTextInput.IsOpen && SemiFunc.InputMode() == InputModes.Gamepad && menuElementHover.isHovering && SemiFunc.InputDown(InputKey.UIClick))
		{
			gamepadTextInput.Show(((TMP_Text)textMain).rectTransform, gamepadTextInputDescription, maxLength, textCurrent, obscureText);
		}
		if (textCurrent == "\b")
		{
			textCurrent = "";
		}
		textCurrent += Input.inputString;
		textCurrent = textCurrent.Replace("\n", "");
		if (disallowSpaces)
		{
			textCurrent = textCurrent.Replace(" ", "");
		}
		if (Input.inputString == "\b")
		{
			textCurrent = textCurrent.Remove(Mathf.Max(textCurrent.Length - 2, 0));
		}
		textCurrent = textCurrent.Replace("\r", "");
		if (textCurrent.Length > maxLength)
		{
			textCurrent = textCurrent.Remove(maxLength);
			if (tooLongDenyCooldown <= 0f)
			{
				tooLongDenyCooldown = 0.25f;
				textUI.SemiUITextFlashColor(Color.red, 0.2f);
				textUI.SemiUISpringShakeX(10f, 10f, 0.3f);
				textUI.SemiUISpringScale(0.05f, 5f, 0.2f);
				MenuManager.instance.MenuEffectClick(MenuManager.MenuClickEffectType.Deny, null, 1f, 1f, soundOnly: true);
			}
		}
		InputTextSet();
		if (textPrevious != textCurrent)
		{
			if (textCurrent.Length > textPrevious.Length)
			{
				textUI.SemiUISpringShakeY(1f, 5f, 0.2f);
				MenuManager.instance.MenuEffectClick(MenuManager.MenuClickEffectType.Tick, null, 2f, 0.2f, soundOnly: true);
			}
			else
			{
				textUI.SemiUITextFlashColor(Color.red, 0.2f);
				textUI.SemiUISpringShakeX(5f, 5f, 0.2f);
				MenuManager.instance.MenuEffectClick(MenuManager.MenuClickEffectType.Dud, null, 2f, 1f, soundOnly: true);
			}
		}
		textPrevious = textCurrent;
	}

	internal void InputTextSet()
	{
		//IL_006f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0085: Unknown result type (might be due to invalid IL or missing references)
		//IL_008a: Unknown result type (might be due to invalid IL or missing references)
		//IL_008f: Unknown result type (might be due to invalid IL or missing references)
		//IL_009b: Unknown result type (might be due to invalid IL or missing references)
		if (upperOnly)
		{
			textCurrent = textCurrent.ToUpper();
		}
		((TMP_Text)textMain).text = (obscureText ? new string(obscureChar, textCurrent.Length) : textCurrent);
		float num = ((TMP_Text)textMain).renderedWidth;
		if (num < 0f)
		{
			num = 0f;
		}
		Vector3 position = ((TMP_Text)textMain).transform.position + new Vector3(num + 1f, 0f, 0f);
		((TMP_Text)textCursor).transform.position = position;
		if (Mathf.Sin(Time.time * 8f) > 0f)
		{
			((TMP_Text)textCursor).text = "|";
		}
		else
		{
			((TMP_Text)textCursor).text = "";
		}
	}
}
