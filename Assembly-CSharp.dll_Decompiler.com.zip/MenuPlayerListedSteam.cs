using Platforms;
using UnityEngine;
using UnityEngine.UI;

public class MenuPlayerListedSteam : MonoBehaviour
{
	private MenuElementHover menuElementHover;

	private MenuPlayerListed menuPlayerListed;

	public RectTransform iconTransform;

	public RawImage icon;

	public AnimationCurve showCurve;

	public AnimationCurve hideCurve;

	private float showLerp = 0.1f;

	private void Awake()
	{
		menuElementHover = ((Component)this).GetComponent<MenuElementHover>();
		menuPlayerListed = ((Component)this).GetComponentInParent<MenuPlayerListed>();
	}

	private void Update()
	{
		//IL_0055: Unknown result type (might be due to invalid IL or missing references)
		//IL_005a: Unknown result type (might be due to invalid IL or missing references)
		//IL_005b: Unknown result type (might be due to invalid IL or missing references)
		//IL_005c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0066: Unknown result type (might be due to invalid IL or missing references)
		//IL_006b: Unknown result type (might be due to invalid IL or missing references)
		//IL_006e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0074: Unknown result type (might be due to invalid IL or missing references)
		//IL_007a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0085: Unknown result type (might be due to invalid IL or missing references)
		//IL_01cd: Unknown result type (might be due to invalid IL or missing references)
		//IL_01ce: Unknown result type (might be due to invalid IL or missing references)
		//IL_01e0: Unknown result type (might be due to invalid IL or missing references)
		//IL_01f0: Unknown result type (might be due to invalid IL or missing references)
		//IL_01f5: Unknown result type (might be due to invalid IL or missing references)
		//IL_020b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0154: Unknown result type (might be due to invalid IL or missing references)
		//IL_0155: Unknown result type (might be due to invalid IL or missing references)
		//IL_0167: Unknown result type (might be due to invalid IL or missing references)
		//IL_0177: Unknown result type (might be due to invalid IL or missing references)
		//IL_017c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0192: Unknown result type (might be due to invalid IL or missing references)
		int num = (Object.op_Implicit((Object)(object)menuPlayerListed.playerAvatar) ? menuPlayerListed.playerAvatar.playerCosmetics.colorsEquipped[5] : 0);
		if (num < 0 || num >= MetaManager.instance.colors.Count)
		{
			num = 0;
		}
		Color color = MetaManager.instance.colors[num].color;
		color = Color.Lerp(color, Color.white, 0.7f);
		Color val = new Color(color.r, color.g, color.b, 0f);
		if (menuElementHover.isHovering)
		{
			if (!menuElementHover.JustBecameCurrentTarget && SemiFunc.InputUIClick())
			{
				MenuManager.instance.MenuEffectClick(MenuManager.MenuClickEffectType.Confirm);
				if (Object.op_Implicit((Object)(object)menuPlayerListed.playerAvatar))
				{
					PlatformManager.instance.OpenPlayerProfile(menuPlayerListed.playerAvatar);
				}
				else if (menuPlayerListed.playerPhoton != null)
				{
					PlatformManager.instance.OpenPlayerProfile(menuPlayerListed.playerPhoton.UserId);
				}
				showLerp = 0.2f;
			}
			if (showLerp < 1f)
			{
				showLerp = Mathf.Clamp01(showLerp + 3f * Time.deltaTime);
				((Graphic)icon).color = Color.Lerp(val, color, showCurve.Evaluate(showLerp));
				((Transform)iconTransform).localScale = Vector3.LerpUnclamped(Vector3.zero, Vector3.one, showCurve.Evaluate(showLerp));
			}
		}
		else if (showLerp > 0f)
		{
			showLerp = Mathf.Clamp01(showLerp - 5f * Time.deltaTime);
			((Graphic)icon).color = Color.Lerp(val, color, hideCurve.Evaluate(showLerp));
			((Transform)iconTransform).localScale = Vector3.LerpUnclamped(Vector3.zero, Vector3.one, hideCurve.Evaluate(showLerp));
		}
	}
}
