using UnityEngine;
using UnityEngine.UI;

[RequireComponent(typeof(Image))]
public class InputGlyphImage : MonoBehaviour
{
	[Tooltip("Which action this glyph represents.")]
	public InputKey inputKey = InputKey.Interact;

	[Tooltip("Image the glyph sprite is written to. Defaults to the Image on this GameObject.")]
	public Image image;

	[Tooltip("Preserve the sprite's native aspect ratio when it changes.")]
	public bool preserveAspect = true;

	private void Reset()
	{
		image = ((Component)this).GetComponent<Image>();
	}

	private void Awake()
	{
		if ((Object)(object)image == (Object)null)
		{
			image = ((Component)this).GetComponent<Image>();
		}
	}

	private void OnEnable()
	{
		InputManager.instance.OnDeviceTypeChanged += OnDeviceChanged;
		Refresh();
	}

	private void OnDisable()
	{
		InputManager.instance.OnDeviceTypeChanged -= OnDeviceChanged;
	}

	private void OnDeviceChanged(InputDeviceType deviceType)
	{
		Refresh();
	}

	public void Refresh()
	{
		if (!((Object)(object)image == (Object)null))
		{
			Sprite sprite = InputGlyphs.GetSprite(inputKey);
			image.sprite = sprite;
			((Behaviour)image).enabled = (Object)(object)sprite != (Object)null;
			if (preserveAspect)
			{
				image.preserveAspect = true;
			}
		}
	}

	public void SetInputKey(InputKey key)
	{
		inputKey = key;
		Refresh();
	}
}
