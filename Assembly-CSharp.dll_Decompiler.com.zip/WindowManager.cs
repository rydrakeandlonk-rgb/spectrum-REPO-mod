using System;
using System.Runtime.InteropServices;
using UnityEngine;

public class WindowManager : MonoBehaviour
{
	public static WindowManager instance;

	private bool titleSet;

	[DllImport("user32.dll")]
	public static extern bool SetWindowText(IntPtr hwnd, string lpString);

	[DllImport("user32.dll")]
	public static extern IntPtr FindWindow(string className, string windowName);

	[RuntimeInitializeOnLoadMethod(/*Could not decode attribute arguments.*/)]
	private static void RuntimeInitializeOnLoad()
	{
		instance = null;
	}

	private void Awake()
	{
		if (!Object.op_Implicit((Object)(object)instance))
		{
			instance = this;
			Object.DontDestroyOnLoad((Object)(object)((Component)this).gameObject);
			TrySetTitle();
		}
		else
		{
			instance.TrySetTitle();
			Object.Destroy((Object)(object)((Component)this).gameObject);
		}
	}

	private void Start()
	{
		TrySetTitle();
	}

	private void TrySetTitle()
	{
		if (!titleSet)
		{
			IntPtr intPtr = FindWindow("UnityWndClass", "Repo");
			if (intPtr != IntPtr.Zero)
			{
				SetWindowText(intPtr, "R.E.P.O.");
				titleSet = true;
			}
		}
	}
}
