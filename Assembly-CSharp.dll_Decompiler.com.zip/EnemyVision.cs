using System;
using System.Collections;
using System.Collections.Generic;
using Photon.Pun;
using UnityEngine;
using UnityEngine.Events;

public class EnemyVision : MonoBehaviour
{
	private Enemy Enemy;

	internal bool HasVision;

	internal float DisableTimer = 0.1f;

	internal float StandOverrideTimer;

	private float planarVisionTimer;

	private Vector3 planarVisionForward;

	private float VisionTimer;

	private float VisionCheckTime = 0.25f;

	public Transform VisionTransform;

	[Header("Base")]
	public float VisionDistance = 10f;

	public Dictionary<int, int> VisionsTriggered = new Dictionary<int, int>();

	public Dictionary<int, bool> VisionTriggered = new Dictionary<int, bool>();

	[Header("Close")]
	public float VisionDistanceClose = 3.5f;

	public float VisionDistanceCloseCrouch = 2f;

	[Header("Dot")]
	public float VisionDotStanding = 0.4f;

	public float VisionDotCrouch = 0.6f;

	public float VisionDotCrawl = 0.9f;

	[Header("Phys Object Vision")]
	public bool PhysObjectVision = true;

	private float PhysObjectVisionRadius = 10f;

	public float PhysObjectVisionRadiusOverride = -1f;

	public float PhysObjectVisionDot = 0.4f;

	[Header("Triggers")]
	public int VisionsToTrigger = 4;

	public int VisionsToTriggerCrouch = 10;

	public int VisionsToTriggerCrawl = 20;

	[Header("Events")]
	public UnityEvent onVisionTriggered;

	internal int onVisionTriggeredID;

	internal PlayerAvatar onVisionTriggeredPlayer;

	internal bool onVisionTriggeredCulled;

	internal bool onVisionTriggeredNear;

	internal float onVisionTriggeredDistance;

	private bool VisionLogicActive;

	private bool[] playerGrabVision = Array.Empty<bool>();

	private Collider[] physObjectVisionHits = new Collider[64];

	private RaycastHit[] visionRayHits = new RaycastHit[64];

	private void Awake()
	{
		Enemy = ((Component)this).GetComponent<Enemy>();
		((MonoBehaviour)this).StartCoroutine(Vision());
		VisionLogicActive = true;
	}

	private void OnDisable()
	{
		((MonoBehaviour)this).StopAllCoroutines();
		VisionLogicActive = false;
		planarVisionTimer = 0f;
	}

	private void OnEnable()
	{
		if (!VisionLogicActive)
		{
			DisableVision(0.5f);
			((MonoBehaviour)this).StartCoroutine(Vision());
			VisionLogicActive = true;
		}
	}

	public void PlayerAdded(int photonID)
	{
		VisionsTriggered.TryAdd(photonID, 0);
		VisionTriggered.TryAdd(photonID, value: false);
	}

	public void PlayerRemoved(int photonID)
	{
		VisionsTriggered.Remove(photonID);
		VisionTriggered.Remove(photonID);
	}

	private IEnumerator Vision()
	{
		VisionLogicActive = true;
		if (GameManager.Multiplayer() && !PhotonNetwork.IsMasterClient)
		{
			yield break;
		}
		while (VisionsTriggered.Count == 0)
		{
			yield return (object)new WaitForSeconds(VisionCheckTime);
		}
		while (true)
		{
			if (DisableTimer > 0f)
			{
				DisableTimer -= Time.deltaTime;
				foreach (PlayerAvatar player in GameDirector.instance.PlayerList)
				{
					int viewID = player.photonView.ViewID;
					VisionTriggered[viewID] = false;
					VisionsTriggered[viewID] = 0;
				}
				yield return null;
				continue;
			}
			if (!Enemy.HasStateChaseBegin || Enemy.CurrentState != EnemyState.ChaseBegin)
			{
				HasVision = false;
				int count = GameDirector.instance.PlayerList.Count;
				if (playerGrabVision.Length < count)
				{
					playerGrabVision = new bool[count];
				}
				Array.Clear(playerGrabVision, 0, count);
				if (PhysObjectVision)
				{
					float radius = PhysObjectVisionRadius;
					if (PhysObjectVisionRadiusOverride > 0f)
					{
						radius = PhysObjectVisionRadiusOverride;
					}
					int num = PhysObjectVisionHitsGet(radius);
					for (int i = 0; i < num; i++)
					{
						Collider val = physObjectVisionHits[i];
						if (!((Component)val).CompareTag("Phys Grab Object"))
						{
							continue;
						}
						PhysGrabObject componentInParent = ((Component)val).GetComponentInParent<PhysGrabObject>();
						if (!Object.op_Implicit((Object)(object)componentInParent) || componentInParent.playerGrabbing.Count <= 0)
						{
							continue;
						}
						Vector3 direction = componentInParent.centerPoint - VisionTransform.position;
						int num2 = VisionRayHitsGet(direction, direction.magnitude);
						bool flag = true;
						if (num2 > 0)
						{
							for (int j = 0; j < num2; j++)
							{
								RaycastHit val2 = visionRayHits[j];
								if (((Component)val2.transform).CompareTag("Phys Grab Object") || ((Component)val2.transform).CompareTag("Enemy"))
								{
									PhysGrabObject componentInParent2 = ((Component)val2.transform).GetComponentInParent<PhysGrabObject>();
									if (Object.op_Implicit((Object)(object)componentInParent2) && ((Object)(object)componentInParent2 == (Object)(object)componentInParent || (Enemy.HasRigidbody && (Object)(object)((Component)val2.transform).GetComponentInParent<EnemyRigidbody>() == (Object)(object)Enemy.Rigidbody)))
									{
										continue;
									}
								}
								flag = false;
							}
						}
						if (!flag || !(VisionDot(direction) >= PhysObjectVisionDot))
						{
							continue;
						}
						int num3 = 0;
						foreach (PlayerAvatar player2 in GameDirector.instance.PlayerList)
						{
							if ((Object)(object)player2 == (Object)(object)componentInParent.playerGrabbing[0].playerAvatar)
							{
								playerGrabVision[num3] = true;
							}
							num3++;
						}
					}
				}
				int num4 = 0;
				foreach (PlayerAvatar player3 in GameDirector.instance.PlayerList)
				{
					bool flag2 = false;
					int viewID2 = player3.photonView.ViewID;
					if (!player3.isDisabled && player3.enemyVisionFreezeTimer > 0f)
					{
						if (VisionTriggered[viewID2])
						{
							VisionTrigger(viewID2, player3, culled: false, playerNear: false);
						}
						num4++;
						continue;
					}
					VisionTriggered[viewID2] = false;
					if (player3.isDisabled || EnemyDirector.instance.debugNoVision.Contains(player3.steamID))
					{
						num4++;
						continue;
					}
					float num5 = Vector3.Distance(VisionTransform.position, player3.PlayerVisionTarget.VisionTransform.position);
					if (!playerGrabVision[num4] && num5 > VisionDistance)
					{
						num4++;
						continue;
					}
					bool flag3 = player3.isCrawling;
					bool flag4 = player3.isCrouching;
					if (player3.isTumbling)
					{
						flag4 = true;
						flag3 = false;
					}
					if (StandOverrideTimer > 0f)
					{
						flag4 = false;
						flag3 = false;
					}
					Transform val3 = null;
					Transform val4 = null;
					Vector3 direction2 = ((Component)player3.PlayerVisionTarget.VisionTransform).transform.position - VisionTransform.position;
					Collider[] array = Physics.OverlapSphere(VisionTransform.position, 0.01f, LayerMask.op_Implicit(Enemy.VisionMask));
					if (array.Length != 0)
					{
						Collider[] array2 = array;
						foreach (Collider val5 in array2)
						{
							if (!((Component)((Component)val5).transform).CompareTag("Enemy"))
							{
								if (((Component)((Component)val5).transform).CompareTag("Player"))
								{
									val3 = ((Component)val5).transform;
								}
								if (Object.op_Implicit((Object)(object)((Component)((Component)val5).transform).GetComponentInParent<PlayerTumble>()))
								{
									val3 = ((Component)val5).transform;
								}
								if (!Object.op_Implicit((Object)(object)((Component)((Component)val5).transform).GetComponentInParent<EnemyRigidbody>()))
								{
									val4 = ((Component)val5).transform;
								}
							}
						}
					}
					if (!Object.op_Implicit((Object)(object)val4))
					{
						int num6 = VisionRayHitsGet(direction2, VisionDistance);
						float num7 = 1000f;
						for (int l = 0; l < num6; l++)
						{
							RaycastHit val6 = visionRayHits[l];
							if (((Component)val6.transform).CompareTag("Enemy"))
							{
								continue;
							}
							if (((Component)val6.transform).CompareTag("Player"))
							{
								val3 = val6.transform;
							}
							if (!Object.op_Implicit((Object)(object)((Component)val6.transform).GetComponentInParent<EnemyRigidbody>()))
							{
								if (Object.op_Implicit((Object)(object)((Component)val6.transform).GetComponentInParent<PlayerTumble>()))
								{
									val3 = val6.transform;
								}
								float num8 = Vector3.Distance(VisionTransform.position, val6.point);
								if (num8 < num7)
								{
									num7 = num8;
									val4 = val6.transform;
								}
							}
						}
					}
					if (playerGrabVision[num4] || (Object.op_Implicit((Object)(object)val3) && (Object)(object)val3 == (Object)(object)val4))
					{
						float num9 = VisionDot(direction2);
						bool flag5 = false;
						if (flag4)
						{
							if (num5 <= VisionDistanceCloseCrouch)
							{
								flag5 = true;
							}
						}
						else if (num5 <= VisionDistanceClose)
						{
							flag5 = true;
						}
						if (flag5)
						{
							VisionsTriggered[viewID2] = VisionsToTrigger;
						}
						bool flag6 = false;
						if (flag3 && Enemy.CurrentState != EnemyState.LookUnder)
						{
							if (num9 >= VisionDotCrawl)
							{
								flag6 = true;
							}
						}
						else if (flag4 && Enemy.CurrentState != EnemyState.LookUnder)
						{
							if (num9 >= VisionDotCrouch)
							{
								flag6 = true;
							}
						}
						else if (num9 >= VisionDotStanding)
						{
							flag6 = true;
						}
						if (playerGrabVision[num4] | flag6 | flag5)
						{
							flag2 = true;
							bool flag7 = false;
							if (flag3 && Enemy.CurrentState != EnemyState.LookUnder)
							{
								if (VisionsTriggered[viewID2] >= VisionsToTriggerCrawl)
								{
									flag7 = true;
								}
							}
							else if (flag4 && Enemy.CurrentState != EnemyState.LookUnder)
							{
								if (VisionsTriggered[viewID2] >= VisionsToTriggerCrouch)
								{
									flag7 = true;
								}
							}
							else if (VisionsTriggered[viewID2] >= VisionsToTrigger)
							{
								flag7 = true;
							}
							bool culled = false;
							if (Enemy.HasOnScreen)
							{
								if (GameManager.instance.gameMode == 0)
								{
									if (Enemy.OnScreen.CulledLocal)
									{
										culled = true;
									}
								}
								else if (Enemy.OnScreen.CulledPlayer[player3.photonView.ViewID])
								{
									culled = true;
								}
							}
							if (flag7 | flag5)
							{
								VisionTrigger(viewID2, player3, culled, flag5);
							}
						}
					}
					if (flag2)
					{
						VisionsTriggered[viewID2]++;
					}
					else
					{
						VisionsTriggered[viewID2] = 0;
					}
					num4++;
				}
			}
			if (StandOverrideTimer > 0f)
			{
				StandOverrideTimer -= VisionCheckTime;
			}
			if (planarVisionTimer > 0f)
			{
				planarVisionTimer = Mathf.Max(0f, planarVisionTimer - VisionCheckTime);
			}
			yield return (object)new WaitForSeconds(VisionCheckTime);
		}
	}

	private int PhysObjectVisionHitsGet(float _radius)
	{
		//IL_0006: Unknown result type (might be due to invalid IL or missing references)
		//IL_0012: Unknown result type (might be due to invalid IL or missing references)
		//IL_003f: Unknown result type (might be due to invalid IL or missing references)
		//IL_004b: Unknown result type (might be due to invalid IL or missing references)
		int num;
		for (num = Physics.OverlapSphereNonAlloc(VisionTransform.position, _radius, physObjectVisionHits, LayerMask.op_Implicit(SemiFunc.LayerMaskGetPhysGrabObject())); num >= physObjectVisionHits.Length; num = Physics.OverlapSphereNonAlloc(VisionTransform.position, _radius, physObjectVisionHits, LayerMask.op_Implicit(SemiFunc.LayerMaskGetPhysGrabObject())))
		{
			Array.Resize(ref physObjectVisionHits, physObjectVisionHits.Length * 2);
		}
		return num;
	}

	private int VisionRayHitsGet(Vector3 _direction, float _distance)
	{
		//IL_0006: Unknown result type (might be due to invalid IL or missing references)
		//IL_000b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0019: Unknown result type (might be due to invalid IL or missing references)
		//IL_0047: Unknown result type (might be due to invalid IL or missing references)
		//IL_004c: Unknown result type (might be due to invalid IL or missing references)
		//IL_005a: Unknown result type (might be due to invalid IL or missing references)
		int num;
		for (num = Physics.RaycastNonAlloc(VisionTransform.position, _direction, visionRayHits, _distance, LayerMask.op_Implicit(Enemy.VisionMask), (QueryTriggerInteraction)1); num >= visionRayHits.Length; num = Physics.RaycastNonAlloc(VisionTransform.position, _direction, visionRayHits, _distance, LayerMask.op_Implicit(Enemy.VisionMask), (QueryTriggerInteraction)1))
		{
			Array.Resize(ref visionRayHits, visionRayHits.Length * 2);
		}
		return num;
	}

	public void VisionTrigger(int playerID, PlayerAvatar player, bool culled, bool playerNear)
	{
		PlayerAdded(playerID);
		VisionTriggered[playerID] = true;
		VisionsTriggered[playerID] = Mathf.Max(VisionsTriggered[playerID], VisionsToTrigger);
		onVisionTriggeredID = playerID;
		onVisionTriggeredPlayer = player;
		onVisionTriggeredCulled = culled;
		onVisionTriggeredNear = playerNear;
		onVisionTriggered.Invoke();
	}

	public void DisableVision(float time)
	{
		DisableTimer = time;
	}

	private float VisionDot(Vector3 _direction)
	{
		//IL_0025: Unknown result type (might be due to invalid IL or missing references)
		//IL_002c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0037: Unknown result type (might be due to invalid IL or missing references)
		//IL_0038: Unknown result type (might be due to invalid IL or missing references)
		//IL_003d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0042: Unknown result type (might be due to invalid IL or missing references)
		//IL_0058: Unknown result type (might be due to invalid IL or missing references)
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		if (planarVisionTimer <= 0f || planarVisionForward.sqrMagnitude < 0.0001f)
		{
			return Vector3.Dot(VisionTransform.forward, _direction.normalized);
		}
		Vector3 val = Vector3.ProjectOnPlane(_direction, Vector3.up);
		if (val.sqrMagnitude < 0.0001f)
		{
			return 1f;
		}
		return Vector3.Dot(planarVisionForward, val.normalized);
	}

	internal void OverridePlanarVision(Vector3 _forward, float _time = 0.1f)
	{
		//IL_0001: Unknown result type (might be due to invalid IL or missing references)
		//IL_0002: Unknown result type (might be due to invalid IL or missing references)
		//IL_0007: Unknown result type (might be due to invalid IL or missing references)
		//IL_000c: Unknown result type (might be due to invalid IL or missing references)
		//IL_000f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0014: Unknown result type (might be due to invalid IL or missing references)
		Vector3 val = Vector3.ProjectOnPlane(_forward, Vector3.up);
		planarVisionForward = val.normalized;
		planarVisionTimer = Mathf.Max(0f, _time);
	}

	public void StandOverride(float time)
	{
		StandOverrideTimer = time;
	}
}
