using System;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;

public class CosmeticCustomCondition : MonoBehaviour
{
	public enum Type
	{
		Enemy_SlowMouth,
		Player_Crown,
		Player_DeathHead,
		HeadTopMesh_Shape_Big,
		FootRight_Shape_Long,
		FootLeft_Shape_Long,
		FootRight_Shape_Normal,
		FootLeft_Shape_Normal,
		FootRight_Shape_Short,
		FootLeft_Shape_Short,
		BodyTop_Overlap_HeadBottom,
		HeadBottom_Overlap_BodyTop,
		HeadBottom_OverrideFlat,
		BodyTop_OverrideFlat,
		HeadTopMesh_Shape_Default,
		HeadTopMesh_Shape_Tiny,
		EyeRight_Disable,
		EyeLeft_Disable,
		BodyTop_Overlap_BodyBottom_Front,
		BodyTop_Overlap_BodyBottom_Back,
		BodyBottom_ProtrudeFront,
		BodyBottom_Protrude,
		Hat_Shape_Wide,
		BodyTop_State_Flat,
		HeadBottom_State_Flat,
		Player_LookDown_Restrict,
		Eyewear_Shape_VeryTall_Inner,
		Eyewear_Shape_Tall,
		Hat_Overlap_FaceTop,
		Hat_Overlap_FaceBottom,
		Eyewear_Overlap_FaceTop,
		Eyewear_Overlap_FaceBottom,
		FaceBottom_Protrude,
		Eyewear_Overlap_FaceBottom_Protrude,
		FaceTop_Shape_Huge,
		FaceTop_Shape_Tall,
		BodyTopMesh_Shape_Default,
		BodyTopMesh_Shape_Big,
		BodyTopMesh_Shape_Tiny,
		BodyBottomMesh_Shape_Default,
		BodyBottomMesh_Shape_Big,
		BodyBottomMesh_Shape_Tiny,
		ArmRightMesh_Shape_Default,
		ArmRightMesh_Shape_Big,
		ArmRightMesh_Shape_Tiny,
		ArmLeftMesh_Shape_Default,
		ArmLeftMesh_Shape_Big,
		ArmLeftMesh_Shape_Tiny,
		LegRightMesh_Shape_Default,
		LegRightMesh_Shape_Big,
		LegRightMesh_Shape_Tiny,
		LegLeftMesh_Shape_Default,
		LegLeftMesh_Shape_Big,
		LegLeftMesh_Shape_Tiny,
		FootRight_Protrude,
		FootLeft_Protrude,
		HeadTop_Covered_TopMiddle,
		HeadTopMesh_Shape_Unchanged,
		HeadBottomMesh_Shape_Unchanged,
		HeadBottomMesh_Shape_Default,
		HeadBottomMesh_Shape_Big,
		HeadBottomMesh_Shape_Tiny,
		BodyTopMesh_Shape_Unchanged,
		BodyBottomMesh_Shape_Unchanged,
		ArmRightMesh_Shape_Unchanged,
		ArmLeftMesh_Shape_Unchanged,
		LegRightMesh_Shape_Unchanged,
		LegLeftMesh_Shape_Unchanged,
		Ears_Shape_Tall,
		FaceBottom_Overlap_HeadBottom,
		FaceTop_Shape_VeryTall,
		ArmRightMesh_Shape_BigUpper,
		ArmLeftMesh_Shape_BigUpper,
		ArmRightMesh_Shape_BigLower,
		ArmLeftMesh_Shape_BigLower,
		HeadTopMesh_Shape_MissingRight,
		FaceTop_Covered_Middle,
		FaceTop_Covered_Left,
		FaceTop_Covered_Right,
		Eyewear_Shape_EyesRight,
		Eyewear_Shape_EyesLeft,
		Eyewear_Shape_EyesBoth,
		Eyewear_Shape_VeryTall_Outer,
		EyeLidRightMesh_Protrude,
		EyeLidLeftMesh_Protrude,
		FaceTop_Overlap_FaceBottom,
		HeadBottom_Protrude,
		BodyBottomMesh_Shape_Wide,
		BodyBottomMesh_Shape_Tall,
		ArmLeftMesh_Shape_Huge,
		ArmRightMesh_Shape_Huge,
		LegRightMesh_Shape_BigUpper,
		LegRightMesh_Shape_BigLower,
		LegRightMesh_Shape_Huge,
		LegLeftMesh_Shape_BigUpper,
		LegLeftMesh_Shape_BigLower,
		LegLeftMesh_Shape_Huge,
		Hat_Push_Out_Eyebrows_Big,
		Hat_Hide_Right_Eyebrow,
		Hat_Push_Out_Eyebrows_Small
	}

	private Cosmetic cosmetic;

	public List<Type> types;

	internal static IEnumerable<Type> GetTypes()
	{
		return from Type e in Enum.GetValues(typeof(Type))
			orderby e.ToString()
			select e;
	}

	private void Start()
	{
		cosmetic = ((Component)this).GetComponentInParent<Cosmetic>();
	}

	private void Update()
	{
		if (!Object.op_Implicit((Object)(object)cosmetic.playerCosmetics))
		{
			return;
		}
		foreach (Type type in types)
		{
			cosmetic.playerCosmetics.ConditionCustomSet(type);
		}
	}
}
