using System.Collections.Generic;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

public class ResultScreenUI : MonoBehaviour
{
	internal enum State
	{
		FadeIn,
		CloseDoor,
		MiddleFade,
		Cosmetics,
		FadeOut
	}

	public static ResultScreenUI instance;

	public GameObject activeObject;

	private bool active = true;

	private SemiFunc.Rarity cosmeticRarity;

	[Space]
	public List<GameObject> boxGraphics;

	public List<GameObject> boxGraphicsArm;

	[Space]
	public List<GameObject> tokenGraphicsFront;

	public List<GameObject> tokenGraphicsSide;

	public List<GameObject> tokenGraphicsFrontArm;

	public List<GameObject> tokenGraphicsSideArm;

	[Space]
	public LocalizedAsset localizedSkipText;

	public TextMeshProUGUI skipText;

	private SpringFloat skipTextSpring = new SpringFloat
	{
		damping = 0.4f,
		speed = 30f,
		lastPosition = 1f
	};

	[Space]
	public ParticleSystem tokenTrailParticle;

	private Animator animator;

	private int animatorTruckClosed = Animator.StringToHash("truckClosed");

	private int animatorMiddleFade = Animator.StringToHash("middleFade");

	private int animatorCosmetic = Animator.StringToHash("cosmetic");

	private int animatorSkipActive = Animator.StringToHash("skipActive");

	private int animatorSkipped = Animator.StringToHash("skipped");

	public Image fadeImage;

	public AnimationCurve fadeCurve;

	private float fadeLerp;

	private Color fadePrevious = Color.black;

	private Color fadeNew = Color.black;

	public RectTransform shakeTransformBack;

	public RectTransform shakeTransformFront;

	public RectTransform shakeTransformRotation;

	[Space]
	public ShakeAnimation shakeX;

	public ShakeAnimation shakeY;

	public ShakeAnimation shakeRotation;

	public Sound soundTruckDoorCloseStart;

	public Sound soundTruckDoorCloseStop;

	[Space]
	public Sound soundArmIntro;

	public Sound soundArmOutro;

	[Space]
	public Sound soundArmMoveShort;

	public Sound soundArmMoveLong;

	[Space]
	public Sound soundBoxImpactCommon;

	public Sound soundTokenTwirl;

	[Space]
	public Sound soundTokenFlickCommon;

	public Sound soundTokenFlickUncommon;

	public Sound soundTokenFlickRare;

	public Sound soundTokenFlickUltraRare;

	internal State stateCurrent;

	private bool stateImpulse = true;

	private float stateTimer;

	internal bool debugSkip;

	private bool fetched;

	internal bool skip;

	private int cosmeticIndex;

	private bool cosmeticIndexRewarded;

	[RuntimeInitializeOnLoadMethod(/*Could not decode attribute arguments.*/)]
	private static void RuntimeInitializeOnLoad()
	{
		instance = null;
	}

	private void Awake()
	{
		//IL_000d: Unknown result type (might be due to invalid IL or missing references)
		instance = this;
		((Graphic)fadeImage).color = fadeNew;
		activeObject.SetActive(false);
		animator = ((Component)this).GetComponent<Animator>();
		animator.keepAnimatorStateOnDisable = true;
		InputGlyphs.OnGlyphsChanged += SkipTextGlyphsChanged;
	}

	private void OnDestroy()
	{
		InputGlyphs.OnGlyphsChanged -= SkipTextGlyphsChanged;
	}

	private void Update()
	{
		//IL_010f: Unknown result type (might be due to invalid IL or missing references)
		if (!fetched)
		{
			if (!SemiFunc.RunIsLevel())
			{
				skip = true;
			}
			fetched = true;
		}
		if (GameDirector.instance.currentState == GameDirector.gameState.Result)
		{
			if (skip || RunManager.instance.allPlayersDead)
			{
				GameDirector.instance.currentState = GameDirector.gameState.End;
			}
			else if (debugSkip)
			{
				FinishResultScreen();
			}
			if (!active)
			{
				activeObject.SetActive(true);
				active = true;
			}
			switch (stateCurrent)
			{
			case State.FadeIn:
				StateFadeIn();
				break;
			case State.CloseDoor:
				StateCloseDoor();
				break;
			case State.MiddleFade:
				StateMiddleFade();
				break;
			case State.Cosmetics:
				StateCosmetics();
				break;
			case State.FadeOut:
				StateFadeOut();
				break;
			}
			FadeLogic();
			ShakeLogic();
			float num = SemiFunc.SpringFloatGet(skipTextSpring, 1f);
			((Transform)((TMP_Text)skipText).rectTransform).localScale = new Vector3(num, num, 1f);
		}
		else if (active)
		{
			activeObject.SetActive(false);
			active = false;
		}
	}

	private void SkipTextRefresh()
	{
		((TMP_Text)skipText).text = SemiFunc.InputDisplayReplaceTags(localizedSkipText?.GetLocalizedString() ?? "[back] to skip", "<color=#FF8500><u><b>", "</b></u></color>");
	}

	private void SkipTextGlyphsChanged()
	{
		if (active)
		{
			SkipTextRefresh();
			skipTextSpring.springVelocity = 6f;
		}
	}

	private void StateFadeIn()
	{
		if (stateImpulse)
		{
			stateImpulse = false;
			stateTimer = 0.2f;
			SkipTextRefresh();
		}
		stateTimer -= Time.deltaTime;
		if (stateTimer <= 0f)
		{
			StateUpdate(State.CloseDoor);
		}
	}

	private void StateCloseDoor()
	{
		if (stateImpulse)
		{
			stateImpulse = false;
			stateTimer = 0.5f;
			animator.SetBool(animatorTruckClosed, true);
		}
		stateTimer -= Time.deltaTime;
		if (!(stateTimer <= 0f))
		{
			return;
		}
		if (RoundDirector.instance.cosmeticWorldObjectsExtracted.Count > 0)
		{
			if (SemiFunc.IsMultiplayer() && !SemiFunc.IsMasterClient() && RunManager.instance.cosmeticWorldObjectCooldown > 0f)
			{
				RoundDirector.instance.cosmeticWorldObjectsExtracted.Clear();
				NetworkManager.instance.TriggerLeavePhotonRoomForcedStuckInLoading();
				StateUpdate(State.FadeOut);
			}
			else
			{
				StateUpdate(State.MiddleFade);
			}
		}
		else
		{
			StateUpdate(State.FadeOut);
		}
	}

	private void StateMiddleFade()
	{
		if (stateImpulse)
		{
			stateImpulse = false;
			stateTimer = 1f;
			animator.SetTrigger(animatorMiddleFade);
			animator.SetTrigger(animatorSkipActive);
		}
		stateTimer -= Time.deltaTime;
		CosmeticTokenUI.instance.Show();
		if (stateTimer <= 0f)
		{
			StateUpdate(State.Cosmetics);
		}
	}

	private void StateCosmetics()
	{
		if (stateImpulse)
		{
			if (cosmeticIndex >= RoundDirector.instance.cosmeticWorldObjectsExtracted.Count)
			{
				StateUpdate(State.FadeOut);
				return;
			}
			SetGraphics((int)RoundDirector.instance.cosmeticWorldObjectsExtracted[cosmeticIndex]);
			cosmeticIndex++;
			cosmeticIndexRewarded = false;
			animator.SetTrigger(animatorCosmetic);
			stateImpulse = false;
		}
		if (SemiFunc.InputDown(InputKey.Back))
		{
			shakeX.Set(3f, 0.75f);
			shakeY.Set(3f, 0.75f);
			shakeRotation.Set(2f, 1f);
			animator.SetTrigger(animatorSkipped);
			StateUpdate(State.FadeOut);
		}
		else
		{
			CosmeticTokenUI.instance.Show();
		}
	}

	private void StateFadeOut()
	{
		if (stateImpulse)
		{
			tokenTrailParticle.Stop();
			stateImpulse = false;
			stateTimer = 1f;
		}
		stateTimer -= Time.deltaTime;
		if (stateTimer <= 0f)
		{
			if (RoundDirector.instance.cosmeticWorldObjectsExtracted.Count > 0 && !cosmeticIndexRewarded)
			{
				MetaManager.instance.CosmeticTokenAdd(RoundDirector.instance.cosmeticWorldObjectsExtracted[cosmeticIndex - 1]);
				cosmeticIndexRewarded = true;
			}
			FinishResultScreen();
		}
	}

	private void StateUpdate(State _state)
	{
		if (stateCurrent != _state)
		{
			stateCurrent = _state;
			stateImpulse = true;
		}
	}

	private void FadeLogic()
	{
		//IL_0073: Unknown result type (might be due to invalid IL or missing references)
		//IL_007f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0084: Unknown result type (might be due to invalid IL or missing references)
		//IL_001f: Unknown result type (might be due to invalid IL or missing references)
		//IL_002b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0030: Unknown result type (might be due to invalid IL or missing references)
		//IL_0093: Unknown result type (might be due to invalid IL or missing references)
		//IL_0098: Unknown result type (might be due to invalid IL or missing references)
		//IL_009e: Unknown result type (might be due to invalid IL or missing references)
		//IL_009f: Unknown result type (might be due to invalid IL or missing references)
		//IL_003f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0044: Unknown result type (might be due to invalid IL or missing references)
		//IL_004a: Unknown result type (might be due to invalid IL or missing references)
		//IL_004b: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d7: Unknown result type (might be due to invalid IL or missing references)
		//IL_00dd: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f3: Unknown result type (might be due to invalid IL or missing references)
		float num;
		if (stateCurrent == State.FadeOut)
		{
			Color val = new Color(0f, 0f, 0f, 1f);
			num = 2f;
			if (fadeNew != val)
			{
				fadePrevious = ((Graphic)fadeImage).color;
				fadeNew = val;
				fadeLerp = 0f;
			}
		}
		else
		{
			Color val2 = new Color(0f, 0f, 0f, 0f);
			num = 2f;
			if (fadeNew != val2)
			{
				fadePrevious = ((Graphic)fadeImage).color;
				fadeNew = val2;
				fadeLerp = 0f;
			}
		}
		if (fadeLerp < 1f)
		{
			fadeLerp += num * Time.deltaTime;
			((Graphic)fadeImage).color = Color.Lerp(fadePrevious, fadeNew, fadeCurve.Evaluate(fadeLerp));
		}
	}

	private void ShakeLogic()
	{
		//IL_003d: Unknown result type (might be due to invalid IL or missing references)
		//IL_006f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0094: Unknown result type (might be due to invalid IL or missing references)
		shakeX.UpdateShake();
		shakeY.UpdateShake();
		shakeRotation.UpdateShake();
		shakeTransformBack.anchoredPosition = new Vector2(shakeX.Get(), shakeY.Get());
		shakeTransformFront.anchoredPosition = new Vector2(shakeX.Get() * 2f, shakeY.Get() * 2f);
		((Transform)shakeTransformRotation).localRotation = Quaternion.Euler(0f, 0f, shakeRotation.Get());
	}

	public void Disable()
	{
		skip = true;
	}

	private void SetGraphics(int _index)
	{
		cosmeticRarity = (SemiFunc.Rarity)_index;
		for (int i = 0; i < boxGraphics.Count; i++)
		{
			if (i == _index)
			{
				boxGraphics[i].SetActive(true);
				boxGraphicsArm[i].SetActive(true);
				tokenGraphicsFront[i].SetActive(true);
				tokenGraphicsSide[i].SetActive(true);
				tokenGraphicsFrontArm[i].SetActive(true);
				tokenGraphicsSideArm[i].SetActive(true);
			}
			else
			{
				boxGraphics[i].SetActive(false);
				boxGraphicsArm[i].SetActive(false);
				tokenGraphicsFront[i].SetActive(false);
				tokenGraphicsSide[i].SetActive(false);
				tokenGraphicsFrontArm[i].SetActive(false);
				tokenGraphicsSideArm[i].SetActive(false);
			}
		}
	}

	public void AnimationEventDoorCloseStart()
	{
		//IL_000c: Unknown result type (might be due to invalid IL or missing references)
		soundTruckDoorCloseStart.Play(((Component)this).transform.position);
		shakeX.Set(2f, 0.25f);
		shakeY.Set(2f, 0.25f);
		shakeRotation.Set(2f, 0.5f);
	}

	public void AnimationEventDoorCloseStop()
	{
		//IL_000c: Unknown result type (might be due to invalid IL or missing references)
		soundTruckDoorCloseStop.Play(((Component)this).transform.position);
		shakeX.Set(3f, 0.75f);
		shakeY.Set(3f, 0.75f);
		shakeRotation.Set(2f, 1f);
	}

	public void AnimationEventArmIntro()
	{
		//IL_000c: Unknown result type (might be due to invalid IL or missing references)
		soundArmIntro.Play(((Component)this).transform.position);
	}

	public void AnimationEventArmOutro()
	{
		//IL_000c: Unknown result type (might be due to invalid IL or missing references)
		soundArmOutro.Play(((Component)this).transform.position);
	}

	public void AnimationEventArmMoveShort()
	{
		//IL_000c: Unknown result type (might be due to invalid IL or missing references)
		soundArmMoveShort.Play(((Component)this).transform.position);
	}

	public void AnimationEventArmMoveLong()
	{
		//IL_000c: Unknown result type (might be due to invalid IL or missing references)
		soundArmMoveLong.Play(((Component)this).transform.position);
	}

	public void AnimationEventBoxImpact()
	{
		//IL_000c: Unknown result type (might be due to invalid IL or missing references)
		soundBoxImpactCommon.Play(((Component)this).transform.position);
		shakeX.Set(3f, 0.75f);
		shakeY.Set(3f, 0.75f);
		shakeRotation.Set(2f, 1f);
	}

	public void AnimationEventTokenTwirl()
	{
		//IL_000c: Unknown result type (might be due to invalid IL or missing references)
		soundTokenTwirl.Play(((Component)this).transform.position);
	}

	public void AnimationEventTokenFlick()
	{
		//IL_002e: Unknown result type (might be due to invalid IL or missing references)
		//IL_005e: Unknown result type (might be due to invalid IL or missing references)
		//IL_008b: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b8: Unknown result type (might be due to invalid IL or missing references)
		switch (cosmeticRarity)
		{
		case SemiFunc.Rarity.Common:
			soundTokenFlickCommon.Play(((Component)this).transform.position);
			break;
		case SemiFunc.Rarity.Uncommon:
			soundTokenFlickUncommon.Play(((Component)this).transform.position);
			break;
		case SemiFunc.Rarity.Rare:
			soundTokenFlickRare.Play(((Component)this).transform.position);
			break;
		case SemiFunc.Rarity.UltraRare:
			soundTokenFlickUltraRare.Play(((Component)this).transform.position);
			break;
		}
		shakeX.Set(2f, 0.75f);
		shakeY.Set(2f, 0.75f);
		shakeRotation.Set(1f, 1f);
	}

	public void AnimationEventTokenParticles()
	{
		if (stateCurrent != State.FadeOut)
		{
			tokenTrailParticle.Play();
		}
	}

	public void AnimationEventCosmeticTokenAdd()
	{
		shakeX.Set(2f, 0.75f);
		shakeY.Set(2f, 0.75f);
		shakeRotation.Set(1f, 1f);
		tokenTrailParticle.Stop();
		if (RoundDirector.instance.cosmeticWorldObjectsExtracted.Count > 0 && !cosmeticIndexRewarded)
		{
			MetaManager.instance.CosmeticTokenAdd(RoundDirector.instance.cosmeticWorldObjectsExtracted[cosmeticIndex - 1]);
			cosmeticIndexRewarded = true;
		}
	}

	public void AnimationEventResetStateImpulse()
	{
		stateImpulse = true;
	}

	private void FinishResultScreen()
	{
		if (RoundDirector.instance.cosmeticWorldObjectsExtracted.Count > 0)
		{
			while (cosmeticIndex < RoundDirector.instance.cosmeticWorldObjectsExtracted.Count)
			{
				MetaManager.instance.CosmeticTokenAdd(RoundDirector.instance.cosmeticWorldObjectsExtracted[cosmeticIndex]);
				cosmeticIndex++;
			}
		}
		GameDirector.instance.currentState = GameDirector.gameState.End;
	}

	public ResultScreenUI()
	{
		//IL_0084: Unknown result type (might be due to invalid IL or missing references)
		//IL_0089: Unknown result type (might be due to invalid IL or missing references)
		//IL_008f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0094: Unknown result type (might be due to invalid IL or missing references)
	}
}
