using System;
using System.Collections.Generic;
using UnityEngine;

public class HorseLegSystem : MonoBehaviour
{
	[Serializable]
	public class HorseLeg
	{
		public Transform upperLeg;

		public Transform upperLegLookAt;

		public Transform lowerLeg;

		public Transform lowerLegLookAt;

		public Transform foot;

		internal Vector3 upperLegAimAxis;

		internal Vector3 lowerLegAimAxis;

		internal Vector3 lowerLegRestScale;

		internal float lowerLegBendSign;

		internal float restDistance;
	}

	public List<HorseLeg> legs = new List<HorseLeg>();

	public float scaleMin = 0.5f;

	public float scaleMax = 2f;

	[Tooltip("lowest the lower leg may swing from its rest pose, in degrees. raise toward 0 to stop it straightening/breaking.")]
	public float lowerLegBendMin = -170f;

	[Tooltip("furthest the lower leg may swing from its rest pose, in degrees.")]
	public float lowerLegBendMax = 170f;

	private void Start()
	{
		foreach (HorseLeg leg in legs)
		{
			LegInit(leg);
		}
		foreach (HorseLeg leg2 in legs)
		{
			LegTick(leg2);
		}
	}

	private void LateUpdate()
	{
		foreach (HorseLeg leg in legs)
		{
			LegTick(leg);
		}
	}

	private void LegInit(HorseLeg _leg)
	{
		//IL_000d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0018: Unknown result type (might be due to invalid IL or missing references)
		//IL_001d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0022: Unknown result type (might be due to invalid IL or missing references)
		//IL_0027: Unknown result type (might be due to invalid IL or missing references)
		//IL_002a: Unknown result type (might be due to invalid IL or missing references)
		//IL_002f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0041: Unknown result type (might be due to invalid IL or missing references)
		//IL_004c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0051: Unknown result type (might be due to invalid IL or missing references)
		//IL_0056: Unknown result type (might be due to invalid IL or missing references)
		//IL_005b: Unknown result type (might be due to invalid IL or missing references)
		//IL_005e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0063: Unknown result type (might be due to invalid IL or missing references)
		//IL_0070: Unknown result type (might be due to invalid IL or missing references)
		//IL_0075: Unknown result type (might be due to invalid IL or missing references)
		//IL_007a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0083: Unknown result type (might be due to invalid IL or missing references)
		//IL_0088: Unknown result type (might be due to invalid IL or missing references)
		//IL_008d: Unknown result type (might be due to invalid IL or missing references)
		//IL_008f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0090: Unknown result type (might be due to invalid IL or missing references)
		//IL_0091: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ac: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b1: Unknown result type (might be due to invalid IL or missing references)
		//IL_00bd: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c8: Unknown result type (might be due to invalid IL or missing references)
		Vector3 val = _leg.upperLeg.InverseTransformDirection(_leg.upperLegLookAt.position - _leg.upperLeg.position);
		_leg.upperLegAimAxis = val.normalized;
		val = _leg.lowerLeg.InverseTransformDirection(_leg.lowerLegLookAt.position - _leg.lowerLeg.position);
		_leg.lowerLegAimAxis = val.normalized;
		Vector3 val2 = SegmentFlatGet(_leg.upperLeg, _leg.upperLegAimAxis);
		Vector3 val3 = SegmentFlatGet(_leg.lowerLeg, _leg.lowerLegAimAxis);
		_leg.lowerLegBendSign = Mathf.Sign(Vector3.SignedAngle(val2, val3, Vector3.right));
		_leg.lowerLegRestScale = _leg.lowerLeg.localScale;
		_leg.restDistance = Vector3.Distance(_leg.lowerLeg.position, _leg.upperLegLookAt.position);
	}

	private void LegTick(HorseLeg _leg)
	{
		FootFollow(_leg);
		UpperLegLook(_leg);
		LowerLegLook(_leg);
		LowerLegScale(_leg);
	}

	private void FootFollow(HorseLeg _leg)
	{
		//IL_0011: Unknown result type (might be due to invalid IL or missing references)
		//IL_0016: Unknown result type (might be due to invalid IL or missing references)
		//IL_001b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0022: Unknown result type (might be due to invalid IL or missing references)
		//IL_0027: Unknown result type (might be due to invalid IL or missing references)
		//IL_002a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0037: Unknown result type (might be due to invalid IL or missing references)
		//IL_0048: Unknown result type (might be due to invalid IL or missing references)
		Vector3 val = _leg.lowerLeg.parent.InverseTransformPoint(_leg.foot.position);
		Vector3 localPosition = _leg.lowerLeg.localPosition;
		localPosition.y = val.y;
		localPosition.z = val.z;
		_leg.lowerLeg.localPosition = localPosition;
	}

	private void UpperLegLook(HorseLeg _leg)
	{
		//IL_0008: Unknown result type (might be due to invalid IL or missing references)
		//IL_0013: Unknown result type (might be due to invalid IL or missing references)
		float angle = HingeAngleGet(_leg.upperLeg, _leg.upperLegAimAxis, _leg.lowerLegLookAt.position);
		HingeApply(_leg.upperLeg, angle);
	}

	private void LowerLegLook(HorseLeg _leg)
	{
		//IL_0008: Unknown result type (might be due to invalid IL or missing references)
		//IL_000d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0012: Unknown result type (might be due to invalid IL or missing references)
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_0029: Unknown result type (might be due to invalid IL or missing references)
		//IL_0034: Unknown result type (might be due to invalid IL or missing references)
		//IL_0039: Unknown result type (might be due to invalid IL or missing references)
		//IL_003e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0043: Unknown result type (might be due to invalid IL or missing references)
		//IL_0048: Unknown result type (might be due to invalid IL or missing references)
		//IL_0049: Unknown result type (might be due to invalid IL or missing references)
		//IL_004a: Unknown result type (might be due to invalid IL or missing references)
		//IL_004b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0074: Unknown result type (might be due to invalid IL or missing references)
		//IL_0079: Unknown result type (might be due to invalid IL or missing references)
		//IL_007e: Unknown result type (might be due to invalid IL or missing references)
		//IL_007f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0084: Unknown result type (might be due to invalid IL or missing references)
		//IL_0087: Unknown result type (might be due to invalid IL or missing references)
		//IL_008c: Unknown result type (might be due to invalid IL or missing references)
		Vector3 val = SegmentFlatGet(_leg.upperLeg, _leg.upperLegAimAxis);
		Vector3 val2 = Vector3.ProjectOnPlane(_leg.lowerLeg.parent.InverseTransformPoint(_leg.upperLegLookAt.position) - _leg.lowerLeg.localPosition, Vector3.right);
		Vector3 targetDirection = Quaternion.AngleAxis(Mathf.Clamp(Vector3.SignedAngle(val, val2, Vector3.right) * _leg.lowerLegBendSign, lowerLegBendMin, lowerLegBendMax) * _leg.lowerLegBendSign, Vector3.right) * val;
		float angle = HingeAngleFromDirection(_leg.lowerLegAimAxis, targetDirection);
		HingeApply(_leg.lowerLeg, angle);
	}

	private Vector3 SegmentFlatGet(Transform _bone, Vector3 _aimAxisLocal)
	{
		//IL_0007: Unknown result type (might be due to invalid IL or missing references)
		//IL_0008: Unknown result type (might be due to invalid IL or missing references)
		//IL_000d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0012: Unknown result type (might be due to invalid IL or missing references)
		//IL_0017: Unknown result type (might be due to invalid IL or missing references)
		return Vector3.ProjectOnPlane(_bone.parent.InverseTransformDirection(_bone.TransformDirection(_aimAxisLocal)), Vector3.right);
	}

	private void LowerLegScale(HorseLeg _leg)
	{
		//IL_0014: Unknown result type (might be due to invalid IL or missing references)
		//IL_001f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0043: Unknown result type (might be due to invalid IL or missing references)
		//IL_0048: Unknown result type (might be due to invalid IL or missing references)
		//IL_005b: Unknown result type (might be due to invalid IL or missing references)
		if (!(_leg.restDistance <= 0f))
		{
			float num = Mathf.Clamp(Vector3.Distance(_leg.lowerLeg.position, _leg.upperLegLookAt.position) / _leg.restDistance, scaleMin, scaleMax);
			Vector3 lowerLegRestScale = _leg.lowerLegRestScale;
			lowerLegRestScale.z *= num;
			_leg.lowerLeg.localScale = lowerLegRestScale;
		}
	}

	private float HingeAngleGet(Transform _bone, Vector3 _aimAxisLocal, Vector3 _targetPosition)
	{
		//IL_0006: Unknown result type (might be due to invalid IL or missing references)
		//IL_0007: Unknown result type (might be due to invalid IL or missing references)
		//IL_000d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0012: Unknown result type (might be due to invalid IL or missing references)
		//IL_0017: Unknown result type (might be due to invalid IL or missing references)
		//IL_0019: Unknown result type (might be due to invalid IL or missing references)
		//IL_001a: Unknown result type (might be due to invalid IL or missing references)
		Vector3 targetDirection = _bone.parent.InverseTransformPoint(_targetPosition) - _bone.localPosition;
		return HingeAngleFromDirection(_aimAxisLocal, targetDirection);
	}

	private float HingeAngleFromDirection(Vector3 _aimAxisLocal, Vector3 _targetDirection)
	{
		//IL_0000: Unknown result type (might be due to invalid IL or missing references)
		//IL_0001: Unknown result type (might be due to invalid IL or missing references)
		//IL_0006: Unknown result type (might be due to invalid IL or missing references)
		//IL_000b: Unknown result type (might be due to invalid IL or missing references)
		//IL_000c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0011: Unknown result type (might be due to invalid IL or missing references)
		//IL_0016: Unknown result type (might be due to invalid IL or missing references)
		//IL_0017: Unknown result type (might be due to invalid IL or missing references)
		//IL_0018: Unknown result type (might be due to invalid IL or missing references)
		Vector3 val = Vector3.ProjectOnPlane(_aimAxisLocal, Vector3.right);
		Vector3 val2 = Vector3.ProjectOnPlane(_targetDirection, Vector3.right);
		return Vector3.SignedAngle(val, val2, Vector3.right);
	}

	private void HingeApply(Transform _bone, float _angle)
	{
		//IL_0002: Unknown result type (might be due to invalid IL or missing references)
		//IL_0007: Unknown result type (might be due to invalid IL or missing references)
		_bone.localRotation = Quaternion.AngleAxis(_angle, Vector3.right);
	}
}
