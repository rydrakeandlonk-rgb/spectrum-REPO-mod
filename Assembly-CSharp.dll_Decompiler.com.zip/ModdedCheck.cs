using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using UnityEngine;

public static class ModdedCheck
{
	public enum ModdedState
	{
		Unknown,
		Vanilla,
		Modded
	}

	[Serializable]
	public class ModData
	{
		public string modGuid;

		public string modName;

		public string modVersion;
	}

	private static ModdedState moddedState;

	private static List<ModData> modList = new List<ModData>();

	private static bool modListFetched;

	[RuntimeInitializeOnLoadMethod(/*Could not decode attribute arguments.*/)]
	private static void RuntimeInitializeOnLoad()
	{
		moddedState = ModdedState.Unknown;
		modList = new List<ModData>();
		modListFetched = false;
	}

	public static ModdedState GetModdedState(bool skipCache = false)
	{
		if (skipCache || moddedState == ModdedState.Unknown)
		{
			IsModded(skipCache);
		}
		return moddedState;
	}

	public static List<ModData> GetLoadedMods()
	{
		if (modListFetched)
		{
			return modList;
		}
		List<ModData> list = new List<ModData>();
		Assembly[] assemblies = AppDomain.CurrentDomain.GetAssemblies();
		foreach (Assembly assembly in assemblies)
		{
			if (assembly.IsDynamic)
			{
				continue;
			}
			try
			{
				object[] customAttributes = assembly.GetCustomAttributes(inherit: false);
				foreach (object obj in customAttributes)
				{
					Type type = obj.GetType();
					if (!(type.Name != "MelonInfoAttribute"))
					{
						string text = type.GetProperty("Name")?.GetValue(obj) as string;
						string modVersion = type.GetProperty("Version")?.GetValue(obj)?.ToString();
						if (!string.IsNullOrEmpty(text))
						{
							list.Add(new ModData
							{
								modGuid = text,
								modName = text,
								modVersion = modVersion
							});
						}
					}
				}
			}
			catch
			{
			}
			Type[] array;
			try
			{
				array = assembly.GetTypes();
			}
			catch (ReflectionTypeLoadException ex)
			{
				array = ex.Types.Where((Type t) => t != null).ToArray();
			}
			catch
			{
				continue;
			}
			Type[] array2 = array;
			foreach (Type type2 in array2)
			{
				object[] customAttributes2;
				try
				{
					customAttributes2 = type2.GetCustomAttributes(inherit: false);
				}
				catch
				{
					continue;
				}
				object[] customAttributes = customAttributes2;
				foreach (object obj5 in customAttributes)
				{
					try
					{
						Type type3 = obj5.GetType();
						if (type3.Name == "BepInPlugin")
						{
							string text2 = type3.GetProperty("GUID")?.GetValue(obj5) as string;
							string modName = type3.GetProperty("Name")?.GetValue(obj5) as string;
							string modVersion2 = type3.GetProperty("Version")?.GetValue(obj5)?.ToString();
							if (!string.IsNullOrEmpty(text2))
							{
								list.Add(new ModData
								{
									modGuid = text2,
									modName = modName,
									modVersion = modVersion2
								});
							}
						}
					}
					catch
					{
					}
				}
			}
		}
		list = list.OrderBy((ModData x) => x.modGuid).ToList();
		modList = list;
		modListFetched = true;
		return modList;
	}

	public static bool IsModded(bool skipCache = false)
	{
		if (!skipCache && moddedState != ModdedState.Unknown)
		{
			return moddedState == ModdedState.Modded;
		}
		if (Environment.GetEnvironmentVariable("DOORSTOP_INITIALIZED") == "TRUE")
		{
			moddedState = ModdedState.Modded;
			return true;
		}
		Assembly[] assemblies = AppDomain.CurrentDomain.GetAssemblies();
		for (int i = 0; i < assemblies.Length; i++)
		{
			string name = assemblies[i].GetName().Name;
			if (name == "MelonLoader" || name == "0Harmony")
			{
				moddedState = ModdedState.Modded;
				return true;
			}
		}
		if (GetLoadedMods().Count > 0)
		{
			moddedState = ModdedState.Modded;
			return true;
		}
		moddedState = ModdedState.Vanilla;
		return false;
	}

	internal static bool NamespaceLoaded(params string[] _namespaces)
	{
		Assembly[] assemblies = AppDomain.CurrentDomain.GetAssemblies();
		foreach (Assembly assembly in assemblies)
		{
			if (assembly.IsDynamic)
			{
				continue;
			}
			Type[] array;
			try
			{
				array = assembly.GetTypes();
			}
			catch (ReflectionTypeLoadException ex)
			{
				array = ex.Types.Where((Type t) => t != null).ToArray();
			}
			catch
			{
				continue;
			}
			Type[] array2 = array;
			for (int num = 0; num < array2.Length; num++)
			{
				string text = array2[num].Namespace;
				if (text == null)
				{
					continue;
				}
				foreach (string text2 in _namespaces)
				{
					if (text == text2 || text.StartsWith(text2 + ".", StringComparison.Ordinal))
					{
						return true;
					}
				}
			}
		}
		return false;
	}
}
