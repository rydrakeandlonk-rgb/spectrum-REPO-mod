using System;
using System.Collections.Generic;
using Photon.Pun;
using UnityEngine;

[DefaultExecutionOrder(100)]
public class SemiMounting : MonoBehaviour
{
	[Serializable]
	public class MountSeat
	{
		public Transform seatTransform;

		public Transform[] firstMountTransforms;

		public Transform grabPoint;

		public Transform visualAnchor;

		public Vector3 visualLocalOffset;

		public Vector3 visualLocalEuler;

		public float followForce = 20f;

		public float downSeatForce = 0.2f;

		public float playerMass = 1f;

		[HideInInspector]
		public PlayerAvatar seatedPlayer;

		[HideInInspector]
		public float grabbedTimer;

		[HideInInspector]
		public float takeASeatTimer;

		[NonSerialized]
		public float remountTimer;

		[NonSerialized]
		public float mountFinishTimer;

		[NonSerialized]
		public float mountSettleTimer;

		[HideInInspector]
		public bool reachedFirstMount;

		[HideInInspector]
		public bool settledAtSeat;

		[HideInInspector]
		public Transform chosenFirstMount;
	}

	public Rigidbody rb;

	public PhysGrabObject physGrabObject;

	public PhysGrabObjectGrabArea grabArea;

	public SpectateCameraCollisionIgnore spectateCameraCollisionIgnore;

	public MountSeat[] seats;

	public bool enablePlayerPhysics = true;

	public float ejectionDistance = 2f;

	public float firstMountReachDistance = 0.05f;

	public float remountDistance = 1.5f;

	public float mountUprightMaxAngle = 40f;

	public float grabRenewTime = 0.5f;

	public float takeASeatGraceTime = 1f;

	public bool onlyPlayMotorSoundWhenMoving;

	public bool meshFollowCamera;

	public Transform meshTransform;

	public float meshOffsetSmoothTime = 0.06f;

	public float meshDismountSpeed = 30f;

	public float meshTeleportDistance = 2f;

	public float meshMaxForwardOffset = 0.85f;

	internal bool anyoneSeated;

	internal bool localPlayerSeated;

	internal bool allowInputWhileMounting;

	private PhotonView photonView;

	private Transform meshOriginalParent;

	private Vector3 meshOriginalLocalPosition;

	private Quaternion meshOriginalLocalRotation;

	private bool meshDeparented;

	private int localSeatIndex = -1;

	private bool meshFollowResetPending = true;

	private Vector3 smoothedCameraOffset;

	private Vector3 smoothedCameraOffsetVelocity;

	private bool smoothedCameraOffsetInitialized;

	private float forwardClampExcess;

	private float forwardClampExcessVelocity;

	private Vector3 previousFrameOffset;

	private bool previousFrameOffsetValid;

	private Vector3[] offsetBuffer = new Vector3[12];

	private int offsetBufferIndex;

	private int offsetBufferCount;

	private Quaternion smoothedTargetRotation;

	private bool smoothedTargetRotationValid;

	private float minimumGrabTime;

	private float disableMountingTimer;

	private EnemyRigidbody enemyRigidbody;

	private const float MountImpactCooldownTime = 2f;

	private float mountImpactCooldownTimer;

	private void Awake()
	{
		//IL_0088: Unknown result type (might be due to invalid IL or missing references)
		//IL_008d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0099: Unknown result type (might be due to invalid IL or missing references)
		//IL_009e: Unknown result type (might be due to invalid IL or missing references)
		photonView = ((Component)this).GetComponent<PhotonView>();
		enemyRigidbody = ((Component)this).GetComponent<EnemyRigidbody>();
		if (!Object.op_Implicit((Object)(object)rb))
		{
			rb = ((Component)this).GetComponent<Rigidbody>();
		}
		if (!Object.op_Implicit((Object)(object)physGrabObject))
		{
			physGrabObject = ((Component)this).GetComponent<PhysGrabObject>();
		}
		if (!Object.op_Implicit((Object)(object)grabArea))
		{
			grabArea = ((Component)this).GetComponentInChildren<PhysGrabObjectGrabArea>();
		}
		if (Object.op_Implicit((Object)(object)meshTransform))
		{
			meshOriginalParent = meshTransform.parent;
			meshOriginalLocalPosition = meshTransform.localPosition;
			meshOriginalLocalRotation = meshTransform.localRotation;
		}
	}

	private void Update()
	{
		if (disableMountingTimer > 0f)
		{
			disableMountingTimer = Mathf.Max(0f, disableMountingTimer - Time.deltaTime);
		}
		MountFinishTick();
		SeatTimersTick();
		MountClaimPoll();
		SeatedPlayersUpdate();
		CacheSeatedState();
		MountImpactCooldownTick();
		MeshFollowLogic();
		SpectateCameraCollisionIgnoreLogic();
	}

	private void FixedUpdate()
	{
		ApplySeatedPlayerForces();
	}

	private void LateUpdate()
	{
		SeatedPlayerVisualsUpdate();
	}

	private void OnDisable()
	{
		SeatedPlayerGrabsRelease();
		ClearSeatsLocal();
		disableMountingTimer = 0f;
	}

	private void OnDestroy()
	{
		MeshDestroyIfDetached();
	}

	private void MountFinishTick()
	{
		//IL_015f: Unknown result type (might be due to invalid IL or missing references)
		//IL_016a: Unknown result type (might be due to invalid IL or missing references)
		//IL_017d: Unknown result type (might be due to invalid IL or missing references)
		//IL_018f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0194: Unknown result type (might be due to invalid IL or missing references)
		//IL_0199: Unknown result type (might be due to invalid IL or missing references)
		//IL_019e: Unknown result type (might be due to invalid IL or missing references)
		//IL_01b0: Unknown result type (might be due to invalid IL or missing references)
		//IL_01bb: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b9: Unknown result type (might be due to invalid IL or missing references)
		//IL_00be: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d9: Unknown result type (might be due to invalid IL or missing references)
		//IL_027b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0281: Unknown result type (might be due to invalid IL or missing references)
		MountSeat[] array = seats;
		foreach (MountSeat mountSeat in array)
		{
			PlayerAvatar seatedPlayer = mountSeat.seatedPlayer;
			if (!Object.op_Implicit((Object)(object)seatedPlayer) || mountSeat.mountFinishTimer <= 0f)
			{
				continue;
			}
			if (SemiFunc.IsMasterClientOrSingleplayer())
			{
				mountSeat.mountFinishTimer = Mathf.Max(0f, mountSeat.mountFinishTimer - Time.deltaTime);
			}
			if (mountSeat.mountFinishTimer <= 0f && SemiFunc.IsMasterClientOrSingleplayer())
			{
				if (Object.op_Implicit((Object)(object)seatedPlayer.tumble) && Object.op_Implicit((Object)(object)seatedPlayer.tumble.rb) && Object.op_Implicit((Object)(object)rb))
				{
					seatedPlayer.tumble.rb.linearVelocity = rb.GetPointVelocity(seatedPlayer.tumble.rb.position);
					seatedPlayer.tumble.rb.angularVelocity = rb.angularVelocity;
				}
				seatedPlayer.physGrabber.OverrideGrabRelease(physGrabObject.photonView.ViewID);
				ClearSeat(SeatIndexOfPlayer(seatedPlayer));
			}
			else
			{
				if (seatedPlayer.isDisabled || !MountingAllowed() || !Object.op_Implicit((Object)(object)seatedPlayer.tumble) || !Object.op_Implicit((Object)(object)seatedPlayer.tumble.rb))
				{
					continue;
				}
				PlayerTumble tumble = seatedPlayer.tumble;
				float num = Vector3.Distance(tumble.rb.position, mountSeat.seatTransform.position);
				Vector3 val = tumble.rb.linearVelocity - rb.GetPointVelocity(tumble.rb.position);
				float magnitude = val.magnitude;
				float num2 = Quaternion.Angle(tumble.rb.rotation, mountSeat.seatTransform.rotation);
				if ((mountSeat.reachedFirstMount || !SeatHasFirstMount(mountSeat)) && num <= 0.15f && magnitude <= 1f && num2 <= 15f)
				{
					mountSeat.mountSettleTimer += Time.deltaTime;
					if (mountSeat.mountSettleTimer >= 0.1f && SemiFunc.IsMasterClientOrSingleplayer())
					{
						int num3 = SeatIndexOfPlayer(seatedPlayer);
						if (SemiFunc.IsMultiplayer())
						{
							photonView.RPC("FinishSeatMountRPC", (RpcTarget)0, new object[2]
							{
								num3,
								seatedPlayer.photonView.ViewID
							});
						}
						else
						{
							FinishSeatMountRPC(num3, seatedPlayer.photonView.ViewID);
						}
						continue;
					}
				}
				else
				{
					mountSeat.mountSettleTimer = 0f;
				}
				mountSeat.grabbedTimer = Mathf.Max(mountSeat.grabbedTimer, grabRenewTime);
				mountSeat.takeASeatTimer = Mathf.Max(mountSeat.takeASeatTimer, 0.2f);
				if (seatedPlayer.isLocal)
				{
					PlayerController.instance.tumbleInputDisableTimer = Mathf.Max(PlayerController.instance.tumbleInputDisableTimer, 0.2f);
				}
			}
		}
	}

	private void SeatTimersTick()
	{
		for (int i = 0; i < seats.Length; i++)
		{
			MountSeat mountSeat = seats[i];
			if (mountSeat.remountTimer > 0f)
			{
				mountSeat.remountTimer = Mathf.Max(0f, mountSeat.remountTimer - Time.deltaTime);
			}
			if (allowInputWhileMounting && Object.op_Implicit((Object)(object)mountSeat.seatedPlayer))
			{
				PhysGrabber physGrabber = mountSeat.seatedPlayer.physGrabber;
				if (!physGrabber.grabbed || (Object)(object)physGrabber.grabbedPhysGrabObject != (Object)(object)physGrabObject)
				{
					if (SemiFunc.IsMasterClientOrSingleplayer())
					{
						ClearSeat(i);
					}
					continue;
				}
			}
			if (mountSeat.grabbedTimer > 0f)
			{
				if (SemiFunc.IsMasterClientOrSingleplayer())
				{
					mountSeat.grabbedTimer -= Time.deltaTime;
				}
			}
			else if ((Object)(object)mountSeat.seatedPlayer != (Object)null && SemiFunc.IsMasterClientOrSingleplayer())
			{
				ClearSeat(i);
			}
			if (mountSeat.takeASeatTimer > 0f)
			{
				mountSeat.takeASeatTimer -= Time.deltaTime;
			}
		}
	}

	private void MountClaimPoll()
	{
		if (!SemiFunc.IsMasterClientOrSingleplayer() || !MountingAllowed() || !Object.op_Implicit((Object)(object)grabArea))
		{
			return;
		}
		for (int i = 0; i < seats.Length; i++)
		{
			if (i >= grabArea.grabAreas.Count)
			{
				continue;
			}
			MountSeat mountSeat = seats[i];
			if ((Object)(object)mountSeat.seatedPlayer != (Object)null || mountSeat.remountTimer > 0f)
			{
				continue;
			}
			List<PhysGrabber> listOfGrabbers = grabArea.grabAreas[i].listOfGrabbers;
			if (listOfGrabbers.Count == 0)
			{
				continue;
			}
			PhysGrabber physGrabber = listOfGrabbers[listOfGrabbers.Count - 1];
			if (Object.op_Implicit((Object)(object)physGrabber) && physGrabber.grabbed && !((Object)(object)physGrabber.grabbedPhysGrabObject != (Object)(object)physGrabObject))
			{
				PlayerAvatar playerAvatar = physGrabber.playerAvatar;
				if (Object.op_Implicit((Object)(object)playerAvatar) && SeatIndexOfPlayer(playerAvatar) == -1)
				{
					SetSeatGrabber(i, playerAvatar);
				}
			}
		}
	}

	private void SeatedPlayersUpdate()
	{
		//IL_016f: Unknown result type (might be due to invalid IL or missing references)
		//IL_017a: Unknown result type (might be due to invalid IL or missing references)
		for (int i = 0; i < seats.Length; i++)
		{
			MountSeat mountSeat = seats[i];
			PlayerAvatar seatedPlayer = mountSeat.seatedPlayer;
			if (!Object.op_Implicit((Object)(object)seatedPlayer))
			{
				continue;
			}
			if (seatedPlayer.isDisabled || !MountingAllowed())
			{
				if (SemiFunc.IsMasterClientOrSingleplayer())
				{
					ClearSeat(i);
				}
				continue;
			}
			PlayerTumble tumble = seatedPlayer.tumble;
			if (!Object.op_Implicit((Object)(object)tumble))
			{
				continue;
			}
			if (seatedPlayer.physGrabber.grabbed && (Object)(object)seatedPlayer.physGrabber.grabbedPhysGrabObject == (Object)(object)physGrabObject)
			{
				mountSeat.grabbedTimer = Mathf.Max(mountSeat.grabbedTimer, grabRenewTime);
			}
			seatedPlayer.physGrabber.OverrideGrabPoint(mountSeat.grabPoint);
			seatedPlayer.playerAvatarVisuals.DisableTumbleMoveAnimation();
			tumble.OverrideDisableTumbleMoveSound(0.2f);
			if (seatedPlayer.isLocal)
			{
				tumble.OverrideTumbleUIDisable(0.2f);
				PlayerController.instance.CollisionController.OverrideDisableFallLoop(0.2f);
			}
			if (SemiFunc.IsMasterClientOrSingleplayer())
			{
				tumble.TumbleOverrideTime(0.5f);
				tumble.OverrideDisableLookAtCamera(0.5f);
				seatedPlayer.FallDamageResetSet(0.5f);
				seatedPlayer.physGrabber.OverrideGrabStrength(0f);
				seatedPlayer.physGrabber.OverrideDisableRotationControls();
				tumble.physGrabObject.OverrideIndestructible(0.5f);
				tumble.impactHurtTimer = 0f;
				if (!tumble.isTumbling && SemiFunc.PerSecond(2f, (Object)(object)this))
				{
					tumble.TumbleRequest(_isTumbling: true, _playerInput: false);
				}
			}
			if (Vector3.Distance(tumble.rb.position, mountSeat.seatTransform.position) > ejectionDistance && mountSeat.takeASeatTimer <= 0f && SemiFunc.IsMasterClientOrSingleplayer())
			{
				seatedPlayer.physGrabber.OverrideGrabRelease(physGrabObject.photonView.ViewID);
				tumble.TumbleRequest(_isTumbling: true, _playerInput: false);
				tumble.TumbleOverrideTime(0.5f);
			}
		}
	}

	private void MountImpactProtection()
	{
		if (mountImpactCooldownTimer <= 0f && Object.op_Implicit((Object)(object)physGrabObject) && Object.op_Implicit((Object)(object)physGrabObject.impactDetector))
		{
			physGrabObject.impactDetector.ImpactDisable(0.5f);
		}
		mountImpactCooldownTimer = 2f;
	}

	private void MountImpactCooldownTick()
	{
		if (anyoneSeated)
		{
			mountImpactCooldownTimer = 2f;
		}
		else if (mountImpactCooldownTimer > 0f)
		{
			mountImpactCooldownTimer = Mathf.Max(0f, mountImpactCooldownTimer - Time.deltaTime);
		}
	}

	private void CacheSeatedState()
	{
		anyoneSeated = false;
		localPlayerSeated = false;
		for (int i = 0; i < seats.Length; i++)
		{
			if (!((Object)(object)seats[i].seatedPlayer == (Object)null))
			{
				anyoneSeated = true;
				if (seats[i].seatedPlayer.isLocal)
				{
					localPlayerSeated = true;
				}
			}
		}
	}

	public void SpectateCameraCollisionIgnoreLogic()
	{
		if (!Object.op_Implicit((Object)(object)spectateCameraCollisionIgnore))
		{
			return;
		}
		bool active = false;
		MountSeat[] array = seats;
		for (int i = 0; i < array.Length; i++)
		{
			if (array[i].grabbedTimer > 0f)
			{
				active = true;
				break;
			}
		}
		spectateCameraCollisionIgnore.active = active;
	}

	private void ApplySeatedPlayerForces()
	{
		//IL_002d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0032: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d2: Unknown result type (might be due to invalid IL or missing references)
		//IL_00dd: Unknown result type (might be due to invalid IL or missing references)
		if (!enablePlayerPhysics || !MountingAllowed() || !SemiFunc.IsMasterClientOrSingleplayer() || !Object.op_Implicit((Object)(object)rb))
		{
			return;
		}
		bool hostUpright = Vector3.Angle(((Component)this).transform.up, Vector3.up) <= mountUprightMaxAngle;
		for (int i = 0; i < seats.Length; i++)
		{
			MountSeat mountSeat = seats[i];
			PlayerAvatar seatedPlayer = mountSeat.seatedPlayer;
			if (!Object.op_Implicit((Object)(object)seatedPlayer))
			{
				continue;
			}
			PlayerTumble tumble = seatedPlayer.tumble;
			if (!Object.op_Implicit((Object)(object)tumble))
			{
				continue;
			}
			tumble.physGrabObject.OverrideMaterial(SemiFunc.PhysicMaterialSlippery());
			tumble.physGrabObject.OverrideZeroGravity(0.2f);
			tumble.physGrabObject.impactDetector.ImpactDisable(0.2f);
			seatedPlayer.physGrabber.OverridePhysGrabForcesDisable(0.2f);
			float num = Vector3.Distance(tumble.rb.position, mountSeat.seatTransform.position);
			if (num > remountDistance && mountSeat.settledAtSeat && SeatHasFirstMount(mountSeat))
			{
				mountSeat.reachedFirstMount = false;
				mountSeat.settledAtSeat = false;
				mountSeat.chosenFirstMount = null;
				mountSeat.mountFinishTimer = (Object.op_Implicit((Object)(object)enemyRigidbody) ? 0f : 6f);
				mountSeat.mountSettleTimer = 0f;
			}
			if (mountSeat.reachedFirstMount || !SeatHasFirstMount(mountSeat))
			{
				LockPlayerToSeat(mountSeat, tumble);
				if (Object.op_Implicit((Object)(object)enemyRigidbody) && num < remountDistance)
				{
					mountSeat.settledAtSeat = true;
				}
			}
			else
			{
				MovePlayerTowardSeat(mountSeat, tumble, hostUpright);
			}
			tumble.physGrabObject.OverrideMass(mountSeat.playerMass);
			ApplyDownSeatForce(mountSeat, tumble);
		}
	}

	private void LockPlayerToSeat(MountSeat _seat, PlayerTumble _playerTumble)
	{
		//IL_000c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0011: Unknown result type (might be due to invalid IL or missing references)
		//IL_0016: Unknown result type (might be due to invalid IL or missing references)
		//IL_001d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0029: Unknown result type (might be due to invalid IL or missing references)
		//IL_0034: Unknown result type (might be due to invalid IL or missing references)
		//IL_0039: Unknown result type (might be due to invalid IL or missing references)
		//IL_003e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0046: Unknown result type (might be due to invalid IL or missing references)
		//IL_004b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0051: Unknown result type (might be due to invalid IL or missing references)
		//IL_005b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0060: Unknown result type (might be due to invalid IL or missing references)
		//IL_0076: Unknown result type (might be due to invalid IL or missing references)
		//IL_008c: Unknown result type (might be due to invalid IL or missing references)
		//IL_009c: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a1: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a8: Unknown result type (might be due to invalid IL or missing references)
		Vector3 pointVelocity = rb.GetPointVelocity(_playerTumble.rb.position);
		_playerTumble.rb.linearVelocity = pointVelocity;
		Vector3 val = _seat.seatTransform.position - _playerTumble.rb.position;
		Rigidbody val2 = _playerTumble.rb;
		val2.linearVelocity += val / Time.fixedDeltaTime * 0.5f;
		_playerTumble.rb.angularVelocity = rb.angularVelocity;
		Vector3 val3 = SemiFunc.PhysFollowRotation(((Component)_playerTumble).transform, _seat.seatTransform.rotation, _playerTumble.rb, 1f);
		_playerTumble.rb.AddTorque(val3, (ForceMode)1);
	}

	private void MovePlayerTowardSeat(MountSeat _seat, PlayerTumble _playerTumble, bool _hostUpright)
	{
		//IL_0029: Unknown result type (might be due to invalid IL or missing references)
		//IL_002f: Unknown result type (might be due to invalid IL or missing references)
		//IL_005b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0067: Unknown result type (might be due to invalid IL or missing references)
		//IL_006c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0071: Unknown result type (might be due to invalid IL or missing references)
		//IL_0076: Unknown result type (might be due to invalid IL or missing references)
		//IL_007d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0083: Unknown result type (might be due to invalid IL or missing references)
		//IL_0088: Unknown result type (might be due to invalid IL or missing references)
		//IL_008f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0094: Unknown result type (might be due to invalid IL or missing references)
		//IL_009c: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a4: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ae: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c0: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d0: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d5: Unknown result type (might be due to invalid IL or missing references)
		//IL_00dd: Unknown result type (might be due to invalid IL or missing references)
		Transform val = FirstMountTransformGet(_seat, _playerTumble);
		Transform val2 = _seat.seatTransform;
		if (!_seat.reachedFirstMount && (Object)(object)val != (Object)null)
		{
			val2 = val;
		}
		float num = Vector3.Distance(_playerTumble.rb.position, val2.position);
		if ((((Object)(object)val2 == (Object)(object)val) & _hostUpright) && num <= firstMountReachDistance)
		{
			_seat.reachedFirstMount = true;
		}
		Vector3 currentVelocity = _playerTumble.rb.linearVelocity - rb.GetPointVelocity(val2.position);
		Vector3 val3 = SemiFunc.PhysFollowPosition(_playerTumble.rb.position, val2.position, currentVelocity, _seat.followForce);
		_playerTumble.rb.AddForce(val3 * _seat.followForce * Time.fixedDeltaTime, (ForceMode)1);
		Vector3 val4 = SemiFunc.PhysFollowRotation(((Component)_playerTumble).transform, val2.rotation, _playerTumble.rb, 3f);
		_playerTumble.rb.AddTorque(val4, (ForceMode)1);
	}

	private void ApplyDownSeatForce(MountSeat _seat, PlayerTumble _playerTumble)
	{
		//IL_0014: Unknown result type (might be due to invalid IL or missing references)
		//IL_0019: Unknown result type (might be due to invalid IL or missing references)
		//IL_001e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0025: Unknown result type (might be due to invalid IL or missing references)
		//IL_002c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0036: Unknown result type (might be due to invalid IL or missing references)
		//IL_0047: Unknown result type (might be due to invalid IL or missing references)
		//IL_0052: Unknown result type (might be due to invalid IL or missing references)
		//IL_005c: Unknown result type (might be due to invalid IL or missing references)
		if (!(_seat.downSeatForce <= 0f))
		{
			Vector3 val = -_seat.seatTransform.up;
			_playerTumble.rb.AddForce(val * _seat.downSeatForce * 2f, (ForceMode)0);
			rb.AddForce(Vector3.up * _seat.downSeatForce * 2f, (ForceMode)0);
		}
	}

	private void SeatedPlayerVisualsUpdate()
	{
		//IL_0053: Unknown result type (might be due to invalid IL or missing references)
		//IL_0059: Unknown result type (might be due to invalid IL or missing references)
		//IL_005e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0063: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_0070: Unknown result type (might be due to invalid IL or missing references)
		//IL_0075: Unknown result type (might be due to invalid IL or missing references)
		//IL_007a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0082: Unknown result type (might be due to invalid IL or missing references)
		//IL_0084: Unknown result type (might be due to invalid IL or missing references)
		//IL_0095: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a7: Unknown result type (might be due to invalid IL or missing references)
		if (seats == null)
		{
			return;
		}
		for (int i = 0; i < seats.Length; i++)
		{
			MountSeat mountSeat = seats[i];
			PlayerAvatar seatedPlayer = mountSeat.seatedPlayer;
			if (Object.op_Implicit((Object)(object)seatedPlayer) && !seatedPlayer.isLocal && Object.op_Implicit((Object)(object)mountSeat.visualAnchor) && Object.op_Implicit((Object)(object)seatedPlayer.playerAvatarVisuals))
			{
				Quaternion val = mountSeat.visualAnchor.rotation * Quaternion.Euler(mountSeat.visualLocalEuler);
				Vector3 val2 = mountSeat.visualAnchor.TransformPoint(mountSeat.visualLocalOffset);
				seatedPlayer.playerAvatarVisuals.MountSeatVisualOverride(val2, val);
				((Component)seatedPlayer.playerAvatarVisuals).transform.position = val2;
				((Component)seatedPlayer.playerAvatarVisuals).transform.rotation = val;
			}
		}
	}

	private void MeshFollowLogic()
	{
		//IL_005b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0066: Unknown result type (might be due to invalid IL or missing references)
		if (!meshFollowCamera || !Object.op_Implicit((Object)(object)meshTransform))
		{
			if (meshDeparented)
			{
				ReparentMesh();
			}
			return;
		}
		LocalSeatIndexRefresh();
		if (localSeatIndex < 0)
		{
			MeshReturnTick(_keepDeparted: false);
			return;
		}
		MountSeat mountSeat = seats[localSeatIndex];
		PlayerAvatar seatedPlayer = mountSeat.seatedPlayer;
		if (Vector3.Distance(seatedPlayer.tumble.rb.position, mountSeat.seatTransform.position) < 2f)
		{
			MeshFollowCameraTick(seatedPlayer);
		}
		else
		{
			MeshReturnTick(_keepDeparted: true);
		}
	}

	private void LocalSeatIndexRefresh()
	{
		localSeatIndex = -1;
		for (int i = 0; i < seats.Length; i++)
		{
			if ((Object)(object)seats[i].seatedPlayer != (Object)null && seats[i].seatedPlayer.isLocal)
			{
				localSeatIndex = i;
				break;
			}
		}
	}

	private void MeshFollowCameraTick(PlayerAvatar _player)
	{
		//IL_00c3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c8: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d0: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d5: Unknown result type (might be due to invalid IL or missing references)
		//IL_00da: Unknown result type (might be due to invalid IL or missing references)
		//IL_00db: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e0: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e1: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e6: Unknown result type (might be due to invalid IL or missing references)
		//IL_00fa: Unknown result type (might be due to invalid IL or missing references)
		//IL_00fb: Unknown result type (might be due to invalid IL or missing references)
		//IL_0020: Unknown result type (might be due to invalid IL or missing references)
		//IL_0025: Unknown result type (might be due to invalid IL or missing references)
		//IL_002a: Unknown result type (might be due to invalid IL or missing references)
		//IL_002d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0032: Unknown result type (might be due to invalid IL or missing references)
		//IL_003a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0047: Unknown result type (might be due to invalid IL or missing references)
		//IL_004f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0054: Unknown result type (might be due to invalid IL or missing references)
		//IL_005a: Unknown result type (might be due to invalid IL or missing references)
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0082: Unknown result type (might be due to invalid IL or missing references)
		//IL_0087: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a2: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a4: Unknown result type (might be due to invalid IL or missing references)
		//IL_015e: Unknown result type (might be due to invalid IL or missing references)
		//IL_015f: Unknown result type (might be due to invalid IL or missing references)
		//IL_014b: Unknown result type (might be due to invalid IL or missing references)
		//IL_014c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0153: Unknown result type (might be due to invalid IL or missing references)
		//IL_0158: Unknown result type (might be due to invalid IL or missing references)
		//IL_015d: Unknown result type (might be due to invalid IL or missing references)
		//IL_01cf: Unknown result type (might be due to invalid IL or missing references)
		//IL_01d4: Unknown result type (might be due to invalid IL or missing references)
		//IL_01d7: Unknown result type (might be due to invalid IL or missing references)
		//IL_01dc: Unknown result type (might be due to invalid IL or missing references)
		//IL_01de: Unknown result type (might be due to invalid IL or missing references)
		//IL_01e1: Unknown result type (might be due to invalid IL or missing references)
		//IL_01e6: Unknown result type (might be due to invalid IL or missing references)
		//IL_01eb: Unknown result type (might be due to invalid IL or missing references)
		//IL_016a: Unknown result type (might be due to invalid IL or missing references)
		//IL_016b: Unknown result type (might be due to invalid IL or missing references)
		//IL_021e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0220: Unknown result type (might be due to invalid IL or missing references)
		//IL_0232: Unknown result type (might be due to invalid IL or missing references)
		//IL_0237: Unknown result type (might be due to invalid IL or missing references)
		//IL_0203: Unknown result type (might be due to invalid IL or missing references)
		//IL_020a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0211: Unknown result type (might be due to invalid IL or missing references)
		//IL_0216: Unknown result type (might be due to invalid IL or missing references)
		//IL_021b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0271: Unknown result type (might be due to invalid IL or missing references)
		//IL_0276: Unknown result type (might be due to invalid IL or missing references)
		//IL_0184: Unknown result type (might be due to invalid IL or missing references)
		//IL_0185: Unknown result type (might be due to invalid IL or missing references)
		//IL_02b9: Unknown result type (might be due to invalid IL or missing references)
		//IL_02be: Unknown result type (might be due to invalid IL or missing references)
		//IL_02bf: Unknown result type (might be due to invalid IL or missing references)
		//IL_02c1: Unknown result type (might be due to invalid IL or missing references)
		//IL_027d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0287: Unknown result type (might be due to invalid IL or missing references)
		//IL_028c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0291: Unknown result type (might be due to invalid IL or missing references)
		//IL_02a3: Unknown result type (might be due to invalid IL or missing references)
		//IL_02ac: Unknown result type (might be due to invalid IL or missing references)
		//IL_02b1: Unknown result type (might be due to invalid IL or missing references)
		//IL_02d7: Unknown result type (might be due to invalid IL or missing references)
		//IL_02d9: Unknown result type (might be due to invalid IL or missing references)
		//IL_02df: Unknown result type (might be due to invalid IL or missing references)
		//IL_02e4: Unknown result type (might be due to invalid IL or missing references)
		//IL_0300: Unknown result type (might be due to invalid IL or missing references)
		//IL_0301: Unknown result type (might be due to invalid IL or missing references)
		//IL_038a: Unknown result type (might be due to invalid IL or missing references)
		//IL_038f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0394: Unknown result type (might be due to invalid IL or missing references)
		//IL_0363: Unknown result type (might be due to invalid IL or missing references)
		//IL_0365: Unknown result type (might be due to invalid IL or missing references)
		//IL_036b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0370: Unknown result type (might be due to invalid IL or missing references)
		//IL_03ca: Unknown result type (might be due to invalid IL or missing references)
		//IL_03cf: Unknown result type (might be due to invalid IL or missing references)
		//IL_04e0: Unknown result type (might be due to invalid IL or missing references)
		//IL_04e2: Unknown result type (might be due to invalid IL or missing references)
		//IL_04e7: Unknown result type (might be due to invalid IL or missing references)
		//IL_04ec: Unknown result type (might be due to invalid IL or missing references)
		//IL_04ee: Unknown result type (might be due to invalid IL or missing references)
		//IL_04f0: Unknown result type (might be due to invalid IL or missing references)
		//IL_04f1: Unknown result type (might be due to invalid IL or missing references)
		//IL_04f6: Unknown result type (might be due to invalid IL or missing references)
		//IL_0313: Unknown result type (might be due to invalid IL or missing references)
		//IL_0314: Unknown result type (might be due to invalid IL or missing references)
		//IL_0342: Unknown result type (might be due to invalid IL or missing references)
		//IL_0347: Unknown result type (might be due to invalid IL or missing references)
		//IL_0400: Unknown result type (might be due to invalid IL or missing references)
		//IL_0405: Unknown result type (might be due to invalid IL or missing references)
		//IL_0419: Unknown result type (might be due to invalid IL or missing references)
		//IL_041e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0423: Unknown result type (might be due to invalid IL or missing references)
		//IL_0426: Unknown result type (might be due to invalid IL or missing references)
		//IL_042b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0430: Unknown result type (might be due to invalid IL or missing references)
		//IL_0521: Unknown result type (might be due to invalid IL or missing references)
		//IL_0526: Unknown result type (might be due to invalid IL or missing references)
		//IL_0508: Unknown result type (might be due to invalid IL or missing references)
		//IL_050a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0514: Unknown result type (might be due to invalid IL or missing references)
		//IL_0519: Unknown result type (might be due to invalid IL or missing references)
		//IL_051e: Unknown result type (might be due to invalid IL or missing references)
		//IL_04c3: Unknown result type (might be due to invalid IL or missing references)
		//IL_04d6: Unknown result type (might be due to invalid IL or missing references)
		//IL_04db: Unknown result type (might be due to invalid IL or missing references)
		//IL_0442: Unknown result type (might be due to invalid IL or missing references)
		//IL_0447: Unknown result type (might be due to invalid IL or missing references)
		//IL_044a: Unknown result type (might be due to invalid IL or missing references)
		//IL_044f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0459: Unknown result type (might be due to invalid IL or missing references)
		//IL_0460: Unknown result type (might be due to invalid IL or missing references)
		//IL_0462: Unknown result type (might be due to invalid IL or missing references)
		//IL_0467: Unknown result type (might be due to invalid IL or missing references)
		//IL_046c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0489: Unknown result type (might be due to invalid IL or missing references)
		//IL_048b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0490: Unknown result type (might be due to invalid IL or missing references)
		//IL_049a: Unknown result type (might be due to invalid IL or missing references)
		//IL_049f: Unknown result type (might be due to invalid IL or missing references)
		//IL_04a4: Unknown result type (might be due to invalid IL or missing references)
		//IL_055b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0560: Unknown result type (might be due to invalid IL or missing references)
		//IL_0564: Unknown result type (might be due to invalid IL or missing references)
		//IL_0569: Unknown result type (might be due to invalid IL or missing references)
		//IL_0531: Unknown result type (might be due to invalid IL or missing references)
		//IL_0533: Unknown result type (might be due to invalid IL or missing references)
		//IL_0574: Unknown result type (might be due to invalid IL or missing references)
		//IL_0579: Unknown result type (might be due to invalid IL or missing references)
		//IL_057d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0588: Unknown result type (might be due to invalid IL or missing references)
		//IL_058d: Unknown result type (might be due to invalid IL or missing references)
		//IL_05a7: Unknown result type (might be due to invalid IL or missing references)
		//IL_05ad: Unknown result type (might be due to invalid IL or missing references)
		//IL_05bd: Unknown result type (might be due to invalid IL or missing references)
		//IL_05c3: Unknown result type (might be due to invalid IL or missing references)
		//IL_05d8: Unknown result type (might be due to invalid IL or missing references)
		//IL_05ee: Unknown result type (might be due to invalid IL or missing references)
		//IL_0601: Unknown result type (might be due to invalid IL or missing references)
		if (!meshDeparented)
		{
			DeparentMesh();
		}
		if (meshFollowResetPending)
		{
			Vector3 position = meshOriginalParent.TransformPoint(meshOriginalLocalPosition);
			Quaternion rotation = MeshRestRotation();
			meshTransform.position = position;
			meshTransform.rotation = rotation;
			smoothedCameraOffset = Vector3.zero;
			smoothedCameraOffsetVelocity = Vector3.zero;
			smoothedCameraOffsetInitialized = false;
			forwardClampExcess = 0f;
			forwardClampExcessVelocity = 0f;
			previousFrameOffset = Vector3.zero;
			previousFrameOffsetValid = false;
			offsetBufferCount = 0;
			offsetBufferIndex = 0;
			smoothedTargetRotation = rotation;
			smoothedTargetRotationValid = false;
			meshFollowResetPending = false;
		}
		Transform overrideTransform = _player.localCamera.GetOverrideTransform();
		Vector3 position2 = overrideTransform.position;
		Vector3 val = meshOriginalParent.TransformPoint(meshOriginalLocalPosition) - position2;
		Vector3 forward = overrideTransform.forward;
		forward.y = 0f;
		forward.Normalize();
		float num = Vector3.Dot(val, forward);
		float num2 = Mathf.Max(0f, num - meshMaxForwardOffset);
		forwardClampExcess = Mathf.SmoothDamp(forwardClampExcess, num2, ref forwardClampExcessVelocity, 0.02f, float.PositiveInfinity, Time.smoothDeltaTime);
		if (forwardClampExcess > 0.001f)
		{
			val -= forward * forwardClampExcess;
		}
		Vector3 val2 = val;
		if (!previousFrameOffsetValid)
		{
			previousFrameOffset = val;
			previousFrameOffsetValid = true;
			for (int i = 0; i < offsetBuffer.Length; i++)
			{
				offsetBuffer[i] = val;
			}
			offsetBufferCount = offsetBuffer.Length;
			offsetBufferIndex = 0;
		}
		else
		{
			float num3 = 1f - Mathf.Exp(-60f * Time.smoothDeltaTime);
			Vector3 val3 = Vector3.Lerp(previousFrameOffset, val, num3);
			Vector3 val4 = val3 - previousFrameOffset;
			float num4 = 0.15f;
			if (val4.sqrMagnitude > num4 * num4)
			{
				val3 = previousFrameOffset + val4.normalized * num4;
			}
			previousFrameOffset = val3;
			offsetBuffer[offsetBufferIndex] = previousFrameOffset;
			offsetBufferIndex = (offsetBufferIndex + 1) % offsetBuffer.Length;
			if (offsetBufferCount < offsetBuffer.Length)
			{
				offsetBufferCount++;
			}
			Vector3 val5 = Vector3.zero;
			for (int j = 0; j < offsetBufferCount; j++)
			{
				val5 += offsetBuffer[j];
			}
			val2 = val5 / (float)offsetBufferCount;
		}
		if (Vector3.Distance(meshTransform.position, position2 + val2) > meshTeleportDistance)
		{
			smoothedCameraOffset = val2;
			smoothedCameraOffsetVelocity = Vector3.zero;
			forwardClampExcess = 0f;
			forwardClampExcessVelocity = 0f;
			previousFrameOffset = val;
			for (int k = 0; k < offsetBuffer.Length; k++)
			{
				offsetBuffer[k] = val;
			}
			offsetBufferCount = offsetBuffer.Length;
			offsetBufferIndex = 0;
			smoothedTargetRotation = MeshRestRotation();
			smoothedTargetRotationValid = true;
			smoothedCameraOffsetInitialized = true;
		}
		if (!smoothedCameraOffsetInitialized)
		{
			smoothedCameraOffset = val2;
			smoothedCameraOffsetVelocity = Vector3.zero;
			smoothedCameraOffsetInitialized = true;
		}
		else
		{
			float num5 = meshOffsetSmoothTime;
			float num6 = Mathf.Clamp01(Mathf.Abs((MeshRestRotation() * Vector3.forward).y) / 0.7f);
			float num7;
			if (!Object.op_Implicit((Object)(object)rb))
			{
				num7 = 0f;
			}
			else
			{
				Vector3 linearVelocity = rb.linearVelocity;
				num7 = Mathf.Clamp01(linearVelocity.magnitude / 10f);
			}
			float num8 = num7;
			num5 = Mathf.Lerp(num5, Time.smoothDeltaTime * 2f, num6 * num8);
			smoothedCameraOffset = Vector3.SmoothDamp(smoothedCameraOffset, val2, ref smoothedCameraOffsetVelocity, num5, float.PositiveInfinity, Time.smoothDeltaTime);
			Vector3 val6 = val2 - smoothedCameraOffset;
			if (val6.sqrMagnitude > 0.0001f)
			{
				Vector3 normalized = val6.normalized;
				float num9 = Vector3.Dot(smoothedCameraOffsetVelocity, normalized);
				Vector3 val7 = smoothedCameraOffsetVelocity - num9 * normalized;
				float num10 = 1f - Mathf.Exp(-8f * Time.smoothDeltaTime);
				smoothedCameraOffsetVelocity = num9 * normalized + val7 * (1f - num10);
			}
			float num11 = 1f - Mathf.Exp(-4f * Time.smoothDeltaTime);
			smoothedCameraOffsetVelocity *= 1f - num11 * 0.3f;
		}
		Vector3 val8 = position2 + smoothedCameraOffset;
		float num12 = Vector3.Dot(val8 - position2, forward);
		if (num12 > meshMaxForwardOffset)
		{
			val8 -= forward * (num12 - meshMaxForwardOffset);
		}
		Quaternion val9 = MeshRestRotation();
		if (!smoothedTargetRotationValid)
		{
			smoothedTargetRotation = val9;
			smoothedTargetRotationValid = true;
		}
		else
		{
			float num13 = 1f - Mathf.Exp(-15f * Time.smoothDeltaTime);
			smoothedTargetRotation = Quaternion.Slerp(smoothedTargetRotation, val9, num13);
		}
		Quaternion rotation2 = meshTransform.rotation;
		Vector3 eulerAngles = rotation2.eulerAngles;
		Vector3 eulerAngles2 = smoothedTargetRotation.eulerAngles;
		float num14 = 1f - Mathf.Exp(-120f * Time.smoothDeltaTime);
		float num15 = Mathf.LerpAngle(eulerAngles.x, eulerAngles2.x, num14);
		float num16 = Mathf.LerpAngle(eulerAngles.y, eulerAngles2.y, num14);
		float num17 = Mathf.LerpAngle(eulerAngles.z, eulerAngles2.z, num14);
		meshTransform.position = val8;
		meshTransform.rotation = Quaternion.Euler(num15, num16, num17);
	}

	private void MeshReturnTick(bool _keepDeparted)
	{
		//IL_003d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0042: Unknown result type (might be due to invalid IL or missing references)
		//IL_0047: Unknown result type (might be due to invalid IL or missing references)
		//IL_004e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0054: Unknown result type (might be due to invalid IL or missing references)
		//IL_0059: Unknown result type (might be due to invalid IL or missing references)
		//IL_005e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0065: Unknown result type (might be due to invalid IL or missing references)
		//IL_006a: Unknown result type (might be due to invalid IL or missing references)
		//IL_007d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0082: Unknown result type (might be due to invalid IL or missing references)
		//IL_009b: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b1: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b6: Unknown result type (might be due to invalid IL or missing references)
		//IL_00cd: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e0: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e5: Unknown result type (might be due to invalid IL or missing references)
		smoothedCameraOffsetInitialized = false;
		previousFrameOffsetValid = false;
		smoothedTargetRotationValid = false;
		meshFollowResetPending = true;
		if (_keepDeparted && !meshDeparented)
		{
			DeparentMesh();
		}
		if (!meshDeparented)
		{
			return;
		}
		Vector3 val = meshOriginalParent.TransformPoint(meshOriginalLocalPosition);
		Quaternion val2 = meshOriginalParent.rotation * meshOriginalLocalRotation;
		float num = Vector3.Distance(meshTransform.position, val);
		meshTransform.position = Vector3.Lerp(meshTransform.position, val, 1f - Mathf.Exp((0f - meshDismountSpeed) * Time.deltaTime));
		meshTransform.rotation = Quaternion.Slerp(meshTransform.rotation, val2, 1f - Mathf.Exp(-5f * Time.deltaTime));
		if (!_keepDeparted)
		{
			float num2 = Quaternion.Angle(meshTransform.rotation, val2);
			if (num < 0.01f && num2 < 1f)
			{
				ReparentMesh();
			}
		}
	}

	private Quaternion MeshRestRotation()
	{
		//IL_0006: Unknown result type (might be due to invalid IL or missing references)
		//IL_000c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0011: Unknown result type (might be due to invalid IL or missing references)
		return meshOriginalParent.rotation * meshOriginalLocalRotation;
	}

	private void MeshDestroyIfDetached()
	{
		if (meshDeparented && Object.op_Implicit((Object)(object)meshTransform))
		{
			Object.Destroy((Object)(object)((Component)meshTransform).gameObject);
		}
	}

	private void DeparentMesh()
	{
		if (Object.op_Implicit((Object)(object)meshTransform) && !meshDeparented)
		{
			meshTransform.SetParent((Transform)null, true);
			meshDeparented = true;
		}
	}

	private void ReparentMesh()
	{
		//IL_002f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0040: Unknown result type (might be due to invalid IL or missing references)
		if (Object.op_Implicit((Object)(object)meshTransform) && meshDeparented)
		{
			meshTransform.SetParent(meshOriginalParent, true);
			meshTransform.localPosition = meshOriginalLocalPosition;
			meshTransform.localRotation = meshOriginalLocalRotation;
			meshDeparented = false;
		}
	}

	public bool MotorSoundCanPlay()
	{
		//IL_000b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0010: Unknown result type (might be due to invalid IL or missing references)
		if (!onlyPlayMotorSoundWhenMoving)
		{
			return true;
		}
		Vector3 val = VelocityGet();
		val.y = 0f;
		return val.sqrMagnitude > 0.01f;
	}

	public Vector3 VelocityGet()
	{
		//IL_0019: Unknown result type (might be due to invalid IL or missing references)
		//IL_000d: Unknown result type (might be due to invalid IL or missing references)
		if (SemiFunc.IsMasterClientOrSingleplayer())
		{
			return rb.linearVelocity;
		}
		return physGrabObject.rbVelocity;
	}

	public bool AnyoneSeated()
	{
		return anyoneSeated;
	}

	public bool LocalPlayerSeated()
	{
		return localPlayerSeated;
	}

	public PlayerAvatar GetSeatedPlayer(int _seatIndex)
	{
		if (_seatIndex < 0 || _seatIndex >= seats.Length)
		{
			return null;
		}
		return seats[_seatIndex].seatedPlayer;
	}

	public bool SeatFullyMounted(int _seatIndex)
	{
		if (_seatIndex < 0 || _seatIndex >= seats.Length)
		{
			return false;
		}
		MountSeat mountSeat = seats[_seatIndex];
		if ((Object)(object)mountSeat.seatedPlayer == (Object)null)
		{
			return false;
		}
		if (!Object.op_Implicit((Object)(object)enemyRigidbody))
		{
			return mountSeat.settledAtSeat;
		}
		if (!mountSeat.reachedFirstMount)
		{
			return !SeatHasFirstMount(mountSeat);
		}
		return true;
	}

	internal bool VehicleGrabActive(PlayerAvatar player)
	{
		if (MountingAllowed() && Object.op_Implicit((Object)(object)player) && !player.isDisabled)
		{
			return SeatIndexOfPlayer(player) >= 0;
		}
		return false;
	}

	internal bool MountingLocksInput(PlayerAvatar player)
	{
		if (allowInputWhileMounting)
		{
			return false;
		}
		int num = SeatIndexOfPlayer(player);
		if (num < 0 || !MountingAllowed() || !Object.op_Implicit((Object)(object)player) || player.isDisabled)
		{
			return false;
		}
		if (seats[num].mountFinishTimer > 0f)
		{
			return !seats[num].settledAtSeat;
		}
		return false;
	}

	private bool SeatHasFirstMount(MountSeat _seat)
	{
		if (_seat.firstMountTransforms != null)
		{
			return _seat.firstMountTransforms.Length != 0;
		}
		return false;
	}

	private Transform FirstMountTransformGet(MountSeat _seat, PlayerTumble _playerTumble)
	{
		//IL_0043: Unknown result type (might be due to invalid IL or missing references)
		//IL_0049: Unknown result type (might be due to invalid IL or missing references)
		if (!SeatHasFirstMount(_seat))
		{
			return null;
		}
		if ((Object)(object)_seat.chosenFirstMount != (Object)null)
		{
			return _seat.chosenFirstMount;
		}
		Transform val = null;
		float num = float.PositiveInfinity;
		for (int i = 0; i < _seat.firstMountTransforms.Length; i++)
		{
			Transform val2 = _seat.firstMountTransforms[i];
			if (Object.op_Implicit((Object)(object)val2))
			{
				float num2 = Vector3.Distance(_playerTumble.rb.position, val2.position);
				if (num2 < num)
				{
					num = num2;
					val = val2;
				}
			}
		}
		_seat.chosenFirstMount = val;
		return val;
	}

	public PlayerAvatar Driver()
	{
		return GetSeatedPlayer(0);
	}

	private int SeatIndexOfPlayer(PlayerAvatar _player)
	{
		for (int i = 0; i < seats.Length; i++)
		{
			if ((Object)(object)seats[i].seatedPlayer == (Object)(object)_player)
			{
				return i;
			}
		}
		return -1;
	}

	public void ForceMount(int _seatIndex, PlayerAvatar _player)
	{
		if (SemiFunc.IsMasterClientOrSingleplayer() && MountingAllowed() && Object.op_Implicit((Object)(object)_player) && _seatIndex >= 0 && _seatIndex < seats.Length && !((Object)(object)seats[_seatIndex].seatedPlayer == (Object)(object)_player))
		{
			if (SemiFunc.IsMultiplayer())
			{
				photonView.RPC("SetSeatGrabberRPC", (RpcTarget)0, new object[2]
				{
					_seatIndex,
					_player.photonView.ViewID
				});
			}
			else
			{
				SetSeatGrabber(_seatIndex, _player);
			}
		}
	}

	public void DismountSeat(int _seatIndex)
	{
		if (_seatIndex >= 0 && _seatIndex < seats.Length && SemiFunc.IsMasterClientOrSingleplayer())
		{
			ClearSeat(_seatIndex);
		}
	}

	public void OverrideDisableMounting(float _time = 0.1f)
	{
		disableMountingTimer = Mathf.Max(disableMountingTimer, _time);
	}

	internal bool MountingAllowed()
	{
		if (!((Behaviour)this).isActiveAndEnabled || disableMountingTimer > 0f)
		{
			return false;
		}
		if (Object.op_Implicit((Object)(object)enemyRigidbody) && Object.op_Implicit((Object)(object)enemyRigidbody.enemy))
		{
			return !enemyRigidbody.enemy.IsStunned();
		}
		return true;
	}

	public void MinimumGrabTimeSet(float _time)
	{
		minimumGrabTime = Mathf.Max(0f, _time);
	}

	private void SetSeatGrabber(int _seatIndex, PlayerAvatar _playerAvatar)
	{
		if (SemiFunc.IsMasterClientOrSingleplayer() && MountingAllowed())
		{
			if (SemiFunc.IsMultiplayer())
			{
				photonView.RPC("SetSeatGrabberRPC", (RpcTarget)0, new object[2]
				{
					_seatIndex,
					_playerAvatar.photonView.ViewID
				});
			}
			else
			{
				SetSeatGrabberLocal(_seatIndex, _playerAvatar);
			}
		}
	}

	private void SetSeatGrabberLocal(int _seatIndex, PlayerAvatar _playerAvatar)
	{
		if (MountingAllowed() && _seatIndex >= 0 && _seatIndex < seats.Length)
		{
			MountSeat obj = seats[_seatIndex];
			obj.seatedPlayer = _playerAvatar;
			obj.reachedFirstMount = false;
			obj.settledAtSeat = false;
			obj.chosenFirstMount = null;
			obj.mountFinishTimer = (Object.op_Implicit((Object)(object)enemyRigidbody) ? 0f : 6f);
			obj.mountSettleTimer = 0f;
			obj.grabbedTimer = Mathf.Max(grabRenewTime, minimumGrabTime);
			obj.takeASeatTimer = Mathf.Max(takeASeatGraceTime, minimumGrabTime);
			if (_playerAvatar.isLocal && Object.op_Implicit((Object)(object)_playerAvatar.physGrabber) && Object.op_Implicit((Object)(object)physGrabObject) && minimumGrabTime > 0f)
			{
				_playerAvatar.physGrabber.OverrideMinimumGrabTime(physGrabObject, minimumGrabTime);
			}
			if (Object.op_Implicit((Object)(object)enemyRigidbody))
			{
				enemyRigidbody.OverrideMountedGrab();
			}
			if (SemiFunc.IsMasterClientOrSingleplayer() || _playerAvatar.isLocal)
			{
				_playerAvatar.tumble.TumbleRequest(_isTumbling: true, _playerInput: false);
			}
			if (_playerAvatar.isLocal)
			{
				PlayerController.instance.tumbleInputDisableTimer = 1f;
			}
			_playerAvatar.tumble.physGrabObject.impactDetector.ImpactDisable(0.5f);
			MountImpactProtection();
		}
	}

	private void ClearSeat(int _seatIndex)
	{
		if (SemiFunc.IsMultiplayer())
		{
			photonView.RPC("ClearSeatRPC", (RpcTarget)0, new object[1] { _seatIndex });
		}
		else
		{
			ClearSeatLocal(_seatIndex);
		}
	}

	private void ClearSeatLocal(int _seatIndex)
	{
		if (_seatIndex >= 0 && _seatIndex < seats.Length)
		{
			MountSeat obj = seats[_seatIndex];
			PlayerAvatar seatedPlayer = obj.seatedPlayer;
			if (Object.op_Implicit((Object)(object)seatedPlayer) && seatedPlayer.isLocal && Object.op_Implicit((Object)(object)seatedPlayer.physGrabber) && Object.op_Implicit((Object)(object)physGrabObject))
			{
				seatedPlayer.physGrabber.OverrideMinimumGrabTime(physGrabObject, 0f);
			}
			if (Object.op_Implicit((Object)(object)seatedPlayer))
			{
				seatedPlayer.playerAvatarVisuals.MountSeatVisualClear();
			}
			obj.seatedPlayer = null;
			obj.reachedFirstMount = false;
			obj.settledAtSeat = false;
			obj.chosenFirstMount = null;
			obj.grabbedTimer = 0f;
			obj.takeASeatTimer = 0f;
			obj.remountTimer = 0.5f;
			obj.mountFinishTimer = 0f;
			obj.mountSettleTimer = 0f;
		}
	}

	private void ClearSeatsLocal()
	{
		if (seats != null)
		{
			for (int i = 0; i < seats.Length; i++)
			{
				ClearSeatLocal(i);
			}
		}
	}

	private void SeatedPlayerGrabsRelease()
	{
		if (!SemiFunc.IsMasterClientOrSingleplayer() || seats == null || !Object.op_Implicit((Object)(object)physGrabObject) || !Object.op_Implicit((Object)(object)physGrabObject.photonView))
		{
			return;
		}
		for (int i = 0; i < seats.Length; i++)
		{
			PlayerAvatar seatedPlayer = seats[i].seatedPlayer;
			if (Object.op_Implicit((Object)(object)seatedPlayer) && Object.op_Implicit((Object)(object)seatedPlayer.physGrabber))
			{
				seatedPlayer.physGrabber.OverrideGrabRelease(physGrabObject.photonView.ViewID);
			}
		}
	}

	[PunRPC]
	private void SetSeatGrabberRPC(int _seatIndex, int _playerAvatarPhotonID, PhotonMessageInfo _info = default(PhotonMessageInfo))
	{
		//IL_0000: Unknown result type (might be due to invalid IL or missing references)
		if (SemiFunc.MasterOnlyRPC(_info))
		{
			PlayerAvatar playerAvatar = SemiFunc.PlayerAvatarGetFromPhotonID(_playerAvatarPhotonID);
			if (Object.op_Implicit((Object)(object)playerAvatar))
			{
				SetSeatGrabberLocal(_seatIndex, playerAvatar);
			}
		}
	}

	[PunRPC]
	private void FinishSeatMountRPC(int seatIndex, int playerPhotonID, PhotonMessageInfo info = default(PhotonMessageInfo))
	{
		//IL_0000: Unknown result type (might be due to invalid IL or missing references)
		if (SemiFunc.MasterOnlyRPC(info) && seatIndex >= 0 && seatIndex < seats.Length)
		{
			MountSeat mountSeat = seats[seatIndex];
			if (Object.op_Implicit((Object)(object)mountSeat.seatedPlayer) && mountSeat.seatedPlayer.photonView.ViewID == playerPhotonID)
			{
				mountSeat.settledAtSeat = true;
				mountSeat.mountFinishTimer = 0f;
			}
		}
	}

	[PunRPC]
	private void ClearSeatRPC(int _seatIndex, PhotonMessageInfo _info = default(PhotonMessageInfo))
	{
		//IL_0000: Unknown result type (might be due to invalid IL or missing references)
		if (SemiFunc.MasterOnlyRPC(_info))
		{
			ClearSeatLocal(_seatIndex);
		}
	}
}
