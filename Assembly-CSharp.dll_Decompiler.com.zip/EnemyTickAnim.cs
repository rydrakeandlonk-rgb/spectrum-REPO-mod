using System;
using System.Collections.Generic;
using UnityEngine;

public class EnemyTickAnim : MonoBehaviour
{
	[Serializable]
	public class springLimb
	{
		public SpringQuaternion spring;

		public string name;

		public Transform transform;

		public Transform target;

		public bool steeringLeg;

		[HideInInspector]
		public Quaternion originalQuaternion;

		public float sineEval;
	}

	[Serializable]
	public class springBloatPart
	{
		public SpringVector3 spring;

		public string name;

		public Transform transform;

		public Transform target;

		[HideInInspector]
		public Vector3 originalScale;

		public float sineEval;
	}

	public Enemy enemy;

	public EnemyTick controller;

	internal Materials.MaterialTrigger material = new Materials.MaterialTrigger();

	public GameObject mouth;

	private float mouthLerp;

	private float mouthLerpSpeed = 1f;

	private float mouthLerpIntensity = 0.5f;

	public GameObject lipsClosed;

	public GameObject lipsOpen;

	public bool lipsState;

	public GameObject flatHead;

	public GameObject bloatedHead;

	private bool flatHeadSwitch;

	private Vector3 bloatPartsOrginalScale;

	[Space]
	public ParticleSystem particleImpact;

	public ParticleSystem particleBits;

	public ParticleSystem particleDirectionalBits;

	public List<ParticleSystem> failedHealParticles;

	[Space]
	[Header("Sounds")]
	public Sound skitteringLoop;

	public Sound walkLoop;

	public Sound runLoop;

	public Sound suckLoop;

	public Sound hurtSound;

	public Sound deathSound;

	public Sound bigSuckSound;

	public Sound jumpSound;

	public Sound noticeSound;

	public Sound detachSound;

	private bool walkLoopPlaying;

	private bool runLoopPlaying;

	private bool jumpImpulse;

	public List<springLimb> springLimbs = new List<springLimb>();

	public List<springBloatPart> springBloatParts = new List<springBloatPart>();

	private SpringQuaternion jumpRight = new SpringQuaternion();

	public Transform jumpTransformRight;

	public Transform jumpTransformTargetRight;

	private SpringQuaternion springJumpLeft = new SpringQuaternion();

	public Transform jumpTransformLeft;

	public Transform jumpTransformTargetLeft;

	private SpringQuaternion springBody = new SpringQuaternion();

	public Transform bodyTransform;

	public Transform bodyTransformTarget;

	public SpringVector3 springHead = new SpringVector3();

	public Transform headTransform;

	public Transform headTransformTarget;

	private float overrideWalkAnimationTimer;

	private bool isWalking;

	private bool wasGrounded;

	private float materialImpactTimer;

	private float bodyAnimationEvalX;

	private float bodyAnimationEvalY;

	private float bodyAnimationEvalZ;

	public AnimationCurve BodyAnimationCurve;

	private float maxScaleBloatParts = 1.3f;

	private Vector3 lastPosition;

	private float janneksVelocity;

	public int maxHealth = 100;

	private int lastSyncedHealth;

	public bool hasBeenFull;

	private EnemyTick.State prevState;

	[Space]
	[Header("Driving Pose")]
	public Vector3 drivingTuckEuler = new Vector3(0f, 0f, 70f);

	public Vector3 drivingArmAimOffsetEuler = Vector3.zero;

	public float drivingPoseBlendSpeed = 6f;

	private float drivingPoseBlend;

	private void Awake()
	{
		//IL_0012: Unknown result type (might be due to invalid IL or missing references)
		//IL_0017: Unknown result type (might be due to invalid IL or missing references)
		bloatPartsOrginalScale = springBloatParts[0].transform.localScale;
	}

	private void Update()
	{
		//IL_0015: Unknown result type (might be due to invalid IL or missing references)
		//IL_0025: Unknown result type (might be due to invalid IL or missing references)
		//IL_0111: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c1: Unknown result type (might be due to invalid IL or missing references)
		//IL_0252: Unknown result type (might be due to invalid IL or missing references)
		//IL_0140: Unknown result type (might be due to invalid IL or missing references)
		//IL_0150: Unknown result type (might be due to invalid IL or missing references)
		//IL_023b: Unknown result type (might be due to invalid IL or missing references)
		//IL_02b7: Unknown result type (might be due to invalid IL or missing references)
		//IL_02bc: Unknown result type (might be due to invalid IL or missing references)
		//IL_031a: Unknown result type (might be due to invalid IL or missing references)
		//IL_031f: Unknown result type (might be due to invalid IL or missing references)
		//IL_032a: Unknown result type (might be due to invalid IL or missing references)
		//IL_032f: Unknown result type (might be due to invalid IL or missing references)
		//IL_033a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0530: Unknown result type (might be due to invalid IL or missing references)
		//IL_0535: Unknown result type (might be due to invalid IL or missing references)
		//IL_05d9: Unknown result type (might be due to invalid IL or missing references)
		//IL_061b: Unknown result type (might be due to invalid IL or missing references)
		//IL_075a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0773: Unknown result type (might be due to invalid IL or missing references)
		//IL_0666: Unknown result type (might be due to invalid IL or missing references)
		//IL_0685: Unknown result type (might be due to invalid IL or missing references)
		//IL_069b: Unknown result type (might be due to invalid IL or missing references)
		//IL_07a4: Unknown result type (might be due to invalid IL or missing references)
		//IL_07bd: Unknown result type (might be due to invalid IL or missing references)
		//IL_0794: Unknown result type (might be due to invalid IL or missing references)
		//IL_06ef: Unknown result type (might be due to invalid IL or missing references)
		//IL_070e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0729: Unknown result type (might be due to invalid IL or missing references)
		//IL_07de: Unknown result type (might be due to invalid IL or missing references)
		if (controller.currentState == EnemyTick.State.Despawn)
		{
			headTransformTarget.localScale = Vector3.zero;
			if (headTransform.localScale.y <= 0.1f)
			{
				foreach (ParticleSystem failedHealParticle in failedHealParticles)
				{
					failedHealParticle.Play();
				}
				enemy.EnemyParent.Despawn();
			}
		}
		if (controller.syncedHealth != lastSyncedHealth)
		{
			OnHealthChanged(controller.syncedHealth);
			if (controller.syncedHealth > lastSyncedHealth)
			{
				bigSuckSound.Play(((Component)controller).transform.position);
			}
			lastSyncedHealth = controller.syncedHealth;
		}
		VisualUpdateSprings();
		OverrideWalkAnimationTick();
		WalkAnimationLogic();
		if (flatHeadSwitch && headTransform.localScale.y <= 0.5f)
		{
			flatHead.SetActive(true);
			bloatedHead.SetActive(false);
			headTransformTarget.localScale = Vector3.one;
			headTransform.localScale = Vector3.one;
			flatHeadSwitch = false;
		}
		OverrideWalkAnimation();
		if (controller.currentState == EnemyTick.State.Bite)
		{
			SuckAnimationLogic();
			if (!lipsState)
			{
				lipsState = true;
				lipsClosed.SetActive(false);
				lipsOpen.SetActive(true);
			}
			mouthLerp += Time.deltaTime * mouthLerpSpeed;
			if (mouthLerp > 0.5f)
			{
				mouthLerp = 0f;
			}
			mouth.transform.localScale = new Vector3(1f + BodyAnimationCurve.Evaluate(mouthLerp) * mouthLerpIntensity, 1f + BodyAnimationCurve.Evaluate(mouthLerp) * mouthLerpIntensity, 1f + BodyAnimationCurve.Evaluate(mouthLerp) * mouthLerpIntensity);
		}
		else
		{
			mouth.transform.localScale = Vector3.one;
			if (lipsState)
			{
				lipsState = false;
				lipsClosed.SetActive(true);
				lipsOpen.SetActive(false);
			}
		}
		if (controller.enemy.Grounded.grounded && !wasGrounded)
		{
			Materials.Instance.Impulse(enemy.Rigidbody.physGrabObject.centerPoint, Vector3.down, Materials.SoundType.Light, footstep: true, footstepParticles: true, material, Materials.HostType.Enemy);
			wasGrounded = true;
		}
		else if (!controller.enemy.Grounded.grounded && wasGrounded)
		{
			wasGrounded = false;
		}
		if (controller.currentState == EnemyTick.State.Spawn && prevState != EnemyTick.State.Spawn)
		{
			springHead.lastPosition = Vector3.zero;
			springHead.springVelocity = Vector3.zero;
			headTransformTarget.localScale = Vector3.one;
			foreach (ParticleSystem failedHealParticle2 in failedHealParticles)
			{
				failedHealParticle2.Play();
			}
			OnHealthChanged(controller.syncedHealth);
		}
		float pitchMultiplier = Mathf.Clamp(janneksVelocity * 12f, 0.75f, 2f);
		if ((double)janneksVelocity > 0.02 && controller.enemy.Grounded.grounded && !controller.RidingVehicle)
		{
			if (hasBeenFull)
			{
				walkLoopPlaying = false;
				runLoopPlaying = true;
			}
			else
			{
				runLoopPlaying = false;
				walkLoopPlaying = true;
			}
		}
		else
		{
			walkLoopPlaying = false;
			runLoopPlaying = false;
		}
		if (SemiFunc.Arachnophobia())
		{
			skitteringLoop.PlayLoop(playing: false, 5f, 5f);
			walkLoop.PlayLoop(playing: false, 5f, 5f);
		}
		else
		{
			skitteringLoop.PlayLoop((double)janneksVelocity > 0.02 && !controller.RidingVehicle, 5f, 5f, pitchMultiplier);
			walkLoop.PlayLoop(walkLoopPlaying, 5f, 5f);
		}
		runLoop.PlayLoop(runLoopPlaying, 5f, 5f);
		if (walkLoopPlaying || runLoopPlaying)
		{
			float num = Mathf.Lerp(1f, 0.2f, Mathf.Clamp01(janneksVelocity * 4f));
			if (materialImpactTimer >= num)
			{
				Materials.Instance.Impulse(enemy.Rigidbody.physGrabObject.centerPoint, Vector3.down, Materials.SoundType.Light, footstep: true, footstepParticles: true, material, Materials.HostType.Enemy);
				materialImpactTimer = 0f;
			}
			materialImpactTimer += Time.deltaTime;
		}
		if (controller.currentState == EnemyTick.State.Bite)
		{
			suckLoop.PlayLoop(playing: true, 5f, 5f);
		}
		else
		{
			suckLoop.PlayLoop(playing: false, 5f, 5f);
		}
		if (controller.currentState == EnemyTick.State.Notice && prevState != EnemyTick.State.Notice)
		{
			noticeSound.Play(((Component)this).transform.position);
		}
		if (controller.currentState == EnemyTick.State.TumbleEnd && prevState == EnemyTick.State.Bite)
		{
			detachSound.Play(((Component)this).transform.position);
		}
		if (controller.currentState == EnemyTick.State.Tumble && prevState != EnemyTick.State.Tumble)
		{
			jumpTransformTargetRight.localRotation = Quaternion.Euler(0f, 0f, 45f);
			jumpTransformTargetLeft.localRotation = Quaternion.Euler(0f, 0f, -45f);
			jumpSound.Play(((Component)this).transform.position);
		}
		if (enemy.Jump.jumping)
		{
			if (jumpImpulse)
			{
				jumpTransformTargetRight.localRotation = Quaternion.Euler(0f, 0f, 50f);
				jumpTransformTargetLeft.localRotation = Quaternion.Euler(0f, 0f, -50f);
				jumpSound.Play(((Component)controller).transform.position);
				jumpImpulse = false;
			}
		}
		else
		{
			if (jumpTransformRight.localRotation.z >= Quaternion.Euler(0f, 0f, 45f).z)
			{
				jumpTransformTargetRight.localRotation = Quaternion.Euler(0f, 0f, 0f);
			}
			if (jumpTransformLeft.localRotation.z <= Quaternion.Euler(0f, 0f, -45f).z)
			{
				jumpTransformTargetLeft.localRotation = Quaternion.Euler(0f, 0f, 0f);
			}
			jumpImpulse = true;
		}
		DrivingPoseLogic();
		prevState = controller.currentState;
	}

	private void VisualUpdateSprings()
	{
		//IL_0078: Unknown result type (might be due to invalid IL or missing references)
		//IL_0082: Unknown result type (might be due to invalid IL or missing references)
		//IL_010b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0115: Unknown result type (might be due to invalid IL or missing references)
		//IL_014a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0154: Unknown result type (might be due to invalid IL or missing references)
		//IL_0190: Unknown result type (might be due to invalid IL or missing references)
		//IL_019a: Unknown result type (might be due to invalid IL or missing references)
		//IL_01d6: Unknown result type (might be due to invalid IL or missing references)
		//IL_01e0: Unknown result type (might be due to invalid IL or missing references)
		//IL_021c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0226: Unknown result type (might be due to invalid IL or missing references)
		int num = 30;
		float damping = 0.35f;
		int num2 = 20;
		float damping2 = 0.15f;
		foreach (springLimb springLimb in springLimbs)
		{
			springLimb.spring.speed = num;
			springLimb.spring.damping = damping;
			springLimb.spring.maxAngle = 5f;
			springLimb.spring.clamp = false;
			springLimb.transform.rotation = SemiFunc.SpringQuaternionGet(springLimb.spring, springLimb.target.rotation);
		}
		foreach (springBloatPart springBloatPart in springBloatParts)
		{
			springBloatPart.spring.speed = num2;
			springBloatPart.spring.damping = damping2;
			springBloatPart.spring.maxDistance = 0.5f;
			springBloatPart.spring.clamp = false;
			springBloatPart.transform.localScale = SemiFunc.SpringVector3Get(springBloatPart.spring, springBloatPart.target.localScale);
		}
		bodyTransform.rotation = SemiFunc.SpringQuaternionGet(springBody, bodyTransformTarget.rotation);
		springBody.speed = 20f;
		springBody.damping = 0.35f;
		headTransform.localScale = SemiFunc.SpringVector3Get(springHead, headTransformTarget.localScale);
		springHead.speed = 20f;
		springHead.damping = 0.15f;
		jumpTransformRight.localRotation = SemiFunc.SpringQuaternionGet(jumpRight, jumpTransformTargetRight.localRotation);
		jumpRight.speed = 20f;
		jumpRight.damping = 0.35f;
		jumpTransformLeft.localRotation = SemiFunc.SpringQuaternionGet(springJumpLeft, jumpTransformTargetLeft.localRotation);
		springJumpLeft.speed = 20f;
		springJumpLeft.damping = 0.35f;
	}

	private void DrivingPoseLogic()
	{
		//IL_0079: Unknown result type (might be due to invalid IL or missing references)
		//IL_006c: Unknown result type (might be due to invalid IL or missing references)
		//IL_007e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0080: Unknown result type (might be due to invalid IL or missing references)
		//IL_0085: Unknown result type (might be due to invalid IL or missing references)
		//IL_008a: Unknown result type (might be due to invalid IL or missing references)
		//IL_008d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0092: Unknown result type (might be due to invalid IL or missing references)
		//IL_0097: Unknown result type (might be due to invalid IL or missing references)
		//IL_0137: Unknown result type (might be due to invalid IL or missing references)
		//IL_013c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0144: Unknown result type (might be due to invalid IL or missing references)
		//IL_0176: Unknown result type (might be due to invalid IL or missing references)
		//IL_017b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0186: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c6: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d2: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d7: Unknown result type (might be due to invalid IL or missing references)
		//IL_00dc: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ee: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f4: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f9: Unknown result type (might be due to invalid IL or missing references)
		//IL_00fb: Unknown result type (might be due to invalid IL or missing references)
		//IL_0100: Unknown result type (might be due to invalid IL or missing references)
		//IL_0110: Unknown result type (might be due to invalid IL or missing references)
		//IL_0115: Unknown result type (might be due to invalid IL or missing references)
		//IL_011d: Unknown result type (might be due to invalid IL or missing references)
		bool ridingVehicle = controller.RidingVehicle;
		drivingPoseBlend = Mathf.MoveTowards(drivingPoseBlend, ridingVehicle ? 1f : 0f, Time.deltaTime * drivingPoseBlendSpeed);
		if (drivingPoseBlend <= 0.001f)
		{
			return;
		}
		ItemVehicle rideVehicleCurrent = controller.RideVehicleCurrent;
		Transform val = (Object.op_Implicit((Object)(object)rideVehicleCurrent) ? rideVehicleCurrent.AIDriverGrabPoint : null);
		Vector3 val2 = (Object.op_Implicit((Object)(object)rideVehicleCurrent) ? ((Component)rideVehicleCurrent).transform.up : Vector3.up);
		Quaternion val3 = Quaternion.Euler(drivingTuckEuler);
		Quaternion val4 = Quaternion.Euler(drivingArmAimOffsetEuler);
		foreach (springLimb springLimb in springLimbs)
		{
			if (springLimb.steeringLeg && Object.op_Implicit((Object)(object)val))
			{
				Vector3 val5 = val.position - springLimb.transform.position;
				if (val5.sqrMagnitude > 0.0001f)
				{
					Quaternion val6 = Quaternion.LookRotation(val5.normalized, val2) * val4;
					springLimb.target.rotation = Quaternion.Slerp(springLimb.target.rotation, val6, drivingPoseBlend);
				}
			}
			else
			{
				springLimb.target.localRotation = Quaternion.Slerp(springLimb.target.localRotation, val3, drivingPoseBlend);
			}
		}
		bodyTransformTarget.localRotation = Quaternion.Slerp(bodyTransformTarget.localRotation, Quaternion.identity, drivingPoseBlend);
	}

	private void WalkAnimationLogic()
	{
		//IL_0026: Unknown result type (might be due to invalid IL or missing references)
		//IL_003b: Unknown result type (might be due to invalid IL or missing references)
		//IL_005b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0060: Unknown result type (might be due to invalid IL or missing references)
		//IL_0133: Unknown result type (might be due to invalid IL or missing references)
		//IL_0246: Unknown result type (might be due to invalid IL or missing references)
		if (controller.RidingVehicle || !isWalking)
		{
			return;
		}
		if (SemiFunc.PerSecond(15f, (Object)(object)this))
		{
			janneksVelocity = Vector3.Distance(lastPosition, ((Component)enemy.Rigidbody).transform.position);
			lastPosition = ((Component)enemy.Rigidbody).transform.position;
		}
		float num = janneksVelocity * 6f;
		int num2 = 0;
		foreach (springLimb springLimb in springLimbs)
		{
			float num3 = BodyAnimationCurve.Evaluate(springLimb.sineEval);
			if (num2 % 2 == 0)
			{
				if (springLimb.sineEval <= 0f)
				{
					springLimb.sineEval = 1f;
				}
				springLimb.sineEval -= Time.deltaTime * 5f * num;
			}
			else
			{
				if (springLimb.sineEval >= 1f)
				{
					springLimb.sineEval = 0f;
				}
				springLimb.sineEval += Time.deltaTime * 5f * num;
			}
			springLimb.target.localRotation = Quaternion.Euler(num3 * 20f, num3 * 20f, num3 * 20f);
			num2++;
		}
		if (bodyAnimationEvalX >= 1f)
		{
			bodyAnimationEvalX = 0f;
		}
		float num4 = BodyAnimationCurve.Evaluate(bodyAnimationEvalX);
		bodyAnimationEvalX += Time.deltaTime * 5f * num;
		if (bodyAnimationEvalY >= 1f)
		{
			bodyAnimationEvalY = 0f;
		}
		float num5 = BodyAnimationCurve.Evaluate(bodyAnimationEvalY);
		bodyAnimationEvalY += Time.deltaTime * 10f * num;
		if (bodyAnimationEvalZ >= 1f)
		{
			bodyAnimationEvalZ = 0f;
		}
		float num6 = BodyAnimationCurve.Evaluate(bodyAnimationEvalZ);
		bodyAnimationEvalZ += Time.deltaTime * 2.5f * num;
		bodyTransformTarget.localRotation = Quaternion.Euler(num4 * 8f, num5 * 8f, num6 * 8f);
	}

	private void SuckAnimationLogic()
	{
		//IL_00e1: Unknown result type (might be due to invalid IL or missing references)
		if (bodyAnimationEvalX >= 1f)
		{
			bodyAnimationEvalX = 0f;
		}
		float num = BodyAnimationCurve.Evaluate(bodyAnimationEvalX);
		bodyAnimationEvalX += Time.deltaTime * 5f;
		if (bodyAnimationEvalY >= 1f)
		{
			bodyAnimationEvalY = 0f;
		}
		float num2 = BodyAnimationCurve.Evaluate(bodyAnimationEvalY);
		bodyAnimationEvalY += Time.deltaTime * 10f;
		if (bodyAnimationEvalZ >= 1f)
		{
			bodyAnimationEvalZ = 0f;
		}
		float num3 = BodyAnimationCurve.Evaluate(bodyAnimationEvalZ);
		bodyAnimationEvalZ += Time.deltaTime * 2.5f;
		bodyTransformTarget.localRotation = Quaternion.Euler(num * 8f, num2 * 8f, num3 * 8f);
	}

	private float HealthToColor(int _syncedHealth)
	{
		float num = 30f;
		float num2 = 100f;
		float num3 = (float)maxHealth * 0.3f;
		if ((float)_syncedHealth <= num3)
		{
			return num2;
		}
		return Mathf.Clamp(num3 + (float)maxHealth - Mathf.Clamp((float)_syncedHealth, num3, (float)maxHealth), num, num2);
	}

	public void OnHealthChanged(int _syncedHealth)
	{
		//IL_0053: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c7: Unknown result type (might be due to invalid IL or missing references)
		//IL_00cc: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d7: Unknown result type (might be due to invalid IL or missing references)
		//IL_00dc: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f6: Unknown result type (might be due to invalid IL or missing references)
		//IL_0115: Unknown result type (might be due to invalid IL or missing references)
		//IL_0125: Unknown result type (might be due to invalid IL or missing references)
		//IL_017b: Unknown result type (might be due to invalid IL or missing references)
		//IL_013c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0204: Unknown result type (might be due to invalid IL or missing references)
		//IL_026d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0224: Unknown result type (might be due to invalid IL or missing references)
		if (!hasBeenFull)
		{
			float currentValue = HealthToColor(_syncedHealth);
			float minValue = (float)maxHealth * 0.3f;
			foreach (Material instancedMaterial in controller.enemy.Health.instancedMaterials)
			{
				instancedMaterial.SetColor("_EmissionColor", SemiFunc.ColorDifficultyGet(minValue, maxHealth, currentValue));
			}
			if ((float)_syncedHealth >= (float)maxHealth * 0.1f)
			{
				if (flatHead.activeSelf)
				{
					flatHead.SetActive(false);
					bloatedHead.SetActive(true);
					springHead.lastPosition = new Vector3(1f, 0.5f, 1f);
					springHead.springVelocity = Vector3.zero;
					headTransformTarget.localScale = new Vector3(1f, 0.5f, 1f);
					headTransform.localScale = new Vector3(1f, 0.5f, 1f);
					if (headTransform.localScale.y == 0.5f)
					{
						headTransformTarget.localScale = Vector3.one;
					}
				}
			}
			else if ((float)_syncedHealth < (float)maxHealth * 0.1f && bloatedHead.activeSelf)
			{
				headTransformTarget.localScale = new Vector3(1f, 0.5f, 1f);
				flatHeadSwitch = true;
			}
			int num = Mathf.RoundToInt((float)maxHealth * 0.3f);
			if (_syncedHealth >= num)
			{
				int num2 = Mathf.CeilToInt((float)Mathf.Max(10, maxHealth - num) / 10f);
				int num3 = Mathf.Clamp((_syncedHealth - num) / 10, 0, num2);
				float num4 = ((num2 > 0) ? ((float)num3 / (float)num2) : 0f);
				float num5 = Mathf.Lerp(1f, maxScaleBloatParts, num4);
				Vector3 localScale = new Vector3(num5, num5, num5);
				foreach (springBloatPart springBloatPart in springBloatParts)
				{
					springBloatPart.target.localScale = localScale;
				}
			}
			else if (!flatHead.activeSelf)
			{
				foreach (springBloatPart springBloatPart2 in springBloatParts)
				{
					springBloatPart2.target.localScale = bloatPartsOrginalScale;
				}
			}
		}
		if (_syncedHealth >= maxHealth && !hasBeenFull)
		{
			hasBeenFull = true;
			if (SemiFunc.IsMasterClientOrSingleplayer())
			{
				enemy.Health.spawnValuable = true;
			}
		}
	}

	private void OverrideWalkAnimation()
	{
		overrideWalkAnimationTimer = 1f;
	}

	private void OverrideWalkAnimationTick()
	{
		//IL_0013: Unknown result type (might be due to invalid IL or missing references)
		if (overrideWalkAnimationTimer <= 0f)
		{
			bodyTransformTarget.localRotation = Quaternion.identity;
			isWalking = false;
		}
		if (overrideWalkAnimationTimer > 0f)
		{
			overrideWalkAnimationTimer -= Time.deltaTime;
			isWalking = true;
		}
	}

	public EnemyTickAnim()
	{
		//IL_0086: Unknown result type (might be due to invalid IL or missing references)
		//IL_008b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0091: Unknown result type (might be due to invalid IL or missing references)
		//IL_0096: Unknown result type (might be due to invalid IL or missing references)
	}
}
