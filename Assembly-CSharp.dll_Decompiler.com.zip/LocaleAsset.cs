using UnityEngine;
using UnityEngine.Localization;

[CreateAssetMenu(fileName = "LocaleAsset - [Unknown Locale Reference] (Disabled).asset", menuName = "Localization/Locale Asset")]
public class LocaleAsset : ScriptableObject
{
	public string NativeName = "";

	public bool RightToLeft;

	public bool Enabled;

	public Locale LocaleReference;

	public bool CanSetOnLoad = true;
}
