using System.Collections;
using UnityEngine;

public class DirtFinderMapPlayer : MonoBehaviour
{
	public static DirtFinderMapPlayer Instance;

	private Transform PlayerTransform;

	private Vector3 StartOffset;

	[RuntimeInitializeOnLoadMethod(/*Could not decode attribute arguments.*/)]
	private static void RuntimeInitializeOnLoad()
	{
		Instance = null;
	}

	private void Awake()
	{
		//IL_000d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0012: Unknown result type (might be due to invalid IL or missing references)
		Instance = this;
		StartOffset = ((Component)this).transform.position;
	}

	private void OnEnable()
	{
		PlayerTransform = null;
		((MonoBehaviour)this).StartCoroutine(FindPlayer());
	}

	private IEnumerator FindPlayer()
	{
		yield return (object)new WaitForSeconds(0.1f);
		while (!Object.op_Implicit((Object)(object)PlayerTransform))
		{
			if (Object.op_Implicit((Object)(object)PlayerController.instance))
			{
				PlayerTransform = ((Component)PlayerController.instance).transform;
				((MonoBehaviour)this).StartCoroutine(Logic());
			}
			yield return (object)new WaitForSeconds(0.1f);
		}
	}

	private IEnumerator Logic()
	{
		while (true)
		{
			if (!SemiFunc.RunIsShop() && !SemiFunc.RunIsArena() && !SemiFunc.RunIsLobby())
			{
				((Component)this).transform.position = ((Component)PlayerTransform).transform.position * Map.Instance.Scale + Map.Instance.OverLayerParent.position + StartOffset;
				((Component)this).transform.rotation = PlayerTransform.rotation;
			}
			else
			{
				((Component)this).transform.position = Map.Instance.OverLayerParent.position + StartOffset;
				((Component)this).transform.rotation = Quaternion.identity;
			}
			((Component)this).transform.localPosition = new Vector3(((Component)this).transform.localPosition.x, 0f, ((Component)this).transform.localPosition.z);
			MapLayer layerParent = Map.Instance.GetLayerParent(PlayerTransform.position.y + 0.01f);
			Map.Instance.PlayerLayer = layerParent.layer;
			yield return (object)new WaitForSeconds(0.1f);
		}
	}
}
