using System;
using System.Collections;
using System.Collections.Generic;
using Photon.Pun;
using UnityEngine;

public class ChargingStation : MonoBehaviour
{
	public static ChargingStation instance;

	private int maxCrystals = 10;

	private int energyPerCrystal = 10;

	private PhotonView photonView;

	private Transform chargeBar;

	private Vector3 chargeBarMaxScale = Vector3.one;

	internal int chargeTotal = 100;

	private float chargeFloat = 1f;

	private float chargeScale = 1f;

	private float chargeScaleTarget = 1f;

	internal int chargeInt;

	public int chargeSegments = 40;

	private int chargeSegmentCurrent;

	private float batteryChargeCost;

	public AnimationCurve chargeCurve;

	private float chargeCurveTime;

	private Transform chargeArea;

	private float chargeAreaCheckTimer;

	private List<ItemBattery> itemsCharging = new List<ItemBattery>();

	private Transform lockedTransform;

	public Light barLight;

	public LocalizedAsset localizedFocusTruckIntro;

	public GameObject meshObject;

	private Material chargingStationEmissionMaterial;

	private bool isCharging;

	private Light light1;

	private Light light2;

	private float lightsFlickerOnTimer = -1f;

	private float lightsFlickerOffTimer = -1f;

	private List<Light> stationLights = new List<Light>();

	private List<float> stationLightMaxIntensities = new List<float>();

	public Sound soundStart;

	public Sound soundStop;

	public Sound soundLoop;

	public Transform crystalCylinder;

	public List<Transform> crystals = new List<Transform>();

	public ParticleSystem lightParticle;

	public ParticleSystem fireflyParticles;

	public ParticleSystem bitsParticles;

	public ParticleSystem chargeParticles;

	public Sound soundPowerCrystalBreak;

	private float crystalCooldown;

	public Item item;

	public GameObject subtleLight;

	public Transform chargeLaserMesh;

	public Transform laserPoint;

	public LineBetweenTwoPoints chargeLaser;

	public float chargeBeamScanDurationMax = 1f;

	public float chargeBeamScanDurationMin = 0.25f;

	public float chargeBeamIntroOutroFraction = 0.2f;

	public SpringQuaternion laserMeshTiltSpring = new SpringQuaternion
	{
		speed = 8f
	};

	public float laserMeshTiltMaxAngle = 5f;

	public AnimationCurve chargeLaserFlickerOnCurve;

	public AnimationCurve chargeLaserFlickerOffCurve;

	public AnimationCurve chargeLaserIntroBounceCurve;

	public AnimationCurve chargeLaserSettleBounceCurve;

	public float chargeLaserShakeAmount = 0.02f;

	public float chargeLaserBounceShakePosition = 0.1f;

	public float chargeLaserBounceShakeRotation = 8f;

	public float chargeLaserIntroBounceDuration = 0.35f;

	public float chargeLaserSettleBounceDuration = 0.35f;

	private Material chargeLaserMaterial;

	private Quaternion laserMeshBaseRotation = Quaternion.identity;

	private Vector3 chargeLaserBasePosition;

	private Vector3 meshTiltTargetWorld;

	private bool meshTiltTargetValid;

	private float chargeLaserFlickerOnTimer = -1f;

	private float chargeLaserFlickerOffTimer = -1f;

	private float chargeLaserIntroBounceTimer = -1f;

	private float chargeLaserSettleBounceTimer = -1f;

	private float chargeLaserShakeTimer;

	private Vector3 chargeLaserShakeFrom;

	private Vector3 chargeLaserShakeTo;

	private Vector3 chargeLaserShakeRotationFrom;

	private Vector3 chargeLaserShakeRotationTo;

	private Dictionary<ItemBattery, List<Collider>> scanColliders = new Dictionary<ItemBattery, List<Collider>>();

	private Dictionary<ItemBattery, int> scanColliderIndex = new Dictionary<ItemBattery, int>();

	private List<ItemBattery> scanOrder = new List<ItemBattery>();

	private int scanCursor;

	private Collider scanCurrentCollider;

	private ItemBattery scanCurrentItem;

	private float scanTimer;

	private float scanDuration = 1f;

	private bool scanLostTargetOutro;

	private int lastSentSegment = -1;

	[RuntimeInitializeOnLoadMethod(/*Could not decode attribute arguments.*/)]
	private static void RuntimeInitializeOnLoad()
	{
		instance = null;
	}

	private void Awake()
	{
		instance = this;
	}

	private void Start()
	{
		//IL_002d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0034: Expected Obj, but got Unknown
		//IL_009f: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a4: Unknown result type (might be due to invalid IL or missing references)
		//IL_00bc: Unknown result type (might be due to invalid IL or missing references)
		//IL_00da: Unknown result type (might be due to invalid IL or missing references)
		//IL_00df: Unknown result type (might be due to invalid IL or missing references)
		//IL_00eb: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f0: Unknown result type (might be due to invalid IL or missing references)
		//IL_0123: Unknown result type (might be due to invalid IL or missing references)
		//IL_03cc: Unknown result type (might be due to invalid IL or missing references)
		batteryChargeCost = 1f / (float)energyPerCrystal / 100f;
		foreach (Transform item in crystalCylinder)
		{
			Transform val = item;
			crystals.Add(val);
		}
		chargingStationEmissionMaterial = meshObject.GetComponent<Renderer>().material;
		chargeBar = ((Component)this).transform.Find("Charge");
		if (Object.op_Implicit((Object)(object)chargeBar))
		{
			chargeBarMaxScale = chargeBar.localScale;
		}
		if (Object.op_Implicit((Object)(object)chargeLaser))
		{
			chargeLaser.SetColor(Color.yellow);
		}
		if (Object.op_Implicit((Object)(object)chargeLaserMesh))
		{
			laserMeshBaseRotation = chargeLaserMesh.localRotation;
			chargeLaserBasePosition = chargeLaserMesh.localPosition;
			Renderer component = ((Component)chargeLaserMesh).GetComponent<Renderer>();
			if (Object.op_Implicit((Object)(object)component))
			{
				chargeLaserMaterial = component.material;
				chargeLaserMaterial.SetColor("_EmissionColor", Color.black);
			}
		}
		photonView = ((Component)this).GetComponent<PhotonView>();
		chargeArea = ((Component)this).transform.Find("Charge Area");
		lockedTransform = ((Component)this).transform.Find("Locked");
		light1 = ((Component)((Component)this).transform.Find("Light1")).GetComponent<Light>();
		light2 = ((Component)((Component)this).transform.Find("Light2")).GetComponent<Light>();
		if (!SemiFunc.RunIsShop())
		{
			if (Object.op_Implicit((Object)(object)lockedTransform))
			{
				Object.Destroy((Object)(object)((Component)lockedTransform).gameObject);
			}
			SetupStationLights();
		}
		else
		{
			if (Object.op_Implicit((Object)(object)subtleLight))
			{
				Object.Destroy((Object)(object)subtleLight);
			}
			if (Object.op_Implicit((Object)(object)chargeArea))
			{
				Object.Destroy((Object)(object)((Component)chargeArea).gameObject);
			}
			if (Object.op_Implicit((Object)(object)chargeBar))
			{
				Object.Destroy((Object)(object)((Component)chargeBar).gameObject);
			}
			Object.Destroy((Object)(object)((Component)light1).gameObject);
			Object.Destroy((Object)(object)((Component)light2).gameObject);
		}
		chargeInt = SemiFunc.StatGetItemsPurchased("Item Power Crystal");
		int num = maxCrystals + 1;
		int num2 = Mathf.RoundToInt((float)(chargeInt * energyPerCrystal / maxCrystals) * (float)energyPerCrystal);
		StatsManager.instance.runStats.TryGetValue("chargingStationChargeTotal", out chargeTotal);
		if (chargeTotal > num2)
		{
			chargeTotal = num2;
		}
		StatsManager.instance.runStats["chargingStationChargeTotal"] = chargeTotal;
		int num3 = Mathf.Clamp(Mathf.CeilToInt((float)chargeTotal / (float)energyPerCrystal), 0, maxCrystals);
		while (crystals.Count > num3 && num > 0 && crystals.Count != 0)
		{
			if (Object.op_Implicit((Object)(object)crystals[0]))
			{
				Object.Destroy((Object)(object)((Component)crystals[0]).gameObject);
			}
			crystals.RemoveAt(0);
			num--;
		}
		chargeFloat = (float)chargeTotal / 100f;
		chargeSegmentCurrent = Mathf.RoundToInt(chargeFloat * (float)chargeSegments);
		if (chargeInt <= 0)
		{
			OutOfCrystalsShutdown();
		}
		chargeScale = chargeFloat;
		chargeScaleTarget = (float)chargeSegmentCurrent / (float)chargeSegments;
		if (Object.op_Implicit((Object)(object)chargeBar))
		{
			chargeBar.localScale = new Vector3(chargeScale * chargeBarMaxScale.x, chargeBarMaxScale.y, chargeBarMaxScale.z);
		}
		num = maxCrystals + 1;
		while (crystals.Count > chargeInt && num > 0 && crystals.Count != 0)
		{
			if (Object.op_Implicit((Object)(object)crystals[0]))
			{
				Object.Destroy((Object)(object)((Component)crystals[0]).gameObject);
			}
			crystals.RemoveAt(0);
			num--;
		}
		if (crystals.Count == 0)
		{
			OutOfCrystalsShutdown();
		}
		((MonoBehaviour)this).StartCoroutine(MissionText());
	}

	private void Update()
	{
		//IL_00e2: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00be: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00cf: Unknown result type (might be due to invalid IL or missing references)
		if (!SemiFunc.RunIsShop() && !RunManager.instance.levelIsShop)
		{
			if (chargeTotal <= 0)
			{
				CrystalsItShouldHave();
			}
			chargeScaleTarget = (float)chargeSegmentCurrent / (float)chargeSegments;
			soundLoop.PlayLoop(isCharging, 2f, 2f);
			UpdateItemsInRange();
			AnimateChargeBar();
			ChargingEffects();
			UpdateChargeBeam();
			UpdateLaserMeshTilt();
			UpdateLaserMeshEmission();
			if (isCharging && crystals.Count > 0)
			{
				float num = 0.5f + Mathf.PingPong(Time.time * 5f, 0.5f);
				Color val = Color.yellow * Mathf.LinearToGammaSpace(num);
				chargingStationEmissionMaterial.SetColor("_EmissionColor", val);
			}
			else
			{
				chargingStationEmissionMaterial.SetColor("_EmissionColor", Color.black);
			}
			UpdateStationLights();
			if (SemiFunc.IsMasterClientOrSingleplayer() && !RunManager.instance.restarting)
			{
				ChargeAreaCheck();
				chargeSegmentCurrent = Mathf.RoundToInt(chargeFloat * (float)chargeSegments);
			}
		}
	}

	private void StopCharge()
	{
		//IL_0029: Unknown result type (might be due to invalid IL or missing references)
		//IL_002f: Unknown result type (might be due to invalid IL or missing references)
		if (SemiFunc.IsMasterClientOrSingleplayer())
		{
			if (SemiFunc.IsMultiplayer())
			{
				photonView.RPC("StopChargeRPC", (RpcTarget)0, Array.Empty<object>());
			}
			else
			{
				StopChargeRPC();
			}
		}
	}

	[PunRPC]
	public void StopChargeRPC(PhotonMessageInfo _info = default(PhotonMessageInfo))
	{
		//IL_0000: Unknown result type (might be due to invalid IL or missing references)
		//IL_0015: Unknown result type (might be due to invalid IL or missing references)
		if (SemiFunc.MasterOnlyRPC(_info))
		{
			soundStop.Play(((Component)this).transform.position);
			isCharging = false;
			chargeLaserFlickerOffTimer = 0f;
			chargeLaserFlickerOnTimer = -1f;
			chargeLaserSettleBounceTimer = 0f;
			chargeLaserIntroBounceTimer = -1f;
			lightsFlickerOffTimer = 0f;
			lightsFlickerOnTimer = -1f;
		}
	}

	private void StartCharge()
	{
		//IL_0029: Unknown result type (might be due to invalid IL or missing references)
		//IL_002f: Unknown result type (might be due to invalid IL or missing references)
		if (SemiFunc.IsMasterClientOrSingleplayer())
		{
			if (SemiFunc.IsMultiplayer())
			{
				photonView.RPC("StartChargeRPC", (RpcTarget)0, Array.Empty<object>());
			}
			else
			{
				StartChargeRPC();
			}
		}
	}

	[PunRPC]
	public void StartChargeRPC(PhotonMessageInfo _info = default(PhotonMessageInfo))
	{
		//IL_0000: Unknown result type (might be due to invalid IL or missing references)
		//IL_0015: Unknown result type (might be due to invalid IL or missing references)
		if (SemiFunc.MasterOnlyRPC(_info))
		{
			soundStart.Play(((Component)this).transform.position);
			isCharging = true;
			chargeLaserFlickerOnTimer = 0f;
			chargeLaserFlickerOffTimer = -1f;
			chargeLaserIntroBounceTimer = 0f;
			chargeLaserSettleBounceTimer = -1f;
			lightsFlickerOnTimer = 0f;
			lightsFlickerOffTimer = -1f;
		}
	}

	private void SetupStationLights()
	{
		if (Object.op_Implicit((Object)(object)barLight))
		{
			AddStationLight(barLight);
		}
		if (Object.op_Implicit((Object)(object)light1))
		{
			AddStationLight(light1);
		}
		if (Object.op_Implicit((Object)(object)light2))
		{
			AddStationLight(light2);
		}
		if (Object.op_Implicit((Object)(object)subtleLight))
		{
			Light component = subtleLight.GetComponent<Light>();
			if (Object.op_Implicit((Object)(object)component))
			{
				AddStationLight(component);
			}
		}
	}

	private void AddStationLight(Light _light)
	{
		stationLights.Add(_light);
		stationLightMaxIntensities.Add(_light.intensity);
		_light.intensity = 0f;
		((Behaviour)_light).enabled = false;
	}

	private void UpdateStationLights()
	{
		bool flag = isCharging && crystals.Count > 0;
		float num = 0f;
		bool enabled = false;
		if (lightsFlickerOnTimer >= 0f)
		{
			lightsFlickerOnTimer += Time.deltaTime;
			float num2 = Mathf.Clamp01(lightsFlickerOnTimer / 0.2f);
			num = chargeLaserFlickerOnCurve.Evaluate(num2);
			enabled = flag;
			if (num2 >= 1f)
			{
				lightsFlickerOnTimer = -1f;
			}
		}
		else if (lightsFlickerOffTimer >= 0f)
		{
			lightsFlickerOffTimer += Time.deltaTime;
			float num3 = chargeCurve.Evaluate(lightsFlickerOffTimer);
			num = Mathf.Lerp(1f, 0f, num3);
			enabled = num > 0f;
			if (lightsFlickerOffTimer >= 1f)
			{
				lightsFlickerOffTimer = -1f;
				num = 0f;
				enabled = false;
			}
		}
		else if (flag)
		{
			num = 1f;
			enabled = true;
		}
		for (int i = 0; i < stationLights.Count; i++)
		{
			Light val = stationLights[i];
			if (Object.op_Implicit((Object)(object)val))
			{
				((Behaviour)val).enabled = enabled;
				val.intensity = num * stationLightMaxIntensities[i];
			}
		}
	}

	private void OutOfCrystalsShutdown()
	{
		//IL_000b: Unknown result type (might be due to invalid IL or missing references)
		//IL_005e: Unknown result type (might be due to invalid IL or missing references)
		//IL_006e: Unknown result type (might be due to invalid IL or missing references)
		chargingStationEmissionMaterial.SetColor("_EmissionColor", Color.black);
		if (isCharging && lightsFlickerOffTimer < 0f)
		{
			lightsFlickerOffTimer = 0f;
			lightsFlickerOnTimer = -1f;
		}
		if (Object.op_Implicit((Object)(object)subtleLight))
		{
			Color color = new Color(0.1f, 0.1f, 0.2f);
			subtleLight.GetComponent<Light>().color = color;
		}
	}

	public IEnumerator MissionText()
	{
		while (LevelGenerator.Instance.Generated)
		{
			yield return (object)new WaitForSeconds(0.1f);
		}
		yield return (object)new WaitForSeconds(2f);
		if (SemiFunc.RunIsLobby())
		{
			SemiFunc.UIFocusText(localizedFocusTruckIntro?.GetLocalizedString() ?? "Enjoy the ride, recharge stuff and GEAR UP!", Color.white, AssetManager.instance.colorYellow);
		}
	}

	private void CrystalsItShouldHave()
	{
		if (SemiFunc.IsMasterClientOrSingleplayer())
		{
			int num = Mathf.Clamp(Mathf.CeilToInt((float)chargeTotal / (float)energyPerCrystal), 0, maxCrystals);
			if (crystals.Count > num)
			{
				DestroyCrystal();
			}
		}
	}

	private void UpdateItemsInRange()
	{
		//IL_003f: Unknown result type (might be due to invalid IL or missing references)
		//IL_004a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0054: Unknown result type (might be due to invalid IL or missing references)
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0064: Unknown result type (might be due to invalid IL or missing references)
		if (!Object.op_Implicit((Object)(object)chargeArea))
		{
			return;
		}
		chargeAreaCheckTimer += Time.deltaTime;
		if (chargeAreaCheckTimer < 0.5f)
		{
			return;
		}
		chargeAreaCheckTimer = 0f;
		Collider[] array = Physics.OverlapBox(chargeArea.position, chargeArea.lossyScale / 2f, chargeArea.rotation, LayerMask.op_Implicit(SemiFunc.LayerMaskGetPhysGrabObject()));
		itemsCharging.Clear();
		Collider[] array2 = array;
		for (int i = 0; i < array2.Length; i++)
		{
			ItemBattery componentInParent = ((Component)array2[i]).GetComponentInParent<ItemBattery>();
			if (Object.op_Implicit((Object)(object)componentInParent) && componentInParent.batteryLife < 100f && !itemsCharging.Contains(componentInParent))
			{
				itemsCharging.Add(componentInParent);
			}
		}
	}

	private void ChargeAreaCheck()
	{
		if (SemiFunc.RunIsShop() || RunManager.instance.levelIsShop)
		{
			return;
		}
		if (chargeFloat <= 0f)
		{
			if (isCharging)
			{
				StopCharge();
			}
			return;
		}
		float num = ChargeItems();
		if (num > 0f)
		{
			if (!isCharging)
			{
				StartCharge();
			}
			StatsManager.instance.runStats["chargingStationCharge"] = chargeInt;
			StatsManager.instance.runStats["chargingStationChargeTotal"] = chargeTotal;
		}
		if (isCharging)
		{
			CrystalsItShouldHave();
		}
		int num2 = Mathf.CeilToInt(chargeFloat * (float)chargeSegments);
		if (SemiFunc.IsMasterClient() && num2 != lastSentSegment)
		{
			lastSentSegment = num2;
			PhotonNetwork.RemoveBufferedRPCs(photonView.ViewID, "ChargingStationSegmentChangedRPC", (int[])null);
			photonView.RPC("ChargingStationSegmentChangedRPC", (RpcTarget)3, new object[1] { (byte)num2 });
		}
		if (num <= 0f && isCharging)
		{
			StopCharge();
		}
	}

	private float ChargeItems()
	{
		float num = 0f;
		foreach (ItemBattery item in itemsCharging)
		{
			if (chargeFloat <= 0f)
			{
				break;
			}
			if (Object.op_Implicit((Object)(object)item) && !(item.batteryLife >= 100f))
			{
				float amount = Mathf.Min(20f * Time.deltaTime, chargeFloat / batteryChargeCost);
				amount = item.ReceiveCharge(amount);
				chargeFloat = Mathf.Max(0f, chargeFloat - amount * batteryChargeCost);
				num += amount;
			}
		}
		chargeTotal = Mathf.Clamp((int)(chargeFloat * 100f), 0, 100);
		return num;
	}

	[PunRPC]
	private void ChargingStationSegmentChangedRPC(byte segment, PhotonMessageInfo _info = default(PhotonMessageInfo))
	{
		//IL_0000: Unknown result type (might be due to invalid IL or missing references)
		if (SemiFunc.MasterOnlyRPC(_info))
		{
			chargeSegmentCurrent = segment;
			if (!SemiFunc.IsMasterClientOrSingleplayer())
			{
				chargeFloat = (float)(int)segment / (float)chargeSegments;
				chargeTotal = Mathf.RoundToInt(chargeFloat * 100f);
			}
			lastSentSegment = segment;
		}
	}

	private void ChargingEffects()
	{
		//IL_0141: Unknown result type (might be due to invalid IL or missing references)
		//IL_0091: Unknown result type (might be due to invalid IL or missing references)
		//IL_01af: Unknown result type (might be due to invalid IL or missing references)
		//IL_01bb: Unknown result type (might be due to invalid IL or missing references)
		//IL_01c0: Unknown result type (might be due to invalid IL or missing references)
		//IL_01d3: Unknown result type (might be due to invalid IL or missing references)
		//IL_020e: Unknown result type (might be due to invalid IL or missing references)
		//IL_00de: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e9: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ee: Unknown result type (might be due to invalid IL or missing references)
		//IL_0100: Unknown result type (might be due to invalid IL or missing references)
		if (Object.op_Implicit((Object)(object)chargeParticles))
		{
			if (isCharging && !chargeParticles.isPlaying)
			{
				chargeParticles.Play(true);
			}
			else if (!isCharging && chargeParticles.isPlaying)
			{
				chargeParticles.Stop();
			}
		}
		if (isCharging)
		{
			TutorialDirector.instance.playerUsedChargingStation = true;
			crystalCylinder.localRotation = Quaternion.Euler(90f, 0f, Mathf.PingPong(Time.time * 150f, 5f) - 2.5f);
			int num = 0;
			foreach (Transform crystal in crystals)
			{
				if (Object.op_Implicit((Object)(object)crystal))
				{
					num++;
					float num2 = 0.1f + Mathf.PingPong((Time.time + (float)num) * 5f, 1f);
					Color val = Color.yellow * Mathf.LinearToGammaSpace(num2);
					((Component)crystal).GetComponent<Renderer>().material.SetColor("_EmissionColor", val);
				}
			}
			crystalCooldown = 0f;
			return;
		}
		crystalCylinder.localRotation = Quaternion.Euler(90f, 0f, 0f);
		foreach (Transform crystal2 in crystals)
		{
			if (Object.op_Implicit((Object)(object)crystal2))
			{
				crystalCooldown += Time.deltaTime * 0.5f;
				float num3 = chargeCurve.Evaluate(crystalCooldown);
				float num4 = Mathf.Lerp(1f, 0.1f, num3);
				Color val2 = Color.yellow * Mathf.LinearToGammaSpace(num4);
				((Component)crystal2).GetComponent<Renderer>().material.SetColor("_EmissionColor", val2);
				crystalCylinder.localRotation = Quaternion.Euler(90f, 0f, (Mathf.PingPong(Time.time * 250f, 10f) - 5f) * (1f - num3));
			}
		}
	}

	private void UpdateChargeBeam()
	{
		//IL_0209: Unknown result type (might be due to invalid IL or missing references)
		//IL_020e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0211: Unknown result type (might be due to invalid IL or missing references)
		//IL_0213: Unknown result type (might be due to invalid IL or missing references)
		//IL_0244: Unknown result type (might be due to invalid IL or missing references)
		//IL_0237: Unknown result type (might be due to invalid IL or missing references)
		//IL_0249: Unknown result type (might be due to invalid IL or missing references)
		//IL_0251: Unknown result type (might be due to invalid IL or missing references)
		//IL_0253: Unknown result type (might be due to invalid IL or missing references)
		if (!Object.op_Implicit((Object)(object)chargeLaser))
		{
			return;
		}
		SyncScanEntries();
		if (scanOrder.Count > 0)
		{
			scanDuration = Mathf.Clamp(1f / (float)scanOrder.Count, chargeBeamScanDurationMin, chargeBeamScanDurationMax);
		}
		bool flag = Object.op_Implicit((Object)(object)scanCurrentItem) && !scanColliders.ContainsKey(scanCurrentItem);
		bool flag2 = Object.op_Implicit((Object)(object)scanCurrentItem) && (Object)(object)scanCurrentCollider == (Object)null;
		bool flag3 = !isCharging && ((Object)(object)scanCurrentCollider != (Object)null || (Object)(object)scanCurrentItem != (Object)null);
		if (!scanLostTargetOutro && (flag | flag2 | flag3))
		{
			scanLostTargetOutro = true;
			scanCurrentCollider = null;
			scanCurrentItem = null;
			scanTimer = 0f;
		}
		scanTimer += Time.deltaTime;
		if (scanLostTargetOutro)
		{
			meshTiltTargetValid = false;
			float num = Mathf.Max(scanDuration * chargeBeamIntroOutroFraction, 0.1f);
			if (scanTimer >= num)
			{
				scanLostTargetOutro = false;
				scanTimer = 0f;
				if (isCharging && scanOrder.Count > 0)
				{
					AdvanceScan();
				}
			}
			return;
		}
		if (!isCharging || scanOrder.Count == 0)
		{
			scanCurrentCollider = null;
			scanCurrentItem = null;
			scanTimer = 0f;
			meshTiltTargetValid = false;
			return;
		}
		if (!Object.op_Implicit((Object)(object)scanCurrentCollider))
		{
			AdvanceScan();
			scanTimer = 0f;
		}
		if (scanTimer >= scanDuration)
		{
			AdvanceScan();
			scanTimer = 0f;
		}
		if (!Object.op_Implicit((Object)(object)scanCurrentCollider))
		{
			meshTiltTargetValid = false;
			return;
		}
		float num2 = Mathf.Clamp01(scanTimer / scanDuration);
		float num3 = 1f - chargeBeamIntroOutroFraction;
		Vector3 point = (meshTiltTargetWorld = PhysGrabScanPoint.Get(scanCurrentCollider, num2));
		meshTiltTargetValid = true;
		if (num2 < num3)
		{
			Vector3 point2 = (Object.op_Implicit((Object)(object)laserPoint) ? laserPoint.position : ((Component)this).transform.position);
			chargeLaser.DrawLineAnimated(point2, point);
		}
	}

	private void UpdateLaserMeshEmission()
	{
		//IL_00e7: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f2: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f7: Unknown result type (might be due to invalid IL or missing references)
		//IL_0103: Unknown result type (might be due to invalid IL or missing references)
		if (!Object.op_Implicit((Object)(object)chargeLaserMaterial))
		{
			return;
		}
		float num = 0f;
		if (chargeLaserFlickerOnTimer >= 0f)
		{
			chargeLaserFlickerOnTimer += Time.deltaTime;
			float num2 = Mathf.Clamp01(chargeLaserFlickerOnTimer / 0.2f);
			num = chargeLaserFlickerOnCurve.Evaluate(num2);
			if (num2 >= 1f)
			{
				chargeLaserFlickerOnTimer = -1f;
			}
		}
		else if (chargeLaserFlickerOffTimer >= 0f)
		{
			chargeLaserFlickerOffTimer += Time.deltaTime;
			float num3 = Mathf.Clamp01(chargeLaserFlickerOffTimer / 0.5f);
			num = 1f - chargeLaserFlickerOffCurve.Evaluate(num3);
			if (num3 >= 1f)
			{
				chargeLaserFlickerOffTimer = -1f;
			}
		}
		else if (isCharging)
		{
			num = 0.5f + Mathf.PingPong(Time.time * 5f, 0.5f);
		}
		Color val = Color.yellow * Mathf.LinearToGammaSpace(num);
		chargeLaserMaterial.SetColor("_EmissionColor", val);
	}

	private void UpdateLaserMeshTilt()
	{
		//IL_00cc: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d1: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d2: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d7: Unknown result type (might be due to invalid IL or missing references)
		//IL_0186: Unknown result type (might be due to invalid IL or missing references)
		//IL_018c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0193: Unknown result type (might be due to invalid IL or missing references)
		//IL_0198: Unknown result type (might be due to invalid IL or missing references)
		//IL_019a: Unknown result type (might be due to invalid IL or missing references)
		//IL_01a0: Unknown result type (might be due to invalid IL or missing references)
		//IL_01a7: Unknown result type (might be due to invalid IL or missing references)
		//IL_01ac: Unknown result type (might be due to invalid IL or missing references)
		//IL_013b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0140: Unknown result type (might be due to invalid IL or missing references)
		//IL_0146: Unknown result type (might be due to invalid IL or missing references)
		//IL_014d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0152: Unknown result type (might be due to invalid IL or missing references)
		//IL_0159: Unknown result type (might be due to invalid IL or missing references)
		//IL_015e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0164: Unknown result type (might be due to invalid IL or missing references)
		//IL_016b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0170: Unknown result type (might be due to invalid IL or missing references)
		//IL_01af: Unknown result type (might be due to invalid IL or missing references)
		//IL_01b4: Unknown result type (might be due to invalid IL or missing references)
		//IL_024f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0256: Unknown result type (might be due to invalid IL or missing references)
		//IL_025b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0264: Unknown result type (might be due to invalid IL or missing references)
		//IL_0269: Unknown result type (might be due to invalid IL or missing references)
		//IL_026a: Unknown result type (might be due to invalid IL or missing references)
		//IL_027a: Unknown result type (might be due to invalid IL or missing references)
		//IL_027c: Unknown result type (might be due to invalid IL or missing references)
		//IL_027e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0283: Unknown result type (might be due to invalid IL or missing references)
		//IL_01e2: Unknown result type (might be due to invalid IL or missing references)
		//IL_01e7: Unknown result type (might be due to invalid IL or missing references)
		//IL_01d8: Unknown result type (might be due to invalid IL or missing references)
		//IL_01ed: Unknown result type (might be due to invalid IL or missing references)
		//IL_01f2: Unknown result type (might be due to invalid IL or missing references)
		//IL_01f7: Unknown result type (might be due to invalid IL or missing references)
		//IL_01fb: Unknown result type (might be due to invalid IL or missing references)
		//IL_0200: Unknown result type (might be due to invalid IL or missing references)
		//IL_0211: Unknown result type (might be due to invalid IL or missing references)
		//IL_0216: Unknown result type (might be due to invalid IL or missing references)
		//IL_021b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0220: Unknown result type (might be due to invalid IL or missing references)
		//IL_0222: Unknown result type (might be due to invalid IL or missing references)
		//IL_0228: Unknown result type (might be due to invalid IL or missing references)
		//IL_022d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0232: Unknown result type (might be due to invalid IL or missing references)
		//IL_0235: Unknown result type (might be due to invalid IL or missing references)
		//IL_023a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0242: Unknown result type (might be due to invalid IL or missing references)
		//IL_0247: Unknown result type (might be due to invalid IL or missing references)
		if (!Object.op_Implicit((Object)(object)chargeLaserMesh))
		{
			return;
		}
		float num = 0f;
		if (chargeLaserIntroBounceTimer >= 0f)
		{
			chargeLaserIntroBounceTimer += Time.deltaTime;
			float num2 = chargeLaserIntroBounceTimer / chargeLaserIntroBounceDuration;
			if (num2 >= 1f)
			{
				chargeLaserIntroBounceTimer = -1f;
			}
			else
			{
				num = chargeLaserIntroBounceCurve.Evaluate(num2);
			}
		}
		float num3 = 0f;
		if (chargeLaserSettleBounceTimer >= 0f)
		{
			chargeLaserSettleBounceTimer += Time.deltaTime;
			float num4 = chargeLaserSettleBounceTimer / chargeLaserSettleBounceDuration;
			if (num4 >= 1f)
			{
				chargeLaserSettleBounceTimer = -1f;
			}
			else
			{
				num3 = 1f - chargeLaserSettleBounceCurve.Evaluate(num4);
			}
		}
		float num5 = Mathf.Max(num, num3);
		Vector3 val = Vector3.zero;
		Vector3 val2 = Vector3.zero;
		if (isCharging || num5 > 0f)
		{
			float num6 = 1f / 24f;
			chargeLaserShakeTimer += Time.deltaTime;
			if (chargeLaserShakeTimer >= num6)
			{
				chargeLaserShakeTimer -= num6;
				float num7 = chargeLaserShakeAmount + num5 * chargeLaserBounceShakePosition;
				float num8 = num5 * chargeLaserBounceShakeRotation;
				chargeLaserShakeFrom = chargeLaserShakeTo;
				chargeLaserShakeTo = Random.insideUnitSphere * num7;
				chargeLaserShakeRotationFrom = chargeLaserShakeRotationTo;
				chargeLaserShakeRotationTo = Random.insideUnitSphere * num8;
			}
			float num9 = Mathf.Clamp01(chargeLaserShakeTimer / num6);
			val = Vector3.Lerp(chargeLaserShakeFrom, chargeLaserShakeTo, num9);
			val2 = Vector3.Lerp(chargeLaserShakeRotationFrom, chargeLaserShakeRotationTo, num9);
		}
		Quaternion targetRotation = laserMeshBaseRotation;
		if (meshTiltTargetValid)
		{
			Transform parent = chargeLaserMesh.parent;
			Vector3 val3 = (Object.op_Implicit((Object)(object)parent) ? parent.InverseTransformPoint(meshTiltTargetWorld) : meshTiltTargetWorld) - chargeLaserBasePosition;
			Vector3 normalized = val3.normalized;
			if (normalized.sqrMagnitude > 0.0001f)
			{
				Quaternion val4 = Quaternion.FromToRotation(laserMeshBaseRotation * Vector3.down, normalized) * laserMeshBaseRotation;
				targetRotation = Quaternion.RotateTowards(laserMeshBaseRotation, val4, laserMeshTiltMaxAngle);
			}
		}
		Quaternion val5 = SemiFunc.SpringQuaternionGet(laserMeshTiltSpring, targetRotation);
		chargeLaserMesh.localPosition = chargeLaserBasePosition + val;
		chargeLaserMesh.localRotation = val5 * Quaternion.Euler(val2);
	}

	private void SyncScanEntries()
	{
		for (int num = scanOrder.Count - 1; num >= 0; num--)
		{
			ItemBattery itemBattery = scanOrder[num];
			if (!Object.op_Implicit((Object)(object)itemBattery) || !itemsCharging.Contains(itemBattery))
			{
				scanColliders.Remove(itemBattery);
				scanColliderIndex.Remove(itemBattery);
				scanOrder.RemoveAt(num);
				if (scanCursor > num)
				{
					scanCursor--;
				}
			}
		}
		foreach (ItemBattery item in itemsCharging)
		{
			if (Object.op_Implicit((Object)(object)item) && !scanColliders.ContainsKey(item))
			{
				List<Collider> list = BuildColliderList(item);
				ShuffleList(list);
				scanColliders[item] = list;
				scanColliderIndex[item] = 0;
				scanOrder.Add(item);
			}
		}
	}

	private void AdvanceScan()
	{
		if (scanOrder.Count == 0)
		{
			scanCurrentCollider = null;
			scanCurrentItem = null;
			return;
		}
		for (int i = 0; i < scanOrder.Count; i++)
		{
			if (scanCursor >= scanOrder.Count)
			{
				scanCursor = 0;
			}
			ItemBattery itemBattery = scanOrder[scanCursor];
			scanCursor = (scanCursor + 1) % scanOrder.Count;
			if (Object.op_Implicit((Object)(object)itemBattery) && scanColliders.TryGetValue(itemBattery, out var value) && value.Count != 0)
			{
				int num = scanColliderIndex[itemBattery] % value.Count;
				Collider val = value[num];
				scanColliderIndex[itemBattery] = (num + 1) % value.Count;
				if (Object.op_Implicit((Object)(object)val))
				{
					scanCurrentCollider = val;
					scanCurrentItem = itemBattery;
					return;
				}
			}
		}
		scanCurrentCollider = null;
		scanCurrentItem = null;
	}

	private List<Collider> BuildColliderList(ItemBattery _item)
	{
		List<Collider> list = new List<Collider>();
		Collider[] componentsInChildren = ((Component)_item).GetComponentsInChildren<Collider>();
		foreach (Collider val in componentsInChildren)
		{
			if (Object.op_Implicit((Object)(object)val) && val.enabled && ((Component)val).gameObject.activeInHierarchy && !val.isTrigger && (val is BoxCollider || val is SphereCollider || val is CapsuleCollider))
			{
				list.Add(val);
			}
		}
		return list;
	}

	private void ShuffleList<T>(List<T> _list)
	{
		for (int num = _list.Count - 1; num > 0; num--)
		{
			int num2 = Random.Range(0, num + 1);
			int index = num;
			int index2 = num2;
			T val = _list[num2];
			T val2 = _list[num];
			T val3 = (_list[index] = val);
			val3 = (_list[index2] = val2);
		}
	}

	private void AnimateChargeBar()
	{
		//IL_008a: Unknown result type (might be due to invalid IL or missing references)
		if (Object.op_Implicit((Object)(object)chargeBar) && !Mathf.Approximately(chargeScale, chargeScaleTarget))
		{
			chargeCurveTime += Time.deltaTime;
			chargeScale = Mathf.Lerp(chargeScale, chargeScaleTarget, chargeCurve.Evaluate(chargeCurveTime));
			chargeBar.localScale = new Vector3(chargeScale * chargeBarMaxScale.x, chargeBarMaxScale.y, chargeBarMaxScale.z);
		}
	}

	private void DestroyCrystal()
	{
		//IL_0037: Unknown result type (might be due to invalid IL or missing references)
		//IL_003d: Unknown result type (might be due to invalid IL or missing references)
		if (crystals.Count >= 1 && SemiFunc.IsMasterClientOrSingleplayer())
		{
			if (SemiFunc.IsMultiplayer())
			{
				photonView.RPC("ChargingStationCrystalBrokenRPC", (RpcTarget)3, Array.Empty<object>());
			}
			else
			{
				ChargingStationCrystalBrokenRPC();
			}
		}
	}

	[PunRPC]
	private void ChargingStationCrystalBrokenRPC(PhotonMessageInfo _info = default(PhotonMessageInfo))
	{
		//IL_0000: Unknown result type (might be due to invalid IL or missing references)
		//IL_0074: Unknown result type (might be due to invalid IL or missing references)
		//IL_0079: Unknown result type (might be due to invalid IL or missing references)
		//IL_0083: Unknown result type (might be due to invalid IL or missing references)
		//IL_0089: Unknown result type (might be due to invalid IL or missing references)
		//IL_0093: Unknown result type (might be due to invalid IL or missing references)
		//IL_0098: Unknown result type (might be due to invalid IL or missing references)
		//IL_009d: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a9: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ba: Unknown result type (might be due to invalid IL or missing references)
		//IL_00cb: Unknown result type (might be due to invalid IL or missing references)
		//IL_010c: Unknown result type (might be due to invalid IL or missing references)
		if (!SemiFunc.MasterOnlyRPC(_info))
		{
			return;
		}
		chargeInt = Mathf.Max(chargeInt - 1, 0);
		StatsManager.instance.runStats["chargingStationCharge"] = chargeInt;
		StatsManager.instance.SetItemPurchase(item, StatsManager.instance.GetItemPurchased(item) - 1);
		if (crystals.Count != 0)
		{
			Transform val = crystals[0];
			Vector3 position = Vector3.zero;
			if (Object.op_Implicit((Object)(object)val))
			{
				position = val.position + val.up * 0.1f;
				((Component)lightParticle).transform.position = position;
				((Component)fireflyParticles).transform.position = position;
				((Component)bitsParticles).transform.position = position;
			}
			lightParticle.Play();
			fireflyParticles.Play();
			bitsParticles.Play();
			crystals.RemoveAt(0);
			if (Object.op_Implicit((Object)(object)val))
			{
				soundPowerCrystalBreak.Play(position);
				Object.Destroy((Object)(object)((Component)val).gameObject);
			}
			if (crystals.Count == 0)
			{
				OutOfCrystalsShutdown();
			}
		}
	}

	public ChargingStation()
	{
		//IL_0011: Unknown result type (might be due to invalid IL or missing references)
		//IL_0016: Unknown result type (might be due to invalid IL or missing references)
		//IL_0108: Unknown result type (might be due to invalid IL or missing references)
		//IL_010d: Unknown result type (might be due to invalid IL or missing references)
	}
}
