using System.Collections;
using Photon.Pun;
using Platforms;
using UnityEngine;
using UnityEngine.SceneManagement;

public class DebugComputerCheck : MonoBehaviour
{
	public enum ServerMode
	{
		Normal,
		Local,
		Dev
	}

	public enum StartMode
	{
		Normal,
		SinglePlayer,
		Multiplayer
	}

	public SemiFunc.User DebugUser;

	public static DebugComputerCheck instance;

	public bool DebugDisable;

	public StartMode Mode;

	public string SaveFile;

	public string LobbyName;

	[Space]
	[Tooltip("Select the photon app ids to use for multiplayer debugging.")]
	public ServerMode serverMode;

	public string serverAddress;

	public int serverPort;

	[Space]
	[Tooltip("What should be the behaviour be for random matchmaking?")]
	public GameManager.RandomMatchmakingModes matchmakingMode;

	[Range(1f, 20f)]
	public int maxPlayers = 6;

	public bool LevelDebug = true;

	public bool DeathLevelChange = true;

	public Level LevelOverride;

	public PrefabRef StartRoomOverride;

	public bool ModuleOverrideActive = true;

	public bool ModuleOverrideLevel = true;

	public PrefabRef ModuleOverride;

	public bool ModuleCountActive;

	public int ModuleCount = 1;

	public float LevelSizeMultiplier = 1f;

	public int LevelsCompleted;

	public bool EnemyDebug = true;

	public EnemySetup[] EnemyOverride;

	public float EnemyEnableTimeOverride;

	public float EnemyDisableTimeOverride;

	public bool EnemyDisable;

	public bool EnemyNoVision;

	public bool EnemySpawnClose;

	public bool EnemyDespawnClose;

	public bool EnemyInvestigates;

	public bool EnemyShortActionTimer;

	public bool EnemyNoSpawnedPause;

	public bool EnemyNoSpawnIdlePause;

	public bool EnemyNoGrabMaxTime;

	public bool EnemyEasyGrab;

	public bool PlayerDebug;

	public bool InfiniteEnergy;

	public bool InfiniteDeathHead;

	public bool GodMode;

	public bool NoTumbleMode;

	public bool DisableOvercharge;

	public bool DebugVoice;

	public bool DebugMapActive;

	public bool DebugTinyCrown;

	public bool DebugSlowMouth;

	public bool PowerGrabber;

	public bool StickyGrabber;

	public bool ShowSelf;

	public bool ToggleMute;

	public bool ItemDebug;

	public bool InfiniteBattery;

	[Space]
	public bool CosmeticReset;

	public bool CosmeticUnlockAll;

	public bool DisableItemIconCache;

	public bool OtherDebug;

	public GameManager.GameEvents GameEvent;

	public ValuableDirector.ValuableDebug valuableDebug;

	public ValuableDirector.CosmeticWorldObjectDebug cosmeticWorldObject;

	public bool DisableMusic;

	public bool DisableLoadingLevelAnimation;

	public bool DisableMoonAnimation;

	public bool DisableResultScreen;

	public bool DisableSplashScreen = true;

	public bool LowHaul;

	public bool SimulateLag;

	public bool DebugShopkeeper;

	public bool WipDebug;

	public bool WipCosmetic;

	public bool WipEnemy;

	public bool WipItem;

	public bool WipLevel;

	public bool WipModule;

	public bool WipValuable;

	public bool StatsDebug;

	public int Currency;

	public bool EmptyBatteries;

	public int StartCrystals = 1;

	public bool BuyAllItems;

	private bool wasShowSelf;

	private string sceneName;

	[RuntimeInitializeOnLoadMethod(/*Could not decode attribute arguments.*/)]
	private static void RuntimeInitializeOnLoad()
	{
		instance = null;
	}

	private void Awake()
	{
		//IL_0007: Unknown result type (might be due to invalid IL or missing references)
		//IL_000c: Unknown result type (might be due to invalid IL or missing references)
		Scene scene = ((Component)this).gameObject.scene;
		sceneName = scene.name;
		if (IsDebugComputerAllowed() && Object.op_Implicit((Object)(object)PlatformManager.instance) && PlatformManager.instance.developerFlags.debug_script)
		{
			((Behaviour)this).enabled = false;
		}
		else
		{
			((Component)this).gameObject.SetActive(false);
		}
	}

	private void Start()
	{
		if (!(sceneName == "Main"))
		{
			return;
		}
		if (Object.op_Implicit((Object)(object)GameManager.instance))
		{
			GameManager.instance.matchmakingMode = matchmakingMode;
			GameManager.instance.SetMaxPlayers(maxPlayers);
		}
		if (LevelDebug && Object.op_Implicit((Object)(object)RunManager.instance) && !SemiFunc.IsSplashScreen() && !SemiFunc.IsMainMenu() && !SemiFunc.RunIsTutorial() && !SemiFunc.RunIsRecording())
		{
			if (SemiFunc.IsMasterClientOrSingleplayer() && LevelsCompleted > 0)
			{
				RunManager.instance.levelsCompleted = LevelsCompleted;
				RunManager.instance.UpdateMoonLevel();
			}
			if (SemiFunc.IsMasterClientOrSingleplayer() && !SemiFunc.RunIsLobbyMenu() && Object.op_Implicit((Object)(object)LevelGenerator.Instance))
			{
				if (StartRoomOverride != null && StartRoomOverride.IsValid())
				{
					LevelGenerator.Instance.DebugStartRoom = StartRoomOverride;
				}
				LevelGenerator.Instance.DebugLevelSize = LevelSizeMultiplier;
				if (ModuleOverrideActive && ModuleOverride != null && ModuleOverride.IsValid())
				{
					LevelGenerator.Instance.DebugModule = ModuleOverride;
					switch (SemiFunc.GetModuleTypeFromName(((Object)ModuleOverride.Prefab).name))
					{
					case Module.Type.DeadEnd:
						LevelGenerator.Instance.DebugDeadEnd = true;
						LevelGenerator.Instance.DebugAmount = 1;
						break;
					case Module.Type.Extraction:
						LevelGenerator.Instance.DebugExtraction = true;
						LevelGenerator.Instance.DebugAmount = 1;
						break;
					case Module.Type.Mega:
						LevelGenerator.Instance.DebugMega = true;
						if (LevelGenerator.Instance.DebugAmount <= 0)
						{
							LevelGenerator.Instance.DebugAmount = 1;
						}
						break;
					case Module.Type.Normal:
						LevelGenerator.Instance.DebugNormal = true;
						break;
					case Module.Type.Passage:
						LevelGenerator.Instance.DebugPassage = true;
						LevelGenerator.Instance.DebugAmount = 6;
						break;
					case Module.Type.Special:
						LevelGenerator.Instance.DebugSpecial = true;
						break;
					}
				}
				if (ModuleCountActive && ModuleCount > 0)
				{
					LevelGenerator.Instance.DebugAmount = ModuleCount;
				}
			}
		}
		if (EnemyDebug)
		{
			if (EnemyDisable && Object.op_Implicit((Object)(object)LevelGenerator.Instance))
			{
				LevelGenerator.Instance.DebugNoEnemy = true;
			}
			if (Object.op_Implicit((Object)(object)EnemyDirector.instance))
			{
				if (EnemyEasyGrab)
				{
					EnemyDirector.instance.debugEasyGrab = true;
				}
				if (EnemySpawnClose)
				{
					EnemyDirector.instance.debugSpawnClose = true;
				}
				if (EnemyDespawnClose)
				{
					EnemyDirector.instance.debugDespawnClose = true;
				}
				if (EnemyInvestigates)
				{
					EnemyDirector.instance.debugInvestigate = true;
				}
				if (EnemyShortActionTimer)
				{
					EnemyDirector.instance.debugShortActionTimer = true;
				}
				if (EnemyNoSpawnedPause)
				{
					EnemyDirector.instance.debugNoSpawnedPause = true;
				}
				if (EnemyNoSpawnIdlePause)
				{
					EnemyDirector.instance.debugNoSpawnIdlePause = true;
				}
				if (EnemyNoGrabMaxTime)
				{
					EnemyDirector.instance.debugNoGrabMaxTime = true;
				}
				if (EnemyOverride.Length != 0)
				{
					EnemyDirector.instance.debugEnemy = EnemyOverride;
					EnemyDirector.instance.debugEnemyEnableTime = EnemyEnableTimeOverride;
					EnemyDirector.instance.debugEnemyDisableTime = EnemyDisableTimeOverride;
				}
			}
		}
		if (PlayerDebug)
		{
			if (InfiniteEnergy && Object.op_Implicit((Object)(object)PlayerController.instance))
			{
				PlayerController.instance.DebugEnergy = true;
			}
			if (NoTumbleMode && Object.op_Implicit((Object)(object)PlayerController.instance))
			{
				PlayerController.instance.DebugNoTumble = true;
			}
			if (DisableOvercharge && Object.op_Implicit((Object)(object)PlayerController.instance))
			{
				PlayerController.instance.DebugDisableOvercharge = true;
			}
			if (DebugVoice)
			{
				((MonoBehaviour)this).StartCoroutine(VoiceUpdate());
			}
			if (DebugMapActive && Object.op_Implicit((Object)(object)Map.Instance))
			{
				Map.Instance.debugActive = true;
			}
			if (StickyGrabber || PowerGrabber)
			{
				((MonoBehaviour)this).StartCoroutine(PhysGrabber());
			}
		}
		if (ItemDebug && InfiniteBattery && Object.op_Implicit((Object)(object)RoundDirector.instance))
		{
			RoundDirector.instance.debugInfiniteBattery = true;
		}
		if (OtherDebug)
		{
			if (Object.op_Implicit((Object)(object)GameManager.instance) && GameEvent != GameManager.instance.currentGameEvent)
			{
				GameManager.instance.GameEventSet(GameEvent);
			}
			if (Object.op_Implicit((Object)(object)ValuableDirector.instance))
			{
				ValuableDirector.instance.valuableDebug = valuableDebug;
				ValuableDirector.instance.cosmeticWorldObjectDebug = cosmeticWorldObject;
			}
			if (DisableMusic)
			{
				if (Object.op_Implicit((Object)(object)LevelMusic.instance))
				{
					LevelMusic.instance.debugDisabled = true;
				}
				if (Object.op_Implicit((Object)(object)ConstantMusic.instance))
				{
					((Component)ConstantMusic.instance).gameObject.SetActive(false);
				}
				if (Object.op_Implicit((Object)(object)MusicEnemyNear.instance))
				{
					((Component)MusicEnemyNear.instance).gameObject.SetActive(false);
				}
			}
			if (DisableLoadingLevelAnimation && Object.op_Implicit((Object)(object)LoadingUI.instance))
			{
				LoadingUI.instance.debugDisableLevelAnimation = true;
			}
			if (DisableMoonAnimation && Object.op_Implicit((Object)(object)MoonUI.instance))
			{
				MoonUI.instance.debugDisable = true;
			}
			if (DisableResultScreen && Object.op_Implicit((Object)(object)ResultScreenUI.instance))
			{
				ResultScreenUI.instance.debugSkip = true;
			}
			if (LowHaul && Object.op_Implicit((Object)(object)RoundDirector.instance))
			{
				RoundDirector.instance.debugLowHaul = true;
			}
			if (SimulateLag)
			{
				((MonoBehaviour)this).StartCoroutine(SimulateLagUpdate());
			}
			if (DebugShopkeeper)
			{
				((MonoBehaviour)this).StartCoroutine(DebugShopkeeperUpdate());
			}
		}
		((MonoBehaviour)this).StartCoroutine(StatsUpdate());
		((MonoBehaviour)this).StartCoroutine(AfterLevelGen());
	}

	private void Update()
	{
		if (!LevelGenerator.Instance.Generated || !(sceneName == "Main"))
		{
			return;
		}
		if (PlayerDebug && ShowSelf)
		{
			if (Object.op_Implicit((Object)(object)PlayerAvatar.instance))
			{
				PlayerAvatar.instance.playerAvatarVisuals.ShowSelfOverride();
				PhysGrabBeam physGrabBeam = PlayerAvatar.instance.physGrabber?.physGrabBeamComponent;
				if (Object.op_Implicit((Object)(object)physGrabBeam) && (Object)(object)physGrabBeam.PhysGrabPointOrigin != (Object)(object)physGrabBeam.PhysGrabPointOriginClient)
				{
					PlayerAvatar.instance.physGrabber.SetThirdPerson(_state: true);
				}
				if (Object.op_Implicit((Object)(object)PlayerAvatar.instance.flashlightController) && PlayerAvatar.instance.flashlightController.toolBackAway.Active)
				{
					PlayerAvatar.instance.flashlightController.SetThirdPerson(_state: true);
				}
				wasShowSelf = true;
			}
		}
		else if (wasShowSelf)
		{
			if (Object.op_Implicit((Object)(object)PlayerAvatar.instance))
			{
				PhysGrabBeam physGrabBeam2 = PlayerAvatar.instance.physGrabber?.physGrabBeamComponent;
				if (Object.op_Implicit((Object)(object)physGrabBeam2) && (Object)(object)physGrabBeam2.PhysGrabPointOrigin != (Object)(object)physGrabBeam2.PhysGrabPointOriginLocal)
				{
					PlayerAvatar.instance.physGrabber.SetThirdPerson(_state: false);
				}
				if (Object.op_Implicit((Object)(object)PlayerAvatar.instance.flashlightController) && !PlayerAvatar.instance.flashlightController.toolBackAway.Active)
				{
					PlayerAvatar.instance.flashlightController.SetThirdPerson(_state: false);
				}
			}
			wasShowSelf = false;
		}
		if (PlayerDebug && InfiniteDeathHead && Object.op_Implicit((Object)(object)SpectateCamera.instance))
		{
			SpectateCamera.instance.headEnergy = 1f;
			SpectateCamera.instance.headEnergyEnough = true;
			SpectateCamera.instance.headEnergyPauseTimer = 1f;
		}
	}

	private bool IsDebugComputerAllowed()
	{
		bool result = false;
		if (DebugUser != SemiFunc.User.None && Object.op_Implicit((Object)(object)PlatformManager.instance) && PlatformManager.instance.developerUser == DebugUser)
		{
			result = true;
		}
		return result;
	}

	private IEnumerator SimulateLagUpdate()
	{
		while (!LevelGenerator.Instance.Generated)
		{
			yield return (object)new WaitForSeconds(0.1f);
		}
		((Behaviour)PunManager.instance.lagSimulationGui).enabled = true;
	}

	private IEnumerator AfterLevelGen()
	{
		while (!LevelGenerator.Instance.Generated)
		{
			yield return (object)new WaitForSeconds(0.1f);
		}
		if (EnemyDebug && EnemyNoVision && Object.op_Implicit((Object)(object)PunManager.instance) && Object.op_Implicit((Object)(object)PlayerController.instance))
		{
			if (SemiFunc.IsMultiplayer())
			{
				PunManager.instance.photonView.RPC("TesterNoAggroCommandRPC", (RpcTarget)2, new object[2]
				{
					PlayerController.instance.playerSteamID,
					true
				});
			}
			else
			{
				PunManager.instance.TesterNoAggroCommandRPC(PlayerController.instance.playerSteamID, _state: true);
			}
		}
		if (PlayerDebug && ToggleMute && Object.op_Implicit((Object)(object)DataDirector.instance) && SemiFunc.RunIsLobbyMenu())
		{
			DataDirector.instance.toggleMute = true;
		}
		if (StatsDebug && EmptyBatteries)
		{
			StatsManager.instance.EmptyAllBatteries();
		}
	}

	private IEnumerator StatsUpdate()
	{
		if (StatsDebug)
		{
			while (!Object.op_Implicit((Object)(object)StatsManager.instance) || !StatsManager.instance.statsSynced || !Object.op_Implicit((Object)(object)PunManager.instance.statsManager))
			{
				yield return (object)new WaitForSeconds(0.1f);
			}
			if (Currency > 0)
			{
				SemiFunc.StatSetRunCurrency(Currency);
			}
			if (BuyAllItems)
			{
				StatsManager.instance.BuyAllItems();
			}
			if (StartCrystals != 1)
			{
				StatsManager.instance.itemsPurchased["Item Power Crystal"] = StartCrystals;
			}
		}
	}

	private IEnumerator VoiceUpdate()
	{
		while (!LevelGenerator.Instance.Generated)
		{
			yield return (object)new WaitForSeconds(0.1f);
		}
		foreach (PlayerAvatar _player in GameDirector.instance.PlayerList)
		{
			while (!Object.op_Implicit((Object)(object)_player.voiceChat))
			{
				yield return (object)new WaitForSeconds(0.1f);
			}
			_player.voiceChat.SetDebug();
		}
	}

	private IEnumerator DebugShopkeeperUpdate()
	{
		while (!LevelGenerator.Instance.Generated)
		{
			yield return (object)new WaitForSeconds(0.1f);
		}
		while (!Object.op_Implicit((Object)(object)ShopKeeper.instance))
		{
			yield return (object)new WaitForSeconds(0.1f);
		}
		ShopKeeper.instance.debugRuckus = true;
	}

	private IEnumerator PhysGrabber()
	{
		while (!LevelGenerator.Instance.Generated)
		{
			yield return (object)new WaitForSeconds(0.1f);
		}
		if (StickyGrabber)
		{
			PlayerController.instance.playerAvatarScript.physGrabber.debugStickyGrabber = true;
		}
		if (PowerGrabber)
		{
			PlayerController.instance.playerAvatarScript.physGrabber.grabStrength = 5f;
		}
	}
}
