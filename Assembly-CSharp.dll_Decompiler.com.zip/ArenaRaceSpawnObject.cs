using System;

[Serializable]
public class ArenaRaceSpawnObject
{
	public PrefabRef prefab;

	public ValuableVolume.Type volumeType;
}
