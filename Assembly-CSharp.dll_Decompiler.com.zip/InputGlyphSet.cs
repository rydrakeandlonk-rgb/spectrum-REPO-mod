using System;
using System.Collections.Generic;
using TMPro;
using UnityEngine;

[CreateAssetMenu(fileName = "InputGlyphSet", menuName = "Input Glyphs/Glyph Set")]
public class InputGlyphSet : ScriptableObject
{
	[Serializable]
	public class Entry
	{
		public string glyphName;

		public Sprite sprite;
	}

	[Tooltip("Which input device family these glyphs represent.")]
	public InputDeviceType deviceType;

	[Tooltip("TMP sprite asset used for inline <sprite> tags in rich text. Optional; if unset, inline prompts fall back to human-readable text.")]
	public TMP_SpriteAsset spriteAsset;

	[Tooltip("The name TMP uses to address the sprite asset in a tag, e.g. <sprite=\"InputGlyphs_Xbox\" name=\"...\">. Defaults to spriteAsset.name when empty.")]
	public string spriteAssetName;

	[Tooltip("Every glyph in this family, keyed by Kenney sprite name.")]
	public List<Entry> entries = new List<Entry>();

	private Dictionary<string, Sprite> _lookup;

	public string ResolvedSpriteAssetName
	{
		get
		{
			if (!string.IsNullOrEmpty(spriteAssetName))
			{
				return spriteAssetName;
			}
			if (!((Object)(object)spriteAsset != (Object)null))
			{
				return null;
			}
			return ((Object)spriteAsset).name;
		}
	}

	private void OnEnable()
	{
		BuildLookup();
	}

	public void BuildLookup()
	{
		_lookup = new Dictionary<string, Sprite>(entries.Count);
		foreach (Entry entry in entries)
		{
			if (entry != null && !string.IsNullOrEmpty(entry.glyphName) && !((Object)(object)entry.sprite == (Object)null))
			{
				_lookup[entry.glyphName] = entry.sprite;
			}
		}
	}

	public bool HasGlyph(string glyphName)
	{
		if (string.IsNullOrEmpty(glyphName))
		{
			return false;
		}
		if (_lookup == null)
		{
			BuildLookup();
		}
		return _lookup.ContainsKey(glyphName);
	}

	public Sprite GetSprite(string glyphName)
	{
		if (string.IsNullOrEmpty(glyphName))
		{
			return null;
		}
		if (_lookup == null)
		{
			BuildLookup();
		}
		if (!_lookup.TryGetValue(glyphName, out var value))
		{
			return null;
		}
		return value;
	}
}
