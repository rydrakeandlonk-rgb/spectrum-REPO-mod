public enum KnowledgeGlyphSide
{
	Front,
	Right,
	Back,
	Left,
	Top,
	Bottom
}
