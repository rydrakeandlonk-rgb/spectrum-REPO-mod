using System;
using System.Collections.Generic;
using System.Globalization;
using System.Text;
using System.Text.RegularExpressions;

public static class TTSFormatting
{
	public enum Reading
	{
		Automatic,
		Number,
		Digits,
		Fraction,
		Date,
		Time,
		Duration,
		Characters,
		Name
	}

	public struct SpeechPart
	{
		public string displayText;

		public string speechText;
	}

	private class Language
	{
		public string code;

		public char decimalMark;

		public char groupMark;

		public string[] letters;

		public string datePattern;

		public string[] months;

		public string[] days;

		public Dictionary<string, string> terms;

		public Dictionary<string, string> readings;

		public Dictionary<string, string> abbreviations;

		public Dictionary<string, Dictionary<string, string>> measures;
	}

	private static Dictionary<string, Language> languages;

	private const string unreadableMarker = "\ufffd";

	private const string HanSupplementaryPattern = "(?:[\\uD840-\\uD868][\\uDC00-\\uDFFF]|\\uD869[\\uDC00-\\uDEDF]|\\uD869[\\uDF00-\\uDFFF]|[\\uD86A-\\uD87A][\\uDC00-\\uDFFF]|\\uD87B[\\uDC00-\\uDE5F]|\\uD87E[\\uDC00-\\uDE1F]|[\\uD880-\\uD88C][\\uDC00-\\uDFFF]|\\uD88D[\\uDC00-\\uDC7F])";

	private const string HanPattern = "(?:[\\u3400-\\u4DBF\\u4E00-\\u9FFF\\uF900-\\uFAFF]|(?:[\\uD840-\\uD868][\\uDC00-\\uDFFF]|\\uD869[\\uDC00-\\uDEDF]|\\uD869[\\uDF00-\\uDFFF]|[\\uD86A-\\uD87A][\\uDC00-\\uDFFF]|\\uD87B[\\uDC00-\\uDE5F]|\\uD87E[\\uDC00-\\uDE1F]|[\\uD880-\\uD88C][\\uDC00-\\uDFFF]|\\uD88D[\\uDC00-\\uDC7F]))";

	private const string NumberPattern = "[+−－-]?[\\d〇]+(?:[.,．，٬٫'’\\u00a0\\u202f ][\\d〇]+)*";

	private const string CurrencyPattern = "(?:(?:USD|EUR|GBP|JPY|CNY|SEK|DKK|NOK|PLN|RUB|UAH|TRY|KRW|THB|BRL)(?![\\p{L}\\p{M}\\u2F00-\\u2FD5])|R\\$|US\\$|[$€£¥₩₽₺฿])";

	private const string UnitPattern = "(?:(?:kg|km|cm|mm|ml|mL|min|ms|°C|°F|g|m|l|L|h|s)(?![\\p{L}\\p{N}\\u2F00-\\u2FD5])|°|%|٪|％|‰|[人\\u2F08]|本|枚|個|个|名|匹|回|冊|歳|才|杯|台|臺|階|つ(?![\\u3099\\u309B\\uFF9E])|時|分|秒|年|[月\\u2F49]|[日\\u2F47]|か[月\\u2F49]|ヶ[月\\u2F49]|张|張|只|隻|条|條|瓶|명|개|시간|시|살|마리|대|번|잔|권|คน|ช\u0e34\u0e49น)";

	private static readonly Dictionary<string, Regex> patterns = new Dictionary<string, Regex>();

	private static readonly Regex tokens = Pattern("</?(?:b|i|u|s|color|size|font|material|sprite|link|align|alpha|voffset|cspace|mspace|noparse|style)(?:[ =][^<>]*)?/?>|https?://[^\\s<>]+|www\\.[^\\s<>]+|[\\p{L}\\p{N}._%+\\-]+@[\\p{L}\\p{N}.\\-]+\\.[\\p{L}]{2,}|[\\d〇]{4}-[\\d〇]{1,2}-[\\d〇]{1,2}(?![\\d〇])|[\\d〇]{1,2}[/\\.][\\d〇]{1,2}[/\\.][\\d〇]{4}(?![\\d〇])|[\\d〇]{1,3}:[\\d〇]{2}(?::[\\d〇]{2})?(?: ?(?:AM|PM|am|pm))?(?![\\d〇])|(?:\\p{L}\\.){2,}|Dr\\.|Mr\\.|Mrs\\.|Ms\\.|dvs\\.|bzw\\.|(?:(?:USD|EUR|GBP|JPY|CNY|SEK|DKK|NOK|PLN|RUB|UAH|TRY|KRW|THB|BRL)(?![\\p{L}\\p{M}\\u2F00-\\u2FD5])|R\\$|US\\$|[$€£¥₩₽₺฿])\\s*[+−－-]?[\\d〇]+(?:[.,．，٬٫'’\\u00a0\\u202f ][\\d〇]+)*\\s*[–—-]\\s*[+−－-]?[\\d〇]+(?:[.,．，٬٫'’\\u00a0\\u202f ][\\d〇]+)*|(?:(?:(?:USD|EUR|GBP|JPY|CNY|SEK|DKK|NOK|PLN|RUB|UAH|TRY|KRW|THB|BRL)(?![\\p{L}\\p{M}\\u2F00-\\u2FD5])|R\\$|US\\$|[$€£¥₩₽₺฿])\\s*)?[+−－-]?[\\d〇]+(?:[.,．，٬٫'’\\u00a0\\u202f ][\\d〇]+)*(?:\\s*[–—-]\\s*[+−－-]?[\\d〇]+(?:[.,．，٬٫'’\\u00a0\\u202f ][\\d〇]+)*|\\s*/\\s*[\\d〇]+)?(?:\\s*(?:(?:(?:USD|EUR|GBP|JPY|CNY|SEK|DKK|NOK|PLN|RUB|UAH|TRY|KRW|THB|BRL)(?![\\p{L}\\p{M}\\u2F00-\\u2FD5])|R\\$|US\\$|[$€£¥₩₽₺฿])|(?:(?:kg|km|cm|mm|ml|mL|min|ms|°C|°F|g|m|l|L|h|s)(?![\\p{L}\\p{N}\\u2F00-\\u2FD5])|°|%|٪|％|‰|[人\\u2F08]|本|枚|個|个|名|匹|回|冊|歳|才|杯|台|臺|階|つ(?![\\u3099\\u309B\\uFF9E])|時|分|秒|年|[月\\u2F49]|[日\\u2F47]|か[月\\u2F49]|ヶ[月\\u2F49]|张|張|只|隻|条|條|瓶|명|개|시간|시|살|마리|대|번|잔|권|คน|ช\u0e34\u0e49น)))|[+−－-]?[\\d〇]+(?:[.,．，٬٫'’\\u00a0\\u202f ][\\d〇]+)*(?:\\s*[–—-]\\s*[+−－-]?[\\d〇]+(?:[.,．，٬٫'’\\u00a0\\u202f ][\\d〇]+)*|\\s*/\\s*[\\d〇]+)?|(?:(?:USD|EUR|GBP|JPY|CNY|SEK|DKK|NOK|PLN|RUB|UAH|TRY|KRW|THB|BRL)(?![\\p{L}\\p{M}\\u2F00-\\u2FD5])|R\\$|US\\$|[$€£¥₩₽₺฿])\\s*[+−－-]?[\\d〇]+(?:[.,．，٬٫'’\\u00a0\\u202f ][\\d〇]+)*|(?:[\\p{L}\\p{M}_\\u2F00-\\u2FD5]|(?:[\\u3400-\\u4DBF\\u4E00-\\u9FFF\\uF900-\\uFAFF]|(?:[\\uD840-\\uD868][\\uDC00-\\uDFFF]|\\uD869[\\uDC00-\\uDEDF]|\\uD869[\\uDF00-\\uDFFF]|[\\uD86A-\\uD87A][\\uDC00-\\uDFFF]|\\uD87B[\\uDC00-\\uDE5F]|\\uD87E[\\uDC00-\\uDE1F]|[\\uD880-\\uD88C][\\uDC00-\\uDFFF]|\\uD88D[\\uDC00-\\uDC7F])))+(?:[\\p{L}\\p{M}\\p{N}_\\u2F00-\\u2FD5]|(?:[\\u3400-\\u4DBF\\u4E00-\\u9FFF\\uF900-\\uFAFF]|(?:[\\uD840-\\uD868][\\uDC00-\\uDFFF]|\\uD869[\\uDC00-\\uDEDF]|\\uD869[\\uDF00-\\uDFFF]|[\\uD86A-\\uD87A][\\uDC00-\\uDFFF]|\\uD87B[\\uDC00-\\uDE5F]|\\uD87E[\\uDC00-\\uDE1F]|[\\uD880-\\uD88C][\\uDC00-\\uDFFF]|\\uD88D[\\uDC00-\\uDC7F]))|\\uDB40[\\uDD00-\\uDDEF]|(?<=[うかきくけこさしすせそたちつてとはひふへほゝウカキクケコサシスセソタチツテトハヒフヘホワヰヱヲヽ])\u309b|(?<=[はひふへほハヒフヘホ])\u309c|['’‐‑-](?:[\\p{L}\\p{M}\\u2F00-\\u2FD5]|(?:[\\u3400-\\u4DBF\\u4E00-\\u9FFF\\uF900-\\uFAFF]|(?:[\\uD840-\\uD868][\\uDC00-\\uDFFF]|\\uD869[\\uDC00-\\uDEDF]|\\uD869[\\uDF00-\\uDFFF]|[\\uD86A-\\uD87A][\\uDC00-\\uDFFF]|\\uD87B[\\uDC00-\\uDE5F]|\\uD87E[\\uDC00-\\uDE1F]|[\\uD880-\\uD88C][\\uDC00-\\uDFFF]|\\uD88D[\\uDC00-\\uDC7F]))))*|[\\uD800-\\uDBFF][\\uDC00-\\uDFFF]|\\S", RegexOptions.IgnoreCase);

	private static readonly Regex number = Pattern("^(?<value>[+−－-]?[\\d〇]+(?:[.,．，٬٫'’\\u00a0\\u202f ][\\d〇]+)*)$");

	private static readonly Regex quantity = Pattern("^(?<value>[+−－-]?[\\d〇]+(?:[.,．，٬٫'’\\u00a0\\u202f ][\\d〇]+)*)\\s*(?<unit>(?:(?:kg|km|cm|mm|ml|mL|min|ms|°C|°F|g|m|l|L|h|s)(?![\\p{L}\\p{N}\\u2F00-\\u2FD5])|°|%|٪|％|‰|[人\\u2F08]|本|枚|個|个|名|匹|回|冊|歳|才|杯|台|臺|階|つ(?![\\u3099\\u309B\\uFF9E])|時|分|秒|年|[月\\u2F49]|[日\\u2F47]|か[月\\u2F49]|ヶ[月\\u2F49]|张|張|只|隻|条|條|瓶|명|개|시간|시|살|마리|대|번|잔|권|คน|ช\u0e34\u0e49น))$");

	private static readonly Regex currency = Pattern("^(?:(?<unit>(?:(?:USD|EUR|GBP|JPY|CNY|SEK|DKK|NOK|PLN|RUB|UAH|TRY|KRW|THB|BRL)(?![\\p{L}\\p{M}\\u2F00-\\u2FD5])|R\\$|US\\$|[$€£¥₩₽₺฿]))\\s*(?<value>[+−－-]?[\\d〇]+(?:[.,．，٬٫'’\\u00a0\\u202f ][\\d〇]+)*)|(?<value>[+−－-]?[\\d〇]+(?:[.,．，٬٫'’\\u00a0\\u202f ][\\d〇]+)*)\\s*(?<unit>(?:(?:USD|EUR|GBP|JPY|CNY|SEK|DKK|NOK|PLN|RUB|UAH|TRY|KRW|THB|BRL)(?![\\p{L}\\p{M}\\u2F00-\\u2FD5])|R\\$|US\\$|[$€£¥₩₽₺฿])))$");

	private static readonly Regex range = Pattern("^(?<first>[+−－-]?[\\d〇]+(?:[.,．，٬٫'’\\u00a0\\u202f ][\\d〇]+)*)\\s*[–—-]\\s*(?<last>[+−－-]?[\\d〇]+(?:[.,．，٬٫'’\\u00a0\\u202f ][\\d〇]+)*)$");

	private static readonly Regex fraction = Pattern("^(?<first>[+−-]?\\d+)\\s*/\\s*(?<last>\\d+)$");

	private static readonly Regex clock = Pattern("^(\\d{1,3}):(\\d{2})(?::(\\d{2}))?(?: ?(AM|PM))?$", RegexOptions.IgnoreCase);

	private static readonly Regex date = Pattern("^(?:(\\d{4})-(\\d{1,2})-(\\d{1,2})|(\\d{1,2})[/\\.](\\d{1,2})[/\\.](\\d{4}))$");

	private static readonly Regex tags = Pattern("</?(?:b|i|u|s|color|size|font|material|sprite|link|align|alpha|voffset|cspace|mspace|noparse|style)(?:[ =][^<>]*)?/?>", RegexOptions.IgnoreCase);

	private static readonly HashSet<string> abbreviations = new HashSet<string>(StringComparer.OrdinalIgnoreCase)
	{
		"HP", "XP", "TTS", "NPC", "FPS", "AFK", "GG", "CPU", "GPU", "USB",
		"DNA", "ID", "URL", "OMG", "LOL"
	};

	public static List<SpeechPart> GetSpeechParts(string text, string localeCode, Reading reading = Reading.Automatic)
	{
		List<SpeechPart> list = new List<SpeechPart>();
		if (string.IsNullOrEmpty(text))
		{
			return list;
		}
		Language language = LanguageGet(localeCode);
		if (reading != Reading.Automatic)
		{
			list.Add(new SpeechPart
			{
				displayText = text,
				speechText = PhonemeWordPauses(FormatToken(TTSPronunciation.NormalizeSpokenText(text), language, reading))
			});
			return ResolveUnreadableParts(list, text, language);
		}
		int num = 0;
		try
		{
			Match match = tokens.Match(text);
			while (match.Success)
			{
				string text2 = match.Value;
				if (text2.Length <= 2 && text2[0] != '〇' && !char.IsLetterOrDigit(text2, 0))
				{
					string text3 = text.Substring(match.Index, TTSPronunciation.SpokenTextElementLength(text, match.Index));
					if (text3.Length > text2.Length)
					{
						text2 = text3;
					}
				}
				Match match2 = quantity.Match(text2);
				if (match2.Success)
				{
					Group obj = match2.Groups["unit"];
					if (TTSPronunciation.KnownWordContinues(text, match.Index + obj.Index, obj.Length, language.code))
					{
						text2 = text2.Substring(0, obj.Index).TrimEnd();
					}
				}
				string text4 = text.Substring(num, match.Index + text2.Length - num);
				num = match.Index + text2.Length;
				string text5 = TTSPronunciation.NormalizeSpokenText(text2);
				string speech = FormatToken(text5, language, Reading.Automatic);
				if (language.code == "fr")
				{
					speech = FrenchContextSpeech(text, match.Index, text5, speech, language);
				}
				speech = PhonemeWordPauses(speech);
				if (speech.Length == 0 && HasVisibleText(text2) && !tags.IsMatch(text2) && !Pattern("^[\\p{P}]+$").IsMatch(text2))
				{
					speech = UnreadableMarkers(text2);
				}
				if (IsPause(text5) && list.Count > 0)
				{
					SpeechPart value = list[list.Count - 1];
					value.displayText += text4;
					if (!value.speechText.EndsWith(".", StringComparison.Ordinal))
					{
						value.speechText += speech;
					}
					list[list.Count - 1] = value;
				}
				else
				{
					list.Add(new SpeechPart
					{
						displayText = text4,
						speechText = speech
					});
				}
				match = tokens.Match(text, num);
			}
		}
		catch (RegexMatchTimeoutException)
		{
			return ResolveUnreadableParts(new List<SpeechPart>
			{
				new SpeechPart
				{
					displayText = text,
					speechText = PhonemeWordPauses(Characters(text, language))
				}
			}, text, language);
		}
		if (list.Count == 0)
		{
			list.Add(new SpeechPart
			{
				displayText = text,
				speechText = ""
			});
		}
		if (num < text.Length && list.Count > 0 && list[0].displayText != text)
		{
			SpeechPart value2 = list[list.Count - 1];
			value2.displayText += text.Substring(num);
			list[list.Count - 1] = value2;
		}
		return ResolveUnreadableParts(list, text, language);
	}

	public static string GetSpeechText(string text, string localeCode, Reading reading = Reading.Automatic)
	{
		StringBuilder stringBuilder = new StringBuilder();
		foreach (SpeechPart speechPart in GetSpeechParts(text, localeCode, reading))
		{
			if (!string.IsNullOrEmpty(speechPart.speechText))
			{
				if (stringBuilder.Length > 0)
				{
					stringBuilder.Append(' ');
				}
				stringBuilder.Append(speechPart.speechText);
			}
		}
		return stringBuilder.ToString();
	}

	private static string FrenchContextSpeech(string _text, int _index, string _word, string _speech, Language _language)
	{
		if (!Pattern("^[\\p{L}\\p{M}]+(?:['’][\\p{L}\\p{M}]+)*$").IsMatch(_word))
		{
			return _speech;
		}
		_word = _word.ToLowerInvariant();
		string input = TTSPronunciation.NormalizeSpokenText(_text.Substring(Math.Max(0, _index - 96), Math.Min(_index, 96))).ToLowerInvariant();
		if (_word.Length > 3 && _word.EndsWith("ent", StringComparison.Ordinal) && Pattern("(?:^|[^\\p{L}\\p{M}])(?:ils|elles)(?:[ \\t\\u00a0\\u202f]+(?:ne|me|te|se|le|la|les|lui|leur|nous|vous|en|y)){0,4}[ \\t\\u00a0\\u202f]+$").IsMatch(input))
		{
			_word = _word.Substring(0, _word.Length - 2);
			_speech = SpokenWord(_word, _language);
		}
		int num = Math.Max(_word.LastIndexOf('\''), _word.LastIndexOf('’'));
		if (num > 0 && num + 1 < _word.Length)
		{
			string text = "";
			switch (_word.Substring(0, num))
			{
			case "c":
				text = "s";
				break;
			case "d":
				text = "d";
				break;
			case "j":
				text = "Z";
				break;
			case "l":
				text = "l";
				break;
			case "m":
				text = "m";
				break;
			case "n":
				text = "n";
				break;
			case "s":
				text = "s";
				break;
			case "t":
				text = "t";
				break;
			case "qu":
				text = "k";
				break;
			}
			if (text.Length > 0)
			{
				string text2 = SpokenWord(_word.Substring(num + 1), _language);
				if (text2.StartsWith("[", StringComparison.Ordinal) && text2.EndsWith("]", StringComparison.Ordinal) && text2.IndexOf(']') == text2.Length - 1)
				{
					_speech = "[" + text + text2.Substring(1);
				}
			}
		}
		if ("aeiouàâéèêëîïôùûœæ".IndexOf(_word[0]) >= 0)
		{
			switch (_word)
			{
			default:
				if (!_word.StartsWith("onzièm", StringComparison.Ordinal) && _speech.StartsWith("[", StringComparison.Ordinal) && _speech.EndsWith("]", StringComparison.Ordinal) && _speech.IndexOf(']') == _speech.Length - 1)
				{
					Match match = Pattern("(?<![\\p{L}\\p{M}])(?<word>[\\p{L}\\p{M}]+)[ \\t\\u00a0\\u202f]+$").Match(input);
					if (!match.Success)
					{
						return _speech;
					}
					string value = match.Groups["word"].Value;
					string text3 = "";
					switch (value)
					{
					case "les":
					case "des":
					case "mes":
					case "tes":
					case "ses":
					case "ces":
					case "nos":
					case "vos":
					case "leurs":
					case "aux":
					case "quels":
					case "quelles":
					case "ils":
					case "elles":
					case "nous":
					case "vous":
					case "dans":
					case "sans":
					case "chez":
					case "sous":
					case "très":
						text3 = "z";
						break;
					case "un":
					case "aucun":
					case "mon":
					case "ton":
					case "son":
					case "on":
					case "en":
						text3 = "n";
						break;
					}
					if (text3.Length != 0)
					{
						return "[" + text3 + _speech.Substring(1);
					}
					return _speech;
				}
				break;
			case "et":
			case "ou":
			case "oui":
			case "onze":
				break;
			}
		}
		return _speech;
	}

	private static string PhonemeWordPauses(string _speech)
	{
		return _speech.Replace("]", "  ]");
	}

	private static string FormatToken(string _text, Language _language, Reading _reading)
	{
		_text = _text.Trim();
		if (_text.Length == 0)
		{
			return "";
		}
		if (tags.IsMatch(_text) && tags.Replace(_text, "").Length == 0)
		{
			return "";
		}
		switch (_reading)
		{
		case Reading.Characters:
			return Characters(_text, _language);
		case Reading.Digits:
			return Digits(_text, _language);
		case Reading.Name:
			return Identifier(_text, _language);
		case Reading.Number:
			return Number(_text, _language);
		default:
		{
			if (IsPause(_text))
			{
				switch (_text)
				{
				default:
					return ".";
				case "!":
				case "！":
					return "!";
				case "?":
				case "؟":
				case "？":
					return "?";
				case ",":
				case ";":
				case "،":
				case "、":
				case "，":
					return ",";
				}
			}
			if (_text.StartsWith("http://", StringComparison.OrdinalIgnoreCase) || _text.StartsWith("https://", StringComparison.OrdinalIgnoreCase) || _text.StartsWith("www.", StringComparison.OrdinalIgnoreCase))
			{
				if (Uri.TryCreate((_text.StartsWith("www.", StringComparison.OrdinalIgnoreCase) ? ("https://" + _text) : _text).TrimEnd(new char[5] { '.', ',', '!', '?', ')' }), UriKind.Absolute, out Uri result))
				{
					try
					{
						return Term("link", _language) + " " + Address(result.IdnHost, _language);
					}
					catch (UriFormatException)
					{
						return Term("link", _language) + " " + Address(_text, _language);
					}
				}
				return Term("link", _language);
			}
			if (_text.IndexOf('@') > 0 && _text.IndexOf('.') > _text.IndexOf('@'))
			{
				return Term("email", _language) + " " + Address(_text, _language);
			}
			if (_reading == Reading.Date || date.IsMatch(_text))
			{
				string text = Date(_text, _language);
				if (text != null)
				{
					return text;
				}
				return LiteralSymbols(_text, _language);
			}
			if (_reading == Reading.Time || _reading == Reading.Duration || clock.IsMatch(_text))
			{
				string text2 = Clock(_text, _language, _reading == Reading.Duration);
				if (text2 != null)
				{
					return text2;
				}
				return LiteralSymbols(_text, _language);
			}
			Match match = Pattern("^(?:(?<unit>(?:(?:USD|EUR|GBP|JPY|CNY|SEK|DKK|NOK|PLN|RUB|UAH|TRY|KRW|THB|BRL)(?![\\p{L}\\p{M}\\u2F00-\\u2FD5])|R\\$|US\\$|[$€£¥₩₽₺฿]))\\s*(?<first>[+−－-]?[\\d〇]+(?:[.,．，٬٫'’\\u00a0\\u202f ][\\d〇]+)*)\\s*[–—-]\\s*(?<last>[+−－-]?[\\d〇]+(?:[.,．，٬٫'’\\u00a0\\u202f ][\\d〇]+)*)|(?<first>[+−－-]?[\\d〇]+(?:[.,．，٬٫'’\\u00a0\\u202f ][\\d〇]+)*)\\s*[–—-]\\s*(?<last>[+−－-]?[\\d〇]+(?:[.,．，٬٫'’\\u00a0\\u202f ][\\d〇]+)*)\\s*(?<unit>(?:(?:USD|EUR|GBP|JPY|CNY|SEK|DKK|NOK|PLN|RUB|UAH|TRY|KRW|THB|BRL)(?![\\p{L}\\p{M}\\u2F00-\\u2FD5])|R\\$|US\\$|[$€£¥₩₽₺฿])|(?:(?:kg|km|cm|mm|ml|mL|min|ms|°C|°F|g|m|l|L|h|s)(?![\\p{L}\\p{N}\\u2F00-\\u2FD5])|°|%|٪|％|‰|[人\\u2F08]|本|枚|個|个|名|匹|回|冊|歳|才|杯|台|臺|階|つ(?![\\u3099\\u309B\\uFF9E])|時|分|秒|年|[月\\u2F49]|[日\\u2F47]|か[月\\u2F49]|ヶ[月\\u2F49]|张|張|只|隻|条|條|瓶|명|개|시간|시|살|마리|대|번|잔|권|คน|ช\u0e34\u0e49น)))$").Match(_text);
			if (match.Success)
			{
				string value = match.Groups["first"].Value;
				string value2 = match.Groups["last"].Value;
				string value3 = match.Groups["unit"].Value;
				return FormatToken(value + " " + value3, _language, Reading.Automatic) + " " + Term("to", _language) + " " + FormatToken(value2 + " " + value3, _language, Reading.Automatic);
			}
			Match match2 = currency.Match(_text);
			if (match2.Success)
			{
				return Measure(match2.Groups["value"].Value, CurrencyCode(match2.Groups["unit"].Value, _language), _language);
			}
			Match match3 = quantity.Match(_text);
			if (match3.Success)
			{
				string value4 = match3.Groups["value"].Value;
				string text3 = match3.Groups["unit"].Value;
				if (text3 == "٪" || text3 == "％")
				{
					text3 = "%";
				}
				string text4 = Counter(value4, text3, _language);
				if (text4 != null)
				{
					return text4;
				}
				string text5 = value4;
				string unit;
				if (text3 == "l")
				{
					unit = "L";
				}
				else
				{
					unit = ((text3 == "mL") ? "ml" : text3);
				}
				return Measure(text5, unit, _language);
			}
			Match match4 = fraction.Match(_text);
			if (match4.Success)
			{
				string text6 = Number(match4.Groups["first"].Value, _language);
				string text7 = Number(match4.Groups["last"].Value, _language);
				if (_reading != Reading.Fraction)
				{
					return text6 + " " + Term("slash", _language) + " " + text7;
				}
				if (_language.code == "ja" || _language.code == "ko" || _language.code.StartsWith("zh", StringComparison.Ordinal))
				{
					return text7 + " " + Term("over", _language) + " " + text6;
				}
				return text6 + " " + Term("over", _language) + " " + text7;
			}
			Match match5 = range.Match(_text);
			if (match5.Success)
			{
				return Number(match5.Groups["first"].Value, _language) + " " + Term("to", _language) + " " + Number(match5.Groups["last"].Value, _language);
			}
			if (number.IsMatch(_text))
			{
				return Number(_text, _language);
			}
			if (_language.abbreviations.TryGetValue(_text, out var value5))
			{
				return Label(value5, _language);
			}
			if (abbreviations.Contains(_text) || Pattern("^(?:\\p{L}\\.){2,}$").IsMatch(_text))
			{
				return Characters(_text.Replace(".", ""), _language);
			}
			if (_language.code.StartsWith("zh", StringComparison.Ordinal))
			{
				Match match6 = Pattern("^第(?<value>\\d+)(?<suffix>[\\u3400-\\u4DBF\\u4E00-\\u9FFF\\uF900-\\uFAFF]*)$").Match(_text);
				if (match6.Success && int.TryParse(match6.Groups["value"].Value, NumberStyles.None, CultureInfo.InvariantCulture, out var result2))
				{
					return Words("第" + TTSPronunciation.NumberWordsForSpeech(result2, _language.code) + match6.Groups["suffix"].Value, _language);
				}
			}
			if (_text.IndexOf('/') >= 0)
			{
				return LiteralSymbols(_text, _language);
			}
			if (_language.code == "ja" && HasDigit(_text) && HasLetter(_text) && TTSPronunciation.TryGetPhonemes(_text, _language.code, out var _phonemes))
			{
				return "[" + _phonemes + "]";
			}
			if (HasDigit(_text) && HasLetter(_text))
			{
				return Identifier(_text, _language);
			}
			if (_text.Length == 1 && Symbol(_text[0]) != null)
			{
				return Term(Symbol(_text[0]), _language);
			}
			return Words(_text, _language);
		}
		}
	}

	private static string Number(string _text, Language _language)
	{
		if (!NumberSplit(_text, _language, out var _integer, out var _fraction, out var _sign))
		{
			return LiteralSymbols(_text, _language);
		}
		StringBuilder stringBuilder = new StringBuilder();
		if (_sign != ' ')
		{
			stringBuilder.Append(Term((_sign == '+') ? "plus" : "minus", _language)).Append(' ');
		}
		stringBuilder.Append(Integer(_integer, _language));
		if (_fraction.Length > 0)
		{
			stringBuilder.Append(' ').Append(Term("decimal", _language)).Append(' ')
				.Append(Digits(_fraction, _language));
		}
		return stringBuilder.ToString();
	}

	private static bool NumberSplit(string _text, Language _language, out string _integer, out string _fraction, out char _sign)
	{
		_integer = "";
		_fraction = "";
		_sign = ' ';
		_text = _text.Replace('−', '-').Replace('٫', _language.decimalMark).Replace('٬', _language.groupMark)
			.Replace('\u00a0', ' ')
			.Replace('\u202f', ' ');
		if (_text.Length == 0)
		{
			return false;
		}
		if (_text[0] == '-' || _text[0] == '+')
		{
			_sign = _text[0];
			_text = _text.Substring(1);
		}
		char c = _language.decimalMark;
		if (c == ',' && _language.groupMark != '.' && _text.IndexOf(',') < 0 && _text.IndexOf('.') >= 0)
		{
			c = '.';
		}
		string[] array = _text.Split(c);
		if (array.Length > 2)
		{
			return false;
		}
		string text = array[0];
		if (array.Length == 2)
		{
			_fraction = array[1];
			if (_fraction.Length == 0 || !AllDigits(_fraction))
			{
				return false;
			}
		}
		string[] array2 = text.Split(new char[4] { _language.groupMark, ' ', '\'', '’' }, StringSplitOptions.None);
		if (array2.Length > 1)
		{
			if (array2[0].Length < 1 || array2[0].Length > 3)
			{
				return false;
			}
			for (int i = 1; i < array2.Length; i++)
			{
				if (array2[i].Length != 3)
				{
					return false;
				}
			}
		}
		string[] array3 = array2;
		foreach (string text2 in array3)
		{
			if (!AllDigits(text2))
			{
				return false;
			}
			_integer += text2;
		}
		return _integer.Length > 0;
	}

	private static string Integer(string _digits, Language _language)
	{
		if (_digits.Length > 1 && _digits[0] == '0')
		{
			return Digits(_digits, _language);
		}
		if (TTSPronunciation.TryGetPhonemes(_digits, _language.code, out var _phonemes))
		{
			return "[" + _phonemes + "]";
		}
		return _digits;
	}

	private static string Digits(string _text, Language _language)
	{
		StringBuilder stringBuilder = new StringBuilder();
		for (int i = 0; i < _text.Length; i++)
		{
			char c = _text[i];
			if (stringBuilder.Length > 0)
			{
				stringBuilder.Append(' ');
			}
			if (c >= '0' && c <= '9')
			{
				stringBuilder.Append(Integer(c.ToString(), _language));
			}
			else if (Symbol(c) != null)
			{
				stringBuilder.Append(Term(Symbol(c), _language));
			}
		}
		return stringBuilder.ToString().Trim();
	}

	private static string Measure(string _text, string _unit, Language _language)
	{
		if (!_language.measures.TryGetValue(_unit, out var value))
		{
			return Number(_text, _language) + " " + Characters(_unit, _language);
		}
		if (!NumberSplit(_text, _language, out var _integer, out var _fraction, out var _sign))
		{
			return LiteralSymbols(_text, _language) + " " + Label(value["other"].Replace("{0}", ""), _language);
		}
		decimal num = (decimal.TryParse(_integer + "." + ((_fraction.Length == 0) ? "0" : _fraction), NumberStyles.AllowDecimalPoint, CultureInfo.InvariantCulture, out var result) ? result : decimal.MaxValue);
		string key = Plural(num, _fraction.Length, _language.code);
		string text = (value.TryGetValue(key, out var value2) ? value2 : value["other"]);
		string text2 = Number(_text, _language);
		if (_language.code == "ko" && _unit == "h" && _fraction.Length == 0 && int.TryParse(_integer, out var result2))
		{
			text2 = ((_sign == ' ') ? "" : (Term((_sign == '+') ? "plus" : "minus", _language) + " ")) + Words(KoreanCounterNumber(result2), _language);
		}
		if (_fraction.Length == 0 && value.TryGetValue("gender", out var value3) && !string.IsNullOrEmpty(value3) && int.TryParse(_integer, out var result3))
		{
			text2 = GenderNumber(result3, value3, _language);
			if (_sign != ' ')
			{
				text2 = Term((_sign == '+') ? "plus" : "minus", _language) + " " + text2;
			}
		}
		if (_sign != ' ' && !text.Contains("{0}"))
		{
			return Term((_sign == '+') ? "plus" : "minus", _language) + " " + Label(text, _language);
		}
		if (_language.code == "it" && num == 1m && _fraction.Length == 0 && _unit == "h")
		{
			text2 = ((_sign == ' ') ? "" : (Term((_sign == '+') ? "plus" : "minus", _language) + " ")) + Words("un", _language);
		}
		string[] array = text.Split(new string[1] { "{0}" }, StringSplitOptions.None);
		if (array.Length == 1)
		{
			return Label(text, _language);
		}
		return (Label(array[0], _language) + " " + text2 + " " + Label(array[1], _language)).Trim();
	}

	private static string GenderNumber(int _value, string _gender, Language _language)
	{
		List<string> numberWords = TTSPronunciation.GetNumberWords(_value, _language.code);
		if (numberWords == null || numberWords.Count == 0)
		{
			return Integer(_value.ToString(CultureInfo.InvariantCulture), _language);
		}
		int num = numberWords.Count - 1;
		bool flag = _value % 10 == 1 && _value % 100 != 11;
		bool flag2 = _value % 10 == 2 && _value % 100 != 12;
		switch (_language.code.Split('-')[0])
		{
		case "sv":
			if (flag && numberWords[num] == "ett" && _gender == "common")
			{
				numberWords[num] = "en";
			}
			break;
		case "da":
			if (flag && _value < 20 && _gender == "neuter")
			{
				numberWords[num] = "et";
			}
			break;
		case "de":
			if (numberWords[num] == "eins")
			{
				numberWords[num] = ((_gender == "feminine") ? "eine" : "ein");
			}
			break;
		case "fr":
			if (flag && numberWords[num] == "un" && _gender == "feminine")
			{
				numberWords[num] = "une";
			}
			break;
		case "es":
			if (numberWords[num] == "uno")
			{
				numberWords[num] = ((_gender == "feminine") ? "una" : "un");
			}
			if (numberWords[num] == "veintiuno")
			{
				numberWords[num] = ((_gender == "feminine") ? "veintiuna" : "veintiún");
			}
			break;
		case "pt":
			if (_gender == "feminine" && numberWords[num] == "um")
			{
				numberWords[num] = "uma";
			}
			if (_gender == "feminine" && numberWords[num] == "dois")
			{
				numberWords[num] = "duas";
			}
			break;
		case "it":
			if (_value == 1)
			{
				numberWords[num] = ((_gender == "feminine") ? "una" : "un");
			}
			break;
		case "ru":
			if (flag && numberWords[num] == "один")
			{
				List<string> list2 = numberWords;
				int index2 = num;
				string value2;
				if (_gender == "feminine")
				{
					value2 = "одна";
				}
				else
				{
					value2 = ((_gender == "neuter") ? "одно" : "один");
				}
				list2[index2] = value2;
			}
			if (flag2 && numberWords[num] == "два" && _gender == "feminine")
			{
				numberWords[num] = "две";
			}
			break;
		case "uk":
			if (flag && numberWords[num] == "один")
			{
				List<string> list = numberWords;
				int index = num;
				string value;
				if (_gender == "feminine")
				{
					value = "одна";
				}
				else
				{
					value = ((_gender == "neuter") ? "одне" : "один");
				}
				list[index] = value;
			}
			if (flag2 && numberWords[num] == "два" && _gender == "feminine")
			{
				numberWords[num] = "дві";
			}
			break;
		case "ar":
		{
			if (!(_gender == "feminine"))
			{
				break;
			}
			int num2 = _value % 100;
			Dictionary<string, string> dictionary = new Dictionary<string, string>
			{
				{ "واحد", "واحدة" },
				{ "اثنان", "اثنتان" },
				{ "ثلاثة", "ثلاث" },
				{ "أربعة", "أربع" },
				{ "خمسة", "خمس" },
				{ "ستة", "ست" },
				{ "سبعة", "سبع" },
				{ "ثمانية", "ثماني" },
				{ "تسعة", "تسع" },
				{ "عشرة", "عشر" }
			};
			if (num2 >= 11 && num2 <= 19)
			{
				numberWords[num] = "عشرة";
				switch (num2)
				{
				case 11:
					numberWords[num - 1] = "إحدى";
					break;
				case 12:
					numberWords[num - 1] = "اثنتا";
					break;
				default:
				{
					if (dictionary.TryGetValue(numberWords[num - 1], out var value3))
					{
						numberWords[num - 1] = value3;
					}
					break;
				}
				}
			}
			else
			{
				int num3 = ((num2 >= 20 && num2 % 10 != 0) ? (num - 2) : num);
				if (num3 >= 0 && dictionary.TryGetValue(numberWords[num3], out var value4))
				{
					numberWords[num3] = value4;
				}
			}
			break;
		}
		case "pl":
			if (_value == 1 && _gender == "feminine")
			{
				numberWords[num] = "jedna";
			}
			if (flag2 && numberWords[num] == "dwa" && _gender == "feminine")
			{
				numberWords[num] = "dwie";
			}
			break;
		}
		StringBuilder stringBuilder = new StringBuilder();
		foreach (string item in numberWords)
		{
			if (stringBuilder.Length > 0)
			{
				stringBuilder.Append(' ');
			}
			if (TTSPronunciation.TryGetNumberWordPhonemes(item, _language.code, out var phonemes))
			{
				stringBuilder.Append('[').Append(phonemes).Append(']');
			}
			else
			{
				stringBuilder.Append(Words(item, _language));
			}
		}
		return stringBuilder.ToString();
	}

	private static string Plural(decimal _value, int _decimals, string _code)
	{
		decimal num = _value % 10m;
		decimal num2 = _value % 100m;
		switch (_code)
		{
		case "ar":
			if (_value == 0m)
			{
				return "zero";
			}
			if (_value == 1m)
			{
				return "one";
			}
			if (_value == 2m)
			{
				return "two";
			}
			if (_value == decimal.Truncate(_value) && num2 >= 3m && num2 <= 10m)
			{
				return "few";
			}
			if (_value == decimal.Truncate(_value) && num2 >= 11m)
			{
				return "many";
			}
			return "other";
		case "ru":
		case "uk":
		case "pl":
		{
			if (_decimals > 0)
			{
				return "other";
			}
			bool num3;
			if (!(_code == "pl"))
			{
				if (!(num == 1m))
				{
					goto IL_0133;
				}
				num3 = num2 != 11m;
			}
			else
			{
				num3 = _value == 1m;
			}
			if (num3)
			{
				return "one";
			}
			goto IL_0133;
		}
		case "fr":
		case "pt":
			if (!(_value < 2m))
			{
				return "other";
			}
			return "one";
		default:
			if (!_code.StartsWith("zh", StringComparison.Ordinal) && !(_code == "th"))
			{
				if (_code == "da")
				{
					if (!(_value == 1m) && (_decimals <= 0 || !(_value > 0m) || !(_value < 2m)))
					{
						return "other";
					}
					return "one";
				}
				if (!(_value == 1m) || (_decimals != 0 && !(_code == "tr")))
				{
					return "other";
				}
				return "one";
			}
			goto case "ja";
		case "ja":
		case "ko":
			{
				return "other";
			}
			IL_0133:
			if (num >= 2m && num <= 4m && (num2 < 12m || num2 > 14m))
			{
				return "few";
			}
			return "many";
		}
	}

	private static string Date(string _text, Language _language)
	{
		Match match = date.Match(_text);
		if (!match.Success)
		{
			return null;
		}
		bool success = match.Groups[1].Success;
		int num = int.Parse(match.Groups[success ? 1 : 6].Value, CultureInfo.InvariantCulture);
		GroupCollection groups = match.Groups;
		int groupnum;
		if (success)
		{
			groupnum = 2;
		}
		else
		{
			groupnum = ((_language.code == "en") ? 4 : 5);
		}
		int num2 = int.Parse(groups[groupnum].Value, CultureInfo.InvariantCulture);
		GroupCollection groups2 = match.Groups;
		int groupnum2;
		if (success)
		{
			groupnum2 = 3;
		}
		else
		{
			groupnum2 = ((_language.code == "en") ? 5 : 4);
		}
		int num3 = int.Parse(groups2[groupnum2].Value, CultureInfo.InvariantCulture);
		if (num < 1 || num > 9999 || num2 < 1 || num2 > 12 || num3 < 1 || num3 > DateTime.DaysInMonth(num, num2))
		{
			return null;
		}
		if (_language.code == "ja")
		{
			string[] array = new string[11]
			{
				"", "ついたち", "ふつか", "みっか", "よっか", "いつか", "むいか", "なのか", "ようか", "ここのか",
				"とおか"
			};
			string text = ((num3 <= 10) ? array[num3] : (num3 switch
			{
				24 => "にじゅうよっか", 
				20 => "はつか", 
				14 => "じゅうよっか", 
				_ => ((num3 % 10 == 7 || num3 % 10 == 9) ? (TTSPronunciation.NumberWordsForSpeech(num3 - num3 % 10, "ja") + ((num3 % 10 == 7) ? "しち" : "く")) : TTSPronunciation.NumberWordsForSpeech(num3, "ja")) + "にち", 
			}));
			string text2 = num2 switch
			{
				9 => "く", 
				7 => "しち", 
				4 => "し", 
				_ => TTSPronunciation.NumberWordsForSpeech(num2, "ja"), 
			};
			return Integer(num.ToString(), _language) + " " + Words("ねん" + text2 + "がつ" + text, _language);
		}
		if (_language.code.StartsWith("zh", StringComparison.Ordinal))
		{
			return Digits(num.ToString(), _language) + " " + Label("年", _language) + " " + Integer(num2.ToString(), _language) + " [jUe] " + Integer(num3.ToString(), _language) + " [r@]";
		}
		if (_language.code == "ko")
		{
			return Integer(num.ToString(), _language) + " " + Words("년", _language) + " " + Words(num2 switch
			{
				10 => "시", 
				6 => "유", 
				_ => TTSPronunciation.NumberWordsForSpeech(num2, "ko"), 
			} + "월", _language) + " " + Integer(num3.ToString(), _language) + " " + Words("일", _language);
		}
		StringBuilder stringBuilder = new StringBuilder();
		foreach (Match item in Pattern("d+|M+|y+|'[^']*'|[^dMy']+").Matches(_language.datePattern))
		{
			string value = item.Value;
			if (stringBuilder.Length > 0)
			{
				stringBuilder.Append(' ');
			}
			if (value[0] == 'd')
			{
				StringBuilder stringBuilder2 = stringBuilder;
				string value2;
				if (_language.days.Length == 31)
				{
					value2 = Label(_language.days[num3 - 1], _language);
				}
				else if (num3 == 1 && _language.code == "fr")
				{
					value2 = Words("premier", _language);
				}
				else
				{
					value2 = ((num3 == 1 && _language.code == "it") ? Words("primo", _language) : Integer(num3.ToString(), _language));
				}
				stringBuilder2.Append(value2);
			}
			else if (value[0] == 'M')
			{
				stringBuilder.Append(Label(_language.months[num2 - 1], _language));
			}
			else if (value[0] == 'y')
			{
				stringBuilder.Append(Integer(num.ToString(), _language));
			}
			else
			{
				stringBuilder.Append(Words(value.Trim('\''), _language));
			}
		}
		return stringBuilder.ToString().Trim();
	}

	private static string Clock(string _text, Language _language, bool _duration)
	{
		Match match = clock.Match(_text);
		if (!match.Success)
		{
			return null;
		}
		int num = int.Parse(match.Groups[1].Value, CultureInfo.InvariantCulture);
		int num2 = int.Parse(match.Groups[2].Value, CultureInfo.InvariantCulture);
		int num3 = (match.Groups[3].Success ? int.Parse(match.Groups[3].Value, CultureInfo.InvariantCulture) : (-1));
		if (num2 > 59 || num3 > 59 || (!_duration && num > 23))
		{
			return null;
		}
		if (match.Groups[4].Success)
		{
			if (_duration || num < 1 || num > 12)
			{
				return null;
			}
			num %= 12;
			if (match.Groups[4].Value.Equals("PM", StringComparison.OrdinalIgnoreCase))
			{
				num += 12;
			}
		}
		string text = Measure(num.ToString(), "h", _language);
		if (!_duration && _language.code == "ja")
		{
			int num4 = num % 10;
			string text2 = TTSPronunciation.NumberWordsForSpeech(num, "ja");
			if (num4 == 4 || num4 == 7 || num4 == 9)
			{
				text2 = ((num > 9) ? TTSPronunciation.NumberWordsForSpeech(num - num4, "ja") : "") + num4 switch
				{
					7 => "しち", 
					4 => "よ", 
					_ => "く", 
				};
			}
			text = Words(text2 + "じ", _language);
		}
		if (!_duration && _language.code == "ko")
		{
			text = Words(((num < 12) ? "오전" : "오후") + KoreanCounterNumber((num % 12 == 0) ? 12 : (num % 12)) + "시", _language);
		}
		string text3 = Measure(num2.ToString(), "min", _language);
		if (_language.code == "ja")
		{
			text3 = JapaneseCounter(num2, "分", _language);
		}
		string text4 = text + " " + text3;
		if (num3 >= 0)
		{
			text4 = text4 + " " + Measure(num3.ToString(), "s", _language);
		}
		return text4;
	}

	private static string Counter(string _number, string _counter, Language _language)
	{
		if (!int.TryParse(_number, NumberStyles.None, CultureInfo.InvariantCulture, out var result))
		{
			return null;
		}
		if (_language.code == "ja" && Pattern("^(人|本|枚|個|匹|回|冊|歳|才|杯|台|階|つ|時|分|秒|年|月|日|か月|ヶ月)$").IsMatch(_counter))
		{
			return JapaneseCounter(result, _counter, _language);
		}
		if (_language.code == "ko" && Pattern("^(명|개|시|시간|살|마리|대|번|잔|권)$").IsMatch(_counter))
		{
			return Words(KoreanCounterNumber(result) + _counter, _language);
		}
		if (_language.code.StartsWith("zh", StringComparison.Ordinal) && new Dictionary<string, string>
		{
			{ "个", "g@" },
			{ "個", "g@" },
			{ "人", "r@n" },
			{ "名", "miN" },
			{ "本", "b@n" },
			{ "张", "dZAN" },
			{ "張", "dZAN" },
			{ "只", "dZ@" },
			{ "隻", "dZ@" },
			{ "条", "tiAU" },
			{ "條", "tiAU" },
			{ "瓶", "piN" },
			{ "台", "taI" },
			{ "臺", "taI" }
		}.TryGetValue(_counter, out var value))
		{
			string text = ((result == 2) ? "两" : TTSPronunciation.NumberWordsForSpeech(result, _language.code));
			if (TTSPronunciation.TryGetPhonemes(text + _counter, _language.code, out var _phonemes))
			{
				return "[" + _phonemes + "]";
			}
			return ((result == 2) ? Words(text, _language) : Integer(_number, _language)) + " [" + value + "]";
		}
		if (_language.code == "th" && (_counter == "คน" || _counter == "ช\u0e34\u0e49น"))
		{
			return Integer(_number, _language) + " " + Words(_counter, _language);
		}
		return null;
	}

	private static string JapaneseCounter(int _value, string _counter, Language _language)
	{
		return Words(TTSPronunciation.JapaneseCounterReading(_value, _counter), _language);
	}

	private static string KoreanCounterNumber(int _value)
	{
		string[] array = new string[10] { "", "한", "두", "세", "네", "다섯", "여섯", "일곱", "여덟", "아홉" };
		string[] array2 = new string[10] { "", "열", "스물", "서른", "마흔", "쉰", "예순", "일흔", "여든", "아흔" };
		switch (_value)
		{
		case 20:
			return "스무";
		case 1:
		case 2:
		case 3:
		case 4:
		case 5:
		case 6:
		case 7:
		case 8:
		case 9:
		case 10:
		case 11:
		case 12:
		case 13:
		case 14:
		case 15:
		case 16:
		case 17:
		case 18:
		case 19:
		case 21:
		case 22:
		case 23:
		case 24:
		case 25:
		case 26:
		case 27:
		case 28:
		case 29:
		case 30:
		case 31:
		case 32:
		case 33:
		case 34:
		case 35:
		case 36:
		case 37:
		case 38:
		case 39:
		case 40:
		case 41:
		case 42:
		case 43:
		case 44:
		case 45:
		case 46:
		case 47:
		case 48:
		case 49:
		case 50:
		case 51:
		case 52:
		case 53:
		case 54:
		case 55:
		case 56:
		case 57:
		case 58:
		case 59:
		case 60:
		case 61:
		case 62:
		case 63:
		case 64:
		case 65:
		case 66:
		case 67:
		case 68:
		case 69:
		case 70:
		case 71:
		case 72:
		case 73:
		case 74:
		case 75:
		case 76:
		case 77:
		case 78:
		case 79:
		case 80:
		case 81:
		case 82:
		case 83:
		case 84:
		case 85:
		case 86:
		case 87:
		case 88:
		case 89:
		case 90:
		case 91:
		case 92:
		case 93:
		case 94:
		case 95:
		case 96:
		case 97:
		case 98:
		case 99:
			return array2[_value / 10] + array[_value % 10];
		default:
			return TTSPronunciation.NumberWordsForSpeech(_value, "ko");
		}
	}

	private static string Identifier(string _text, Language _language)
	{
		StringBuilder stringBuilder = new StringBuilder();
		foreach (Match item in Pattern("\\d+|[^\\d]+").Matches(_text))
		{
			if (stringBuilder.Length > 0)
			{
				stringBuilder.Append(' ');
			}
			stringBuilder.Append(AllDigits(item.Value) ? Digits(item.Value, _language) : Words(item.Value.Replace('_', ' '), _language));
		}
		return stringBuilder.ToString();
	}

	private static string Characters(string _text, Language _language)
	{
		StringBuilder stringBuilder = new StringBuilder();
		foreach (string item in TTSPronunciation.SpokenTextElements(_text))
		{
			if (item.Length > 1)
			{
				if (stringBuilder.Length > 0)
				{
					stringBuilder.Append(' ');
				}
				stringBuilder.Append(Words(item, _language));
				continue;
			}
			char c = item[0];
			char c2 = char.ToUpperInvariant(c);
			string text;
			if (c2 >= 'A' && c2 <= 'Z')
			{
				text = Label(_language.letters[c2 - 65], _language);
			}
			else if (c >= '0' && c <= '9')
			{
				text = Integer(c.ToString(), _language);
			}
			else
			{
				text = ((Symbol(c) == null) ? Words(c.ToString(), _language) : Term(Symbol(c), _language));
			}
			if (text.Length != 0)
			{
				if (stringBuilder.Length > 0)
				{
					stringBuilder.Append(' ');
				}
				stringBuilder.Append(text);
			}
		}
		return stringBuilder.ToString();
	}

	private static string Address(string _text, Language _language)
	{
		StringBuilder stringBuilder = new StringBuilder();
		if (_text.StartsWith("www.", StringComparison.OrdinalIgnoreCase))
		{
			_text = _text.Substring(4);
		}
		foreach (Match item in Pattern("\\d+|(?:[\\p{L}\\p{M}]|(?:[\\u3400-\\u4DBF\\u4E00-\\u9FFF\\uF900-\\uFAFF]|(?:[\\uD840-\\uD868][\\uDC00-\\uDFFF]|\\uD869[\\uDC00-\\uDEDF]|\\uD869[\\uDF00-\\uDFFF]|[\\uD86A-\\uD87A][\\uDC00-\\uDFFF]|\\uD87B[\\uDC00-\\uDE5F]|\\uD87E[\\uDC00-\\uDE1F]|[\\uD880-\\uD88C][\\uDC00-\\uDFFF]|\\uD88D[\\uDC00-\\uDC7F])))+|[^\\s]").Matches(_text))
		{
			if (stringBuilder.Length > 0)
			{
				stringBuilder.Append(' ');
			}
			if (AllDigits(item.Value))
			{
				stringBuilder.Append(Digits(item.Value, _language));
			}
			else if (item.Value == "_")
			{
				stringBuilder.Append(Term("underscore", _language));
			}
			else
			{
				stringBuilder.Append(LiteralSymbols(item.Value, _language));
			}
		}
		return stringBuilder.ToString();
	}

	private static string LiteralSymbols(string _text, Language _language)
	{
		StringBuilder stringBuilder = new StringBuilder();
		foreach (Match item in Pattern("\\d+|(?:[\\p{L}\\p{M}]|(?:[\\u3400-\\u4DBF\\u4E00-\\u9FFF\\uF900-\\uFAFF]|(?:[\\uD840-\\uD868][\\uDC00-\\uDFFF]|\\uD869[\\uDC00-\\uDEDF]|\\uD869[\\uDF00-\\uDFFF]|[\\uD86A-\\uD87A][\\uDC00-\\uDFFF]|\\uD87B[\\uDC00-\\uDE5F]|\\uD87E[\\uDC00-\\uDE1F]|[\\uD880-\\uD88C][\\uDC00-\\uDFFF]|\\uD88D[\\uDC00-\\uDC7F])))+|[^\\s]").Matches(_text))
		{
			string value = item.Value;
			string text;
			if (AllDigits(value))
			{
				text = Integer(value, _language);
			}
			else
			{
				text = ((value.Length != 1 || Symbol(value[0]) == null) ? Words(value, _language) : Term(Symbol(value[0]), _language));
			}
			if (text.Length != 0)
			{
				if (stringBuilder.Length > 0)
				{
					stringBuilder.Append(' ');
				}
				stringBuilder.Append(text);
			}
		}
		return stringBuilder.ToString();
	}

	private static string Label(string _text, Language _language)
	{
		_text = _text.Trim();
		if (_text.Length == 0)
		{
			return "";
		}
		if (_text.StartsWith("~", StringComparison.Ordinal))
		{
			return "[" + _text.Substring(1).Replace(",", "") + "]";
		}
		if (_language.readings.TryGetValue(_text, out var value))
		{
			return Label(value, _language);
		}
		foreach (KeyValuePair<string, string> reading in _language.readings)
		{
			if (_text.Contains(reading.Key))
			{
				int num = _text.IndexOf(reading.Key, StringComparison.Ordinal);
				return (Label(_text.Substring(0, num), _language) + " " + Label(reading.Value, _language) + " " + Label(_text.Substring(num + reading.Key.Length), _language)).Trim();
			}
		}
		return Words(_text, _language, _spellInitials: true);
	}

	private static string Words(string _text, Language _language, bool _spellInitials = false)
	{
		StringBuilder stringBuilder = new StringBuilder();
		_text = tags.Replace(_text, "").Replace("[", "").Replace("]", "");
		if (Pattern("^[\\p{P}\\s]+$").IsMatch(_text))
		{
			return "";
		}
		if (!HasLetter(_text) && !HasDigit(_text))
		{
			return UnreadableMarkers(_text);
		}
		StringBuilder stringBuilder2 = new StringBuilder(_text.Length);
		foreach (string item in TTSPronunciation.SpokenTextElements(_text))
		{
			char c = item[0];
			int num;
			if (TTSPronunciation.HanCharacterLength(item, 0) == 0)
			{
				if (char.IsSurrogate(c))
				{
					num = 1;
					goto IL_00d6;
				}
				if (!char.IsLetterOrDigit(c) && !char.IsPunctuation(c) && !char.IsWhiteSpace(c))
				{
					num = ((char.GetUnicodeCategory(c) != UnicodeCategory.NonSpacingMark) ? 1 : 0);
					if (num != 0)
					{
						goto IL_00d6;
					}
				}
				else
				{
					num = 0;
				}
			}
			else
			{
				num = 0;
			}
			goto IL_00df;
			IL_00df:
			stringBuilder2.Append(item);
			if (num != 0)
			{
				stringBuilder2.Append(' ');
			}
			continue;
			IL_00d6:
			stringBuilder2.Append(' ');
			goto IL_00df;
		}
		_text = stringBuilder2.ToString();
		foreach (string item2 in TTSPronunciation.SplitSpokenWords(_text))
		{
			StringBuilder stringBuilder3 = new StringBuilder();
			for (int i = 0; i < item2.Length; i++)
			{
				char c2 = item2[i];
				if (char.IsLetterOrDigit(c2) || char.IsSurrogate(c2) || TTSPronunciation.HanCharacterLength(item2, i) > 0 || char.GetUnicodeCategory(c2) == UnicodeCategory.NonSpacingMark || c2 == '\'' || c2 == '’' || c2 == '-' || c2 == '\u200d')
				{
					stringBuilder3.Append(c2);
				}
			}
			if (stringBuilder.Length > 0)
			{
				stringBuilder.Append(' ');
			}
			if (stringBuilder3.Length == 0)
			{
				if (HasVisibleText(item2) && !Pattern("^[\\p{P}]+$").IsMatch(item2))
				{
					stringBuilder.Append("\ufffd");
				}
			}
			else if (_spellInitials && Pattern("^[A-Z]{2,3}$").IsMatch(stringBuilder3.ToString()))
			{
				stringBuilder.Append(Characters(stringBuilder3.ToString(), _language));
			}
			else
			{
				stringBuilder.Append(SpokenWord(stringBuilder3.ToString(), _language));
			}
		}
		return stringBuilder.ToString();
	}

	private static string SpokenWord(string _word, Language _language)
	{
		_word = TTSPronunciation.NormalizeSpokenText(_word);
		if (TTSPronunciation.TryGetApproximatePhonemes(_word, _language.code, out var _phonemes))
		{
			return "[" + _phonemes + "]";
		}
		List<string> readablePhonemeParts = TTSPronunciation.GetReadablePhonemeParts(_word, _language.code);
		if (readablePhonemeParts != null)
		{
			StringBuilder stringBuilder = new StringBuilder();
			foreach (string item in readablePhonemeParts)
			{
				if (stringBuilder.Length > 0)
				{
					stringBuilder.Append(' ');
				}
				stringBuilder.Append(string.IsNullOrEmpty(item) ? "\ufffd" : ("[" + item + "]"));
			}
			return stringBuilder.ToString();
		}
		StringBuilder stringBuilder2 = new StringBuilder();
		string text = _word.Normalize(NormalizationForm.FormD);
		foreach (char c in text)
		{
			if (char.GetUnicodeCategory(c) != UnicodeCategory.NonSpacingMark)
			{
				stringBuilder2.Append(c);
			}
		}
		if (Pattern("^[a-zA-Z]+(?:'[a-zA-Z]+)*$").IsMatch(stringBuilder2.ToString()))
		{
			return stringBuilder2.ToString().ToLowerInvariant();
		}
		if (Pattern("[a-zA-Z]").IsMatch(stringBuilder2.ToString()))
		{
			StringBuilder stringBuilder3 = new StringBuilder();
			foreach (Match item2 in Pattern("[a-zA-Z]+(?:'[a-zA-Z]+)*|[^a-zA-Z]+").Matches(stringBuilder2.ToString()))
			{
				if (stringBuilder3.Length > 0)
				{
					stringBuilder3.Append(' ');
				}
				if (Pattern("^[a-zA-Z]").IsMatch(item2.Value))
				{
					stringBuilder3.Append(TTSPronunciation.TryGetApproximatePhonemes(item2.Value, _language.code, out var _phonemes2) ? ("[" + _phonemes2 + "]") : item2.Value.ToLowerInvariant());
				}
				else
				{
					stringBuilder3.Append(UnreadableMarkers(item2.Value));
				}
			}
			return stringBuilder3.ToString();
		}
		return UnreadableMarkers(_word);
	}

	private static bool HasVisibleText(string _text)
	{
		for (int i = 0; i < _text.Length; i++)
		{
			char c = _text[i];
			if (char.IsHighSurrogate(c) && i + 1 < _text.Length && char.IsLowSurrogate(_text[i + 1]))
			{
				int num = char.ConvertToUtf32(_text, i);
				if (num >= 917760 && num <= 917999)
				{
					i++;
					continue;
				}
			}
			UnicodeCategory unicodeCategory = char.GetUnicodeCategory(c);
			if (!char.IsWhiteSpace(c) && !char.IsControl(c) && unicodeCategory != UnicodeCategory.Format && (c < '\ufe00' || c > '\ufe0f'))
			{
				return true;
			}
		}
		return false;
	}

	private static string UnreadableMarkers(string _text)
	{
		StringBuilder stringBuilder = new StringBuilder();
		foreach (string item in TTSPronunciation.SpokenTextElements(_text))
		{
			if (HasVisibleText(item))
			{
				stringBuilder.Append("\ufffd");
			}
		}
		return stringBuilder.ToString();
	}

	private static List<SpeechPart> ResolveUnreadableParts(List<SpeechPart> _parts, string _text, Language _language)
	{
		bool flag = false;
		bool flag2 = false;
		foreach (SpeechPart _part in _parts)
		{
			string speechText = _part.speechText;
			foreach (char c in speechText)
			{
				if ((c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z') || (c >= '0' && c <= '9'))
				{
					flag = true;
				}
			}
			if (Pattern("\\[[' &@]*[&@][' &@]*\\]").IsMatch(_part.speechText))
			{
				flag = true;
			}
			if (_part.speechText.Contains("\ufffd"))
			{
				flag2 = true;
			}
		}
		if (!flag && !flag2)
		{
			_parts = new List<SpeechPart>
			{
				new SpeechPart
				{
					displayText = _text,
					speechText = UnreadableMarkers(tags.Replace(_text, ""))
				}
			};
		}
		for (int j = 0; j < _parts.Count; j++)
		{
			SpeechPart value = _parts[j];
			StringBuilder stringBuilder = new StringBuilder();
			string speechText = value.speechText;
			foreach (char c2 in speechText)
			{
				if (c2 == "\ufffd"[0])
				{
					stringBuilder.Append(PhonemeWordPauses(UnreadableSpeech(_language)));
				}
				else
				{
					stringBuilder.Append(c2);
				}
			}
			value.speechText = stringBuilder.ToString();
			_parts[j] = value;
		}
		int num = _parts.Count - 1;
		while (num >= 0 && _parts.Count > 1)
		{
			if (string.IsNullOrWhiteSpace(_parts[num].speechText))
			{
				int index = ((num <= 0) ? 1 : (num - 1));
				SpeechPart value2 = _parts[index];
				value2.displayText = ((num > 0) ? (value2.displayText + _parts[num].displayText) : (_parts[num].displayText + value2.displayText));
				_parts[index] = value2;
				_parts.RemoveAt(num);
			}
			num--;
		}
		return _parts;
	}

	private static string UnreadableSpeech(Language _language)
	{
		switch (_language.code)
		{
		case "ja":
		case "es":
		case "es-ES":
			return "[ee]";
		case "zh":
		case "zh-TW":
		case "th":
			return "[@@]";
		case "ko":
		case "pt":
		case "pt-PT":
			return "[VV]";
		case "ar":
			return "[AA]";
		case "fr":
		case "sv":
		case "da":
		case "fi":
			return "[33]";
		case "de":
		case "it":
		case "ru":
		case "uk":
			return "[ee]";
		case "pl":
		case "tr":
			return "[II]";
		default:
			return "[@@]";
		}
	}

	private static string Term(string _key, Language _language)
	{
		return Label(_language.terms[_key], _language);
	}

	private static string Symbol(char _char)
	{
		switch (_char)
		{
		case '-':
		case '–':
		case '—':
		case '−':
			return "minus";
		case '+':
			return "plus";
		case ',':
		case '.':
			return "dot";
		case '/':
		case '\\':
			return "slash";
		case ':':
			return "colon";
		case '@':
			return "at";
		case '=':
			return "equals";
		case '&':
			return "and";
		case '*':
		case '×':
			return "times";
		case '÷':
			return "divided";
		case '<':
			return "less";
		case '>':
			return "greater";
		case '#':
			return "number";
		case '%':
			return "percent";
		case '°':
			return "degree";
		default:
			return null;
		}
	}

	private static string CurrencyCode(string _symbol, Language _language)
	{
		switch (_symbol)
		{
		case "$":
		case "US$":
			return "USD";
		case "R$":
			return "BRL";
		case "€":
			return "EUR";
		case "£":
			return "GBP";
		case "¥":
			if (!_language.code.StartsWith("zh", StringComparison.Ordinal))
			{
				return "JPY";
			}
			return "CNY";
		case "₩":
			return "KRW";
		case "₽":
			return "RUB";
		case "₺":
			return "TRY";
		case "฿":
			return "THB";
		default:
			return _symbol.ToUpperInvariant();
		}
	}

	private static Language LanguageGet(string _locale)
	{
		if (languages == null)
		{
			languages = BuildLanguages();
		}
		_locale = TTSPronunciation.LocaleCodeGet(_locale);
		if (languages.TryGetValue(_locale, out var value))
		{
			return value;
		}
		string key = _locale.Split('-')[0];
		if (!languages.TryGetValue(key, out value))
		{
			return languages["en"];
		}
		return value;
	}

	private static Regex Pattern(string _pattern, RegexOptions _options = RegexOptions.None)
	{
		int num = (int)_options;
		string key = num.ToString(CultureInfo.InvariantCulture) + _pattern;
		lock (patterns)
		{
			if (patterns.TryGetValue(key, out var value))
			{
				return value;
			}
			Regex regex = new Regex(_pattern, _options | RegexOptions.CultureInvariant, TimeSpan.FromMilliseconds(100.0));
			patterns.Add(key, regex);
			return regex;
		}
	}

	private static bool AllDigits(string _text)
	{
		if (_text.Length == 0)
		{
			return false;
		}
		foreach (char c in _text)
		{
			if (c < '0' || c > '9')
			{
				return false;
			}
		}
		return true;
	}

	private static bool HasDigit(string _text)
	{
		for (int i = 0; i < _text.Length; i++)
		{
			if (char.IsDigit(_text[i]))
			{
				return true;
			}
		}
		return false;
	}

	private static bool HasLetter(string _text)
	{
		for (int i = 0; i < _text.Length; i++)
		{
			if (char.IsLetter(_text[i]) || TTSPronunciation.HanCharacterLength(_text, i) > 0)
			{
				return true;
			}
		}
		return false;
	}

	private static bool IsPause(string _text)
	{
		switch (_text)
		{
		default:
			return _text == "؟";
		case ".":
		case ",":
		case ";":
		case ":":
		case "!":
		case "?":
		case "…":
		case "。":
		case "、":
		case "，":
		case "！":
		case "？":
		case "،":
		case "؛":
			return true;
		}
	}

	private static Dictionary<string, Language> BuildLanguages()
	{
		Dictionary<string, Language> dictionary = new Dictionary<string, Language>(StringComparer.OrdinalIgnoreCase);
		dictionary["en"] = new Language
		{
			code = "en",
			decimalMark = '.',
			groupMark = ',',
			letters = new string[26]
			{
				"ay", "bee", "see", "dee", "ee", "ef", "gee", "aitch", "eye", "jay",
				"kay", "el", "em", "en", "oh", "pee", "cue", "ar", "ess", "tee",
				"you", "vee", "double-you", "ex", "why", "zee"
			},
			datePattern = "MMMM d, y",
			months = new string[12]
			{
				"January", "February", "March", "April", "May", "June", "July", "August", "September", "October",
				"November", "December"
			},
			days = new string[31]
			{
				"first", "second", "third", "fourth", "fifth", "sixth", "seventh", "eighth", "ninth", "tenth",
				"eleventh", "twelfth", "thirteenth", "fourteenth", "fifteenth", "sixteenth", "seventeenth", "eighteenth", "nineteenth", "twentieth",
				"twenty first", "twenty second", "twenty third", "twenty fourth", "twenty fifth", "twenty sixth", "twenty seventh", "twenty eighth", "twenty ninth", "thirtieth",
				"thirty first"
			},
			terms = new Dictionary<string, string>
			{
				{ "minus", "minus" },
				{ "plus", "plus" },
				{ "decimal", "point" },
				{ "percent", "percent" },
				{ "to", "to" },
				{ "over", "over" },
				{ "slash", "slash" },
				{ "colon", "colon" },
				{ "dot", "dot" },
				{ "at", "at" },
				{ "equals", "equals" },
				{ "and", "and" },
				{ "times", "times" },
				{ "divided", "divided by" },
				{ "less", "less than" },
				{ "greater", "greater than" },
				{ "number", "number" },
				{ "link", "link" },
				{ "email", "email" },
				{ "degree", "degrees" },
				{ "underscore", "underscore" }
			},
			readings = new Dictionary<string, string>(),
			abbreviations = new Dictionary<string, string>
			{
				{ "Dr.", "doctor" },
				{ "Mr.", "mister" },
				{ "Mrs.", "missus" },
				{ "Ms.", "miz" },
				{ "e.g.", "for example" },
				{ "i.e.", "that is" }
			},
			measures = new Dictionary<string, Dictionary<string, string>>
			{
				{
					"kg",
					new Dictionary<string, string>
					{
						{ "one", "{0} kilogram" },
						{ "other", "{0} kilograms" },
						{ "gender", "" }
					}
				},
				{
					"g",
					new Dictionary<string, string>
					{
						{ "one", "{0} gram" },
						{ "other", "{0} grams" },
						{ "gender", "" }
					}
				},
				{
					"km",
					new Dictionary<string, string>
					{
						{ "one", "{0} kilometer" },
						{ "other", "{0} kilometers" },
						{ "gender", "" }
					}
				},
				{
					"m",
					new Dictionary<string, string>
					{
						{ "one", "{0} meter" },
						{ "other", "{0} meters" },
						{ "gender", "" }
					}
				},
				{
					"cm",
					new Dictionary<string, string>
					{
						{ "one", "{0} centimeter" },
						{ "other", "{0} centimeters" },
						{ "gender", "" }
					}
				},
				{
					"mm",
					new Dictionary<string, string>
					{
						{ "one", "{0} millimeter" },
						{ "other", "{0} millimeters" },
						{ "gender", "" }
					}
				},
				{
					"L",
					new Dictionary<string, string>
					{
						{ "one", "{0} liter" },
						{ "other", "{0} liters" },
						{ "gender", "" }
					}
				},
				{
					"ml",
					new Dictionary<string, string>
					{
						{ "one", "{0} milliliter" },
						{ "other", "{0} milliliters" },
						{ "gender", "" }
					}
				},
				{
					"°C",
					new Dictionary<string, string>
					{
						{ "one", "{0} degree Celsius" },
						{ "other", "{0} degrees Celsius" },
						{ "gender", "" }
					}
				},
				{
					"°F",
					new Dictionary<string, string>
					{
						{ "one", "{0} degree Fahrenheit" },
						{ "other", "{0} degrees Fahrenheit" },
						{ "gender", "" }
					}
				},
				{
					"h",
					new Dictionary<string, string>
					{
						{ "one", "{0} hour" },
						{ "other", "{0} hours" },
						{ "gender", "" }
					}
				},
				{
					"min",
					new Dictionary<string, string>
					{
						{ "one", "{0} minute" },
						{ "other", "{0} minutes" },
						{ "gender", "" }
					}
				},
				{
					"s",
					new Dictionary<string, string>
					{
						{ "one", "{0} second" },
						{ "other", "{0} seconds" },
						{ "gender", "" }
					}
				},
				{
					"day",
					new Dictionary<string, string>
					{
						{ "one", "{0} day" },
						{ "other", "{0} days" },
						{ "gender", "" }
					}
				},
				{
					"month",
					new Dictionary<string, string>
					{
						{ "one", "{0} month" },
						{ "other", "{0} months" },
						{ "gender", "" }
					}
				},
				{
					"year",
					new Dictionary<string, string>
					{
						{ "one", "{0} year" },
						{ "other", "{0} years" },
						{ "gender", "" }
					}
				},
				{
					"%",
					new Dictionary<string, string>
					{
						{ "one", "{0} percent" },
						{ "other", "{0} percent" },
						{ "gender", "" }
					}
				},
				{
					"‰",
					new Dictionary<string, string>
					{
						{ "one", "{0} permille" },
						{ "other", "{0} permille" },
						{ "gender", "" }
					}
				},
				{
					"°",
					new Dictionary<string, string>
					{
						{ "one", "{0} degree temperature" },
						{ "other", "{0} degrees temperature" },
						{ "gender", "" }
					}
				},
				{
					"ms",
					new Dictionary<string, string>
					{
						{ "one", "{0} millisecond" },
						{ "other", "{0} milliseconds" },
						{ "gender", "" }
					}
				},
				{
					"USD",
					new Dictionary<string, string>
					{
						{ "one", "{0} US dollar" },
						{ "other", "{0} US dollars" }
					}
				},
				{
					"EUR",
					new Dictionary<string, string>
					{
						{ "one", "{0} euro" },
						{ "other", "{0} euros" }
					}
				},
				{
					"GBP",
					new Dictionary<string, string>
					{
						{ "one", "{0} British pound" },
						{ "other", "{0} British pounds" }
					}
				},
				{
					"JPY",
					new Dictionary<string, string>
					{
						{ "one", "{0} Japanese yen" },
						{ "other", "{0} Japanese yen" }
					}
				},
				{
					"CNY",
					new Dictionary<string, string>
					{
						{ "one", "{0} Chinese yuan" },
						{ "other", "{0} Chinese yuan" }
					}
				},
				{
					"SEK",
					new Dictionary<string, string>
					{
						{ "one", "{0} Swedish krona" },
						{ "other", "{0} Swedish kronor" }
					}
				},
				{
					"DKK",
					new Dictionary<string, string>
					{
						{ "one", "{0} Danish krone" },
						{ "other", "{0} Danish kroner" }
					}
				},
				{
					"NOK",
					new Dictionary<string, string>
					{
						{ "one", "{0} Norwegian krone" },
						{ "other", "{0} Norwegian kroner" }
					}
				},
				{
					"PLN",
					new Dictionary<string, string>
					{
						{ "one", "{0} Polish zloty" },
						{ "other", "{0} Polish zlotys" }
					}
				},
				{
					"RUB",
					new Dictionary<string, string>
					{
						{ "one", "{0} Russian ruble" },
						{ "other", "{0} Russian rubles" }
					}
				},
				{
					"UAH",
					new Dictionary<string, string>
					{
						{ "one", "{0} Ukrainian hryvnia" },
						{ "other", "{0} Ukrainian hryvnias" }
					}
				},
				{
					"TRY",
					new Dictionary<string, string>
					{
						{ "one", "{0} Turkish lira" },
						{ "other", "{0} Turkish Lira" }
					}
				},
				{
					"KRW",
					new Dictionary<string, string>
					{
						{ "one", "{0} South Korean won" },
						{ "other", "{0} South Korean won" }
					}
				},
				{
					"THB",
					new Dictionary<string, string>
					{
						{ "one", "{0} Thai baht" },
						{ "other", "{0} Thai baht" }
					}
				},
				{
					"BRL",
					new Dictionary<string, string>
					{
						{ "one", "{0} Brazilian real" },
						{ "other", "{0} Brazilian reals" }
					}
				}
			}
		};
		dictionary["sv"] = new Language
		{
			code = "sv",
			decimalMark = ',',
			groupMark = ' ',
			letters = new string[26]
			{
				"a", "be", "se", "de", "e", "eff", "ge", "hå", "i", "ji",
				"kå", "ell", "emm", "enn", "o", "pe", "ku", "ärr", "ess", "te",
				"u", "ve", "dubbel-ve", "eks", "y", "säta"
			},
			datePattern = "d MMMM y",
			months = new string[12]
			{
				"januari", "februari", "mars", "april", "maj", "juni", "juli", "augusti", "september", "oktober",
				"november", "december"
			},
			days = new string[31]
			{
				"första", "andra", "tredje", "fjärde", "femte", "sjätte", "sjunde", "åttonde", "nionde", "tionde",
				"elfte", "tolfte", "trettonde", "fjortonde", "femtonde", "sextonde", "sjuttonde", "artonde", "nittonde", "tjugonde",
				"tjugoförsta", "tjugoandra", "tjugotredje", "tjugofjärde", "tjugofemte", "tjugosjätte", "tjugosjunde", "tjugoåttonde", "tjugonionde", "trettionde",
				"trettioförsta"
			},
			terms = new Dictionary<string, string>
			{
				{ "minus", "minus" },
				{ "plus", "plus" },
				{ "decimal", "komma" },
				{ "percent", "procent" },
				{ "to", "till" },
				{ "over", "genom" },
				{ "slash", "snedstreck" },
				{ "colon", "kolon" },
				{ "dot", "punkt" },
				{ "at", "snabel a" },
				{ "equals", "är lika med" },
				{ "and", "och" },
				{ "times", "gånger" },
				{ "divided", "delat med" },
				{ "less", "mindre än" },
				{ "greater", "större än" },
				{ "number", "nummer" },
				{ "link", "länk" },
				{ "email", "e post" },
				{ "degree", "grader" },
				{ "underscore", "understreck" }
			},
			readings = new Dictionary<string, string>(),
			abbreviations = new Dictionary<string, string>
			{
				{ "Dr.", "doktor" },
				{ "t.ex.", "till exempel" },
				{ "bl.a.", "bland annat" },
				{ "dvs.", "det vill säga" }
			},
			measures = new Dictionary<string, Dictionary<string, string>>
			{
				{
					"kg",
					new Dictionary<string, string>
					{
						{ "one", "{0} kilogram" },
						{ "other", "{0} kilogram" },
						{ "gender", "neuter" }
					}
				},
				{
					"g",
					new Dictionary<string, string>
					{
						{ "one", "{0} gram" },
						{ "other", "{0} gram" },
						{ "gender", "neuter" }
					}
				},
				{
					"km",
					new Dictionary<string, string>
					{
						{ "one", "{0} kilometer" },
						{ "other", "{0} kilometer" },
						{ "gender", "common" }
					}
				},
				{
					"m",
					new Dictionary<string, string>
					{
						{ "one", "{0} meter" },
						{ "other", "{0} meter" },
						{ "gender", "common" }
					}
				},
				{
					"cm",
					new Dictionary<string, string>
					{
						{ "one", "{0} centimeter" },
						{ "other", "{0} centimeter" },
						{ "gender", "common" }
					}
				},
				{
					"mm",
					new Dictionary<string, string>
					{
						{ "one", "{0} millimeter" },
						{ "other", "{0} millimeter" },
						{ "gender", "common" }
					}
				},
				{
					"L",
					new Dictionary<string, string>
					{
						{ "one", "{0} liter" },
						{ "other", "{0} liter" },
						{ "gender", "common" }
					}
				},
				{
					"ml",
					new Dictionary<string, string>
					{
						{ "one", "{0} milliliter" },
						{ "other", "{0} milliliter" },
						{ "gender", "common" }
					}
				},
				{
					"°C",
					new Dictionary<string, string>
					{
						{ "one", "{0} grad Celsius" },
						{ "other", "{0} grader Celsius" },
						{ "gender", "common" }
					}
				},
				{
					"°F",
					new Dictionary<string, string>
					{
						{ "one", "{0} grad Fahrenheit" },
						{ "other", "{0} grader Fahrenheit" },
						{ "gender", "common" }
					}
				},
				{
					"h",
					new Dictionary<string, string>
					{
						{ "one", "{0} timme" },
						{ "other", "{0} timmar" },
						{ "gender", "common" }
					}
				},
				{
					"min",
					new Dictionary<string, string>
					{
						{ "one", "{0} minut" },
						{ "other", "{0} minuter" },
						{ "gender", "common" }
					}
				},
				{
					"s",
					new Dictionary<string, string>
					{
						{ "one", "{0} sekund" },
						{ "other", "{0} sekunder" },
						{ "gender", "common" }
					}
				},
				{
					"day",
					new Dictionary<string, string>
					{
						{ "one", "{0} dygn" },
						{ "other", "{0} dygn" },
						{ "gender", "neuter" }
					}
				},
				{
					"month",
					new Dictionary<string, string>
					{
						{ "one", "{0} månad" },
						{ "other", "{0} månader" },
						{ "gender", "common" }
					}
				},
				{
					"year",
					new Dictionary<string, string>
					{
						{ "one", "{0} år" },
						{ "other", "{0} år" },
						{ "gender", "neuter" }
					}
				},
				{
					"%",
					new Dictionary<string, string>
					{
						{ "one", "{0} procent" },
						{ "other", "{0} procent" },
						{ "gender", "common" }
					}
				},
				{
					"‰",
					new Dictionary<string, string>
					{
						{ "one", "{0} promille" },
						{ "other", "{0} promille" },
						{ "gender", "common" }
					}
				},
				{
					"°",
					new Dictionary<string, string>
					{
						{ "one", "{0} grad" },
						{ "other", "{0} grader" },
						{ "gender", "common" }
					}
				},
				{
					"ms",
					new Dictionary<string, string>
					{
						{ "one", "{0} millisekund" },
						{ "other", "{0} millisekunder" },
						{ "gender", "common" }
					}
				},
				{
					"USD",
					new Dictionary<string, string>
					{
						{ "one", "{0} amerikansk dollar" },
						{ "other", "{0} amerikanska dollar" },
						{ "gender", "common" }
					}
				},
				{
					"EUR",
					new Dictionary<string, string>
					{
						{ "other", "{0} euro" },
						{ "gender", "common" }
					}
				},
				{
					"GBP",
					new Dictionary<string, string>
					{
						{ "one", "{0} brittiskt pund" },
						{ "other", "{0} brittiska pund" },
						{ "gender", "neuter" }
					}
				},
				{
					"JPY",
					new Dictionary<string, string>
					{
						{ "one", "{0} japansk yen" },
						{ "other", "{0} japanska yen" },
						{ "gender", "common" }
					}
				},
				{
					"CNY",
					new Dictionary<string, string>
					{
						{ "one", "{0} kinesisk yuan" },
						{ "other", "{0} kinesiska yuan" },
						{ "gender", "common" }
					}
				},
				{
					"SEK",
					new Dictionary<string, string>
					{
						{ "one", "{0} svensk krona" },
						{ "other", "{0} svenska kronor" },
						{ "gender", "common" }
					}
				},
				{
					"DKK",
					new Dictionary<string, string>
					{
						{ "one", "{0} dansk krona" },
						{ "other", "{0} danska kronor" },
						{ "gender", "common" }
					}
				},
				{
					"NOK",
					new Dictionary<string, string>
					{
						{ "one", "{0} norsk krona" },
						{ "other", "{0} norska kronor" },
						{ "gender", "common" }
					}
				},
				{
					"PLN",
					new Dictionary<string, string>
					{
						{ "one", "{0} polsk zloty" },
						{ "other", "{0} polska zloty" },
						{ "gender", "common" }
					}
				},
				{
					"RUB",
					new Dictionary<string, string>
					{
						{ "one", "{0} rysk rubel" },
						{ "other", "{0} ryska rubel" },
						{ "gender", "common" }
					}
				},
				{
					"UAH",
					new Dictionary<string, string>
					{
						{ "one", "{0} ukrainsk hryvnia" },
						{ "other", "{0} ukrainska hryvnia" },
						{ "gender", "common" }
					}
				},
				{
					"TRY",
					new Dictionary<string, string>
					{
						{ "one", "{0} turkisk lira" },
						{ "other", "{0} turkiska lira" },
						{ "gender", "common" }
					}
				},
				{
					"KRW",
					new Dictionary<string, string>
					{
						{ "one", "{0} sydkoreansk won" },
						{ "other", "{0} sydkoreanska won" },
						{ "gender", "common" }
					}
				},
				{
					"THB",
					new Dictionary<string, string>
					{
						{ "one", "{0} thailändsk baht" },
						{ "other", "{0} thailändska baht" },
						{ "gender", "common" }
					}
				},
				{
					"BRL",
					new Dictionary<string, string>
					{
						{ "one", "{0} brasiliansk real" },
						{ "other", "{0} brasilianska real" },
						{ "gender", "common" }
					}
				}
			}
		};
		dictionary["da"] = new Language
		{
			code = "da",
			decimalMark = ',',
			groupMark = '.',
			letters = new string[26]
			{
				"a", "be", "se", "de", "e", "æf", "ge", "hå", "i", "jåd",
				"kå", "æl", "æm", "æn", "o", "pe", "ku", "ær", "æs", "te",
				"u", "ve", "dobbelt-ve", "æks", "y", "sæt"
			},
			datePattern = "d. MMMM y",
			months = new string[12]
			{
				"januar", "februar", "marts", "april", "maj", "juni", "juli", "august", "september", "oktober",
				"november", "december"
			},
			days = new string[31]
			{
				"første", "anden", "tredje", "fjerde", "femte", "sjette", "syvende", "ottende", "niende", "tiende",
				"ellevte", "tolvte", "trettende", "fjortende", "femtende", "sekstende", "syttende", "attende", "nittende", "tyvende",
				"enogtyvende", "toogtyvende", "treogtyvende", "fireogtyvende", "femogtyvende", "seksogtyvende", "syvogtyvende", "otteogtyvende", "niogtyvende", "tredivte",
				"enogtredivte"
			},
			terms = new Dictionary<string, string>
			{
				{ "minus", "minus" },
				{ "plus", "plus" },
				{ "decimal", "komma" },
				{ "percent", "procent" },
				{ "to", "til" },
				{ "over", "over" },
				{ "slash", "skråstreg" },
				{ "colon", "kolon" },
				{ "dot", "punktum" },
				{ "at", "snabel a" },
				{ "equals", "lig med" },
				{ "and", "og" },
				{ "times", "gange" },
				{ "divided", "divideret med" },
				{ "less", "mindre end" },
				{ "greater", "større end" },
				{ "number", "nummer" },
				{ "link", "link" },
				{ "email", "e mail" },
				{ "degree", "grader" },
				{ "underscore", "understreg" }
			},
			readings = new Dictionary<string, string>(),
			abbreviations = new Dictionary<string, string> { { "Dr.", "doktor" } },
			measures = new Dictionary<string, Dictionary<string, string>>
			{
				{
					"kg",
					new Dictionary<string, string>
					{
						{ "one", "{0} kilogram" },
						{ "other", "{0} kilogram" },
						{ "gender", "neuter" }
					}
				},
				{
					"g",
					new Dictionary<string, string>
					{
						{ "one", "{0} gram" },
						{ "other", "{0} gram" },
						{ "gender", "neuter" }
					}
				},
				{
					"km",
					new Dictionary<string, string>
					{
						{ "one", "{0} kilometer" },
						{ "other", "{0} kilometer" },
						{ "gender", "common" }
					}
				},
				{
					"m",
					new Dictionary<string, string>
					{
						{ "one", "{0} meter" },
						{ "other", "{0} meter" },
						{ "gender", "common" }
					}
				},
				{
					"cm",
					new Dictionary<string, string>
					{
						{ "one", "{0} centimeter" },
						{ "other", "{0} centimeter" },
						{ "gender", "common" }
					}
				},
				{
					"mm",
					new Dictionary<string, string>
					{
						{ "one", "{0} millimeter" },
						{ "other", "{0} millimeter" },
						{ "gender", "common" }
					}
				},
				{
					"L",
					new Dictionary<string, string>
					{
						{ "one", "{0} liter" },
						{ "other", "{0} liter" },
						{ "gender", "common" }
					}
				},
				{
					"ml",
					new Dictionary<string, string>
					{
						{ "one", "{0} milliliter" },
						{ "other", "{0} milliliter" },
						{ "gender", "common" }
					}
				},
				{
					"°C",
					new Dictionary<string, string>
					{
						{ "one", "{0} grad celsius" },
						{ "other", "{0} grader celsius" },
						{ "gender", "common" }
					}
				},
				{
					"°F",
					new Dictionary<string, string>
					{
						{ "one", "{0} grad fahrenheit" },
						{ "other", "{0} grader fahrenheit" },
						{ "gender", "common" }
					}
				},
				{
					"h",
					new Dictionary<string, string>
					{
						{ "one", "{0} time" },
						{ "other", "{0} timer" },
						{ "gender", "common" }
					}
				},
				{
					"min",
					new Dictionary<string, string>
					{
						{ "one", "{0} minut" },
						{ "other", "{0} minutter" },
						{ "gender", "neuter" }
					}
				},
				{
					"s",
					new Dictionary<string, string>
					{
						{ "one", "{0} sekund" },
						{ "other", "{0} sekunder" },
						{ "gender", "neuter" }
					}
				},
				{
					"day",
					new Dictionary<string, string>
					{
						{ "one", "{0} dag" },
						{ "other", "{0} dage" },
						{ "gender", "common" }
					}
				},
				{
					"month",
					new Dictionary<string, string>
					{
						{ "one", "{0} måned" },
						{ "other", "{0} måneder" },
						{ "gender", "common" }
					}
				},
				{
					"year",
					new Dictionary<string, string>
					{
						{ "one", "{0} år" },
						{ "other", "{0} år" },
						{ "gender", "neuter" }
					}
				},
				{
					"%",
					new Dictionary<string, string>
					{
						{ "one", "{0} procent" },
						{ "other", "{0} procent" },
						{ "gender", "common" }
					}
				},
				{
					"‰",
					new Dictionary<string, string>
					{
						{ "one", "{0} promille" },
						{ "other", "{0} promille" },
						{ "gender", "common" }
					}
				},
				{
					"°",
					new Dictionary<string, string> { { "other", "{0} grader" } }
				},
				{
					"ms",
					new Dictionary<string, string>
					{
						{ "one", "{0} millisekund" },
						{ "other", "{0} millisekunder" },
						{ "gender", "neuter" }
					}
				},
				{
					"USD",
					new Dictionary<string, string>
					{
						{ "one", "{0} amerikansk dollar" },
						{ "other", "{0} amerikanske dollar" },
						{ "gender", "common" }
					}
				},
				{
					"EUR",
					new Dictionary<string, string>
					{
						{ "other", "{0} euro" },
						{ "gender", "common" }
					}
				},
				{
					"GBP",
					new Dictionary<string, string>
					{
						{ "one", "{0} britisk pund" },
						{ "other", "{0} britiske pund" },
						{ "gender", "neuter" }
					}
				},
				{
					"JPY",
					new Dictionary<string, string>
					{
						{ "one", "{0} japansk yen" },
						{ "other", "{0} japanske yen" },
						{ "gender", "common" }
					}
				},
				{
					"CNY",
					new Dictionary<string, string>
					{
						{ "one", "{0} kinesisk yuan" },
						{ "other", "{0} kinesiske yuan" },
						{ "gender", "common" }
					}
				},
				{
					"SEK",
					new Dictionary<string, string>
					{
						{ "one", "{0} svensk krone" },
						{ "other", "{0} svenske kroner" },
						{ "gender", "common" }
					}
				},
				{
					"DKK",
					new Dictionary<string, string>
					{
						{ "one", "{0} dansk krone" },
						{ "other", "{0} danske kroner" },
						{ "gender", "common" }
					}
				},
				{
					"NOK",
					new Dictionary<string, string>
					{
						{ "one", "{0} norsk krone" },
						{ "other", "{0} norske kroner" },
						{ "gender", "common" }
					}
				},
				{
					"PLN",
					new Dictionary<string, string>
					{
						{ "one", "{0} polsk zloty" },
						{ "other", "{0} polske zloty" },
						{ "gender", "common" }
					}
				},
				{
					"RUB",
					new Dictionary<string, string>
					{
						{ "one", "{0} russisk rubel" },
						{ "other", "{0} russiske rubler" },
						{ "gender", "common" }
					}
				},
				{
					"UAH",
					new Dictionary<string, string>
					{
						{ "one", "{0} ukrainsk grynia" },
						{ "other", "{0} ukrainske grynia" },
						{ "gender", "common" }
					}
				},
				{
					"TRY",
					new Dictionary<string, string>
					{
						{ "one", "{0} tyrkisk lira" },
						{ "other", "{0} tyrkiske lira" },
						{ "gender", "common" }
					}
				},
				{
					"KRW",
					new Dictionary<string, string>
					{
						{ "one", "{0} sydkoreansk won" },
						{ "other", "{0} sydkoreanske won" },
						{ "gender", "common" }
					}
				},
				{
					"THB",
					new Dictionary<string, string>
					{
						{ "one", "{0} thailandsk baht" },
						{ "other", "{0} thailandske baht" },
						{ "gender", "common" }
					}
				},
				{
					"BRL",
					new Dictionary<string, string>
					{
						{ "one", "{0} brasiliansk real" },
						{ "other", "{0} brasilianske realer" },
						{ "gender", "common" }
					}
				}
			}
		};
		dictionary["fi"] = new Language
		{
			code = "fi",
			decimalMark = ',',
			groupMark = ' ',
			letters = new string[26]
			{
				"aa", "bee", "see", "dee", "ee", "äf", "gee", "hoo", "ii", "jii",
				"koo", "äl", "äm", "än", "oo", "pee", "kuu", "är", "äs", "tee",
				"uu", "vee", "kaksois-vee", "äks", "yy", "tseta"
			},
			datePattern = "d. MMMM y",
			months = new string[12]
			{
				"tammikuuta", "helmikuuta", "maaliskuuta", "huhtikuuta", "toukokuuta", "kesäkuuta", "heinäkuuta", "elokuuta", "syyskuuta", "lokakuuta",
				"marraskuuta", "joulukuuta"
			},
			days = new string[31]
			{
				"ensimmäinen", "toinen", "kolmas", "neljäs", "viides", "kuudes", "seitsemäs", "kahdeksas", "yhdeksäs", "kymmenes",
				"yhdestoista", "kahdestoista", "kolmastoista", "neljästoista", "viidestoista", "kuudestoista", "seitsemästoista", "kahdeksastoista", "yhdeksästoista", "kahdeskymmenes",
				"kahdeskymmenesensimmäinen", "kahdeskymmenestoinen", "kahdeskymmeneskolmas", "kahdeskymmenesneljäs", "kahdeskymmenesviides", "kahdeskymmeneskuudes", "kahdeskymmenesseitsemäs", "kahdeskymmeneskahdeksas", "kahdeskymmenesyhdeksäs", "kolmaskymmenes",
				"kolmaskymmenesensimmäinen"
			},
			terms = new Dictionary<string, string>
			{
				{ "minus", "miinus" },
				{ "plus", "plus" },
				{ "decimal", "pilkku" },
				{ "percent", "prosenttia" },
				{ "to", "viiva" },
				{ "over", "jaettuna" },
				{ "slash", "kauttaviiva" },
				{ "colon", "kaksoispiste" },
				{ "dot", "piste" },
				{ "at", "ät" },
				{ "equals", "yhtä kuin" },
				{ "and", "ja" },
				{ "times", "kertaa" },
				{ "divided", "jaettuna" },
				{ "less", "pienempi kuin" },
				{ "greater", "suurempi kuin" },
				{ "number", "numero" },
				{ "link", "linkki" },
				{ "email", "sähköposti" },
				{ "degree", "astetta" },
				{ "underscore", "alaviiva" }
			},
			readings = new Dictionary<string, string>(),
			abbreviations = new Dictionary<string, string> { { "Dr.", "tohtori" } },
			measures = new Dictionary<string, Dictionary<string, string>>
			{
				{
					"kg",
					new Dictionary<string, string>
					{
						{ "one", "{0} kilogramma" },
						{ "other", "{0} kilogrammaa" },
						{ "gender", "" }
					}
				},
				{
					"g",
					new Dictionary<string, string>
					{
						{ "one", "{0} gramma" },
						{ "other", "{0} grammaa" },
						{ "gender", "" }
					}
				},
				{
					"km",
					new Dictionary<string, string>
					{
						{ "one", "{0} kilometri" },
						{ "other", "{0} kilometriä" },
						{ "gender", "" }
					}
				},
				{
					"m",
					new Dictionary<string, string>
					{
						{ "one", "{0} metri" },
						{ "other", "{0} metriä" },
						{ "gender", "" }
					}
				},
				{
					"cm",
					new Dictionary<string, string>
					{
						{ "one", "{0} senttimetri" },
						{ "other", "{0} senttimetriä" },
						{ "gender", "" }
					}
				},
				{
					"mm",
					new Dictionary<string, string>
					{
						{ "one", "{0} millimetri" },
						{ "other", "{0} millimetriä" },
						{ "gender", "" }
					}
				},
				{
					"L",
					new Dictionary<string, string>
					{
						{ "one", "{0} litra" },
						{ "other", "{0} litraa" },
						{ "gender", "" }
					}
				},
				{
					"ml",
					new Dictionary<string, string>
					{
						{ "one", "{0} millilitra" },
						{ "other", "{0} millilitraa" },
						{ "gender", "" }
					}
				},
				{
					"°C",
					new Dictionary<string, string>
					{
						{ "one", "{0} celsiusaste" },
						{ "other", "{0} celsiusastetta" },
						{ "gender", "" }
					}
				},
				{
					"°F",
					new Dictionary<string, string>
					{
						{ "one", "{0} fahrenheitaste" },
						{ "other", "{0} fahrenheitastetta" },
						{ "gender", "" }
					}
				},
				{
					"h",
					new Dictionary<string, string>
					{
						{ "one", "{0} tunti" },
						{ "other", "{0} tuntia" },
						{ "gender", "" }
					}
				},
				{
					"min",
					new Dictionary<string, string>
					{
						{ "one", "{0} minuutti" },
						{ "other", "{0} minuuttia" },
						{ "gender", "" }
					}
				},
				{
					"s",
					new Dictionary<string, string>
					{
						{ "one", "{0} sekunti" },
						{ "other", "{0} sekuntia" },
						{ "gender", "" }
					}
				},
				{
					"day",
					new Dictionary<string, string>
					{
						{ "one", "{0} päivä" },
						{ "other", "{0} päivää" },
						{ "gender", "" }
					}
				},
				{
					"month",
					new Dictionary<string, string>
					{
						{ "one", "{0} kuukausi" },
						{ "other", "{0} kuukautta" },
						{ "gender", "" }
					}
				},
				{
					"year",
					new Dictionary<string, string>
					{
						{ "one", "{0} vuosi" },
						{ "other", "{0} vuotta" },
						{ "gender", "" }
					}
				},
				{
					"%",
					new Dictionary<string, string>
					{
						{ "one", "{0} prosentti" },
						{ "other", "{0} prosenttia" },
						{ "gender", "" }
					}
				},
				{
					"‰",
					new Dictionary<string, string>
					{
						{ "one", "{0} promille" },
						{ "other", "{0} promillea" },
						{ "gender", "" }
					}
				},
				{
					"°",
					new Dictionary<string, string>
					{
						{ "one", "{0} aste" },
						{ "other", "{0} astetta" },
						{ "gender", "" }
					}
				},
				{
					"ms",
					new Dictionary<string, string>
					{
						{ "one", "{0} millisekunti" },
						{ "other", "{0} millisekuntia" },
						{ "gender", "" }
					}
				},
				{
					"USD",
					new Dictionary<string, string>
					{
						{ "one", "{0} Yhdysvaltain dollari" },
						{ "other", "{0} Yhdysvaltain dollaria" }
					}
				},
				{
					"EUR",
					new Dictionary<string, string>
					{
						{ "one", "{0} euro" },
						{ "other", "{0} euroa" }
					}
				},
				{
					"GBP",
					new Dictionary<string, string>
					{
						{ "one", "{0} Englannin punta" },
						{ "other", "{0} Englannin puntaa" }
					}
				},
				{
					"JPY",
					new Dictionary<string, string>
					{
						{ "one", "{0} Japanin jeni" },
						{ "other", "{0} Japanin jeniä" }
					}
				},
				{
					"CNY",
					new Dictionary<string, string>
					{
						{ "one", "{0} Kiinan juan" },
						{ "other", "{0} Kiinan juania" }
					}
				},
				{
					"SEK",
					new Dictionary<string, string>
					{
						{ "one", "{0} Ruotsin kruunu" },
						{ "other", "{0} Ruotsin kruunua" }
					}
				},
				{
					"DKK",
					new Dictionary<string, string>
					{
						{ "one", "{0} Tanskan kruunu" },
						{ "other", "{0} Tanskan kruunua" }
					}
				},
				{
					"NOK",
					new Dictionary<string, string>
					{
						{ "one", "{0} Norjan kruunu" },
						{ "other", "{0} Norjan kruunua" }
					}
				},
				{
					"PLN",
					new Dictionary<string, string>
					{
						{ "one", "{0} Puolan złoty" },
						{ "other", "{0} Puolan złotya" }
					}
				},
				{
					"RUB",
					new Dictionary<string, string>
					{
						{ "one", "{0} Venäjän rupla" },
						{ "other", "{0} Venäjän ruplaa" }
					}
				},
				{
					"UAH",
					new Dictionary<string, string>
					{
						{ "one", "{0} Ukrainan hryvnia" },
						{ "other", "{0} Ukrainan hryvniaa" }
					}
				},
				{
					"TRY",
					new Dictionary<string, string>
					{
						{ "one", "{0} Turkin liira" },
						{ "other", "{0} Turkin liiraa" }
					}
				},
				{
					"KRW",
					new Dictionary<string, string>
					{
						{ "one", "{0} Etelä-Korean won" },
						{ "other", "{0} Etelä-Korean wonia" }
					}
				},
				{
					"THB",
					new Dictionary<string, string>
					{
						{ "one", "{0} Thaimaan baht" },
						{ "other", "{0} Thaimaan bahtia" }
					}
				},
				{
					"BRL",
					new Dictionary<string, string>
					{
						{ "one", "{0} Brasilian real" },
						{ "other", "{0} Brasilian realia" }
					}
				}
			}
		};
		dictionary["fr"] = new Language
		{
			code = "fr",
			decimalMark = ',',
			groupMark = ' ',
			letters = new string[26]
			{
				"a", "bé", "cé", "dé", "e", "effe", "gé", "ache", "i", "ji",
				"ka", "elle", "emme", "enne", "o", "pé", "ku", "erre", "esse", "té",
				"u", "vé", "double-vé", "iks", "i-grec", "zède"
			},
			datePattern = "d MMMM y",
			months = new string[12]
			{
				"janvier", "février", "mars", "avril", "mai", "juin", "juillet", "août", "septembre", "octobre",
				"novembre", "décembre"
			},
			days = new string[0],
			terms = new Dictionary<string, string>
			{
				{ "minus", "moins" },
				{ "plus", "plus" },
				{ "decimal", "virgule" },
				{ "percent", "pour cent" },
				{ "to", "à" },
				{ "over", "sur" },
				{ "slash", "barre oblique" },
				{ "colon", "deux points" },
				{ "dot", "point" },
				{ "at", "arobase" },
				{ "equals", "égale" },
				{ "and", "et" },
				{ "times", "fois" },
				{ "divided", "divisé par" },
				{ "less", "inférieur à" },
				{ "greater", "supérieur à" },
				{ "number", "numéro" },
				{ "link", "lien" },
				{ "email", "courriel" },
				{ "degree", "degrés" },
				{ "underscore", "tiret bas" }
			},
			readings = new Dictionary<string, string>(),
			abbreviations = new Dictionary<string, string> { { "Dr.", "docteur" } },
			measures = new Dictionary<string, Dictionary<string, string>>
			{
				{
					"kg",
					new Dictionary<string, string>
					{
						{ "one", "{0}\u00a0kilogramme" },
						{ "other", "{0}\u00a0kilogrammes" },
						{ "gender", "masculine" }
					}
				},
				{
					"g",
					new Dictionary<string, string>
					{
						{ "one", "{0}\u00a0gramme" },
						{ "other", "{0}\u00a0grammes" },
						{ "gender", "masculine" }
					}
				},
				{
					"km",
					new Dictionary<string, string>
					{
						{ "one", "{0}\u00a0kilomètre" },
						{ "other", "{0}\u00a0kilomètres" },
						{ "gender", "masculine" }
					}
				},
				{
					"m",
					new Dictionary<string, string>
					{
						{ "one", "{0}\u00a0mètre" },
						{ "other", "{0}\u00a0mètres" },
						{ "gender", "masculine" }
					}
				},
				{
					"cm",
					new Dictionary<string, string>
					{
						{ "one", "{0}\u00a0centimètre" },
						{ "other", "{0}\u00a0centimètres" },
						{ "gender", "masculine" }
					}
				},
				{
					"mm",
					new Dictionary<string, string>
					{
						{ "one", "{0}\u00a0millimètre" },
						{ "other", "{0}\u00a0millimètres" },
						{ "gender", "masculine" }
					}
				},
				{
					"L",
					new Dictionary<string, string>
					{
						{ "one", "{0}\u00a0litre" },
						{ "other", "{0}\u00a0litres" },
						{ "gender", "masculine" }
					}
				},
				{
					"ml",
					new Dictionary<string, string>
					{
						{ "one", "{0} millilitre" },
						{ "other", "{0} millilitres" },
						{ "gender", "masculine" }
					}
				},
				{
					"°C",
					new Dictionary<string, string>
					{
						{ "one", "{0}\u00a0degré Celsius" },
						{ "other", "{0}\u00a0degrés Celsius" },
						{ "gender", "masculine" }
					}
				},
				{
					"°F",
					new Dictionary<string, string>
					{
						{ "one", "{0}\u00a0degré Fahrenheit" },
						{ "other", "{0}\u00a0degrés Fahrenheit" },
						{ "gender", "masculine" }
					}
				},
				{
					"h",
					new Dictionary<string, string>
					{
						{ "one", "{0}\u00a0heure" },
						{ "other", "{0}\u00a0heures" },
						{ "gender", "feminine" }
					}
				},
				{
					"min",
					new Dictionary<string, string>
					{
						{ "one", "{0} minute" },
						{ "other", "{0} minutes" },
						{ "gender", "feminine" }
					}
				},
				{
					"s",
					new Dictionary<string, string>
					{
						{ "one", "{0}\u00a0seconde" },
						{ "other", "{0}\u00a0secondes" },
						{ "gender", "feminine" }
					}
				},
				{
					"day",
					new Dictionary<string, string>
					{
						{ "one", "{0}\u00a0jour" },
						{ "other", "{0}\u00a0jours" },
						{ "gender", "masculine" }
					}
				},
				{
					"month",
					new Dictionary<string, string>
					{
						{ "one", "{0}\u00a0mois" },
						{ "other", "{0}\u00a0mois" },
						{ "gender", "masculine" }
					}
				},
				{
					"year",
					new Dictionary<string, string>
					{
						{ "one", "{0}\u00a0an" },
						{ "other", "{0} ans" },
						{ "gender", "masculine" }
					}
				},
				{
					"%",
					new Dictionary<string, string>
					{
						{ "one", "{0} pour cent" },
						{ "other", "{0} pour cent" },
						{ "gender", "masculine" }
					}
				},
				{
					"‰",
					new Dictionary<string, string>
					{
						{ "one", "{0}\u00a0pour mille" },
						{ "other", "{0}\u00a0pour mille" },
						{ "gender", "masculine" }
					}
				},
				{
					"°",
					new Dictionary<string, string>
					{
						{ "one", "{0}\u00a0degré" },
						{ "other", "{0}\u00a0degrés" },
						{ "gender", "masculine" }
					}
				},
				{
					"ms",
					new Dictionary<string, string>
					{
						{ "one", "{0}\u00a0milliseconde" },
						{ "other", "{0}\u00a0millisecondes" },
						{ "gender", "feminine" }
					}
				},
				{
					"USD",
					new Dictionary<string, string>
					{
						{ "one", "{0} dollar des États-Unis" },
						{ "other", "{0} dollars des États-Unis" },
						{ "gender", "masculine" }
					}
				},
				{
					"EUR",
					new Dictionary<string, string>
					{
						{ "one", "{0} euro" },
						{ "other", "{0} euros" },
						{ "gender", "masculine" }
					}
				},
				{
					"GBP",
					new Dictionary<string, string>
					{
						{ "one", "{0} livre sterling" },
						{ "other", "{0} livres sterling" },
						{ "gender", "feminine" }
					}
				},
				{
					"JPY",
					new Dictionary<string, string>
					{
						{ "one", "{0} yen japonais" },
						{ "other", "{0} yens japonais" },
						{ "gender", "masculine" }
					}
				},
				{
					"CNY",
					new Dictionary<string, string>
					{
						{ "one", "{0} yuan renminbi chinois" },
						{ "other", "{0} yuans renminbi chinois" },
						{ "gender", "masculine" }
					}
				},
				{
					"SEK",
					new Dictionary<string, string>
					{
						{ "one", "{0} couronne suédoise" },
						{ "other", "{0} couronnes suédoises" },
						{ "gender", "feminine" }
					}
				},
				{
					"DKK",
					new Dictionary<string, string>
					{
						{ "one", "{0} couronne danoise" },
						{ "other", "{0} couronnes danoises" },
						{ "gender", "feminine" }
					}
				},
				{
					"NOK",
					new Dictionary<string, string>
					{
						{ "one", "{0} couronne norvégienne" },
						{ "other", "{0} couronnes norvégiennes" },
						{ "gender", "feminine" }
					}
				},
				{
					"PLN",
					new Dictionary<string, string>
					{
						{ "one", "{0} zloty polonais" },
						{ "other", "{0} zlotys polonais" },
						{ "gender", "masculine" }
					}
				},
				{
					"RUB",
					new Dictionary<string, string>
					{
						{ "one", "{0} rouble russe" },
						{ "other", "{0} roubles russes" },
						{ "gender", "masculine" }
					}
				},
				{
					"UAH",
					new Dictionary<string, string>
					{
						{ "one", "{0} hryvnia ukrainienne" },
						{ "other", "{0} hryvnias ukrainiennes" },
						{ "gender", "feminine" }
					}
				},
				{
					"TRY",
					new Dictionary<string, string>
					{
						{ "one", "{0} livre turque" },
						{ "other", "{0} livres turques" },
						{ "gender", "feminine" }
					}
				},
				{
					"KRW",
					new Dictionary<string, string>
					{
						{ "one", "{0} won sud-coréen" },
						{ "other", "{0} wons sud-coréens" },
						{ "gender", "masculine" }
					}
				},
				{
					"THB",
					new Dictionary<string, string>
					{
						{ "one", "{0} baht thaïlandais" },
						{ "other", "{0} bahts thaïlandais" },
						{ "gender", "masculine" }
					}
				},
				{
					"BRL",
					new Dictionary<string, string>
					{
						{ "one", "{0} réal brésilien" },
						{ "other", "{0} réals brésiliens" },
						{ "gender", "masculine" }
					}
				}
			}
		};
		dictionary["de"] = new Language
		{
			code = "de",
			decimalMark = ',',
			groupMark = '.',
			letters = new string[26]
			{
				"a", "be", "ce", "de", "e", "eff", "ge", "ha", "i", "jot",
				"ka", "ell", "emm", "enn", "o", "pe", "ku", "err", "ess", "te",
				"u", "fau", "we", "iks", "ypsilon", "zett"
			},
			datePattern = "d. MMMM y",
			months = new string[12]
			{
				"Januar", "Februar", "März", "April", "Mai", "Juni", "Juli", "August", "September", "Oktober",
				"November", "Dezember"
			},
			days = new string[31]
			{
				"erste", "zweite", "dritte", "vierte", "fünfte", "sechste", "siebte", "achte", "neunte", "zehnte",
				"elfte", "zwölfte", "dreizehnte", "vierzehnte", "fünfzehnte", "sechzehnte", "siebzehnte", "achtzehnte", "neunzehnte", "zwanzigste",
				"einundzwanzigste", "zweiundzwanzigste", "dreiundzwanzigste", "vierundzwanzigste", "fünfundzwanzigste", "sechsundzwanzigste", "siebenundzwanzigste", "achtundzwanzigste", "neunundzwanzigste", "dreißigste",
				"einunddreißigste"
			},
			terms = new Dictionary<string, string>
			{
				{ "minus", "minus" },
				{ "plus", "plus" },
				{ "decimal", "komma" },
				{ "percent", "prozent" },
				{ "to", "bis" },
				{ "over", "durch" },
				{ "slash", "schrägstrich" },
				{ "colon", "doppelpunkt" },
				{ "dot", "punkt" },
				{ "at", "ät" },
				{ "equals", "gleich" },
				{ "and", "und" },
				{ "times", "mal" },
				{ "divided", "geteilt durch" },
				{ "less", "kleiner als" },
				{ "greater", "größer als" },
				{ "number", "nummer" },
				{ "link", "link" },
				{ "email", "e mail" },
				{ "degree", "grad" },
				{ "underscore", "unterstrich" }
			},
			readings = new Dictionary<string, string>(),
			abbreviations = new Dictionary<string, string>
			{
				{ "Dr.", "doktor" },
				{ "z.B.", "zum beispiel" },
				{ "bzw.", "beziehungsweise" }
			},
			measures = new Dictionary<string, Dictionary<string, string>>
			{
				{
					"kg",
					new Dictionary<string, string>
					{
						{ "one", "{0} Kilogramm" },
						{ "other", "{0} Kilogramm" },
						{ "gender", "neuter" }
					}
				},
				{
					"g",
					new Dictionary<string, string>
					{
						{ "one", "{0} Gramm" },
						{ "other", "{0} Gramm" },
						{ "gender", "neuter" }
					}
				},
				{
					"km",
					new Dictionary<string, string>
					{
						{ "one", "{0} Kilometer" },
						{ "other", "{0} Kilometer" },
						{ "gender", "masculine" }
					}
				},
				{
					"m",
					new Dictionary<string, string>
					{
						{ "one", "{0} Meter" },
						{ "other", "{0} Meter" },
						{ "gender", "masculine" }
					}
				},
				{
					"cm",
					new Dictionary<string, string>
					{
						{ "one", "{0} Zentimeter" },
						{ "other", "{0} Zentimeter" },
						{ "gender", "masculine" }
					}
				},
				{
					"mm",
					new Dictionary<string, string>
					{
						{ "one", "{0} Millimeter" },
						{ "other", "{0} Millimeter" },
						{ "gender", "masculine" }
					}
				},
				{
					"L",
					new Dictionary<string, string>
					{
						{ "one", "{0} Liter" },
						{ "other", "{0} Liter" },
						{ "gender", "masculine" }
					}
				},
				{
					"ml",
					new Dictionary<string, string>
					{
						{ "one", "{0}\u00a0Milliliter" },
						{ "other", "{0}\u00a0Milliliter" },
						{ "gender", "masculine" }
					}
				},
				{
					"°C",
					new Dictionary<string, string>
					{
						{ "one", "{0} Grad Celsius" },
						{ "other", "{0} Grad Celsius" },
						{ "gender", "neuter" }
					}
				},
				{
					"°F",
					new Dictionary<string, string>
					{
						{ "one", "{0} Grad Fahrenheit" },
						{ "other", "{0} Grad Fahrenheit" },
						{ "gender", "neuter" }
					}
				},
				{
					"h",
					new Dictionary<string, string>
					{
						{ "one", "{0} Stunde" },
						{ "other", "{0} Stunden" },
						{ "gender", "feminine" }
					}
				},
				{
					"min",
					new Dictionary<string, string>
					{
						{ "one", "{0} Minute" },
						{ "other", "{0} Minuten" },
						{ "gender", "feminine" }
					}
				},
				{
					"s",
					new Dictionary<string, string>
					{
						{ "one", "{0} Sekunde" },
						{ "other", "{0} Sekunden" },
						{ "gender", "feminine" }
					}
				},
				{
					"day",
					new Dictionary<string, string>
					{
						{ "one", "{0} Tag" },
						{ "other", "{0} Tage" },
						{ "gender", "masculine" }
					}
				},
				{
					"month",
					new Dictionary<string, string>
					{
						{ "one", "{0} Monat" },
						{ "other", "{0} Monate" },
						{ "gender", "masculine" }
					}
				},
				{
					"year",
					new Dictionary<string, string>
					{
						{ "one", "{0} Jahr" },
						{ "other", "{0} Jahre" },
						{ "gender", "neuter" }
					}
				},
				{
					"%",
					new Dictionary<string, string>
					{
						{ "one", "{0} Prozent" },
						{ "other", "{0} Prozent" },
						{ "gender", "neuter" }
					}
				},
				{
					"‰",
					new Dictionary<string, string>
					{
						{ "one", "{0} Promille" },
						{ "other", "{0} Promille" },
						{ "gender", "neuter" }
					}
				},
				{
					"°",
					new Dictionary<string, string>
					{
						{ "one", "{0} Grad" },
						{ "other", "{0} Grad" },
						{ "gender", "neuter" }
					}
				},
				{
					"ms",
					new Dictionary<string, string>
					{
						{ "one", "{0} Millisekunde" },
						{ "other", "{0} Millisekunden" },
						{ "gender", "feminine" }
					}
				},
				{
					"USD",
					new Dictionary<string, string>
					{
						{ "other", "{0} US-Dollar" },
						{ "gender", "masculine" }
					}
				},
				{
					"EUR",
					new Dictionary<string, string>
					{
						{ "other", "{0} Euro" },
						{ "gender", "masculine" }
					}
				},
				{
					"GBP",
					new Dictionary<string, string>
					{
						{ "one", "{0} Britisches Pfund" },
						{ "other", "{0} Britische Pfund" },
						{ "gender", "neuter" }
					}
				},
				{
					"JPY",
					new Dictionary<string, string>
					{
						{ "one", "{0} Japanischer Yen" },
						{ "other", "{0} Japanische Yen" },
						{ "gender", "masculine" }
					}
				},
				{
					"CNY",
					new Dictionary<string, string>
					{
						{ "one", "{0} Chinesischer Yuan" },
						{ "other", "{0} Renminbi Yuan" },
						{ "gender", "masculine" }
					}
				},
				{
					"SEK",
					new Dictionary<string, string>
					{
						{ "one", "{0} Schwedische Krone" },
						{ "other", "{0} Schwedische Kronen" },
						{ "gender", "feminine" }
					}
				},
				{
					"DKK",
					new Dictionary<string, string>
					{
						{ "one", "{0} Dänische Krone" },
						{ "other", "{0} Dänische Kronen" },
						{ "gender", "feminine" }
					}
				},
				{
					"NOK",
					new Dictionary<string, string>
					{
						{ "one", "{0} Norwegische Krone" },
						{ "other", "{0} Norwegische Kronen" },
						{ "gender", "feminine" }
					}
				},
				{
					"PLN",
					new Dictionary<string, string>
					{
						{ "one", "{0} Polnischer Złoty" },
						{ "other", "{0} Polnische Złoty" },
						{ "gender", "masculine" }
					}
				},
				{
					"RUB",
					new Dictionary<string, string>
					{
						{ "one", "{0} Russischer Rubel" },
						{ "other", "{0} Russische Rubel" },
						{ "gender", "masculine" }
					}
				},
				{
					"UAH",
					new Dictionary<string, string>
					{
						{ "one", "{0} Ukrainische Hrywnja" },
						{ "other", "{0} Ukrainische Hrywen" },
						{ "gender", "feminine" }
					}
				},
				{
					"TRY",
					new Dictionary<string, string>
					{
						{ "other", "{0} Türkische Lira" },
						{ "gender", "feminine" }
					}
				},
				{
					"KRW",
					new Dictionary<string, string>
					{
						{ "one", "{0} Südkoreanischer Won" },
						{ "other", "{0} Südkoreanische Won" },
						{ "gender", "masculine" }
					}
				},
				{
					"THB",
					new Dictionary<string, string>
					{
						{ "one", "{0} Thailändischer Baht" },
						{ "other", "{0} Thailändische Baht" },
						{ "gender", "masculine" }
					}
				},
				{
					"BRL",
					new Dictionary<string, string>
					{
						{ "one", "{0} Brasilianischer Real" },
						{ "other", "{0} Brasilianische Real" },
						{ "gender", "masculine" }
					}
				}
			}
		};
		dictionary["it"] = new Language
		{
			code = "it",
			decimalMark = ',',
			groupMark = '.',
			letters = new string[26]
			{
				"a", "bi", "ci", "di", "e", "effe", "gi", "acca", "i", "i-lunga",
				"cappa", "elle", "emme", "enne", "o", "pi", "cu", "erre", "esse", "ti",
				"u", "vu", "doppia-vu", "ics", "ipsilon", "zeta"
			},
			datePattern = "d MMMM y",
			months = new string[12]
			{
				"gennaio", "febbraio", "marzo", "aprile", "maggio", "giugno", "luglio", "agosto", "settembre", "ottobre",
				"novembre", "dicembre"
			},
			days = new string[0],
			terms = new Dictionary<string, string>
			{
				{ "minus", "meno" },
				{ "plus", "più" },
				{ "decimal", "virgola" },
				{ "percent", "per cento" },
				{ "to", "a" },
				{ "over", "su" },
				{ "slash", "barra" },
				{ "colon", "due punti" },
				{ "dot", "punto" },
				{ "at", "chiocciola" },
				{ "equals", "uguale" },
				{ "and", "e" },
				{ "times", "per" },
				{ "divided", "diviso" },
				{ "less", "minore di" },
				{ "greater", "maggiore di" },
				{ "number", "numero" },
				{ "link", "collegamento" },
				{ "email", "email" },
				{ "degree", "gradi" },
				{ "underscore", "trattino basso" }
			},
			readings = new Dictionary<string, string>(),
			abbreviations = new Dictionary<string, string> { { "Dr.", "dottore" } },
			measures = new Dictionary<string, Dictionary<string, string>>
			{
				{
					"kg",
					new Dictionary<string, string>
					{
						{ "one", "{0} chilogrammo" },
						{ "other", "{0} chilogrammi" },
						{ "gender", "masculine" }
					}
				},
				{
					"g",
					new Dictionary<string, string>
					{
						{ "one", "{0} grammo" },
						{ "other", "{0} grammi" },
						{ "gender", "masculine" }
					}
				},
				{
					"km",
					new Dictionary<string, string>
					{
						{ "one", "{0} chilometro" },
						{ "other", "{0} chilometri" },
						{ "gender", "masculine" }
					}
				},
				{
					"m",
					new Dictionary<string, string>
					{
						{ "one", "{0} metro" },
						{ "other", "{0} metri" },
						{ "gender", "masculine" }
					}
				},
				{
					"cm",
					new Dictionary<string, string>
					{
						{ "one", "{0} centimetro" },
						{ "other", "{0} centimetri" },
						{ "gender", "masculine" }
					}
				},
				{
					"mm",
					new Dictionary<string, string>
					{
						{ "one", "{0} millimetro" },
						{ "other", "{0} millimetri" },
						{ "gender", "masculine" }
					}
				},
				{
					"L",
					new Dictionary<string, string>
					{
						{ "one", "{0} litro" },
						{ "other", "{0} litri" },
						{ "gender", "masculine" }
					}
				},
				{
					"ml",
					new Dictionary<string, string>
					{
						{ "one", "{0} millilitro" },
						{ "other", "{0} millilitri" },
						{ "gender", "masculine" }
					}
				},
				{
					"°C",
					new Dictionary<string, string>
					{
						{ "one", "{0} grado Celsius" },
						{ "other", "{0} gradi Celsius" },
						{ "gender", "masculine" }
					}
				},
				{
					"°F",
					new Dictionary<string, string>
					{
						{ "one", "{0} grado Fahrenheit" },
						{ "other", "{0} gradi Fahrenheit" },
						{ "gender", "masculine" }
					}
				},
				{
					"h",
					new Dictionary<string, string>
					{
						{ "one", "{0} ora" },
						{ "other", "{0} ore" },
						{ "gender", "feminine" }
					}
				},
				{
					"min",
					new Dictionary<string, string>
					{
						{ "one", "{0} minuto" },
						{ "other", "{0} minuti" },
						{ "gender", "masculine" }
					}
				},
				{
					"s",
					new Dictionary<string, string>
					{
						{ "one", "{0} secondo" },
						{ "other", "{0} secondi" },
						{ "gender", "masculine" }
					}
				},
				{
					"day",
					new Dictionary<string, string>
					{
						{ "one", "{0} giorno" },
						{ "other", "{0} giorni" },
						{ "gender", "masculine" }
					}
				},
				{
					"month",
					new Dictionary<string, string>
					{
						{ "one", "{0} mese" },
						{ "other", "{0} mesi" },
						{ "gender", "masculine" }
					}
				},
				{
					"year",
					new Dictionary<string, string>
					{
						{ "one", "{0} anno" },
						{ "other", "{0} anni" },
						{ "gender", "masculine" }
					}
				},
				{
					"%",
					new Dictionary<string, string>
					{
						{ "one", "{0} percento" },
						{ "other", "{0} percento" },
						{ "gender", "masculine" }
					}
				},
				{
					"‰",
					new Dictionary<string, string>
					{
						{ "one", "{0} per mille" },
						{ "other", "{0} per mille" },
						{ "gender", "masculine" }
					}
				},
				{
					"°",
					new Dictionary<string, string>
					{
						{ "one", "{0} grado" },
						{ "other", "{0} gradi" },
						{ "gender", "masculine" }
					}
				},
				{
					"ms",
					new Dictionary<string, string>
					{
						{ "one", "{0} millisecondo" },
						{ "other", "{0} millisecondi" },
						{ "gender", "masculine" }
					}
				},
				{
					"USD",
					new Dictionary<string, string>
					{
						{ "one", "{0} dollaro statunitense" },
						{ "other", "{0} dollari statunitensi" },
						{ "gender", "masculine" }
					}
				},
				{
					"EUR",
					new Dictionary<string, string>
					{
						{ "other", "{0} euro" },
						{ "gender", "masculine" }
					}
				},
				{
					"GBP",
					new Dictionary<string, string>
					{
						{ "one", "{0} sterlina britannica" },
						{ "other", "{0} sterline britanniche" },
						{ "gender", "feminine" }
					}
				},
				{
					"JPY",
					new Dictionary<string, string>
					{
						{ "one", "{0} yen giapponese" },
						{ "other", "{0} yen giapponesi" },
						{ "gender", "masculine" }
					}
				},
				{
					"CNY",
					new Dictionary<string, string>
					{
						{ "one", "{0} yuan cinese" },
						{ "other", "{0} yuan cinesi" },
						{ "gender", "masculine" }
					}
				},
				{
					"SEK",
					new Dictionary<string, string>
					{
						{ "one", "{0} corona svedese" },
						{ "other", "{0} corone svedesi" },
						{ "gender", "feminine" }
					}
				},
				{
					"DKK",
					new Dictionary<string, string>
					{
						{ "one", "{0} corona danese" },
						{ "other", "{0} corone danesi" },
						{ "gender", "feminine" }
					}
				},
				{
					"NOK",
					new Dictionary<string, string>
					{
						{ "one", "{0} corona norvegese" },
						{ "other", "{0} corone norvegesi" },
						{ "gender", "feminine" }
					}
				},
				{
					"PLN",
					new Dictionary<string, string>
					{
						{ "one", "{0} zloty polacco" },
						{ "other", "{0} zloty polacchi" },
						{ "gender", "masculine" }
					}
				},
				{
					"RUB",
					new Dictionary<string, string>
					{
						{ "one", "{0} rublo russo" },
						{ "other", "{0} rubli russi" },
						{ "gender", "masculine" }
					}
				},
				{
					"UAH",
					new Dictionary<string, string>
					{
						{ "one", "{0} grivnia ucraina" },
						{ "other", "{0} grivnie ucraine" },
						{ "gender", "feminine" }
					}
				},
				{
					"TRY",
					new Dictionary<string, string>
					{
						{ "one", "{0} lira turca" },
						{ "other", "{0} lire turche" },
						{ "gender", "feminine" }
					}
				},
				{
					"KRW",
					new Dictionary<string, string>
					{
						{ "one", "{0} won sudcoreano" },
						{ "other", "{0} won sudcoreani" },
						{ "gender", "masculine" }
					}
				},
				{
					"THB",
					new Dictionary<string, string>
					{
						{ "one", "{0} baht thailandese" },
						{ "other", "{0} baht thailandesi" },
						{ "gender", "masculine" }
					}
				},
				{
					"BRL",
					new Dictionary<string, string>
					{
						{ "one", "{0} real brasiliano" },
						{ "other", "{0} real brasiliani" },
						{ "gender", "masculine" }
					}
				}
			}
		};
		dictionary["es"] = new Language
		{
			code = "es",
			decimalMark = ',',
			groupMark = '.',
			letters = new string[26]
			{
				"a", "be", "ce", "de", "e", "efe", "ge", "hache", "i", "jota",
				"ka", "ele", "eme", "ene", "o", "pe", "cu", "erre", "ese", "te",
				"u", "uve", "doble-uve", "equis", "ye", "zeta"
			},
			datePattern = "d 'de' MMMM 'de' y",
			months = new string[12]
			{
				"enero", "febrero", "marzo", "abril", "mayo", "junio", "julio", "agosto", "septiembre", "octubre",
				"noviembre", "diciembre"
			},
			days = new string[0],
			terms = new Dictionary<string, string>
			{
				{ "minus", "menos" },
				{ "plus", "más" },
				{ "decimal", "coma" },
				{ "percent", "por ciento" },
				{ "to", "a" },
				{ "over", "sobre" },
				{ "slash", "barra" },
				{ "colon", "dos puntos" },
				{ "dot", "punto" },
				{ "at", "arroba" },
				{ "equals", "igual a" },
				{ "and", "y" },
				{ "times", "por" },
				{ "divided", "dividido por" },
				{ "less", "menor que" },
				{ "greater", "mayor que" },
				{ "number", "número" },
				{ "link", "enlace" },
				{ "email", "correo" },
				{ "degree", "grados" },
				{ "underscore", "guion bajo" }
			},
			readings = new Dictionary<string, string>(),
			abbreviations = new Dictionary<string, string> { { "Dr.", "doctor" } },
			measures = new Dictionary<string, Dictionary<string, string>>
			{
				{
					"kg",
					new Dictionary<string, string>
					{
						{ "one", "{0} kilogramo" },
						{ "other", "{0} kilogramos" },
						{ "gender", "masculine" }
					}
				},
				{
					"g",
					new Dictionary<string, string>
					{
						{ "one", "{0} gramo" },
						{ "other", "{0} gramos" },
						{ "gender", "masculine" }
					}
				},
				{
					"km",
					new Dictionary<string, string>
					{
						{ "one", "{0} kilómetro" },
						{ "other", "{0} kilómetros" },
						{ "gender", "masculine" }
					}
				},
				{
					"m",
					new Dictionary<string, string>
					{
						{ "one", "{0} metro" },
						{ "other", "{0} metros" },
						{ "gender", "masculine" }
					}
				},
				{
					"cm",
					new Dictionary<string, string>
					{
						{ "one", "{0} centímetro" },
						{ "other", "{0} centímetros" },
						{ "gender", "masculine" }
					}
				},
				{
					"mm",
					new Dictionary<string, string>
					{
						{ "one", "{0} milímetro" },
						{ "other", "{0} milímetros" },
						{ "gender", "masculine" }
					}
				},
				{
					"L",
					new Dictionary<string, string>
					{
						{ "one", "{0} litro" },
						{ "other", "{0} litros" },
						{ "gender", "masculine" }
					}
				},
				{
					"ml",
					new Dictionary<string, string>
					{
						{ "one", "{0} mililitro" },
						{ "other", "{0} mililitros" },
						{ "gender", "masculine" }
					}
				},
				{
					"°C",
					new Dictionary<string, string>
					{
						{ "one", "{0} grado Celsius" },
						{ "other", "{0} grados Celsius" },
						{ "gender", "masculine" }
					}
				},
				{
					"°F",
					new Dictionary<string, string>
					{
						{ "one", "{0} grado Fahrenheit" },
						{ "other", "{0} grados Fahrenheit" },
						{ "gender", "masculine" }
					}
				},
				{
					"h",
					new Dictionary<string, string>
					{
						{ "one", "{0} hora" },
						{ "other", "{0} horas" },
						{ "gender", "feminine" }
					}
				},
				{
					"min",
					new Dictionary<string, string>
					{
						{ "one", "{0} minuto" },
						{ "other", "{0} minutos" },
						{ "gender", "masculine" }
					}
				},
				{
					"s",
					new Dictionary<string, string>
					{
						{ "one", "{0} segundo" },
						{ "other", "{0} segundos" },
						{ "gender", "masculine" }
					}
				},
				{
					"day",
					new Dictionary<string, string>
					{
						{ "one", "{0} día" },
						{ "other", "{0} días" },
						{ "gender", "masculine" }
					}
				},
				{
					"month",
					new Dictionary<string, string>
					{
						{ "one", "{0} mes" },
						{ "other", "{0} meses" },
						{ "gender", "masculine" }
					}
				},
				{
					"year",
					new Dictionary<string, string>
					{
						{ "one", "{0} año" },
						{ "other", "{0} años" },
						{ "gender", "masculine" }
					}
				},
				{
					"%",
					new Dictionary<string, string>
					{
						{ "one", "{0} por ciento" },
						{ "other", "{0} por ciento" },
						{ "gender", "masculine" }
					}
				},
				{
					"‰",
					new Dictionary<string, string>
					{
						{ "one", "{0} por mil" },
						{ "other", "{0} por mil" },
						{ "gender", "masculine" }
					}
				},
				{
					"°",
					new Dictionary<string, string>
					{
						{ "one", "{0} grado" },
						{ "other", "{0} grados" },
						{ "gender", "masculine" }
					}
				},
				{
					"ms",
					new Dictionary<string, string>
					{
						{ "one", "{0} milisegundo" },
						{ "other", "{0} milisegundos" },
						{ "gender", "masculine" }
					}
				},
				{
					"USD",
					new Dictionary<string, string>
					{
						{ "one", "{0} dólar estadounidense" },
						{ "other", "{0} dólares estadounidenses" },
						{ "gender", "masculine" }
					}
				},
				{
					"EUR",
					new Dictionary<string, string>
					{
						{ "one", "{0} euro" },
						{ "other", "{0} euros" },
						{ "gender", "masculine" }
					}
				},
				{
					"GBP",
					new Dictionary<string, string>
					{
						{ "one", "{0} libra esterlina" },
						{ "other", "{0} libras esterlinas" },
						{ "gender", "feminine" }
					}
				},
				{
					"JPY",
					new Dictionary<string, string>
					{
						{ "one", "{0} yen japonés" },
						{ "other", "{0} yenes japoneses" },
						{ "gender", "masculine" }
					}
				},
				{
					"CNY",
					new Dictionary<string, string>
					{
						{ "one", "{0} yuan renminbi" },
						{ "other", "{0} yuanes renminbi" },
						{ "gender", "masculine" }
					}
				},
				{
					"SEK",
					new Dictionary<string, string>
					{
						{ "one", "{0} corona sueca" },
						{ "other", "{0} coronas suecas" },
						{ "gender", "feminine" }
					}
				},
				{
					"DKK",
					new Dictionary<string, string>
					{
						{ "one", "{0} corona danesa" },
						{ "other", "{0} coronas danesas" },
						{ "gender", "feminine" }
					}
				},
				{
					"NOK",
					new Dictionary<string, string>
					{
						{ "one", "{0} corona noruega" },
						{ "other", "{0} coronas noruegas" },
						{ "gender", "feminine" }
					}
				},
				{
					"PLN",
					new Dictionary<string, string>
					{
						{ "one", "{0} esloti polaco" },
						{ "other", "{0} eslotis polacos" },
						{ "gender", "masculine" }
					}
				},
				{
					"RUB",
					new Dictionary<string, string>
					{
						{ "one", "{0} rublo ruso" },
						{ "other", "{0} rublos rusos" },
						{ "gender", "masculine" }
					}
				},
				{
					"UAH",
					new Dictionary<string, string>
					{
						{ "one", "{0} grivna ucraniana" },
						{ "other", "{0} grivnas ucranianas" },
						{ "gender", "feminine" }
					}
				},
				{
					"TRY",
					new Dictionary<string, string>
					{
						{ "one", "{0} lira turca" },
						{ "other", "{0} liras turcas" },
						{ "gender", "feminine" }
					}
				},
				{
					"KRW",
					new Dictionary<string, string>
					{
						{ "one", "{0} won surcoreano" },
						{ "other", "{0} wons surcoreanos" },
						{ "gender", "masculine" }
					}
				},
				{
					"THB",
					new Dictionary<string, string>
					{
						{ "one", "{0} bat tailandés" },
						{ "other", "{0} bats tailandeses" },
						{ "gender", "masculine" }
					}
				},
				{
					"BRL",
					new Dictionary<string, string>
					{
						{ "one", "{0} real brasileño" },
						{ "other", "{0} reales brasileños" },
						{ "gender", "masculine" }
					}
				}
			}
		};
		dictionary["pt"] = new Language
		{
			code = "pt",
			decimalMark = ',',
			groupMark = '.',
			letters = new string[26]
			{
				"a", "bê", "cê", "dê", "ê", "efe", "gê", "agá", "i", "jota",
				"cá", "ele", "eme", "ene", "ó", "pê", "quê", "erre", "esse", "tê",
				"u", "vê", "dáblio", "xis", "ípsilon", "zê"
			},
			datePattern = "d 'de' MMMM 'de' y",
			months = new string[12]
			{
				"janeiro", "fevereiro", "março", "abril", "maio", "junho", "julho", "agosto", "setembro", "outubro",
				"novembro", "dezembro"
			},
			days = new string[0],
			terms = new Dictionary<string, string>
			{
				{ "minus", "menos" },
				{ "plus", "mais" },
				{ "decimal", "vírgula" },
				{ "percent", "por cento" },
				{ "to", "a" },
				{ "over", "sobre" },
				{ "slash", "barra" },
				{ "colon", "dois pontos" },
				{ "dot", "ponto" },
				{ "at", "arroba" },
				{ "equals", "igual a" },
				{ "and", "e" },
				{ "times", "vezes" },
				{ "divided", "dividido por" },
				{ "less", "menor que" },
				{ "greater", "maior que" },
				{ "number", "número" },
				{ "link", "link" },
				{ "email", "email" },
				{ "degree", "graus" },
				{ "underscore", "sublinhado" }
			},
			readings = new Dictionary<string, string>(),
			abbreviations = new Dictionary<string, string> { { "Dr.", "doutor" } },
			measures = new Dictionary<string, Dictionary<string, string>>
			{
				{
					"kg",
					new Dictionary<string, string>
					{
						{ "one", "{0} quilograma" },
						{ "other", "{0} quilogramas" },
						{ "gender", "masculine" }
					}
				},
				{
					"g",
					new Dictionary<string, string>
					{
						{ "one", "{0} grama" },
						{ "other", "{0} gramas" },
						{ "gender", "masculine" }
					}
				},
				{
					"km",
					new Dictionary<string, string>
					{
						{ "one", "{0} quilômetro" },
						{ "other", "{0} quilômetros" },
						{ "gender", "masculine" }
					}
				},
				{
					"m",
					new Dictionary<string, string>
					{
						{ "one", "{0} metro" },
						{ "other", "{0} metros" },
						{ "gender", "masculine" }
					}
				},
				{
					"cm",
					new Dictionary<string, string>
					{
						{ "one", "{0} centímetro" },
						{ "other", "{0} centímetros" },
						{ "gender", "masculine" }
					}
				},
				{
					"mm",
					new Dictionary<string, string>
					{
						{ "one", "{0} milímetro" },
						{ "other", "{0} milímetros" },
						{ "gender", "masculine" }
					}
				},
				{
					"L",
					new Dictionary<string, string>
					{
						{ "one", "{0} litro" },
						{ "other", "{0} litros" },
						{ "gender", "masculine" }
					}
				},
				{
					"ml",
					new Dictionary<string, string>
					{
						{ "one", "{0} mililitro" },
						{ "other", "{0} mililitros" },
						{ "gender", "masculine" }
					}
				},
				{
					"°C",
					new Dictionary<string, string>
					{
						{ "one", "{0} grau Celsius" },
						{ "other", "{0} graus Celsius" },
						{ "gender", "masculine" }
					}
				},
				{
					"°F",
					new Dictionary<string, string>
					{
						{ "one", "{0} grau Fahrenheit" },
						{ "other", "{0} graus Fahrenheit" },
						{ "gender", "masculine" }
					}
				},
				{
					"h",
					new Dictionary<string, string>
					{
						{ "one", "{0} hora" },
						{ "other", "{0} horas" },
						{ "gender", "feminine" }
					}
				},
				{
					"min",
					new Dictionary<string, string>
					{
						{ "one", "{0} minuto" },
						{ "other", "{0} minutos" },
						{ "gender", "masculine" }
					}
				},
				{
					"s",
					new Dictionary<string, string>
					{
						{ "one", "{0} segundo" },
						{ "other", "{0} segundos" },
						{ "gender", "masculine" }
					}
				},
				{
					"day",
					new Dictionary<string, string>
					{
						{ "one", "{0} dia" },
						{ "other", "{0} dias" },
						{ "gender", "masculine" }
					}
				},
				{
					"month",
					new Dictionary<string, string>
					{
						{ "one", "{0} mês" },
						{ "other", "{0} meses" },
						{ "gender", "masculine" }
					}
				},
				{
					"year",
					new Dictionary<string, string>
					{
						{ "one", "{0} ano" },
						{ "other", "{0} anos" },
						{ "gender", "masculine" }
					}
				},
				{
					"%",
					new Dictionary<string, string>
					{
						{ "one", "{0} por cento" },
						{ "other", "{0} por cento" },
						{ "gender", "masculine" }
					}
				},
				{
					"‰",
					new Dictionary<string, string>
					{
						{ "one", "{0} por mil" },
						{ "other", "{0} por mil" },
						{ "gender", "masculine" }
					}
				},
				{
					"°",
					new Dictionary<string, string> { { "other", "{0} graus" } }
				},
				{
					"ms",
					new Dictionary<string, string>
					{
						{ "one", "{0} milissegundo" },
						{ "other", "{0} milissegundos" },
						{ "gender", "masculine" }
					}
				},
				{
					"USD",
					new Dictionary<string, string>
					{
						{ "one", "{0} Dólar americano" },
						{ "other", "{0} Dólares americanos" },
						{ "gender", "masculine" }
					}
				},
				{
					"EUR",
					new Dictionary<string, string>
					{
						{ "one", "{0} Euro" },
						{ "other", "{0} Euros" },
						{ "gender", "masculine" }
					}
				},
				{
					"GBP",
					new Dictionary<string, string>
					{
						{ "one", "{0} Libra esterlina" },
						{ "other", "{0} Libras esterlinas" },
						{ "gender", "feminine" }
					}
				},
				{
					"JPY",
					new Dictionary<string, string>
					{
						{ "one", "{0} Iene japonês" },
						{ "other", "{0} Ienes japoneses" },
						{ "gender", "masculine" }
					}
				},
				{
					"CNY",
					new Dictionary<string, string>
					{
						{ "one", "{0} Yuan chinês" },
						{ "other", "{0} Yuans chineses" },
						{ "gender", "masculine" }
					}
				},
				{
					"SEK",
					new Dictionary<string, string>
					{
						{ "one", "{0} Coroa sueca" },
						{ "other", "{0} Coroas suecas" },
						{ "gender", "feminine" }
					}
				},
				{
					"DKK",
					new Dictionary<string, string>
					{
						{ "one", "{0} Coroa dinamarquesa" },
						{ "other", "{0} Coroas dinamarquesas" },
						{ "gender", "feminine" }
					}
				},
				{
					"NOK",
					new Dictionary<string, string>
					{
						{ "one", "{0} Coroa norueguesa" },
						{ "other", "{0} Coroas norueguesas" },
						{ "gender", "feminine" }
					}
				},
				{
					"PLN",
					new Dictionary<string, string>
					{
						{ "one", "{0} Zloty polonês" },
						{ "other", "{0} Zlotys poloneses" },
						{ "gender", "masculine" }
					}
				},
				{
					"RUB",
					new Dictionary<string, string>
					{
						{ "one", "{0} Rublo russo" },
						{ "other", "{0} Rublos russos" },
						{ "gender", "masculine" }
					}
				},
				{
					"UAH",
					new Dictionary<string, string>
					{
						{ "one", "{0} Hryvnia ucraniano" },
						{ "other", "{0} Hryvnias ucranianos" },
						{ "gender", "feminine" }
					}
				},
				{
					"TRY",
					new Dictionary<string, string>
					{
						{ "one", "{0} Lira turca" },
						{ "other", "{0} Liras turcas" },
						{ "gender", "feminine" }
					}
				},
				{
					"KRW",
					new Dictionary<string, string>
					{
						{ "one", "{0} Won sul-coreano" },
						{ "other", "{0} Wons sul-coreanos" },
						{ "gender", "masculine" }
					}
				},
				{
					"THB",
					new Dictionary<string, string>
					{
						{ "one", "{0} Baht tailandês" },
						{ "other", "{0} Bahts tailandeses" },
						{ "gender", "masculine" }
					}
				},
				{
					"BRL",
					new Dictionary<string, string>
					{
						{ "one", "{0} Real brasileiro" },
						{ "other", "{0} Reais brasileiros" },
						{ "gender", "masculine" }
					}
				}
			}
		};
		dictionary["pt-PT"] = new Language
		{
			code = "pt-PT",
			decimalMark = ',',
			groupMark = '.',
			letters = new string[26]
			{
				"a", "bê", "cê", "dê", "ê", "efe", "gê", "agá", "i", "jota",
				"cá", "ele", "eme", "ene", "ó", "pê", "quê", "erre", "esse", "tê",
				"u", "vê", "dáblio", "xis", "ípsilon", "zê"
			},
			datePattern = "d 'de' MMMM 'de' y",
			months = new string[12]
			{
				"janeiro", "fevereiro", "março", "abril", "maio", "junho", "julho", "agosto", "setembro", "outubro",
				"novembro", "dezembro"
			},
			days = new string[0],
			terms = new Dictionary<string, string>
			{
				{ "minus", "menos" },
				{ "plus", "mais" },
				{ "decimal", "vírgula" },
				{ "percent", "por cento" },
				{ "to", "a" },
				{ "over", "sobre" },
				{ "slash", "barra" },
				{ "colon", "dois pontos" },
				{ "dot", "ponto" },
				{ "at", "arroba" },
				{ "equals", "igual a" },
				{ "and", "e" },
				{ "times", "vezes" },
				{ "divided", "dividido por" },
				{ "less", "menor que" },
				{ "greater", "maior que" },
				{ "number", "número" },
				{ "link", "link" },
				{ "email", "email" },
				{ "degree", "graus" },
				{ "underscore", "sublinhado" }
			},
			readings = new Dictionary<string, string>(),
			abbreviations = new Dictionary<string, string> { { "Dr.", "doutor" } },
			measures = new Dictionary<string, Dictionary<string, string>>
			{
				{
					"kg",
					new Dictionary<string, string>
					{
						{ "one", "{0} quilograma" },
						{ "other", "{0} quilogramas" },
						{ "gender", "masculine" }
					}
				},
				{
					"g",
					new Dictionary<string, string>
					{
						{ "one", "{0} grama" },
						{ "other", "{0} gramas" },
						{ "gender", "masculine" }
					}
				},
				{
					"km",
					new Dictionary<string, string>
					{
						{ "one", "{0} quilómetro" },
						{ "other", "{0} quilómetros" },
						{ "gender", "masculine" }
					}
				},
				{
					"m",
					new Dictionary<string, string>
					{
						{ "one", "{0} metro" },
						{ "other", "{0} metros" },
						{ "gender", "masculine" }
					}
				},
				{
					"cm",
					new Dictionary<string, string>
					{
						{ "one", "{0} centímetro" },
						{ "other", "{0} centímetros" },
						{ "gender", "masculine" }
					}
				},
				{
					"mm",
					new Dictionary<string, string>
					{
						{ "one", "{0} milímetro" },
						{ "other", "{0} milímetros" },
						{ "gender", "masculine" }
					}
				},
				{
					"L",
					new Dictionary<string, string>
					{
						{ "one", "{0} litro" },
						{ "other", "{0} litros" },
						{ "gender", "masculine" }
					}
				},
				{
					"ml",
					new Dictionary<string, string>
					{
						{ "one", "{0} mililitro" },
						{ "other", "{0} mililitros" },
						{ "gender", "masculine" }
					}
				},
				{
					"°C",
					new Dictionary<string, string>
					{
						{ "one", "{0} grau Celsius" },
						{ "other", "{0} graus Celsius" },
						{ "gender", "masculine" }
					}
				},
				{
					"°F",
					new Dictionary<string, string>
					{
						{ "one", "{0} grau Fahrenheit" },
						{ "other", "{0} graus Fahrenheit" },
						{ "gender", "masculine" }
					}
				},
				{
					"h",
					new Dictionary<string, string>
					{
						{ "one", "{0} hora" },
						{ "other", "{0} horas" },
						{ "gender", "feminine" }
					}
				},
				{
					"min",
					new Dictionary<string, string>
					{
						{ "one", "{0} minuto" },
						{ "other", "{0} minutos" },
						{ "gender", "masculine" }
					}
				},
				{
					"s",
					new Dictionary<string, string>
					{
						{ "one", "{0} segundo" },
						{ "other", "{0} segundos" },
						{ "gender", "masculine" }
					}
				},
				{
					"day",
					new Dictionary<string, string>
					{
						{ "one", "{0} dia" },
						{ "other", "{0} dias" },
						{ "gender", "masculine" }
					}
				},
				{
					"month",
					new Dictionary<string, string>
					{
						{ "one", "{0} mês" },
						{ "other", "{0} meses" },
						{ "gender", "masculine" }
					}
				},
				{
					"year",
					new Dictionary<string, string>
					{
						{ "one", "{0} ano" },
						{ "other", "{0} anos" },
						{ "gender", "masculine" }
					}
				},
				{
					"%",
					new Dictionary<string, string>
					{
						{ "one", "{0} por cento" },
						{ "other", "{0} por cento" },
						{ "gender", "masculine" }
					}
				},
				{
					"‰",
					new Dictionary<string, string>
					{
						{ "one", "{0} por mil" },
						{ "other", "{0} por mil" },
						{ "gender", "masculine" }
					}
				},
				{
					"°",
					new Dictionary<string, string> { { "other", "{0} graus" } }
				},
				{
					"ms",
					new Dictionary<string, string>
					{
						{ "one", "{0} milissegundo" },
						{ "other", "{0} milissegundos" },
						{ "gender", "masculine" }
					}
				},
				{
					"USD",
					new Dictionary<string, string>
					{
						{ "one", "{0} dólar dos Estados Unidos" },
						{ "other", "{0} dólares dos Estados Unidos" },
						{ "gender", "masculine" }
					}
				},
				{
					"EUR",
					new Dictionary<string, string>
					{
						{ "one", "{0} euro" },
						{ "other", "{0} euros" },
						{ "gender", "masculine" }
					}
				},
				{
					"GBP",
					new Dictionary<string, string>
					{
						{ "one", "{0} libra esterlina britânica" },
						{ "other", "{0} libras esterlinas britânicas" },
						{ "gender", "feminine" }
					}
				},
				{
					"JPY",
					new Dictionary<string, string>
					{
						{ "one", "{0} iene japonês" },
						{ "other", "{0} ienes japoneses" },
						{ "gender", "masculine" }
					}
				},
				{
					"CNY",
					new Dictionary<string, string>
					{
						{ "one", "{0} yuan" },
						{ "other", "{0} yuans" },
						{ "gender", "masculine" }
					}
				},
				{
					"SEK",
					new Dictionary<string, string>
					{
						{ "one", "{0} coroa sueca" },
						{ "other", "{0} coroas suecas" },
						{ "gender", "feminine" }
					}
				},
				{
					"DKK",
					new Dictionary<string, string>
					{
						{ "one", "{0} coroa dinamarquesa" },
						{ "other", "{0} coroas dinamarquesas" },
						{ "gender", "feminine" }
					}
				},
				{
					"NOK",
					new Dictionary<string, string>
					{
						{ "one", "{0} coroa norueguesa" },
						{ "other", "{0} coroas norueguesas" },
						{ "gender", "feminine" }
					}
				},
				{
					"PLN",
					new Dictionary<string, string>
					{
						{ "one", "{0} zloti polaco" },
						{ "other", "{0} zlotis polacos" },
						{ "gender", "masculine" }
					}
				},
				{
					"RUB",
					new Dictionary<string, string>
					{
						{ "one", "{0} rublo russo" },
						{ "other", "{0} rublos russos" },
						{ "gender", "masculine" }
					}
				},
				{
					"UAH",
					new Dictionary<string, string>
					{
						{ "one", "{0} hryvnia ucraniano" },
						{ "other", "{0} hryvnias ucranianos" },
						{ "gender", "feminine" }
					}
				},
				{
					"TRY",
					new Dictionary<string, string>
					{
						{ "one", "{0} lira turca" },
						{ "other", "{0} liras turcas" },
						{ "gender", "feminine" }
					}
				},
				{
					"KRW",
					new Dictionary<string, string>
					{
						{ "one", "{0} won sul-coreano" },
						{ "other", "{0} wons sul-coreano" },
						{ "gender", "masculine" }
					}
				},
				{
					"THB",
					new Dictionary<string, string>
					{
						{ "one", "{0} baht tailandês" },
						{ "other", "{0} bahts tailandeses" },
						{ "gender", "masculine" }
					}
				},
				{
					"BRL",
					new Dictionary<string, string>
					{
						{ "one", "{0} real brasileiro" },
						{ "other", "{0} reais brasileiros" },
						{ "gender", "masculine" }
					}
				}
			}
		};
		dictionary["pl"] = new Language
		{
			code = "pl",
			decimalMark = ',',
			groupMark = ' ',
			letters = new string[26]
			{
				"a", "be", "ce", "de", "e", "ef", "gie", "ha", "i", "jot",
				"ka", "el", "em", "en", "o", "pe", "ku", "er", "es", "te",
				"u", "fał", "wu", "iks", "igrek", "zet"
			},
			datePattern = "d MMMM y",
			months = new string[12]
			{
				"stycznia", "lutego", "marca", "kwietnia", "maja", "czerwca", "lipca", "sierpnia", "września", "października",
				"listopada", "grudnia"
			},
			days = new string[31]
			{
				"pierwszy", "drugi", "trzeci", "czwarty", "piąty", "szósty", "siódmy", "ósmy", "dziewiąty", "dziesiąty",
				"jedenasty", "dwunasty", "trzynasty", "czternasty", "piętnasty", "szesnasty", "siedemnasty", "osiemnasty", "dziewiętnasty", "dwudziesty",
				"dwudziesty pierwszy", "dwudziesty drugi", "dwudziesty trzeci", "dwudziesty czwarty", "dwudziesty piąty", "dwudziesty szósty", "dwudziesty siódmy", "dwudziesty ósmy", "dwudziesty dziewiąty", "trzydziesty",
				"trzydziesty pierwszy"
			},
			terms = new Dictionary<string, string>
			{
				{ "minus", "minus" },
				{ "plus", "plus" },
				{ "decimal", "przecinek" },
				{ "percent", "procent" },
				{ "to", "do" },
				{ "over", "przez" },
				{ "slash", "ukośnik" },
				{ "colon", "dwukropek" },
				{ "dot", "kropka" },
				{ "at", "małpa" },
				{ "equals", "równa się" },
				{ "and", "i" },
				{ "times", "razy" },
				{ "divided", "podzielone przez" },
				{ "less", "mniejsze niż" },
				{ "greater", "większe niż" },
				{ "number", "numer" },
				{ "link", "link" },
				{ "email", "email" },
				{ "degree", "stopni" },
				{ "underscore", "podkreślenie" }
			},
			readings = new Dictionary<string, string>(),
			abbreviations = new Dictionary<string, string> { { "Dr.", "doktor" } },
			measures = new Dictionary<string, Dictionary<string, string>>
			{
				{
					"kg",
					new Dictionary<string, string>
					{
						{ "one", "{0} kilogram" },
						{ "few", "{0} kilogramy" },
						{ "many", "{0} kilogramów" },
						{ "other", "{0} kilograma" },
						{ "gender", "inanimate" }
					}
				},
				{
					"g",
					new Dictionary<string, string>
					{
						{ "one", "{0} gram" },
						{ "few", "{0} gramy" },
						{ "many", "{0} gramów" },
						{ "other", "{0} grama" },
						{ "gender", "inanimate" }
					}
				},
				{
					"km",
					new Dictionary<string, string>
					{
						{ "one", "{0} kilometr" },
						{ "few", "{0} kilometry" },
						{ "many", "{0} kilometrów" },
						{ "other", "{0} kilometra" },
						{ "gender", "inanimate" }
					}
				},
				{
					"m",
					new Dictionary<string, string>
					{
						{ "one", "{0} metr" },
						{ "few", "{0} metry" },
						{ "many", "{0} metrów" },
						{ "other", "{0} metra" },
						{ "gender", "inanimate" }
					}
				},
				{
					"cm",
					new Dictionary<string, string>
					{
						{ "one", "{0} centymetr" },
						{ "few", "{0} centymetry" },
						{ "many", "{0} centymetrów" },
						{ "other", "{0} centymetra" },
						{ "gender", "inanimate" }
					}
				},
				{
					"mm",
					new Dictionary<string, string>
					{
						{ "one", "{0} milimetr" },
						{ "few", "{0} milimetry" },
						{ "many", "{0} milimetrów" },
						{ "other", "{0} milimetra" },
						{ "gender", "inanimate" }
					}
				},
				{
					"L",
					new Dictionary<string, string>
					{
						{ "one", "{0} litr" },
						{ "few", "{0} litry" },
						{ "many", "{0} litrów" },
						{ "other", "{0} litra" },
						{ "gender", "inanimate" }
					}
				},
				{
					"ml",
					new Dictionary<string, string>
					{
						{ "one", "{0} mililitr" },
						{ "few", "{0} mililitry" },
						{ "many", "{0} mililitrów" },
						{ "other", "{0} mililitra" },
						{ "gender", "inanimate" }
					}
				},
				{
					"°C",
					new Dictionary<string, string>
					{
						{ "one", "{0} stopień Celsjusza" },
						{ "few", "{0} stopnie Celsjusza" },
						{ "many", "{0} stopni Celsjusza" },
						{ "other", "{0} stopnia Celsjusza" },
						{ "gender", "inanimate" }
					}
				},
				{
					"°F",
					new Dictionary<string, string>
					{
						{ "one", "{0} stopień Fahrenheita" },
						{ "few", "{0} stopnie Fahrenheita" },
						{ "many", "{0} stopni Fahrenheita" },
						{ "other", "{0} stopnia Fahrenheita" },
						{ "gender", "inanimate" }
					}
				},
				{
					"h",
					new Dictionary<string, string>
					{
						{ "one", "{0} godzina" },
						{ "few", "{0} godziny" },
						{ "many", "{0} godzin" },
						{ "other", "{0} godziny" },
						{ "gender", "feminine" }
					}
				},
				{
					"min",
					new Dictionary<string, string>
					{
						{ "one", "{0} minuta" },
						{ "few", "{0} minuty" },
						{ "many", "{0} minut" },
						{ "other", "{0} minuty" },
						{ "gender", "feminine" }
					}
				},
				{
					"s",
					new Dictionary<string, string>
					{
						{ "one", "{0} sekunda" },
						{ "few", "{0} sekundy" },
						{ "many", "{0} sekund" },
						{ "other", "{0} sekundy" },
						{ "gender", "feminine" }
					}
				},
				{
					"day",
					new Dictionary<string, string>
					{
						{ "one", "{0} dzień" },
						{ "few", "{0} dni" },
						{ "many", "{0} dni" },
						{ "other", "{0} dnia" },
						{ "gender", "inanimate" }
					}
				},
				{
					"month",
					new Dictionary<string, string>
					{
						{ "one", "{0} miesiąc" },
						{ "few", "{0} miesiące" },
						{ "many", "{0} miesięcy" },
						{ "other", "{0} miesiąca" },
						{ "gender", "inanimate" }
					}
				},
				{
					"year",
					new Dictionary<string, string>
					{
						{ "one", "{0} rok" },
						{ "few", "{0} lata" },
						{ "many", "{0} lat" },
						{ "other", "{0} roku" },
						{ "gender", "inanimate" }
					}
				},
				{
					"%",
					new Dictionary<string, string>
					{
						{ "one", "{0} procent" },
						{ "few", "{0} procent" },
						{ "many", "{0} procent" },
						{ "other", "{0} procent" },
						{ "gender", "inanimate" }
					}
				},
				{
					"‰",
					new Dictionary<string, string>
					{
						{ "one", "{0} promil" },
						{ "few", "{0} promile" },
						{ "many", "{0} promili" },
						{ "other", "{0} promila" },
						{ "gender", "inanimate" }
					}
				},
				{
					"°",
					new Dictionary<string, string>
					{
						{ "one", "{0} stopień" },
						{ "few", "{0} stopnie" },
						{ "many", "{0} stopni" },
						{ "other", "{0} stopnia" },
						{ "gender", "inanimate" }
					}
				},
				{
					"ms",
					new Dictionary<string, string>
					{
						{ "one", "{0} milisekunda" },
						{ "few", "{0} milisekundy" },
						{ "many", "{0} milisekund" },
						{ "other", "{0} milisekundy" },
						{ "gender", "feminine" }
					}
				},
				{
					"USD",
					new Dictionary<string, string>
					{
						{ "one", "{0} dolar amerykański" },
						{ "few", "{0} dolary amerykańskie" },
						{ "many", "{0} dolarów amerykańskich" },
						{ "other", "{0} dolara amerykańskiego" },
						{ "gender", "masculine" }
					}
				},
				{
					"EUR",
					new Dictionary<string, string>
					{
						{ "other", "{0} euro" },
						{ "gender", "neuter" }
					}
				},
				{
					"GBP",
					new Dictionary<string, string>
					{
						{ "one", "{0} funt szterling" },
						{ "few", "{0} funty szterlingi" },
						{ "many", "{0} funtów szterlingów" },
						{ "other", "{0} funta szterlinga" },
						{ "gender", "masculine" }
					}
				},
				{
					"JPY",
					new Dictionary<string, string>
					{
						{ "one", "{0} jen japoński" },
						{ "few", "{0} jeny japońskie" },
						{ "many", "{0} jenów japońskich" },
						{ "other", "{0} jena japońskiego" },
						{ "gender", "masculine" }
					}
				},
				{
					"CNY",
					new Dictionary<string, string>
					{
						{ "one", "{0} juan chiński" },
						{ "few", "{0} juany chińskie" },
						{ "many", "{0} juanów chińskich" },
						{ "other", "{0} juana chińskiego" },
						{ "gender", "masculine" }
					}
				},
				{
					"SEK",
					new Dictionary<string, string>
					{
						{ "one", "{0} korona szwedzka" },
						{ "few", "{0} korony szwedzkie" },
						{ "many", "{0} koron szwedzkich" },
						{ "other", "{0} korony szwedzkiej" },
						{ "gender", "feminine" }
					}
				},
				{
					"DKK",
					new Dictionary<string, string>
					{
						{ "one", "{0} korona duńska" },
						{ "few", "{0} korony duńskie" },
						{ "many", "{0} koron duńskich" },
						{ "other", "{0} korony duńskiej" },
						{ "gender", "feminine" }
					}
				},
				{
					"NOK",
					new Dictionary<string, string>
					{
						{ "one", "{0} korona norweska" },
						{ "few", "{0} korony norweskie" },
						{ "many", "{0} koron norweskich" },
						{ "other", "{0} korony norweskiej" },
						{ "gender", "feminine" }
					}
				},
				{
					"PLN",
					new Dictionary<string, string>
					{
						{ "one", "{0} złoty polski" },
						{ "few", "{0} złote polskie" },
						{ "many", "{0} złotych polskich" },
						{ "other", "{0} złotego polskiego" },
						{ "gender", "masculine" }
					}
				},
				{
					"RUB",
					new Dictionary<string, string>
					{
						{ "one", "{0} rubel rosyjski" },
						{ "few", "{0} ruble rosyjskie" },
						{ "many", "{0} rubli rosyjskich" },
						{ "other", "{0} rubla rosyjskiego" },
						{ "gender", "masculine" }
					}
				},
				{
					"UAH",
					new Dictionary<string, string>
					{
						{ "one", "{0} hrywna ukraińska" },
						{ "few", "{0} hrywny ukraińskie" },
						{ "many", "{0} hrywien ukraińskich" },
						{ "other", "{0} hrywny ukraińskiej" },
						{ "gender", "feminine" }
					}
				},
				{
					"TRY",
					new Dictionary<string, string>
					{
						{ "one", "{0} lira turecka" },
						{ "few", "{0} liry tureckie" },
						{ "many", "{0} lir tureckich" },
						{ "other", "{0} liry tureckiej" },
						{ "gender", "feminine" }
					}
				},
				{
					"KRW",
					new Dictionary<string, string>
					{
						{ "one", "{0} won południowokoreański" },
						{ "few", "{0} wony południowokoreańskie" },
						{ "many", "{0} wonów południowokoreańskich" },
						{ "other", "{0} wona południowokoreańskiego" },
						{ "gender", "masculine" }
					}
				},
				{
					"THB",
					new Dictionary<string, string>
					{
						{ "one", "{0} baht tajski" },
						{ "few", "{0} bahty tajskie" },
						{ "many", "{0} bahtów tajskich" },
						{ "other", "{0} bahta tajskiego" },
						{ "gender", "masculine" }
					}
				},
				{
					"BRL",
					new Dictionary<string, string>
					{
						{ "one", "{0} real brazylijski" },
						{ "few", "{0} reale brazylijskie" },
						{ "many", "{0} reali brazylijskich" },
						{ "other", "{0} reala brazylijskiego" },
						{ "gender", "masculine" }
					}
				}
			}
		};
		dictionary["ru"] = new Language
		{
			code = "ru",
			decimalMark = ',',
			groupMark = ' ',
			letters = new string[26]
			{
				"эй", "би", "си", "ди", "и", "эф", "джи", "эйч", "ай", "джей",
				"кей", "эл", "эм", "эн", "оу", "пи", "кью", "ар", "эс", "ти",
				"ю", "ви", "дабл-ю", "экс", "уай", "зед"
			},
			datePattern = "d MMMM y\u202f'г'.",
			months = new string[12]
			{
				"января", "февраля", "марта", "апреля", "мая", "июня", "июля", "августа", "сентября", "октября",
				"ноября", "декабря"
			},
			days = new string[31]
			{
				"первое", "второе", "третье", "четвёртое", "пятое", "шестое", "седьмое", "восьмое", "девятое", "десятое",
				"одиннадцатое", "двенадцатое", "тринадцатое", "четырнадцатое", "пятнадцатое", "шестнадцатое", "семнадцатое", "восемнадцатое", "девятнадцатое", "двадцатое",
				"двадцать первое", "двадцать второе", "двадцать третье", "двадцать четвёртое", "двадцать пятое", "двадцать шестое", "двадцать седьмое", "двадцать восьмое", "двадцать девятое", "тридцатое",
				"тридцать первое"
			},
			terms = new Dictionary<string, string>
			{
				{ "minus", "минус" },
				{ "plus", "плюс" },
				{ "decimal", "запятая" },
				{ "percent", "процентов" },
				{ "to", "до" },
				{ "over", "делить на" },
				{ "slash", "косая черта" },
				{ "colon", "двоеточие" },
				{ "dot", "точка" },
				{ "at", "собака" },
				{ "equals", "равно" },
				{ "and", "и" },
				{ "times", "умножить на" },
				{ "divided", "делить на" },
				{ "less", "меньше" },
				{ "greater", "больше" },
				{ "number", "номер" },
				{ "link", "ссылка" },
				{ "email", "почта" },
				{ "degree", "градусов" },
				{ "underscore", "нижнее подчёркивание" }
			},
			readings = new Dictionary<string, string>(),
			abbreviations = new Dictionary<string, string> { { "Dr.", "доктор" } },
			measures = new Dictionary<string, Dictionary<string, string>>
			{
				{
					"kg",
					new Dictionary<string, string>
					{
						{ "one", "{0} килограмм" },
						{ "few", "{0} килограмма" },
						{ "many", "{0} килограмм" },
						{ "other", "{0} килограмма" },
						{ "gender", "masculine" }
					}
				},
				{
					"g",
					new Dictionary<string, string>
					{
						{ "one", "{0} грамм" },
						{ "few", "{0} грамма" },
						{ "many", "{0} грамм" },
						{ "other", "{0} грамма" },
						{ "gender", "masculine" }
					}
				},
				{
					"km",
					new Dictionary<string, string>
					{
						{ "one", "{0} километр" },
						{ "few", "{0} километра" },
						{ "many", "{0} километров" },
						{ "other", "{0} километра" },
						{ "gender", "masculine" }
					}
				},
				{
					"m",
					new Dictionary<string, string>
					{
						{ "one", "{0} метр" },
						{ "few", "{0} метра" },
						{ "many", "{0} метров" },
						{ "other", "{0} метра" },
						{ "gender", "masculine" }
					}
				},
				{
					"cm",
					new Dictionary<string, string>
					{
						{ "one", "{0} сантиметр" },
						{ "few", "{0} сантиметра" },
						{ "many", "{0} сантиметров" },
						{ "other", "{0} сантиметра" },
						{ "gender", "masculine" }
					}
				},
				{
					"mm",
					new Dictionary<string, string>
					{
						{ "one", "{0} миллиметр" },
						{ "few", "{0} миллиметра" },
						{ "many", "{0} миллиметров" },
						{ "other", "{0} миллиметра" },
						{ "gender", "masculine" }
					}
				},
				{
					"L",
					new Dictionary<string, string>
					{
						{ "one", "{0} литр" },
						{ "few", "{0} литра" },
						{ "many", "{0} литров" },
						{ "other", "{0} литра" },
						{ "gender", "masculine" }
					}
				},
				{
					"ml",
					new Dictionary<string, string>
					{
						{ "one", "{0} миллилитр" },
						{ "few", "{0} миллилитра" },
						{ "many", "{0} миллилитров" },
						{ "other", "{0} миллилитра" },
						{ "gender", "masculine" }
					}
				},
				{
					"°C",
					new Dictionary<string, string>
					{
						{ "one", "{0} градус Цельсия" },
						{ "few", "{0} градуса Цельсия" },
						{ "many", "{0} градусов Цельсия" },
						{ "other", "{0} градуса Цельсия" },
						{ "gender", "masculine" }
					}
				},
				{
					"°F",
					new Dictionary<string, string>
					{
						{ "one", "{0} градус Фаренгейта" },
						{ "few", "{0} градуса Фаренгейта" },
						{ "many", "{0} градусов Фаренгейта" },
						{ "other", "{0} градуса Фаренгейта" },
						{ "gender", "masculine" }
					}
				},
				{
					"h",
					new Dictionary<string, string>
					{
						{ "one", "{0} час" },
						{ "few", "{0} часа" },
						{ "many", "{0} часов" },
						{ "other", "{0} часа" },
						{ "gender", "masculine" }
					}
				},
				{
					"min",
					new Dictionary<string, string>
					{
						{ "one", "{0} минута" },
						{ "few", "{0} минуты" },
						{ "many", "{0} минут" },
						{ "other", "{0} минуты" },
						{ "gender", "feminine" }
					}
				},
				{
					"s",
					new Dictionary<string, string>
					{
						{ "one", "{0} секунда" },
						{ "few", "{0} секунды" },
						{ "many", "{0} секунд" },
						{ "other", "{0} секунды" },
						{ "gender", "feminine" }
					}
				},
				{
					"day",
					new Dictionary<string, string>
					{
						{ "one", "{0} день" },
						{ "few", "{0} дня" },
						{ "many", "{0} дней" },
						{ "other", "{0} дня" },
						{ "gender", "masculine" }
					}
				},
				{
					"month",
					new Dictionary<string, string>
					{
						{ "one", "{0} месяц" },
						{ "few", "{0} месяца" },
						{ "many", "{0} месяцев" },
						{ "other", "{0} месяца" },
						{ "gender", "masculine" }
					}
				},
				{
					"year",
					new Dictionary<string, string>
					{
						{ "one", "{0} год" },
						{ "few", "{0} года" },
						{ "many", "{0} лет" },
						{ "other", "{0} года" },
						{ "gender", "masculine" }
					}
				},
				{
					"%",
					new Dictionary<string, string>
					{
						{ "one", "{0} процент" },
						{ "few", "{0} процента" },
						{ "many", "{0} процентов" },
						{ "other", "{0} процента" },
						{ "gender", "masculine" }
					}
				},
				{
					"‰",
					new Dictionary<string, string>
					{
						{ "one", "{0} промилле" },
						{ "few", "{0} промилле" },
						{ "many", "{0} промилле" },
						{ "other", "{0} промилле" },
						{ "gender", "neuter" }
					}
				},
				{
					"°",
					new Dictionary<string, string>
					{
						{ "one", "{0} градус" },
						{ "few", "{0} градуса" },
						{ "many", "{0} градусов" },
						{ "other", "{0} градуса" },
						{ "gender", "masculine" }
					}
				},
				{
					"ms",
					new Dictionary<string, string>
					{
						{ "one", "{0} миллисекунда" },
						{ "few", "{0} миллисекунды" },
						{ "many", "{0} миллисекунд" },
						{ "other", "{0} миллисекунды" },
						{ "gender", "feminine" }
					}
				},
				{
					"USD",
					new Dictionary<string, string>
					{
						{ "one", "{0} доллар США" },
						{ "few", "{0} доллара США" },
						{ "many", "{0} долларов США" },
						{ "other", "{0} доллара США" },
						{ "gender", "masculine" }
					}
				},
				{
					"EUR",
					new Dictionary<string, string>
					{
						{ "other", "{0} евро" },
						{ "gender", "neuter" }
					}
				},
				{
					"GBP",
					new Dictionary<string, string>
					{
						{ "one", "{0} британский фунт стерлингов" },
						{ "few", "{0} британских фунта стерлингов" },
						{ "many", "{0} британских фунтов стерлингов" },
						{ "other", "{0} британского фунта стерлингов" },
						{ "gender", "masculine" }
					}
				},
				{
					"JPY",
					new Dictionary<string, string>
					{
						{ "one", "{0} японская иена" },
						{ "few", "{0} японские иены" },
						{ "many", "{0} японских иен" },
						{ "other", "{0} японской иены" },
						{ "gender", "masculine" }
					}
				},
				{
					"CNY",
					new Dictionary<string, string>
					{
						{ "one", "{0} китайский юань" },
						{ "few", "{0} китайских юаня" },
						{ "many", "{0} китайских юаней" },
						{ "other", "{0} китайского юаня" },
						{ "gender", "masculine" }
					}
				},
				{
					"SEK",
					new Dictionary<string, string>
					{
						{ "one", "{0} шведская крона" },
						{ "few", "{0} шведские кроны" },
						{ "many", "{0} шведских крон" },
						{ "other", "{0} шведской кроны" },
						{ "gender", "feminine" }
					}
				},
				{
					"DKK",
					new Dictionary<string, string>
					{
						{ "one", "{0} датская крона" },
						{ "few", "{0} датские кроны" },
						{ "many", "{0} датских крон" },
						{ "other", "{0} датской кроны" },
						{ "gender", "feminine" }
					}
				},
				{
					"NOK",
					new Dictionary<string, string>
					{
						{ "one", "{0} норвежская крона" },
						{ "few", "{0} норвежские кроны" },
						{ "many", "{0} норвежских крон" },
						{ "other", "{0} норвежской кроны" },
						{ "gender", "feminine" }
					}
				},
				{
					"PLN",
					new Dictionary<string, string>
					{
						{ "one", "{0} польский злотый" },
						{ "few", "{0} польских злотых" },
						{ "many", "{0} польских злотых" },
						{ "other", "{0} польского злотого" },
						{ "gender", "masculine" }
					}
				},
				{
					"RUB",
					new Dictionary<string, string>
					{
						{ "one", "{0} российский рубль" },
						{ "few", "{0} российских рубля" },
						{ "many", "{0} российских рублей" },
						{ "other", "{0} российского рубля" },
						{ "gender", "masculine" }
					}
				},
				{
					"UAH",
					new Dictionary<string, string>
					{
						{ "one", "{0} украинская гривна" },
						{ "few", "{0} украинские гривны" },
						{ "many", "{0} украинских гривен" },
						{ "other", "{0} украинской гривны" },
						{ "gender", "feminine" }
					}
				},
				{
					"TRY",
					new Dictionary<string, string>
					{
						{ "one", "{0} турецкая лира" },
						{ "few", "{0} турецкие лиры" },
						{ "many", "{0} турецких лир" },
						{ "other", "{0} турецкой лиры" },
						{ "gender", "feminine" }
					}
				},
				{
					"KRW",
					new Dictionary<string, string>
					{
						{ "one", "{0} южнокорейская вона" },
						{ "few", "{0} южнокорейские воны" },
						{ "many", "{0} южнокорейских вон" },
						{ "other", "{0} южнокорейской воны" },
						{ "gender", "masculine" }
					}
				},
				{
					"THB",
					new Dictionary<string, string>
					{
						{ "one", "{0} таиландский бат" },
						{ "few", "{0} таиландских бата" },
						{ "many", "{0} таиландских батов" },
						{ "other", "{0} таиландского бата" },
						{ "gender", "masculine" }
					}
				},
				{
					"BRL",
					new Dictionary<string, string>
					{
						{ "one", "{0} бразильский реал" },
						{ "few", "{0} бразильских реала" },
						{ "many", "{0} бразильских реалов" },
						{ "other", "{0} бразильского реала" },
						{ "gender", "masculine" }
					}
				}
			}
		};
		dictionary["uk"] = new Language
		{
			code = "uk",
			decimalMark = ',',
			groupMark = ' ',
			letters = new string[26]
			{
				"ей", "бі", "сі", "ді", "і", "еф", "джі", "ейч", "ай", "джей",
				"кей", "ел", "ем", "ен", "оу", "пі", "кю", "ар", "ес", "ті",
				"ю", "ві", "дабл-ю", "екс", "вай", "зед"
			},
			datePattern = "d MMMM y\u202f'р'.",
			months = new string[12]
			{
				"січня", "лютого", "березня", "квітня", "травня", "червня", "липня", "серпня", "вересня", "жовтня",
				"листопада", "грудня"
			},
			days = new string[31]
			{
				"перше", "друге", "третє", "четверте", "пяте", "шосте", "сьоме", "восьме", "девяте", "десяте",
				"одинадцяте", "дванадцяте", "тринадцяте", "чотирнадцяте", "пятнадцяте", "шістнадцяте", "сімнадцяте", "вісімнадцяте", "девятнадцяте", "двадцяте",
				"двадцять перше", "двадцять друге", "двадцять третє", "двадцять четверте", "двадцять пяте", "двадцять шосте", "двадцять сьоме", "двадцять восьме", "двадцять девяте", "тридцяте",
				"тридцять перше"
			},
			terms = new Dictionary<string, string>
			{
				{ "minus", "мінус" },
				{ "plus", "плюс" },
				{ "decimal", "кома" },
				{ "percent", "відсотків" },
				{ "to", "до" },
				{ "over", "поділити на" },
				{ "slash", "похила риска" },
				{ "colon", "двокрапка" },
				{ "dot", "крапка" },
				{ "at", "равлик" },
				{ "equals", "дорівнює" },
				{ "and", "і" },
				{ "times", "помножити на" },
				{ "divided", "поділити на" },
				{ "less", "менше" },
				{ "greater", "більше" },
				{ "number", "номер" },
				{ "link", "посилання" },
				{ "email", "пошта" },
				{ "degree", "градусів" },
				{ "underscore", "нижнє підкреслення" }
			},
			readings = new Dictionary<string, string>(),
			abbreviations = new Dictionary<string, string> { { "Dr.", "доктор" } },
			measures = new Dictionary<string, Dictionary<string, string>>
			{
				{
					"kg",
					new Dictionary<string, string>
					{
						{ "one", "{0} кілограм" },
						{ "few", "{0} кілограми" },
						{ "many", "{0} кілограмів" },
						{ "other", "{0} кілограма" },
						{ "gender", "masculine" }
					}
				},
				{
					"g",
					new Dictionary<string, string>
					{
						{ "one", "{0} грам" },
						{ "few", "{0} грами" },
						{ "many", "{0} грамів" },
						{ "other", "{0} грама" },
						{ "gender", "masculine" }
					}
				},
				{
					"km",
					new Dictionary<string, string>
					{
						{ "one", "{0} кілометр" },
						{ "few", "{0} кілометри" },
						{ "many", "{0} кілометрів" },
						{ "other", "{0} кілометра" },
						{ "gender", "masculine" }
					}
				},
				{
					"m",
					new Dictionary<string, string>
					{
						{ "one", "{0} метр" },
						{ "few", "{0} метри" },
						{ "many", "{0} метрів" },
						{ "other", "{0} метра" },
						{ "gender", "masculine" }
					}
				},
				{
					"cm",
					new Dictionary<string, string>
					{
						{ "one", "{0} сантиметр" },
						{ "few", "{0} сантиметри" },
						{ "many", "{0} сантиметрів" },
						{ "other", "{0} сантиметра" },
						{ "gender", "masculine" }
					}
				},
				{
					"mm",
					new Dictionary<string, string>
					{
						{ "one", "{0} міліметр" },
						{ "few", "{0} міліметри" },
						{ "many", "{0} міліметрів" },
						{ "other", "{0} міліметра" },
						{ "gender", "masculine" }
					}
				},
				{
					"L",
					new Dictionary<string, string>
					{
						{ "one", "{0} літр" },
						{ "few", "{0} літри" },
						{ "many", "{0} літрів" },
						{ "other", "{0} літра" },
						{ "gender", "masculine" }
					}
				},
				{
					"ml",
					new Dictionary<string, string>
					{
						{ "one", "{0} мілілітр" },
						{ "few", "{0} мілілітри" },
						{ "many", "{0} мілілітрів" },
						{ "other", "{0} мілілітра" },
						{ "gender", "masculine" }
					}
				},
				{
					"°C",
					new Dictionary<string, string>
					{
						{ "one", "{0} градус Цельсія" },
						{ "few", "{0} градуси Цельсія" },
						{ "many", "{0} градусів Цельсія" },
						{ "other", "{0} градуса Цельсія" },
						{ "gender", "masculine" }
					}
				},
				{
					"°F",
					new Dictionary<string, string>
					{
						{ "one", "{0} градус Фаренгейта" },
						{ "few", "{0} градуси Фаренгейта" },
						{ "many", "{0} градусів Фаренгейта" },
						{ "other", "{0} градуса Фаренгейта" },
						{ "gender", "" }
					}
				},
				{
					"h",
					new Dictionary<string, string>
					{
						{ "one", "{0} година" },
						{ "few", "{0} години" },
						{ "many", "{0} годин" },
						{ "other", "{0} години" },
						{ "gender", "feminine" }
					}
				},
				{
					"min",
					new Dictionary<string, string>
					{
						{ "one", "{0} хвилина" },
						{ "few", "{0} хвилини" },
						{ "many", "{0} хвилин" },
						{ "other", "{0} хвилини" },
						{ "gender", "feminine" }
					}
				},
				{
					"s",
					new Dictionary<string, string>
					{
						{ "one", "{0} секунда" },
						{ "few", "{0} секунди" },
						{ "many", "{0} секунд" },
						{ "other", "{0} секунди" },
						{ "gender", "feminine" }
					}
				},
				{
					"day",
					new Dictionary<string, string>
					{
						{ "one", "{0} день" },
						{ "few", "{0} дні" },
						{ "many", "{0} днів" },
						{ "other", "{0} дня" },
						{ "gender", "masculine" }
					}
				},
				{
					"month",
					new Dictionary<string, string>
					{
						{ "one", "{0} місяць" },
						{ "few", "{0} місяці" },
						{ "many", "{0} місяців" },
						{ "other", "{0} місяця" },
						{ "gender", "masculine" }
					}
				},
				{
					"year",
					new Dictionary<string, string>
					{
						{ "one", "{0} рік" },
						{ "few", "{0} роки" },
						{ "many", "{0} років" },
						{ "other", "{0} року" },
						{ "gender", "masculine" }
					}
				},
				{
					"%",
					new Dictionary<string, string>
					{
						{ "one", "{0} відсоток" },
						{ "few", "{0} відсотки" },
						{ "many", "{0} відсотків" },
						{ "other", "{0} відсотка" },
						{ "gender", "masculine" }
					}
				},
				{
					"‰",
					new Dictionary<string, string>
					{
						{ "one", "{0} проміле" },
						{ "few", "{0} проміле" },
						{ "many", "{0} проміле" },
						{ "other", "{0} проміле" },
						{ "gender", "masculine" }
					}
				},
				{
					"°",
					new Dictionary<string, string> { { "other", "{0} градусів" } }
				},
				{
					"ms",
					new Dictionary<string, string>
					{
						{ "one", "{0} мілісекунда" },
						{ "few", "{0} мілісекунди" },
						{ "many", "{0} мілісекунд" },
						{ "other", "{0} мілісекунди" },
						{ "gender", "feminine" }
					}
				},
				{
					"USD",
					new Dictionary<string, string>
					{
						{ "one", "{0} долар США" },
						{ "few", "{0} долари США" },
						{ "many", "{0} доларів США" },
						{ "other", "{0} долара США" },
						{ "gender", "masculine" }
					}
				},
				{
					"EUR",
					new Dictionary<string, string>
					{
						{ "other", "{0} євро" },
						{ "gender", "neuter" }
					}
				},
				{
					"GBP",
					new Dictionary<string, string>
					{
						{ "one", "{0} англійський фунт" },
						{ "few", "{0} англійські фунти" },
						{ "many", "{0} англійських фунтів" },
						{ "other", "{0} англійського фунта" },
						{ "gender", "masculine" }
					}
				},
				{
					"JPY",
					new Dictionary<string, string>
					{
						{ "one", "{0} японська єна" },
						{ "few", "{0} японські єни" },
						{ "many", "{0} японських єн" },
						{ "other", "{0} японської єни" },
						{ "gender", "masculine" }
					}
				},
				{
					"CNY",
					new Dictionary<string, string>
					{
						{ "one", "{0} китайський юань" },
						{ "few", "{0} китайські юані" },
						{ "many", "{0} китайських юанів" },
						{ "other", "{0} китайського юаня" },
						{ "gender", "masculine" }
					}
				},
				{
					"SEK",
					new Dictionary<string, string>
					{
						{ "one", "{0} шведська крона" },
						{ "few", "{0} шведські крони" },
						{ "many", "{0} шведських крон" },
						{ "other", "{0} шведської крони" },
						{ "gender", "feminine" }
					}
				},
				{
					"DKK",
					new Dictionary<string, string>
					{
						{ "one", "{0} данська крона" },
						{ "few", "{0} данські крони" },
						{ "many", "{0} данських крон" },
						{ "other", "{0} данської крони" },
						{ "gender", "feminine" }
					}
				},
				{
					"NOK",
					new Dictionary<string, string>
					{
						{ "one", "{0} норвезька крона" },
						{ "few", "{0} норвезькі крони" },
						{ "many", "{0} норвезьких крон" },
						{ "other", "{0} норвезької крони" },
						{ "gender", "feminine" }
					}
				},
				{
					"PLN",
					new Dictionary<string, string>
					{
						{ "one", "{0} польський злотий" },
						{ "few", "{0} польські злоті" },
						{ "many", "{0} польських злотих" },
						{ "other", "{0} польського злотого" },
						{ "gender", "masculine" }
					}
				},
				{
					"RUB",
					new Dictionary<string, string>
					{
						{ "one", "{0} російський рубль" },
						{ "few", "{0} російські рублі" },
						{ "many", "{0} російських рублів" },
						{ "other", "{0} російського рубля" },
						{ "gender", "masculine" }
					}
				},
				{
					"UAH",
					new Dictionary<string, string>
					{
						{ "one", "{0} українська гривня" },
						{ "few", "{0} українські гривні" },
						{ "many", "{0} українських гривень" },
						{ "other", "{0} української гривні" },
						{ "gender", "feminine" }
					}
				},
				{
					"TRY",
					new Dictionary<string, string>
					{
						{ "one", "{0} турецька ліра" },
						{ "few", "{0} турецькі ліри" },
						{ "many", "{0} турецьких лір" },
						{ "other", "{0} турецької ліри" },
						{ "gender", "feminine" }
					}
				},
				{
					"KRW",
					new Dictionary<string, string>
					{
						{ "one", "{0} південнокорейський вон" },
						{ "few", "{0} південнокорейські вони" },
						{ "many", "{0} південнокорейських вонів" },
						{ "other", "{0} південнокорейського вона" },
						{ "gender", "masculine" }
					}
				},
				{
					"THB",
					new Dictionary<string, string>
					{
						{ "one", "{0} таїландський бат" },
						{ "few", "{0} таїландські бати" },
						{ "many", "{0} таїландських батів" },
						{ "other", "{0} таїландського бата" },
						{ "gender", "masculine" }
					}
				},
				{
					"BRL",
					new Dictionary<string, string>
					{
						{ "one", "{0} бразильський реал" },
						{ "few", "{0} бразильські реали" },
						{ "many", "{0} бразильських реалів" },
						{ "other", "{0} бразильського реала" },
						{ "gender", "masculine" }
					}
				}
			}
		};
		dictionary["tr"] = new Language
		{
			code = "tr",
			decimalMark = ',',
			groupMark = '.',
			letters = new string[26]
			{
				"a", "be", "ce", "de", "e", "fe", "ge", "he", "ı", "je",
				"ke", "le", "me", "ne", "o", "pe", "ku", "re", "se", "te",
				"u", "ve", "dabılyu", "iks", "ye", "ze"
			},
			datePattern = "d MMMM y",
			months = new string[12]
			{
				"Ocak", "Şubat", "Mart", "Nisan", "Mayıs", "Haziran", "Temmuz", "Ağustos", "Eylül", "Ekim",
				"Kasım", "Aralık"
			},
			days = new string[0],
			terms = new Dictionary<string, string>
			{
				{ "minus", "eksi" },
				{ "plus", "artı" },
				{ "decimal", "virgül" },
				{ "percent", "yüzde" },
				{ "to", "ila" },
				{ "over", "bölü" },
				{ "slash", "eğik çizgi" },
				{ "colon", "iki nokta" },
				{ "dot", "nokta" },
				{ "at", "et" },
				{ "equals", "eşittir" },
				{ "and", "ve" },
				{ "times", "çarpı" },
				{ "divided", "bölü" },
				{ "less", "küçüktür" },
				{ "greater", "büyüktür" },
				{ "number", "numara" },
				{ "link", "bağlantı" },
				{ "email", "e posta" },
				{ "degree", "derece" },
				{ "underscore", "alt çizgi" }
			},
			readings = new Dictionary<string, string>(),
			abbreviations = new Dictionary<string, string> { { "Dr.", "doktor" } },
			measures = new Dictionary<string, Dictionary<string, string>>
			{
				{
					"kg",
					new Dictionary<string, string>
					{
						{ "one", "{0} kilogram" },
						{ "other", "{0} kilogram" },
						{ "gender", "" }
					}
				},
				{
					"g",
					new Dictionary<string, string>
					{
						{ "one", "{0} gram" },
						{ "other", "{0} gram" },
						{ "gender", "" }
					}
				},
				{
					"km",
					new Dictionary<string, string>
					{
						{ "one", "{0} kilometre" },
						{ "other", "{0} kilometre" },
						{ "gender", "" }
					}
				},
				{
					"m",
					new Dictionary<string, string>
					{
						{ "one", "{0} metre" },
						{ "other", "{0} metre" },
						{ "gender", "" }
					}
				},
				{
					"cm",
					new Dictionary<string, string>
					{
						{ "one", "{0} santimetre" },
						{ "other", "{0} santimetre" },
						{ "gender", "" }
					}
				},
				{
					"mm",
					new Dictionary<string, string>
					{
						{ "one", "{0} milimetre" },
						{ "other", "{0} milimetre" },
						{ "gender", "" }
					}
				},
				{
					"L",
					new Dictionary<string, string>
					{
						{ "one", "{0} litre" },
						{ "other", "{0} litre" },
						{ "gender", "" }
					}
				},
				{
					"ml",
					new Dictionary<string, string>
					{
						{ "one", "{0} mililitre" },
						{ "other", "{0} mililitre" },
						{ "gender", "" }
					}
				},
				{
					"°C",
					new Dictionary<string, string>
					{
						{ "one", "{0} santigrat derece" },
						{ "other", "{0} santigrat derece" },
						{ "gender", "" }
					}
				},
				{
					"°F",
					new Dictionary<string, string>
					{
						{ "one", "{0} fahrenhayt derece" },
						{ "other", "{0} fahrenhayt derece" },
						{ "gender", "" }
					}
				},
				{
					"h",
					new Dictionary<string, string>
					{
						{ "one", "{0} saat" },
						{ "other", "{0} saat" },
						{ "gender", "" }
					}
				},
				{
					"min",
					new Dictionary<string, string>
					{
						{ "one", "{0} dakika" },
						{ "other", "{0} dakika" },
						{ "gender", "" }
					}
				},
				{
					"s",
					new Dictionary<string, string>
					{
						{ "one", "{0} saniye" },
						{ "other", "{0} saniye" },
						{ "gender", "" }
					}
				},
				{
					"day",
					new Dictionary<string, string>
					{
						{ "one", "{0} gün" },
						{ "other", "{0} gün" },
						{ "gender", "" }
					}
				},
				{
					"month",
					new Dictionary<string, string>
					{
						{ "one", "{0} ay" },
						{ "other", "{0} ay" },
						{ "gender", "" }
					}
				},
				{
					"year",
					new Dictionary<string, string>
					{
						{ "one", "{0} yıl" },
						{ "other", "{0} yıl" },
						{ "gender", "" }
					}
				},
				{
					"%",
					new Dictionary<string, string>
					{
						{ "one", "yüzde {0}" },
						{ "other", "yüzde {0}" },
						{ "gender", "" }
					}
				},
				{
					"‰",
					new Dictionary<string, string>
					{
						{ "one", "binde {0}" },
						{ "other", "binde {0}" },
						{ "gender", "" }
					}
				},
				{
					"°",
					new Dictionary<string, string>
					{
						{ "one", "{0} derece" },
						{ "other", "{0} derece" },
						{ "gender", "" }
					}
				},
				{
					"ms",
					new Dictionary<string, string>
					{
						{ "one", "{0} milisaniye" },
						{ "other", "{0} milisaniye" },
						{ "gender", "" }
					}
				},
				{
					"USD",
					new Dictionary<string, string> { { "other", "{0} ABD doları" } }
				},
				{
					"EUR",
					new Dictionary<string, string> { { "other", "{0} Euro" } }
				},
				{
					"GBP",
					new Dictionary<string, string> { { "other", "{0} İngiliz sterlini" } }
				},
				{
					"JPY",
					new Dictionary<string, string> { { "other", "{0} Japon yeni" } }
				},
				{
					"CNY",
					new Dictionary<string, string> { { "other", "{0} Çin yuanı" } }
				},
				{
					"SEK",
					new Dictionary<string, string> { { "other", "{0} İsveç kronu" } }
				},
				{
					"DKK",
					new Dictionary<string, string> { { "other", "{0} Danimarka kronu" } }
				},
				{
					"NOK",
					new Dictionary<string, string> { { "other", "{0} Norveç kronu" } }
				},
				{
					"PLN",
					new Dictionary<string, string> { { "other", "{0} Polonya zlotisi" } }
				},
				{
					"RUB",
					new Dictionary<string, string> { { "other", "{0} Rus rublesi" } }
				},
				{
					"UAH",
					new Dictionary<string, string> { { "other", "{0} Ukrayna grivnası" } }
				},
				{
					"TRY",
					new Dictionary<string, string> { { "other", "{0} Türk lirası" } }
				},
				{
					"KRW",
					new Dictionary<string, string> { { "other", "{0} Güney Kore wonu" } }
				},
				{
					"THB",
					new Dictionary<string, string> { { "other", "{0} Tayland bahtı" } }
				},
				{
					"BRL",
					new Dictionary<string, string> { { "other", "{0} Brezilya reali" } }
				}
			}
		};
		dictionary["ja"] = new Language
		{
			code = "ja",
			decimalMark = '.',
			groupMark = ',',
			letters = new string[26]
			{
				"エー", "ビー", "シー", "ディー", "イー", "エフ", "ジー", "エイチ", "アイ", "ジェー",
				"ケー", "エル", "エム", "エヌ", "オー", "ピー", "キュー", "アール", "エス", "ティー",
				"ユー", "ブイ", "ダブリュー", "エックス", "ワイ", "ゼット"
			},
			datePattern = "y年M月d日",
			months = new string[12]
			{
				"1月", "2月", "3月", "4月", "5月", "6月", "7月", "8月", "9月", "10月",
				"11月", "12月"
			},
			days = new string[0],
			terms = new Dictionary<string, string>
			{
				{ "minus", "マイナス" },
				{ "plus", "プラス" },
				{ "decimal", "てん" },
				{ "percent", "パーセント" },
				{ "to", "から" },
				{ "over", "ぶんの" },
				{ "slash", "スラッシュ" },
				{ "colon", "コロン" },
				{ "dot", "ドット" },
				{ "at", "アットマーク" },
				{ "equals", "イコール" },
				{ "and", "と" },
				{ "times", "かける" },
				{ "divided", "わる" },
				{ "less", "よりちいさい" },
				{ "greater", "よりおおきい" },
				{ "number", "ばんごう" },
				{ "link", "リンク" },
				{ "email", "メール" },
				{ "degree", "ど" },
				{ "underscore", "アンダースコア" }
			},
			readings = new Dictionary<string, string>
			{
				{ "米ドル", "べいドル" },
				{ "英国ポンド", "えいこくポンド" },
				{ "円", "えん" },
				{ "中国人民元", "ちゅうごくじんみんげん" },
				{ "韓国ウォン", "かんこくウォン" },
				{ "摂氏", "せっし" },
				{ "華氏", "かし" },
				{ "度", "ど" },
				{ "時間", "じかん" },
				{ "分", "ふん" },
				{ "秒", "びょう" },
				{ "日", "にち" },
				{ "か月", "かげつ" },
				{ "年", "ねん" },
				{ "ミリ秒", "ミリびょう" }
			},
			abbreviations = new Dictionary<string, string> { { "Dr.", "ドクター" } },
			measures = new Dictionary<string, Dictionary<string, string>>
			{
				{
					"kg",
					new Dictionary<string, string>
					{
						{ "other", "{0} キログラム" },
						{ "gender", "" }
					}
				},
				{
					"g",
					new Dictionary<string, string>
					{
						{ "other", "{0} グラム" },
						{ "gender", "" }
					}
				},
				{
					"km",
					new Dictionary<string, string>
					{
						{ "other", "{0} キロメートル" },
						{ "gender", "" }
					}
				},
				{
					"m",
					new Dictionary<string, string>
					{
						{ "other", "{0} メートル" },
						{ "gender", "" }
					}
				},
				{
					"cm",
					new Dictionary<string, string>
					{
						{ "other", "{0} センチメートル" },
						{ "gender", "" }
					}
				},
				{
					"mm",
					new Dictionary<string, string>
					{
						{ "other", "{0} ミリメートル" },
						{ "gender", "" }
					}
				},
				{
					"L",
					new Dictionary<string, string>
					{
						{ "other", "{0} リットル" },
						{ "gender", "" }
					}
				},
				{
					"ml",
					new Dictionary<string, string>
					{
						{ "other", "{0} ミリリットル" },
						{ "gender", "" }
					}
				},
				{
					"°C",
					new Dictionary<string, string>
					{
						{ "other", "摂氏 {0} 度" },
						{ "gender", "" }
					}
				},
				{
					"°F",
					new Dictionary<string, string>
					{
						{ "other", "華氏 {0} 度" },
						{ "gender", "" }
					}
				},
				{
					"h",
					new Dictionary<string, string>
					{
						{ "other", "{0} 時間" },
						{ "gender", "" }
					}
				},
				{
					"min",
					new Dictionary<string, string>
					{
						{ "other", "{0} 分" },
						{ "gender", "" }
					}
				},
				{
					"s",
					new Dictionary<string, string>
					{
						{ "other", "{0} 秒" },
						{ "gender", "" }
					}
				},
				{
					"day",
					new Dictionary<string, string>
					{
						{ "other", "{0} 日" },
						{ "gender", "" }
					}
				},
				{
					"month",
					new Dictionary<string, string>
					{
						{ "other", "{0} か月" },
						{ "gender", "" }
					}
				},
				{
					"year",
					new Dictionary<string, string>
					{
						{ "other", "{0} 年" },
						{ "gender", "" }
					}
				},
				{
					"%",
					new Dictionary<string, string>
					{
						{ "other", "{0} パーセント" },
						{ "gender", "" }
					}
				},
				{
					"‰",
					new Dictionary<string, string>
					{
						{ "other", "{0} パーミル" },
						{ "gender", "" }
					}
				},
				{
					"°",
					new Dictionary<string, string>
					{
						{ "other", "{0}度" },
						{ "gender", "" }
					}
				},
				{
					"ms",
					new Dictionary<string, string>
					{
						{ "other", "{0} ミリ秒" },
						{ "gender", "" }
					}
				},
				{
					"USD",
					new Dictionary<string, string> { { "other", "{0} 米ドル" } }
				},
				{
					"EUR",
					new Dictionary<string, string> { { "other", "{0} ユーロ" } }
				},
				{
					"GBP",
					new Dictionary<string, string> { { "other", "{0} 英国ポンド" } }
				},
				{
					"JPY",
					new Dictionary<string, string> { { "other", "{0} 円" } }
				},
				{
					"CNY",
					new Dictionary<string, string> { { "other", "{0} 中国人民元" } }
				},
				{
					"SEK",
					new Dictionary<string, string> { { "other", "{0} スウェーデン クローナ" } }
				},
				{
					"DKK",
					new Dictionary<string, string> { { "other", "{0} デンマーク クローネ" } }
				},
				{
					"NOK",
					new Dictionary<string, string> { { "other", "{0} ノルウェー クローネ" } }
				},
				{
					"PLN",
					new Dictionary<string, string> { { "other", "{0} ポーランド ズウォティ" } }
				},
				{
					"RUB",
					new Dictionary<string, string> { { "other", "{0} ロシア ルーブル" } }
				},
				{
					"UAH",
					new Dictionary<string, string> { { "other", "{0} ウクライナ フリヴニャ" } }
				},
				{
					"TRY",
					new Dictionary<string, string> { { "other", "{0} トルコ リラ" } }
				},
				{
					"KRW",
					new Dictionary<string, string> { { "other", "{0} 韓国ウォン" } }
				},
				{
					"THB",
					new Dictionary<string, string> { { "other", "{0} タイ バーツ" } }
				},
				{
					"BRL",
					new Dictionary<string, string> { { "other", "{0} ブラジル レアル" } }
				}
			}
		};
		dictionary["ko"] = new Language
		{
			code = "ko",
			decimalMark = '.',
			groupMark = ',',
			letters = new string[26]
			{
				"에이", "비", "씨", "디", "이", "에프", "지", "에이치", "아이", "제이",
				"케이", "엘", "엠", "엔", "오", "피", "큐", "알", "에스", "티",
				"유", "브이", "더블유", "엑스", "와이", "제트"
			},
			datePattern = "y년 MMMM d일",
			months = new string[12]
			{
				"1월", "2월", "3월", "4월", "5월", "6월", "7월", "8월", "9월", "10월",
				"11월", "12월"
			},
			days = new string[0],
			terms = new Dictionary<string, string>
			{
				{ "minus", "마이너스" },
				{ "plus", "플러스" },
				{ "decimal", "점" },
				{ "percent", "퍼센트" },
				{ "to", "에서" },
				{ "over", "분의" },
				{ "slash", "슬래시" },
				{ "colon", "콜론" },
				{ "dot", "점" },
				{ "at", "골뱅이" },
				{ "equals", "같다" },
				{ "and", "그리고" },
				{ "times", "곱하기" },
				{ "divided", "나누기" },
				{ "less", "작다" },
				{ "greater", "크다" },
				{ "number", "번호" },
				{ "link", "링크" },
				{ "email", "이메일" },
				{ "degree", "도" },
				{ "underscore", "밑줄" }
			},
			readings = new Dictionary<string, string>(),
			abbreviations = new Dictionary<string, string> { { "Dr.", "닥터" } },
			measures = new Dictionary<string, Dictionary<string, string>>
			{
				{
					"kg",
					new Dictionary<string, string>
					{
						{ "other", "{0}킬로그램" },
						{ "gender", "" }
					}
				},
				{
					"g",
					new Dictionary<string, string>
					{
						{ "other", "{0}그램" },
						{ "gender", "" }
					}
				},
				{
					"km",
					new Dictionary<string, string>
					{
						{ "other", "{0}킬로미터" },
						{ "gender", "" }
					}
				},
				{
					"m",
					new Dictionary<string, string>
					{
						{ "other", "{0}미터" },
						{ "gender", "" }
					}
				},
				{
					"cm",
					new Dictionary<string, string>
					{
						{ "other", "{0}센티미터" },
						{ "gender", "" }
					}
				},
				{
					"mm",
					new Dictionary<string, string>
					{
						{ "other", "{0}밀리미터" },
						{ "gender", "" }
					}
				},
				{
					"L",
					new Dictionary<string, string>
					{
						{ "other", "{0}리터" },
						{ "gender", "" }
					}
				},
				{
					"ml",
					new Dictionary<string, string>
					{
						{ "other", "{0}밀리리터" },
						{ "gender", "" }
					}
				},
				{
					"°C",
					new Dictionary<string, string>
					{
						{ "other", "섭씨 {0}도" },
						{ "gender", "" }
					}
				},
				{
					"°F",
					new Dictionary<string, string>
					{
						{ "other", "화씨 {0}도" },
						{ "gender", "" }
					}
				},
				{
					"h",
					new Dictionary<string, string>
					{
						{ "other", "{0}시간" },
						{ "gender", "" }
					}
				},
				{
					"min",
					new Dictionary<string, string>
					{
						{ "other", "{0}분" },
						{ "gender", "" }
					}
				},
				{
					"s",
					new Dictionary<string, string>
					{
						{ "other", "{0}초" },
						{ "gender", "" }
					}
				},
				{
					"day",
					new Dictionary<string, string>
					{
						{ "other", "{0}일" },
						{ "gender", "" }
					}
				},
				{
					"month",
					new Dictionary<string, string>
					{
						{ "other", "{0}개월" },
						{ "gender", "" }
					}
				},
				{
					"year",
					new Dictionary<string, string>
					{
						{ "other", "{0}년" },
						{ "gender", "" }
					}
				},
				{
					"%",
					new Dictionary<string, string> { { "other", "{0} 퍼센트" } }
				},
				{
					"‰",
					new Dictionary<string, string> { { "other", "{0} 분의 1000" } }
				},
				{
					"°",
					new Dictionary<string, string>
					{
						{ "other", "{0}도" },
						{ "gender", "" }
					}
				},
				{
					"ms",
					new Dictionary<string, string>
					{
						{ "other", "{0}밀리초" },
						{ "gender", "" }
					}
				},
				{
					"USD",
					new Dictionary<string, string> { { "other", "{0} 미국 달러" } }
				},
				{
					"EUR",
					new Dictionary<string, string> { { "other", "{0} 유로" } }
				},
				{
					"GBP",
					new Dictionary<string, string> { { "other", "{0} 영국 파운드" } }
				},
				{
					"JPY",
					new Dictionary<string, string> { { "other", "{0} 일본 엔화" } }
				},
				{
					"CNY",
					new Dictionary<string, string> { { "other", "{0} 중국 위안화" } }
				},
				{
					"SEK",
					new Dictionary<string, string> { { "other", "{0} 스웨덴 크로나" } }
				},
				{
					"DKK",
					new Dictionary<string, string> { { "other", "{0} 덴마크 크로네" } }
				},
				{
					"NOK",
					new Dictionary<string, string> { { "other", "{0} 노르웨이 크로네" } }
				},
				{
					"PLN",
					new Dictionary<string, string> { { "other", "{0} 폴란드 즈워티" } }
				},
				{
					"RUB",
					new Dictionary<string, string> { { "other", "{0} 러시아 루블" } }
				},
				{
					"UAH",
					new Dictionary<string, string> { { "other", "{0} 우크라이나 그리브나" } }
				},
				{
					"TRY",
					new Dictionary<string, string> { { "other", "{0} 튀르키예 리라" } }
				},
				{
					"KRW",
					new Dictionary<string, string> { { "other", "{0} 대한민국 원" } }
				},
				{
					"THB",
					new Dictionary<string, string> { { "other", "{0} 태국 바트" } }
				},
				{
					"BRL",
					new Dictionary<string, string> { { "other", "{0} 브라질 레알" } }
				}
			}
		};
		dictionary["zh"] = new Language
		{
			code = "zh",
			decimalMark = '.',
			groupMark = ',',
			letters = new string[26]
			{
				"~eI", "~bi", "~si", "~di", "~i", "~ef", "~dZi", "~eItS", "~aI", "~dZeI",
				"~keI", "~el", "~em", "~en", "~oU", "~pi", "~kju", "~Ar", "~es", "~ti",
				"~ju", "~vi", "~dVb@lju", "~eks", "~waI", "~zi"
			},
			datePattern = "y年M月d日",
			months = new string[12]
			{
				"一月", "二月", "三月", "四月", "五月", "六月", "七月", "八月", "九月", "十月",
				"十一月", "十二月"
			},
			days = new string[0],
			terms = new Dictionary<string, string>
			{
				{ "minus", "负" },
				{ "plus", "加" },
				{ "decimal", "点" },
				{ "percent", "百分之" },
				{ "to", "到" },
				{ "over", "分之" },
				{ "slash", "斜杠" },
				{ "colon", "冒号" },
				{ "dot", "点" },
				{ "at", "艾特" },
				{ "equals", "等于" },
				{ "and", "和" },
				{ "times", "乘" },
				{ "divided", "除以" },
				{ "less", "小于" },
				{ "greater", "大于" },
				{ "number", "编号" },
				{ "link", "链接" },
				{ "email", "邮箱" },
				{ "degree", "度" },
				{ "underscore", "下划线" }
			},
			readings = new Dictionary<string, string>
			{
				{ "负", "~f,u" },
				{ "加", "~dZ,i,A" },
				{ "点", "~d,i,e,n" },
				{ "百分之", "~b,aI f,@,n dZ,@" },
				{ "到", "~d,A,U" },
				{ "分之", "~f,@,n dZ,@" },
				{ "斜杠", "~S,i,e g,A,N" },
				{ "冒号", "~m,A,U h,A,U" },
				{ "艾特", "~aI t,@" },
				{ "等于", "~d,@,N j,y" },
				{ "和", "~h,@" },
				{ "乘", "~tS,@,N" },
				{ "除以", "~tS,u i" },
				{ "小于", "~S,i,A,U j,y" },
				{ "大于", "~d,A j,y" },
				{ "编号", "~b,i,e,n h,A,U" },
				{ "链接", "~l,i,e,n dZ,i,e" },
				{ "邮箱", "~j,U S,i,A,N" },
				{ "度", "~d,u" },
				{ "千克", "~tS,i,e,n k,@" },
				{ "克", "~k,@" },
				{ "公里", "~g,U,N l,i" },
				{ "米", "~m,i" },
				{ "厘米", "~l,i m,i" },
				{ "毫米", "~h,A,U m,i" },
				{ "升", "~S,@,N" },
				{ "公升", "~g,U,N S,@,N" },
				{ "毫升", "~h,A,U S,@,N" },
				{ "摄氏度", "~S,@ S,@ d,u" },
				{ "攝氏", "~S,@ S,@" },
				{ "华氏度", "~h,w,A S,@ d,u" },
				{ "華氏", "~h,w,A S,@" },
				{ "小时", "~S,i,A,U S,@" },
				{ "小時", "~S,i,A,U S,@" },
				{ "分钟", "~f,@,n dZ,U,N" },
				{ "分鐘", "~f,@,n dZ,U,N" },
				{ "秒钟", "~m,i,A,U dZ,U,N" },
				{ "秒鐘", "~m,i,A,U dZ,U,N" },
				{ "秒", "~m,i,A,U" },
				{ "天", "~t,i,e,n" },
				{ "个月", "~g,@ j,U,e" },
				{ "個月", "~g,@ j,U,e" },
				{ "年", "~n,i,e,n" },
				{ "美元", "~m,eI j,U,e,n" },
				{ "欧元", "~oU j,U,e,n" },
				{ "歐元", "~oU j,U,e,n" },
				{ "英镑", "~i,N b,A,N" },
				{ "英鎊", "~i,N b,A,N" },
				{ "日元", "~r,@ j,U,e,n" },
				{ "日圓", "~r,@ j,U,e,n" },
				{ "人民币", "~r,@,n m,i,n b,i" },
				{ "人民幣", "~r,@,n m,i,n b,i" },
				{ "瑞典克朗", "~r,U,eI d,i,e,n k,@ l,A,N" },
				{ "丹麦克朗", "~d,A,n m,aI k,@ l,A,N" },
				{ "丹麥克朗", "~d,A,n m,aI k,@ l,A,N" },
				{ "挪威克朗", "~n,w,o w,eI k,@ l,A,N" },
				{ "波兰兹罗提", "~b,o l,A,n z,@ l,w,o t,i" },
				{ "波蘭茲羅提", "~b,o l,A,n z,@ l,w,o t,i" },
				{ "俄罗斯卢布", "~@ l,w,o s,@ l,u b,u" },
				{ "俄羅斯盧布", "~@ l,w,o s,@ l,u b,u" },
				{ "乌克兰格里夫纳", "~w,u k,@ l,A,n g,@ l,i f,u n,A" },
				{ "烏克蘭格里夫納", "~w,u k,@ l,A,n g,@ l,i f,u n,A" },
				{ "土耳其里拉", "~t,u A,r tS,i l,i l,A" },
				{ "韩元", "~h,A,n j,U,e,n" },
				{ "韓元", "~h,A,n j,U,e,n" },
				{ "泰铢", "~t,aI dZ,u" },
				{ "泰銖", "~t,aI dZ,u" },
				{ "巴西雷亚尔", "~b,A S,i l,eI j,A A,r" },
				{ "巴西雷亞爾", "~b,A S,i l,eI j,A A,r" },
				{ "公分", "~g,U,N f,@,n" },
				{ "公尺", "~g,U,N tS,@" },
				{ "公斤", "~g,U,N dZ,i,n" },
				{ "公釐", "~g,U,N l,i" },
				{ "毫秒", "~h,A,U m,i,A,U" },
				{ "千分之", "~tS,i,e,n f,@,n dZ,@" },
				{ "下划线", "~S,i,A h,w,A S,i,e,n" }
			},
			abbreviations = new Dictionary<string, string> { { "Dr.", "~p,o S,@" } },
			measures = new Dictionary<string, Dictionary<string, string>>
			{
				{
					"kg",
					new Dictionary<string, string>
					{
						{ "other", "{0}千克" },
						{ "gender", "" }
					}
				},
				{
					"g",
					new Dictionary<string, string>
					{
						{ "other", "{0}克" },
						{ "gender", "" }
					}
				},
				{
					"km",
					new Dictionary<string, string>
					{
						{ "other", "{0}公里" },
						{ "gender", "" }
					}
				},
				{
					"m",
					new Dictionary<string, string>
					{
						{ "other", "{0}米" },
						{ "gender", "" }
					}
				},
				{
					"cm",
					new Dictionary<string, string>
					{
						{ "other", "{0}厘米" },
						{ "gender", "" }
					}
				},
				{
					"mm",
					new Dictionary<string, string>
					{
						{ "other", "{0}毫米" },
						{ "gender", "" }
					}
				},
				{
					"L",
					new Dictionary<string, string>
					{
						{ "other", "{0}升" },
						{ "gender", "" }
					}
				},
				{
					"ml",
					new Dictionary<string, string>
					{
						{ "other", "{0}毫升" },
						{ "gender", "" }
					}
				},
				{
					"°C",
					new Dictionary<string, string>
					{
						{ "other", "{0}摄氏度" },
						{ "gender", "" }
					}
				},
				{
					"°F",
					new Dictionary<string, string>
					{
						{ "other", "{0}华氏度" },
						{ "gender", "" }
					}
				},
				{
					"h",
					new Dictionary<string, string>
					{
						{ "other", "{0}小时" },
						{ "gender", "" }
					}
				},
				{
					"min",
					new Dictionary<string, string>
					{
						{ "other", "{0}分钟" },
						{ "gender", "" }
					}
				},
				{
					"s",
					new Dictionary<string, string>
					{
						{ "other", "{0}秒钟" },
						{ "gender", "" }
					}
				},
				{
					"day",
					new Dictionary<string, string>
					{
						{ "other", "{0}天" },
						{ "gender", "" }
					}
				},
				{
					"month",
					new Dictionary<string, string>
					{
						{ "other", "{0}个月" },
						{ "gender", "" }
					}
				},
				{
					"year",
					new Dictionary<string, string>
					{
						{ "other", "{0}年" },
						{ "gender", "" }
					}
				},
				{
					"%",
					new Dictionary<string, string>
					{
						{ "other", "百分之{0}" },
						{ "gender", "" }
					}
				},
				{
					"‰",
					new Dictionary<string, string>
					{
						{ "other", "千分之{0}" },
						{ "gender", "" }
					}
				},
				{
					"°",
					new Dictionary<string, string>
					{
						{ "other", "{0}度" },
						{ "gender", "" }
					}
				},
				{
					"ms",
					new Dictionary<string, string>
					{
						{ "other", "{0}毫秒" },
						{ "gender", "" }
					}
				},
				{
					"USD",
					new Dictionary<string, string> { { "other", "{0} 美元" } }
				},
				{
					"EUR",
					new Dictionary<string, string> { { "other", "{0} 欧元" } }
				},
				{
					"GBP",
					new Dictionary<string, string> { { "other", "{0} 英镑" } }
				},
				{
					"JPY",
					new Dictionary<string, string> { { "other", "{0} 日元" } }
				},
				{
					"CNY",
					new Dictionary<string, string> { { "other", "{0} 人民币" } }
				},
				{
					"SEK",
					new Dictionary<string, string> { { "other", "{0} 瑞典克朗" } }
				},
				{
					"DKK",
					new Dictionary<string, string> { { "other", "{0} 丹麦克朗" } }
				},
				{
					"NOK",
					new Dictionary<string, string> { { "other", "{0} 挪威克朗" } }
				},
				{
					"PLN",
					new Dictionary<string, string> { { "other", "{0} 波兰兹罗提" } }
				},
				{
					"RUB",
					new Dictionary<string, string> { { "other", "{0} 俄罗斯卢布" } }
				},
				{
					"UAH",
					new Dictionary<string, string> { { "other", "{0} 乌克兰格里夫纳" } }
				},
				{
					"TRY",
					new Dictionary<string, string> { { "other", "{0} 土耳其里拉" } }
				},
				{
					"KRW",
					new Dictionary<string, string> { { "other", "{0} 韩元" } }
				},
				{
					"THB",
					new Dictionary<string, string> { { "other", "{0} 泰铢" } }
				},
				{
					"BRL",
					new Dictionary<string, string> { { "other", "{0} 巴西雷亚尔" } }
				}
			}
		};
		dictionary["zh-TW"] = new Language
		{
			code = "zh-TW",
			decimalMark = '.',
			groupMark = ',',
			letters = new string[26]
			{
				"~eI", "~bi", "~si", "~di", "~i", "~ef", "~dZi", "~eItS", "~aI", "~dZeI",
				"~keI", "~el", "~em", "~en", "~oU", "~pi", "~kju", "~Ar", "~es", "~ti",
				"~ju", "~vi", "~dVb@lju", "~eks", "~waI", "~zi"
			},
			datePattern = "y年M月d日",
			months = new string[12]
			{
				"1月", "2月", "3月", "4月", "5月", "6月", "7月", "8月", "9月", "10月",
				"11月", "12月"
			},
			days = new string[0],
			terms = new Dictionary<string, string>
			{
				{ "minus", "负" },
				{ "plus", "加" },
				{ "decimal", "点" },
				{ "percent", "百分之" },
				{ "to", "到" },
				{ "over", "分之" },
				{ "slash", "斜杠" },
				{ "colon", "冒号" },
				{ "dot", "点" },
				{ "at", "艾特" },
				{ "equals", "等于" },
				{ "and", "和" },
				{ "times", "乘" },
				{ "divided", "除以" },
				{ "less", "小于" },
				{ "greater", "大于" },
				{ "number", "编号" },
				{ "link", "链接" },
				{ "email", "邮箱" },
				{ "degree", "度" },
				{ "underscore", "下划线" }
			},
			readings = new Dictionary<string, string>
			{
				{ "负", "~f,u" },
				{ "加", "~dZ,i,A" },
				{ "点", "~d,i,e,n" },
				{ "百分之", "~b,aI f,@,n dZ,@" },
				{ "到", "~d,A,U" },
				{ "分之", "~f,@,n dZ,@" },
				{ "斜杠", "~S,i,e g,A,N" },
				{ "冒号", "~m,A,U h,A,U" },
				{ "艾特", "~aI t,@" },
				{ "等于", "~d,@,N j,y" },
				{ "和", "~h,@" },
				{ "乘", "~tS,@,N" },
				{ "除以", "~tS,u i" },
				{ "小于", "~S,i,A,U j,y" },
				{ "大于", "~d,A j,y" },
				{ "编号", "~b,i,e,n h,A,U" },
				{ "链接", "~l,i,e,n dZ,i,e" },
				{ "邮箱", "~j,U S,i,A,N" },
				{ "度", "~d,u" },
				{ "千克", "~tS,i,e,n k,@" },
				{ "克", "~k,@" },
				{ "公里", "~g,U,N l,i" },
				{ "米", "~m,i" },
				{ "厘米", "~l,i m,i" },
				{ "毫米", "~h,A,U m,i" },
				{ "升", "~S,@,N" },
				{ "公升", "~g,U,N S,@,N" },
				{ "毫升", "~h,A,U S,@,N" },
				{ "摄氏度", "~S,@ S,@ d,u" },
				{ "攝氏", "~S,@ S,@" },
				{ "华氏度", "~h,w,A S,@ d,u" },
				{ "華氏", "~h,w,A S,@" },
				{ "小时", "~S,i,A,U S,@" },
				{ "小時", "~S,i,A,U S,@" },
				{ "分钟", "~f,@,n dZ,U,N" },
				{ "分鐘", "~f,@,n dZ,U,N" },
				{ "秒钟", "~m,i,A,U dZ,U,N" },
				{ "秒鐘", "~m,i,A,U dZ,U,N" },
				{ "秒", "~m,i,A,U" },
				{ "天", "~t,i,e,n" },
				{ "个月", "~g,@ j,U,e" },
				{ "個月", "~g,@ j,U,e" },
				{ "年", "~n,i,e,n" },
				{ "美元", "~m,eI j,U,e,n" },
				{ "欧元", "~oU j,U,e,n" },
				{ "歐元", "~oU j,U,e,n" },
				{ "英镑", "~i,N b,A,N" },
				{ "英鎊", "~i,N b,A,N" },
				{ "日元", "~r,@ j,U,e,n" },
				{ "日圓", "~r,@ j,U,e,n" },
				{ "人民币", "~r,@,n m,i,n b,i" },
				{ "人民幣", "~r,@,n m,i,n b,i" },
				{ "瑞典克朗", "~r,U,eI d,i,e,n k,@ l,A,N" },
				{ "丹麦克朗", "~d,A,n m,aI k,@ l,A,N" },
				{ "丹麥克朗", "~d,A,n m,aI k,@ l,A,N" },
				{ "挪威克朗", "~n,w,o w,eI k,@ l,A,N" },
				{ "波兰兹罗提", "~b,o l,A,n z,@ l,w,o t,i" },
				{ "波蘭茲羅提", "~b,o l,A,n z,@ l,w,o t,i" },
				{ "俄罗斯卢布", "~@ l,w,o s,@ l,u b,u" },
				{ "俄羅斯盧布", "~@ l,w,o s,@ l,u b,u" },
				{ "乌克兰格里夫纳", "~w,u k,@ l,A,n g,@ l,i f,u n,A" },
				{ "烏克蘭格里夫納", "~w,u k,@ l,A,n g,@ l,i f,u n,A" },
				{ "土耳其里拉", "~t,u A,r tS,i l,i l,A" },
				{ "韩元", "~h,A,n j,U,e,n" },
				{ "韓元", "~h,A,n j,U,e,n" },
				{ "泰铢", "~t,aI dZ,u" },
				{ "泰銖", "~t,aI dZ,u" },
				{ "巴西雷亚尔", "~b,A S,i l,eI j,A A,r" },
				{ "巴西雷亞爾", "~b,A S,i l,eI j,A A,r" },
				{ "公分", "~g,U,N f,@,n" },
				{ "公尺", "~g,U,N tS,@" },
				{ "公斤", "~g,U,N dZ,i,n" },
				{ "公釐", "~g,U,N l,i" },
				{ "毫秒", "~h,A,U m,i,A,U" },
				{ "千分之", "~tS,i,e,n f,@,n dZ,@" },
				{ "下划线", "~S,i,A h,w,A S,i,e,n" }
			},
			abbreviations = new Dictionary<string, string> { { "Dr.", "~p,o S,@" } },
			measures = new Dictionary<string, Dictionary<string, string>>
			{
				{
					"kg",
					new Dictionary<string, string>
					{
						{ "other", "{0} 公斤" },
						{ "gender", "" }
					}
				},
				{
					"g",
					new Dictionary<string, string>
					{
						{ "other", "{0} 克" },
						{ "gender", "" }
					}
				},
				{
					"km",
					new Dictionary<string, string>
					{
						{ "other", "{0} 公里" },
						{ "gender", "" }
					}
				},
				{
					"m",
					new Dictionary<string, string>
					{
						{ "other", "{0} 公尺" },
						{ "gender", "" }
					}
				},
				{
					"cm",
					new Dictionary<string, string>
					{
						{ "other", "{0} 公分" },
						{ "gender", "" }
					}
				},
				{
					"mm",
					new Dictionary<string, string>
					{
						{ "other", "{0} 公釐" },
						{ "gender", "" }
					}
				},
				{
					"L",
					new Dictionary<string, string>
					{
						{ "other", "{0} 公升" },
						{ "gender", "" }
					}
				},
				{
					"ml",
					new Dictionary<string, string>
					{
						{ "other", "{0} 毫升" },
						{ "gender", "" }
					}
				},
				{
					"°C",
					new Dictionary<string, string>
					{
						{ "other", "攝氏 {0} 度" },
						{ "gender", "" }
					}
				},
				{
					"°F",
					new Dictionary<string, string>
					{
						{ "other", "華氏 {0} 度" },
						{ "gender", "" }
					}
				},
				{
					"h",
					new Dictionary<string, string>
					{
						{ "other", "{0} 小時" },
						{ "gender", "" }
					}
				},
				{
					"min",
					new Dictionary<string, string>
					{
						{ "other", "{0} 分鐘" },
						{ "gender", "" }
					}
				},
				{
					"s",
					new Dictionary<string, string>
					{
						{ "other", "{0} 秒" },
						{ "gender", "" }
					}
				},
				{
					"day",
					new Dictionary<string, string>
					{
						{ "other", "{0} 天" },
						{ "gender", "" }
					}
				},
				{
					"month",
					new Dictionary<string, string>
					{
						{ "other", "{0} 個月" },
						{ "gender", "" }
					}
				},
				{
					"year",
					new Dictionary<string, string>
					{
						{ "other", "{0} 年" },
						{ "gender", "" }
					}
				},
				{
					"%",
					new Dictionary<string, string>
					{
						{ "other", "百分之{0}" },
						{ "gender", "" }
					}
				},
				{
					"‰",
					new Dictionary<string, string>
					{
						{ "other", "千分之{0}" },
						{ "gender", "" }
					}
				},
				{
					"°",
					new Dictionary<string, string>
					{
						{ "other", "{0}度" },
						{ "gender", "" }
					}
				},
				{
					"ms",
					new Dictionary<string, string>
					{
						{ "other", "{0} 毫秒" },
						{ "gender", "" }
					}
				},
				{
					"USD",
					new Dictionary<string, string> { { "other", "{0} 美元" } }
				},
				{
					"EUR",
					new Dictionary<string, string> { { "other", "{0} 歐元" } }
				},
				{
					"GBP",
					new Dictionary<string, string> { { "other", "{0} 英鎊" } }
				},
				{
					"JPY",
					new Dictionary<string, string> { { "other", "{0} 日圓" } }
				},
				{
					"CNY",
					new Dictionary<string, string> { { "other", "{0} 人民幣" } }
				},
				{
					"SEK",
					new Dictionary<string, string> { { "other", "{0} 瑞典克朗" } }
				},
				{
					"DKK",
					new Dictionary<string, string> { { "other", "{0} 丹麥克朗" } }
				},
				{
					"NOK",
					new Dictionary<string, string> { { "other", "{0} 挪威克朗" } }
				},
				{
					"PLN",
					new Dictionary<string, string> { { "other", "{0} 波蘭茲羅提" } }
				},
				{
					"RUB",
					new Dictionary<string, string> { { "other", "{0} 俄羅斯盧布" } }
				},
				{
					"UAH",
					new Dictionary<string, string> { { "other", "{0} 烏克蘭格里夫納" } }
				},
				{
					"TRY",
					new Dictionary<string, string> { { "other", "{0} 土耳其里拉" } }
				},
				{
					"KRW",
					new Dictionary<string, string> { { "other", "{0} 韓元" } }
				},
				{
					"THB",
					new Dictionary<string, string> { { "other", "{0} 泰銖" } }
				},
				{
					"BRL",
					new Dictionary<string, string> { { "other", "{0} 巴西雷亞爾" } }
				}
			}
		};
		dictionary["th"] = new Language
		{
			code = "th",
			decimalMark = '.',
			groupMark = ',',
			letters = new string[26]
			{
				"เอ", "บ\u0e35", "ซ\u0e35", "ด\u0e35", "อ\u0e35", "เอฟ", "จ\u0e35", "เอช", "ไอ", "เจ",
				"เค", "แอล", "เอ\u0e47ม", "เอ\u0e47น", "โอ", "พ\u0e35", "ค\u0e34ว", "อาร\u0e4c", "เอส", "ท\u0e35",
				"ย\u0e39", "ว\u0e35", "ด\u0e31บเบ\u0e34ลย\u0e39", "เอ\u0e47กซ\u0e4c", "วาย", "แซด"
			},
			datePattern = "d MMMM G y",
			months = new string[12]
			{
				"มกราคม", "ก\u0e38มภาพ\u0e31นธ\u0e4c", "ม\u0e35นาคม", "เมษายน", "พฤษภาคม", "ม\u0e34ถ\u0e38นายน", "กรกฎาคม", "ส\u0e34งหาคม", "ก\u0e31นยายน", "ต\u0e38ลาคม",
				"พฤศจ\u0e34กายน", "ธ\u0e31นวาคม"
			},
			days = new string[0],
			terms = new Dictionary<string, string>
			{
				{ "minus", "ลบ" },
				{ "plus", "บวก" },
				{ "decimal", "จ\u0e38ด" },
				{ "percent", "เปอร\u0e4cเซ\u0e47นต\u0e4c" },
				{ "to", "ถ\u0e36ง" },
				{ "over", "ส\u0e48วน" },
				{ "slash", "ท\u0e31บ" },
				{ "colon", "ทว\u0e34ภาค" },
				{ "dot", "จ\u0e38ด" },
				{ "at", "แอท" },
				{ "equals", "เท\u0e48าก\u0e31บ" },
				{ "and", "และ" },
				{ "times", "ค\u0e39ณ" },
				{ "divided", "หารด\u0e49วย" },
				{ "less", "น\u0e49อยกว\u0e48า" },
				{ "greater", "มากกว\u0e48า" },
				{ "number", "หมายเลข" },
				{ "link", "ล\u0e34งก\u0e4c" },
				{ "email", "อ\u0e35เมล" },
				{ "degree", "องศา" },
				{ "underscore", "ข\u0e35ดล\u0e48าง" }
			},
			readings = new Dictionary<string, string>(),
			abbreviations = new Dictionary<string, string> { { "Dr.", "ดอกเตอร\u0e4c" } },
			measures = new Dictionary<string, Dictionary<string, string>>
			{
				{
					"kg",
					new Dictionary<string, string>
					{
						{ "other", "{0} ก\u0e34โลกร\u0e31ม" },
						{ "gender", "" }
					}
				},
				{
					"g",
					new Dictionary<string, string>
					{
						{ "other", "{0} กร\u0e31ม" },
						{ "gender", "" }
					}
				},
				{
					"km",
					new Dictionary<string, string>
					{
						{ "other", "{0} ก\u0e34โลเมตร" },
						{ "gender", "" }
					}
				},
				{
					"m",
					new Dictionary<string, string>
					{
						{ "other", "{0} เมตร" },
						{ "gender", "" }
					}
				},
				{
					"cm",
					new Dictionary<string, string>
					{
						{ "other", "{0} เซนต\u0e34เมตร" },
						{ "gender", "" }
					}
				},
				{
					"mm",
					new Dictionary<string, string>
					{
						{ "other", "{0} ม\u0e34ลล\u0e34เมตร" },
						{ "gender", "" }
					}
				},
				{
					"L",
					new Dictionary<string, string>
					{
						{ "other", "{0} ล\u0e34ตร" },
						{ "gender", "" }
					}
				},
				{
					"ml",
					new Dictionary<string, string>
					{
						{ "other", "{0} ม\u0e34ลล\u0e34ล\u0e34ตร" },
						{ "gender", "" }
					}
				},
				{
					"°C",
					new Dictionary<string, string>
					{
						{ "other", "{0} องศาเซลเซ\u0e35ยส" },
						{ "gender", "" }
					}
				},
				{
					"°F",
					new Dictionary<string, string>
					{
						{ "other", "{0} องศาฟาเรนไฮต\u0e4c" },
						{ "gender", "" }
					}
				},
				{
					"h",
					new Dictionary<string, string>
					{
						{ "other", "{0} ช\u0e31\u0e48วโมง" },
						{ "gender", "" }
					}
				},
				{
					"min",
					new Dictionary<string, string>
					{
						{ "other", "{0} นาท\u0e35" },
						{ "gender", "" }
					}
				},
				{
					"s",
					new Dictionary<string, string>
					{
						{ "other", "{0} ว\u0e34นาท\u0e35" },
						{ "gender", "" }
					}
				},
				{
					"day",
					new Dictionary<string, string>
					{
						{ "other", "{0} ว\u0e31น" },
						{ "gender", "" }
					}
				},
				{
					"month",
					new Dictionary<string, string>
					{
						{ "other", "{0} เด\u0e37อน" },
						{ "gender", "" }
					}
				},
				{
					"year",
					new Dictionary<string, string>
					{
						{ "other", "{0} ป\u0e35" },
						{ "gender", "" }
					}
				},
				{
					"%",
					new Dictionary<string, string>
					{
						{ "other", "{0}\u00a0เปอร\u0e4cเซ\u0e47นต\u0e4c" },
						{ "gender", "" }
					}
				},
				{
					"‰",
					new Dictionary<string, string>
					{
						{ "other", "{0} เปอร\u0e4cม\u0e34ลล\u0e4c" },
						{ "gender", "" }
					}
				},
				{
					"°",
					new Dictionary<string, string> { { "other", "{0} องศา" } }
				},
				{
					"ms",
					new Dictionary<string, string>
					{
						{ "other", "{0} ม\u0e34ลล\u0e34ว\u0e34นาท\u0e35" },
						{ "gender", "" }
					}
				},
				{
					"USD",
					new Dictionary<string, string> { { "other", "{0} ดอลลาร\u0e4cสหร\u0e31ฐ" } }
				},
				{
					"EUR",
					new Dictionary<string, string> { { "other", "{0} ย\u0e39โร" } }
				},
				{
					"GBP",
					new Dictionary<string, string> { { "other", "{0} ปอนด\u0e4cสเตอร\u0e4cล\u0e34ง (สหราชอาณาจ\u0e31กร)" } }
				},
				{
					"JPY",
					new Dictionary<string, string> { { "other", "{0} เยนญ\u0e35\u0e48ป\u0e38\u0e48น" } }
				},
				{
					"CNY",
					new Dictionary<string, string> { { "other", "{0} หยวนจ\u0e35น" } }
				},
				{
					"SEK",
					new Dictionary<string, string> { { "other", "{0} โครนาสว\u0e35เดน" } }
				},
				{
					"DKK",
					new Dictionary<string, string> { { "other", "{0} โครนเดนมาร\u0e4cก" } }
				},
				{
					"NOK",
					new Dictionary<string, string> { { "other", "{0} โครนนอร\u0e4cเวย\u0e4c" } }
				},
				{
					"PLN",
					new Dictionary<string, string> { { "other", "{0} ซลอต\u0e35โปแลนด\u0e4c" } }
				},
				{
					"RUB",
					new Dictionary<string, string> { { "other", "{0} ร\u0e39เบ\u0e34ลร\u0e31สเซ\u0e35ย" } }
				},
				{
					"UAH",
					new Dictionary<string, string> { { "other", "{0} ฮร\u0e35ฟเน\u0e35ยย\u0e39เครน" } }
				},
				{
					"TRY",
					new Dictionary<string, string> { { "other", "{0} ล\u0e35ราต\u0e38รก\u0e35" } }
				},
				{
					"KRW",
					new Dictionary<string, string> { { "other", "{0} วอนเกาหล\u0e35ใต\u0e49" } }
				},
				{
					"THB",
					new Dictionary<string, string> { { "other", "{0} บาทไทย" } }
				},
				{
					"BRL",
					new Dictionary<string, string> { { "other", "{0} เร\u0e35ยลบราซ\u0e34ล" } }
				}
			}
		};
		dictionary["ar"] = new Language
		{
			code = "ar",
			decimalMark = '.',
			groupMark = ',',
			letters = new string[26]
			{
				"إيه", "بي", "سي", "دي", "إي", "إف", "جي", "إيتش", "آي", "جاي",
				"كاي", "إل", "إم", "إن", "أو", "بي", "كيو", "آر", "إس", "تي",
				"يو", "في", "دابليو", "إكس", "واي", "زد"
			},
			datePattern = "d MMMM y",
			months = new string[12]
			{
				"يناير", "فبراير", "مارس", "أبريل", "مايو", "يونيو", "يوليو", "أغسطس", "سبتمبر", "أكتوبر",
				"نوفمبر", "ديسمبر"
			},
			days = new string[0],
			terms = new Dictionary<string, string>
			{
				{ "minus", "ناقص" },
				{ "plus", "زائد" },
				{ "decimal", "فاصلة" },
				{ "percent", "بالمئة" },
				{ "to", "إلى" },
				{ "over", "على" },
				{ "slash", "شرطة مائلة" },
				{ "colon", "نقطتان" },
				{ "dot", "نقطة" },
				{ "at", "آت" },
				{ "equals", "يساوي" },
				{ "and", "و" },
				{ "times", "ضرب" },
				{ "divided", "قسمة" },
				{ "less", "أصغر من" },
				{ "greater", "أكبر من" },
				{ "number", "رقم" },
				{ "link", "رابط" },
				{ "email", "بريد إلكتروني" },
				{ "degree", "درجة" },
				{ "underscore", "شرطة سفلية" }
			},
			readings = new Dictionary<string, string>(),
			abbreviations = new Dictionary<string, string> { { "Dr.", "دكتور" } },
			measures = new Dictionary<string, Dictionary<string, string>>
			{
				{
					"kg",
					new Dictionary<string, string>
					{
						{ "zero", "{0} كيلوغرام" },
						{ "one", "{0} كيلوغرام" },
						{ "two", "{0} كيلوغرام" },
						{ "few", "{0} كيلوغرام" },
						{ "many", "{0} كيلوغرام" },
						{ "other", "{0} كيلوغرام" },
						{ "gender", "masculine" }
					}
				},
				{
					"g",
					new Dictionary<string, string>
					{
						{ "zero", "{0} غرام" },
						{ "one", "غرام" },
						{ "two", "غرامان" },
						{ "few", "{0} غرامات" },
						{ "many", "{0} غرام\u064bا" },
						{ "other", "{0} غرام" },
						{ "gender", "masculine" }
					}
				},
				{
					"km",
					new Dictionary<string, string>
					{
						{ "zero", "{0} كيلومتر" },
						{ "one", "{0} كيلومتر" },
						{ "two", "{0} كيلومتر" },
						{ "few", "{0} كيلومترات" },
						{ "many", "{0} كيلومتر\u064bا" },
						{ "other", "{0} كيلومتر" },
						{ "gender", "masculine" }
					}
				},
				{
					"m",
					new Dictionary<string, string>
					{
						{ "zero", "{0} متر" },
						{ "one", "متر" },
						{ "two", "{0} متر" },
						{ "few", "{0} أمتار" },
						{ "many", "{0} متر\u064bا" },
						{ "other", "{0} متر" },
						{ "gender", "masculine" }
					}
				},
				{
					"cm",
					new Dictionary<string, string>
					{
						{ "zero", "{0} سنتيمتر" },
						{ "one", "{0} سنتيمتر" },
						{ "two", "{0} سنتيمتر" },
						{ "few", "{0} سنتيمتر" },
						{ "many", "{0} سنتيمتر" },
						{ "other", "{0} سنتيمتر" },
						{ "gender", "masculine" }
					}
				},
				{
					"mm",
					new Dictionary<string, string>
					{
						{ "zero", "{0} مليمتر" },
						{ "one", "{0} مليمتر" },
						{ "two", "{0} مليمتر" },
						{ "few", "{0} مليمتر" },
						{ "many", "{0} مليمتر" },
						{ "other", "{0} مليمتر" },
						{ "gender", "masculine" }
					}
				},
				{
					"L",
					new Dictionary<string, string>
					{
						{ "zero", "{0} لتر" },
						{ "one", "لتر" },
						{ "two", "{0} لتر" },
						{ "few", "{0} لتر" },
						{ "many", "{0} لتر" },
						{ "other", "{0} لتر" },
						{ "gender", "masculine" }
					}
				},
				{
					"ml",
					new Dictionary<string, string>
					{
						{ "zero", "{0} مليلتر" },
						{ "one", "{0} مليلتر" },
						{ "two", "{0} مليلتر" },
						{ "few", "{0} مليلتر" },
						{ "many", "{0} مليلتر" },
						{ "other", "{0} مليلتر" },
						{ "gender", "masculine" }
					}
				},
				{
					"°C",
					new Dictionary<string, string>
					{
						{ "zero", "{0} درجة مئوية" },
						{ "one", "{0} درجة مئوية" },
						{ "two", "{0} درجة مئوية" },
						{ "few", "{0} درجة مئوية" },
						{ "many", "{0} درجة مئوية" },
						{ "other", "{0} درجة مئوية" },
						{ "gender", "feminine" }
					}
				},
				{
					"°F",
					new Dictionary<string, string>
					{
						{ "zero", "{0} درجة فهرنهايت" },
						{ "one", "{0} درجة فهرنهايت" },
						{ "two", "{0} درجة فهرنهايت" },
						{ "few", "{0} درجة فهرنهايت" },
						{ "many", "{0} درجة فهرنهايت" },
						{ "other", "{0} درجة فهرنهايت" },
						{ "gender", "" }
					}
				},
				{
					"h",
					new Dictionary<string, string>
					{
						{ "zero", "{0} ساعة" },
						{ "one", "ساعة" },
						{ "two", "ساعتان" },
						{ "few", "{0} ساعات" },
						{ "many", "{0} ساعة" },
						{ "other", "{0} ساعة" },
						{ "gender", "feminine" }
					}
				},
				{
					"min",
					new Dictionary<string, string>
					{
						{ "zero", "{0} دقيقة" },
						{ "one", "دقيقة" },
						{ "two", "دقيقتان" },
						{ "few", "{0} دقائق" },
						{ "many", "{0} دقيقة" },
						{ "other", "{0} دقيقة" },
						{ "gender", "feminine" }
					}
				},
				{
					"s",
					new Dictionary<string, string>
					{
						{ "zero", "{0} ثانية" },
						{ "one", "ثانية" },
						{ "two", "ثانيتان" },
						{ "few", "{0} ثوان" },
						{ "many", "{0} ثانية" },
						{ "other", "{0} ثانية" },
						{ "gender", "feminine" }
					}
				},
				{
					"day",
					new Dictionary<string, string>
					{
						{ "zero", "{0} يوم" },
						{ "one", "يوم" },
						{ "two", "يومان" },
						{ "few", "{0} أيام" },
						{ "many", "{0} يوم\u064bا" },
						{ "other", "{0} يوم" },
						{ "gender", "masculine" }
					}
				},
				{
					"month",
					new Dictionary<string, string>
					{
						{ "zero", "{0} شهر" },
						{ "one", "شهر" },
						{ "two", "شهران" },
						{ "few", "{0} أشهر" },
						{ "many", "{0} شهر\u064bا" },
						{ "other", "{0} شهر" },
						{ "gender", "masculine" }
					}
				},
				{
					"year",
					new Dictionary<string, string>
					{
						{ "zero", "{0} سنة" },
						{ "one", "سنة" },
						{ "two", "سنتان" },
						{ "few", "{0} سنوات" },
						{ "many", "{0} سنة" },
						{ "other", "{0} سنة" },
						{ "gender", "feminine" }
					}
				},
				{
					"%",
					new Dictionary<string, string> { { "other", "{0} بالمائة" } }
				},
				{
					"‰",
					new Dictionary<string, string>
					{
						{ "zero", "{0} في الألف" },
						{ "one", "{0} في الألف" },
						{ "two", "{0} في الألف" },
						{ "few", "{0} في الألف" },
						{ "many", "{0} في الألف" },
						{ "other", "{0} في الألف" },
						{ "gender", "masculine" }
					}
				},
				{
					"°",
					new Dictionary<string, string> { { "other", "{0} درجة" } }
				},
				{
					"ms",
					new Dictionary<string, string>
					{
						{ "zero", "{0} ملي ثانية" },
						{ "one", "{0} ملي ثانية" },
						{ "two", "{0} ملي ثانية" },
						{ "few", "{0} ملي ثانية" },
						{ "many", "{0} ملي ثانية" },
						{ "other", "{0} ملي ثانية" },
						{ "gender", "feminine" }
					}
				},
				{
					"USD",
					new Dictionary<string, string>
					{
						{ "other", "{0} دولار أمريكي" },
						{ "gender", "masculine" }
					}
				},
				{
					"EUR",
					new Dictionary<string, string>
					{
						{ "other", "{0} يورو" },
						{ "gender", "masculine" }
					}
				},
				{
					"GBP",
					new Dictionary<string, string>
					{
						{ "other", "{0} جنيه إسترليني" },
						{ "gender", "masculine" }
					}
				},
				{
					"JPY",
					new Dictionary<string, string>
					{
						{ "other", "{0} ين ياباني" },
						{ "gender", "masculine" }
					}
				},
				{
					"CNY",
					new Dictionary<string, string>
					{
						{ "other", "{0} يوان صيني" },
						{ "gender", "masculine" }
					}
				},
				{
					"SEK",
					new Dictionary<string, string>
					{
						{ "other", "{0} كرونة سويدية" },
						{ "gender", "feminine" }
					}
				},
				{
					"DKK",
					new Dictionary<string, string>
					{
						{ "other", "{0} كرونة دنماركية" },
						{ "gender", "feminine" }
					}
				},
				{
					"NOK",
					new Dictionary<string, string>
					{
						{ "other", "{0} كرونة نرويجية" },
						{ "gender", "feminine" }
					}
				},
				{
					"PLN",
					new Dictionary<string, string>
					{
						{ "other", "{0} زلوتي بولندي" },
						{ "gender", "masculine" }
					}
				},
				{
					"RUB",
					new Dictionary<string, string>
					{
						{ "other", "{0} روبل روسي" },
						{ "gender", "masculine" }
					}
				},
				{
					"UAH",
					new Dictionary<string, string>
					{
						{ "other", "{0} هريفنيا أوكراني" },
						{ "gender", "feminine" }
					}
				},
				{
					"TRY",
					new Dictionary<string, string>
					{
						{ "other", "{0} ليرة تركية" },
						{ "gender", "feminine" }
					}
				},
				{
					"KRW",
					new Dictionary<string, string>
					{
						{ "other", "{0} وون كوريا الجنوبية" },
						{ "gender", "masculine" }
					}
				},
				{
					"THB",
					new Dictionary<string, string>
					{
						{ "other", "{0} باخت تايلاندي" },
						{ "gender", "masculine" }
					}
				},
				{
					"BRL",
					new Dictionary<string, string>
					{
						{ "other", "{0} ريال برازيلي" },
						{ "gender", "masculine" }
					}
				}
			}
		};
		Language language = dictionary["es"];
		dictionary["es-ES"] = new Language
		{
			code = "es-ES",
			decimalMark = language.decimalMark,
			groupMark = language.groupMark,
			letters = language.letters,
			datePattern = language.datePattern,
			months = language.months,
			days = language.days,
			terms = language.terms,
			readings = language.readings,
			abbreviations = language.abbreviations,
			measures = language.measures
		};
		return dictionary;
	}
}
