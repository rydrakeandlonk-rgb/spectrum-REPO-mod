using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using Photon.Pun;
using TMPro;
using UnityEngine;
using UnityEngine.Events;
using UnityEngine.UI;

public class TruckScreenText : MonoBehaviour
{
	public enum ScreenType
	{
		TruckScreen,
		TruckLobbyScreen,
		TruckShopScreen
	}

	public enum TruckScreenPage
	{
		Start,
		EndNotEnough,
		EndEnough,
		AllPlayersInTruck
	}

	public enum LobbyScreenPage
	{
		Start,
		FailFirst,
		FailSecond,
		FailThird,
		HitRoad
	}

	public enum ShopScreenPage
	{
		Start,
		NotEnough,
		Enough,
		Stealing,
		AllPlayersInTruck
	}

	public enum PlayerChatBoxState
	{
		Idle,
		Typing,
		LockedDestroySlackers,
		LockedStartingTruck
	}

	[Serializable]
	public class CustomEmojiSounds
	{
		public string emojiString;

		public Sound emojiSound;
	}

	[Serializable]
	public class TextLine
	{
		public string messageName;

		[Multiline]
		public List<string> textLines = new List<string>();

		public bool customSoundEffects;

		public bool customEvents;

		public bool customRevealSettings;

		public Sound customMessageSoundEffect;

		public Sound customTypingSoundEffect;

		public UnityEvent onLineStart;

		public UnityEvent onLineEnd;

		public ScreenTextRevealDelaySettings typingSpeed;

		[HideInInspector]
		public float letterRevealDelay;

		public ScreenNextMessageDelaySettings messageDelayTime;

		[HideInInspector]
		public float delayAfter;

		[HideInInspector]
		public string text;

		[HideInInspector]
		public string textOriginal;
	}

	[Serializable]
	public class TextPages
	{
		public string pageName;

		public List<TextLine> textLines = new List<TextLine>();

		public bool goToNextPageAutomatically;
	}

	public ScreenTextRevealDelaySettings textRevealNormalSetting;

	public ScreenNextMessageDelaySettings nextMessageDelayNormalSetting;

	public GameObject staticGrabCollider;

	public static TruckScreenText instance;

	private StaticGrabObject staticGrabObject;

	public ScreenType screenType;

	public string chatMessageString;

	public TextMeshProUGUI chatMessage;

	public UnityEvent onChatMessage;

	private float chatMessageTimer;

	private float chatMessageTimerMax = 2f;

	private bool chatActive;

	private PhotonView photonView;

	private int chatCharacterIndex;

	private float chatDeactivatedTimer;

	private string nicknameTaxman;

	private string currentNickname = "";

	private bool screenActive;

	private int nextPageOverride = -1;

	public Transform chatMessageLoadingBar;

	public Transform chatMessageResultBar;

	public Light chatMessageResultBarLight;

	internal float chatMessageResultBarTimer;

	private float chatActiveTimer;

	private bool selfDestructingPlayers;

	private TuckScreenLocked truckScreenLocked;

	public LocalizedAsset destroyingSlackersLocalized;

	public LocalizedAsset startingEngineLocalized;

	public LocalizedAsset hittingTheRoadLocalized;

	private string chatMessageIdleString1 = "<sprite name=message>";

	private string chatMessageIdleString2 = "<sprite name=message_arrow>";

	private string chatMessageIdleStringCurrent = "<sprite name=message>";

	private float chatMessageIdleStringTimer;

	internal PlayerChatBoxState playerChatBoxState;

	private bool playerChatBoxStateStart;

	public List<CustomEmojiSounds> customEmojiSounds = new List<CustomEmojiSounds>();

	public Sound typingSound;

	public Sound emojiSound;

	public Sound newLineSound;

	public Sound newPageSound;

	public Sound chargeChatLoop;

	public Sound chatMessageResultSuccess;

	public Sound chatMessageResultFail;

	public RawImage background;

	public Color mainBackgroundColor = new Color(0.6f, 0.6f, 0.6f, 1f);

	public Color offBackgroundColor = new Color(0f, 0f, 0f, 1f);

	public Color evilBackgroundColor = new Color(0.5f, 0f, 0f, 1f);

	public Color transitionBackgroundColor = new Color(0.5f, 0.5f, 0f, 1f);

	private float arrowPointAtGoalTimer;

	private float engineSoundTimer;

	public Transform engineSoundTransform;

	public Sound engineRevSound;

	public Sound engineSuccessSound;

	public TextMeshProUGUI textMesh;

	public string testingText;

	public List<TextPages> pages = new List<TextPages>();

	private int currentPageIndex;

	private int currentLineIndex;

	private int currentCharIndex;

	private float typingTimer;

	internal float delayTimer;

	internal bool isTyping;

	private float backgroundColorChangeTimer;

	private float backgroundColorChangeDuration = 0.5f;

	private float startWaitTimer;

	private bool started;

	private bool lobbyStarted;

	[RuntimeInitializeOnLoadMethod(/*Could not decode attribute arguments.*/)]
	private static void RuntimeInitializeOnLoad()
	{
		instance = null;
	}

	private void Awake()
	{
		instance = this;
		string newName = (((Component)this).GetComponent<LocalizationChangedEvent>()?.GetLocalizedAsset())?.GetLocalizedString() ?? "Taxman";
		UpdateTaxmanNickname(newName);
	}

	private void Start()
	{
		truckScreenLocked = ((Component)this).GetComponentInChildren<TuckScreenLocked>();
		staticGrabObject = ((Component)this).GetComponent<StaticGrabObject>();
		foreach (TextPages page in pages)
		{
			foreach (TextLine textLine in page.textLines)
			{
				if (Object.op_Implicit((Object)(object)textLine.typingSpeed))
				{
					textLine.letterRevealDelay = textLine.typingSpeed.GetDelay();
				}
				else
				{
					textLine.letterRevealDelay = textRevealNormalSetting.GetDelay();
				}
				if (Object.op_Implicit((Object)(object)textLine.messageDelayTime))
				{
					textLine.delayAfter = textLine.messageDelayTime.GetDelay();
				}
				else
				{
					textLine.delayAfter = nextMessageDelayNormalSetting.GetDelay();
				}
			}
		}
		screenActive = true;
		if ((Object)(object)textMesh == (Object)null)
		{
			Debug.LogError((object)"TextMeshProUGUI component is not assigned.");
		}
		photonView = ((Component)this).GetComponent<PhotonView>();
		currentNickname = nicknameTaxman;
		chatMessageString = SemiFunc.EmojiText(chatMessageString);
	}

	public void UpdateTaxmanNickname(string newName)
	{
		string text = nicknameTaxman;
		nicknameTaxman = "\n\n<color=#4d0000ff><b>" + newName + ":</b></color>\n";
		if (text != null)
		{
			((TMP_Text)textMesh).text = ((TMP_Text)textMesh).text.Replace(text, nicknameTaxman);
		}
	}

	private void LobbyScreenStartLogic()
	{
		if (lobbyStarted)
		{
			return;
		}
		if (SemiFunc.IsMasterClientOrSingleplayer() && screenType == ScreenType.TruckLobbyScreen && RunManager.instance.levelFailed)
		{
			if (RunManager.instance.runLives == 2)
			{
				GotoPage(1);
			}
			if (RunManager.instance.runLives == 1)
			{
				GotoPage(2);
			}
			if (RunManager.instance.runLives == 0)
			{
				GotoPage(3);
			}
		}
		lobbyStarted = true;
	}

	public void TutorialFinish()
	{
		GameDirector.instance.OutroStart();
		NetworkManager.instance.leavePhotonRoom = true;
	}

	public void ArrowPointAtGoal()
	{
		arrowPointAtGoalTimer = 4f;
	}

	private void ArrowPointAtGoalLogic()
	{
		//IL_002d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0041: Unknown result type (might be due to invalid IL or missing references)
		if (arrowPointAtGoalTimer > 0f)
		{
			if (PlayerAvatar.instance.RoomVolumeCheck.inTruck)
			{
				SemiFunc.UIShowArrow(new Vector3(340f, 90f, 0f), new Vector3(610f, 330f, 0f), 45f);
			}
			arrowPointAtGoalTimer -= Time.deltaTime;
		}
	}

	private void ChatMessageIdleStringTick()
	{
		if (chatActive)
		{
			return;
		}
		if (chatMessageIdleStringTimer < 1f)
		{
			chatMessageIdleStringTimer += Time.deltaTime;
			return;
		}
		if (chatMessageIdleStringCurrent == chatMessageIdleString1)
		{
			chatMessageIdleStringCurrent = chatMessageIdleString2;
		}
		else
		{
			chatMessageIdleStringCurrent = chatMessageIdleString1;
		}
		((TMP_Text)chatMessage).text = chatMessageIdleStringCurrent;
		chatMessageIdleStringTimer = 0f;
	}

	private void PlayerSelfDestruction()
	{
		if (!SemiFunc.PerSecond(5f, (Object)(object)this) || !selfDestructingPlayers)
		{
			return;
		}
		bool flag = true;
		foreach (PlayerAvatar item in SemiFunc.PlayerGetList())
		{
			if (!item.isDisabled)
			{
				if (item.RoomVolumeCheck.inTruck && !item.selfDestructPrevented)
				{
					item.selfDestructPrevented = true;
				}
				else if (!item.selfDestructPrevented)
				{
					flag = false;
				}
			}
		}
		if (flag)
		{
			ChatMessageResultSuccess();
			PlayerChatBoxStateUpdate(PlayerChatBoxState.LockedStartingTruck);
			GotoPage(2);
			selfDestructingPlayers = false;
		}
	}

	private void Update()
	{
		//IL_0038: Unknown result type (might be due to invalid IL or missing references)
		//IL_0059: Unknown result type (might be due to invalid IL or missing references)
		//IL_0069: Unknown result type (might be due to invalid IL or missing references)
		//IL_0073: Unknown result type (might be due to invalid IL or missing references)
		PlayerChatBoxStateMachine();
		PlayerSelfDestruction();
		ChatMessageResultTick();
		ChatMessageIdleStringTick();
		HoldChat();
		float num = chatMessageTimer / chatMessageTimerMax;
		chatMessageLoadingBar.localScale = new Vector3(Mathf.Lerp(chatMessageLoadingBar.localScale.x, num, Time.deltaTime * 10f), chatMessageLoadingBar.localScale.y, chatMessageLoadingBar.localScale.z);
		if (chatActive)
		{
			chatActiveTimer = 0.2f;
		}
		else
		{
			chatActiveTimer -= Time.deltaTime;
			if (chatActiveTimer <= 0f)
			{
				chatMessageTimer = 0f;
			}
		}
		if (SemiFunc.IsMasterClientOrSingleplayer() && !started && GameDirector.instance.currentState == GameDirector.gameState.Main)
		{
			if (startWaitTimer < 1f)
			{
				startWaitTimer += Time.deltaTime;
			}
			else
			{
				InitializeTextTyping();
				LobbyScreenStartLogic();
			}
		}
		if (started)
		{
			UpdateBackgroundColor();
			if (isTyping)
			{
				TypingUpdate();
			}
			else
			{
				DelayUpdate();
			}
			CheckTextMeshLines();
			ArrowPointAtGoalLogic();
		}
	}

	private void InitializeTextTypingLogic()
	{
		((TMP_Text)textMesh).text = "";
		currentPageIndex = 0;
		currentLineIndex = 0;
		currentCharIndex = 0;
		typingTimer = 0f;
		foreach (TextPages page in pages)
		{
			foreach (TextLine textLine in page.textLines)
			{
				if (textLine.textLines.Count > 0)
				{
					textLine.text = textLine.textLines[0];
				}
				else
				{
					textLine.text = "Missing line!!";
				}
				textLine.text = SemiFunc.EmojiText(textLine.text);
				textLine.textOriginal = textLine.text;
			}
		}
		started = true;
		NextLine(currentLineIndex);
	}

	private void InitializeTextTyping()
	{
		if (GameManager.instance.gameMode == 0)
		{
			InitializeTextTypingLogic();
		}
		else if (PhotonNetwork.IsMasterClient)
		{
			photonView.RPC("InitializeTextTypingRPC", (RpcTarget)0, Array.Empty<object>());
		}
	}

	[PunRPC]
	public void InitializeTextTypingRPC(PhotonMessageInfo _info = default(PhotonMessageInfo))
	{
		//IL_0000: Unknown result type (might be due to invalid IL or missing references)
		if (SemiFunc.MasterOnlyRPC(_info))
		{
			InitializeTextTypingLogic();
		}
	}

	private void CheckTextMeshLines()
	{
		if (((TMP_Text)textMesh).textInfo.lineCount > 12)
		{
			int num = ((TMP_Text)textMesh).text.IndexOf('\n');
			if (num != -1)
			{
				((TMP_Text)textMesh).text = ((TMP_Text)textMesh).text.Substring(num + 1);
			}
		}
	}

	private void ChatMessageResultSuccess()
	{
		//IL_0011: Unknown result type (might be due to invalid IL or missing references)
		//IL_0021: Unknown result type (might be due to invalid IL or missing references)
		//IL_002b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0052: Unknown result type (might be due to invalid IL or missing references)
		//IL_008b: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b4: Unknown result type (might be due to invalid IL or missing references)
		chatMessageLoadingBar.localScale = new Vector3(0f, chatMessageLoadingBar.localScale.y, chatMessageLoadingBar.localScale.z);
		((Component)chatMessageResultBar).gameObject.SetActive(true);
		chatMessageResultSuccess.Play(chatMessageResultBar.position);
		chatMessageResultBarLight.color = new Color(0f, 1f, 0f, 1f);
		((Graphic)((Component)chatMessageResultBar).GetComponent<RawImage>()).color = new Color(0f, 1f, 0f, 1f);
		chatMessageResultBarTimer = 0.2f;
	}

	private void ChatMessageResultFail()
	{
		//IL_0011: Unknown result type (might be due to invalid IL or missing references)
		//IL_0021: Unknown result type (might be due to invalid IL or missing references)
		//IL_002b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0052: Unknown result type (might be due to invalid IL or missing references)
		//IL_008b: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b4: Unknown result type (might be due to invalid IL or missing references)
		chatMessageLoadingBar.localScale = new Vector3(0f, chatMessageLoadingBar.localScale.y, chatMessageLoadingBar.localScale.z);
		((Component)chatMessageResultBar).gameObject.SetActive(true);
		chatMessageResultFail.Play(chatMessageResultBar.position);
		chatMessageResultBarLight.color = new Color(1f, 0f, 0f, 1f);
		((Graphic)((Component)chatMessageResultBar).GetComponent<RawImage>()).color = new Color(1f, 0f, 0f, 1f);
		chatMessageResultBarTimer = 0.2f;
	}

	private void ChatMessageResultTick()
	{
		if (chatMessageResultBarTimer > 0f)
		{
			chatMessageResultBarTimer -= Time.deltaTime;
		}
		else if (chatMessageResultBarTimer != -123f)
		{
			((Component)chatMessageResultBar).gameObject.SetActive(false);
			chatMessageResultBarTimer = -123f;
		}
	}

	public void ChatMessageLevel()
	{
		if (RoundDirector.instance.extractionPointsCompleted == RoundDirector.instance.extractionPoints)
		{
			if (SemiFunc.PlayersAllInTruck())
			{
				ChatMessageResultSuccess();
				PlayerChatBoxStateUpdate(PlayerChatBoxState.LockedStartingTruck);
				GotoPage(2);
			}
			else
			{
				ChatMessageResultFail();
				PlayerChatBoxStateUpdate(PlayerChatBoxState.LockedDestroySlackers);
				GotoPage(3);
			}
		}
		else
		{
			ChatMessageResultFail();
			GotoPage(1);
		}
	}

	public void ChatMessageLobby()
	{
		ChatMessageResultSuccess();
		PlayerChatBoxStateUpdate(PlayerChatBoxState.LockedStartingTruck);
		GotoPage(4);
	}

	public void ChatMessageTutorial()
	{
		PlayerChatBoxStateUpdate(PlayerChatBoxState.LockedStartingTruck);
		ChatMessageResultSuccess();
		GotoPage(2);
	}

	public void ChatMessageShop()
	{
		if (SemiFunc.PlayersAllInTruck())
		{
			ChatMessageResultSuccess();
			PlayerChatBoxStateUpdate(PlayerChatBoxState.LockedStartingTruck);
			GotoPage(2);
		}
		else
		{
			ChatMessageResultFail();
			PlayerChatBoxStateUpdate(PlayerChatBoxState.LockedDestroySlackers);
			GotoPage(4);
		}
	}

	private void OnValidate()
	{
		if (!SemiFunc.OnValidateCheck())
		{
			((TMP_Text)textMesh).text = SemiFunc.EmojiText(testingText);
		}
	}

	private void ReplaceStringWithVariable(string variableString, string variableValueString, TextLine currentLine)
	{
		currentLine.text = currentLine.text.Remove(currentCharIndex, variableString.Length - 1);
		currentLine.text = currentLine.text.Insert(currentCharIndex + 1, variableValueString);
	}

	private void TypingUpdate()
	{
		//IL_075e: Unknown result type (might be due to invalid IL or missing references)
		//IL_072c: Unknown result type (might be due to invalid IL or missing references)
		if (!screenActive || currentPageIndex >= pages.Count)
		{
			return;
		}
		TextPages textPages = pages[currentPageIndex];
		if (currentLineIndex >= textPages.textLines.Count)
		{
			return;
		}
		TextLine textLine = textPages.textLines[currentLineIndex];
		if (currentCharIndex >= textLine.text.Length)
		{
			return;
		}
		if (currentCharIndex == 0 && typingTimer == 0f)
		{
			if (currentLineIndex != 0)
			{
				((TMP_Text)textMesh).text = ((TMP_Text)textMesh).text;
			}
			((TMP_Text)textMesh).text = ((TMP_Text)textMesh).text + currentNickname;
			NewLineSoundEffect();
		}
		typingTimer += Time.deltaTime;
		if (!(typingTimer >= textLine.letterRevealDelay))
		{
			return;
		}
		string emojiString = "";
		bool flag = false;
		int i = currentCharIndex;
		if (textLine.text[i] == '<')
		{
			for (; textLine.text[i] != '>'; i++)
			{
				emojiString += textLine.text[i];
			}
			flag = true;
		}
		if (flag)
		{
			TextMeshProUGUI val = textMesh;
			((TMP_Text)val).text = ((TMP_Text)val).text + emojiString;
			currentCharIndex = i;
		}
		string text = "";
		int num = 0;
		bool flag2 = false;
		if (textLine.text[currentCharIndex] == '[')
		{
			flag2 = true;
			int num2 = currentCharIndex;
			int num3 = num;
			while (textLine.text[currentCharIndex] != ']')
			{
				text += textLine.text[currentCharIndex];
				currentCharIndex++;
				num++;
				if (currentCharIndex >= textLine.text.Length)
				{
					flag2 = false;
					currentCharIndex = num2;
					num = num3;
					break;
				}
			}
			text += textLine.text[currentCharIndex];
			currentCharIndex++;
			num++;
			currentCharIndex -= num;
			if (text == "[haul]")
			{
				int num4 = RoundDirector.instance.extractionPointsCompleted;
				if (num4 == RoundDirector.instance.extractionPoints && playerChatBoxState != PlayerChatBoxState.LockedStartingTruck)
				{
					num4 = RoundDirector.instance.extractionPoints - 1;
				}
				string text2 = " <color=#FFAA00>" + num4 + "</color><color=#3F2B00> / </color><color=#FFAA00>" + RoundDirector.instance.extractionPoints + "</color> ";
				text2 += "<sprite name=extraction>";
				ReplaceStringWithVariable(text, text2, textLine);
				if (!Object.op_Implicit((Object)(object)RoundDirector.instance.extractionPointCurrent) && RoundDirector.instance.extractionPointsCompleted > 0 && RoundDirector.instance.extractionPoints > 1 && RoundDirector.instance.extractionPointsCompleted != RoundDirector.instance.extractionPoints)
				{
					TutorialDirector.instance.ActivateTip("Multiple Extractions", 0f, _interrupt: true);
				}
			}
			if (text == "[goal]")
			{
				int haulGoal = RoundDirector.instance.haulGoal;
				string valueString = haulGoal.ToString();
				valueString = FormatDollarValueStrings(valueString);
				ReplaceStringWithVariable(text, valueString, textLine);
			}
			if (text == "[goalmax]")
			{
				string valueString2 = RoundDirector.instance.haulGoalMax.ToString();
				valueString2 = FormatDollarValueStrings(valueString2);
				ReplaceStringWithVariable(text, valueString2, textLine);
			}
			if (text == "[hitroad]")
			{
				if (currentNickname == nicknameTaxman)
				{
					chatMessageString = chatMessageString.Replace("?", "!");
				}
				ReplaceStringWithVariable(text, chatMessageString, textLine);
				currentNickname = nicknameTaxman;
			}
			if (text == "[allplayerintruck]")
			{
				List<string> list = new List<string>();
				foreach (PlayerAvatar player in GameDirector.instance.PlayerList)
				{
					if (!player.isDisabled && !player.RoomVolumeCheck.inTruck)
					{
						list.Add(player.playerName);
					}
				}
				string text3 = "";
				for (int j = 0; j < list.Count; j++)
				{
					if (j != 0)
					{
						text3 = ((j != list.Count - 1) ? (text3 + ", " + list[j]) : (text3 + " & " + list[j]));
					}
					else
					{
						text3 += list[j];
					}
				}
				text3 += "...<sprite name=fedup>";
				text3 += "\n";
				text3 += SemiFunc.EmojiText("{pointright}{truck}{pointleft}");
				ReplaceStringWithVariable(text, text3, textLine);
			}
			if (text == "[betrayplayers]")
			{
				List<string> list2 = new List<string>();
				foreach (PlayerAvatar player2 in GameDirector.instance.PlayerList)
				{
					if (!player2.isDisabled && !player2.RoomVolumeCheck.inTruck)
					{
						list2.Add(player2.playerName);
					}
				}
				string text4 = "";
				for (int k = 0; k < list2.Count; k++)
				{
					if (k != 0)
					{
						text4 = ((k != list2.Count - 1) ? (text4 + ", " + list2[k]) : (text4 + " & " + list2[k]));
					}
					else
					{
						text4 += list2[k];
					}
				}
				text4 += "... <sprite name=fedup>";
				text4 += "\n";
				text4 += SemiFunc.EmojiText("{pointright}{truck}{pointleft}");
				ReplaceStringWithVariable(text, text4, textLine);
			}
		}
		if (!flag2)
		{
			TextMeshProUGUI val2 = textMesh;
			((TMP_Text)val2).text = ((TMP_Text)val2).text + textLine.text[currentCharIndex];
		}
		if (flag)
		{
			emojiString += textLine.text[currentCharIndex];
		}
		if (textLine.text[currentCharIndex] != ' ')
		{
			if (!flag)
			{
				TypeSoundEffect();
			}
			else if (customEmojiSounds.Any((CustomEmojiSounds x) => x.emojiString == emojiString))
			{
				customEmojiSounds.Find((CustomEmojiSounds x) => x.emojiString == emojiString).emojiSound.Play(((TMP_Text)textMesh).transform.position);
			}
			else
			{
				emojiSound.Play(((TMP_Text)textMesh).transform.position);
			}
		}
		currentCharIndex++;
		typingTimer = 0f;
		if (currentCharIndex >= textLine.text.Length)
		{
			((TMP_Text)textMesh).text = ((TMP_Text)textMesh).text;
			isTyping = false;
			delayTimer = 0f;
		}
	}

	private void UpdateBackgroundColor()
	{
		//IL_0042: Unknown result type (might be due to invalid IL or missing references)
		//IL_0030: Unknown result type (might be due to invalid IL or missing references)
		if (backgroundColorChangeTimer < backgroundColorChangeDuration)
		{
			backgroundColorChangeTimer += Time.deltaTime;
		}
		else if (screenActive)
		{
			((Graphic)background).color = mainBackgroundColor;
		}
		else
		{
			((Graphic)background).color = offBackgroundColor;
		}
	}

	private void DelayUpdate()
	{
		if (!SemiFunc.IsMasterClientOrSingleplayer() || currentLineIndex >= pages[currentPageIndex].textLines.Count)
		{
			return;
		}
		TextLine textLine = pages[currentPageIndex].textLines[currentLineIndex];
		delayTimer += Time.deltaTime;
		if (!(delayTimer >= textLine.delayAfter))
		{
			return;
		}
		UnityEvent onLineEnd = pages[currentPageIndex].textLines[currentLineIndex].onLineEnd;
		if (onLineEnd != null)
		{
			onLineEnd.Invoke();
		}
		currentLineIndex++;
		if ((currentLineIndex >= pages[currentPageIndex].textLines.Count && pages[currentPageIndex].goToNextPageAutomatically) || nextPageOverride != -1)
		{
			if (nextPageOverride != -1)
			{
				GotoPage(nextPageOverride);
				nextPageOverride = -1;
			}
			else
			{
				GotoPage(currentPageIndex + 1);
			}
			currentLineIndex = 0;
			if (currentPageIndex >= pages.Count)
			{
				currentPageIndex = pages.Count;
			}
		}
		if (currentLineIndex < pages[currentPageIndex].textLines.Count)
		{
			NextLine(currentLineIndex);
		}
	}

	private void RestartTyping()
	{
		InitializeTextTyping();
	}

	private void TypeSoundEffect()
	{
		//IL_0090: Unknown result type (might be due to invalid IL or missing references)
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		if (pages[currentPageIndex].textLines[currentLineIndex].customTypingSoundEffect.Sounds.Length != 0)
		{
			pages[currentPageIndex].textLines[currentLineIndex].customTypingSoundEffect.Play(((TMP_Text)textMesh).transform.position);
		}
		else
		{
			typingSound.Play(((TMP_Text)textMesh).transform.position);
		}
	}

	private void NewLineSoundEffect()
	{
		//IL_0090: Unknown result type (might be due to invalid IL or missing references)
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		if (pages[currentPageIndex].textLines[currentLineIndex].customMessageSoundEffect.Sounds.Length != 0)
		{
			pages[currentPageIndex].textLines[currentLineIndex].customMessageSoundEffect.Play(((TMP_Text)textMesh).transform.position);
		}
		else
		{
			newLineSound.Play(((TMP_Text)textMesh).transform.position);
		}
	}

	public void StartChat()
	{
		if (screenActive)
		{
			if (GameManager.instance.gameMode == 0)
			{
				chatActive = true;
			}
			else
			{
				photonView.RPC("StartChatRPC", (RpcTarget)0, Array.Empty<object>());
			}
		}
	}

	[PunRPC]
	public void StartChatRPC(PhotonMessageInfo _info = default(PhotonMessageInfo))
	{
		//IL_0000: Unknown result type (might be due to invalid IL or missing references)
		if (SemiFunc.MasterOnlyRPC(_info))
		{
			chatActive = true;
		}
	}

	public void HoldChat()
	{
		//IL_02df: Unknown result type (might be due to invalid IL or missing references)
		//IL_02ad: Unknown result type (might be due to invalid IL or missing references)
		chargeChatLoop.LoopPitch = 1f + chatMessageTimer / chatMessageTimerMax;
		chargeChatLoop.PlayLoop(chatActive, 0.9f, 0.9f);
		if (!screenActive && chatActiveTimer <= 0f)
		{
			return;
		}
		if (chatDeactivatedTimer > 0f && chatActiveTimer <= 0f)
		{
			chatDeactivatedTimer -= Time.deltaTime;
		}
		else
		{
			if (!chatActive && chatActiveTimer <= 0f)
			{
				return;
			}
			if (playerChatBoxState != PlayerChatBoxState.Idle)
			{
				ForceReleaseChat();
				staticGrabCollider.SetActive(false);
				chatActive = false;
				return;
			}
			chatMessageTimer += 1.5f * Time.deltaTime;
			if (chatMessageTimer >= chatMessageTimerMax)
			{
				chatMessageTimer = 0f;
				chatActiveTimer = 0f;
				chatActive = false;
				if (staticGrabObject.playerGrabbing.Count <= 0)
				{
					return;
				}
				PhysGrabber physGrabber = staticGrabObject.playerGrabbing[0];
				if (Object.op_Implicit((Object)(object)physGrabber))
				{
					string playerName = physGrabber.playerAvatar.playerName;
					if (GameManager.instance.gameMode == 0)
					{
						ChatMessageSend(playerName);
					}
					else if (PhotonNetwork.IsMasterClient)
					{
						photonView.RPC("ChatMessageSendRPC", (RpcTarget)0, new object[1] { playerName });
					}
				}
				return;
			}
			int num = (int)(chatMessageTimer / chatMessageTimerMax * (float)chatMessageString.Length);
			num = Mathf.Min(num, chatMessageString.Length);
			bool flag = false;
			string emojiString = "";
			while (chatCharacterIndex < num)
			{
				if (chatMessageString[chatCharacterIndex] == '<')
				{
					flag = true;
					int num2 = chatMessageString.IndexOf('>', chatCharacterIndex);
					if (num2 != -1)
					{
						num = Mathf.Min(num + (num2 - chatCharacterIndex), chatMessageString.Length);
						chatCharacterIndex = num2 + 1;
					}
					else
					{
						chatCharacterIndex++;
						emojiString += chatMessageString[chatCharacterIndex];
					}
				}
				else
				{
					chatCharacterIndex++;
				}
				if (!flag)
				{
					TypeSoundEffect();
				}
				else if (customEmojiSounds.Any((CustomEmojiSounds x) => x.emojiString == emojiString))
				{
					customEmojiSounds.Find((CustomEmojiSounds x) => x.emojiString == emojiString).emojiSound.Play(((TMP_Text)textMesh).transform.position);
				}
				else
				{
					emojiSound.Play(((TMP_Text)textMesh).transform.position);
				}
				((TMP_Text)chatMessage).text = chatMessageString.Substring(0, chatCharacterIndex);
			}
		}
	}

	private void ForceReleaseChat()
	{
		if (staticGrabObject.playerGrabbing.Count <= 0)
		{
			return;
		}
		List<PhysGrabber> list = new List<PhysGrabber>();
		list.AddRange(staticGrabObject.playerGrabbing);
		foreach (PhysGrabber item in list)
		{
			if (!SemiFunc.IsMultiplayer())
			{
				item.ReleaseObject(photonView.ViewID);
			}
			else if (SemiFunc.IsMasterClient() && Object.op_Implicit((Object)(object)item.photonView) && item.photonView.Owner != null)
			{
				item.OverrideGrabRelease(photonView.ViewID, 0.1f);
			}
		}
	}

	private void NextLineLogic(int _lineIndex, int index)
	{
		if (currentPageIndex >= 0 && currentPageIndex < pages.Count && currentLineIndex >= 0 && currentLineIndex < pages[currentPageIndex].textLines.Count && index >= 0 && index < pages[currentPageIndex].textLines[currentLineIndex].textLines.Count)
		{
			UnityEvent onLineStart = pages[currentPageIndex].textLines[currentLineIndex].onLineStart;
			if (onLineStart != null)
			{
				onLineStart.Invoke();
			}
			pages[currentPageIndex].textLines[currentLineIndex].text = SemiFunc.EmojiText(pages[currentPageIndex].textLines[currentLineIndex].textLines[index]);
			currentCharIndex = 0;
			currentLineIndex = _lineIndex;
			isTyping = true;
			typingTimer = 0f;
			delayTimer = 0f;
		}
	}

	private void NextLine(int _currentLineIndex)
	{
		if (pages[currentPageIndex].textLines.Count != 0)
		{
			if (GameManager.instance.gameMode == 0)
			{
				int count = pages[currentPageIndex].textLines[currentLineIndex].textLines.Count;
				int index = Random.Range(0, count);
				NextLineLogic(_currentLineIndex, index);
			}
			else if (PhotonNetwork.IsMasterClient)
			{
				int count2 = pages[currentPageIndex].textLines[currentLineIndex].textLines.Count;
				int num = Random.Range(0, count2);
				photonView.RPC("NextLineRPC", (RpcTarget)0, new object[3] { num, _currentLineIndex, currentPageIndex });
			}
		}
	}

	[PunRPC]
	public void NextLineRPC(int index, int _currentLineIndex, int _pageIndex, PhotonMessageInfo _info = default(PhotonMessageInfo))
	{
		//IL_0000: Unknown result type (might be due to invalid IL or missing references)
		if (SemiFunc.MasterOnlyRPC(_info))
		{
			if (!SemiFunc.IsMasterClientOrSingleplayer())
			{
				currentPageIndex = _pageIndex;
				currentLineIndex = _currentLineIndex;
			}
			NextLineLogic(_currentLineIndex, index);
		}
	}

	private void ForceCompleteChatMessage()
	{
		int length = pages[currentPageIndex].textLines[currentLineIndex].text.Length;
		if (currentCharIndex <= length)
		{
			for (int i = currentCharIndex; i < length; i++)
			{
				TypingUpdate();
			}
			currentCharIndex = length;
			isTyping = false;
			typingTimer = 0f;
		}
		TypeSoundEffect();
	}

	private void ChatMessageSend(string playerName)
	{
		//IL_0006: Unknown result type (might be due to invalid IL or missing references)
		string text = ColorUtility.ToHtmlStringRGB(SemiFunc.PlayerGetColorMain(SemiFunc.PlayerGetFromName(playerName)));
		currentNickname = "\n\n<color=#" + text + "><b>" + playerName + ":</b></color>\n";
		onChatMessage.Invoke();
		chatDeactivatedTimer = 3f;
		((TMP_Text)chatMessage).text = "";
	}

	public void SelfDestructPlayersOutsideTruck()
	{
		//IL_000a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0010: Unknown result type (might be due to invalid IL or missing references)
		if (!SemiFunc.IsMultiplayer())
		{
			SelfDestructPlayersOutsideTruckRPC();
		}
		else if (PhotonNetwork.IsMasterClient)
		{
			photonView.RPC("SelfDestructPlayersOutsideTruckRPC", (RpcTarget)0, Array.Empty<object>());
		}
	}

	[PunRPC]
	public void SelfDestructPlayersOutsideTruckRPC(PhotonMessageInfo _info = default(PhotonMessageInfo))
	{
		//IL_0000: Unknown result type (might be due to invalid IL or missing references)
		if (SemiFunc.MasterOnlyRPC(_info))
		{
			selfDestructingPlayers = true;
			ChatManager.instance.PossessLeftBehind();
		}
	}

	[PunRPC]
	public void ChatMessageSendRPC(string playerName, PhotonMessageInfo _info = default(PhotonMessageInfo))
	{
		//IL_0000: Unknown result type (might be due to invalid IL or missing references)
		if (SemiFunc.MasterOnlyRPC(_info))
		{
			ChatMessageSend(playerName);
		}
	}

	public void GotoNextLevel()
	{
		EngineStartSound();
		RunManager.instance.ChangeLevel(_completedLevel: true, _levelFailed: false);
	}

	public void ShopCompleted()
	{
		((MonoBehaviour)this).StartCoroutine(ShopGotoNextLevel());
	}

	private void EngineStartSound()
	{
		//IL_0029: Unknown result type (might be due to invalid IL or missing references)
		//IL_002f: Unknown result type (might be due to invalid IL or missing references)
		if (SemiFunc.IsMasterClientOrSingleplayer())
		{
			if (SemiFunc.IsMultiplayer())
			{
				photonView.RPC("EngineStartRPC", (RpcTarget)0, Array.Empty<object>());
			}
			else
			{
				EngineStartRPC();
			}
		}
	}

	[PunRPC]
	public void EngineStartRPC(PhotonMessageInfo _info = default(PhotonMessageInfo))
	{
		//IL_0000: Unknown result type (might be due to invalid IL or missing references)
		//IL_001a: Unknown result type (might be due to invalid IL or missing references)
		if (SemiFunc.MasterOnlyRPC(_info))
		{
			engineSuccessSound.Play(((TMP_Text)textMesh).transform.position);
		}
	}

	public IEnumerator ShopGotoNextLevel()
	{
		yield return (object)new WaitForSeconds(0.5f);
		ExtractionPoint _extractionPoint = RoundDirector.instance.extractionPointCurrent;
		while (Object.op_Implicit((Object)(object)_extractionPoint) && _extractionPoint.ShopExtractionInProgress())
		{
			yield return null;
		}
		RunManager.instance.ChangeLevel(_completedLevel: true, _levelFailed: false);
	}

	private void PageTransitionEffect()
	{
		//IL_0007: Unknown result type (might be due to invalid IL or missing references)
		//IL_0038: Unknown result type (might be due to invalid IL or missing references)
		((Graphic)background).color = transitionBackgroundColor;
		backgroundColorChangeTimer = 0f;
		backgroundColorChangeDuration = 0.5f;
		newPageSound.Play(((TMP_Text)textMesh).transform.position);
	}

	public void GotoPage(int pageIndex)
	{
		if (GameManager.instance.gameMode == 0)
		{
			GotoPageLogic(pageIndex);
		}
		else if (PhotonNetwork.IsMasterClient)
		{
			photonView.RPC("GotoPageRPC", (RpcTarget)0, new object[1] { pageIndex });
		}
	}

	[PunRPC]
	public void MessageSendCustomRPC(string playerName, string message, PhotonMessageInfo _info = default(PhotonMessageInfo))
	{
		//IL_0014: Unknown result type (might be due to invalid IL or missing references)
		//IL_0143: Unknown result type (might be due to invalid IL or missing references)
		//IL_0043: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a5: Unknown result type (might be due to invalid IL or missing references)
		if (isTyping)
		{
			return;
		}
		bool flag = false;
		bool flag2 = false;
		if (GameManager.Multiplayer() && _info.Sender != PhotonNetwork.MasterClient)
		{
			flag = true;
			foreach (PlayerAvatar item in SemiFunc.PlayerGetList())
			{
				if (item.photonView.Owner == _info.Sender)
				{
					playerName = item.playerName;
				}
			}
		}
		if ((playerName != "") | flag)
		{
			foreach (PlayerAvatar item2 in SemiFunc.PlayerGetList())
			{
				if (item2.playerName == playerName)
				{
					string text = ColorUtility.ToHtmlStringRGB(SemiFunc.PlayerGetColorMain(SemiFunc.PlayerGetFromName(playerName)));
					currentNickname = "\n\n<color=#" + text + "><b>" + playerName + ":</b></color>\n";
					flag2 = true;
					break;
				}
			}
			if (!flag2)
			{
				return;
			}
		}
		else
		{
			currentNickname = nicknameTaxman;
		}
		TextMeshProUGUI val = textMesh;
		((TMP_Text)val).text = ((TMP_Text)val).text + currentNickname + SemiFunc.EmojiText(message);
		newLineSound.Play(((TMP_Text)textMesh).transform.position);
		currentNickname = nicknameTaxman;
	}

	public void MessageSendCustom(string playerName, string message, int emojis)
	{
		//IL_0166: Unknown result type (might be due to invalid IL or missing references)
		//IL_016c: Unknown result type (might be due to invalid IL or missing references)
		if (playerName != "")
		{
			List<string> list = new List<string> { "{:)}", "{:D}", "{:P}", "{eyes}", "{:o}", "{heart}" };
			List<string> list2 = new List<string> { "{:(}", "{:'(}", "{heartbreak}", "{fedup}" };
			string text = "";
			if (emojis != 0)
			{
				List<string> list3 = list;
				if (emojis == 1)
				{
					list3 = list;
				}
				if (emojis == 2)
				{
					list3 = list2;
				}
				text += list3[Random.Range(0, list3.Count)];
				if (Random.Range(0, 2) == 1)
				{
					text += list3[Random.Range(0, list3.Count)];
				}
				if (Random.Range(0, 5) == 1)
				{
					text += list3[Random.Range(0, list3.Count)];
				}
				if (Random.Range(0, 30) == 1)
				{
					text = list3[Random.Range(0, list3.Count)];
					text += text;
					text += text;
				}
			}
			message += text;
		}
		if (SemiFunc.IsMultiplayer())
		{
			photonView.RPC("MessageSendCustomRPC", (RpcTarget)0, new object[2] { playerName, message });
		}
		else
		{
			MessageSendCustomRPC(playerName, message);
		}
	}

	private void GotoPageLogic(int pageIndex)
	{
		currentPageIndex = pageIndex;
		currentLineIndex = 0;
		currentCharIndex = 0;
		typingTimer = 0f;
		isTyping = true;
		foreach (TextPages page in pages)
		{
			foreach (TextLine textLine in page.textLines)
			{
				textLine.text = textLine.textOriginal;
			}
		}
		NextLine(currentLineIndex);
	}

	[PunRPC]
	public void GotoPageRPC(int pageIndex, PhotonMessageInfo _info = default(PhotonMessageInfo))
	{
		//IL_0000: Unknown result type (might be due to invalid IL or missing references)
		if (SemiFunc.MasterOnlyRPC(_info))
		{
			GotoPageLogic(pageIndex);
		}
	}

	public void ReleaseChat()
	{
		//IL_000f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0015: Unknown result type (might be due to invalid IL or missing references)
		if (GameManager.instance.gameMode == 0)
		{
			ReleaseChatRPC();
		}
		else
		{
			photonView.RPC("ReleaseChatRPC", (RpcTarget)0, Array.Empty<object>());
		}
	}

	private string FormatDollarValueStrings(string valueString)
	{
		valueString = SemiFunc.DollarGetString(int.Parse(valueString));
		return valueString;
	}

	[PunRPC]
	public void ReleaseChatRPC(PhotonMessageInfo _info = default(PhotonMessageInfo))
	{
		//IL_0000: Unknown result type (might be due to invalid IL or missing references)
		if (SemiFunc.MasterOnlyRPC(_info))
		{
			chatActive = false;
			chatMessageTimer = 0f;
			chatCharacterIndex = 0;
			((TMP_Text)chatMessage).text = "";
		}
	}

	private void GotoPageAfterPageIsDone(int pageIndex)
	{
		nextPageOverride = pageIndex;
	}

	private void PlayerChatBoxStateUpdate(PlayerChatBoxState _state)
	{
		//IL_0033: Unknown result type (might be due to invalid IL or missing references)
		//IL_0039: Unknown result type (might be due to invalid IL or missing references)
		if (SemiFunc.IsMasterClientOrSingleplayer())
		{
			if (SemiFunc.IsMultiplayer())
			{
				photonView.RPC("PlayerChatBoxStateUpdateRPC", (RpcTarget)0, new object[1] { _state });
			}
			else
			{
				PlayerChatBoxStateUpdateRPC(_state);
			}
		}
	}

	public void PlayerChatBoxStateUpdateToLockedDestroySlackers()
	{
		PlayerChatBoxStateUpdate(PlayerChatBoxState.LockedDestroySlackers);
	}

	public void PlayerChatBoxStateUpdateToLockedStartingTruck()
	{
		PlayerChatBoxStateUpdate(PlayerChatBoxState.LockedStartingTruck);
	}

	[PunRPC]
	private void PlayerChatBoxStateUpdateRPC(PlayerChatBoxState _state, PhotonMessageInfo _info = default(PhotonMessageInfo))
	{
		//IL_0000: Unknown result type (might be due to invalid IL or missing references)
		if (SemiFunc.MasterOnlyRPC(_info))
		{
			playerChatBoxState = _state;
			playerChatBoxStateStart = true;
		}
	}

	private void PlayerChatBoxStateIdle()
	{
		//IL_0016: Unknown result type (might be due to invalid IL or missing references)
		//IL_001c: Unknown result type (might be due to invalid IL or missing references)
		//IL_001f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0025: Unknown result type (might be due to invalid IL or missing references)
		if (playerChatBoxStateStart)
		{
			truckScreenLocked.LockChatToggle(_lock: false);
			staticGrabCollider.SetActive(true);
			playerChatBoxStateStart = false;
		}
	}

	private void PlayerChatBoxStateLockedStartingTruck()
	{
		//IL_0027: Unknown result type (might be due to invalid IL or missing references)
		//IL_0042: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ed: Unknown result type (might be due to invalid IL or missing references)
		//IL_0092: Unknown result type (might be due to invalid IL or missing references)
		//IL_0093: Unknown result type (might be due to invalid IL or missing references)
		if (playerChatBoxStateStart)
		{
			ForceReleaseChat();
			Color darkColor = new Color(0.8f, 0.2f, 0.1f, 1f);
			Color lightColor = new Color(1f, 0.8f, 0f, 1f);
			string lockedText = ((!SemiFunc.RunIsLobby()) ? (startingEngineLocalized?.GetLocalizedString() ?? "STARTING ENGINE") : (hittingTheRoadLocalized?.GetLocalizedString() ?? "HITTING THE ROAD"));
			truckScreenLocked.LockChatToggle(_lock: true, lockedText, lightColor, darkColor);
			playerChatBoxStateStart = false;
		}
		if (!SemiFunc.RunIsLobby())
		{
			if (engineSoundTimer > 0f)
			{
				engineSoundTimer -= Time.deltaTime;
				return;
			}
			engineSoundTimer = Random.Range(2f, 4f);
			engineRevSound.Play(((Component)truckScreenLocked).transform.position);
		}
	}

	private void PlayerChatBoxStateLockedDestroySlackers()
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_003f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0069: Unknown result type (might be due to invalid IL or missing references)
		//IL_006a: Unknown result type (might be due to invalid IL or missing references)
		if (playerChatBoxStateStart)
		{
			ForceReleaseChat();
			Color darkColor = new Color(0.4f, 0f, 0.3f, 1f);
			Color lightColor = new Color(1f, 0f, 0f, 1f);
			string lockedText = destroyingSlackersLocalized?.GetLocalizedString() ?? "DESTROYING SLACKERS";
			truckScreenLocked.LockChatToggle(_lock: true, lockedText, lightColor, darkColor);
			playerChatBoxStateStart = false;
		}
	}

	private void PlayerChatBoxStateMachine()
	{
		switch (playerChatBoxState)
		{
		case PlayerChatBoxState.Idle:
			PlayerChatBoxStateIdle();
			break;
		case PlayerChatBoxState.LockedStartingTruck:
			PlayerChatBoxStateLockedStartingTruck();
			break;
		case PlayerChatBoxState.LockedDestroySlackers:
			PlayerChatBoxStateLockedDestroySlackers();
			break;
		case PlayerChatBoxState.Typing:
			break;
		}
	}

	public TruckScreenText()
	{
		//IL_005e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0063: Unknown result type (might be due to invalid IL or missing references)
		//IL_007d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0082: Unknown result type (might be due to invalid IL or missing references)
		//IL_009c: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a1: Unknown result type (might be due to invalid IL or missing references)
		//IL_00bb: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c0: Unknown result type (might be due to invalid IL or missing references)
	}
}
