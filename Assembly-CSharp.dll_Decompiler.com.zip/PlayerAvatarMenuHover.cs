using UnityEngine;
using UnityEngine.UI;

public class PlayerAvatarMenuHover : MonoBehaviour
{
	private RectTransform rectTransform;

	private MenuPage parentPage;

	public Transform pointer;

	private bool startClick;

	private Vector2 mouseClickPos;

	public PlayerAvatarMenu playerAvatarMenu;

	private MenuElementHover menuElementHover;

	private RectTransform navigationTarget;

	public RenderTexture renderTexture;

	private Camera previewCamera;

	private RawImage rawImage;

	private RenderTexture renderTextureInstance;

	private void Awake()
	{
		//IL_005a: Unknown result type (might be due to invalid IL or missing references)
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0069: Expected Obj, but got Unknown
		rectTransform = ((Component)this).GetComponent<RectTransform>();
		parentPage = ((Component)this).GetComponentInParent<MenuPage>();
		menuElementHover = ((Component)this).GetComponent<MenuElementHover>();
		rawImage = ((Component)this).GetComponent<RawImage>();
		previewCamera = ((Component)playerAvatarMenu.cameraAndStuff).GetComponentInChildren<Camera>();
		if (Object.op_Implicit((Object)(object)renderTexture))
		{
			renderTextureInstance = new RenderTexture(renderTexture.descriptor);
			((Object)renderTextureInstance).name = ((Object)renderTexture).name + "_Instance";
			renderTextureInstance.Create();
			rawImage.texture = (Texture)(object)renderTextureInstance;
			previewCamera.targetTexture = renderTextureInstance;
		}
	}

	private void Update()
	{
		//IL_0006: Unknown result type (might be due to invalid IL or missing references)
		//IL_000b: Unknown result type (might be due to invalid IL or missing references)
		//IL_000c: Unknown result type (might be due to invalid IL or missing references)
		//IL_000d: Unknown result type (might be due to invalid IL or missing references)
		//IL_00cd: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d9: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ea: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f4: Unknown result type (might be due to invalid IL or missing references)
		//IL_00fe: Unknown result type (might be due to invalid IL or missing references)
		//IL_010f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0123: Unknown result type (might be due to invalid IL or missing references)
		//IL_0128: Unknown result type (might be due to invalid IL or missing references)
		//IL_007d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0082: Unknown result type (might be due to invalid IL or missing references)
		//IL_0086: Unknown result type (might be due to invalid IL or missing references)
		//IL_008b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0090: Unknown result type (might be due to invalid IL or missing references)
		//IL_0095: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a5: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a6: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ab: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b2: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b8: Unknown result type (might be due to invalid IL or missing references)
		//IL_00bd: Unknown result type (might be due to invalid IL or missing references)
		//IL_0182: Unknown result type (might be due to invalid IL or missing references)
		//IL_0184: Unknown result type (might be due to invalid IL or missing references)
		//IL_0189: Unknown result type (might be due to invalid IL or missing references)
		//IL_0193: Unknown result type (might be due to invalid IL or missing references)
		//IL_0198: Unknown result type (might be due to invalid IL or missing references)
		//IL_01a5: Unknown result type (might be due to invalid IL or missing references)
		//IL_01b2: Unknown result type (might be due to invalid IL or missing references)
		//IL_017c: Unknown result type (might be due to invalid IL or missing references)
		//IL_017d: Unknown result type (might be due to invalid IL or missing references)
		Vector2 val = SemiFunc.UIMouseGetLocalPositionWithinRectTransform(rectTransform);
		Vector2 val2 = val;
		if (SemiFunc.InputMode() == InputModes.Gamepad || MenuManager.instance.isKeyboardNavigating)
		{
			if (Object.op_Implicit((Object)(object)MenuManager.instance.currentMenuIDTransform))
			{
				navigationTarget = MenuManager.instance.currentMenuIDTransform;
			}
			if (Object.op_Implicit((Object)(object)navigationTarget) && ((Component)navigationTarget).gameObject.activeInHierarchy && Object.op_Implicit((Object)(object)MenuCursor.instance))
			{
				RectTransform val3 = navigationTarget;
				Rect rect = navigationTarget.rect;
				Vector3 val4 = ((Transform)val3).TransformPoint(Vector2.op_Implicit(rect.center));
				Vector3 val5 = ((Component)MenuCursor.instance).transform.parent.InverseTransformPoint(val4);
				val2 = SemiFunc.UIMouseGetLocalPositionWithinRectTransform(rectTransform, Vector2.op_Implicit(val5));
			}
		}
		else
		{
			navigationTarget = null;
		}
		pointer.localPosition = new Vector3(val2.x * 0.98f, val2.y * 1.035f, 0f) / SemiFunc.UIMulti() * 2.23f;
		Transform val6 = pointer;
		val6.localPosition += new Vector3(-0.065f, -0.06f, 0f);
		((Renderer)((Component)pointer).GetComponent<MeshRenderer>()).enabled = false;
		if (SemiFunc.InputMode() == InputModes.MouseAndKeyboard && !MenuManager.instance.isKeyboardNavigating && SemiFunc.InputHold(InputKey.UIClick) && menuElementHover.isHovering)
		{
			if (!startClick)
			{
				startClick = true;
				mouseClickPos = val;
			}
			Vector2 val7 = (val - mouseClickPos) * 25f;
			playerAvatarMenu.Rotate(new Vector3(0f, 0f - val7.x, 0f));
		}
		else
		{
			startClick = false;
		}
	}

	private void OnDestroy()
	{
		if (Object.op_Implicit((Object)(object)renderTextureInstance))
		{
			if (Object.op_Implicit((Object)(object)previewCamera))
			{
				previewCamera.targetTexture = null;
			}
			renderTextureInstance.Release();
			Object.Destroy((Object)(object)renderTextureInstance);
		}
	}
}
