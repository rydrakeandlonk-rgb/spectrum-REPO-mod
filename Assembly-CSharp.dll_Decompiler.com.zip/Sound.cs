using System;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Events;

[Serializable]
public class Sound
{
	public AudioSource Source;

	public AudioClip[] Sounds;

	private AudioLowPassLogic LowPassLogic;

	private bool HasLowPassLogic;

	public AudioManager.AudioType Type;

	[Range(0f, 1f)]
	public float Volume = 0.5f;

	internal float VolumeDefault = 0.5f;

	[Range(0f, 1f)]
	public float VolumeRandom = 0.1f;

	internal float VolumeRandomDefault = 0.1f;

	internal bool DefaultsStored;

	[Range(0f, 5f)]
	public float Pitch = 1f;

	internal float PitchDefault = 1f;

	[Range(0f, 2f)]
	public float PitchRandom = 0.1f;

	[Range(0f, 1f)]
	public float SpatialBlend = 1f;

	[Range(0f, 5f)]
	public float Doppler = 1f;

	[Range(0f, 1f)]
	public float ReverbMix = 1f;

	[Range(0f, 5f)]
	public float FalloffMultiplier = 1f;

	[Space]
	[Range(0f, 1f)]
	public float OffscreenVolume = 1f;

	[Range(0f, 1f)]
	public float OffscreenFalloff = 1f;

	[Space]
	public List<Collider> LowPassIgnoreColliders = new List<Collider>();

	private AudioClip LoopClip;

	internal float LoopVolume;

	internal float LoopVolumeCurrent;

	internal float LoopVolumeFinal;

	internal float LoopPitch;

	private bool LoopFalloffSetup;

	private float LoopFalloffMin;

	private float LoopFalloffMax;

	internal float LoopFalloff;

	internal float LoopFalloffFinal;

	private float LoopOffScreenTime = 0.25f;

	private float LoopOffScreenTimer;

	private bool LoopOffScreen;

	private float LoopOffScreenVolume;

	private float LoopOffScreenFalloff;

	internal float StartTimeOverride = 999999f;

	internal bool AudioInfoFetched;

	public UnityEvent onLoopComplete;

	private float prevLoopTime;

	public AudioSource Play(Vector3 position, float volumeMultiplier = 1f, float falloffMultiplier = 1f, float offscreenVolumeMultiplier = 1f, float offscreenFalloffMultiplier = 1f)
	{
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0060: Unknown result type (might be due to invalid IL or missing references)
		//IL_018f: Unknown result type (might be due to invalid IL or missing references)
		if (Sounds.Length == 0)
		{
			return null;
		}
		AudioClip val = Sounds[Random.Range(0, Sounds.Length)];
		float num = Pitch + Random.Range(0f - PitchRandom, PitchRandom);
		AudioSource val2 = Source;
		if (!Object.op_Implicit((Object)(object)val2))
		{
			GameObject val3 = AudioPrefab();
			if (!Object.op_Implicit((Object)(object)val3))
			{
				return null;
			}
			GameObject val4 = Object.Instantiate<GameObject>(val3, position, Quaternion.identity, AudioManager.instance.SoundsParent);
			if (Object.op_Implicit((Object)(object)val))
			{
				((Object)val4.gameObject).name = ((Object)val).name;
			}
			val2 = val4.GetComponent<AudioSource>();
			if (!Object.op_Implicit((Object)(object)val) || (Object)(object)val3 != (Object)(object)AudioManager.instance.AudioPersistent)
			{
				if (Object.op_Implicit((Object)(object)val))
				{
					Object.Destroy((Object)(object)val4, val.length / num);
				}
				else
				{
					Object.Destroy((Object)(object)val4);
				}
			}
		}
		else if (!((Behaviour)val2).isActiveAndEnabled)
		{
			return null;
		}
		AudioSource val5 = val2;
		val5.minDistance *= FalloffMultiplier;
		AudioSource val6 = val2;
		val6.minDistance *= falloffMultiplier;
		AudioSource val7 = val2;
		val7.maxDistance *= FalloffMultiplier;
		AudioSource val8 = val2;
		val8.maxDistance *= falloffMultiplier;
		val2.clip = Sounds[Random.Range(0, Sounds.Length)];
		val2.volume = (Volume + Random.Range(0f - VolumeRandom, VolumeRandom)) * volumeMultiplier;
		if (SpatialBlend > 0f && (OffscreenVolume * offscreenVolumeMultiplier < 1f || OffscreenFalloff * offscreenFalloffMultiplier < 1f) && !SemiFunc.OnScreen(((Component)val2).transform.position, 0.1f, 0.1f))
		{
			AudioSource val9 = val2;
			val9.volume *= OffscreenVolume * offscreenVolumeMultiplier;
			AudioSource val10 = val2;
			val10.minDistance *= OffscreenFalloff * offscreenFalloffMultiplier;
			AudioSource val11 = val2;
			val11.maxDistance *= OffscreenFalloff * offscreenFalloffMultiplier;
		}
		val2.spatialBlend = SpatialBlend;
		val2.reverbZoneMix = ReverbMix;
		val2.dopplerLevel = Doppler;
		val2.pitch = num;
		val2.loop = false;
		if (SpatialBlend > 0f)
		{
			StartLowPass(val2);
		}
		if (!((Behaviour)val2).isActiveAndEnabled)
		{
			return null;
		}
		val2.Play();
		return val2;
	}

	public AudioSource Play(Transform followTarget, float volumeMultiplier = 1f, float falloffMultiplier = 1f, float offscreenVolumeMultiplier = 1f, float offscreenFalloffMultiplier = 1f)
	{
		//IL_001a: Unknown result type (might be due to invalid IL or missing references)
		if (!Object.op_Implicit((Object)(object)followTarget))
		{
			return null;
		}
		bool flag = !Object.op_Implicit((Object)(object)Source);
		AudioSource val = Play(followTarget.position, volumeMultiplier, falloffMultiplier, offscreenVolumeMultiplier, offscreenFalloffMultiplier);
		if (flag && Object.op_Implicit((Object)(object)val))
		{
			((Component)val).gameObject.AddComponent<SoundFollowTransform>().Target = followTarget;
		}
		return val;
	}

	public AudioSource Play(Transform followTarget, Vector3 contactPoint, float volumeMultiplier = 1f, float falloffMultiplier = 1f, float offscreenVolumeMultiplier = 1f, float offscreenFalloffMultiplier = 1f)
	{
		//IL_0019: Unknown result type (might be due to invalid IL or missing references)
		//IL_0044: Unknown result type (might be due to invalid IL or missing references)
		//IL_0045: Unknown result type (might be due to invalid IL or missing references)
		//IL_004a: Unknown result type (might be due to invalid IL or missing references)
		if (!Object.op_Implicit((Object)(object)followTarget))
		{
			return null;
		}
		bool flag = !Object.op_Implicit((Object)(object)Source);
		AudioSource val = Play(contactPoint, volumeMultiplier, falloffMultiplier, offscreenVolumeMultiplier, offscreenFalloffMultiplier);
		if (flag && Object.op_Implicit((Object)(object)val))
		{
			SoundFollowTransform soundFollowTransform = ((Component)val).gameObject.AddComponent<SoundFollowTransform>();
			soundFollowTransform.Target = followTarget;
			soundFollowTransform.Offset = followTarget.InverseTransformPoint(contactPoint);
		}
		return val;
	}

	private GameObject AudioPrefab()
	{
		if (!Object.op_Implicit((Object)(object)AudioManager.instance))
		{
			return null;
		}
		GameObject result = AudioManager.instance.AudioDefault;
		switch (Type)
		{
		case AudioManager.AudioType.HighFalloff:
			result = AudioManager.instance.AudioHighFalloff;
			break;
		case AudioManager.AudioType.Footstep:
			result = AudioManager.instance.AudioFootstep;
			break;
		case AudioManager.AudioType.MaterialImpact:
			result = AudioManager.instance.AudioMaterialImpact;
			break;
		case AudioManager.AudioType.Cutscene:
			result = AudioManager.instance.AudioCutscene;
			break;
		case AudioManager.AudioType.AmbienceBreaker:
			result = AudioManager.instance.AudioAmbienceBreaker;
			break;
		case AudioManager.AudioType.LowFalloff:
			result = AudioManager.instance.AudioLowFalloff;
			break;
		case AudioManager.AudioType.Global:
			result = AudioManager.instance.AudioGlobal;
			break;
		case AudioManager.AudioType.HigherFalloff:
			result = AudioManager.instance.AudioHigherFalloff;
			break;
		case AudioManager.AudioType.Attack:
			result = AudioManager.instance.AudioAttack;
			break;
		case AudioManager.AudioType.Persistent:
			result = AudioManager.instance.AudioPersistent;
			break;
		}
		return result;
	}

	internal AudioSource LoopSourceCreate(Vector3 _position)
	{
		//IL_0026: Unknown result type (might be due to invalid IL or missing references)
		//IL_0027: Unknown result type (might be due to invalid IL or missing references)
		if (Object.op_Implicit((Object)(object)Source))
		{
			return Source;
		}
		GameObject val = AudioPrefab();
		if (!Object.op_Implicit((Object)(object)val))
		{
			return null;
		}
		GameObject val2 = Object.Instantiate<GameObject>(val, _position, Quaternion.identity, AudioManager.instance.SoundsParent);
		AudioSource component = val2.GetComponent<AudioSource>();
		if (!Object.op_Implicit((Object)(object)component))
		{
			Object.Destroy((Object)(object)val2);
			return null;
		}
		if (Sounds != null && Sounds.Length != 0 && Object.op_Implicit((Object)(object)Sounds[0]))
		{
			((Object)val2).name = ((Object)Sounds[0]).name + " Loop";
		}
		LoopSourceSet(component);
		return Source;
	}

	internal void LoopSourceSet(AudioSource _source)
	{
		if (Object.op_Implicit((Object)(object)Source) && (Object)(object)Source != (Object)(object)_source)
		{
			Source.Stop();
		}
		Source = _source;
		LowPassLogic = null;
		HasLowPassLogic = false;
		LoopClip = null;
		LoopVolume = 0f;
		LoopVolumeCurrent = 0f;
		LoopVolumeFinal = 0f;
		LoopPitch = 0f;
		LoopFalloffSetup = false;
		LoopFalloffMin = 0f;
		LoopFalloffMax = 0f;
		LoopFalloff = 0f;
		LoopFalloffFinal = 0f;
		LoopOffScreenTimer = 0f;
		LoopOffScreen = false;
		LoopOffScreenVolume = 0f;
		AudioInfoFetched = false;
		prevLoopTime = 0f;
	}

	public bool StoreDefault(bool force = false)
	{
		if (DefaultsStored && !force)
		{
			return false;
		}
		DefaultsStored = true;
		VolumeDefault = Volume;
		VolumeRandomDefault = VolumeRandom;
		PitchDefault = Pitch;
		return true;
	}

	public void Stop()
	{
		Source.Stop();
	}

	private void StartLowPass(AudioSource source)
	{
		LowPassLogic = ((Component)source).GetComponent<AudioLowPassLogic>();
		if (Object.op_Implicit((Object)(object)LowPassLogic))
		{
			if (LowPassIgnoreColliders.Count > 0)
			{
				LowPassLogic.LowPassIgnoreColliders.AddRange(LowPassIgnoreColliders);
			}
			LowPassLogic.Setup();
			HasLowPassLogic = true;
		}
	}

	public void PlayLoop(bool playing, float fadeInSpeed, float fadeOutSpeed, float pitchMultiplier = 1f, float volumeMultiplier = 1f)
	{
		if (Sounds.Length == 0)
		{
			return;
		}
		if (!AudioInfoFetched || !Object.op_Implicit((Object)(object)Source.clip))
		{
			LoopClip = Sounds[Random.Range(0, Sounds.Length)];
			Source.clip = LoopClip;
			AudioInfoFetched = true;
		}
		if (playing)
		{
			if (!Source.isPlaying)
			{
				LoopVolume = Volume + Random.Range(0f - VolumeRandom, VolumeRandom);
				LoopPitch = Pitch + Random.Range(0f - PitchRandom, PitchRandom);
				LoopVolumeCurrent = 0f;
				LoopVolumeFinal = LoopVolumeCurrent;
				Source.volume = LoopVolumeCurrent * volumeMultiplier;
				Source.pitch = Mathf.Max(0f, LoopPitch * pitchMultiplier);
				Source.spatialBlend = SpatialBlend;
				Source.reverbZoneMix = ReverbMix;
				Source.dopplerLevel = Doppler;
				if (!LoopFalloffSetup)
				{
					AudioSource source = Source;
					source.minDistance *= FalloffMultiplier;
					AudioSource source2 = Source;
					source2.maxDistance *= FalloffMultiplier;
					LoopFalloffMin = Source.minDistance;
					LoopFalloffMax = Source.maxDistance;
					LoopFalloff = Source.maxDistance;
					LoopFalloffSetup = true;
				}
				else
				{
					Source.minDistance = LoopFalloffMin;
					Source.maxDistance = LoopFalloffMax;
				}
				Source.time = (Object.op_Implicit((Object)(object)Source.clip) ? Random.Range(0f, Source.clip.length) : 0f);
				if (StartTimeOverride != 999999f)
				{
					Source.time = StartTimeOverride;
				}
				prevLoopTime = Source.time;
				Source.loop = true;
				StartLowPass(Source);
				if (((Component)Source).gameObject.activeInHierarchy)
				{
					Source.Play();
				}
				return;
			}
			LoopVolumeCurrent += fadeInSpeed * Time.deltaTime;
			LoopVolumeCurrent = Mathf.Clamp(LoopVolumeCurrent, 0f, LoopVolume);
			LoopOffScreenLogic();
			Source.pitch = LoopPitch * pitchMultiplier;
			if (HasLowPassLogic)
			{
				LowPassLogic.Volume = LoopVolumeFinal * volumeMultiplier;
			}
			else
			{
				Source.volume = LoopVolumeFinal * volumeMultiplier;
			}
			if (Source.time < prevLoopTime)
			{
				AudioInfoFetched = false;
				UnityEvent val = onLoopComplete;
				if (val != null)
				{
					val.Invoke();
				}
			}
			prevLoopTime = Source.time;
		}
		else if (Source.isPlaying)
		{
			LoopVolumeCurrent -= fadeOutSpeed * Time.deltaTime;
			LoopVolumeCurrent = Mathf.Clamp(LoopVolumeCurrent, 0f, LoopVolume);
			LoopOffScreenLogic();
			Source.pitch = LoopPitch * pitchMultiplier;
			if (HasLowPassLogic)
			{
				LowPassLogic.Volume = LoopVolumeFinal * volumeMultiplier;
			}
			else
			{
				Source.volume = LoopVolumeFinal * volumeMultiplier;
			}
			if (LoopVolumeFinal <= 0f)
			{
				Source.Stop();
			}
		}
	}

	private void LoopOffScreenLogic()
	{
		//IL_005e: Unknown result type (might be due to invalid IL or missing references)
		LoopVolumeFinal = LoopVolumeCurrent;
		if (!(SpatialBlend > 0f) || (!(OffscreenVolume < 1f) && !(OffscreenFalloff < 1f)))
		{
			return;
		}
		if (LoopOffScreenTimer <= 0f)
		{
			LoopOffScreenTimer = LoopOffScreenTime;
			LoopOffScreen = !SemiFunc.OnScreen(((Component)Source).transform.position, 0.1f, 0.1f);
		}
		else
		{
			LoopOffScreenTimer -= Time.deltaTime;
		}
		if (OffscreenVolume < 1f)
		{
			if (LoopOffScreen)
			{
				LoopOffScreenVolume = Mathf.Lerp(LoopOffScreenVolume, OffscreenVolume, 15f * Time.deltaTime);
			}
			else
			{
				LoopOffScreenVolume = Mathf.Lerp(LoopOffScreenVolume, 1f, 15f * Time.deltaTime);
			}
			LoopVolumeFinal *= LoopOffScreenVolume;
		}
		if (OffscreenFalloff < 1f)
		{
			if (LoopOffScreen)
			{
				LoopFalloffFinal = Mathf.Lerp(LoopFalloffFinal, LoopFalloff * OffscreenFalloff, 15f * Time.deltaTime);
			}
			else
			{
				LoopFalloffFinal = Mathf.Lerp(LoopFalloffFinal, LoopFalloff, 15f * Time.deltaTime);
			}
			if (HasLowPassLogic)
			{
				LowPassLogic.Falloff = LoopFalloffFinal;
			}
			else
			{
				Source.maxDistance = LoopFalloffFinal;
			}
		}
	}

	public static void CopySound(Sound from, Sound to)
	{
		to.Source = from.Source;
		to.Sounds = from.Sounds;
		to.Type = from.Type;
		to.Volume = from.Volume;
		to.VolumeRandom = from.VolumeRandom;
		to.Pitch = from.Pitch;
		to.PitchRandom = from.PitchRandom;
		to.SpatialBlend = from.SpatialBlend;
		to.ReverbMix = from.ReverbMix;
		to.Doppler = from.Doppler;
	}
}
