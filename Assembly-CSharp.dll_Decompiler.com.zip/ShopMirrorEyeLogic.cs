using System.Collections.Generic;
using UnityEngine;

public class ShopMirrorEyeLogic : MonoBehaviour
{
	public Transform mirrorTransform;

	private List<PlayerAvatar> players = new List<PlayerAvatar>();

	private BoxCollider mirrorCollider;

	private void Awake()
	{
		mirrorCollider = ((Component)this).GetComponent<BoxCollider>();
	}

	private void Update()
	{
		//IL_0026: Unknown result type (might be due to invalid IL or missing references)
		//IL_0036: Unknown result type (might be due to invalid IL or missing references)
		//IL_0040: Unknown result type (might be due to invalid IL or missing references)
		//IL_0050: Unknown result type (might be due to invalid IL or missing references)
		//IL_0055: Unknown result type (might be due to invalid IL or missing references)
		//IL_0109: Unknown result type (might be due to invalid IL or missing references)
		//IL_010e: Unknown result type (might be due to invalid IL or missing references)
		//IL_011f: Unknown result type (might be due to invalid IL or missing references)
		//IL_013c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0141: Unknown result type (might be due to invalid IL or missing references)
		//IL_0149: Unknown result type (might be due to invalid IL or missing references)
		//IL_014b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0150: Unknown result type (might be due to invalid IL or missing references)
		//IL_0154: Unknown result type (might be due to invalid IL or missing references)
		//IL_015b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0162: Unknown result type (might be due to invalid IL or missing references)
		//IL_016a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0175: Unknown result type (might be due to invalid IL or missing references)
		//IL_0177: Unknown result type (might be due to invalid IL or missing references)
		//IL_017c: Unknown result type (might be due to invalid IL or missing references)
		//IL_018a: Unknown result type (might be due to invalid IL or missing references)
		if (SemiFunc.PerSecond(1f, (Object)(object)this))
		{
			players.Clear();
			Collider[] array = Physics.OverlapBox(((Component)mirrorCollider).transform.position, ((Component)mirrorCollider).transform.lossyScale / 2f, ((Component)mirrorCollider).transform.rotation, LayerMask.op_Implicit(SemiFunc.LayerMaskGetPlayersAndPhysObjects()));
			foreach (Collider val in array)
			{
				PlayerController componentInParent = ((Component)val).GetComponentInParent<PlayerController>();
				PlayerAvatar playerAvatar;
				if (Object.op_Implicit((Object)(object)componentInParent))
				{
					playerAvatar = componentInParent.playerAvatarScript;
				}
				else
				{
					playerAvatar = ((Component)val).GetComponentInParent<PlayerAvatar>();
					if (!Object.op_Implicit((Object)(object)playerAvatar))
					{
						PlayerTumble componentInParent2 = ((Component)val).GetComponentInParent<PlayerTumble>();
						if (Object.op_Implicit((Object)(object)componentInParent2))
						{
							playerAvatar = componentInParent2.playerAvatar;
						}
					}
				}
				if (Object.op_Implicit((Object)(object)playerAvatar) && !players.Contains(playerAvatar))
				{
					players.Add(playerAvatar);
				}
			}
		}
		foreach (PlayerAvatar player in players)
		{
			if (Object.op_Implicit((Object)(object)player) && !(Vector3.Dot(-mirrorTransform.forward, ((Component)player.localCamera).transform.forward) < 0f))
			{
				Vector3 position = player.playerAvatarVisuals.headLookAtTransform.position;
				Vector3 val2 = mirrorTransform.InverseTransformPoint(position);
				val2 = new Vector3(val2.x, val2.y, 0f - val2.z);
				Vector3 position2 = mirrorTransform.TransformPoint(val2);
				player.playerAvatarVisuals.playerEyes.Override(position2, 1f, ((Component)this).gameObject);
			}
		}
	}
}
