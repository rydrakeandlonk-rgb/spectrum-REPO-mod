using System.Collections.Generic;
using UnityEngine;

public class MineCartRailTrack : MonoBehaviour
{
	public struct RailFrame
	{
		public Vector3 position;

		public Vector3 tangent;

		public Vector3 up;

		public Vector3 right;

		public float distance;

		public float bank;

		public float radius;

		public bool curl;
	}

	public List<MineCartRailTrackPoint> points = new List<MineCartRailTrackPoint>();

	[Tooltip("loops the last point back to the first.")]
	public bool closedLoop;

	public float railWidth = 0.1f;

	public float railHeight = 0.2f;

	public float railSpacing = 0.6f;

	public float railY;

	[Tooltip("longest a segment can be on straights. lower = more, shorter pieces. meters.")]
	public float maxSegmentLength = 1f;

	[Tooltip("most a segment can turn before it splits. lower = denser through turns. degrees.")]
	public float maxSegmentAngle = 8f;

	[Tooltip("overall detail. above 1 = finer, below 1 = coarser.")]
	public float resolutionMultiplier = 1f;

	[Tooltip("hard cap on segments per span so a crazy curve can't blow up the count.")]
	public int maxSegmentsPerSpan = 256;

	[Tooltip("global curve roundness. keep at 1 so a point's 1x = the natural curve.")]
	public float tangentStrength = 1f;

	[Tooltip("rounds any corner too tight for the rails so they can't overlap. tight corners bow off the point a bit, gentle ones don't. cart follows the same path.")]
	public bool limitTurnRadius = true;

	[Tooltip("extra room between the inner rail's inner edge and the turn center. min centerline radius = railSpacing + railWidth/2 + this. bigger = rounder corners. also the rail-pair backstop margin.")]
	public float minTurnRadiusClearance = 0.05f;

	private readonly List<int> sampledPointFrameIndices = new List<int>();

	private List<RailFrame> queryCenterline;

	private float playerCameraCheckTime;

	private bool playerCameraLocal;

	private const float playerCameraCheckInterval = 1f / 15f;

	private const float playerCameraFogDistanceMargin = 5f;

	public bool InPlayerCameraLocal()
	{
		//IL_0045: Unknown result type (might be due to invalid IL or missing references)
		//IL_004b: Invalid comparison between Unknown and I4
		//IL_00a2: Unknown result type (might be due to invalid IL or missing references)
		if (Time.unscaledTime < playerCameraCheckTime)
		{
			return playerCameraLocal;
		}
		playerCameraCheckTime = Time.unscaledTime + 1f / 15f;
		playerCameraLocal = false;
		if (!SemiFunc.PlayerCameraLocalGet(out var _camera))
		{
			return false;
		}
		float num = _camera.farClipPlane;
		if (RenderSettings.fog && (int)RenderSettings.fogMode == 1 && RenderSettings.fogEndDistance > 0f)
		{
			num = Mathf.Min(num, RenderSettings.fogEndDistance + 5f);
		}
		if (!float.IsFinite(num) || num <= 0f)
		{
			return false;
		}
		foreach (MineCartRailTrackPoint point in points)
		{
			if (Object.op_Implicit((Object)(object)point) && SemiFunc.InPlayerCameraLocalFrustum(_camera, ((Component)point).transform.position, num))
			{
				playerCameraLocal = true;
				break;
			}
		}
		return playerCameraLocal;
	}

	private int SpanCount()
	{
		if (points.Count < 2)
		{
			return 0;
		}
		if (!closedLoop)
		{
			return points.Count - 1;
		}
		return points.Count;
	}

	private MineCartRailTrackPoint PointAt(int _index)
	{
		int count = points.Count;
		if (closedLoop)
		{
			return points[(_index % count + count) % count];
		}
		return points[Mathf.Clamp(_index, 0, count - 1)];
	}

	public bool AnyPointMissing()
	{
		foreach (MineCartRailTrackPoint point in points)
		{
			if (!Object.op_Implicit((Object)(object)point))
			{
				return true;
			}
		}
		return false;
	}

	private Vector3 CatmullRomRaw(int _spanIndex, float _t)
	{
		//IL_000e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0013: Unknown result type (might be due to invalid IL or missing references)
		//IL_0020: Unknown result type (might be due to invalid IL or missing references)
		//IL_0025: Unknown result type (might be due to invalid IL or missing references)
		//IL_0034: Unknown result type (might be due to invalid IL or missing references)
		//IL_0039: Unknown result type (might be due to invalid IL or missing references)
		//IL_0048: Unknown result type (might be due to invalid IL or missing references)
		//IL_004d: Unknown result type (might be due to invalid IL or missing references)
		//IL_008d: Unknown result type (might be due to invalid IL or missing references)
		//IL_008e: Unknown result type (might be due to invalid IL or missing references)
		//IL_008f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0094: Unknown result type (might be due to invalid IL or missing references)
		//IL_0095: Unknown result type (might be due to invalid IL or missing references)
		//IL_0096: Unknown result type (might be due to invalid IL or missing references)
		//IL_009b: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a2: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a7: Unknown result type (might be due to invalid IL or missing references)
		//IL_00aa: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ab: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ac: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b1: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b2: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b8: Unknown result type (might be due to invalid IL or missing references)
		//IL_00bf: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c4: Unknown result type (might be due to invalid IL or missing references)
		//IL_0111: Unknown result type (might be due to invalid IL or missing references)
		//IL_0112: Unknown result type (might be due to invalid IL or missing references)
		//IL_0119: Unknown result type (might be due to invalid IL or missing references)
		//IL_011b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0120: Unknown result type (might be due to invalid IL or missing references)
		//IL_0127: Unknown result type (might be due to invalid IL or missing references)
		//IL_0128: Unknown result type (might be due to invalid IL or missing references)
		//IL_012d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0134: Unknown result type (might be due to invalid IL or missing references)
		//IL_0136: Unknown result type (might be due to invalid IL or missing references)
		//IL_013b: Unknown result type (might be due to invalid IL or missing references)
		Vector3 position = ((Component)PointAt(_spanIndex - 1)).transform.position;
		Vector3 position2 = ((Component)PointAt(_spanIndex)).transform.position;
		Vector3 position3 = ((Component)PointAt(_spanIndex + 1)).transform.position;
		Vector3 position4 = ((Component)PointAt(_spanIndex + 2)).transform.position;
		float num = PointReach(_spanIndex) * tangentStrength * PointAt(_spanIndex).outroMultiplier;
		float num2 = PointReach(_spanIndex + 1) * tangentStrength * PointAt(_spanIndex + 1).introMultiplier;
		Vector3 val = TangentDir(position3 - position, position3 - position2) * num;
		Vector3 val2 = TangentDir(position4 - position2, position3 - position2) * num2;
		float num3 = _t * _t;
		float num4 = num3 * _t;
		float num5 = 2f * num4 - 3f * num3 + 1f;
		float num6 = num4 - 2f * num3 + _t;
		float num7 = -2f * num4 + 3f * num3;
		float num8 = num4 - num3;
		return num5 * position2 + num6 * val + num7 * position3 + num8 * val2;
	}

	private float PointReach(int _index)
	{
		//IL_000c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0011: Unknown result type (might be due to invalid IL or missing references)
		//IL_0020: Unknown result type (might be due to invalid IL or missing references)
		//IL_0025: Unknown result type (might be due to invalid IL or missing references)
		//IL_002c: Unknown result type (might be due to invalid IL or missing references)
		//IL_003b: Unknown result type (might be due to invalid IL or missing references)
		Vector3 position = ((Component)PointAt(_index)).transform.position;
		float num = Vector3.Distance(((Component)PointAt(_index - 1)).transform.position, position);
		float num2 = Vector3.Distance(position, ((Component)PointAt(_index + 1)).transform.position);
		if (num < 1E-06f)
		{
			return num2;
		}
		if (num2 < 1E-06f)
		{
			return num;
		}
		return Mathf.Min(num, num2);
	}

	private Vector3 TangentDir(Vector3 _neighborDir, Vector3 _chordDir)
	{
		//IL_0000: Unknown result type (might be due to invalid IL or missing references)
		//IL_0001: Unknown result type (might be due to invalid IL or missing references)
		//IL_0010: Unknown result type (might be due to invalid IL or missing references)
		//IL_0011: Unknown result type (might be due to invalid IL or missing references)
		//IL_0028: Unknown result type (might be due to invalid IL or missing references)
		//IL_0020: Unknown result type (might be due to invalid IL or missing references)
		Vector3 val = _neighborDir;
		if (val.sqrMagnitude < 1E-06f)
		{
			val = _chordDir;
		}
		if (val.sqrMagnitude < 1E-06f)
		{
			return Vector3.zero;
		}
		return val.normalized;
	}

	public Vector3 EvaluateSpline(int _spanIndex, float _t)
	{
		//IL_0003: Unknown result type (might be due to invalid IL or missing references)
		return CatmullRomRaw(_spanIndex, _t);
	}

	private float CircumRadius(Vector3 _a, Vector3 _b, Vector3 _c)
	{
		//IL_0000: Unknown result type (might be due to invalid IL or missing references)
		//IL_0001: Unknown result type (might be due to invalid IL or missing references)
		//IL_0008: Unknown result type (might be due to invalid IL or missing references)
		//IL_0009: Unknown result type (might be due to invalid IL or missing references)
		//IL_0010: Unknown result type (might be due to invalid IL or missing references)
		//IL_0011: Unknown result type (might be due to invalid IL or missing references)
		//IL_0018: Unknown result type (might be due to invalid IL or missing references)
		//IL_0019: Unknown result type (might be due to invalid IL or missing references)
		//IL_001a: Unknown result type (might be due to invalid IL or missing references)
		//IL_001f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0020: Unknown result type (might be due to invalid IL or missing references)
		//IL_0021: Unknown result type (might be due to invalid IL or missing references)
		//IL_0026: Unknown result type (might be due to invalid IL or missing references)
		//IL_002b: Unknown result type (might be due to invalid IL or missing references)
		float num = Vector3.Distance(_a, _b);
		float num2 = Vector3.Distance(_b, _c);
		float num3 = Vector3.Distance(_c, _a);
		Vector3 val = Vector3.Cross(_b - _a, _c - _a);
		float num4 = val.magnitude * 0.5f;
		if (num4 < 1E-07f)
		{
			return float.MaxValue;
		}
		return num * num2 * num3 / (4f * num4);
	}

	private Vector3 EvaluateTangent(int _spanIndex, float _t)
	{
		//IL_001b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0023: Unknown result type (might be due to invalid IL or missing references)
		//IL_0028: Unknown result type (might be due to invalid IL or missing references)
		//IL_002d: Unknown result type (might be due to invalid IL or missing references)
		//IL_004a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0042: Unknown result type (might be due to invalid IL or missing references)
		float num = 0.001f;
		float t = Mathf.Clamp01(_t - num);
		float t2 = Mathf.Clamp01(_t + num);
		Vector3 val = EvaluateSpline(_spanIndex, t2) - EvaluateSpline(_spanIndex, t);
		if (val.sqrMagnitude < 1E-06f)
		{
			return ((Component)this).transform.forward;
		}
		return val.normalized;
	}

	private float SpanBank(int _span, float _t)
	{
		float bankAngle = PointAt(_span).bankAngle;
		float bankAngle2 = PointAt(_span + 1).bankAngle;
		float num = _t * _t * (3f - 2f * _t);
		return Mathf.Lerp(bankAngle, bankAngle2, num);
	}

	private RailFrame BuildFrame(int _span, float _t, float _distance)
	{
		//IL_000d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0012: Unknown result type (might be due to invalid IL or missing references)
		//IL_001c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0021: Unknown result type (might be due to invalid IL or missing references)
		//IL_003f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0045: Unknown result type (might be due to invalid IL or missing references)
		//IL_004a: Unknown result type (might be due to invalid IL or missing references)
		//IL_004f: Unknown result type (might be due to invalid IL or missing references)
		//IL_008d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0093: Unknown result type (might be due to invalid IL or missing references)
		//IL_0098: Unknown result type (might be due to invalid IL or missing references)
		//IL_009d: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a0: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a5: Unknown result type (might be due to invalid IL or missing references)
		//IL_006a: Unknown result type (might be due to invalid IL or missing references)
		//IL_006f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0074: Unknown result type (might be due to invalid IL or missing references)
		//IL_0079: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ca: Unknown result type (might be due to invalid IL or missing references)
		//IL_00cf: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d4: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d7: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d9: Unknown result type (might be due to invalid IL or missing references)
		//IL_00de: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ea: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ec: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f1: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f6: Unknown result type (might be due to invalid IL or missing references)
		RailFrame result = default;
		result.position = EvaluateSpline(_span, _t);
		result.tangent = EvaluateTangent(_span, _t);
		result.distance = _distance;
		result.radius = AnalyticHorizontalRadius(_span, _t);
		result.right = Vector3.Cross(Vector3.up, result.tangent);
		if (result.right.sqrMagnitude < 1E-06f)
		{
			result.right = Vector3.Cross(result.tangent, Vector3.forward);
		}
		result.right.Normalize();
		Vector3 val = Vector3.Cross(result.tangent, result.right);
		result.up = val.normalized;
		float num = (result.bank = SpanBank(_span, _t));
		if (Mathf.Abs(num) > 0.001f)
		{
			Quaternion val2 = Quaternion.AngleAxis(num, result.tangent);
			result.right = val2 * result.right;
			result.up = val2 * result.up;
		}
		return result;
	}

	private float AnalyticHorizontalRadius(int _span, float _t)
	{
		//IL_0010: Unknown result type (might be due to invalid IL or missing references)
		//IL_0015: Unknown result type (might be due to invalid IL or missing references)
		//IL_0019: Unknown result type (might be due to invalid IL or missing references)
		//IL_001e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0029: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0054: Unknown result type (might be due to invalid IL or missing references)
		//IL_0055: Unknown result type (might be due to invalid IL or missing references)
		//IL_0056: Unknown result type (might be due to invalid IL or missing references)
		float num = 0.01f;
		Vector3 a = EvaluateSpline(_span, Mathf.Clamp01(_t - num));
		Vector3 b = EvaluateSpline(_span, _t);
		Vector3 c = EvaluateSpline(_span, Mathf.Clamp01(_t + num));
		a.y = 0f;
		b.y = 0f;
		c.y = 0f;
		return CircumRadius(a, b, c);
	}

	private void StabilizeFrames(List<RailFrame> _frames)
	{
		//IL_0009: Unknown result type (might be due to invalid IL or missing references)
		//IL_000e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0028: Unknown result type (might be due to invalid IL or missing references)
		//IL_002d: Unknown result type (might be due to invalid IL or missing references)
		//IL_003f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0044: Unknown result type (might be due to invalid IL or missing references)
		//IL_0045: Unknown result type (might be due to invalid IL or missing references)
		//IL_004a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0075: Unknown result type (might be due to invalid IL or missing references)
		//IL_007a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0097: Unknown result type (might be due to invalid IL or missing references)
		//IL_0099: Unknown result type (might be due to invalid IL or missing references)
		//IL_009c: Unknown result type (might be due to invalid IL or missing references)
		//IL_009d: Unknown result type (might be due to invalid IL or missing references)
		//IL_009f: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a4: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a8: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ad: Unknown result type (might be due to invalid IL or missing references)
		//IL_00af: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b1: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b5: Unknown result type (might be due to invalid IL or missing references)
		//IL_007f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0081: Unknown result type (might be due to invalid IL or missing references)
		//IL_006a: Unknown result type (might be due to invalid IL or missing references)
		//IL_006b: Unknown result type (might be due to invalid IL or missing references)
		//IL_006c: Unknown result type (might be due to invalid IL or missing references)
		//IL_005d: Unknown result type (might be due to invalid IL or missing references)
		//IL_005e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0063: Unknown result type (might be due to invalid IL or missing references)
		//IL_010b: Unknown result type (might be due to invalid IL or missing references)
		//IL_010d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0114: Unknown result type (might be due to invalid IL or missing references)
		//IL_0116: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d5: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d6: Unknown result type (might be due to invalid IL or missing references)
		//IL_00db: Unknown result type (might be due to invalid IL or missing references)
		//IL_00dc: Unknown result type (might be due to invalid IL or missing references)
		//IL_00de: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e7: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ec: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ee: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f0: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f5: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f9: Unknown result type (might be due to invalid IL or missing references)
		//IL_00fe: Unknown result type (might be due to invalid IL or missing references)
		//IL_008e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0090: Unknown result type (might be due to invalid IL or missing references)
		//IL_0095: Unknown result type (might be due to invalid IL or missing references)
		//IL_0071: Unknown result type (might be due to invalid IL or missing references)
		if (_frames.Count == 0)
		{
			return;
		}
		Vector3 val = Vector3.zero;
		bool flag = false;
		for (int i = 0; i < _frames.Count; i++)
		{
			RailFrame railFrame = _frames[i];
			Vector3 normalized = railFrame.tangent.normalized;
			if (!(normalized.sqrMagnitude < 0.5f))
			{
				Vector3 val2 = Vector3.Cross(Vector3.up, normalized);
				if (val2.sqrMagnitude < 0.001f)
				{
					val2 = (flag ? Vector3.ProjectOnPlane(val, normalized) : Vector3.Cross(normalized, Vector3.forward));
				}
				val2 = val2.normalized;
				if (flag && Vector3.Dot(val2, val) < 0f)
				{
					val2 = -val2;
				}
				val = val2;
				flag = true;
				Vector3 val3 = Vector3.Cross(normalized, val2);
				Vector3 normalized2 = val3.normalized;
				Vector3 right = val2;
				Vector3 up = normalized2;
				float bank = _frames[i].bank;
				if (Mathf.Abs(bank) > 0.01f)
				{
					Quaternion val4 = Quaternion.AngleAxis(bank, normalized);
					val3 = val4 * val2;
					right = val3.normalized;
					val3 = val4 * normalized2;
					up = val3.normalized;
				}
				RailFrame value = _frames[i];
				value.right = right;
				value.up = up;
				_frames[i] = value;
			}
		}
	}

	private int SpanSegmentCount(int _span)
	{
		//IL_004f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0054: Unknown result type (might be due to invalid IL or missing references)
		//IL_005d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0062: Unknown result type (might be due to invalid IL or missing references)
		//IL_0075: Unknown result type (might be due to invalid IL or missing references)
		//IL_007a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0080: Unknown result type (might be due to invalid IL or missing references)
		//IL_0085: Unknown result type (might be due to invalid IL or missing references)
		//IL_0089: Unknown result type (might be due to invalid IL or missing references)
		//IL_008b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0097: Unknown result type (might be due to invalid IL or missing references)
		//IL_0099: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a5: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a7: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a9: Unknown result type (might be due to invalid IL or missing references)
		float num = Mathf.Max(0.0001f, resolutionMultiplier);
		float num2 = Mathf.Max(0.01f, maxSegmentLength / num);
		float num3 = Mathf.Max(0.5f, maxSegmentAngle / num);
		int num4 = 16;
		float num5 = 0f;
		float num6 = 0f;
		Vector3 val = EvaluateSpline(_span, 0f);
		Vector3 val2 = EvaluateTangent(_span, 0f);
		for (int i = 1; i <= num4; i++)
		{
			float t = (float)i / (float)num4;
			Vector3 val3 = EvaluateSpline(_span, t);
			Vector3 val4 = EvaluateTangent(_span, t);
			num5 += Vector3.Distance(val, val3);
			num6 += Vector3.Angle(val2, val4);
			val = val3;
			val2 = val4;
		}
		int num7 = Mathf.CeilToInt(num5 / num2);
		int num8 = Mathf.CeilToInt(num6 / num3);
		return Mathf.Clamp(Mathf.Max(num7, num8), 1, maxSegmentsPerSpan);
	}

	private List<RailFrame> SampleCenterline()
	{
		//IL_0080: Unknown result type (might be due to invalid IL or missing references)
		//IL_0087: Unknown result type (might be due to invalid IL or missing references)
		List<RailFrame> list = new List<RailFrame>();
		sampledPointFrameIndices.Clear();
		int num = SpanCount();
		if (num == 0 || AnyPointMissing())
		{
			return list;
		}
		float num2 = 0f;
		RailFrame item = BuildFrame(0, 0f, 0f);
		list.Add(item);
		sampledPointFrameIndices.Add(0);
		for (int i = 0; i < num; i++)
		{
			int num3 = SpanSegmentCount(i);
			for (int j = 1; j <= num3; j++)
			{
				float t = (float)j / (float)num3;
				RailFrame railFrame = BuildFrame(i, t, 0f);
				num2 = (railFrame.distance = num2 + Vector3.Distance(item.position, railFrame.position));
				list.Add(railFrame);
				item = railFrame;
			}
			sampledPointFrameIndices.Add(list.Count - 1);
		}
		bool flag = ApplyBrokenElevation(list);
		if (LimitCurvature(list) | flag)
		{
			RebuildFrameDerivatives(list);
		}
		StabilizeFrames(list);
		return list;
	}

	private float MinTurnRadius()
	{
		return railSpacing + railWidth * 0.5f + Mathf.Max(0f, minTurnRadiusClearance);
	}

	private int NeighborBefore(int _i, int _count)
	{
		if (_i > 0)
		{
			return _i - 1;
		}
		if (!closedLoop)
		{
			return 0;
		}
		return _count - 2;
	}

	private int NeighborAfter(int _i, int _count)
	{
		if (_i < _count - 1)
		{
			return _i + 1;
		}
		if (!closedLoop)
		{
			return _count - 1;
		}
		return 1;
	}

	private float HorizontalCircumRadius(Vector3 _a, Vector3 _b, Vector3 _c)
	{
		//IL_0025: Unknown result type (might be due to invalid IL or missing references)
		//IL_0026: Unknown result type (might be due to invalid IL or missing references)
		//IL_0027: Unknown result type (might be due to invalid IL or missing references)
		_a.y = 0f;
		_b.y = 0f;
		_c.y = 0f;
		return CircumRadius(_a, _b, _c);
	}

	private bool LimitCurvature(List<RailFrame> _frames)
	{
		//IL_008b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0090: Unknown result type (might be due to invalid IL or missing references)
		//IL_009d: Unknown result type (might be due to invalid IL or missing references)
		//IL_00aa: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c5: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ed: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ef: Unknown result type (might be due to invalid IL or missing references)
		if (!limitTurnRadius)
		{
			return false;
		}
		int count = _frames.Count;
		if (count < 3)
		{
			return false;
		}
		float num = MinTurnRadius();
		if (num <= 0f)
		{
			return false;
		}
		bool result = false;
		for (int i = 0; i < 32; i++)
		{
			bool flag = false;
			for (int j = 0; j < count; j++)
			{
				if ((!closedLoop && (j <= 0 || j >= count - 1)) || (closedLoop && j == count - 1))
				{
					continue;
				}
				int index = NeighborBefore(j, count);
				int index2 = NeighborAfter(j, count);
				Vector3 _b = _frames[j].position;
				if (LimitVertex(ref _b, _frames[index].position, _frames[index2].position, num))
				{
					RailFrame value = _frames[j];
					value.position = _b;
					_frames[j] = value;
					if (closedLoop && j == 0)
					{
						RailFrame value2 = _frames[count - 1];
						value2.position = _b;
						_frames[count - 1] = value2;
					}
					flag = true;
					result = true;
				}
			}
			if (!flag)
			{
				break;
			}
		}
		return result;
	}

	private bool LimitVertex(ref Vector3 _b, Vector3 _a, Vector3 _c, float _minRadius)
	{
		//IL_0002: Unknown result type (might be due to invalid IL or missing references)
		//IL_000d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0013: Unknown result type (might be due to invalid IL or missing references)
		//IL_002b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0032: Unknown result type (might be due to invalid IL or missing references)
		//IL_003d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0043: Unknown result type (might be due to invalid IL or missing references)
		//IL_0049: Unknown result type (might be due to invalid IL or missing references)
		//IL_004a: Unknown result type (might be due to invalid IL or missing references)
		//IL_004b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0057: Unknown result type (might be due to invalid IL or missing references)
		//IL_0058: Unknown result type (might be due to invalid IL or missing references)
		//IL_0059: Unknown result type (might be due to invalid IL or missing references)
		//IL_0063: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_0069: Unknown result type (might be due to invalid IL or missing references)
		//IL_006a: Unknown result type (might be due to invalid IL or missing references)
		//IL_006b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0070: Unknown result type (might be due to invalid IL or missing references)
		//IL_0086: Unknown result type (might be due to invalid IL or missing references)
		//IL_008a: Unknown result type (might be due to invalid IL or missing references)
		//IL_008f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0091: Unknown result type (might be due to invalid IL or missing references)
		//IL_0092: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d1: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d2: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d6: Unknown result type (might be due to invalid IL or missing references)
		//IL_00db: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e0: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f0: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f7: Unknown result type (might be due to invalid IL or missing references)
		//IL_00fc: Unknown result type (might be due to invalid IL or missing references)
		Vector3 val = new Vector3(_a.x, 0f, _a.z);
		Vector3 val2 = new Vector3(_b.x, 0f, _b.z);
		Vector3 val3 = new Vector3(_c.x, 0f, _c.z);
		if (HorizontalCircumRadius(val, val2, val3) >= _minRadius)
		{
			return false;
		}
		Vector3 val4 = (val + val3) * 0.5f;
		Vector3 val5 = val2 - val4;
		float magnitude = val5.magnitude;
		if (magnitude < 1E-06f)
		{
			return false;
		}
		Vector3 val6 = val5 / magnitude;
		float num = Vector3.Distance(val, val3) * 0.5f;
		float num2 = _minRadius * _minRadius - num * num;
		float num3 = ((num2 <= 0f) ? 0f : (_minRadius - Mathf.Sqrt(num2)));
		if (num3 >= magnitude)
		{
			return false;
		}
		Vector3 val7 = val4 + val6 * num3;
		_b = new Vector3(val7.x, _b.y, val7.z);
		return true;
	}

	private void RebuildFrameDerivatives(List<RailFrame> _frames)
	{
		//IL_0033: Unknown result type (might be due to invalid IL or missing references)
		//IL_003f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0044: Unknown result type (might be due to invalid IL or missing references)
		//IL_0049: Unknown result type (might be due to invalid IL or missing references)
		//IL_0060: Unknown result type (might be due to invalid IL or missing references)
		//IL_0065: Unknown result type (might be due to invalid IL or missing references)
		//IL_007e: Unknown result type (might be due to invalid IL or missing references)
		//IL_008a: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e2: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e4: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b1: Unknown result type (might be due to invalid IL or missing references)
		//IL_00bd: Unknown result type (might be due to invalid IL or missing references)
		//IL_00cb: Unknown result type (might be due to invalid IL or missing references)
		int count = _frames.Count;
		if (count == 0)
		{
			return;
		}
		float num = 0f;
		for (int i = 0; i < count; i++)
		{
			int index = NeighborBefore(i, count);
			int index2 = NeighborAfter(i, count);
			Vector3 tangent = _frames[index2].position - _frames[index].position;
			if (tangent.sqrMagnitude < 1E-06f)
			{
				tangent = _frames[i].tangent;
			}
			else
			{
				tangent.Normalize();
			}
			if (i > 0)
			{
				num += Vector3.Distance(_frames[i - 1].position, _frames[i].position);
			}
			float radius = float.MaxValue;
			if (i > 0 && i < count - 1)
			{
				radius = HorizontalCircumRadius(_frames[i - 1].position, _frames[i].position, _frames[i + 1].position);
			}
			RailFrame value = _frames[i];
			value.tangent = tangent;
			value.distance = num;
			value.radius = radius;
			_frames[i] = value;
		}
	}

	private bool ApplyBrokenElevation(List<RailFrame> _frames)
	{
		//IL_017f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0184: Unknown result type (might be due to invalid IL or missing references)
		//IL_018b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0190: Unknown result type (might be due to invalid IL or missing references)
		//IL_0195: Unknown result type (might be due to invalid IL or missing references)
		if (_frames.Count < 2)
		{
			return false;
		}
		List<float> list = new List<float>();
		List<MineCartRailTrackPoint> list2 = new List<MineCartRailTrackPoint>();
		for (int i = 0; i < points.Count; i++)
		{
			MineCartRailTrackPoint mineCartRailTrackPoint = points[i];
			if (Object.op_Implicit((Object)(object)mineCartRailTrackPoint) && mineCartRailTrackPoint.broken && (mineCartRailTrackPoint.backElevation != 0f || mineCartRailTrackPoint.frontElevation != 0f))
			{
				int index = sampledPointFrameIndices[Mathf.Clamp(i, 0, sampledPointFrameIndices.Count - 1)];
				list.Add(_frames[index].distance);
				list2.Add(mineCartRailTrackPoint);
			}
		}
		if (list2.Count == 0)
		{
			return false;
		}
		float distance = _frames[_frames.Count - 1].distance;
		for (int j = 0; j < _frames.Count; j++)
		{
			float distance2 = _frames[j].distance;
			float num = 0f;
			for (int k = 0; k < list2.Count; k++)
			{
				num += SideElevation(distance2, list[k], list2[k]);
				if (closedLoop && distance > 0f)
				{
					num += SideElevation(distance2, list[k] + distance, list2[k]);
					num += SideElevation(distance2, list[k] - distance, list2[k]);
				}
			}
			if (num != 0f)
			{
				RailFrame value = _frames[j];
				ref Vector3 position = ref value.position;
				position += Vector3.up * num;
				_frames[j] = value;
			}
		}
		return true;
	}

	private float SideElevation(float _distance, float _pointDistance, MineCartRailTrackPoint _point)
	{
		float num = _pointDistance - _point.backGapDistance;
		float num2 = _pointDistance + _point.forwardGapDistance;
		if (_distance <= num)
		{
			return RampElevation(_distance, num - _point.backElevationTransition, num, _point.backElevation);
		}
		if (_distance >= num2)
		{
			return RampElevation(_distance, num2 + _point.frontElevationTransition, num2, _point.frontElevation);
		}
		if (_distance < _pointDistance)
		{
			return RampElevation(num, num - _point.backElevationTransition, num, _point.backElevation);
		}
		return RampElevation(num2, num2 + _point.frontElevationTransition, num2, _point.frontElevation);
	}

	private float RampElevation(float _distance, float _zeroAt, float _fullAt, float _elevation)
	{
		if (_elevation == 0f)
		{
			return 0f;
		}
		float num = _fullAt - _zeroAt;
		if (Mathf.Abs(num) < 0.0001f)
		{
			return 0f;
		}
		float num2 = Mathf.Clamp01((_distance - _zeroAt) / num);
		return _elevation * num2 * num2 * (3f - 2f * num2);
	}

	private List<RailFrame> QueryCenterline()
	{
		if (queryCenterline != null && queryCenterline.Count >= 2)
		{
			return queryCenterline;
		}
		queryCenterline = SampleCenterline();
		return queryCenterline;
	}

	public bool GetNearestFrame(Vector3 _worldPosition, out Vector3 _position, out Vector3 _tangent, out Vector3 _up)
	{
		//IL_0001: Unknown result type (might be due to invalid IL or missing references)
		//IL_0002: Unknown result type (might be due to invalid IL or missing references)
		//IL_0008: Unknown result type (might be due to invalid IL or missing references)
		//IL_000d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0014: Unknown result type (might be due to invalid IL or missing references)
		//IL_0019: Unknown result type (might be due to invalid IL or missing references)
		//IL_0045: Unknown result type (might be due to invalid IL or missing references)
		//IL_004a: Unknown result type (might be due to invalid IL or missing references)
		//IL_004b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0050: Unknown result type (might be due to invalid IL or missing references)
		//IL_008d: Unknown result type (might be due to invalid IL or missing references)
		//IL_009d: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a9: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ae: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b5: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ba: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c2: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c7: Unknown result type (might be due to invalid IL or missing references)
		_position = _worldPosition;
		_tangent = Vector3.forward;
		_up = Vector3.up;
		List<RailFrame> list = QueryCenterline();
		if (list.Count < 2)
		{
			return false;
		}
		int num = -1;
		float num2 = float.MaxValue;
		for (int i = 0; i < list.Count; i++)
		{
			Vector3 val = list[i].position - _worldPosition;
			float sqrMagnitude = val.sqrMagnitude;
			if (sqrMagnitude < num2)
			{
				num2 = sqrMagnitude;
				num = i;
			}
		}
		if (num < 0)
		{
			return false;
		}
		RailFrame _result = list[num];
		float _resultSqr = num2;
		ProjectOntoSegment(list, num - 1, num, _worldPosition, ref _result, ref _resultSqr);
		ProjectOntoSegment(list, num, num + 1, _worldPosition, ref _result, ref _resultSqr);
		_position = _result.position;
		_tangent = _result.tangent;
		_up = _result.up;
		return true;
	}

	private void ProjectOntoSegment(List<RailFrame> _frames, int _i0, int _i1, Vector3 _worldPosition, ref RailFrame _result, ref float _resultSqr)
	{
		//IL_0015: Unknown result type (might be due to invalid IL or missing references)
		//IL_001a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0022: Unknown result type (might be due to invalid IL or missing references)
		//IL_0027: Unknown result type (might be due to invalid IL or missing references)
		//IL_0028: Unknown result type (might be due to invalid IL or missing references)
		//IL_002d: Unknown result type (might be due to invalid IL or missing references)
		//IL_003f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0041: Unknown result type (might be due to invalid IL or missing references)
		//IL_0042: Unknown result type (might be due to invalid IL or missing references)
		//IL_0047: Unknown result type (might be due to invalid IL or missing references)
		//IL_0055: Unknown result type (might be due to invalid IL or missing references)
		//IL_0056: Unknown result type (might be due to invalid IL or missing references)
		//IL_0058: Unknown result type (might be due to invalid IL or missing references)
		//IL_005d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0062: Unknown result type (might be due to invalid IL or missing references)
		//IL_0064: Unknown result type (might be due to invalid IL or missing references)
		//IL_0066: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0087: Unknown result type (might be due to invalid IL or missing references)
		//IL_0089: Unknown result type (might be due to invalid IL or missing references)
		//IL_0097: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a9: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ae: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b2: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b7: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c5: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d1: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d7: Unknown result type (might be due to invalid IL or missing references)
		//IL_00dc: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e0: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e5: Unknown result type (might be due to invalid IL or missing references)
		if (_i0 < 0 || _i1 >= _frames.Count)
		{
			return;
		}
		Vector3 position = _frames[_i0].position;
		Vector3 val = _frames[_i1].position - position;
		float sqrMagnitude = val.sqrMagnitude;
		if (!(sqrMagnitude < 1E-06f))
		{
			float num = Mathf.Clamp01(Vector3.Dot(_worldPosition - position, val) / sqrMagnitude);
			Vector3 val2 = position + val * num;
			Vector3 val3 = val2 - _worldPosition;
			float sqrMagnitude2 = val3.sqrMagnitude;
			if (!(sqrMagnitude2 >= _resultSqr))
			{
				_resultSqr = sqrMagnitude2;
				_result.position = val2;
				val3 = Vector3.Slerp(_frames[_i0].tangent, _frames[_i1].tangent, num);
				_result.tangent = val3.normalized;
				val3 = Vector3.Slerp(_frames[_i0].up, _frames[_i1].up, num);
				_result.up = val3.normalized;
			}
		}
	}
}
