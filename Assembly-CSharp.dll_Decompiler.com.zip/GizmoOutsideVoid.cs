using UnityEngine;

public class GizmoOutsideVoid : MonoBehaviour
{
	private Color color = new Color(1f, 0f, 1f, 0.02f);

	public bool drawWireframe = true;

	public bool includeInactive = true;

	private MeshFilter[] meshFilters;

	public GizmoOutsideVoid()
	{
		//IL_0015: Unknown result type (might be due to invalid IL or missing references)
		//IL_001a: Unknown result type (might be due to invalid IL or missing references)
	}
}
