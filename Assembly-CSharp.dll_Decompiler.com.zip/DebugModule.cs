using UnityEngine;

[RequireComponent(typeof(Module))]
public class DebugModule : MonoBehaviour
{
	public float padding = 0.1f;

	private void CheckColliders()
	{
		//IL_001d: Unknown result type (might be due to invalid IL or missing references)
		float halfExtent = GetHalfExtent();
		int num = 0;
		Collider[] componentsInChildren = ((Component)this).GetComponentsInChildren<Collider>(true);
		foreach (Collider val in componentsInChildren)
		{
			if (BoundsOutsideWorld(val.bounds, halfExtent))
			{
				num++;
				Debug.LogWarning((object)("Collider outside boundaries: " + GetHierarchyPath(((Component)val).transform)), (Object)(object)((Component)val).gameObject);
			}
		}
		if (num == 0)
		{
			Debug.Log((object)("Check Colliders: All colliders are inside the " + halfExtent * 2f + " x " + halfExtent * 2f + " space."), (Object)(object)((Component)this).gameObject);
		}
		else
		{
			Debug.LogWarning((object)("Check Colliders: " + num + " collider(s) outside the " + halfExtent * 2f + " x " + halfExtent * 2f + " space."), (Object)(object)((Component)this).gameObject);
		}
	}

	private void CheckMeshes()
	{
		//IL_0037: Unknown result type (might be due to invalid IL or missing references)
		float halfExtent = GetHalfExtent();
		int num = 0;
		MeshFilter[] componentsInChildren = ((Component)this).GetComponentsInChildren<MeshFilter>(true);
		foreach (MeshFilter val in componentsInChildren)
		{
			if (Object.op_Implicit((Object)(object)val.sharedMesh) && BoundsOutsideLocal(((Component)val).transform, val.sharedMesh.bounds, halfExtent))
			{
				num++;
				Debug.LogWarning((object)("Mesh outside boundaries: " + GetHierarchyPath(((Component)val).transform)), (Object)(object)((Component)val).gameObject);
			}
		}
		if (num == 0)
		{
			Debug.Log((object)("Check Meshes: All meshes are inside the " + halfExtent * 2f + " x " + halfExtent * 2f + " space."), (Object)(object)((Component)this).gameObject);
		}
		else
		{
			Debug.LogWarning((object)("Check Meshes: " + num + " mesh(es) outside the " + halfExtent * 2f + " x " + halfExtent * 2f + " space."), (Object)(object)((Component)this).gameObject);
		}
	}

	private float GetHalfExtent()
	{
		return ((((Component)this).GetComponent<Module>().type == Module.Type.Mega) ? 15f : 7.5f) + padding;
	}

	private bool BoundsOutsideWorld(Bounds _worldBounds, float _halfExtent)
	{
		//IL_000e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0015: Unknown result type (might be due to invalid IL or missing references)
		//IL_0020: Unknown result type (might be due to invalid IL or missing references)
		//IL_0025: Unknown result type (might be due to invalid IL or missing references)
		//IL_002a: Unknown result type (might be due to invalid IL or missing references)
		//IL_002f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0036: Unknown result type (might be due to invalid IL or missing references)
		//IL_0037: Unknown result type (might be due to invalid IL or missing references)
		//IL_003c: Unknown result type (might be due to invalid IL or missing references)
		//IL_003e: Unknown result type (might be due to invalid IL or missing references)
		//IL_004d: Unknown result type (might be due to invalid IL or missing references)
		for (int i = -1; i <= 1; i += 2)
		{
			for (int j = -1; j <= 1; j += 2)
			{
				for (int k = -1; k <= 1; k += 2)
				{
					Vector3 val = _worldBounds.center + Vector3.Scale(_worldBounds.extents, new Vector3((float)i, (float)j, (float)k));
					Vector3 val2 = ((Component)this).transform.InverseTransformPoint(val);
					if (Mathf.Abs(val2.x) > _halfExtent || Mathf.Abs(val2.z) > _halfExtent)
					{
						return true;
					}
				}
			}
		}
		return false;
	}

	private bool BoundsOutsideLocal(Transform _source, Bounds _localBounds, float _halfExtent)
	{
		//IL_000e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0015: Unknown result type (might be due to invalid IL or missing references)
		//IL_0020: Unknown result type (might be due to invalid IL or missing references)
		//IL_0025: Unknown result type (might be due to invalid IL or missing references)
		//IL_002a: Unknown result type (might be due to invalid IL or missing references)
		//IL_002f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0031: Unknown result type (might be due to invalid IL or missing references)
		//IL_0032: Unknown result type (might be due to invalid IL or missing references)
		//IL_0037: Unknown result type (might be due to invalid IL or missing references)
		//IL_003f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0041: Unknown result type (might be due to invalid IL or missing references)
		//IL_0046: Unknown result type (might be due to invalid IL or missing references)
		//IL_0048: Unknown result type (might be due to invalid IL or missing references)
		//IL_0057: Unknown result type (might be due to invalid IL or missing references)
		for (int i = -1; i <= 1; i += 2)
		{
			for (int j = -1; j <= 1; j += 2)
			{
				for (int k = -1; k <= 1; k += 2)
				{
					Vector3 val = _localBounds.center + Vector3.Scale(_localBounds.extents, new Vector3((float)i, (float)j, (float)k));
					Vector3 val2 = _source.TransformPoint(val);
					Vector3 val3 = ((Component)this).transform.InverseTransformPoint(val2);
					if (Mathf.Abs(val3.x) > _halfExtent || Mathf.Abs(val3.z) > _halfExtent)
					{
						return true;
					}
				}
			}
		}
		return false;
	}

	private string GetHierarchyPath(Transform _target)
	{
		string text = ((Object)_target).name;
		Transform parent = _target.parent;
		while (Object.op_Implicit((Object)(object)parent) && (Object)(object)parent != (Object)(object)((Component)this).transform)
		{
			text = ((Object)parent).name + "/" + text;
			parent = parent.parent;
		}
		return text;
	}
}
