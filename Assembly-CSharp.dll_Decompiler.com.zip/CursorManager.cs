using UnityEngine;
using UnityEngine.InputSystem;

public class CursorManager : MonoBehaviour
{
	public static CursorManager instance;

	private float unlockTimer;

	[RuntimeInitializeOnLoadMethod(/*Could not decode attribute arguments.*/)]
	private static void RuntimeInitializeOnLoad()
	{
		instance = null;
	}

	private void Awake()
	{
		Cursor.visible = false;
		if (!Object.op_Implicit((Object)(object)instance))
		{
			instance = this;
			Object.DontDestroyOnLoad((Object)(object)((Component)this).gameObject);
		}
		else
		{
			Object.Destroy((Object)(object)((Component)this).gameObject);
		}
	}

	private void Update()
	{
		if (unlockTimer > 0f)
		{
			if (Object.op_Implicit((Object)(object)MenuCursor.instance) && SemiFunc.InputMode() == InputModes.MouseAndKeyboard)
			{
				MenuCursor.instance.Show();
			}
			unlockTimer -= Time.deltaTime;
		}
		else if (unlockTimer != -1234f)
		{
			Cursor.lockState = (CursorLockMode)1;
			unlockTimer = -1234f;
		}
	}

	public void PositionSet(Vector2 position)
	{
		//IL_0018: Unknown result type (might be due to invalid IL or missing references)
		//IL_0021: Unknown result type (might be due to invalid IL or missing references)
		Mouse current = Mouse.current;
		if (Application.isFocused && current != null && ((InputDevice)current).enabled && (int)Cursor.lockState == 0)
		{
			current.WarpCursorPosition(position);
		}
	}

	public void Unlock(float _time)
	{
		Cursor.lockState = (CursorLockMode)0;
		Cursor.visible = false;
		unlockTimer = _time;
	}
}
