using UnityEngine;

public class shopkeeperDetectionSphere : MonoBehaviour
{
	public ShopKeeper shopkeeper;

	private void OnTriggerEnter(Collider other)
	{
		shopkeeper.OnTriggerEnterLogic(other);
	}
}
