using UnityEngine;

public class TruckSafetySpawnPoint : MonoBehaviour
{
	public static TruckSafetySpawnPoint instance;

	[RuntimeInitializeOnLoadMethod(/*Could not decode attribute arguments.*/)]
	private static void RuntimeInitializeOnLoad()
	{
		instance = null;
	}

	private void Awake()
	{
		instance = this;
	}
}
