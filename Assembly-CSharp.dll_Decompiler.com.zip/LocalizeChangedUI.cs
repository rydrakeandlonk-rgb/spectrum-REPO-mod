using UnityEngine;

public class LocalizeChangedUI : SemiUI
{
	public bool animateOnGlyphsChanged;

	protected override void Start()
	{
		base.Start();
		Show();
		AddCallback();
	}

	public void AddCallback()
	{
		LocalizationManager.instance.AddLocalizationChangedCallback(LocalizeChangedSpringShakeY);
		if (animateOnGlyphsChanged)
		{
			InputGlyphs.OnGlyphsChanged += LocalizeChangedSpringShakeY;
		}
	}

	public void RemoveCallback()
	{
		LocalizationManager.instance.RemoveLocalizationChangedCallback(LocalizeChangedSpringShakeY);
		if (animateOnGlyphsChanged)
		{
			InputGlyphs.OnGlyphsChanged -= LocalizeChangedSpringShakeY;
		}
	}

	protected override void OnDestroy()
	{
		base.OnDestroy();
		if (Object.op_Implicit((Object)(object)LocalizationManager.instance))
		{
			LocalizationManager.instance.RemoveLocalizationChangedCallback(LocalizeChangedSpringShakeY);
		}
		if (animateOnGlyphsChanged)
		{
			InputGlyphs.OnGlyphsChanged -= LocalizeChangedSpringShakeY;
		}
	}

	public void LocalizeChangedSpringShakeY()
	{
		float amount = Random.Range(5f, 10f);
		float frequency = Random.Range(1f, 2.5f);
		float time = Random.Range(0.2f, 0.25f);
		SemiUISpringShakeY(amount, frequency, time);
	}
}
