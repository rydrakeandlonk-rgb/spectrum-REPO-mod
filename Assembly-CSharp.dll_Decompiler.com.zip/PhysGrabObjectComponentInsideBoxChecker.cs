using System;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Events;

public class PhysGrabObjectComponentInsideBoxChecker : MonoBehaviour
{
	[Serializable]
	public class LayerMasks
	{
		public LayerMask[] layerMask;

		public float checkInterval;

		[HideInInspector]
		public float timer;
	}

	[Serializable]
	public class LookForValuableTypes
	{
		public ValuableVolume.Type volumeType;

		public bool includeBigger;

		public bool includeSmaller;
	}

	public List<LayerMasks> layerMasksToCheck;

	public List<MonoBehaviour> componentTypesToFind = new List<MonoBehaviour>();

	public UnityEvent<List<PhysGrabObject>> onObjectsFound;

	public UnityEvent onNoObjectsFound;

	public bool checkForValuableTypes;

	public List<LookForValuableTypes> lookForValuableTypes = new List<LookForValuableTypes>();

	private List<Type> cachedTypes = new List<Type>();

	internal List<PhysGrabObject> foundObjects = new List<PhysGrabObject>();

	private void Start()
	{
		foreach (MonoBehaviour item in componentTypesToFind)
		{
			if (Object.op_Implicit((Object)(object)item))
			{
				cachedTypes.Add(((object)item).GetType());
			}
		}
	}

	private void Update()
	{
		//IL_004e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0059: Unknown result type (might be due to invalid IL or missing references)
		//IL_0063: Unknown result type (might be due to invalid IL or missing references)
		//IL_006e: Unknown result type (might be due to invalid IL or missing references)
		//IL_007a: Unknown result type (might be due to invalid IL or missing references)
		if (!SemiFunc.IsMasterClientOrSingleplayer())
		{
			return;
		}
		foreach (LayerMasks item in layerMasksToCheck)
		{
			if (item.timer >= item.checkInterval)
			{
				item.timer = 0f;
				foundObjects.Clear();
				Collider[] array = Physics.OverlapBox(((Component)this).transform.position, ((Component)this).transform.lossyScale / 2f, ((Component)this).transform.rotation, LayerMask.op_Implicit(item.layerMask[0]));
				for (int i = 0; i < array.Length; i++)
				{
					PhysGrabObject componentInParent = ((Component)array[i]).GetComponentInParent<PhysGrabObject>();
					if (Object.op_Implicit((Object)(object)componentInParent) && !foundObjects.Contains(componentInParent))
					{
						bool num = cachedTypes.Count <= 0 || HasAnyComponentType(((Component)componentInParent).gameObject);
						bool flag = !checkForValuableTypes || MatchesValuableTypeFilter(componentInParent);
						if (num & flag)
						{
							foundObjects.Add(componentInParent);
						}
					}
				}
				if (foundObjects.Count > 0)
				{
					onObjectsFound.Invoke(foundObjects);
				}
				else
				{
					onNoObjectsFound.Invoke();
				}
			}
			item.timer += Time.deltaTime;
		}
	}

	private bool HasAnyComponentType(GameObject _gameObject)
	{
		foreach (Type cachedType in cachedTypes)
		{
			if (Object.op_Implicit((Object)(object)_gameObject.GetComponentInParent(cachedType)))
			{
				return true;
			}
		}
		return false;
	}

	private bool MatchesValuableTypeFilter(PhysGrabObject _physGrabObject)
	{
		ValuableObject component = ((Component)_physGrabObject).GetComponent<ValuableObject>();
		if (!Object.op_Implicit((Object)(object)component))
		{
			return false;
		}
		int volumeType = (int)component.volumeType;
		foreach (LookForValuableTypes lookForValuableType in lookForValuableTypes)
		{
			int volumeType2 = (int)lookForValuableType.volumeType;
			if (volumeType == volumeType2)
			{
				return true;
			}
			if (lookForValuableType.includeBigger && volumeType > volumeType2)
			{
				return true;
			}
			if (lookForValuableType.includeSmaller && volumeType < volumeType2)
			{
				return true;
			}
		}
		return false;
	}

	private void OnDrawGizmos()
	{
		//IL_0014: Unknown result type (might be due to invalid IL or missing references)
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0033: Unknown result type (might be due to invalid IL or missing references)
		//IL_0051: Unknown result type (might be due to invalid IL or missing references)
		//IL_005b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0060: Unknown result type (might be due to invalid IL or missing references)
		Gizmos.color = new Color(0f, 0.5f, 1f, 0.3f);
		Gizmos.matrix = ((Component)this).transform.localToWorldMatrix;
		Gizmos.DrawCube(Vector3.zero, Vector3.one);
		Gizmos.color = new Color(0f, 0f, 1f, 0.6f);
		Gizmos.DrawWireCube(Vector3.zero, Vector3.one);
	}
}
