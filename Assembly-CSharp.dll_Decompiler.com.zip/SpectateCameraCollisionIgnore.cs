using UnityEngine;

public class SpectateCameraCollisionIgnore : MonoBehaviour
{
	internal bool active = true;
}
