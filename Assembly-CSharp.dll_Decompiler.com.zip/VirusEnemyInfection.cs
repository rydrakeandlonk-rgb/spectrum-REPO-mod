using System.Collections.Generic;
using UnityEngine;

public class VirusEnemyInfection : MonoBehaviour
{
	private PlayerAvatar targetPlayer;

	private float virusLifeTime = 60f;

	private float virusLifeTimer;

	private float virusPopUpHeightVariation = 0.5f;

	private float popUpSpawnDistance;

	private float virusWindowPopDelay = 0.5f;

	private float virusWindowPopTimer;

	private int popUpWindowMaxAmount = 10;

	private int popUpsSpawned;

	public List<GameObject> popUpWindowTypes = new List<GameObject>();

	private Vector2 popUpSpawnTimeIntervalRange = new Vector2(1f, 3f);

	private float popUpSpawnTimer;

	private List<GameObject> instansiatedPopUpWindows = new List<GameObject>();

	private void Update()
	{
		virusLifeTimer += Time.deltaTime;
		instansiatedPopUpWindows.RemoveAll((GameObject _popUp) => !Object.op_Implicit((Object)(object)_popUp));
		if (virusLifeTimer >= virusLifeTime)
		{
			if (instansiatedPopUpWindows.Count <= 0)
			{
				Object.Destroy((Object)(object)((Component)this).gameObject);
				return;
			}
			virusWindowPopTimer += Time.deltaTime;
			if (virusWindowPopTimer >= virusWindowPopDelay)
			{
				virusWindowPopTimer = 0f;
				GameObject val = instansiatedPopUpWindows[0];
				instansiatedPopUpWindows.RemoveAt(0);
				val.GetComponent<VirusPopUp>().DestroyPopUp();
			}
		}
		else if (instansiatedPopUpWindows.Count < popUpWindowMaxAmount)
		{
			if (popUpSpawnTimer <= 0f)
			{
				SpawnPopUpWindow();
				popUpSpawnTimer = Random.Range(popUpSpawnTimeIntervalRange.x, popUpSpawnTimeIntervalRange.y);
			}
			else
			{
				popUpSpawnTimer -= Time.deltaTime;
			}
		}
	}

	private void SpawnPopUpWindow()
	{
		//IL_0071: Unknown result type (might be due to invalid IL or missing references)
		//IL_0076: Unknown result type (might be due to invalid IL or missing references)
		if (popUpWindowTypes.Count > 0)
		{
			List<PlayerAvatar> list = SemiFunc.PlayerGetList();
			if (list.Count > 0)
			{
				float angle = Random.Range(0f, 360f);
				float yOffset = Random.Range(0f - virusPopUpHeightVariation, virusPopUpHeightVariation);
				PlayerAvatar playerAvatar = list[0];
				GameObject val = Object.Instantiate<GameObject>(popUpWindowTypes[Random.Range(0, popUpWindowTypes.Count)], ((Component)playerAvatar.playerAvatarVisuals).transform.position, Quaternion.identity);
				VirusPopUp component = val.GetComponent<VirusPopUp>();
				component.SetUp(angle, yOffset, playerAvatar);
				component.AdjustDistance(popUpSpawnDistance);
				popUpSpawnDistance -= 0.05f;
				instansiatedPopUpWindows.Add(val);
			}
		}
	}

	public VirusEnemyInfection()
	{
		//IL_003f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0044: Unknown result type (might be due to invalid IL or missing references)
	}
}
