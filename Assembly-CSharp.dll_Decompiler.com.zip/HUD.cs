using UnityEngine;

public class HUD : MonoBehaviour
{
	public static HUD instance;

	public bool hidden;

	public GameObject hideParent;

	[RuntimeInitializeOnLoadMethod(/*Could not decode attribute arguments.*/)]
	private static void RuntimeInitializeOnLoad()
	{
		instance = null;
	}

	private void Awake()
	{
		instance = this;
	}

	public void Hide()
	{
		hideParent.SetActive(false);
		hidden = true;
	}

	public void Show()
	{
		hideParent.SetActive(true);
		hidden = false;
	}
}
