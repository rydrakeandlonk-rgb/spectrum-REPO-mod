using UnityEngine;

public class GraphicsButtonWindowMode : MonoBehaviour
{
	public static GraphicsButtonWindowMode instance;

	private MenuSlider slider;

	[RuntimeInitializeOnLoadMethod(/*Could not decode attribute arguments.*/)]
	private static void RuntimeInitializeOnLoad()
	{
		instance = null;
	}

	private void Awake()
	{
		instance = this;
		slider = ((Component)this).GetComponent<MenuSlider>();
	}

	public void UpdateSlider()
	{
		slider.Start();
	}

	public void ButtonPressed()
	{
		GraphicsManager.instance.UpdateWindowMode(_setResolution: true);
	}
}
