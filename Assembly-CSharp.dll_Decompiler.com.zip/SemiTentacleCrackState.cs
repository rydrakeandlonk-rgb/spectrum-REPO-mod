using UnityEngine;

internal struct SemiTentacleCrackState
{
	internal Vector3 start;

	internal Vector3 control;

	internal Vector3 loopDirection;

	internal float distance;

	internal float duration;
}
