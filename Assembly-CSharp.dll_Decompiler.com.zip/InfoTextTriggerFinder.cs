using UnityEngine;

public class InfoTextTriggerFinder : MonoBehaviour
{
	private void Update()
	{
		//IL_0087: Unknown result type (might be due to invalid IL or missing references)
		//IL_008d: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ba: Unknown result type (might be due to invalid IL or missing references)
		//IL_00bf: Unknown result type (might be due to invalid IL or missing references)
		//IL_00dc: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e8: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ed: Unknown result type (might be due to invalid IL or missing references)
		//IL_0102: Unknown result type (might be due to invalid IL or missing references)
		//IL_0124: Unknown result type (might be due to invalid IL or missing references)
		//IL_013a: Unknown result type (might be due to invalid IL or missing references)
		//IL_013f: Unknown result type (might be due to invalid IL or missing references)
		if (!SemiFunc.PerSecond(5f, (Object)(object)this) || !Object.op_Implicit((Object)(object)GameDirector.instance) || GameDirector.instance.currentState != GameDirector.gameState.Main || !Object.op_Implicit((Object)(object)PlayerController.instance))
		{
			return;
		}
		PlayerAvatar playerAvatarScript = PlayerController.instance.playerAvatarScript;
		if (!Object.op_Implicit((Object)(object)playerAvatarScript) || !Object.op_Implicit((Object)(object)playerAvatarScript.physGrabber) || !Object.op_Implicit((Object)(object)playerAvatarScript.localCamera) || playerAvatarScript.physGrabber.grabbed)
		{
			return;
		}
		Transform overrideTransform = playerAvatarScript.localCamera.GetOverrideTransform();
		if (!Object.op_Implicit((Object)(object)overrideTransform))
		{
			return;
		}
		RaycastHit[] array = Physics.RaycastAll(overrideTransform.position, overrideTransform.forward, 10f, LayerMask.GetMask(new string[1] { "Triggers" }), (QueryTriggerInteraction)2);
		RaycastHit val3 = default;
		for (int i = 0; i < array.Length; i++)
		{
			RaycastHit val = array[i];
			InfoTextTrigger component = ((Component)val.transform).GetComponent<InfoTextTrigger>();
			if (!Object.op_Implicit((Object)(object)component))
			{
				continue;
			}
			Vector3 val2 = overrideTransform.position - val.point;
			if (!(component.maxDistance >= val2.magnitude))
			{
				break;
			}
			int num = LayerMask.op_Implicit(SemiFunc.LayerMaskGetPhysGrabObject()) + LayerMask.GetMask(new string[1] { "Default" });
			if (Physics.OverlapSphere(val.point, 0.1f, num).Length != 0)
			{
				break;
			}
			if (!Physics.Raycast(val.point, val2, ref val3, val2.magnitude, num))
			{
				component.Activate();
				break;
			}
			PlayerTumble componentInParent = ((Component)val3.collider).GetComponentInParent<PlayerTumble>();
			if (Object.op_Implicit((Object)(object)componentInParent) && (Object)(object)componentInParent.playerAvatar == (Object)(object)playerAvatarScript)
			{
				component.Activate();
			}
			break;
		}
	}
}
