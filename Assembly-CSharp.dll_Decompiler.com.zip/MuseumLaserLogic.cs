using Photon.Pun;
using UnityEngine;
using UnityEngine.Serialization;

public class MuseumLaserLogic : MonoBehaviour
{
	public enum MuseumLaserState
	{
		Inactive,
		PoweringUp,
		Active,
		ShuttingDown,
		Overloaded
	}

	public MeshRenderer beamMeshRenderer;

	public MeshRenderer beamInnerMeshRenderer;

	private Transform beamTransform;

	private Transform beamInnerTransform;

	private Material beamMaterial;

	private Material beamInnerMaterial;

	public AnimationCurve animationCurvePowerUp;

	public AnimationCurve animationCurveShutdown;

	private float originalBeamScaleX;

	private float originalBeamScaleZ;

	private float originalBeamInnerScaleX;

	private float originalBeamInnerScaleZ;

	public Transform laserBall1Transform;

	public Transform laserBall2Transform;

	[Space(10f)]
	public Transform beamLight1Transform;

	public Transform beamLight2Transform;

	public Transform beamLightMid1Transform;

	public Transform beamLightMid2Transform;

	[Space(10f)]
	public Transform spinnerTransform;

	public Transform particleSparksTransform;

	public Transform laserHitPosTransform;

	[FormerlySerializedAs("LaserBeamVisualTransform")]
	public Transform laserBeamVisualTransform;

	public Transform laserBeamVisualHitTransform;

	public Transform laserBeamVisualHitInnerTransform;

	public Transform hurtColliderTransform;

	[Space(20f)]
	public ParticleSystem particleSparksParticleSystem;

	public ParticleSystem particleSparksBall1ParticleSystem;

	public ParticleSystem particleLaserHitParticleSystem;

	public ParticleSystem particleOverloadedSparksParticleSystem;

	[Space(20f)]
	public Light spotlight1;

	public Light spotlight2;

	public Light ballLight1;

	public Light ballLight2;

	public Light beamLight1;

	public Light beamLight2;

	public Light beamLightMid1;

	public Light beamLightMid2;

	[Space(20f)]
	private float lightOriginalIntensitySpotlight1;

	private float lightOriginalIntensitySpotlight2;

	private float lightOriginalIntensityBall1;

	private float lightOriginalIntensityBall2;

	private float lightOriginalIntensityBeam1;

	private float lightOriginalIntensityBeam2;

	private float lightOriginalIntensityBeamMid1;

	private float lightOriginalIntensityBeamMid2;

	[Space(20f)]
	public Transform audioSourceTransform;

	public Transform audioSourceCloseTransform;

	public Transform audioSourceHitTransform;

	[Space(20f)]
	public Sound soundLoop;

	public Sound soundNearLoop;

	public Sound soundHitLoop;

	public Sound soundPowerUp;

	public Sound soundOverload;

	public Sound soundShutdown;

	public Sound soundSparks;

	private float beamWidthMultiplier = 1f;

	private PhotonView photonView;

	private float originalBeamHitScale;

	private float originalBeamHitInnerScale;

	private HurtCollider hurtCollider;

	private float firstHitTimer;

	private float turnOffTimer;

	private float overloadedSparkTimer;

	internal bool playerNear;

	internal bool enemyNear;

	internal bool isHitting;

	internal bool isBeamActive;

	private static readonly RaycastHit[] _hitsBuffer = new RaycastHit[1];

	public MuseumLaserState currentState;

	private bool stateStart;

	private bool isCulled;

	private float stateTimer;

	private float stateTimerMax = 1f;

	private bool hitEnemy;

	private EnemyType hitEnemyType = EnemyType.Light;

	private float hitEnemyTimer;

	private float overloadedTimeMax = 6f;

	private void Start()
	{
		//IL_002a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0035: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b9: Unknown result type (might be due to invalid IL or missing references)
		//IL_00cf: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e5: Unknown result type (might be due to invalid IL or missing references)
		//IL_0183: Unknown result type (might be due to invalid IL or missing references)
		//IL_0199: Unknown result type (might be due to invalid IL or missing references)
		//IL_01b4: Unknown result type (might be due to invalid IL or missing references)
		stateStart = true;
		hurtCollider = ((Component)hurtColliderTransform).GetComponentInChildren<HurtCollider>();
		photonView = ((Component)this).GetComponent<PhotonView>();
		float range = Vector3.Distance(laserBall1Transform.position, laserBall2Transform.position);
		spotlight1.range = range;
		spotlight2.range = range;
		beamMaterial = ((Renderer)beamMeshRenderer).material;
		beamInnerMaterial = ((Renderer)beamInnerMeshRenderer).material;
		beamTransform = ((Component)beamMeshRenderer).transform;
		beamInnerTransform = ((Component)beamInnerMeshRenderer).transform;
		originalBeamScaleX = beamTransform.localScale.x;
		originalBeamScaleZ = beamTransform.localScale.z;
		originalBeamInnerScaleX = beamInnerTransform.localScale.x;
		originalBeamInnerScaleZ = beamInnerTransform.localScale.z;
		lightOriginalIntensitySpotlight1 = spotlight1.intensity;
		lightOriginalIntensitySpotlight2 = spotlight2.intensity;
		lightOriginalIntensityBall1 = ballLight1.intensity;
		lightOriginalIntensityBall2 = ballLight2.intensity;
		lightOriginalIntensityBeam1 = beamLight1.intensity;
		lightOriginalIntensityBeam2 = beamLight2.intensity;
		lightOriginalIntensityBeamMid1 = beamLightMid1.intensity;
		lightOriginalIntensityBeamMid2 = beamLightMid2.intensity;
		originalBeamHitScale = laserBeamVisualHitTransform.localScale.z;
		originalBeamHitInnerScale = laserBeamVisualHitInnerTransform.localScale.z;
		laserHitPosTransform.position = laserBall2Transform.position;
		MuseumLaserEditorLogic component = ((Component)this).GetComponent<MuseumLaserEditorLogic>();
		if (Object.op_Implicit((Object)(object)component))
		{
			((Behaviour)component).enabled = false;
		}
		if (Object.op_Implicit((Object)(object)hurtCollider))
		{
			((Behaviour)hurtCollider).enabled = false;
		}
	}

	private void Update()
	{
		bool flag = currentState != MuseumLaserState.Inactive && currentState != MuseumLaserState.Overloaded && !isCulled;
		bool playing = flag && playerNear;
		soundLoop.PlayLoop(flag, 2f, 2f);
		soundHitLoop.PlayLoop(isHitting & flag, 20f, 2f);
		soundNearLoop.PlayLoop(playing, 2f, 2f);
		if (firstHitTimer > 0f)
		{
			firstHitTimer -= Time.deltaTime;
		}
		StateMachine();
	}

	private void BeamToggle(bool _toggle)
	{
		((Renderer)beamMeshRenderer).enabled = _toggle;
		((Renderer)beamInnerMeshRenderer).enabled = _toggle;
		((Component)beamLight1Transform).gameObject.SetActive(_toggle);
		((Component)beamLight2Transform).gameObject.SetActive(_toggle);
		((Component)beamLightMid1Transform).gameObject.SetActive(_toggle);
		((Component)beamLightMid2Transform).gameObject.SetActive(_toggle);
		((Component)laserBeamVisualTransform).gameObject.SetActive(_toggle);
		beamWidthMultiplier = 1f;
		isBeamActive = _toggle;
		isHitting = false;
		SetLightIntensities();
		ToggleLights(_toggle);
		if (_toggle)
		{
			particleSparksParticleSystem.Play();
			particleSparksBall1ParticleSystem.Play();
			return;
		}
		particleSparksParticleSystem.Stop();
		particleSparksBall1ParticleSystem.Stop();
		if (Object.op_Implicit((Object)(object)particleLaserHitParticleSystem))
		{
			particleLaserHitParticleSystem.Stop(true);
		}
	}

	private void SetLightIntensities(float _intensity = 1f)
	{
		spotlight1.intensity = _intensity * lightOriginalIntensitySpotlight1;
		spotlight2.intensity = _intensity * lightOriginalIntensitySpotlight2;
		beamLight1.intensity = _intensity * lightOriginalIntensityBeam1;
		beamLight2.intensity = _intensity * lightOriginalIntensityBeam2;
		beamLightMid1.intensity = _intensity * lightOriginalIntensityBeamMid1;
		beamLightMid2.intensity = _intensity * lightOriginalIntensityBeamMid2;
		ballLight1.intensity = _intensity * lightOriginalIntensityBall1;
		ballLight2.intensity = _intensity * lightOriginalIntensityBall2;
	}

	private void ToggleLights(bool _toggle)
	{
		((Behaviour)spotlight1).enabled = _toggle;
		((Behaviour)spotlight2).enabled = _toggle;
		((Behaviour)beamLight1).enabled = _toggle;
		((Behaviour)beamLight2).enabled = _toggle;
		((Behaviour)beamLightMid1).enabled = _toggle;
		((Behaviour)beamLightMid2).enabled = _toggle;
		((Behaviour)ballLight1).enabled = _toggle;
		((Behaviour)ballLight2).enabled = _toggle;
	}

	private void StateMachine()
	{
		switch (currentState)
		{
		case MuseumLaserState.Inactive:
			StateInactive();
			break;
		case MuseumLaserState.PoweringUp:
			StatePoweringUp();
			break;
		case MuseumLaserState.Active:
			StateActive();
			break;
		case MuseumLaserState.ShuttingDown:
			StateShuttingDown();
			break;
		case MuseumLaserState.Overloaded:
			StateOverloaded();
			break;
		}
	}

	private void StateInactive()
	{
		if (stateStart)
		{
			stateStart = false;
			BeamToggle(_toggle: false);
			LaserVisuals();
		}
		PlayerNearTurnOnCheck();
		GrabbedValuableNearTurnOnCheck();
	}

	private void StatePoweringUp()
	{
		//IL_0035: Unknown result type (might be due to invalid IL or missing references)
		//IL_0040: Unknown result type (might be due to invalid IL or missing references)
		//IL_0045: Unknown result type (might be due to invalid IL or missing references)
		//IL_004a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0055: Unknown result type (might be due to invalid IL or missing references)
		//IL_0060: Unknown result type (might be due to invalid IL or missing references)
		//IL_0065: Unknown result type (might be due to invalid IL or missing references)
		//IL_006a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0084: Unknown result type (might be due to invalid IL or missing references)
		//IL_008f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0095: Unknown result type (might be due to invalid IL or missing references)
		//IL_009a: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a1: Unknown result type (might be due to invalid IL or missing references)
		if (stateStart)
		{
			stateStart = false;
			stateTimerMax = 0.6f;
			BeamToggle(_toggle: true);
			SetLightIntensities(0f);
			Vector3 val = laserHitPosTransform.position - laserBall1Transform.position;
			float num = Mathf.Clamp01(Vector3.Dot(((Component)PlayerController.instance).transform.position - laserBall1Transform.position, val) / val.sqrMagnitude);
			Vector3 position = Vector3.Lerp(laserBall1Transform.position, laserHitPosTransform.position, num);
			soundPowerUp.Play(position);
			turnOffTimer = 3f;
		}
		float num2 = animationCurvePowerUp.Evaluate(stateTimer / stateTimerMax);
		beamWidthMultiplier = Mathf.Lerp(0f, 1f, num2);
		SetLightIntensities(num2);
		if (stateTimer >= stateTimerMax)
		{
			StateSet(MuseumLaserState.Active);
		}
		stateTimer += Time.deltaTime;
		LaserVisuals();
		LaserHitLogic();
	}

	private void StateActive()
	{
		//IL_008c: Unknown result type (might be due to invalid IL or missing references)
		if (stateStart)
		{
			stateStart = false;
			turnOffTimer = 3f;
			BeamToggle(_toggle: true);
		}
		LaserVisuals();
		TurnOffCheck();
		CullingLogic();
		LaserHitLogic();
		if (hitEnemy)
		{
			overloadedSparkTimer -= Time.deltaTime;
			if (overloadedSparkTimer <= 0f)
			{
				overloadedSparkTimer = Random.Range(0.05f, 0.1f);
				particleOverloadedSparksParticleSystem.Play();
				soundSparks.Play(laserBall1Transform.position);
			}
		}
	}

	private void StateShuttingDown()
	{
		//IL_0035: Unknown result type (might be due to invalid IL or missing references)
		//IL_0040: Unknown result type (might be due to invalid IL or missing references)
		//IL_0045: Unknown result type (might be due to invalid IL or missing references)
		//IL_004a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0055: Unknown result type (might be due to invalid IL or missing references)
		//IL_0060: Unknown result type (might be due to invalid IL or missing references)
		//IL_0065: Unknown result type (might be due to invalid IL or missing references)
		//IL_006a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0084: Unknown result type (might be due to invalid IL or missing references)
		//IL_008f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0095: Unknown result type (might be due to invalid IL or missing references)
		//IL_009a: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a1: Unknown result type (might be due to invalid IL or missing references)
		if (stateStart)
		{
			stateStart = false;
			stateTimerMax = 0.6f;
			BeamToggle(_toggle: true);
			SetLightIntensities();
			Vector3 val = laserHitPosTransform.position - laserBall1Transform.position;
			float num = Mathf.Clamp01(Vector3.Dot(((Component)PlayerController.instance).transform.position - laserBall1Transform.position, val) / val.sqrMagnitude);
			Vector3 position = Vector3.Lerp(laserBall1Transform.position, laserHitPosTransform.position, num);
			soundShutdown.Play(position);
		}
		float num2 = animationCurveShutdown.Evaluate(stateTimer / stateTimerMax);
		beamWidthMultiplier = Mathf.Lerp(0f, 1f, num2);
		SetLightIntensities(num2);
		LaserHitLogic();
		stateTimer += Time.deltaTime;
		if (stateTimer >= stateTimerMax)
		{
			StateSet(MuseumLaserState.Inactive);
		}
		LaserVisuals();
	}

	private void StateOverloaded()
	{
		//IL_003c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0047: Unknown result type (might be due to invalid IL or missing references)
		//IL_004c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0051: Unknown result type (might be due to invalid IL or missing references)
		//IL_005c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0067: Unknown result type (might be due to invalid IL or missing references)
		//IL_006c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0071: Unknown result type (might be due to invalid IL or missing references)
		//IL_008b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0096: Unknown result type (might be due to invalid IL or missing references)
		//IL_009c: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a1: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a8: Unknown result type (might be due to invalid IL or missing references)
		//IL_0169: Unknown result type (might be due to invalid IL or missing references)
		if (stateStart)
		{
			hitEnemy = false;
			hitEnemyTimer = 0f;
			stateStart = false;
			BeamToggle(_toggle: false);
			SetLightIntensities(0f);
			Vector3 val = laserHitPosTransform.position - laserBall1Transform.position;
			float num = Mathf.Clamp01(Vector3.Dot(((Component)PlayerController.instance).transform.position - laserBall1Transform.position, val) / val.sqrMagnitude);
			Vector3 position = Vector3.Lerp(laserBall1Transform.position, laserHitPosTransform.position, num);
			soundOverload.Play(position);
			stateTimerMax = overloadedTimeMax;
			stateTimer = 0f;
			overloadedSparkTimer = 0f;
			((Behaviour)hurtCollider).enabled = false;
			LaserVisuals();
			if (SemiFunc.IsMasterClient())
			{
				photonView.RPC("HitEnemyRPC", (RpcTarget)1, new object[1] { false });
			}
		}
		overloadedSparkTimer -= Time.deltaTime;
		if (overloadedSparkTimer <= 0f)
		{
			overloadedSparkTimer = Random.Range(0.2f, 0.6f);
			particleOverloadedSparksParticleSystem.Play();
			soundSparks.Play(laserBall1Transform.position);
		}
		stateTimer += Time.deltaTime;
		if (stateTimer >= stateTimerMax)
		{
			StateSet(MuseumLaserState.Inactive);
		}
	}

	private void PlayerNearTurnOnCheck()
	{
		//IL_0021: Unknown result type (might be due to invalid IL or missing references)
		//IL_002c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0031: Unknown result type (might be due to invalid IL or missing references)
		//IL_0032: Unknown result type (might be due to invalid IL or missing references)
		if (!SemiFunc.IsMasterClientOrSingleplayer() || !SemiFunc.PerSecond(5f, (Object)(object)this))
		{
			return;
		}
		float num = 3f;
		Vector3 position = laserBall1Transform.position;
		Vector3 position2 = laserBall2Transform.position;
		if (SemiFunc.PlayerNearestLineDistance(position, position2) < num)
		{
			playerNear = true;
			if (currentState == MuseumLaserState.Inactive)
			{
				StateSet(MuseumLaserState.PoweringUp);
			}
		}
	}

	private void GrabbedValuableNearTurnOnCheck()
	{
		//IL_0021: Unknown result type (might be due to invalid IL or missing references)
		//IL_002c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0031: Unknown result type (might be due to invalid IL or missing references)
		//IL_0032: Unknown result type (might be due to invalid IL or missing references)
		if (SemiFunc.IsMasterClientOrSingleplayer() && SemiFunc.PerSecond(1f, (Object)(object)this))
		{
			float num = 3f;
			Vector3 position = laserBall1Transform.position;
			Vector3 position2 = laserBall2Transform.position;
			if (SemiFunc.PhysGrabObjectValuableGrabbedLineDistanceToNearest(position, position2, num) < num && currentState == MuseumLaserState.Inactive)
			{
				StateSet(MuseumLaserState.PoweringUp);
			}
		}
	}

	private void TurnOffCheck()
	{
		//IL_0034: Unknown result type (might be due to invalid IL or missing references)
		//IL_003f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0044: Unknown result type (might be due to invalid IL or missing references)
		//IL_0045: Unknown result type (might be due to invalid IL or missing references)
		//IL_0046: Unknown result type (might be due to invalid IL or missing references)
		//IL_0065: Unknown result type (might be due to invalid IL or missing references)
		if (!SemiFunc.IsMasterClientOrSingleplayer())
		{
			return;
		}
		if (turnOffTimer > 0f)
		{
			turnOffTimer -= Time.deltaTime;
			return;
		}
		float num = 10f;
		Vector3 position = laserBall1Transform.position;
		Vector3 position2 = laserBall2Transform.position;
		if (SemiFunc.PlayerNearestLineDistance(position, position2) > num && currentState == MuseumLaserState.Active)
		{
			StateSet(MuseumLaserState.ShuttingDown);
		}
		num = 10f;
		if (SemiFunc.PhysGrabObjectValuableGrabbedLineDistanceToNearest(position, position2, num) > num && currentState == MuseumLaserState.Active)
		{
			StateSet(MuseumLaserState.ShuttingDown);
		}
		turnOffTimer = 3f;
	}

	private void LaserVisuals()
	{
		//IL_00a4: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ae: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b8: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c9: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d4: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d9: Unknown result type (might be due to invalid IL or missing references)
		//IL_00de: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e9: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f4: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f9: Unknown result type (might be due to invalid IL or missing references)
		//IL_00fe: Unknown result type (might be due to invalid IL or missing references)
		//IL_011e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0129: Unknown result type (might be due to invalid IL or missing references)
		//IL_012f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0145: Unknown result type (might be due to invalid IL or missing references)
		//IL_0268: Unknown result type (might be due to invalid IL or missing references)
		//IL_0273: Unknown result type (might be due to invalid IL or missing references)
		//IL_0289: Unknown result type (might be due to invalid IL or missing references)
		//IL_029f: Unknown result type (might be due to invalid IL or missing references)
		//IL_02aa: Unknown result type (might be due to invalid IL or missing references)
		//IL_02c6: Unknown result type (might be due to invalid IL or missing references)
		//IL_02dc: Unknown result type (might be due to invalid IL or missing references)
		//IL_02e7: Unknown result type (might be due to invalid IL or missing references)
		//IL_0303: Unknown result type (might be due to invalid IL or missing references)
		//IL_0319: Unknown result type (might be due to invalid IL or missing references)
		//IL_0324: Unknown result type (might be due to invalid IL or missing references)
		//IL_0340: Unknown result type (might be due to invalid IL or missing references)
		//IL_0370: Unknown result type (might be due to invalid IL or missing references)
		//IL_0395: Unknown result type (might be due to invalid IL or missing references)
		//IL_0416: Unknown result type (might be due to invalid IL or missing references)
		//IL_0422: Unknown result type (might be due to invalid IL or missing references)
		//IL_04b5: Unknown result type (might be due to invalid IL or missing references)
		//IL_04c1: Unknown result type (might be due to invalid IL or missing references)
		//IL_01b7: Unknown result type (might be due to invalid IL or missing references)
		//IL_0208: Unknown result type (might be due to invalid IL or missing references)
		//IL_0218: Unknown result type (might be due to invalid IL or missing references)
		//IL_0222: Unknown result type (might be due to invalid IL or missing references)
		//IL_022c: Unknown result type (might be due to invalid IL or missing references)
		//IL_023d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0247: Unknown result type (might be due to invalid IL or missing references)
		//IL_0251: Unknown result type (might be due to invalid IL or missing references)
		//IL_0041: Unknown result type (might be due to invalid IL or missing references)
		//IL_004c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0056: Unknown result type (might be due to invalid IL or missing references)
		//IL_005b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0066: Unknown result type (might be due to invalid IL or missing references)
		//IL_0071: Unknown result type (might be due to invalid IL or missing references)
		//IL_007b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0080: Unknown result type (might be due to invalid IL or missing references)
		//IL_0094: Unknown result type (might be due to invalid IL or missing references)
		if (!isCulled)
		{
			float num = beamWidthMultiplier;
			float num2 = 5f;
			if (SemiFunc.PerSecond(15f, (Object)(object)this) && Object.op_Implicit((Object)(object)particleSparksParticleSystem))
			{
				((Component)particleSparksParticleSystem).transform.position = Vector3.Lerp(laserBall1Transform.position + laserBall1Transform.forward * 0.3f, laserHitPosTransform.position - laserHitPosTransform.forward * 0.3f, Random.Range(0f, 1f));
			}
			spinnerTransform.Rotate(Vector3.forward * 1000f * Time.deltaTime, (Space)1);
			Vector3 val = laserHitPosTransform.position - laserBall1Transform.position;
			float num3 = Mathf.Clamp01(Vector3.Dot(((Component)PlayerController.instance).transform.position - laserBall1Transform.position, val) / val.sqrMagnitude);
			audioSourceTransform.position = Vector3.Lerp(laserBall1Transform.position, laserHitPosTransform.position, num3);
			audioSourceCloseTransform.position = audioSourceTransform.position;
			((Component)laserBeamVisualHitTransform).gameObject.SetActive(isHitting);
			if (isHitting)
			{
				float num4 = 60f;
				float num5 = 0.05f;
				float num6 = Mathf.Sin(Time.time * num4) * num5;
				laserBeamVisualHitTransform.localScale = new Vector3((originalBeamHitScale + num6) * num, originalBeamHitScale + num6 * num, originalBeamHitScale + num6 * num);
				num5 = 0.05f;
				num4 = 65f;
				num6 = Mathf.Sin(Time.time * num4) * num5;
				laserBeamVisualHitInnerTransform.localScale = new Vector3(originalBeamHitInnerScale + num6 * num, originalBeamHitInnerScale + num6 * num, originalBeamHitInnerScale + num6 * num);
				laserBeamVisualHitTransform.Rotate(Vector3.up * 1000f * Time.deltaTime, (Space)1);
				laserBeamVisualHitInnerTransform.Rotate(Vector3.up * 1000f * Time.deltaTime, (Space)1);
			}
			beamLight1Transform.position = Vector3.Lerp(laserBall1Transform.position, laserHitPosTransform.position, Mathf.PingPong(Time.time * num2, 1f));
			beamLight2Transform.position = Vector3.Lerp(laserBall1Transform.position, laserHitPosTransform.position, Mathf.PingPong(Time.time * num2 + 0.5f, 1f));
			beamLightMid1Transform.position = Vector3.Lerp(laserBall1Transform.position, laserHitPosTransform.position, Mathf.PingPong(Time.time * num2 + 0.25f, 1f));
			beamLightMid2Transform.position = Vector3.Lerp(laserBall1Transform.position, laserHitPosTransform.position, Mathf.PingPong(Time.time * num2 + 0.75f, 1f));
			float num7 = 0.5f;
			float num8 = Time.time * num7;
			beamMaterial.SetTextureOffset("_MainTex", new Vector2(num8, num8 * 10f));
			beamInnerMaterial.SetTextureOffset("_MainTex", new Vector2(num8 * 2f, num8 * 20f));
			float num9 = 100f;
			float num10 = 0.2f;
			float num11 = 0.5f + 0.5f * Mathf.Sin(Time.time * num9);
			float num12 = Mathf.Lerp(originalBeamScaleX, originalBeamScaleX * (1f + num10), num11) * num;
			float num13 = Mathf.Lerp(originalBeamScaleZ, originalBeamScaleZ * (1f + num10), num11) * num;
			beamTransform.localScale = new Vector3(num12, beamTransform.localScale.y, num13);
			num9 = 80f;
			num10 = 1f;
			float num14 = 0.5f + 0.5f * Mathf.Sin(Time.time * num9 + 0.5f);
			float num15 = Mathf.Lerp(originalBeamInnerScaleX, originalBeamInnerScaleX / 4f * (1f + num10), num14) * num;
			float num16 = Mathf.Lerp(originalBeamInnerScaleZ, originalBeamInnerScaleZ / 4f * (1f + num10), num14) * num;
			beamInnerTransform.localScale = new Vector3(num15, beamInnerTransform.localScale.y, num16);
		}
	}

	private void StateSet(MuseumLaserState newState)
	{
		if (SemiFunc.IsMasterClientOrSingleplayer())
		{
			if (SemiFunc.IsMultiplayer())
			{
				photonView.RPC("StateSetRPC", (RpcTarget)0, new object[1] { (int)newState });
			}
			else
			{
				currentState = newState;
				stateStart = true;
				stateTimer = 0f;
			}
		}
	}

	[PunRPC]
	private void StateSetRPC(int newState, PhotonMessageInfo _info = default(PhotonMessageInfo))
	{
		//IL_0000: Unknown result type (might be due to invalid IL or missing references)
		if (SemiFunc.MasterOnlyRPC(_info))
		{
			if (currentState != (MuseumLaserState)newState)
			{
				currentState = (MuseumLaserState)newState;
				stateStart = true;
				stateTimer = 0f;
			}
		}
	}

	private void LaserHitLogic()
	{
		//IL_024c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0257: Unknown result type (might be due to invalid IL or missing references)
		//IL_0262: Unknown result type (might be due to invalid IL or missing references)
		//IL_026c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0271: Unknown result type (might be due to invalid IL or missing references)
		//IL_0288: Unknown result type (might be due to invalid IL or missing references)
		//IL_028d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0290: Unknown result type (might be due to invalid IL or missing references)
		//IL_02b4: Unknown result type (might be due to invalid IL or missing references)
		//IL_02c6: Unknown result type (might be due to invalid IL or missing references)
		//IL_02d1: Unknown result type (might be due to invalid IL or missing references)
		//IL_02dd: Unknown result type (might be due to invalid IL or missing references)
		//IL_02f3: Unknown result type (might be due to invalid IL or missing references)
		//IL_0016: Unknown result type (might be due to invalid IL or missing references)
		//IL_0021: Unknown result type (might be due to invalid IL or missing references)
		//IL_0026: Unknown result type (might be due to invalid IL or missing references)
		//IL_002b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0048: Unknown result type (might be due to invalid IL or missing references)
		//IL_004d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0055: Unknown result type (might be due to invalid IL or missing references)
		//IL_0071: Unknown result type (might be due to invalid IL or missing references)
		//IL_0076: Unknown result type (might be due to invalid IL or missing references)
		//IL_0235: Unknown result type (might be due to invalid IL or missing references)
		//IL_015d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0168: Unknown result type (might be due to invalid IL or missing references)
		//IL_016d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0172: Unknown result type (might be due to invalid IL or missing references)
		//IL_0176: Unknown result type (might be due to invalid IL or missing references)
		//IL_0181: Unknown result type (might be due to invalid IL or missing references)
		//IL_0186: Unknown result type (might be due to invalid IL or missing references)
		//IL_018b: Unknown result type (might be due to invalid IL or missing references)
		//IL_01b1: Unknown result type (might be due to invalid IL or missing references)
		//IL_01bc: Unknown result type (might be due to invalid IL or missing references)
		//IL_01c3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c5: Unknown result type (might be due to invalid IL or missing references)
		//IL_00db: Unknown result type (might be due to invalid IL or missing references)
		//IL_00eb: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f6: Unknown result type (might be due to invalid IL or missing references)
		//IL_0101: Unknown result type (might be due to invalid IL or missing references)
		//IL_010b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0110: Unknown result type (might be due to invalid IL or missing references)
		//IL_0122: Unknown result type (might be due to invalid IL or missing references)
		//IL_0127: Unknown result type (might be due to invalid IL or missing references)
		//IL_013e: Unknown result type (might be due to invalid IL or missing references)
		if (SemiFunc.PerSecond(15f, (Object)(object)this))
		{
			Vector3 val = laserHitPosTransform.position - laserBall1Transform.position;
			float num = val.magnitude + 0.1f;
			val.Normalize();
			if (Physics.RaycastNonAlloc(laserBall1Transform.position, val, _hitsBuffer, num, LayerMask.op_Implicit(SemiFunc.LayerMaskGetPlayersAndPhysObjects()), (QueryTriggerInteraction)1) > 0)
			{
				RaycastHit val2 = _hitsBuffer[0];
				if ((Object)(object)val2.transform != (Object)null)
				{
					if (!isHitting)
					{
						particleLaserHitParticleSystem.Play(true);
						((Behaviour)hurtCollider).enabled = true;
						if (firstHitTimer <= 0f)
						{
							audioSourceHitTransform.position = val2.point;
							hurtColliderTransform.position = audioSourceHitTransform.position;
							float num2 = Vector3.Distance(laserBall1Transform.position, laserHitPosTransform.position + laserBall1Transform.forward * 0.1f);
							Vector3 localScale = laserBeamVisualTransform.localScale;
							localScale.z = num2 / 2f;
							laserBeamVisualTransform.localScale = localScale;
							firstHitTimer = 0.2f;
						}
					}
					isHitting = true;
					Vector3 val3 = laserBall2Transform.position - laserBall1Transform.position;
					float num3 = Vector3.Dot(val2.point - laserBall1Transform.position, val3);
					float sqrMagnitude = val3.sqrMagnitude;
					float num4 = Mathf.Clamp01(num3 / sqrMagnitude);
					laserHitPosTransform.position = Vector3.Lerp(laserBall1Transform.position, laserBall2Transform.position, num4);
					laserHitPosTransform.LookAt(laserBall1Transform);
				}
				else
				{
					if (isHitting)
					{
						particleLaserHitParticleSystem.Stop(true);
						((Behaviour)hurtCollider).enabled = false;
					}
					isHitting = false;
				}
			}
			else
			{
				if (isHitting)
				{
					particleLaserHitParticleSystem.Stop(true);
					((Behaviour)hurtCollider).enabled = false;
				}
				laserHitPosTransform.position = laserBall2Transform.position;
				isHitting = false;
			}
		}
		float num5 = Vector3.Distance(laserBall1Transform.position, laserHitPosTransform.position + laserBall1Transform.forward * 0.1f);
		float num6 = 25f;
		Vector3 localScale2 = laserBeamVisualTransform.localScale;
		localScale2.z = Mathf.Lerp(localScale2.z, num5 / 2f, Time.deltaTime * num6);
		laserBeamVisualTransform.localScale = localScale2;
		audioSourceHitTransform.position = Vector3.Lerp(audioSourceHitTransform.position, laserHitPosTransform.position, Time.deltaTime * num6);
		hurtColliderTransform.position = audioSourceHitTransform.position;
		hurtColliderTransform.LookAt(laserBall2Transform);
		if (!SemiFunc.IsMasterClientOrSingleplayer() || !hitEnemy)
		{
			return;
		}
		if (hitEnemyTimer <= 0f)
		{
			if (currentState != MuseumLaserState.Overloaded)
			{
				StateSet(MuseumLaserState.Overloaded);
			}
			hitEnemy = false;
		}
		if (hitEnemyTimer > 0f)
		{
			hitEnemyTimer -= Time.deltaTime;
		}
	}

	public void OnEnemyHit()
	{
		Enemy onImpactEnemyEnemy = hurtCollider.onImpactEnemyEnemy;
		if (Object.op_Implicit((Object)(object)onImpactEnemyEnemy) && !hitEnemy)
		{
			if (SemiFunc.IsMasterClient())
			{
				photonView.RPC("HitEnemyRPC", (RpcTarget)1, new object[1] { true });
			}
			EnemyHitShake();
			hitEnemy = true;
			hitEnemyType = onImpactEnemyEnemy.Type;
			hitEnemyTimer = 1.5f;
			if (onImpactEnemyEnemy.Type == EnemyType.VeryLight)
			{
				overloadedTimeMax = 3f;
			}
			else if (onImpactEnemyEnemy.Type == EnemyType.Light)
			{
				overloadedTimeMax = 6f;
			}
			else if (onImpactEnemyEnemy.Type == EnemyType.Medium)
			{
				overloadedTimeMax = 12f;
			}
			else if (onImpactEnemyEnemy.Type == EnemyType.Heavy)
			{
				overloadedTimeMax = 16f;
			}
			else if (onImpactEnemyEnemy.Type == EnemyType.VeryHeavy)
			{
				overloadedTimeMax = 20f;
			}
		}
	}

	[PunRPC]
	public void HitEnemyRPC(bool _hitEnemy, PhotonMessageInfo _info = default(PhotonMessageInfo))
	{
		//IL_0000: Unknown result type (might be due to invalid IL or missing references)
		if (SemiFunc.MasterOnlyRPC(_info))
		{
			if (_hitEnemy && !hitEnemy)
			{
				EnemyHitShake();
			}
			hitEnemy = _hitEnemy;
		}
	}

	private void EnemyHitShake()
	{
		//IL_001f: Unknown result type (might be due to invalid IL or missing references)
		//IL_004d: Unknown result type (might be due to invalid IL or missing references)
		GameDirector.instance.CameraShake.ShakeDistance(1.5f, 1f, 6f, hurtColliderTransform.position, 0.1f);
		GameDirector.instance.CameraImpact.ShakeDistance(3f, 1f, 6f, hurtColliderTransform.position, 0.05f);
	}

	private void CullingLogic()
	{
		//IL_0020: Unknown result type (might be due to invalid IL or missing references)
		//IL_0025: Unknown result type (might be due to invalid IL or missing references)
		//IL_0065: Unknown result type (might be due to invalid IL or missing references)
		//IL_006a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0071: Unknown result type (might be due to invalid IL or missing references)
		//IL_0076: Unknown result type (might be due to invalid IL or missing references)
		//IL_0077: Unknown result type (might be due to invalid IL or missing references)
		//IL_0078: Unknown result type (might be due to invalid IL or missing references)
		//IL_0079: Unknown result type (might be due to invalid IL or missing references)
		//IL_007e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0080: Unknown result type (might be due to invalid IL or missing references)
		//IL_0081: Unknown result type (might be due to invalid IL or missing references)
		//IL_0082: Unknown result type (might be due to invalid IL or missing references)
		//IL_0087: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a1: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a2: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a5: Unknown result type (might be due to invalid IL or missing references)
		//IL_00aa: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ac: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ad: Unknown result type (might be due to invalid IL or missing references)
		//IL_0059: Unknown result type (might be due to invalid IL or missing references)
		//IL_005e: Unknown result type (might be due to invalid IL or missing references)
		if (SemiFunc.PerSecond(5f, (Object)(object)this))
		{
			float num = 20f;
			Vector3 position = ((Component)PlayerController.instance).transform.position;
			if (SemiFunc.IsMultiplayer() && SemiFunc.IsSpectating() && Object.op_Implicit((Object)(object)SpectateCamera.instance.player))
			{
				position = ((Component)SpectateCamera.instance.player.PlayerVisionTarget).transform.position;
			}
			Vector3 position2 = laserBall1Transform.position;
			Vector3 position3 = laserBall2Transform.position;
			Vector3 val = position3 - position2;
			float num2 = Vector3.Dot(position - position2, val);
			float sqrMagnitude = val.sqrMagnitude;
			float num3 = Mathf.Clamp01(num2 / sqrMagnitude);
			Vector3 val2 = Vector3.Lerp(position2, position3, num3);
			float num4 = Vector3.Distance(position, val2);
			if (num4 < num)
			{
				isCulled = false;
			}
			else
			{
				isCulled = true;
			}
			playerNear = false;
			if (!isCulled)
			{
				num = 3f;
				if (num4 < num)
				{
					playerNear = true;
				}
			}
		}
		if (isCulled)
		{
			if (isBeamActive)
			{
				BeamToggle(_toggle: false);
			}
		}
		else if (!isBeamActive)
		{
			BeamToggle(_toggle: true);
		}
	}
}
