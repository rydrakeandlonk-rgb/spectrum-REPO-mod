using TMPro;
using UnityEngine;
using UnityEngine.UI;

public class MenuElementServer : MonoBehaviour
{
	public enum IntroType
	{
		Vertical,
		Right,
		Left
	}

	internal IntroType introType;

	internal string roomName;

	internal MenuButtonPopUp menuButtonPopUp;

	public Image fadePanel;

	private MenuElementHover menuElementHover;

	private float initialFadeAlpha;

	public TextMeshProUGUI textName;

	public TextMeshProUGUI textPlayers;

	[Space]
	public RectTransform animationTransform;

	public AnimationCurve introCurve;

	private float introLerp;

	private bool introDone;

	private void Awake()
	{
		//IL_0013: Unknown result type (might be due to invalid IL or missing references)
		menuElementHover = ((Component)this).GetComponent<MenuElementHover>();
		initialFadeAlpha = ((Graphic)fadePanel).color.a;
		menuButtonPopUp = ((Component)this).GetComponent<MenuButtonPopUp>();
	}

	private void Update()
	{
		//IL_00ee: Unknown result type (might be due to invalid IL or missing references)
		//IL_001c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0111: Unknown result type (might be due to invalid IL or missing references)
		//IL_0116: Unknown result type (might be due to invalid IL or missing references)
		//IL_0119: Unknown result type (might be due to invalid IL or missing references)
		//IL_0140: Unknown result type (might be due to invalid IL or missing references)
		//IL_0033: Unknown result type (might be due to invalid IL or missing references)
		//IL_0038: Unknown result type (might be due to invalid IL or missing references)
		//IL_003b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0061: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b3: Unknown result type (might be due to invalid IL or missing references)
		UpdateIntro();
		if (menuElementHover.isHovering)
		{
			if (((Graphic)fadePanel).color.a != 0f)
			{
				Color color = ((Graphic)fadePanel).color;
				color.a = Mathf.Lerp(color.a, 0f, Time.deltaTime * 10f);
				((Graphic)fadePanel).color = color;
			}
			if (!menuElementHover.JustBecameCurrentTarget && SemiFunc.InputUIClick())
			{
				MenuManager.instance.MenuEffectClick(MenuManager.MenuClickEffectType.Confirm);
				MenuButtonPopUp component = ((Component)this).GetComponent<MenuButtonPopUp>();
				MenuManager.instance.PagePopUpTwoOptions(component, component.headerText, component.localizedHeader, component.headerColor, component.bodyText, component.localizedBody, component.option1Text, component.localizedOption1, component.option2Text, component.localizedOption2, component.richText);
			}
		}
		else if (Mathf.Abs(((Graphic)fadePanel).color.a - initialFadeAlpha) > 0.001f)
		{
			Color color2 = ((Graphic)fadePanel).color;
			color2.a = Mathf.Lerp(color2.a, initialFadeAlpha, Time.deltaTime * 10f);
			((Graphic)fadePanel).color = color2;
		}
	}

	private void UpdateIntro()
	{
		//IL_0052: Unknown result type (might be due to invalid IL or missing references)
		//IL_0057: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ae: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b3: Unknown result type (might be due to invalid IL or missing references)
		//IL_0108: Unknown result type (might be due to invalid IL or missing references)
		//IL_010d: Unknown result type (might be due to invalid IL or missing references)
		if (!introDone)
		{
			if (introType == IntroType.Vertical)
			{
				introLerp += Time.deltaTime * 5f;
				animationTransform.anchoredPosition = Vector2.op_Implicit(new Vector3(0f, introCurve.Evaluate(introLerp) * 8f, 0f));
			}
			else if (introType == IntroType.Right)
			{
				introLerp += Time.deltaTime * 5f;
				animationTransform.anchoredPosition = Vector2.op_Implicit(new Vector3(introCurve.Evaluate(introLerp) * 30f, 0f, 0f));
			}
			else if (introType == IntroType.Left)
			{
				introLerp += Time.deltaTime * 5f;
				animationTransform.anchoredPosition = Vector2.op_Implicit(new Vector3((0f - introCurve.Evaluate(introLerp)) * 30f, 0f, 0f));
			}
			if (introLerp > 1f)
			{
				introDone = true;
			}
		}
	}

	public void OnButton()
	{
		DataDirector.instance.networkJoinServerName = roomName;
		MenuManager.instance.MenuEffectClick(MenuManager.MenuClickEffectType.Confirm, null, 1f, 1f);
		RunManager.instance.ResetProgress();
		StatsManager.instance.saveFileCurrent = "";
		GameManager.instance.SetConnectRandom(_connectRandom: true);
		GameManager.instance.SetLobbyType(GameManager.LobbyTypes.Public);
		GameManager.instance.localTest = false;
		RunManager.instance.ChangeLevel(_completedLevel: true, _levelFailed: false, RunManager.ChangeLevelType.LobbyMenu);
		RunManager.instance.lobbyJoin = true;
	}
}
