using UnityEngine;

public class EnemyHeadGrabberLocalCamera : MonoBehaviour
{
	private float activeTimer;

	public SpringQuaternion spring;

	public Transform springTransform;

	[Space]
	public Transform scaleTransform;

	public AnimationCurve scaleCurve;

	private float scaleLerp;

	private void Awake()
	{
		//IL_000c: Unknown result type (might be due to invalid IL or missing references)
		Active();
		scaleTransform.localScale = Vector3.one;
	}

	private void Update()
	{
		//IL_005d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0067: Unknown result type (might be due to invalid IL or missing references)
		//IL_0077: Unknown result type (might be due to invalid IL or missing references)
		//IL_007c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0083: Unknown result type (might be due to invalid IL or missing references)
		//IL_002b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0041: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a6: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c6: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e9: Unknown result type (might be due to invalid IL or missing references)
		//IL_0109: Unknown result type (might be due to invalid IL or missing references)
		//IL_010e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0115: Unknown result type (might be due to invalid IL or missing references)
		//IL_0121: Unknown result type (might be due to invalid IL or missing references)
		//IL_0126: Unknown result type (might be due to invalid IL or missing references)
		//IL_012d: Unknown result type (might be due to invalid IL or missing references)
		//IL_012e: Unknown result type (might be due to invalid IL or missing references)
		//IL_013a: Unknown result type (might be due to invalid IL or missing references)
		if (scaleLerp < 1f)
		{
			scaleLerp += Time.deltaTime * 1f;
			scaleTransform.localScale = Vector3.one * scaleCurve.Evaluate(scaleLerp);
		}
		springTransform.rotation = SemiFunc.SpringQuaternionGet(spring, ((Component)this).transform.rotation);
		Vector3 localEulerAngles = springTransform.localEulerAngles;
		if (springTransform.localEulerAngles.x > 180f)
		{
			localEulerAngles.x -= 360f;
		}
		localEulerAngles.x = Mathf.Clamp(localEulerAngles.x, -360f, 15f);
		if (springTransform.localEulerAngles.z > 180f)
		{
			localEulerAngles.z -= 360f;
		}
		localEulerAngles.z = Mathf.Clamp(localEulerAngles.z, -10f, 10f);
		Quaternion localRotation = springTransform.localRotation;
		springTransform.localEulerAngles = localEulerAngles;
		Quaternion localRotation2 = springTransform.localRotation;
		springTransform.localRotation = Quaternion.Slerp(localRotation, localRotation2, 200f * Time.deltaTime);
		activeTimer -= Time.deltaTime;
		if (activeTimer <= 0f)
		{
			Object.Destroy((Object)(object)((Component)this).gameObject);
		}
	}

	public void Active()
	{
		activeTimer = 0.25f;
	}

	public void ActiveReset()
	{
		activeTimer = 0f;
	}
}
