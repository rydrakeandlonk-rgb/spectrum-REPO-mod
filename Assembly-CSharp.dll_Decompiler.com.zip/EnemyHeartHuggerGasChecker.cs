using System.Collections.Generic;
using UnityEngine;

public class EnemyHeartHuggerGasChecker : MonoBehaviour
{
	internal EnemyHeartHugger enemyHeartHugger;

	internal Vector3 velocity;

	internal float lifeTimeCurrent;

	internal float lifeTimeMax;

	public AnimationCurve scaleOverLifeTime;

	private float perlinSetting1;

	private float perlinSetting2;

	internal float scaleTarget;

	private List<PlayerAvatar> playersColliding = new List<PlayerAvatar>();

	private float checkTimer;

	private Vector3 prevCheckPos;

	public GameObject gasGuider;

	private void Start()
	{
		//IL_0007: Unknown result type (might be due to invalid IL or missing references)
		//IL_000c: Unknown result type (might be due to invalid IL or missing references)
		prevCheckPos = ((Component)this).transform.position;
		perlinSetting1 = Random.Range(0.2f, 3f);
		perlinSetting2 = Random.Range(0.5f, 4f);
	}

	private void Update()
	{
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0073: Unknown result type (might be due to invalid IL or missing references)
		//IL_007d: Unknown result type (might be due to invalid IL or missing references)
		//IL_008f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0094: Unknown result type (might be due to invalid IL or missing references)
		//IL_0104: Unknown result type (might be due to invalid IL or missing references)
		//IL_0115: Unknown result type (might be due to invalid IL or missing references)
		//IL_019f: Unknown result type (might be due to invalid IL or missing references)
		//IL_01b7: Unknown result type (might be due to invalid IL or missing references)
		//IL_01bd: Unknown result type (might be due to invalid IL or missing references)
		//IL_01c2: Unknown result type (might be due to invalid IL or missing references)
		//IL_01c7: Unknown result type (might be due to invalid IL or missing references)
		//IL_01cb: Unknown result type (might be due to invalid IL or missing references)
		//IL_01d0: Unknown result type (might be due to invalid IL or missing references)
		//IL_01d3: Unknown result type (might be due to invalid IL or missing references)
		//IL_01de: Unknown result type (might be due to invalid IL or missing references)
		//IL_01eb: Unknown result type (might be due to invalid IL or missing references)
		//IL_01f8: Unknown result type (might be due to invalid IL or missing references)
		//IL_0244: Unknown result type (might be due to invalid IL or missing references)
		//IL_024b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0219: Unknown result type (might be due to invalid IL or missing references)
		//IL_021e: Unknown result type (might be due to invalid IL or missing references)
		//IL_022b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0230: Unknown result type (might be due to invalid IL or missing references)
		//IL_0234: Unknown result type (might be due to invalid IL or missing references)
		//IL_0239: Unknown result type (might be due to invalid IL or missing references)
		//IL_027d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0282: Unknown result type (might be due to invalid IL or missing references)
		//IL_0462: Unknown result type (might be due to invalid IL or missing references)
		//IL_0467: Unknown result type (might be due to invalid IL or missing references)
		//IL_032a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0344: Unknown result type (might be due to invalid IL or missing references)
		//IL_0349: Unknown result type (might be due to invalid IL or missing references)
		//IL_034e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0365: Unknown result type (might be due to invalid IL or missing references)
		//IL_036a: Unknown result type (might be due to invalid IL or missing references)
		//IL_03d2: Unknown result type (might be due to invalid IL or missing references)
		//IL_03d7: Unknown result type (might be due to invalid IL or missing references)
		//IL_0421: Unknown result type (might be due to invalid IL or missing references)
		//IL_0426: Unknown result type (might be due to invalid IL or missing references)
		if (!SemiFunc.IsMasterClientOrSingleplayer() || !Object.op_Implicit((Object)(object)enemyHeartHugger) || !enemyHeartHugger.enemy.EnemyParent.Spawned || enemyHeartHugger.enemy.Health.dead)
		{
			Object.Destroy((Object)(object)((Component)this).gameObject);
			return;
		}
		float num = Mathf.PerlinNoise(Time.time * perlinSetting1, perlinSetting2);
		Transform transform = ((Component)this).transform;
		transform.position += velocity * Time.deltaTime * (1f + num * 0.5f);
		if (lifeTimeCurrent < lifeTimeMax)
		{
			float num2 = lifeTimeCurrent / lifeTimeMax;
			float num3 = 1f;
			if (velocity.magnitude <= 0f)
			{
				num3 = 5f;
			}
			lifeTimeCurrent += Time.deltaTime * num3;
			((Component)this).transform.localScale = new Vector3(scaleTarget, scaleTarget, scaleTarget) * scaleOverLifeTime.Evaluate(num2);
			foreach (PlayerAvatar item in playersColliding)
			{
				if (Object.op_Implicit((Object)(object)item))
				{
					enemyHeartHugger.PlayerInGas(item);
				}
			}
			if (checkTimer <= 0f)
			{
				checkTimer = 1f;
				playersColliding.Clear();
				float num4 = ((Component)this).transform.localScale.z * 0.5f;
				Vector3 val = ((Component)this).transform.position - prevCheckPos;
				Vector3 normalized = val.normalized;
				float num5 = Vector3.Distance(prevCheckPos, ((Component)this).transform.position);
				RaycastHit val2 = default;
				if (Physics.SphereCast(prevCheckPos, num4 * 0.75f, normalized, ref val2, num5, LayerMask.GetMask(new string[1] { "Default" })))
				{
					velocity = Vector3.zero;
					((Component)this).transform.position = val2.point + normalized * num4;
				}
				RaycastHit[] array = Physics.SphereCastAll(prevCheckPos, num4, normalized, num5, LayerMask.GetMask(new string[2] { "Player", "PhysGrabObject" }));
				for (int i = 0; i < array.Length; i++)
				{
					RaycastHit val3 = array[i];
					PlayerController componentInParent = ((Component)val3.collider).GetComponentInParent<PlayerController>();
					PlayerAvatar playerAvatar;
					if (Object.op_Implicit((Object)(object)componentInParent))
					{
						playerAvatar = componentInParent.playerAvatarScript;
					}
					else
					{
						playerAvatar = ((Component)val3.collider).GetComponentInParent<PlayerAvatar>();
						if (!Object.op_Implicit((Object)(object)playerAvatar))
						{
							PlayerTumble componentInParent2 = ((Component)val3.collider).GetComponentInParent<PlayerTumble>();
							if (Object.op_Implicit((Object)(object)componentInParent2))
							{
								playerAvatar = componentInParent2.playerAvatar;
							}
						}
					}
					if (Object.op_Implicit((Object)(object)playerAvatar) && Object.op_Implicit((Object)(object)playerAvatar.tumble) && !enemyHeartHugger.PlayerIsOnCooldown(playerAvatar) && !enemyHeartHugger.PlayerInGasCheck(playerAvatar))
					{
						Vector3 val4 = playerAvatar.PlayerVisionTarget.VisionTransform.position - enemyHeartHugger.enemy.Vision.VisionTransform.position;
						if (!Physics.Raycast(enemyHeartHugger.enemy.Vision.VisionTransform.position, val4, val4.magnitude, LayerMask.GetMask(new string[1] { "Default" }), (QueryTriggerInteraction)1))
						{
							playerAvatar.tumble.TumbleRequest(_isTumbling: true, _playerInput: false);
							playersColliding.Add(playerAvatar);
							enemyHeartHugger.PlayerInGas(playerAvatar);
							playerAvatar.OverrideTumbleWings(pink: true, 1f);
							GameObject val5 = Object.Instantiate<GameObject>(gasGuider, ((Component)this).transform.position, Quaternion.identity);
							EnemyHeartHuggerGasGuider component = val5.GetComponent<EnemyHeartHuggerGasGuider>();
							component.playerTumble = playerAvatar.tumble;
							component.targetTransform = ((Component)playerAvatar).transform;
							component.enemyHeartHugger = enemyHeartHugger;
							component.headTransform = enemyHeartHugger.headCenterTransform;
							component.startPosition = val3.point;
							component.physGrabObject = playerAvatar.tumble.physGrabObject;
							component.player = playerAvatar;
							val5.SetActive(true);
						}
					}
				}
				prevCheckPos = ((Component)this).transform.position;
			}
			else
			{
				checkTimer -= Time.deltaTime;
			}
		}
		else
		{
			Object.Destroy((Object)(object)((Component)this).gameObject);
		}
	}
}
