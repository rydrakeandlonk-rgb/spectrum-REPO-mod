using System;
using System.Collections.Generic;
using UnityEngine;

[ExecuteAlways]
public class BotSystemSpringPoseAnimatorPose : MonoBehaviour
{
	[Serializable]
	public class BoneOffset
	{
		public Transform bone;

		public Transform linkedMainRigBone;

		public Quaternion targetWorldRotation;

		public Vector3 offsetEuler;

		public Transform idleOffsetTransform;

		public float amount = 1f;

		public bool additive = true;

		[Range(0f, 1f)]
		public float curveOffset;

		[HideInInspector]
		public int[] childIndexPath;

		[HideInInspector]
		public int[] mainRigBoneChildIndexPath;

		[SerializeField]
		[HideInInspector]
		public string indexPath;

		[SerializeField]
		[HideInInspector]
		public string nameOrdinalPath;
	}

	public string poseName = "Untitled";

	[Tooltip("multiplies the animator's spring speed while this pose is active")]
	public float springSpeedMultiplier = 1f;

	[Tooltip("multiplies the animator's spring damping while this pose is active")]
	public float springDampingMultiplier = 1f;

	public BotSystemSpringPoseAnimator sourceAnimator;

	[Tooltip("curves that drive the idle motion. the animator spreads bones across them (sequential or random).")]
	public List<AnimationCurve> idleCurves = new List<AnimationCurve> { AnimationCurve.Linear(0f, 0f, 1f, 1f) };

	public float idleSpeed = 1f;

	public bool loop = true;

	public List<BoneOffset> boneOffsets = new List<BoneOffset>();

	private Dictionary<Transform, BoneOffset> boneDataByBoneCache;

	private Dictionary<Transform, BoneOffset> boneDataByMainCache;

	private Dictionary<string, BoneOffset> boneDataByNameCache;

	public void InvalidateBoneDataCache()
	{
		boneDataByBoneCache = null;
		boneDataByMainCache = null;
		boneDataByNameCache = null;
	}

	private void BuildBoneDataCache()
	{
		boneDataByBoneCache = new Dictionary<Transform, BoneOffset>(boneOffsets.Count);
		boneDataByMainCache = new Dictionary<Transform, BoneOffset>(boneOffsets.Count);
		boneDataByNameCache = new Dictionary<string, BoneOffset>(boneOffsets.Count);
		for (int i = 0; i < boneOffsets.Count; i++)
		{
			BoneOffset boneOffset = boneOffsets[i];
			if (boneOffset != null && !((Object)(object)boneOffset.bone == (Object)null))
			{
				if (!boneDataByBoneCache.ContainsKey(boneOffset.bone))
				{
					boneDataByBoneCache[boneOffset.bone] = boneOffset;
				}
				if (Object.op_Implicit((Object)(object)boneOffset.linkedMainRigBone) && !boneDataByMainCache.ContainsKey(boneOffset.linkedMainRigBone))
				{
					boneDataByMainCache[boneOffset.linkedMainRigBone] = boneOffset;
				}
				if (!boneDataByNameCache.ContainsKey(((Object)boneOffset.bone).name))
				{
					boneDataByNameCache[((Object)boneOffset.bone).name] = boneOffset;
				}
			}
		}
	}

	public void BuildPoseMaps(out Dictionary<string, Transform> _byIndex, out Dictionary<string, Transform> _byNameOrd)
	{
		_byIndex = new Dictionary<string, Transform>(1024);
		_byNameOrd = new Dictionary<string, Transform>(1024);
		Transform transform = ((Component)this).transform;
		WalkBuildPoseMaps(transform, "", "ROOT[0]", _byIndex, _byNameOrd);
	}

	private void WalkBuildPoseMaps(Transform _t, string _idxPath, string _nameOrdPath, Dictionary<string, Transform> _byIndex, Dictionary<string, Transform> _byNameOrd)
	{
		BoneOffset boneData = GetBoneData(_t);
		if (boneData != null && !string.IsNullOrEmpty(boneData.indexPath))
		{
			_byIndex[boneData.indexPath] = _t;
			if (!string.IsNullOrEmpty(boneData.nameOrdinalPath))
			{
				_byNameOrd[boneData.nameOrdinalPath] = _t;
			}
		}
		else
		{
			if (!_byIndex.ContainsKey(_idxPath))
			{
				_byIndex[_idxPath] = _t;
			}
			if (!_byNameOrd.ContainsKey(_nameOrdPath))
			{
				_byNameOrd[_nameOrdPath] = _t;
			}
		}
		Dictionary<string, int> dictionary = new Dictionary<string, int>(_t.childCount);
		for (int i = 0; i < _t.childCount; i++)
		{
			Transform child = _t.GetChild(i);
			dictionary.TryGetValue(((Object)child).name, out var value);
			dictionary[((Object)child).name] = value + 1;
			string idxPath = (string.IsNullOrEmpty(_idxPath) ? i.ToString() : $"{_idxPath}/{i}");
			string nameOrdPath = $"{_nameOrdPath}/{((Object)child).name}[{value}]";
			WalkBuildPoseMaps(child, idxPath, nameOrdPath, _byIndex, _byNameOrd);
		}
	}

	public void GetIdsForPoseBone(Transform _t, out string _idx, out string _nameOrd)
	{
		BoneOffset boneData = GetBoneData(_t);
		if (boneData != null)
		{
			_idx = boneData.indexPath;
			_nameOrd = boneData.nameOrdinalPath;
			return;
		}
		_idx = "";
		_nameOrd = "ROOT[0]";
		List<Transform> list = new List<Transform>();
		Transform val = _t;
		while (Object.op_Implicit((Object)(object)val) && (Object)(object)val != (Object)(object)((Component)this).transform)
		{
			list.Add(val);
			val = val.parent;
		}
		list.Reverse();
		string text = "";
		string text2 = "ROOT[0]";
		foreach (Transform item in list)
		{
			int siblingIndex = item.GetSiblingIndex();
			text = (string.IsNullOrEmpty(text) ? siblingIndex.ToString() : $"{text}/{siblingIndex}");
			int num = 0;
			for (int i = 0; i < siblingIndex; i++)
			{
				if (((Object)item.parent.GetChild(i)).name == ((Object)item).name)
				{
					num++;
				}
			}
			text2 = $"{text2}/{((Object)item).name}[{num}]";
		}
		_idx = text;
		_nameOrd = text2;
	}

	public BoneOffset GetBoneData(Transform _t)
	{
		if ((Object)(object)_t == (Object)null)
		{
			return null;
		}
		if (Application.isPlaying)
		{
			if (boneDataByBoneCache == null)
			{
				BuildBoneDataCache();
			}
			boneDataByBoneCache.TryGetValue(_t, out var value);
			return value;
		}
		for (int i = 0; i < boneOffsets.Count; i++)
		{
			if (!((Object)(object)boneOffsets[i].bone == (Object)null) && (Object)(object)boneOffsets[i].bone == (Object)(object)_t)
			{
				return boneOffsets[i];
			}
		}
		return null;
	}

	public BoneOffset GetBoneDataByName(Transform _t)
	{
		if ((Object)(object)_t == (Object)null)
		{
			return null;
		}
		for (int i = 0; i < boneOffsets.Count; i++)
		{
			if (!((Object)(object)boneOffsets[i].bone == (Object)null) && ((Object)boneOffsets[i].bone).name == ((Object)_t).name)
			{
				return boneOffsets[i];
			}
		}
		return null;
	}

	public BoneOffset GetBoneDataForMain(Transform _mainBone)
	{
		if (!Object.op_Implicit((Object)(object)_mainBone))
		{
			return null;
		}
		if (Application.isPlaying)
		{
			if (boneDataByMainCache == null)
			{
				BuildBoneDataCache();
			}
			if (boneDataByMainCache.TryGetValue(_mainBone, out var value))
			{
				return value;
			}
			boneDataByNameCache.TryGetValue(((Object)_mainBone).name, out var value2);
			return value2;
		}
		for (int i = 0; i < boneOffsets.Count; i++)
		{
			if ((Object)(object)boneOffsets[i].linkedMainRigBone == (Object)(object)_mainBone)
			{
				return boneOffsets[i];
			}
		}
		for (int j = 0; j < boneOffsets.Count; j++)
		{
			if (Object.op_Implicit((Object)(object)boneOffsets[j].bone) && ((Object)boneOffsets[j].bone).name == ((Object)_mainBone).name)
			{
				return boneOffsets[j];
			}
		}
		return null;
	}

	public float GetCurveEval(int _curveIndex, float _time)
	{
		return GetCurveEval(_curveIndex, _time, 0f);
	}

	public float GetCurveEval(int _curveIndex, float _time, float _offset)
	{
		if (idleCurves == null || idleCurves.Count == 0)
		{
			return 0f;
		}
		if (_curveIndex < 0 || _curveIndex >= idleCurves.Count)
		{
			_curveIndex = 0;
		}
		AnimationCurve val = idleCurves[_curveIndex];
		float num = ((idleSpeed <= 0.0001f) ? 0f : (_time * idleSpeed));
		num += _offset;
		if (loop)
		{
			num = Mathf.Repeat(num, 1f);
		}
		return val.Evaluate(num);
	}

	public int GetCurveIndexForBone(int _i)
	{
		if (idleCurves == null || idleCurves.Count == 0)
		{
			return 0;
		}
		if (boneOffsets == null || boneOffsets.Count == 0)
		{
			return 0;
		}
		return Mathf.Abs(_i) % idleCurves.Count;
	}

	public int GetRandomCurveIndex(Random _rng)
	{
		if (idleCurves == null || idleCurves.Count == 0)
		{
			return 0;
		}
		return _rng.Next(0, idleCurves.Count);
	}
}
