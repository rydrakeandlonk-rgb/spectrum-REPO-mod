using UnityEngine;

public class DirtFinderMapFloor : MonoBehaviour
{
	public enum FloorType
	{
		Floor_1x1,
		Floor_1x1_Diagonal,
		Floor_1x05,
		Floor_1x025,
		Floor_1x05_Diagonal,
		Floor_1x025_Diagonal,
		Truck_Floor,
		Truck_Wall,
		Used_Floor,
		Used_Wall,
		Inactive_Floor,
		Inactive_Wall,
		Floor_1x1_Curve,
		Floor_1x1_Curve_Inverted,
		Floor_1x05_Curve,
		Floor_1x05_Curve_Inverted,
		Floor_Stairs
	}

	public FloorType Type;

	internal MapObject MapObject;

	private void Start()
	{
		Map.Instance.GenerationAdd((Component)(object)this);
	}

	private void OnDisable()
	{
		if (!((Component)this).gameObject.activeInHierarchy && Object.op_Implicit((Object)(object)Map.Instance))
		{
			Map.Instance.GenerationRemove((Component)(object)this);
		}
	}
}
