using Photon.Pun;
using UnityEngine;

public class PlayerLocalCamera : MonoBehaviour, IPunObservable
{
	private PhotonView photonView;

	private Vector3 clientPosition;

	private Quaternion clientRotation;

	private bool teleported;

	public PlayerAvatar playerAvatar;

	private bool clientPositionOverride;

	private readonly SemiNetPackedStream networkFallbackCameraStream = new SemiNetPackedStream(40);

	private Vector3 networkFallbackCameraViewPosition;

	private bool networkFallbackCameraActive;

	private bool networkFallbackCameraReady;

	private bool networkFallbackCameraStateValid;

	private bool networkFallbackCameraHeartbeat;

	private float networkFallbackCameraHeartbeatTime;

	private ushort networkVoicePing;

	private byte networkFallbackCameraTeleportSequence;

	private bool clientFallbackCameraActive;

	private bool clientFallbackCameraReady;

	private byte clientFallbackCameraTeleportSequence;

	private bool clientFallbackCameraTeleportSequenceInitialized;

	private int cameraPositionTransitionRevision;

	private Vector3 cameraPositionTransitionTarget;

	private float cameraPositionTransitionReadyExpireTime;

	private bool cameraPositionTransitionReadyPending;

	private Vector3 previousPosition;

	internal float positionVelocity;

	internal byte CameraCullingTeleportSequence
	{
		get
		{
			if (!Object.op_Implicit((Object)(object)photonView) || !photonView.IsMine)
			{
				return clientFallbackCameraTeleportSequence;
			}
			return networkFallbackCameraTeleportSequence;
		}
	}

	internal bool CameraFallbackReady
	{
		get
		{
			if (!Object.op_Implicit((Object)(object)playerAvatar))
			{
				return false;
			}
			if (!SemiFunc.IsMultiplayer())
			{
				if (playerAvatar.deadSet)
				{
					if (playerAvatar.spectating && Object.op_Implicit((Object)(object)SpectateCamera.instance))
					{
						return SpectateCamera.instance.CameraCullingReady;
					}
					return false;
				}
				return true;
			}
			if (!Object.op_Implicit((Object)(object)photonView))
			{
				return false;
			}
			if (photonView.IsMine)
			{
				if (networkFallbackCameraActive && networkFallbackCameraReady)
				{
					return networkFallbackCameraStateValid;
				}
				return false;
			}
			float _age;
			if (clientFallbackCameraActive && clientFallbackCameraReady)
			{
				return SemiFunc.PlayerCameraStateAgeGet(playerAvatar, out _age);
			}
			return false;
		}
	}

	private void Awake()
	{
		photonView = ((Component)this).GetComponent<PhotonView>();
	}

	private void Update()
	{
		//IL_0101: Unknown result type (might be due to invalid IL or missing references)
		//IL_011b: Unknown result type (might be due to invalid IL or missing references)
		//IL_012c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0132: Unknown result type (might be due to invalid IL or missing references)
		//IL_014e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0153: Unknown result type (might be due to invalid IL or missing references)
		//IL_004f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0055: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0033: Unknown result type (might be due to invalid IL or missing references)
		//IL_003f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0044: Unknown result type (might be due to invalid IL or missing references)
		//IL_0075: Unknown result type (might be due to invalid IL or missing references)
		//IL_0086: Unknown result type (might be due to invalid IL or missing references)
		//IL_009c: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a2: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b2: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c8: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ce: Unknown result type (might be due to invalid IL or missing references)
		//IL_00de: Unknown result type (might be due to invalid IL or missing references)
		if (SemiFunc.IsMultiplayer() && !photonView.IsMine)
		{
			if (Object.op_Implicit((Object)(object)playerAvatar))
			{
				clientPosition = playerAvatar.clientCameraPosition;
				clientRotation = playerAvatar.clientCameraRotation;
			}
			if (Vector3.Distance(((Component)this).transform.position, clientPosition) > 10f || teleported)
			{
				((Component)this).transform.position = clientPosition;
				((Component)this).transform.rotation = clientRotation;
			}
			((Component)this).transform.position = Vector3.Lerp(((Component)this).transform.position, clientPosition, 20f * Time.deltaTime);
			((Component)this).transform.rotation = Quaternion.Lerp(((Component)this).transform.rotation, clientRotation, 20f * Time.deltaTime);
			teleported = false;
		}
		else
		{
			((Component)this).transform.position = ((Component)CameraNoise.Instance).transform.position;
			((Component)this).transform.rotation = ((Component)CameraNoise.Instance).transform.rotation;
		}
		positionVelocity = Vector3.Distance(((Component)this).transform.position, previousPosition) / Time.deltaTime;
		previousPosition = ((Component)this).transform.position;
	}

	private void LateUpdate()
	{
		if (!SemiFunc.IsMultiplayer() || (Object.op_Implicit((Object)(object)photonView) && photonView.IsMine))
		{
			SemiFunc.PlayerCameraVisibilityRefresh();
			CameraPositionTransitionReadyTick();
		}
	}

	public Transform GetOverrideTransform()
	{
		if (GetOverrideActive())
		{
			return playerAvatar.PlayerVisionTarget.VisionTransform;
		}
		return ((Component)this).transform;
	}

	public bool GetOverrideActive()
	{
		if (!clientPositionOverride)
		{
			if (playerAvatar.isLocal && Object.op_Implicit((Object)(object)CameraPosition.instance))
			{
				return CameraPosition.instance.overridePositionActive;
			}
			return false;
		}
		return true;
	}

	private bool CameraFallbackActiveGet()
	{
		if (!Object.op_Implicit((Object)(object)playerAvatar))
		{
			return false;
		}
		if (((Behaviour)playerAvatar).isActiveAndEnabled && ((Component)playerAvatar).gameObject.activeInHierarchy && !playerAvatar.deadSet && !playerAvatar.isDisabled)
		{
			return playerAvatar.spectating;
		}
		return true;
	}

	private bool CameraFallbackReadyGet(bool _fallbackActive)
	{
		if (!_fallbackActive || !Object.op_Implicit((Object)(object)playerAvatar))
		{
			return false;
		}
		if (playerAvatar.deadSet)
		{
			if (playerAvatar.spectating && Object.op_Implicit((Object)(object)SpectateCamera.instance))
			{
				return SpectateCamera.instance.CameraCullingReady;
			}
			return false;
		}
		return true;
	}

	private int CameraPositionTransitionSourceGet()
	{
		if (SemiFunc.IsMultiplayer())
		{
			if (!Object.op_Implicit((Object)(object)photonView))
			{
				return 0;
			}
			return -photonView.ViewID;
		}
		return ((Object)this).GetInstanceID();
	}

	internal void CameraPositionTransitionStart(Vector3 _position)
	{
		//IL_0063: Unknown result type (might be due to invalid IL or missing references)
		//IL_0070: Unknown result type (might be due to invalid IL or missing references)
		//IL_007d: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e2: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e3: Unknown result type (might be due to invalid IL or missing references)
		//IL_0101: Unknown result type (might be due to invalid IL or missing references)
		//IL_0128: Unknown result type (might be due to invalid IL or missing references)
		if (Object.op_Implicit((Object)(object)playerAvatar) && playerAvatar.isLocal && ((Behaviour)playerAvatar).isActiveAndEnabled && ((Component)playerAvatar).gameObject.activeInHierarchy && !playerAvatar.deadSet && !playerAvatar.isDisabled && !playerAvatar.spectating && float.IsFinite(_position.x) && float.IsFinite(_position.y) && float.IsFinite(_position.z) && !(_position.sqrMagnitude > 1000000f) && (!SemiFunc.IsMultiplayer() || (Object.op_Implicit((Object)(object)photonView) && photonView.IsMine)) && CameraPositionTransitionSourceGet() != 0)
		{
			cameraPositionTransitionRevision++;
			if (cameraPositionTransitionRevision == 0)
			{
				cameraPositionTransitionRevision = 1;
			}
			cameraPositionTransitionTarget = _position;
			cameraPositionTransitionReadyExpireTime = Time.unscaledTime + 3f;
			cameraPositionTransitionReadyPending = true;
			CameraPositionTransitionStartApply(_position, cameraPositionTransitionRevision);
			if (SemiFunc.IsMultiplayer())
			{
				photonView.RPC("CameraPositionTransitionStartRPC", (RpcTarget)1, new object[2] { _position, cameraPositionTransitionRevision });
			}
		}
	}

	private void CameraPositionTransitionStartApply(Vector3 _position, int _transitionRevision)
	{
		//IL_0022: Unknown result type (might be due to invalid IL or missing references)
		int num = CameraPositionTransitionSourceGet();
		if (Object.op_Implicit((Object)(object)playerAvatar) && num != 0 && _transitionRevision != 0)
		{
			SemiFunc.PlayerCameraAnyTransitionStart(playerAvatar, (Object)(object)this, _position, 3f, num, _transitionRevision);
		}
	}

	[PunRPC]
	private void CameraPositionTransitionStartRPC(Vector3 _position, int _transitionRevision, PhotonMessageInfo _info = default(PhotonMessageInfo))
	{
		//IL_0000: Unknown result type (might be due to invalid IL or missing references)
		//IL_0010: Unknown result type (might be due to invalid IL or missing references)
		if (SemiFunc.OwnerOnlyRPC(_info, photonView))
		{
			CameraPositionTransitionStartApply(_position, _transitionRevision);
		}
	}

	private void CameraPositionTransitionReadyTick()
	{
		//IL_002a: Unknown result type (might be due to invalid IL or missing references)
		//IL_002c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0031: Unknown result type (might be due to invalid IL or missing references)
		//IL_0036: Unknown result type (might be due to invalid IL or missing references)
		if (!cameraPositionTransitionReadyPending)
		{
			return;
		}
		Vector3 _position;
		float _visibilityDistance;
		if (Time.unscaledTime > cameraPositionTransitionReadyExpireTime)
		{
			cameraPositionTransitionReadyPending = false;
		}
		else if (SemiFunc.PlayerCameraLocalViewGet(out _position, out _visibilityDistance))
		{
			Vector3 val = _position - cameraPositionTransitionTarget;
			if (!(val.sqrMagnitude > 25f))
			{
				cameraPositionTransitionReadyPending = false;
				CameraCullingTransitionReady(CameraPositionTransitionSourceGet(), cameraPositionTransitionRevision);
			}
		}
	}

	public void CameraCullingTransitionReady(int _transitionSource, int _transitionRevision)
	{
		//IL_0092: Unknown result type (might be due to invalid IL or missing references)
		//IL_0064: Unknown result type (might be due to invalid IL or missing references)
		if (!Object.op_Implicit((Object)(object)playerAvatar) || _transitionSource == 0 || _transitionRevision == 0)
		{
			return;
		}
		if (SemiFunc.IsMultiplayer())
		{
			if (!Object.op_Implicit((Object)(object)photonView) || !photonView.IsMine)
			{
				return;
			}
		}
		else if (!playerAvatar.isLocal)
		{
			return;
		}
		SemiFunc.PlayerCameraVisibilityRefresh();
		if (SemiFunc.PlayerCameraLocalViewGet(out var _position, out var _visibilityDistance))
		{
			if (!SemiFunc.IsMultiplayer())
			{
				SemiFunc.PlayerCameraAnyTransitionReady(playerAvatar, _transitionSource, _transitionRevision, _position, _visibilityDistance);
				return;
			}
			photonView.RPC("CameraCullingTransitionReadyRPC", (RpcTarget)0, new object[4] { _transitionSource, _transitionRevision, _position, _visibilityDistance });
		}
	}

	[PunRPC]
	private void CameraCullingTransitionReadyRPC(int _transitionSource, int _transitionRevision, Vector3 _position, float _visibilityDistance, PhotonMessageInfo _info = default(PhotonMessageInfo))
	{
		//IL_0000: Unknown result type (might be due to invalid IL or missing references)
		//IL_0018: Unknown result type (might be due to invalid IL or missing references)
		if (SemiFunc.OwnerOnlyRPC(_info, photonView))
		{
			SemiFunc.PlayerCameraAnyTransitionReady(playerAvatar, _transitionSource, _transitionRevision, _position, _visibilityDistance);
		}
	}

	public void OnPhotonSerializeView(PhotonStream stream, PhotonMessageInfo info)
	{
		//IL_0017: Unknown result type (might be due to invalid IL or missing references)
		//IL_0443: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b7: Unknown result type (might be due to invalid IL or missing references)
		//IL_00bc: Unknown result type (might be due to invalid IL or missing references)
		//IL_00be: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c5: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ca: Unknown result type (might be due to invalid IL or missing references)
		//IL_010d: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f8: Unknown result type (might be due to invalid IL or missing references)
		//IL_00fd: Unknown result type (might be due to invalid IL or missing references)
		//IL_0106: Unknown result type (might be due to invalid IL or missing references)
		//IL_010b: Unknown result type (might be due to invalid IL or missing references)
		//IL_011b: Unknown result type (might be due to invalid IL or missing references)
		//IL_04af: Unknown result type (might be due to invalid IL or missing references)
		//IL_04b4: Unknown result type (might be due to invalid IL or missing references)
		//IL_04b6: Unknown result type (might be due to invalid IL or missing references)
		//IL_04bb: Unknown result type (might be due to invalid IL or missing references)
		//IL_04bd: Unknown result type (might be due to invalid IL or missing references)
		//IL_04c2: Unknown result type (might be due to invalid IL or missing references)
		//IL_014d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0129: Unknown result type (might be due to invalid IL or missing references)
		//IL_04d5: Unknown result type (might be due to invalid IL or missing references)
		//IL_04da: Unknown result type (might be due to invalid IL or missing references)
		//IL_04de: Unknown result type (might be due to invalid IL or missing references)
		//IL_04e3: Unknown result type (might be due to invalid IL or missing references)
		//IL_015b: Unknown result type (might be due to invalid IL or missing references)
		//IL_04f4: Unknown result type (might be due to invalid IL or missing references)
		//IL_04f9: Unknown result type (might be due to invalid IL or missing references)
		//IL_0169: Unknown result type (might be due to invalid IL or missing references)
		//IL_0515: Unknown result type (might be due to invalid IL or missing references)
		//IL_0177: Unknown result type (might be due to invalid IL or missing references)
		//IL_0523: Unknown result type (might be due to invalid IL or missing references)
		//IL_0185: Unknown result type (might be due to invalid IL or missing references)
		//IL_0187: Unknown result type (might be due to invalid IL or missing references)
		//IL_0555: Unknown result type (might be due to invalid IL or missing references)
		//IL_0531: Unknown result type (might be due to invalid IL or missing references)
		//IL_01bf: Unknown result type (might be due to invalid IL or missing references)
		//IL_01c4: Unknown result type (might be due to invalid IL or missing references)
		//IL_01c6: Unknown result type (might be due to invalid IL or missing references)
		//IL_01cb: Unknown result type (might be due to invalid IL or missing references)
		//IL_0563: Unknown result type (might be due to invalid IL or missing references)
		//IL_01d1: Unknown result type (might be due to invalid IL or missing references)
		//IL_01d6: Unknown result type (might be due to invalid IL or missing references)
		//IL_05a2: Unknown result type (might be due to invalid IL or missing references)
		//IL_0571: Unknown result type (might be due to invalid IL or missing references)
		//IL_05b0: Unknown result type (might be due to invalid IL or missing references)
		//IL_057f: Unknown result type (might be due to invalid IL or missing references)
		//IL_01eb: Unknown result type (might be due to invalid IL or missing references)
		//IL_01ee: Unknown result type (might be due to invalid IL or missing references)
		//IL_01f3: Unknown result type (might be due to invalid IL or missing references)
		//IL_01f8: Unknown result type (might be due to invalid IL or missing references)
		//IL_05be: Unknown result type (might be due to invalid IL or missing references)
		//IL_058d: Unknown result type (might be due to invalid IL or missing references)
		//IL_058f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0264: Unknown result type (might be due to invalid IL or missing references)
		//IL_0266: Unknown result type (might be due to invalid IL or missing references)
		//IL_02cb: Unknown result type (might be due to invalid IL or missing references)
		//IL_06ae: Unknown result type (might be due to invalid IL or missing references)
		//IL_06b6: Unknown result type (might be due to invalid IL or missing references)
		//IL_06bb: Unknown result type (might be due to invalid IL or missing references)
		//IL_06c0: Unknown result type (might be due to invalid IL or missing references)
		//IL_073d: Unknown result type (might be due to invalid IL or missing references)
		//IL_073e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0769: Unknown result type (might be due to invalid IL or missing references)
		//IL_076b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0776: Unknown result type (might be due to invalid IL or missing references)
		//IL_0778: Unknown result type (might be due to invalid IL or missing references)
		//IL_0787: Unknown result type (might be due to invalid IL or missing references)
		//IL_0789: Unknown result type (might be due to invalid IL or missing references)
		//IL_0374: Unknown result type (might be due to invalid IL or missing references)
		//IL_0376: Unknown result type (might be due to invalid IL or missing references)
		//IL_03fe: Unknown result type (might be due to invalid IL or missing references)
		//IL_040c: Unknown result type (might be due to invalid IL or missing references)
		//IL_041d: Unknown result type (might be due to invalid IL or missing references)
		byte[] array = (stream.IsWriting ? null : (stream.ReceiveNext() as byte[]));
		if (!SemiFunc.MasterAndOwnerOnlyRPC(info, photonView))
		{
			return;
		}
		Vector3 val3;
		if (stream.IsWriting)
		{
			if (!photonView.IsMine || photonView.Owner == null || photonView.Owner != PhotonNetwork.LocalPlayer)
			{
				networkFallbackCameraStream.Begin();
				networkFallbackCameraStream.WriteByte((byte)0);
				networkFallbackCameraStream.WriteByte((byte)0);
				networkFallbackCameraStream.WriteUInt16((ushort)0);
				networkFallbackCameraStream.Send(stream);
				return;
			}
			bool flag = CameraFallbackActiveGet();
			bool flag2 = networkFallbackCameraActive;
			bool flag3 = CameraFallbackReadyGet(flag);
			bool flag4 = networkFallbackCameraReady;
			Vector3 val = Vector3.zero;
			Quaternion val2 = Quaternion.identity;
			Vector3 _position = Vector3.zero;
			float _visibilityDistance = 0f;
			bool flag5 = false;
			bool flag6 = SemiFunc.PlayerCameraLocalViewGet(out _position, out _visibilityDistance);
			CameraAim instance = CameraAim.Instance;
			if (Object.op_Implicit((Object)(object)instance))
			{
				val = ((Component)instance).transform.position;
				val2 = ((Component)instance).transform.rotation;
			}
			bool flag7 = float.IsFinite(val.x) && float.IsFinite(val.y) && float.IsFinite(val.z) && val.sqrMagnitude <= 1000000f;
			bool flag8 = float.IsFinite(val2.x) && float.IsFinite(val2.y) && float.IsFinite(val2.z) && float.IsFinite(val2.w) && Quaternion.Dot(val2, val2) > 0.0001f;
			bool num = Object.op_Implicit((Object)(object)instance) & flag7 & flag8;
			flag5 = flag6 && _visibilityDistance <= 6553.5f;
			if (!num)
			{
				val = Vector3.zero;
				val2 = Quaternion.identity;
			}
			if (!flag5)
			{
				_position = Vector3.zero;
				_visibilityDistance = 0f;
			}
			int num2;
			if (flag5 && networkFallbackCameraStateValid)
			{
				val3 = _position - networkFallbackCameraViewPosition;
				num2 = ((val3.sqrMagnitude > 25f) ? 1 : 0);
			}
			else
			{
				num2 = 0;
			}
			bool flag9 = (byte)num2 != 0;
			if ((flag != flag2 || flag3 != flag4 || flag5 != networkFallbackCameraStateValid) | flag9)
			{
				Teleported();
			}
			if (NetworkTeleportedConsume())
			{
				networkFallbackCameraTeleportSequence++;
				PlayerVoiceChat.VoiceTargetPlayersInvalidate();
			}
			networkFallbackCameraActive = flag;
			networkFallbackCameraReady = flag3;
			networkFallbackCameraStateValid = flag5;
			networkFallbackCameraViewPosition = _position;
			ushort num3 = PlayerVoiceChat.VoiceNetworkPingGet();
			if (Time.unscaledTime >= networkFallbackCameraHeartbeatTime)
			{
				networkFallbackCameraHeartbeatTime = Time.unscaledTime + 0.5f;
				networkFallbackCameraHeartbeat = !networkFallbackCameraHeartbeat;
				networkVoicePing = num3;
			}
			else if (num3 == 0 || networkVoicePing == 0 || num3 > networkVoicePing)
			{
				networkVoicePing = num3;
			}
			bool flag10 = flag5 && SemiNetPackedStream.PositionFullPrecisionRequired(_position);
			byte b = 0;
			if (flag10)
			{
				b |= 4;
			}
			if (flag)
			{
				b |= 1;
			}
			if (flag5)
			{
				b |= 2;
			}
			if (networkFallbackCameraHeartbeat)
			{
				b |= 8;
			}
			if (flag3)
			{
				b |= 0x10;
			}
			if (Object.op_Implicit((Object)(object)CameraPosition.instance) && CameraPosition.instance.overridePositionActive)
			{
				b |= 0x20;
			}
			if (num)
			{
				b |= 0x40;
			}
			ushort num4 = (ushort)(flag5 ? ((ushort)Mathf.Clamp(Mathf.RoundToInt(_visibilityDistance * 10f), 1, 65535)) : 0);
			if (Object.op_Implicit((Object)(object)playerAvatar))
			{
				playerAvatar.clientCameraViewPosition = _position;
				playerAvatar.clientCameraVisibilityDistance = (float)(int)num4 * 0.1f;
				playerAvatar.clientCameraStateReceiveTime = Time.unscaledTime;
				playerAvatar.clientCameraStatePacketAge = 0f;
				playerAvatar.clientCameraStateValid = flag5;
			}
			networkFallbackCameraStream.Begin();
			networkFallbackCameraStream.WriteByte(b);
			networkFallbackCameraStream.WriteByte(networkFallbackCameraTeleportSequence);
			networkFallbackCameraStream.WriteUInt16(networkVoicePing);
			if (num)
			{
				networkFallbackCameraStream.WritePosition(val, true);
				networkFallbackCameraStream.WriteRotation(val2);
			}
			if (flag5)
			{
				networkFallbackCameraStream.WritePosition(_position, flag10);
				networkFallbackCameraStream.WriteUInt16(num4);
			}
			networkFallbackCameraStream.Send(stream);
			return;
		}
		SemiNetPackedReader val4 = new SemiNetPackedReader(array);
		byte b2 = val4.ReadByte();
		int num5 = 4 + (((b2 & 0x40) != 0) ? 16 : 0);
		if ((b2 & 2) != 0)
		{
			num5 += (((b2 & 4) != 0) ? 14 : 8);
		}
		if (!val4.LengthMatches(num5))
		{
			return;
		}
		byte b3 = val4.ReadByte();
		ushort clientVoicePing = val4.ReadUInt16();
		bool flag11 = (b2 & 1) != 0;
		bool flag12 = flag11 && (b2 & 0x10) != 0;
		Vector3 val5 = Vector3.zero;
		Quaternion val6 = Quaternion.identity;
		Vector3 val7 = Vector3.zero;
		float num6 = 0f;
		if ((b2 & 0x40) != 0)
		{
			val5 = val4.ReadPosition(true);
			val6 = val4.ReadRotation();
		}
		if ((b2 & 2) != 0)
		{
			val7 = val4.ReadPosition((b2 & 4) != 0);
			num6 = (float)(int)val4.ReadUInt16() * 0.1f;
		}
		if (!val4.CompleteGet())
		{
			return;
		}
		bool flag13 = float.IsFinite(val5.x) && float.IsFinite(val5.y) && float.IsFinite(val5.z) && val5.sqrMagnitude <= 1000000f;
		bool flag14 = float.IsFinite(val6.x) && float.IsFinite(val6.y) && float.IsFinite(val6.z) && float.IsFinite(val6.w) && Quaternion.Dot(val6, val6) > 0.0001f;
		bool flag15 = float.IsFinite(val7.x) && float.IsFinite(val7.y) && float.IsFinite(val7.z) && val7.sqrMagnitude <= 1000000f;
		bool flag16 = ((b2 & 0x40) != 0) & flag13 & flag14;
		bool flag17 = (((b2 & 2) != 0) & flag15) && float.IsFinite(num6) && num6 > 0f;
		bool flag18 = Object.op_Implicit((Object)(object)playerAvatar) && playerAvatar.clientCameraStateValid;
		bool flag19 = SemiFunc.PlayerCameraStateAgeGet(playerAvatar, out var _);
		float num7 = (Object.op_Implicit((Object)(object)playerAvatar) ? playerAvatar.clientCameraVisibilityDistance : 0f);
		bool flag20 = clientFallbackCameraActive != flag11;
		bool flag21 = clientFallbackCameraReady != flag12;
		bool flag22 = clientFallbackCameraTeleportSequenceInitialized && clientFallbackCameraTeleportSequence != b3;
		int num8;
		if (Object.op_Implicit((Object)(object)playerAvatar) & flag18 & flag19 & flag17)
		{
			val3 = val7 - playerAvatar.clientCameraViewPosition;
			num8 = ((val3.sqrMagnitude > 25f) ? 1 : 0);
		}
		else
		{
			num8 = 0;
		}
		bool flag23 = (byte)num8 != 0;
		bool flag24 = Object.op_Implicit((Object)(object)playerAvatar) && flag18 != flag17;
		bool flag25 = (flag18 & flag19 & flag17) && num6 > num7 + 0.1f;
		clientFallbackCameraActive = flag11;
		clientFallbackCameraReady = flag12;
		clientFallbackCameraTeleportSequence = b3;
		clientFallbackCameraTeleportSequenceInitialized = true;
		if (Object.op_Implicit((Object)(object)playerAvatar))
		{
			SemiFunc.PlayerCameraStateReceive(playerAvatar, info, val7);
			playerAvatar.clientVoicePing = clientVoicePing;
			playerAvatar.clientCameraStateValid = flag17;
			if (flag16)
			{
				playerAvatar.clientCameraPosition = val5;
				playerAvatar.clientCameraRotation = val6;
			}
			if (flag17)
			{
				playerAvatar.clientCameraViewPosition = val7;
				playerAvatar.clientCameraVisibilityDistance = num6;
			}
			else
			{
				playerAvatar.clientCameraVisibilityDistance = 0f;
			}
		}
		ClientPositionOverrideSet((b2 & 0x20) != 0);
		if (flag20 | flag21 | flag22 | flag23)
		{
			Teleported();
			PlayerVoiceChat.VoiceTargetPlayersInvalidate();
		}
		else if (flag24 | flag25)
		{
			SemiFunc.PlayerCameraRemoteRevisionImpulse();
		}
	}

	public void ClientPositionOverrideSet(bool _active)
	{
		if (clientPositionOverride != _active)
		{
			Teleported();
		}
		clientPositionOverride = _active;
	}

	public void Teleported()
	{
		teleported = true;
		if (networkFallbackCameraActive)
		{
			networkFallbackCameraStateValid = false;
		}
		SemiFunc.PlayerCameraRevisionImpulse();
	}

	public bool NetworkTeleportedConsume()
	{
		bool result = teleported;
		teleported = false;
		return result;
	}

	private void OnDrawGizmos()
	{
		//IL_0014: Unknown result type (might be due to invalid IL or missing references)
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Unknown result type (might be due to invalid IL or missing references)
		//IL_004c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0060: Unknown result type (might be due to invalid IL or missing references)
		Gizmos.color = new Color(1f, 0f, 0.79f, 0.5f);
		Gizmos.matrix = ((Component)this).transform.localToWorldMatrix;
		Gizmos.DrawSphere(Vector3.zero, 0.1f);
		Gizmos.DrawCube(new Vector3(0f, 0f, 0.15f), new Vector3(0.1f, 0.1f, 0.3f));
	}

	public PlayerLocalCamera()
	{
		//IL_0003: Unknown result type (might be due to invalid IL or missing references)
		//IL_000d: Expected Obj, but got Unknown
	}
}
