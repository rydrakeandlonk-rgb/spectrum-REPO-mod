using System;
using System.Collections.Generic;
using System.Threading;
using UnityEngine;
using UnityEngine.Events;
using UnityEngine.UI;

public class MenuSliderMicrophone : MonoBehaviour
{
	private static MenuSliderMicrophone microphonePreviewOwner;

	private MenuSlider menuSlider;

	private MenuPage menuPage;

	public UnityEvent micEvent;

	public Image micLevelBar;

	public LocalizedAsset localizedNoneOption;

	private AudioClip microphoneClip;

	private string currentDeviceName;

	private string selectedDeviceName;

	private int currentDeviceCount;

	private int previousMicrophonePosition = -1;

	private float microphoneRetryTimer;

	private float microphoneProgressTimer;

	private int microphoneRestartPending;

	private const int sampleDataLength = 128;

	private float[] micData;

	private float micLevel;

	private float micGain = 10f;

	[RuntimeInitializeOnLoadMethod(/*Could not decode attribute arguments.*/)]
	private static void RuntimeInitializeOnLoad()
	{
		microphonePreviewOwner = null;
	}

	private void Awake()
	{
		//IL_0040: Unknown result type (might be due to invalid IL or missing references)
		//IL_004a: Expected Obj, but got Unknown
		menuSlider = ((Component)this).GetComponent<MenuSlider>();
		menuPage = ((Component)this).GetComponentInParent<MenuPage>();
		micData = new float[128];
		SetOptions();
		menuSlider.onChange.AddListener((UnityAction)MicrophoneDeviceSet);
	}

	private void Update()
	{
		//IL_0071: Unknown result type (might be due to invalid IL or missing references)
		//IL_0095: Unknown result type (might be due to invalid IL or missing references)
		if (currentDeviceCount != SessionManager.instance.micDeviceList.Count || selectedDeviceName != SessionManager.instance.micDeviceCurrent)
		{
			if (menuSlider.prevCurrentValue != menuSlider.currentValue || menuSlider.valueChangedImpulse)
			{
				MicrophoneDeviceSet();
			}
			SetOptions();
		}
		MicrophonePreviewTick();
		RectTransform component = ((Component)micLevelBar).GetComponent<RectTransform>();
		((Transform)component).localScale = new Vector3(MicrophoneLevelSmooth(((Transform)component).localScale.x, micLevel, Time.deltaTime), 0.2f, 1f);
	}

	private void MicrophoneDeviceSet()
	{
		if (Object.op_Implicit((Object)(object)menuPage) && (menuPage.currentPageState == MenuPage.PageState.Closing || menuPage.currentPageState == MenuPage.PageState.Closed))
		{
			DataDirector.instance.SettingValueSet(DataDirector.Setting.MicDevice, SessionManager.instance.micDeviceCurrentIndex);
			return;
		}
		string text = menuSlider.CustomOptionGetCurrentString();
		if (menuSlider.currentValue == menuSlider.customOptions.Count - 2)
		{
			text = "";
		}
		if (!(text == DataDirector.instance.micDevice))
		{
			SessionManager.instance.MicrophoneDeviceSet(text);
			selectedDeviceName = SessionManager.instance.micDeviceCurrent;
			DataDirector.instance.SaveSettings();
		}
	}

	private void OnEnable()
	{
		//IL_0007: Unknown result type (might be due to invalid IL or missing references)
		//IL_0011: Expected Obj, but got Unknown
		AudioSettings.OnAudioConfigurationChanged += MicrophoneAudioConfigurationChanged;
	}

	private void MicrophoneAudioConfigurationChanged(bool deviceWasChanged)
	{
		Interlocked.Exchange(ref microphoneRestartPending, 1);
	}

	private void MicrophonePreviewTick()
	{
		if (Interlocked.Exchange(ref microphoneRestartPending, 0) != 0)
		{
			MicrophonePreviewStop();
			microphoneRetryTimer = 0.5f;
		}
		if (Object.op_Implicit((Object)(object)menuPage) && (menuPage.currentPageState == MenuPage.PageState.Closing || menuPage.currentPageState == MenuPage.PageState.Closed))
		{
			MicrophonePreviewStop();
			return;
		}
		if (Object.op_Implicit((Object)(object)PlayerVoiceChat.instance))
		{
			MicrophonePreviewStop();
			micLevel = MicrophoneVoiceLevelGet(PlayerVoiceChat.instance);
			return;
		}
		if (currentDeviceName != SessionManager.instance.micDeviceCurrent)
		{
			MicrophonePreviewStop();
			currentDeviceName = SessionManager.instance.micDeviceCurrent;
			microphoneRetryTimer = 0f;
		}
		if (currentDeviceName == null)
		{
			return;
		}
		string[] devices = Microphone.devices;
		if (devices.Length == 0 || (currentDeviceName != "" && Array.IndexOf(devices, currentDeviceName) < 0))
		{
			MicrophonePreviewStop();
			microphoneRetryTimer = 0.5f;
			return;
		}
		if (!Object.op_Implicit((Object)(object)microphoneClip))
		{
			micLevel = 0f;
			microphoneRetryTimer = Mathf.Max(0f, microphoneRetryTimer - Time.unscaledDeltaTime);
			if (microphoneRetryTimer > 0f)
			{
				return;
			}
			microphoneRetryTimer = 1f;
			MicrophonePreviewStopAll();
			microphonePreviewOwner = this;
			try
			{
				int num = default;
				int num2 = default;
				Microphone.GetDeviceCaps(currentDeviceName, ref num, ref num2);
				int num3 = 44100;
				if (num > 0)
				{
					num3 = Mathf.Max(num3, num);
				}
				if (num2 > 0)
				{
					num3 = Mathf.Min(num3, num2);
				}
				microphoneClip = Microphone.Start(currentDeviceName, true, 1, num3);
			}
			catch (Exception ex)
			{
				Debug.LogWarning((object)("microphone test could not start... " + ex.Message));
			}
			previousMicrophonePosition = -1;
			microphoneProgressTimer = 3f;
			return;
		}
		try
		{
			MicrophonePreviewRead();
		}
		catch (Exception ex2)
		{
			MicrophonePreviewStop();
			microphoneRetryTimer = 1f;
			Debug.LogWarning((object)("microphone test could not read... " + ex2.Message));
		}
	}

	private void MicrophonePreviewRead()
	{
		if (!Microphone.IsRecording(currentDeviceName))
		{
			MicrophonePreviewStop();
			microphoneRetryTimer = 1f;
			return;
		}
		int position = Microphone.GetPosition(currentDeviceName);
		if (position != previousMicrophonePosition)
		{
			previousMicrophonePosition = position;
			microphoneProgressTimer = 3f;
		}
		else
		{
			microphoneProgressTimer = Mathf.Max(0f, microphoneProgressTimer - Time.unscaledDeltaTime);
			if (microphoneProgressTimer <= 0f)
			{
				MicrophonePreviewStop();
				microphoneRetryTimer = 1f;
				return;
			}
		}
		int num = position - 128;
		if (num >= 0)
		{
			if (!microphoneClip.GetData(micData, num))
			{
				MicrophonePreviewStop();
				microphoneRetryTimer = 1f;
			}
			else
			{
				micLevel = MicrophoneSamplesLevelGet(micData, micGain);
			}
		}
	}

	internal static float MicrophoneSamplesLevelGet(float[] samples, float gain = 10f)
	{
		float num = 0f;
		foreach (float num2 in samples)
		{
			num += num2 * num2;
		}
		return Mathf.Clamp01(Mathf.Sqrt(num / (float)samples.Length) * gain);
	}

	internal static float MicrophoneVoiceLevelGet(PlayerVoiceChat voiceChat)
	{
		if (!Object.op_Implicit((Object)(object)voiceChat))
		{
			return 0f;
		}
		return voiceChat.clipLoudnessNoTTS * 5f;
	}

	internal static float MicrophoneLevelSmooth(float current, float target, float deltaTime)
	{
		return Mathf.Lerp(current, target, deltaTime * 10f);
	}

	internal static void MicrophonePreviewStopAll()
	{
		if (Object.op_Implicit((Object)(object)microphonePreviewOwner))
		{
			microphonePreviewOwner.MicrophonePreviewStop();
		}
	}

	private void MicrophonePreviewStop()
	{
		micLevel = 0f;
		previousMicrophonePosition = -1;
		bool flag = (Object)(object)microphonePreviewOwner == (Object)(object)this;
		if (flag)
		{
			microphonePreviewOwner = null;
		}
		try
		{
			if (flag)
			{
				Microphone.End(currentDeviceName);
			}
		}
		finally
		{
			if (Object.op_Implicit((Object)(object)microphoneClip))
			{
				Object.Destroy((Object)(object)microphoneClip);
			}
			microphoneClip = null;
		}
	}

	private void OnDisable()
	{
		//IL_0007: Unknown result type (might be due to invalid IL or missing references)
		//IL_0011: Expected Obj, but got Unknown
		AudioSettings.OnAudioConfigurationChanged -= MicrophoneAudioConfigurationChanged;
		Interlocked.Exchange(ref microphoneRestartPending, 0);
		MicrophonePreviewStop();
	}

	private void OnDestroy()
	{
		//IL_0007: Unknown result type (might be due to invalid IL or missing references)
		//IL_0011: Expected Obj, but got Unknown
		//IL_0023: Unknown result type (might be due to invalid IL or missing references)
		//IL_002d: Expected Obj, but got Unknown
		AudioSettings.OnAudioConfigurationChanged -= MicrophoneAudioConfigurationChanged;
		menuSlider.onChange.RemoveListener((UnityAction)MicrophoneDeviceSet);
		MicrophonePreviewStop();
	}

	private void SetOptions()
	{
		menuSlider.customOptions.Clear();
		foreach (string micDevice in SessionManager.instance.micDeviceList)
		{
			menuSlider.CustomOptionAdd(micDevice, null, micEvent);
		}
		menuSlider.CustomOptionAdd("System Default", null, micEvent);
		menuSlider.CustomOptionAdd(null, localizedNoneOption, micEvent);
		List<MenuSlider.CustomOption> customOptions = menuSlider.customOptions;
		customOptions[customOptions.Count - 1].barFillPercent = 0;
		for (int i = 0; i < menuSlider.customOptions.Count; i++)
		{
			menuSlider.customOptions[i].customValueInt = i;
			menuSlider.customOptions[i].maxTextLength = 28;
		}
		currentDeviceCount = SessionManager.instance.micDeviceList.Count;
		selectedDeviceName = SessionManager.instance.micDeviceCurrent;
		int micDeviceCurrentIndex = SessionManager.instance.micDeviceCurrentIndex;
		micDeviceCurrentIndex = Mathf.Clamp(micDeviceCurrentIndex, 0, currentDeviceCount + 1);
		menuSlider.settingsValue = (float)micDeviceCurrentIndex / (float)(currentDeviceCount + 1);
		menuSlider.UpdateSegmentTextAndValue();
		menuSlider.prevCurrentValue = menuSlider.currentValue;
		menuSlider.valueChangedImpulse = false;
	}
}
