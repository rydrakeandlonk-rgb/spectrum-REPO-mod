using System;
using UnityEngine;

[Serializable]
public class EnemyGnomeVoice
{
	public AudioClip[] clips = Array.Empty<AudioClip>();

	public float pitch = 2f;

	public float pitchRandom = 0.1f;

	public float volume = 1f;

	private AudioClip[] selectedClip = new AudioClip[1];

	public void Play(Sound sound, Transform followTarget)
	{
		if (!Object.op_Implicit((Object)(object)GameManager.instance) || !SemiFunc.GameEventIsHalloween() || clips == null || clips.Length == 0)
		{
			sound.Play(followTarget);
			return;
		}
		AudioClip val = clips[Random.Range(0, clips.Length)];
		if (!Object.op_Implicit((Object)(object)val))
		{
			sound.Play(followTarget);
			return;
		}
		AudioClip[] sounds = sound.Sounds;
		float num = sound.Pitch;
		float num2 = sound.PitchRandom;
		float num3 = sound.Volume;
		selectedClip[0] = val;
		sound.Sounds = selectedClip;
		sound.Pitch = pitch;
		sound.PitchRandom = pitchRandom;
		sound.Volume = volume;
		try
		{
			sound.Play(followTarget);
		}
		finally
		{
			sound.Sounds = sounds;
			sound.Pitch = num;
			sound.PitchRandom = num2;
			sound.Volume = num3;
		}
	}

	public void LoopSetup(Sound sound)
	{
		if (Object.op_Implicit((Object)(object)GameManager.instance) && SemiFunc.GameEventIsHalloween() && clips != null && clips.Length != 0 && Object.op_Implicit((Object)(object)clips[0]))
		{
			sound.Sounds = clips;
			sound.Pitch = pitch;
			sound.PitchRandom = pitchRandom;
			sound.Volume = volume;
		}
	}
}
