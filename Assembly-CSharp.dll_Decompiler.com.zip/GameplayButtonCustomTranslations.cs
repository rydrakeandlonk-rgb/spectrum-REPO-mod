using UnityEngine;

public class GameplayButtonCustomTranslations : MonoBehaviour
{
	public void ButtonPressed()
	{
		if (Object.op_Implicit((Object)(object)LocalizationManager.instance))
		{
			LocalizationManager.instance.UpdateLocalizationOverrides();
		}
		if (Object.op_Implicit((Object)(object)DataDirector.instance))
		{
			DataDirector.instance.SaveSettings();
		}
	}
}
