using UnityEngine;

public class CameraUtils : MonoBehaviour
{
	public static CameraUtils Instance;

	public Camera MainCamera;

	[RuntimeInitializeOnLoadMethod(/*Could not decode attribute arguments.*/)]
	private static void RuntimeInitializeOnLoad()
	{
		Instance = null;
	}

	private void Awake()
	{
		Instance = this;
		MainCamera = Camera.main;
	}

	private void Start()
	{
		MainCamera = Camera.main;
	}
}
