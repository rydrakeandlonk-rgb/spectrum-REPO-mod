using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading;
using UnityEngine;

public class MetaManager : MonoBehaviour
{
	internal string savePath = "MetaSave";

	internal string presetCacheFolder = "CosmeticsPresets";

	private int presetSlots = 28;

	private const int fileRetryAttempts = 5;

	private const int fileRetryDelay = 200;

	public static MetaManager instance;

	internal bool saveReady;

	private bool saveAllowed;

	internal List<int> cosmeticTokens = new List<int>();

	internal List<int> cosmeticUnlocks = new List<int>();

	internal List<int> cosmeticHistory = new List<int>();

	internal List<int> cosmeticEquipped = new List<int>();

	internal bool cosmeticPreviewEnabled;

	internal List<int> cosmeticEquippedPreview = new List<int>();

	internal int[] colorsEquipped;

	internal bool colorsPreviewEnabled;

	internal int[] colorsEquippedPreview;

	internal List<List<int>> cosmeticPresets = new List<List<int>>();

	internal List<List<int>> colorPresets = new List<List<int>>();

	private int debugBlockedOrder;

	[Space]
	public List<CosmeticTypeAsset> cosmeticTypeAssets = new List<CosmeticTypeAsset>();

	[Space]
	public List<CosmeticCategoryAsset> CosmeticCategoryAssets = new List<CosmeticCategoryAsset>();

	[Space]
	public List<CosmeticAsset> cosmeticAssets = new List<CosmeticAsset>();

	[Space]
	public List<SemiColor> colors;

	public List<SemiColor> colorsUIOrder;

	private string SavePathFull => Path.Combine(Application.persistentDataPath, savePath + ".es3");

	private string SavePathLegacyBackup => Path.Combine(Application.persistentDataPath, savePath + ".bak");

	[RuntimeInitializeOnLoadMethod(/*Could not decode attribute arguments.*/)]
	private static void RuntimeInitializeOnLoad()
	{
		instance = null;
	}

	private void Awake()
	{
		//IL_0083: Unknown result type (might be due to invalid IL or missing references)
		//IL_0088: Unknown result type (might be due to invalid IL or missing references)
		if ((Object)(object)instance == (Object)null)
		{
			instance = this;
			Object.DontDestroyOnLoad((Object)(object)((Component)this).gameObject);
			for (int i = 0; i < colors.Count; i++)
			{
				colors[i].color = new Color(colors[i].color.r, colors[i].color.g, colors[i].color.b, 1f);
			}
			if (Application.isEditor)
			{
				savePath += "Editor";
			}
			ColorsInitialize();
			PresetsInitialize();
			int num = Enumerable.Count(cosmeticAssets, (CosmeticAsset x) => !Object.op_Implicit((Object)(object)x));
			if (num > 0)
			{
				Debug.LogError((object)$"MetaManager contains {num} null cosmetics assets!");
			}
			for (int num2 = 0; num2 < cosmeticAssets.Count; num2++)
			{
				if (Object.op_Implicit((Object)(object)cosmeticAssets[num2]) && (string.IsNullOrWhiteSpace(cosmeticAssets[num2].assetId) || cosmeticAssets[num2].assetId.StartsWith("vanilla:")))
				{
					cosmeticAssets[num2].assetId = $"vanilla:{num2}";
				}
			}
		}
		else
		{
			Object.Destroy((Object)(object)((Component)this).gameObject);
		}
	}

	private void Start()
	{
		Load();
		if (saveReady && Object.op_Implicit((Object)(object)DebugComputerCheck.instance) && !DebugComputerCheck.instance.DebugDisable && DebugComputerCheck.instance.ItemDebug)
		{
			if (DebugComputerCheck.instance.CosmeticUnlockAll)
			{
				CosmeticUnlockAll();
			}
			if (DebugComputerCheck.instance.CosmeticReset)
			{
				Reset();
			}
		}
	}

	private void OnValidate()
	{
		if (SemiFunc.OnValidateCheck())
		{
			return;
		}
		colors = colors.Distinct().ToList();
		colorsUIOrder.RemoveAll((SemiColor item) => !Object.op_Implicit((Object)(object)item) || !colors.Contains(item));
		foreach (SemiColor color in colors)
		{
			if (Object.op_Implicit((Object)(object)color) && !colorsUIOrder.Contains(color))
			{
				colorsUIOrder.Add(color);
			}
		}
	}

	private ES3Settings MakeSettings(string _path)
	{
		//IL_0010: Unknown result type (might be due to invalid IL or missing references)
		//IL_0015: Unknown result type (might be due to invalid IL or missing references)
		//IL_0017: Unknown result type (might be due to invalid IL or missing references)
		//IL_001c: Unknown result type (might be due to invalid IL or missing references)
		//IL_002d: Expected Obj, but got Unknown
		return new ES3Settings(_path, new Enum[1] { (Enum)(object)(Location)0 })
		{
			encryptionType = (EncryptionType)1,
			encryptionPassword = StatsManager.instance.totallyNormalString
		};
	}

	private List<string> GetBackups()
	{
		return Directory.GetFiles(Application.persistentDataPath, savePath + "_BACKUP*.es3").OrderByDescending(SemiFunc.GetBackupNumber).ToList();
	}

	private bool CreateBackup(string _path)
	{
		if (!SemiFunc.IsMainEditor() || !File.Exists(_path))
		{
			return false;
		}
		try
		{
			List<string> backups = GetBackups();
			int num = ((backups.Count <= 0) ? 1 : (SemiFunc.GetBackupNumber(backups[0]) + 1));
			File.Copy(_path, Path.Combine(Application.persistentDataPath, $"{savePath}_BACKUP{num}.es3"), overwrite: true);
			foreach (string item in GetBackups().Skip(3))
			{
				SemiFunc.DeleteFileSafe(item);
			}
			return true;
		}
		catch (Exception ex)
		{
			Debug.LogWarning((object)("[MetaSave] Could not back up " + Path.GetFileName(_path) + ": " + ex.Message));
			return false;
		}
	}

	public void Save()
	{
		if (!SemiFunc.IsMainEditor() || !saveAllowed)
		{
			return;
		}
		try
		{
			ES3Settings val = MakeSettings(SavePathFull);
			val.location = (Location)4;
			ES3.Save<List<int>>("cosmeticTokens", cosmeticTokens, val);
			ES3.Save<List<int>>("cosmeticUnlocks", cosmeticUnlocks, val);
			ES3.Save<List<int>>("cosmeticHistory", cosmeticHistory, val);
			ES3.Save<List<int>>("cosmeticEquipped", cosmeticEquipped, val);
			ES3.Save<List<List<int>>>("cosmeticPresets", cosmeticPresets, val);
			ES3.Save<List<List<int>>>("colorPresets", colorPresets, val);
			ES3.Save<int[]>("colorsEquipped", colorsEquipped, val);
			ES3.StoreCachedFile(val);
		}
		catch (Exception arg)
		{
			Debug.LogError((object)$"[MetaSave] Save failed: {arg}");
		}
	}

	private bool TryLoad(string _path)
	{
		if (!File.Exists(_path))
		{
			return false;
		}
		try
		{
			ES3Settings val = MakeSettings(_path);
			if (!ES3.FileExists(val))
			{
				return false;
			}
			if (ES3.KeyExists("cosmeticTokens", val))
			{
				cosmeticTokens = ES3.Load<List<int>>("cosmeticTokens", val);
			}
			if (ES3.KeyExists("cosmeticUnlocks", val))
			{
				cosmeticUnlocks = ES3.Load<List<int>>("cosmeticUnlocks", val);
			}
			if (ES3.KeyExists("cosmeticHistory", val))
			{
				cosmeticHistory = ES3.Load<List<int>>("cosmeticHistory", val);
			}
			if (ES3.KeyExists("cosmeticEquipped", val))
			{
				cosmeticEquipped = ES3.Load<List<int>>("cosmeticEquipped", val);
			}
			foreach (int item in cosmeticEquipped.ToList())
			{
				if (item < 0 || item >= cosmeticAssets.Count)
				{
					Debug.LogError((object)("Invalid equipped cosmetic index: " + item));
					cosmeticEquipped.Remove(item);
				}
			}
			if (ES3.KeyExists("cosmeticPresets", val))
			{
				List<List<int>> list = ES3.Load<List<List<int>>>("cosmeticPresets", val);
				if (list != null)
				{
					int num = Mathf.Min(cosmeticPresets.Count, list.Count);
					for (int i = 0; i < num; i++)
					{
						cosmeticPresets[i] = list[i];
					}
				}
			}
			if (ES3.KeyExists("colorPresets", val))
			{
				List<List<int>> list2 = ES3.Load<List<List<int>>>("colorPresets", val);
				if (list2 != null)
				{
					int num2 = Mathf.Min(colorPresets.Count, list2.Count);
					for (int j = 0; j < num2; j++)
					{
						colorPresets[j] = list2[j];
					}
				}
			}
			if (ES3.KeyExists("colorsEquipped", val))
			{
				int[] array = ES3.Load<int[]>("colorsEquipped", val);
				if (array != null)
				{
					int num3 = Mathf.Min(colorsEquipped.Length, array.Length);
					for (int k = 0; k < num3; k++)
					{
						colorsEquipped[k] = array[k];
					}
				}
			}
			return true;
		}
		catch (Exception arg)
		{
			Debug.LogError((object)$"[MetaSave] Failed to load {Path.GetFileName(_path)}: {arg}");
			return false;
		}
	}

	private bool TryLoadRetry(string _path)
	{
		if (!File.Exists(_path))
		{
			return false;
		}
		for (int i = 1; i < 5; i++)
		{
			if (TryLoad(_path))
			{
				return true;
			}
			Thread.Sleep(200);
		}
		return TryLoad(_path);
	}

	private void Load()
	{
		if (File.Exists(SavePathLegacyBackup))
		{
			CreateBackup(SavePathLegacyBackup);
			SemiFunc.DeleteFileSafe(SavePathLegacyBackup);
		}
		if (TryLoadRetry(SavePathFull))
		{
			Debug.Log((object)("[MetaSave] " + savePath + ".es3 found"));
			CreateBackup(SavePathFull);
			saveAllowed = true;
			saveReady = true;
			return;
		}
		List<string> backups = GetBackups();
		foreach (string item in backups)
		{
			if (TryLoadRetry(item))
			{
				Debug.LogWarning((object)("[MetaSave] " + savePath + ".es3 restored from " + Path.GetFileName(item)));
				SemiFunc.DeleteFileSafe(SavePathFull);
				saveAllowed = true;
				Save();
				saveReady = true;
				return;
			}
		}
		if (File.Exists(SavePathFull) || backups.Count > 0)
		{
			Debug.LogError((object)("[MetaSave] " + savePath + " exists but could not be loaded - saving disabled this session"));
			saveReady = true;
			return;
		}
		Debug.LogWarning((object)("[MetaSave] " + savePath + ".es3 not found - creating new"));
		saveAllowed = true;
		Save();
		saveReady = true;
	}

	public void Reset()
	{
		cosmeticTokens.Clear();
		cosmeticUnlocks.Clear();
		cosmeticHistory.Clear();
		cosmeticEquipped.Clear();
		cosmeticPresets.Clear();
		for (int i = 0; i < presetSlots; i++)
		{
			cosmeticPresets.Add(new List<int>());
		}
		string path = (Application.isEditor ? Path.Combine("Cache", "Editor") : "Cache");
		SemiFunc.DeleteDirectoriesRecursive(Path.Combine(Application.persistentDataPath, path, "Icons", presetCacheFolder));
		CosmeticTokenUI.instance?.Setup();
		if (Object.op_Implicit((Object)(object)MenuManager.instance.currentMenuPage))
		{
			MenuPageColor component = ((Component)MenuManager.instance.currentMenuPage).GetComponent<MenuPageColor>();
			if (Object.op_Implicit((Object)(object)component))
			{
				component.ConfirmButton();
			}
			MenuPageCosmetics component2 = ((Component)MenuManager.instance.currentMenuPage).GetComponent<MenuPageCosmetics>();
			if (Object.op_Implicit((Object)(object)component2))
			{
				component2.ConfirmButton();
			}
		}
		SemiFunc.DeleteFileSafe(SavePathFull);
		foreach (string backup in GetBackups())
		{
			SemiFunc.DeleteFileSafe(backup);
		}
		Save();
	}

	public bool CosmeticHistoryAdd(CosmeticAsset _cosmeticAsset)
	{
		int num = cosmeticAssets.IndexOf(_cosmeticAsset);
		if (num == -1)
		{
			Debug.LogError((object)("Failed to add cosmetic to history: " + ((Object)_cosmeticAsset).name));
			return false;
		}
		if (cosmeticHistory.Contains(num))
		{
			Debug.LogError((object)("Cosmetic already in history: " + ((Object)_cosmeticAsset).name));
			return false;
		}
		cosmeticHistory.Add(num);
		return true;
	}

	public bool CosmeticUnlock(CosmeticAsset _cosmeticAsset)
	{
		int num = cosmeticAssets.IndexOf(_cosmeticAsset);
		if (num == -1)
		{
			Debug.LogError((object)("Failed to unlock cosmetic: " + ((Object)_cosmeticAsset).name));
			return false;
		}
		if (cosmeticUnlocks.Contains(num))
		{
			Debug.LogError((object)("Cosmetic already unlocked: " + ((Object)_cosmeticAsset).name));
			return false;
		}
		cosmeticUnlocks.Add(num);
		Save();
		return true;
	}

	public bool CosmeticLock(CosmeticAsset _cosmeticAsset)
	{
		int num = cosmeticAssets.IndexOf(_cosmeticAsset);
		if (num == -1)
		{
			Debug.LogError((object)("Failed to lock cosmetic: " + ((Object)_cosmeticAsset).name));
			return false;
		}
		if (!cosmeticUnlocks.Contains(num))
		{
			Debug.LogError((object)("Cosmetic already locked: " + ((Object)_cosmeticAsset).name));
			return false;
		}
		cosmeticUnlocks.Remove(num);
		Save();
		return true;
	}

	public bool CosmeticUnlockAll()
	{
		bool flag = false;
		for (int i = 0; i < cosmeticAssets.Count; i++)
		{
			if (!cosmeticUnlocks.Contains(i))
			{
				cosmeticUnlocks.Add(i);
				flag = true;
				if (Object.op_Implicit((Object)(object)cosmeticAssets[i]))
				{
					SemiLogger.LogDev("Force unlocked cosmetic: " + ((Object)cosmeticAssets[i]).name);
				}
			}
		}
		if (flag)
		{
			Save();
		}
		return flag;
	}

	private List<int> GetPossibleCosmetics(SemiFunc.Rarity _rarity, bool _requireFinalized)
	{
		List<int> list = new List<int>();
		foreach (CosmeticAsset cosmeticAsset in cosmeticAssets)
		{
			if (Object.op_Implicit((Object)(object)cosmeticAsset) && cosmeticAsset.rarity == _rarity && cosmeticAsset.prefab.IsValid() && (!_requireFinalized || cosmeticAsset.status != CosmeticAsset.Status.Finalized))
			{
				int item = cosmeticAssets.IndexOf(cosmeticAsset);
				if (!cosmeticUnlocks.Contains(item))
				{
					list.Add(item);
				}
			}
		}
		return list;
	}

	public CosmeticAsset CosmeticLockedGet(SemiFunc.Rarity _rarity)
	{
		bool flag = Object.op_Implicit((Object)(object)GameManager.instance) && GameManager.instance.IsWIPActive(DebugCommandHandler.WIPTypes.Cosmetic);
		List<int> possibleCosmetics = GetPossibleCosmetics(_rarity, flag);
		if ((possibleCosmetics.Count == 0) & flag)
		{
			possibleCosmetics = GetPossibleCosmetics(_rarity, _requireFinalized: false);
		}
		if (possibleCosmetics.Count == 0)
		{
			return null;
		}
		possibleCosmetics.Shuffle();
		int index = possibleCosmetics[Random.Range(0, possibleCosmetics.Count)];
		return cosmeticAssets[index];
	}

	public bool CosmeticEquip(CosmeticAsset _cosmeticAssetNew, bool _isPreview)
	{
		if ((Object)(object)_cosmeticAssetNew == (Object)null)
		{
			Debug.LogError((object)"Missing cosmetic in equip");
			return false;
		}
		int num = cosmeticAssets.IndexOf(_cosmeticAssetNew);
		if (num == -1)
		{
			Debug.LogError((object)("Cosmetic not in asset list: " + ((Object)_cosmeticAssetNew).name));
			return false;
		}
		if (!cosmeticUnlocks.Contains(num))
		{
			Debug.LogError((object)("Cosmetic not unlocked: " + ((Object)_cosmeticAssetNew).name));
			return false;
		}
		List<int> list;
		if (_isPreview)
		{
			if (!cosmeticEquippedPreview.Contains(num))
			{
				cosmeticEquippedPreview.Add(num);
			}
			list = cosmeticEquippedPreview.ToList();
		}
		else
		{
			if (cosmeticEquipped.Contains(num))
			{
				return false;
			}
			cosmeticEquipped.Add(num);
			list = cosmeticEquipped.ToList();
		}
		foreach (CosmeticAsset item in GetCosmeticsToUnequip(list, _cosmeticAssetNew))
		{
			CosmeticUnequip(item, _isPreview);
		}
		if (_isPreview)
		{
			if (Object.op_Implicit((Object)(object)_cosmeticAssetNew.defaultColor))
			{
				colorsEquippedPreview[(int)_cosmeticAssetNew.type] = colors.IndexOf(_cosmeticAssetNew.defaultColor);
			}
			else
			{
				colorsEquippedPreview[(int)_cosmeticAssetNew.type] = 0;
			}
		}
		else if (Object.op_Implicit((Object)(object)_cosmeticAssetNew.defaultColor))
		{
			colorsEquipped[(int)_cosmeticAssetNew.type] = colors.IndexOf(_cosmeticAssetNew.defaultColor);
		}
		else
		{
			colorsEquipped[(int)_cosmeticAssetNew.type] = 0;
		}
		return true;
	}

	public bool CosmeticUnequip(CosmeticAsset _cosmeticAsset, bool _isPreview, bool _resetColor = true)
	{
		if ((Object)(object)_cosmeticAsset == (Object)null)
		{
			Debug.LogError((object)"Missing cosmetic in unequip");
			return false;
		}
		int num = cosmeticAssets.IndexOf(_cosmeticAsset);
		if (num == -1)
		{
			Debug.LogError((object)("Cosmetic not in asset list: " + ((Object)_cosmeticAsset).name));
			return false;
		}
		int num2 = 0;
		CosmeticTypeAsset cosmeticTypeAsset = cosmeticTypeAssets[(int)_cosmeticAsset.type];
		if (Object.op_Implicit((Object)(object)cosmeticTypeAsset) && !cosmeticTypeAsset.canEquipMultiple && Object.op_Implicit((Object)(object)_cosmeticAsset.defaultColor))
		{
			num2 = colors.IndexOf(_cosmeticAsset.defaultColor);
		}
		if (_isPreview)
		{
			if (!cosmeticEquippedPreview.Contains(num))
			{
				return false;
			}
			int index = cosmeticEquippedPreview.IndexOf(num);
			cosmeticEquippedPreview.RemoveAt(index);
			if (_resetColor || num2 == colorsEquippedPreview[(int)_cosmeticAsset.type])
			{
				colorsEquippedPreview[(int)_cosmeticAsset.type] = 0;
			}
		}
		else
		{
			if (!cosmeticEquipped.Contains(num))
			{
				return false;
			}
			int index2 = cosmeticEquipped.IndexOf(num);
			cosmeticEquipped.RemoveAt(index2);
			if (_resetColor || num2 == colorsEquipped[(int)_cosmeticAsset.type])
			{
				colorsEquipped[(int)_cosmeticAsset.type] = 0;
			}
		}
		return true;
	}

	public List<CosmeticAsset> GetCosmeticsToUnequip(List<int> _cosmeticEquipped, CosmeticAsset _cosmeticAssetNew)
	{
		List<CosmeticAsset> list = new List<CosmeticAsset>();
		if (!Object.op_Implicit((Object)(object)_cosmeticAssetNew))
		{
			return list;
		}
		CosmeticTypeAsset cosmeticTypeAsset = cosmeticTypeAssets[(int)_cosmeticAssetNew.type];
		foreach (int item in _cosmeticEquipped)
		{
			CosmeticAsset cosmeticAsset = cosmeticAssets[item];
			if (!Object.op_Implicit((Object)(object)cosmeticAsset) || (Object)(object)cosmeticAsset == (Object)(object)_cosmeticAssetNew)
			{
				continue;
			}
			CosmeticTypeAsset cosmeticTypeAsset2 = cosmeticTypeAssets[(int)cosmeticAsset.type];
			bool flag = false;
			if ((cosmeticAsset.type == _cosmeticAssetNew.type && !cosmeticTypeAsset.canEquipMultiple) || cosmeticTypeAsset.disabledTypeList.Contains(cosmeticTypeAsset2.type) || cosmeticTypeAsset2.disabledTypeList.Contains(cosmeticTypeAsset.type))
			{
				list.Add(cosmeticAsset);
				flag = true;
			}
			if (flag)
			{
				continue;
			}
			foreach (CosmeticCustomCondition.Type disabledCustomType in cosmeticTypeAsset.disabledCustomTypeList)
			{
				if (cosmeticAsset.customTypeList.Contains(disabledCustomType) || cosmeticTypeAsset2.customTypeList.Contains(disabledCustomType))
				{
					list.Add(cosmeticAsset);
					flag = true;
					break;
				}
			}
			if (flag)
			{
				continue;
			}
			foreach (CosmeticCustomCondition.Type disabledCustomType2 in cosmeticTypeAsset2.disabledCustomTypeList)
			{
				if (_cosmeticAssetNew.customTypeList.Contains(disabledCustomType2) || cosmeticTypeAsset.customTypeList.Contains(disabledCustomType2))
				{
					list.Add(cosmeticAsset);
					flag = true;
					break;
				}
			}
		}
		return list;
	}

	public void CosmeticPreviewSet(bool _state)
	{
		if (!_state)
		{
			cosmeticEquippedPreview = new List<int>();
		}
		cosmeticPreviewEnabled = _state;
		colorsPreviewEnabled = _state;
	}

	public bool CosmeticPlayerUpdateLocal(bool _synced, bool _forced = false)
	{
		PlayerAvatar playerAvatar = SemiFunc.PlayerGetLocal();
		if (!Object.op_Implicit((Object)(object)playerAvatar))
		{
			return false;
		}
		bool result = false;
		PlayerCosmetics playerCosmetics = playerAvatar.playerCosmetics;
		if (Object.op_Implicit((Object)(object)playerCosmetics) && !playerCosmetics.firstSetup && (_synced | _forced))
		{
			playerCosmetics.SetupCosmetics(_synced, _forced);
			playerCosmetics.SetupColors(_synced);
			result = true;
		}
		if (Object.op_Implicit((Object)(object)playerAvatar.playerDeathHead) && (_synced | _forced))
		{
			PlayerCosmetics playerCosmetics2 = playerAvatar.playerDeathHead.playerCosmetics;
			if (Object.op_Implicit((Object)(object)playerCosmetics2) && !playerCosmetics2.firstSetup)
			{
				playerCosmetics2.SetupCosmetics(_synced, _forced);
				playerCosmetics2.SetupColors(_synced);
				result = true;
			}
		}
		if (Object.op_Implicit((Object)(object)PlayerExpressionsUI.instance) && (_synced | _forced))
		{
			PlayerCosmetics playerCosmetics3 = PlayerExpressionsUI.instance.playerAvatarVisuals.playerCosmetics;
			if (Object.op_Implicit((Object)(object)playerCosmetics3) && !playerCosmetics3.firstSetup)
			{
				playerCosmetics3.SetupCosmetics(_synced: false, _forced);
				playerCosmetics3.SetupColors(_synced: false);
				result = true;
			}
		}
		if (Object.op_Implicit((Object)(object)PlayerAvatarMenu.instance))
		{
			PlayerCosmetics playerCosmetics4 = PlayerAvatarMenu.instance.playerCosmetics;
			if (Object.op_Implicit((Object)(object)playerCosmetics4) && !playerCosmetics4.firstSetup)
			{
				playerCosmetics4.SetupCosmetics(_synced: false, _forced);
				playerCosmetics4.SetupColors(_synced: false);
				result = true;
			}
		}
		return result;
	}

	public void CosmeticTokenAdd(SemiFunc.Rarity _rarity)
	{
		cosmeticTokens.Add((int)_rarity);
		CosmeticTokenUI.instance.Setup();
		Save();
	}

	public void CosmeticTokenRemove()
	{
		if (cosmeticTokens.Count != 0)
		{
			cosmeticTokens.RemoveAt(cosmeticTokens.Count - 1);
			CosmeticTokenUI.instance.Setup();
			Save();
		}
	}

	private void ColorsInitialize()
	{
		colorsEquipped = new int[Enum.GetValues(typeof(SemiFunc.CosmeticType)).Length];
		for (int i = 0; i < colorsEquipped.Length; i++)
		{
			colorsEquipped[i] = 0;
		}
	}

	public void CosmeticColorSet(int _index, int _colorID)
	{
		colorsEquipped[_index] = _colorID;
	}

	private void PresetsInitialize()
	{
		cosmeticPresets.Clear();
		colorPresets.Clear();
		for (int i = 0; i < presetSlots; i++)
		{
			cosmeticPresets.Add(new List<int>());
			colorPresets.Add(new List<int>());
		}
	}

	public void CosmeticPresetSet(int _index, List<int> _cosmeticEquipped, List<int> _colorsEquipped)
	{
		cosmeticPresets[_index] = _cosmeticEquipped.ToList();
		colorPresets[_index] = _colorsEquipped.ToList();
	}

	public void CosmeticTypeAssetSort()
	{
		cosmeticTypeAssets = cosmeticTypeAssets.OrderBy((CosmeticTypeAsset x) => x.type).ToList();
	}
}
