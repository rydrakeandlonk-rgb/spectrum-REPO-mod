using System;
using System.Collections.Generic;
using UnityEngine;

public class EyeLines : MonoBehaviour
{
	private List<Transform> targetsList = new List<Transform>();

	private PlayerAvatar targetPlayer;

	private bool isActive;

	public LineRenderer lineRendererLeft;

	public LineRenderer lineRendererRight;

	public float textureScrollSpeed = 0.5f;

	public bool IsActive()
	{
		return isActive;
	}

	public void SetIsActive(bool _isActive)
	{
		if (_isActive && !isActive)
		{
			lineRendererLeft.widthMultiplier = 0f;
			lineRendererRight.widthMultiplier = 0f;
		}
		isActive = _isActive;
	}

	private void Awake()
	{
		lineRendererLeft.widthMultiplier = 0f;
		lineRendererRight.widthMultiplier = 0f;
	}

	public void InitializeLine(PlayerAvatar _targetPlayer)
	{
		//IL_0014: Unknown result type (might be due to invalid IL or missing references)
		targetPlayer = _targetPlayer;
		isActive = true;
		((Component)this).transform.localPosition = Vector3.zero;
	}

	public void DrawLine(LineRenderer _lineRenderer, Vector3 _startPoint, Vector3 _endPoint)
	{
		//IL_002c: Unknown result type (might be due to invalid IL or missing references)
		//IL_002d: Unknown result type (might be due to invalid IL or missing references)
		//IL_002f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0034: Unknown result type (might be due to invalid IL or missing references)
		//IL_0045: Unknown result type (might be due to invalid IL or missing references)
		//IL_004f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0054: Unknown result type (might be due to invalid IL or missing references)
		//IL_0059: Unknown result type (might be due to invalid IL or missing references)
		//IL_0086: Unknown result type (might be due to invalid IL or missing references)
		//IL_008b: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a6: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b0: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b6: Unknown result type (might be due to invalid IL or missing references)
		//IL_00bb: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c0: Unknown result type (might be due to invalid IL or missing references)
		//IL_00cd: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d2: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ed: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f7: Unknown result type (might be due to invalid IL or missing references)
		//IL_00fd: Unknown result type (might be due to invalid IL or missing references)
		//IL_0102: Unknown result type (might be due to invalid IL or missing references)
		//IL_0107: Unknown result type (might be due to invalid IL or missing references)
		//IL_012f: Unknown result type (might be due to invalid IL or missing references)
		if (isActive)
		{
			FadeLineIn(_lineRenderer);
			Vector3[] array = new Vector3[20];
			for (int i = 0; i < 20; i++)
			{
				float num = (float)i / 19f;
				array[i] = Vector3.Lerp(_startPoint, _endPoint, num) - Vector3.up * Mathf.Sin(num * MathF.PI) * 0.5f;
				float num2 = 1f - Mathf.Abs(num - 0.5f) * 2f;
				float num3 = 1f;
				ref Vector3 reference = ref array[i];
				reference += Vector3.right * Mathf.Sin(Time.time * (30f * num3) + (float)i) * 0.02f * num2;
				ref Vector3 reference2 = ref array[i];
				reference2 += Vector3.forward * Mathf.Cos(Time.time * (30f * num3) + (float)i) * 0.02f * num2;
			}
			((Renderer)_lineRenderer).material.mainTextureOffset = new Vector2(Time.time * textureScrollSpeed, 0f);
			_lineRenderer.positionCount = 20;
			_lineRenderer.SetPositions(array);
		}
		else
		{
			FadeLineOut(_lineRenderer);
		}
	}

	public void DrawLines()
	{
		//IL_000d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0027: Unknown result type (might be due to invalid IL or missing references)
		//IL_003e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0058: Unknown result type (might be due to invalid IL or missing references)
		DrawLine(lineRendererLeft, ((Component)this).transform.position, targetPlayer.playerAvatarVisuals.playerEyes.pupilLeft.position);
		DrawLine(lineRendererRight, ((Component)this).transform.position, targetPlayer.playerAvatarVisuals.playerEyes.pupilRight.position);
	}

	private void Update()
	{
		//IL_0006: Unknown result type (might be due to invalid IL or missing references)
		((Component)this).transform.localPosition = Vector3.zero;
	}

	private void FadeLineIn(LineRenderer _lineRenderer)
	{
		if (_lineRenderer.widthMultiplier < 0.195f)
		{
			_lineRenderer.widthMultiplier = Mathf.Lerp(_lineRenderer.widthMultiplier, 0.2f, Time.deltaTime * 2f);
		}
		else
		{
			_lineRenderer.widthMultiplier = 0.2f;
		}
	}

	private void FadeLineOut(LineRenderer _lineRenderer)
	{
		if (_lineRenderer.widthMultiplier > 0.005f)
		{
			_lineRenderer.widthMultiplier = Mathf.Lerp(_lineRenderer.widthMultiplier, 0f, Time.deltaTime * 15f);
		}
		else
		{
			((Component)this).gameObject.SetActive(false);
		}
	}
}
