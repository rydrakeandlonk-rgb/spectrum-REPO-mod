using System.Collections.Generic;
using UnityEngine;

public class AmbienceLoop : MonoBehaviour
{
	public static AmbienceLoop instance;

	public AudioSource source;

	private AudioClip clip;

	private float volume;

	[Space]
	public AnimationCurve roomCurve;

	public float roomLerpSpeed = 1f;

	private float roomLerpAmount;

	private float roomVolumePrevious;

	internal float roomVolumeCurrent;

	private RoomAmbience roomAmbience;

	[Space]
	public GameObject overrideObject;

	public List<AmbienceLoopOverride> overrideLoops = new List<AmbienceLoopOverride>();

	private float overrideLoopLerp;

	internal float overrideLoopFadeTime = 0.3f;

	[RuntimeInitializeOnLoadMethod(/*Could not decode attribute arguments.*/)]
	private static void RuntimeInitializeOnLoad()
	{
		instance = null;
	}

	private void Awake()
	{
		instance = this;
	}

	private void Update()
	{
		if (!LevelGenerator.Instance.Generated)
		{
			return;
		}
		bool flag = false;
		RoomVolumeCheck roomVolumeCheck = PlayerController.instance.playerAvatarScript.RoomVolumeCheck;
		if (roomVolumeCheck.CurrentRooms.Count > 0)
		{
			RoomAmbience roomAmbience = roomVolumeCheck.CurrentRooms[0].RoomAmbience;
			if (Object.op_Implicit((Object)(object)roomAmbience) && (Object)(object)roomAmbience != (Object)(object)this.roomAmbience && !roomVolumeCheck.CurrentRooms[0].Extraction)
			{
				this.roomAmbience = roomAmbience;
				roomLerpAmount = 0f;
				roomVolumePrevious = roomVolumeCurrent;
			}
			LevelAmbience roomAmbienceOverride = roomVolumeCheck.CurrentRooms[0].RoomAmbienceOverride;
			if (roomVolumeCheck.CurrentRooms[0].Extraction && roomVolumeCheck.CurrentRooms.Count > 1)
			{
				roomAmbienceOverride = roomVolumeCheck.CurrentRooms[1].RoomAmbienceOverride;
			}
			if (Object.op_Implicit((Object)(object)roomVolumeCheck.CurrentRooms.Find((RoomVolume r) => r.priorityVolume)))
			{
				int num = -9999;
				RoomVolume roomVolume = null;
				foreach (RoomVolume currentRoom in roomVolumeCheck.CurrentRooms)
				{
					if (currentRoom.priorityVolume && currentRoom.priority > num)
					{
						num = currentRoom.priority;
						roomVolume = currentRoom;
					}
				}
				roomAmbienceOverride = roomVolume.RoomAmbienceOverride;
				this.roomAmbience = roomVolume.RoomAmbience;
			}
			if (Object.op_Implicit((Object)(object)roomAmbienceOverride))
			{
				bool flag2 = false;
				foreach (AmbienceLoopOverride overrideLoop in overrideLoops)
				{
					if ((Object)(object)overrideLoop.ambience == (Object)(object)roomAmbienceOverride)
					{
						flag2 = true;
						overrideLoop.Play();
						if (Object.op_Implicit((Object)(object)this.roomAmbience))
						{
							overrideLoop.volumeRoomAmbienceNew = this.roomAmbience.volume;
						}
						break;
					}
				}
				if (!flag2)
				{
					GameObject val = Object.Instantiate<GameObject>(overrideObject, ((Component)this).transform);
					AmbienceLoopOverride component = val.GetComponent<AmbienceLoopOverride>();
					component.ambience = roomAmbienceOverride;
					overrideLoops.Add(component);
					((Object)val.gameObject).name = ((Object)roomAmbienceOverride).name;
					if (Object.op_Implicit((Object)(object)this.roomAmbience))
					{
						component.volumeRoomAmbienceNew = this.roomAmbience.volume;
						component.volumeRoomAmbiencePrevious = this.roomAmbience.volume;
						component.volumeRoomAmbienceCurrent = this.roomAmbience.volume;
						component.volumeRoomAmbienceLerp = 1f;
					}
				}
				flag = true;
			}
		}
		if (Object.op_Implicit((Object)(object)this.roomAmbience))
		{
			if (roomLerpAmount < 1f)
			{
				roomLerpAmount += roomLerpSpeed * Time.deltaTime;
				roomLerpAmount = Mathf.Clamp01(roomLerpAmount);
				roomVolumeCurrent = Mathf.Lerp(roomVolumePrevious, this.roomAmbience.volume, roomCurve.Evaluate(roomLerpAmount));
			}
			if (flag)
			{
				overrideLoopLerp += overrideLoopFadeTime * Time.deltaTime;
				overrideLoopLerp = Mathf.Clamp01(overrideLoopLerp);
			}
			else
			{
				overrideLoopLerp -= overrideLoopFadeTime * Time.deltaTime;
				overrideLoopLerp = Mathf.Clamp01(overrideLoopLerp);
			}
			source.volume = Mathf.Lerp(volume * roomVolumeCurrent, 0f, roomCurve.Evaluate(overrideLoopLerp));
		}
	}

	public void Setup()
	{
		foreach (LevelAmbience ambiencePreset in LevelGenerator.Instance.Level.AmbiencePresets)
		{
			if (Object.op_Implicit((Object)(object)ambiencePreset) && Object.op_Implicit((Object)(object)ambiencePreset.loopClip))
			{
				clip = ambiencePreset.loopClip;
				volume = ambiencePreset.loopVolume;
			}
		}
		source.clip = clip;
		source.volume = 0f;
		source.loop = true;
		source.Play();
	}

	public void LiveUpdate()
	{
		foreach (LevelAmbience ambiencePreset in LevelGenerator.Instance.Level.AmbiencePresets)
		{
			if (Object.op_Implicit((Object)(object)ambiencePreset.loopClip))
			{
				clip = ambiencePreset.loopClip;
				volume = ambiencePreset.loopVolume;
			}
		}
		source.volume = volume;
	}
}
