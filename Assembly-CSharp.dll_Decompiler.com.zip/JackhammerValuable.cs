using System;
using Photon.Pun;
using UnityEngine;

public class JackhammerValuable : MonoBehaviour
{
	public enum States
	{
		Idle,
		Active
	}

	private static readonly int animActive = Animator.StringToHash("active");

	private Animator animator;

	private PhysGrabObject physGrabObject;

	public Sound soundStart;

	public Sound soundEnd;

	public Sound soundLoop;

	public Sound soundImpactLoop;

	public GameObject mesh;

	public CollisionFree colliderCollision;

	public ParticleSystem dirtParticles;

	public ParticleSystem dustParticles;

	private Quaternion initialRotation;

	private float impactEffectsTimer;

	private float investigateTimer;

	private float investigateInterval = 2f;

	private PhotonView photonView;

	internal States currentState;

	private bool stateStart;

	private bool mainLoopPlaying;

	private bool impactLoopPlaying;

	private void Start()
	{
		//IL_0047: Unknown result type (might be due to invalid IL or missing references)
		//IL_004c: Unknown result type (might be due to invalid IL or missing references)
		physGrabObject = ((Component)this).GetComponent<PhysGrabObject>();
		photonView = ((Component)this).GetComponent<PhotonView>();
		animator = ((Component)this).GetComponent<Animator>();
		((Behaviour)animator).enabled = false;
		dirtParticles.Stop();
		initialRotation = mesh.transform.localRotation;
	}

	private void Update()
	{
		soundLoop.PlayLoop(mainLoopPlaying, 5f, 5f);
		soundImpactLoop.PlayLoop(impactLoopPlaying, 5f, 5f);
		switch (currentState)
		{
		case States.Active:
			StateActive();
			break;
		case States.Idle:
			StateIdle();
			break;
		}
	}

	private void StateActive()
	{
		//IL_001b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0076: Unknown result type (might be due to invalid IL or missing references)
		//IL_019c: Unknown result type (might be due to invalid IL or missing references)
		//IL_01a8: Unknown result type (might be due to invalid IL or missing references)
		//IL_01ad: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ff: Unknown result type (might be due to invalid IL or missing references)
		//IL_012d: Unknown result type (might be due to invalid IL or missing references)
		if (stateStart)
		{
			stateStart = false;
			soundStart.Play(physGrabObject.centerPoint);
		}
		mainLoopPlaying = true;
		animator.SetBool(animActive, true);
		((Behaviour)animator).enabled = true;
		if (investigateTimer <= 0f)
		{
			EnemyDirector.instance.SetInvestigate(((Component)this).transform.position, 15f);
			investigateTimer = investigateInterval;
		}
		else
		{
			investigateTimer -= Time.deltaTime;
		}
		if (colliderCollision.colliding)
		{
			impactLoopPlaying = true;
			if (impactEffectsTimer >= 0.075f)
			{
				dirtParticles.Play();
				dustParticles.Play();
				GameDirector.instance.CameraImpact.ShakeDistance(0.75f, 1f, 6f, ((Component)this).transform.position, 0.01f);
				GameDirector.instance.CameraShake.ShakeDistance(1f, 1f, 6f, ((Component)this).transform.position, 0.25f);
				impactEffectsTimer = 0f;
			}
			impactEffectsTimer += Time.deltaTime;
		}
		else
		{
			impactLoopPlaying = false;
		}
		float num = 50f;
		float num2 = 2f * Mathf.Sin(Time.time * num);
		float num3 = 2f * Mathf.Sin(Time.time * num + MathF.PI / 2f);
		mesh.transform.localRotation = initialRotation * Quaternion.Euler(num2, 0f, num3);
		if (SemiFunc.IsMasterClientOrSingleplayer() && !physGrabObject.grabbed)
		{
			SetState(States.Idle);
		}
	}

	private void StateIdle()
	{
		//IL_001f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0048: Unknown result type (might be due to invalid IL or missing references)
		if (stateStart)
		{
			dirtParticles.Stop();
			mesh.transform.localRotation = initialRotation;
			stateStart = false;
			if (!LevelGenerator.Instance.Generated)
			{
				soundEnd.Play(physGrabObject.centerPoint);
			}
			impactLoopPlaying = false;
		}
		mainLoopPlaying = false;
		animator.SetBool(animActive, false);
		if (SemiFunc.IsMasterClientOrSingleplayer() && physGrabObject.grabbed)
		{
			SetState(States.Active);
		}
	}

	public void StopAnimator()
	{
		((Behaviour)animator).enabled = false;
	}

	public void OnHurtColliderHitEnemy()
	{
		physGrabObject.lightBreakImpulse = true;
	}

	[PunRPC]
	public void SetStateRPC(States state, PhotonMessageInfo _info = default(PhotonMessageInfo))
	{
		//IL_0000: Unknown result type (might be due to invalid IL or missing references)
		if (SemiFunc.MasterOnlyRPC(_info))
		{
			currentState = state;
			stateStart = true;
		}
	}

	private void SetState(States state)
	{
		//IL_001d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0023: Unknown result type (might be due to invalid IL or missing references)
		if (SemiFunc.IsMasterClientOrSingleplayer() && currentState != state)
		{
			if (!SemiFunc.IsMultiplayer())
			{
				SetStateRPC(state);
				return;
			}
			photonView.RPC("SetStateRPC", (RpcTarget)0, new object[1] { state });
		}
	}
}
