using UnityEngine;

public class PlayerAvatarEyelids : MonoBehaviour
{
	private PlayerAvatarVisuals playerVisuals;

	private void Start()
	{
		playerVisuals = ((Component)this).GetComponentInParent<PlayerAvatarVisuals>();
	}

	private void Update()
	{
		//IL_0006: Unknown result type (might be due to invalid IL or missing references)
		//IL_000b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0018: Unknown result type (might be due to invalid IL or missing references)
		//IL_0028: Unknown result type (might be due to invalid IL or missing references)
		//IL_002d: Unknown result type (might be due to invalid IL or missing references)
		//IL_003d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0043: Unknown result type (might be due to invalid IL or missing references)
		//IL_004f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0054: Unknown result type (might be due to invalid IL or missing references)
		//IL_0057: Unknown result type (might be due to invalid IL or missing references)
		//IL_0061: Unknown result type (might be due to invalid IL or missing references)
		Quaternion localRotation = ((Component)this).transform.localRotation;
		((Component)this).transform.localRotation = Quaternion.LookRotation(((Component)this).transform.forward, ((Component)playerVisuals).transform.up);
		Transform transform = ((Component)this).transform;
		float x = localRotation.x;
		float y = localRotation.y;
		Quaternion localRotation2 = ((Component)this).transform.localRotation;
		transform.localRotation = Quaternion.Euler(x, y, localRotation2.eulerAngles.z);
	}
}
