using System;
using Photon.Pun;
using UnityEngine;

public class RoachOrbit : MonoBehaviour
{
	[Header("Roach Smash")]
	public GameObject roachSmashPrefab;

	public float radius = 5f;

	public float rotationSpeed = 1f;

	public float noiseScale = 1f;

	public float noiseSpeed = 0.5f;

	public float noiseScale2 = 0.5f;

	public float noiseSpeed2 = 1f;

	private Vector3 startPosition;

	private float noiseOffsetX;

	private float noiseOffsetZ;

	private float noiseOffsetX2;

	private float noiseOffsetZ2;

	private PhotonView photonView;

	public Sound squashSound;

	public Sound roachLoopSound;

	private void Start()
	{
		//IL_0007: Unknown result type (might be due to invalid IL or missing references)
		//IL_000c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0018: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0044: Unknown result type (might be due to invalid IL or missing references)
		//IL_0060: Unknown result type (might be due to invalid IL or missing references)
		startPosition = ((Component)this).transform.position;
		noiseOffsetX = ((Component)this).transform.position.x;
		noiseOffsetZ = ((Component)this).transform.position.z;
		noiseOffsetX2 = ((Component)this).transform.position.x * 1.5f;
		noiseOffsetZ2 = ((Component)this).transform.position.z * 1.5f;
		photonView = ((Component)this).GetComponent<PhotonView>();
	}

	[PunRPC]
	private void SquashRPC()
	{
		//IL_000c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0037: Unknown result type (might be due to invalid IL or missing references)
		//IL_003c: Unknown result type (might be due to invalid IL or missing references)
		squashSound.Play(((Component)this).transform.position);
		Object.Instantiate<GameObject>(roachSmashPrefab, ((Component)this).transform.position, Quaternion.identity);
		Object.Destroy((Object)(object)((Component)this).gameObject);
	}

	public void Squash()
	{
		//IL_0018: Unknown result type (might be due to invalid IL or missing references)
		//IL_0043: Unknown result type (might be due to invalid IL or missing references)
		//IL_0048: Unknown result type (might be due to invalid IL or missing references)
		if (GameManager.instance.gameMode == 0)
		{
			squashSound.Play(((Component)this).transform.position);
			Object.Instantiate<GameObject>(roachSmashPrefab, ((Component)this).transform.position, Quaternion.identity);
			Object.Destroy((Object)(object)((Component)this).gameObject);
		}
		else
		{
			photonView.RPC("SquashRPC", (RpcTarget)3, Array.Empty<object>());
		}
	}

	private void Update()
	{
		//IL_00fc: Unknown result type (might be due to invalid IL or missing references)
		//IL_010a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0115: Unknown result type (might be due to invalid IL or missing references)
		//IL_011a: Unknown result type (might be due to invalid IL or missing references)
		//IL_011f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0121: Unknown result type (might be due to invalid IL or missing references)
		//IL_0129: Unknown result type (might be due to invalid IL or missing references)
		//IL_012e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0133: Unknown result type (might be due to invalid IL or missing references)
		//IL_013b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0142: Unknown result type (might be due to invalid IL or missing references)
		//IL_0144: Unknown result type (might be due to invalid IL or missing references)
		//IL_0150: Unknown result type (might be due to invalid IL or missing references)
		//IL_0152: Unknown result type (might be due to invalid IL or missing references)
		//IL_0157: Unknown result type (might be due to invalid IL or missing references)
		//IL_0168: Unknown result type (might be due to invalid IL or missing references)
		//IL_016d: Unknown result type (might be due to invalid IL or missing references)
		//IL_016f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0171: Unknown result type (might be due to invalid IL or missing references)
		//IL_0173: Unknown result type (might be due to invalid IL or missing references)
		//IL_0178: Unknown result type (might be due to invalid IL or missing references)
		//IL_0186: Unknown result type (might be due to invalid IL or missing references)
		//IL_018b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0199: Unknown result type (might be due to invalid IL or missing references)
		roachLoopSound.PlayLoop(playing: true, 1f, 2f);
		float num = ((GameManager.instance.gameMode != 0) ? ((float)PhotonNetwork.Time) : Time.time);
		float num2 = num * noiseSpeed;
		float num3 = Mathf.PerlinNoise(noiseOffsetX + num2 * noiseScale, 0f) * 2f - 1f;
		float num4 = Mathf.PerlinNoise(0f, noiseOffsetZ + num2 * noiseScale) * 2f - 1f;
		num2 = num * noiseSpeed2;
		float num5 = Mathf.PerlinNoise(noiseOffsetX2 + num2 * noiseScale2, 0f) * 2f - 1f;
		float num6 = Mathf.PerlinNoise(0f, noiseOffsetZ2 + num2 * noiseScale2) * 2f - 1f;
		float num7 = (num3 + num5) / 2f;
		float num8 = (num4 + num6) / 2f;
		Vector3 val = startPosition + new Vector3(num7, 0f, num8) * radius;
		Vector3 val2 = val - ((Component)this).transform.position;
		((Component)this).transform.position = val;
		if (val2 != Vector3.zero)
		{
			Quaternion val3 = Quaternion.LookRotation(val2);
			Quaternion val4 = Quaternion.Euler(0f, -90f, 0f);
			val3 *= val4;
			((Component)this).transform.rotation = Quaternion.Slerp(((Component)this).transform.rotation, val3, rotationSpeed * Time.deltaTime);
		}
	}
}
