using UnityEngine;

public class InfoTextTrigger : MonoBehaviour
{
	public string infoText;

	private string infoTextLocalized;

	[Space]
	public LocalizedAsset localizedAsset;

	private bool localizedAssetFetched;

	[Space]
	public bool inputDisplayReplaceTags;

	private bool inputDisplayReplaceTagsFetched;

	private string infoTextTags;

	public float maxDistance = 10f;

	internal bool active;

	private float activeTimer;

	private float disabledTimer;

	private void Awake()
	{
		((Component)this).GetComponent<Collider>().isTrigger = true;
		InputGlyphs.OnGlyphsChanged += RefreshText;
		LocalizationManager.instance.AddLocalizationChangedCallback(RefreshText);
	}

	private void OnDestroy()
	{
		InputGlyphs.OnGlyphsChanged -= RefreshText;
		LocalizationManager.instance.RemoveLocalizationChangedCallback(RefreshText);
	}

	private void RefreshText()
	{
		inputDisplayReplaceTagsFetched = false;
	}

	private void Update()
	{
		if (active)
		{
			activeTimer -= Time.deltaTime;
			if (activeTimer <= 0f || disabledTimer > 0f)
			{
				active = false;
				inputDisplayReplaceTagsFetched = false;
				localizedAssetFetched = false;
			}
			else
			{
				if (!localizedAssetFetched)
				{
					infoTextLocalized = localizedAsset?.GetLocalizedString();
					localizedAssetFetched = true;
				}
				string text = infoText;
				if (!string.IsNullOrEmpty(infoTextLocalized))
				{
					text = infoTextLocalized;
				}
				if (inputDisplayReplaceTags)
				{
					if (!inputDisplayReplaceTagsFetched)
					{
						infoTextTags = SemiFunc.InputDisplayReplaceTags(text, "<color=#fff><u><b>", "</b></u></color>");
						inputDisplayReplaceTagsFetched = true;
					}
					ItemInfoUI.instance.ItemInfoText(null, infoTextTags);
				}
				else
				{
					ItemInfoUI.instance.ItemInfoText(null, text);
				}
			}
		}
		if (disabledTimer > 0f)
		{
			disabledTimer -= Time.deltaTime;
		}
	}

	public void Activate()
	{
		if (!(disabledTimer > 0f))
		{
			active = true;
			activeTimer = 0.25f;
		}
	}

	public void Disable(float _time = 0.1f)
	{
		disabledTimer = _time;
	}
}
