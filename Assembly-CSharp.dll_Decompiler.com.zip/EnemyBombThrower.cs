using Photon.Pun;
using UnityEngine;

public class EnemyBombThrower : MonoBehaviour
{
	public enum State
	{
		Spawn,
		Idle,
		Roam,
		Investigate,
		Notice,
		GotoPlayer,
		BackAwayPlayer,
		BackAwayHead,
		Attack,
		Melee,
		Stun,
		Leave,
		Despawn
	}

	private enum RotationState
	{
		LookVelocitySlow,
		LookVelocityFast,
		LookTarget,
		LookTargetDirectly,
		LookHead
	}

	internal float rotationStopTimer;

	private float rotationUpdatedLastTime;

	internal State currentState;

	private float stateTimer;

	private bool stateImpulse;

	internal State previousState;

	internal Enemy enemy;

	internal PhotonView photonView;

	internal PlayerAvatar playerTarget;

	private Vector3 agentDestination;

	private bool visionPrevious;

	private float visionPreviousTime;

	private bool navmeshPrevious;

	private float navmeshPreviousTime;

	internal bool headGrown = true;

	private float headCooldown;

	private float headAttackCooldown;

	private float meleeTimer;

	private float meleeCooldown;

	private float torsoHeadBreakerCooldown;

	private int torsoHeadBreakerPrevious;

	public EnemyBombThrowerAnim anim;

	public EnemyBombThrowerHead head;

	public SphereCollider headCollider;

	public Transform headSpawnTransform;

	public SpringQuaternion horizontalRotationSpring;

	private Quaternion horizontalRotationTarget = Quaternion.identity;

	private void Awake()
	{
		enemy = ((Component)this).GetComponent<Enemy>();
		photonView = ((Component)this).GetComponent<PhotonView>();
	}

	private void Update()
	{
		if ((!GameManager.Multiplayer() || PhotonNetwork.IsMasterClient) && LevelGenerator.Instance.Generated)
		{
			if (enemy.IsStunned())
			{
				UpdateState(State.Stun);
			}
			else if (enemy.CurrentState == EnemyState.Despawn)
			{
				UpdateState(State.Despawn);
			}
			switch (currentState)
			{
			case State.Spawn:
				StateSpawn();
				break;
			case State.Idle:
				StateIdle();
				break;
			case State.Roam:
				StateRoam();
				break;
			case State.Investigate:
				StateInvestigate();
				break;
			case State.Notice:
				StateNotice();
				break;
			case State.GotoPlayer:
				StateGotoPlayer();
				break;
			case State.BackAwayPlayer:
				StateBackAwayPlayer();
				break;
			case State.BackAwayHead:
				StateBackAwayHead();
				break;
			case State.Attack:
				StateAttack();
				break;
			case State.Melee:
				StateMelee();
				break;
			case State.Stun:
				StateStun();
				break;
			case State.Leave:
				StateLeave();
				break;
			case State.Despawn:
				StateDespawn();
				break;
			}
			RotationLogic();
			HeadLogic();
			MeleeLogic();
			TorsoHeadBreakerLogic();
		}
	}

	private void StateSpawn()
	{
		if (stateImpulse)
		{
			AgentReset();
			RigidbodyReset();
			stateImpulse = false;
			stateTimer = 2f;
		}
		stateTimer -= Time.deltaTime;
		if (stateTimer <= 0f)
		{
			UpdateState(State.Idle);
		}
	}

	private void StateIdle()
	{
		if (stateImpulse)
		{
			AgentReset();
			RigidbodyReset();
			stateImpulse = false;
			stateTimer = Random.Range(2f, 8f);
		}
		if (!SemiFunc.EnemySpawnIdlePause())
		{
			stateTimer -= Time.deltaTime;
			if (stateTimer <= 0f)
			{
				UpdateState(State.Roam);
			}
			else if (SemiFunc.EnemyForceLeave(enemy))
			{
				UpdateState(State.Leave);
			}
		}
	}

	private void StateRoam()
	{
		//IL_004d: Unknown result type (might be due to invalid IL or missing references)
		if (stateImpulse)
		{
			stateImpulse = false;
			stateTimer = 5f;
			if (!SemiFunc.EnemyRoamPoint(enemy, out agentDestination))
			{
				return;
			}
			AgentReset();
			RigidbodyReset();
			stateImpulse = false;
		}
		enemy.NavMeshAgent.SetDestination(agentDestination);
		RotationStateSet(RotationState.LookVelocitySlow);
		RigidbodyNotMovingTickTimer();
		if (!GoToIdleOnDestinationReached() && SemiFunc.EnemyForceLeave(enemy))
		{
			UpdateState(State.Leave);
		}
	}

	private void StateInvestigate()
	{
		//IL_003b: Unknown result type (might be due to invalid IL or missing references)
		if (stateImpulse)
		{
			stateImpulse = false;
			stateTimer = 5f;
			RigidbodyReset();
			AgentReset();
		}
		else
		{
			RotationStateSet(RotationState.LookVelocitySlow);
			enemy.NavMeshAgent.SetDestination(agentDestination);
			RigidbodyNotMovingTickTimer();
			if (GoToIdleOnDestinationReached())
			{
				return;
			}
		}
		if (SemiFunc.EnemyForceLeave(enemy))
		{
			UpdateState(State.Leave);
		}
	}

	private void StateNotice()
	{
		if (stateImpulse)
		{
			stateImpulse = false;
			stateTimer = 2f;
			AgentReset();
			RigidbodyReset();
			stateImpulse = false;
		}
		RotationStateSet(RotationState.LookTargetDirectly);
		stateTimer -= Time.deltaTime;
		if (stateTimer <= 0f)
		{
			UpdateState(State.GotoPlayer);
		}
	}

	private void StateGotoPlayer()
	{
		//IL_00f0: Unknown result type (might be due to invalid IL or missing references)
		//IL_00be: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c9: Unknown result type (might be due to invalid IL or missing references)
		//IL_011b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0126: Unknown result type (might be due to invalid IL or missing references)
		if (stateImpulse)
		{
			stateImpulse = false;
			stateTimer = 5f;
			AgentReset();
			RigidbodyReset();
		}
		if (VisionBlocked())
		{
			stateTimer -= Time.deltaTime;
		}
		if (!Object.op_Implicit((Object)(object)playerTarget) || playerTarget.isDisabled || stateTimer <= 0f)
		{
			UpdateState(State.Idle);
		}
		else if (!AttackSetLogic() && !MeleeSetLogic() && !enemy.Jump.jumpingDelay && !enemy.Jump.jumping)
		{
			if (VisionBlocked() || Vector3.Distance(((Component)playerTarget).transform.position, ((Component)this).transform.position) > 6f)
			{
				enemy.NavMeshAgent.SetDestination(((Component)playerTarget).transform.position);
				AgentMoveFast();
				RotationStateSet(RotationState.LookVelocityFast);
			}
			else if (!VisionBlocked() && Vector3.Distance(((Component)playerTarget).transform.position, ((Component)this).transform.position) < 4f)
			{
				UpdateState(State.BackAwayPlayer);
			}
			else
			{
				AgentReset();
				RotationStateSet(RotationState.LookTarget);
			}
		}
	}

	private void StateBackAwayPlayer()
	{
		//IL_008a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0095: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d3: Unknown result type (might be due to invalid IL or missing references)
		if (stateImpulse)
		{
			stateImpulse = false;
			stateTimer = 1f;
			AgentReset();
			RigidbodyReset();
		}
		if (VisionBlocked())
		{
			stateTimer -= Time.deltaTime;
			if (stateTimer <= 0f)
			{
				UpdateState(State.GotoPlayer);
				return;
			}
		}
		if (!Object.op_Implicit((Object)(object)playerTarget) || playerTarget.isDisabled)
		{
			UpdateState(State.Idle);
		}
		else if (!VisionBlocked() && Vector3.Distance(((Component)playerTarget).transform.position, ((Component)this).transform.position) >= 5f)
		{
			UpdateState(State.GotoPlayer);
		}
		else if (!AttackSetLogic() && !MeleeSetLogic())
		{
			RotationStateSet(RotationState.LookTarget);
			BackAwayLogic(((Component)playerTarget).transform.position);
			if (SemiFunc.EnemyForceLeave(enemy))
			{
				UpdateState(State.Leave);
			}
		}
	}

	private void StateBackAwayHead()
	{
		//IL_0087: Unknown result type (might be due to invalid IL or missing references)
		//IL_0092: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b6: Unknown result type (might be due to invalid IL or missing references)
		if (stateImpulse)
		{
			stateImpulse = false;
			stateTimer = 3f;
			AgentReset();
			RigidbodyReset();
		}
		stateTimer -= Time.deltaTime;
		if (head.currentState == EnemyBombThrowerHead.State.Disabled || stateTimer <= 0f)
		{
			if (Object.op_Implicit((Object)(object)playerTarget) && !playerTarget.isDisabled)
			{
				UpdateState(State.GotoPlayer);
			}
			else
			{
				UpdateState(State.Idle);
			}
		}
		else if (Vector3.Distance(((Component)head).transform.position, ((Component)this).transform.position) < 6f)
		{
			RotationStateSet(RotationState.LookHead);
			BackAwayLogic(((Component)playerTarget).transform.position);
		}
	}

	private void StateAttack()
	{
		if (stateImpulse)
		{
			stateImpulse = false;
			stateTimer = 2f;
			AgentReset();
			RigidbodyReset();
			stateImpulse = false;
		}
		RotationStateSet(RotationState.LookTargetDirectly);
		stateTimer -= Time.deltaTime;
		if (stateTimer <= 0f)
		{
			UpdateState(State.BackAwayHead);
		}
	}

	private void StateMelee()
	{
		if (stateImpulse)
		{
			stateImpulse = false;
			stateTimer = 2f;
			AgentReset();
			RigidbodyReset();
			stateImpulse = false;
		}
		stateTimer -= Time.deltaTime;
		if (stateTimer > 1f)
		{
			RotationStateSet(RotationState.LookTargetDirectly);
		}
		else if (stateTimer <= 0f)
		{
			UpdateState(State.BackAwayHead);
		}
	}

	private void StateStun()
	{
		//IL_003a: Unknown result type (might be due to invalid IL or missing references)
		//IL_003f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0049: Unknown result type (might be due to invalid IL or missing references)
		if (stateImpulse)
		{
			stateImpulse = false;
			stateTimer = 2f;
			enemy.Rigidbody.rb.AddTorque(-((Component)enemy.Rigidbody).transform.right * 20f, (ForceMode)1);
			RigidbodyReset();
			AgentReset();
		}
		enemy.Vision.DisableVision(1f);
		if (!enemy.IsStunned())
		{
			stateTimer -= Time.deltaTime;
			if (stateTimer <= 0f)
			{
				UpdateState(State.Idle);
			}
		}
	}

	private void StateLeave()
	{
		//IL_0058: Unknown result type (might be due to invalid IL or missing references)
		if (stateImpulse)
		{
			stateTimer = 5f;
			if (!SemiFunc.EnemyLeavePoint(enemy, out agentDestination))
			{
				return;
			}
			SemiFunc.EnemyLeaveStart(enemy);
			RigidbodyReset();
			stateImpulse = false;
		}
		RigidbodyNotMovingTickTimer();
		RotationStateSet(RotationState.LookVelocityFast);
		enemy.NavMeshAgent.SetDestination(agentDestination);
		AgentMoveFast();
		GoToIdleOnDestinationReached();
	}

	private void StateDespawn()
	{
		if (stateImpulse)
		{
			AgentReset();
			RigidbodyReset();
			stateImpulse = false;
		}
	}

	private void UpdateState(State _state)
	{
		//IL_006c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0072: Unknown result type (might be due to invalid IL or missing references)
		if (SemiFunc.IsMasterClientOrSingleplayer() && _state != currentState)
		{
			previousState = currentState;
			currentState = _state;
			stateImpulse = true;
			stateTimer = 0f;
			if (GameManager.Multiplayer())
			{
				photonView.RPC("UpdateStateRPC", (RpcTarget)0, new object[1] { currentState });
			}
			else
			{
				UpdateStateRPC(currentState);
			}
		}
	}

	private void RotationStateSet(RotationState _state)
	{
		//IL_0001: Unknown result type (might be due to invalid IL or missing references)
		//IL_0006: Unknown result type (might be due to invalid IL or missing references)
		//IL_0206: Unknown result type (might be due to invalid IL or missing references)
		//IL_0208: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a5: Unknown result type (might be due to invalid IL or missing references)
		//IL_00aa: Unknown result type (might be due to invalid IL or missing references)
		//IL_00af: Unknown result type (might be due to invalid IL or missing references)
		//IL_0230: Unknown result type (might be due to invalid IL or missing references)
		//IL_023f: Unknown result type (might be due to invalid IL or missing references)
		//IL_00df: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f4: Unknown result type (might be due to invalid IL or missing references)
		//IL_0113: Unknown result type (might be due to invalid IL or missing references)
		//IL_0128: Unknown result type (might be due to invalid IL or missing references)
		//IL_012d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0132: Unknown result type (might be due to invalid IL or missing references)
		//IL_0137: Unknown result type (might be due to invalid IL or missing references)
		//IL_0183: Unknown result type (might be due to invalid IL or missing references)
		//IL_0198: Unknown result type (might be due to invalid IL or missing references)
		//IL_0166: Unknown result type (might be due to invalid IL or missing references)
		//IL_0167: Unknown result type (might be due to invalid IL or missing references)
		//IL_013c: Unknown result type (might be due to invalid IL or missing references)
		//IL_013e: Unknown result type (might be due to invalid IL or missing references)
		//IL_01b4: Unknown result type (might be due to invalid IL or missing references)
		//IL_01c9: Unknown result type (might be due to invalid IL or missing references)
		//IL_01ce: Unknown result type (might be due to invalid IL or missing references)
		//IL_01d3: Unknown result type (might be due to invalid IL or missing references)
		//IL_01d8: Unknown result type (might be due to invalid IL or missing references)
		//IL_01d9: Unknown result type (might be due to invalid IL or missing references)
		//IL_01db: Unknown result type (might be due to invalid IL or missing references)
		//IL_0200: Unknown result type (might be due to invalid IL or missing references)
		//IL_0201: Unknown result type (might be due to invalid IL or missing references)
		Quaternion val = horizontalRotationTarget;
		if (rotationStopTimer > 0f)
		{
			return;
		}
		if (_state == RotationState.LookTarget && !Object.op_Implicit((Object)(object)playerTarget))
		{
			_state = RotationState.LookVelocityFast;
		}
		if (_state == RotationState.LookVelocitySlow)
		{
			horizontalRotationSpring.speed = 5f;
			horizontalRotationSpring.damping = 0.7f;
		}
		else
		{
			horizontalRotationSpring.speed = 8f;
			horizontalRotationSpring.damping = 0.7f;
		}
		switch (_state)
		{
		case RotationState.LookVelocitySlow:
		case RotationState.LookVelocityFast:
			if (enemy.Rigidbody.velocity.magnitude >= 1f)
			{
				horizontalRotationTarget = Quaternion.LookRotation(enemy.Rigidbody.velocity.normalized);
			}
			break;
		case RotationState.LookTarget:
		case RotationState.LookTargetDirectly:
			if (Object.op_Implicit((Object)(object)playerTarget) && Vector3.Distance(((Component)playerTarget).transform.position, ((Component)enemy.Rigidbody).transform.position) >= 0.2f)
			{
				Quaternion val3 = Quaternion.LookRotation(((Component)playerTarget).transform.position - ((Component)enemy.Rigidbody).transform.position);
				if (_state == RotationState.LookTargetDirectly || Quaternion.Angle(val3, horizontalRotationTarget) >= 60f || Time.time - rotationUpdatedLastTime > 2f)
				{
					horizontalRotationTarget = val3;
				}
			}
			break;
		case RotationState.LookHead:
			if (Vector3.Distance(((Component)head).transform.position, ((Component)enemy.Rigidbody).transform.position) >= 0.2f)
			{
				Quaternion val2 = Quaternion.LookRotation(((Component)head).transform.position - ((Component)enemy.Rigidbody).transform.position);
				if (Quaternion.Angle(val2, horizontalRotationTarget) >= 60f || Time.time - rotationUpdatedLastTime > 2f)
				{
					horizontalRotationTarget = val2;
				}
			}
			break;
		}
		if (val != horizontalRotationTarget)
		{
			rotationUpdatedLastTime = Time.time;
		}
		horizontalRotationTarget.eulerAngles = new Vector3(0f, horizontalRotationTarget.eulerAngles.y, 0f);
	}

	private void RotationLogic()
	{
		//IL_002c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0036: Unknown result type (might be due to invalid IL or missing references)
		if (rotationStopTimer > 0f)
		{
			rotationStopTimer -= Time.deltaTime;
		}
		((Component)this).transform.rotation = SemiFunc.SpringQuaternionGet(horizontalRotationSpring, horizontalRotationTarget);
	}

	private void AgentReset()
	{
		//IL_001b: Unknown result type (might be due to invalid IL or missing references)
		enemy.NavMeshAgent.Warp(((Component)enemy.Rigidbody).transform.position);
		enemy.NavMeshAgent.ResetPath();
	}

	private void AgentMoveFast()
	{
		enemy.NavMeshAgent.OverrideAgent(2f, 15f, 0.1f);
	}

	private void RigidbodyReset()
	{
		enemy.Rigidbody.StuckReset();
		enemy.Jump.StuckReset();
		SemiFunc.EnemyCartJumpReset(enemy);
	}

	private void RigidbodyNotMovingTickTimer()
	{
		if (enemy.Rigidbody.notMovingTimer > 2f)
		{
			stateTimer -= Time.deltaTime;
		}
	}

	private bool GoToIdleOnDestinationReached()
	{
		//IL_002f: Unknown result type (might be due to invalid IL or missing references)
		//IL_003f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0060: Unknown result type (might be due to invalid IL or missing references)
		//IL_0066: Unknown result type (might be due to invalid IL or missing references)
		if (!enemy.Jump.jumping && (stateTimer <= 0f || Vector3.Distance(((Component)enemy.Rigidbody).transform.position, enemy.NavMeshAgent.GetPoint()) <= 1f || Vector3.Distance(((Component)enemy.Rigidbody).transform.position, agentDestination) <= 1f))
		{
			UpdateState(State.Idle);
			return true;
		}
		return false;
	}

	private void UpdatePlayerTarget(PlayerAvatar _player)
	{
		playerTarget = _player;
		int num = -1;
		if (Object.op_Implicit((Object)(object)playerTarget))
		{
			num = playerTarget.photonView.ViewID;
		}
		if (GameManager.Multiplayer())
		{
			photonView.RPC("UpdatePlayerTargetRPC", (RpcTarget)1, new object[1] { num });
		}
	}

	internal bool VisionBlocked()
	{
		//IL_0042: Unknown result type (might be due to invalid IL or missing references)
		//IL_0062: Unknown result type (might be due to invalid IL or missing references)
		//IL_0067: Unknown result type (might be due to invalid IL or missing references)
		//IL_006c: Unknown result type (might be due to invalid IL or missing references)
		//IL_007e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0083: Unknown result type (might be due to invalid IL or missing references)
		if (!Object.op_Implicit((Object)(object)playerTarget))
		{
			return true;
		}
		if (Time.time - visionPreviousTime > 0.2f && Object.op_Implicit((Object)(object)playerTarget))
		{
			Vector3 position = playerTarget.PlayerVisionTarget.VisionTransform.position;
			visionPreviousTime = Time.time;
			Vector3 val = position - enemy.Vision.VisionTransform.position;
			visionPrevious = Physics.Raycast(enemy.Vision.VisionTransform.position, val, val.magnitude, LayerMask.GetMask(new string[1] { "Default" }), (QueryTriggerInteraction)1);
		}
		return visionPrevious;
	}

	private bool AttackSetLogic()
	{
		//IL_0090: Unknown result type (might be due to invalid IL or missing references)
		//IL_009b: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b7: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c2: Unknown result type (might be due to invalid IL or missing references)
		if (headAttackCooldown > 0f)
		{
			return false;
		}
		if (!enemy.Jump.jumpingDelay && !enemy.Jump.jumping && !enemy.Jump.landDelay && headGrown && anim.headGrownVisually && !VisionBlocked() && (enemy.Rigidbody.notMovingTimer > 3f || (Vector3.Distance(((Component)playerTarget).transform.position, ((Component)this).transform.position) <= 6f && Vector3.Distance(((Component)playerTarget).transform.position, ((Component)this).transform.position) >= 4f)))
		{
			UpdateState(State.Attack);
			return true;
		}
		return false;
	}

	private bool MeleeSetLogic()
	{
		if (meleeTimer >= 1f)
		{
			meleeCooldown = 2f;
			UpdateState(State.Melee);
			return true;
		}
		return false;
	}

	private void BackAwayLogic(Vector3 _target)
	{
		//IL_001b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0020: Unknown result type (might be due to invalid IL or missing references)
		//IL_0021: Unknown result type (might be due to invalid IL or missing references)
		//IL_0026: Unknown result type (might be due to invalid IL or missing references)
		//IL_0029: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0035: Unknown result type (might be due to invalid IL or missing references)
		//IL_003a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0045: Unknown result type (might be due to invalid IL or missing references)
		//IL_004b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0050: Unknown result type (might be due to invalid IL or missing references)
		//IL_0055: Unknown result type (might be due to invalid IL or missing references)
		//IL_0057: Unknown result type (might be due to invalid IL or missing references)
		//IL_012e: Unknown result type (might be due to invalid IL or missing references)
		//IL_013e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0158: Unknown result type (might be due to invalid IL or missing references)
		//IL_0162: Unknown result type (might be due to invalid IL or missing references)
		//IL_006e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0073: Unknown result type (might be due to invalid IL or missing references)
		//IL_008a: Unknown result type (might be due to invalid IL or missing references)
		//IL_009a: Unknown result type (might be due to invalid IL or missing references)
		//IL_00af: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d9: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e9: Unknown result type (might be due to invalid IL or missing references)
		//IL_0103: Unknown result type (might be due to invalid IL or missing references)
		//IL_010d: Unknown result type (might be due to invalid IL or missing references)
		enemy.NavMeshAgent.Disable(0.1f);
		Vector3 val = ((Component)this).transform.position - _target;
		Vector3 normalized = val.normalized;
		Vector3 val2 = ((Component)this).transform.position + new Vector3(normalized.x, 0f, normalized.z);
		if (NavmeshCheck(val2))
		{
			((Component)this).transform.position = Vector3.MoveTowards(((Component)this).transform.position, val2, enemy.NavMeshAgent.DefaultSpeed * Time.deltaTime);
			if (Vector3.Distance(((Component)this).transform.position, ((Component)enemy.Rigidbody).transform.position) > 3f)
			{
				((Component)this).transform.position = new Vector3(((Component)enemy.Rigidbody).transform.position.x, ((Component)this).transform.position.y, ((Component)enemy.Rigidbody).transform.position.z);
			}
		}
		else
		{
			((Component)this).transform.position = new Vector3(((Component)enemy.Rigidbody).transform.position.x, ((Component)this).transform.position.y, ((Component)enemy.Rigidbody).transform.position.z);
		}
	}

	private void HeadLogic()
	{
		//IL_0057: Unknown result type (might be due to invalid IL or missing references)
		//IL_0067: Unknown result type (might be due to invalid IL or missing references)
		if (!headGrown && head.currentState == EnemyBombThrowerHead.State.Disabled)
		{
			headCooldown -= Time.deltaTime;
			if (headCooldown <= 0f && SemiFunc.PerSecond(5f, (Object)(object)this))
			{
				bool flag = false;
				Collider[] array = Physics.OverlapSphere(((Component)headCollider).transform.position, headCollider.radius, LayerMask.op_Implicit(SemiFunc.LayerMaskGetVisionObstruct()));
				foreach (Collider val in array)
				{
					if (!((Component)val).gameObject.CompareTag("Phys Grab Object") || !((Object)(object)((Component)val).GetComponentInParent<PhysGrabObject>() == (Object)(object)enemy.Rigidbody.physGrabObject))
					{
						flag = true;
					}
				}
				if (!flag)
				{
					HeadGrownSet(_state: true);
				}
			}
		}
		if (anim.headGrownVisually)
		{
			if (headAttackCooldown > 0f)
			{
				headAttackCooldown -= Time.deltaTime;
			}
		}
		else
		{
			headAttackCooldown = 0.5f;
		}
	}

	private void MeleeLogic()
	{
		//IL_0087: Unknown result type (might be due to invalid IL or missing references)
		//IL_0092: Unknown result type (might be due to invalid IL or missing references)
		if (meleeCooldown > 0f)
		{
			meleeCooldown -= Time.deltaTime;
			meleeTimer = 0f;
		}
		else if (!enemy.Jump.jumpingDelay && !enemy.Jump.jumping && !enemy.Jump.landDelay && !VisionBlocked() && currentState != State.Attack && currentState != State.Melee && Vector3.Distance(((Component)playerTarget).transform.position, ((Component)this).transform.position) <= 2.5f)
		{
			meleeTimer += Time.deltaTime;
		}
		else
		{
			meleeTimer = 0f;
		}
	}

	private void TorsoHeadBreakerLogic()
	{
		//IL_00a1: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a7: Unknown result type (might be due to invalid IL or missing references)
		if (!enemy.EnemyParent.playerClose)
		{
			return;
		}
		if (torsoHeadBreakerCooldown <= 0f)
		{
			if (Random.Range(0, 100) <= 25)
			{
				torsoHeadBreakerCooldown = 1f;
			}
			else
			{
				torsoHeadBreakerCooldown = Random.Range(5f, 20f);
			}
			int num;
			for (num = torsoHeadBreakerPrevious; num == torsoHeadBreakerPrevious; num = Random.Range(0, 12))
			{
			}
			torsoHeadBreakerPrevious = num;
			if (SemiFunc.IsMultiplayer())
			{
				photonView.RPC("TorsoHeadBreakerRPC", (RpcTarget)0, new object[1] { num });
			}
			else
			{
				TorsoHeadBreakerRPC(num);
			}
		}
		else
		{
			torsoHeadBreakerCooldown -= Time.deltaTime;
		}
	}

	public void HeadGrownSet(bool _state)
	{
		//IL_002c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0032: Unknown result type (might be due to invalid IL or missing references)
		if (GameManager.Multiplayer())
		{
			photonView.RPC("HeadGrownSetRPC", (RpcTarget)0, new object[1] { _state });
		}
		else
		{
			HeadGrownSetRPC(_state);
		}
	}

	private bool NavmeshCheck(Vector3 _position)
	{
		//IL_002a: Unknown result type (might be due to invalid IL or missing references)
		if (Time.time - navmeshPreviousTime > 0.2f)
		{
			navmeshPreviousTime = Time.time;
			navmeshPrevious = enemy.NavMeshAgent.OnNavmesh(_position, 1f, _checkPit: true);
		}
		return navmeshPrevious;
	}

	[PunRPC]
	private void UpdateStateRPC(State _state, PhotonMessageInfo _info = default(PhotonMessageInfo))
	{
		//IL_0000: Unknown result type (might be due to invalid IL or missing references)
		if (SemiFunc.MasterOnlyRPC(_info))
		{
			currentState = _state;
		}
	}

	[PunRPC]
	private void UpdatePlayerTargetRPC(int _photonViewID, PhotonMessageInfo _info = default(PhotonMessageInfo))
	{
		//IL_0000: Unknown result type (might be due to invalid IL or missing references)
		if (!SemiFunc.MasterOnlyRPC(_info))
		{
			return;
		}
		foreach (PlayerAvatar item in SemiFunc.PlayerGetList())
		{
			if (item.photonView.ViewID == _photonViewID)
			{
				playerTarget = item;
				break;
			}
		}
	}

	[PunRPC]
	private void HeadGrownSetRPC(bool _state, PhotonMessageInfo _info = default(PhotonMessageInfo))
	{
		//IL_0000: Unknown result type (might be due to invalid IL or missing references)
		if (SemiFunc.MasterOnlyRPC(_info))
		{
			headGrown = _state;
			if (headGrown)
			{
				((Component)headCollider).gameObject.SetActive(true);
			}
			else
			{
				((Component)headCollider).gameObject.SetActive(false);
			}
			if (SemiFunc.IsMasterClientOrSingleplayer() && !headGrown)
			{
				head.UpdateState(EnemyBombThrowerHead.State.Spawn);
				headCooldown = 1f;
			}
		}
	}

	[PunRPC]
	private void TorsoHeadBreakerRPC(int _index, PhotonMessageInfo _info = default(PhotonMessageInfo))
	{
		//IL_0000: Unknown result type (might be due to invalid IL or missing references)
		if (SemiFunc.MasterOnlyRPC(_info))
		{
			anim.TorsoHeadBreakerTrigger(_index);
		}
	}

	public void OnSpawn()
	{
		if (SemiFunc.IsMasterClientOrSingleplayer() && SemiFunc.EnemySpawn(enemy))
		{
			UpdateState(State.Spawn);
		}
	}

	public void OnVision()
	{
		if (enemy.Jump.jumpingDelay || enemy.Jump.jumping || head.currentState != EnemyBombThrowerHead.State.Disabled)
		{
			return;
		}
		if (currentState == State.Idle || currentState == State.Roam || currentState == State.Investigate || currentState == State.Leave)
		{
			UpdatePlayerTarget(enemy.Vision.onVisionTriggeredPlayer);
			if (Object.op_Implicit((Object)(object)playerTarget))
			{
				UpdateState(State.Notice);
			}
		}
		else if ((currentState == State.GotoPlayer || currentState == State.BackAwayPlayer) && (Object)(object)playerTarget == (Object)(object)enemy.Vision.onVisionTriggeredPlayer)
		{
			stateTimer = Mathf.Max(2f, stateTimer);
		}
	}

	public void OnInvestigate()
	{
		//IL_002e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0033: Unknown result type (might be due to invalid IL or missing references)
		if (SemiFunc.IsMasterClientOrSingleplayer() && (currentState == State.Idle || currentState == State.Roam || currentState == State.Investigate))
		{
			agentDestination = enemy.StateInvestigate.onInvestigateTriggeredPosition;
			UpdateState(State.Investigate);
		}
	}

	public void OnHurt()
	{
		anim.EventHurt();
		if (SemiFunc.IsMasterClientOrSingleplayer())
		{
			meleeTimer = 1f;
			if (currentState == State.Leave)
			{
				UpdateState(State.Idle);
			}
		}
	}

	public void OnDeath()
	{
		anim.EventDeath();
		if (SemiFunc.IsMasterClientOrSingleplayer())
		{
			if (headGrown)
			{
				HeadGrownSet(_state: false);
			}
			enemy.EnemyParent.Despawn();
		}
	}

	public EnemyBombThrower()
	{
		//IL_0008: Unknown result type (might be due to invalid IL or missing references)
		//IL_000d: Unknown result type (might be due to invalid IL or missing references)
	}
}
