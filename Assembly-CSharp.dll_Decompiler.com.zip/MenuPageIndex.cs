using System;

public enum MenuPageIndex
{
	Main,
	Escape,
	Settings,
	SettingsGameplay,
	SettingsGraphics,
	SettingsAudio,
	SettingsControls,
	PopUpTwoOptions,
	Lobby,
	PopUp,
	Color,
	Saves,
	Password,
	Regions,
	ServerList,
	[Obsolete]
	ServerListCreateNew,
	PublicGameChoice,
	[Obsolete]
	ServerListSearch,
	Moons,
	[Obsolete]
	SavesRename,
	Cosmetics,
	SettingsLanguage,
	SettingsGamepad,
	PopUpTextInput
}
