using UnityEngine;

public class DebugUI : MonoBehaviour
{
	public static DebugUI instance;

	public GameObject enableParent;

	[RuntimeInitializeOnLoadMethod(/*Could not decode attribute arguments.*/)]
	private static void RuntimeInitializeOnLoad()
	{
		instance = null;
	}

	private void Awake()
	{
		instance = this;
	}

	private void Start()
	{
		if (!Application.isEditor)
		{
			Object.Destroy((Object)(object)((Component)this).gameObject);
		}
	}

	private void Update()
	{
		if (Input.GetKeyDown((KeyCode)282))
		{
			enableParent.SetActive(!enableParent.activeSelf);
		}
	}
}
