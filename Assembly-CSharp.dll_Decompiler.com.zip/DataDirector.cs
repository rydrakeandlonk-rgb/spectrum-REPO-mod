using System;
using System.Collections.Generic;
using System.IO;
using Photon.Pun;
using Photon.Realtime;
using UnityEngine;

public class DataDirector : MonoBehaviour
{
	public enum Setting
	{
		MusicVolume,
		SfxVolume,
		AmbienceVolume,
		MicDevice,
		ProximityVoice,
		Resolution,
		Fullscreen,
		MicVolume,
		TextToSpeechVolume,
		CameraShake,
		CameraAnimation,
		Tips,
		Vsync,
		MasterVolume,
		CameraSmoothing,
		LightDistance,
		Bloom,
		LensEffect,
		MotionBlur,
		MaxFPS,
		ShadowQuality,
		ShadowDistance,
		ChromaticAberration,
		Grain,
		WindowMode,
		RenderSize,
		GlitchLoop,
		AimSensitivity,
		CameraNoise,
		Gamma,
		PlayerNames,
		RunsPlayed,
		PushToTalk,
		TutorialPlayed,
		TutorialJumping,
		TutorialSprinting,
		TutorialSneaking,
		TutorialHiding,
		TutorialTumbling,
		TutorialPushingAndPulling,
		TutorialRotating,
		TutorialReviving,
		TutorialHealing,
		TutorialCartHandling,
		TutorialItemToggling,
		TutorialInventoryFill,
		TutorialMap,
		TutorialChargingStation,
		TutorialOnlyOneExtraction,
		TutorialChat,
		TutorialFinalExtraction,
		TutorialMultipleExtractions,
		TutorialShop,
		TutorialExpressions,
		TutorialOvercharge1,
		TutorialOvercharge2,
		AimInvertVertical,
		Photosensitivity,
		SplashScreenCount,
		RichPresence,
		ItemUnequipAutoHold,
		TutorialHeadSpectate,
		TutorialEnemyElsa,
		Arachnophobia,
		Cosmetics,
		PopupCosmeticsColorAll,
		PopupCosmeticsColorBody,
		PopupCosmeticsColorCosmetics,
		PopupCosmeticsRandomizeAll,
		PopupCosmeticsRandomizeBody,
		PopupCosmeticsRandomizeCosmetics,
		PopupCosmeticsResetAll,
		PopupCosmeticsResetBody,
		PopupCosmeticsResetCosmetics,
		TutorialExtractionReminder,
		TutorialCosmeticWorldObject1,
		TutorialCosmeticWorldObject2,
		TutorialCosmeticShopMachine,
		MirrorQuality,
		CustomTranslations,
		ObjectShadowQuality
	}

	public enum SettingType
	{
		Audio,
		Gameplay,
		Graphics,
		None
	}

	public static DataDirector instance;

	private string playerBodyColor = "0";

	internal string micDevice = "";

	private Dictionary<Setting, string> settingsName = new Dictionary<Setting, string>();

	private Dictionary<Setting, int> settingsValue = new Dictionary<Setting, int>();

	private Dictionary<Setting, int> defaultSettingsValue = new Dictionary<Setting, int>();

	private Dictionary<SettingType, List<Setting>> settings = new Dictionary<SettingType, List<Setting>>();

	internal string networkPassword;

	internal string networkRegion;

	internal string networkServerName;

	internal string networkJoinServerName;

	public const string SERVER_NAME_PROP_KEY = "server_name";

	public TypedLobby customLobby = new TypedLobby("custom", (LobbyType)0);

	public TypedLobby privateLobby = new TypedLobby("private", (LobbyType)0);

	internal int aimSensitivityDefault;

	internal int cameraSmoothingDefault;

	internal bool toggleMute;

	internal bool settingsLoaded;

	[RuntimeInitializeOnLoadMethod(/*Could not decode attribute arguments.*/)]
	private static void RuntimeInitializeOnLoad()
	{
		instance = null;
	}

	private void Awake()
	{
		if ((Object)(object)instance == (Object)null)
		{
			instance = this;
			Object.DontDestroyOnLoad((Object)(object)((Component)this).gameObject);
			InitializeSettings();
			LoadSettings();
		}
		else
		{
			Object.Destroy((Object)(object)((Component)this).gameObject);
		}
	}

	private void Update()
	{
		if (SemiFunc.IsMultiplayer())
		{
			if (SemiFunc.InputDown(InputKey.ToggleMute))
			{
				toggleMute = !toggleMute;
			}
		}
		else
		{
			toggleMute = false;
		}
	}

	private void InitializeSettings()
	{
		SettingAdd(SettingType.Audio, Setting.MasterVolume, "Master Volume", 75);
		SettingAdd(SettingType.Audio, Setting.MusicVolume, "Music Volume", 75);
		SettingAdd(SettingType.Audio, Setting.SfxVolume, "Sfx Volume", 75);
		SettingAdd(SettingType.Audio, Setting.ProximityVoice, "Proximity Voice Volume", 75);
		SettingAdd(SettingType.Audio, Setting.TextToSpeechVolume, "Text to Speech Volume", 75);
		SettingAdd(SettingType.Audio, Setting.MicDevice, "Microphone", 0);
		SettingAdd(SettingType.Audio, Setting.MicVolume, "Microphone Volume", 100);
		SettingAdd(SettingType.Audio, Setting.PushToTalk, "Push to Talk", 0);
		SettingAdd(SettingType.Graphics, Setting.Resolution, "Resolution", 0);
		SettingAdd(SettingType.Graphics, Setting.Fullscreen, "Fullscreen", 0);
		SettingAdd(SettingType.Graphics, Setting.LightDistance, "Light Distance", 3);
		SettingAdd(SettingType.Graphics, Setting.Vsync, "Vsync", 0);
		SettingAdd(SettingType.Graphics, Setting.Bloom, "Bloom", 1);
		SettingAdd(SettingType.Graphics, Setting.ChromaticAberration, "Chromatic Aberration", 1);
		SettingAdd(SettingType.Graphics, Setting.Grain, "Grain", 1);
		SettingAdd(SettingType.Graphics, Setting.MotionBlur, "Motion Blur", 1);
		SettingAdd(SettingType.Graphics, Setting.LensEffect, "Lens Effect", 1);
		SettingAdd(SettingType.Graphics, Setting.GlitchLoop, "Glitch Loop", 1);
		SettingAdd(SettingType.Graphics, Setting.MaxFPS, "Max FPS", 144);
		SettingAdd(SettingType.Graphics, Setting.ShadowQuality, "Shadow Quality", 2);
		SettingAdd(SettingType.Graphics, Setting.ShadowDistance, "Shadow Distance", 3);
		SettingAdd(SettingType.Graphics, Setting.WindowMode, "Window Mode", 0);
		SettingAdd(SettingType.Graphics, Setting.RenderSize, "Pixelation", 2);
		SettingAdd(SettingType.Graphics, Setting.MirrorQuality, "Mirror Quality", 2);
		SettingAdd(SettingType.Graphics, Setting.Gamma, "Gamma", 40);
		SettingAdd(SettingType.Graphics, Setting.ObjectShadowQuality, "Object Shadow Quality", 1);
		SettingAdd(SettingType.Gameplay, Setting.Tips, "Tips", 1);
		aimSensitivityDefault = 35;
		SettingAdd(SettingType.None, Setting.AimSensitivity, "Aim Sensitivity", aimSensitivityDefault);
		cameraSmoothingDefault = 80;
		SettingAdd(SettingType.Gameplay, Setting.CameraSmoothing, "Camera Smoothing", cameraSmoothingDefault);
		SettingAdd(SettingType.Gameplay, Setting.CameraShake, "Camera Shake", 100);
		SettingAdd(SettingType.Gameplay, Setting.CameraNoise, "Camera Noise", 100);
		SettingAdd(SettingType.Gameplay, Setting.CameraAnimation, "Camera Animation", 4);
		SettingAdd(SettingType.Gameplay, Setting.PlayerNames, "Player Names", 1);
		SettingAdd(SettingType.None, Setting.AimInvertVertical, "Aim Invert Vertical", 0);
		SettingAdd(SettingType.Gameplay, Setting.Photosensitivity, "Photosensitivity", 0);
		SettingAdd(SettingType.Gameplay, Setting.Arachnophobia, "Arachnophobia", 0);
		SettingAdd(SettingType.Gameplay, Setting.RichPresence, "Rich Presence", 2);
		SettingAdd(SettingType.Gameplay, Setting.ItemUnequipAutoHold, "Item Unequip Auto Hold", 1);
		SettingAdd(SettingType.Gameplay, Setting.Cosmetics, "Cosmetics", 1);
		SettingAdd(SettingType.Gameplay, Setting.CustomTranslations, "Custom Translations", 1);
		SettingAdd(SettingType.None, Setting.RunsPlayed, "Runs Played", 0);
		SettingAdd(SettingType.None, Setting.TutorialPlayed, "Tutorial Played", 0);
		SettingAdd(SettingType.None, Setting.SplashScreenCount, "Splash Screen Count", 0);
		SettingAdd(SettingType.None, Setting.TutorialJumping, "Tutorial Jumping", 0);
		SettingAdd(SettingType.None, Setting.TutorialSprinting, "Tutorial Sprinting", 0);
		SettingAdd(SettingType.None, Setting.TutorialSneaking, "Tutorial Sneaking", 0);
		SettingAdd(SettingType.None, Setting.TutorialHiding, "Tutorial Hiding", 0);
		SettingAdd(SettingType.None, Setting.TutorialTumbling, "Tutorial Tumbling", 0);
		SettingAdd(SettingType.None, Setting.TutorialPushingAndPulling, "Tutorial Pushing and Pulling", 0);
		SettingAdd(SettingType.None, Setting.TutorialRotating, "Tutorial Rotating", 0);
		SettingAdd(SettingType.None, Setting.TutorialReviving, "Tutorial Reviving", 0);
		SettingAdd(SettingType.None, Setting.TutorialHealing, "Tutorial Healing", 0);
		SettingAdd(SettingType.None, Setting.TutorialCartHandling, "Tutorial Cart Handling", 0);
		SettingAdd(SettingType.None, Setting.TutorialItemToggling, "Tutorial Item Toggling", 0);
		SettingAdd(SettingType.None, Setting.TutorialInventoryFill, "Tutorial Inventory Fill", 0);
		SettingAdd(SettingType.None, Setting.TutorialMap, "Tutorial Map", 0);
		SettingAdd(SettingType.None, Setting.TutorialChargingStation, "Tutorial Charging Station", 0);
		SettingAdd(SettingType.None, Setting.TutorialOnlyOneExtraction, "Tutorial Only One Extraction", 0);
		SettingAdd(SettingType.None, Setting.TutorialChat, "Tutorial Chat", 0);
		SettingAdd(SettingType.None, Setting.TutorialFinalExtraction, "Tutorial Final Extraction", 0);
		SettingAdd(SettingType.None, Setting.TutorialMultipleExtractions, "Tutorial Multiple Extractions", 0);
		SettingAdd(SettingType.None, Setting.TutorialExtractionReminder, "Tutorial Extraction Reminder", 0);
		SettingAdd(SettingType.None, Setting.TutorialShop, "Tutorial Shop", 0);
		SettingAdd(SettingType.None, Setting.TutorialExpressions, "Tutorial Expressions", 0);
		SettingAdd(SettingType.None, Setting.TutorialOvercharge1, "Tutorial Overcharge 1", 0);
		SettingAdd(SettingType.None, Setting.TutorialOvercharge2, "Tutorial Overcharge 2", 0);
		SettingAdd(SettingType.None, Setting.TutorialHeadSpectate, "Tutorial Head Spectate", 0);
		SettingAdd(SettingType.None, Setting.TutorialEnemyElsa, "Tutorial Enemy Elsa", 0);
		SettingAdd(SettingType.None, Setting.TutorialCosmeticWorldObject1, "Tutorial Cosmetic World Object 1", 0);
		SettingAdd(SettingType.None, Setting.TutorialCosmeticWorldObject2, "Tutorial Cosmetic World Object 2", 0);
		SettingAdd(SettingType.None, Setting.TutorialCosmeticShopMachine, "Tutorial Cosmetic Shop Machine", 0);
		SettingAdd(SettingType.None, Setting.PopupCosmeticsColorAll, "Popup Cosmetics Color All", 0);
		SettingAdd(SettingType.None, Setting.PopupCosmeticsColorBody, "Popup Cosmetics Color Body", 0);
		SettingAdd(SettingType.None, Setting.PopupCosmeticsColorCosmetics, "Popup Cosmetics Color Cosmetics", 0);
		SettingAdd(SettingType.None, Setting.PopupCosmeticsRandomizeAll, "Popup Cosmetics Randomize All", 0);
		SettingAdd(SettingType.None, Setting.PopupCosmeticsRandomizeBody, "Popup Cosmetics Randomize Body", 0);
		SettingAdd(SettingType.None, Setting.PopupCosmeticsRandomizeCosmetics, "Popup Cosmetics Randomize Cosmetics", 0);
		SettingAdd(SettingType.None, Setting.PopupCosmeticsResetAll, "Popup Cosmetics Reset All", 0);
		SettingAdd(SettingType.None, Setting.PopupCosmeticsResetBody, "Popup Cosmetics Reset Body", 0);
		SettingAdd(SettingType.None, Setting.PopupCosmeticsResetCosmetics, "Popup Cosmetics Reset Cosmetics", 0);
	}

	private void SettingAdd(SettingType settingType, Setting setting, string _name, int value)
	{
		if (settings.ContainsKey(settingType))
		{
			settings[settingType].Add(setting);
		}
		else
		{
			settings[settingType] = new List<Setting> { setting };
		}
		if (settingsName.ContainsKey(setting))
		{
			Debug.LogError((object)("Setting already exists: " + setting.ToString() + " " + _name));
			return;
		}
		settingsName[setting] = _name;
		settingsValue[setting] = value;
		defaultSettingsValue[setting] = value;
	}

	public int SettingValueFetch(Setting setting)
	{
		if (!settingsValue.ContainsKey(setting))
		{
			return 0;
		}
		return settingsValue[setting];
	}

	public float SettingValueFetchFloat(Setting setting)
	{
		return (float)settingsValue[setting] / 100f;
	}

	public void SettingValueSet(Setting setting, int value)
	{
		if (settingsValue.ContainsKey(setting))
		{
			settingsValue[setting] = value;
		}
		else
		{
			Debug.LogWarning((object)("Setting not found: " + setting));
		}
	}

	public string SettingNameGet(Setting setting)
	{
		if (!settingsName.ContainsKey(setting))
		{
			return null;
		}
		return settingsName[setting];
	}

	public void SaveSettings()
	{
		//IL_007f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0085: Expected Obj, but got Unknown
		if (!SemiFunc.IsMainEditor())
		{
			return;
		}
		SettingsSaveData settingsSaveData = new SettingsSaveData();
		settingsSaveData.settingsValue = new Dictionary<string, int>();
		foreach (KeyValuePair<Setting, int> item in settingsValue)
		{
			settingsSaveData.settingsValue[item.Key.ToString()] = item.Value;
		}
		ES3Settings val = new ES3Settings(new Enum[1] { (Enum)(object)(Location)4 });
		val.path = "SettingsData.es3";
		ES3.Save<SettingsSaveData>("Settings", settingsSaveData, val);
		ES3.Save<string>("PlayerBodyColor", playerBodyColor, val);
		ES3.Save<string>("micDevice", micDevice, val);
		try
		{
			ES3.StoreCachedFile(val);
		}
		catch (Exception ex)
		{
			Debug.LogError((object)ex);
		}
	}

	public void ColorSetBody(int colorID)
	{
		string text = colorID.ToString();
		if (playerBodyColor != text)
		{
			playerBodyColor = text;
			SaveSettings();
		}
	}

	public int ColorGetBody()
	{
		//IL_0014: Unknown result type (might be due to invalid IL or missing references)
		//IL_001a: Expected Obj, but got Unknown
		ES3Settings val = new ES3Settings("SettingsData.es3", new Enum[1] { (Enum)(object)(Location)0 });
		if (ES3.KeyExists("PlayerBodyColor", val))
		{
			playerBodyColor = ES3.Load<string>("PlayerBodyColor", val);
		}
		return int.Parse(playerBodyColor);
	}

	public void LoadSettings()
	{
		//IL_0014: Unknown result type (might be due to invalid IL or missing references)
		//IL_001a: Expected Obj, but got Unknown
		try
		{
			ES3Settings val = new ES3Settings("SettingsData.es3", new Enum[1] { (Enum)(object)(Location)0 });
			if (ES3.FileExists(val))
			{
				if (ES3.KeyExists("Settings", val))
				{
					foreach (KeyValuePair<string, int> item in ES3.Load<SettingsSaveData>("Settings", val).settingsValue)
					{
						if (Enum.TryParse<Setting>(item.Key, out var result) && settingsValue.ContainsKey(result))
						{
							settingsValue[result] = item.Value;
						}
					}
				}
				else
				{
					Debug.LogWarning((object)("Key 'Settings' not found in file: " + val.FullPath));
				}
				if (ES3.KeyExists("PlayerBodyColor", val))
				{
					playerBodyColor = ES3.Load<string>("PlayerBodyColor", val);
				}
				if (ES3.KeyExists("micDevice", val))
				{
					micDevice = ES3.Load<string>("micDevice", val);
				}
			}
			else
			{
				SaveSettings();
			}
		}
		catch (Exception ex)
		{
			Debug.LogError((object)("Failed to load settings: " + ex.Message));
			if (SemiFunc.IsMainEditor())
			{
				ES3.DeleteFile("SettingsData.es3");
			}
			SaveSettings();
		}
		settingsLoaded = true;
	}

	public void ResetSettingToDefault(Setting setting)
	{
		if (defaultSettingsValue.ContainsKey(setting))
		{
			settingsValue[setting] = defaultSettingsValue[setting];
			if (setting == Setting.MicDevice)
			{
				micDevice = "";
				if (Object.op_Implicit((Object)(object)SessionManager.instance))
				{
					SessionManager.instance.MicrophoneDeviceSet(micDevice);
				}
			}
		}
		else
		{
			Debug.LogWarning((object)("Default value not found for setting: " + setting));
		}
	}

	public void ResetSettingTypeToDefault(SettingType settingType)
	{
		if (settings.ContainsKey(settingType))
		{
			foreach (Setting item in settings[settingType])
			{
				if (defaultSettingsValue.ContainsKey(item))
				{
					ResetSettingToDefault(item);
				}
			}
			return;
		}
		Debug.LogWarning((object)("SettingType not found: " + settingType));
	}

	public void RunsPlayedAdd()
	{
		int value = SettingValueFetch(Setting.RunsPlayed) + 1;
		SettingValueSet(Setting.RunsPlayed, value);
		try
		{
			SaveSettings();
		}
		catch (IOException ex)
		{
			Debug.LogWarning((object)("could not save the run count... continuing with the count in memory: " + ex.Message));
		}
		catch (UnauthorizedAccessException ex2)
		{
			Debug.LogWarning((object)("could not save the run count.. continuing with the count in memory: " + ex2.Message));
		}
	}

	public void TutorialPlayed()
	{
		if (SettingValueFetch(Setting.TutorialPlayed) == 0)
		{
			SettingValueSet(Setting.TutorialPlayed, 1);
			SaveSettings();
		}
	}

	public void SaveDeleteCheck(bool _leaveGame)
	{
		if (SemiFunc.IsMasterClientOrSingleplayer() && !((Object)(object)RunManager.instance.levelPrevious == (Object)(object)RunManager.instance.levelTutorial) && !((Object)(object)RunManager.instance.levelPrevious == (Object)(object)RunManager.instance.levelMainMenu) && !((Object)(object)RunManager.instance.levelPrevious == (Object)(object)RunManager.instance.levelRecording))
		{
			bool flag = false;
			if (SemiFunc.RunIsArena())
			{
				flag = true;
			}
			else if (RunManager.instance.allPlayersDead && (Object)(object)RunManager.instance.levelPrevious != (Object)(object)RunManager.instance.levelMainMenu && (Object)(object)RunManager.instance.levelPrevious != (Object)(object)RunManager.instance.levelLobbyMenu && (Object)(object)RunManager.instance.levelPrevious != (Object)(object)RunManager.instance.levelTutorial && (Object)(object)RunManager.instance.levelPrevious != (Object)(object)RunManager.instance.levelLobby && !SemiFunc.IsLevelShop(RunManager.instance.levelPrevious) && (Object)(object)RunManager.instance.levelPrevious != (Object)(object)RunManager.instance.levelRecording)
			{
				flag = true;
			}
			else if (_leaveGame && RunManager.instance.levelsCompleted == 0)
			{
				flag = true;
			}
			if (flag)
			{
				SemiFunc.SaveFileDelete(StatsManager.instance.saveFileCurrent);
			}
		}
	}

	public void PhotonSetRegion()
	{
		PhotonNetwork.PhotonServerSettings.AppSettings.FixedRegion = networkRegion;
		Debug.Log((object)("Photon - Set Region: " + networkRegion));
	}

	public string PhotonVersionGet()
	{
		return BuildManager.instance.version.title + ".net3";
	}

	public void PhotonSetVersion()
	{
		string text = PhotonVersionGet();
		PhotonNetwork.PhotonServerSettings.AppSettings.AppVersion = text;
		Debug.Log((object)("Photon - Set Version: " + text));
	}

	public void PhotonSetAppId()
	{
		//IL_000a: Unknown result type (might be due to invalid IL or missing references)
		//IL_001f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0025: Unknown result type (might be due to invalid IL or missing references)
		//IL_0011: Unknown result type (might be due to invalid IL or missing references)
		if ((int)PhotonNetwork.PhotonServerSettings.AppSettings.Protocol == 0)
		{
			PhotonNetwork.ServerPortOverrides = PhotonPortDefinition.AlternativeUdpPorts;
		}
		else
		{
			PhotonNetwork.ServerPortOverrides = default;
		}
		PhotonNetwork.ObjectsInOneUpdate = 10;
		string server = "";
		int port = 0;
		string appIdRealtime = "99515094-45b7-4c98-ab70-a448c548c83d";
		string appIdVoice = "dfc40a01-c3a4-4395-9707-b71118816d2b";
		if (Object.op_Implicit((Object)(object)DebugComputerCheck.instance) && !DebugComputerCheck.instance.DebugDisable && DebugComputerCheck.instance.serverMode == DebugComputerCheck.ServerMode.Local)
		{
			if (!string.IsNullOrWhiteSpace(DebugComputerCheck.instance.serverAddress))
			{
				server = DebugComputerCheck.instance.serverAddress;
			}
			if (DebugComputerCheck.instance.serverPort > 0)
			{
				port = DebugComputerCheck.instance.serverPort;
			}
		}
		PhotonNetwork.PhotonServerSettings.AppSettings.AppIdRealtime = appIdRealtime;
		PhotonNetwork.PhotonServerSettings.AppSettings.AppIdVoice = appIdVoice;
		PhotonNetwork.PhotonServerSettings.AppSettings.Server = server;
		PhotonNetwork.PhotonServerSettings.AppSettings.Port = port;
		Debug.Log((object)"Photon - Set AppId");
	}

	public void PhotonLogAppIds()
	{
		if (!string.IsNullOrEmpty(PhotonNetwork.PhotonServerSettings.AppSettings.AppIdRealtime))
		{
			Debug.Log((object)("Photon - AppId (Realtime): " + PhotonNetwork.PhotonServerSettings.AppSettings.AppIdRealtime));
		}
		if (!string.IsNullOrEmpty(PhotonNetwork.PhotonServerSettings.AppSettings.AppIdVoice))
		{
			Debug.Log((object)("Photon - AppId (Voice): " + PhotonNetwork.PhotonServerSettings.AppSettings.AppIdVoice));
		}
		if (!string.IsNullOrEmpty(PhotonNetwork.PhotonServerSettings.AppSettings.Server))
		{
			Debug.Log((object)("Photon - AppId (Server): " + PhotonNetwork.PhotonServerSettings.AppSettings.Server));
		}
		if (PhotonNetwork.PhotonServerSettings.AppSettings.Port > 0)
		{
			Debug.Log((object)("Photon - AppId (Port): " + PhotonNetwork.PhotonServerSettings.AppSettings.Port));
		}
	}

	public DataDirector()
	{
		//IL_0049: Unknown result type (might be due to invalid IL or missing references)
		//IL_0053: Expected Obj, but got Unknown
		//IL_005a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0064: Expected Obj, but got Unknown
	}
}
