using TMPro;
using UnityEngine;

public class VehicleUI : SemiUI
{
	private TextMeshProUGUI Text;

	public static VehicleUI instance;

	public bool isMPH;

	private float messageTimer;

	public TextMeshProUGUI valuableBoxText;

	public ParticleSystem speedParticles;

	private bool speedParticlesPlaying;

	[RuntimeInitializeOnLoadMethod(/*Could not decode attribute arguments.*/)]
	private static void RuntimeInitializeOnLoad()
	{
		instance = null;
	}

	protected override void Start()
	{
		base.Start();
		Text = ((Component)this).GetComponent<TextMeshProUGUI>();
		instance = this;
	}

	protected override void Update()
	{
		base.Update();
		if (messageTimer > 0f)
		{
			messageTimer -= Time.deltaTime;
		}
		else
		{
			Hide();
		}
	}

	public void ShowSpeed(float _kmh)
	{
		messageTimer = 0.1f;
		Show();
		string text = Mathf.Clamp(Mathf.RoundToInt(isMPH ? (_kmh * 0.621371f) : _kmh), 0, 999).ToString();
		string text2 = new string('0', 3 - text.Length);
		string text3 = (isMPH ? "mph" : "km/h");
		((TMP_Text)Text).text = "<mspace=0.4em><color=#4A151080>" + text2 + "</color><color=yellow>" + text + "</color></mspace> <size=50%><b><color=orange>" + text3 + "</color></b></size>";
		if (Object.op_Implicit((Object)(object)speedParticles))
		{
			if (_kmh > 50f && !speedParticlesPlaying)
			{
				speedParticles.Play();
				speedParticlesPlaying = true;
			}
			else if (_kmh <= 50f && speedParticlesPlaying)
			{
				speedParticles.Stop();
				speedParticlesPlaying = false;
			}
		}
	}

	public void ShowValuableBoxValue(int _value)
	{
		if (Object.op_Implicit((Object)(object)valuableBoxText))
		{
			string text = Mathf.Clamp(_value, 0, 99999).ToString();
			string text2 = new string('0', 5 - text.Length);
			((TMP_Text)valuableBoxText).text = "<mspace=0.4em><color=#558B2F80>$</color><color=#4A151080>" + text2 + "</color><color=#FFFF00A6>" + text + "</color></mspace>";
		}
	}

	public void HideValuableBoxValue()
	{
		if (Object.op_Implicit((Object)(object)valuableBoxText))
		{
			((TMP_Text)valuableBoxText).text = "";
		}
	}
}
