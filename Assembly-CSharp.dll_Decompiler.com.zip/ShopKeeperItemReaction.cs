using UnityEngine;

public class ShopKeeperItemReaction : MonoBehaviour
{
	public enum State
	{
		Idle,
		Discounted,
		Rejected
	}

	private State currentState;

	private int timesShown;

	public static ShopKeeperItemReaction GetOrAdd(GameObject _gameObject)
	{
		ShopKeeperItemReaction shopKeeperItemReaction = _gameObject.GetComponent<ShopKeeperItemReaction>();
		if (!Object.op_Implicit((Object)(object)shopKeeperItemReaction))
		{
			shopKeeperItemReaction = _gameObject.AddComponent<ShopKeeperItemReaction>();
		}
		return shopKeeperItemReaction;
	}

	public State StateGet()
	{
		return currentState;
	}

	public void StateSet(State _state)
	{
		currentState = _state;
	}

	public int TimesShownGet()
	{
		return timesShown;
	}

	public void TimesShownSet(int _timesShown)
	{
		timesShown = Mathf.Max(0, _timesShown);
	}

	public void DiscountSet()
	{
		currentState = State.Discounted;
	}

	public void RejectedSet()
	{
		currentState = State.Rejected;
	}
}
