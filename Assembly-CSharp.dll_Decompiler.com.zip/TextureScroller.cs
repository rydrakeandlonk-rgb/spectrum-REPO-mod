using UnityEngine;

public class TextureScroller : MonoBehaviour
{
	public float scrollSpeed = 0.5f;

	private Renderer rend;

	private Material scrollMaterial;

	private Vector2 savedOffset;

	private TruckLandscapeScroller truck;

	private void Start()
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_0029: Unknown result type (might be due to invalid IL or missing references)
		rend = ((Component)this).GetComponent<Renderer>();
		scrollMaterial = rend.material;
		savedOffset = scrollMaterial.mainTextureOffset;
		truck = ((Component)this).GetComponentInParent<TruckLandscapeScroller>();
		if ((Object)(object)truck != (Object)null)
		{
			scrollSpeed *= truck.truckSpeed;
		}
	}

	private void Update()
	{
		//IL_0025: Unknown result type (might be due to invalid IL or missing references)
		//IL_0030: Unknown result type (might be due to invalid IL or missing references)
		float num = Mathf.Repeat(Time.time * scrollSpeed, 1f);
		Vector2 mainTextureOffset = new Vector2(num, savedOffset.y);
		scrollMaterial.mainTextureOffset = mainTextureOffset;
	}

	private void OnDisable()
	{
		//IL_0014: Unknown result type (might be due to invalid IL or missing references)
		if (Object.op_Implicit((Object)(object)scrollMaterial))
		{
			scrollMaterial.mainTextureOffset = savedOffset;
		}
	}
}
