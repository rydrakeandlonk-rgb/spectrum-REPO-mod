using System.Collections.Generic;
using UnityEngine;

public class EnemySlowMouthAttached : MonoBehaviour
{
	public enum State
	{
		Intro,
		Idle,
		Puke,
		Outro
	}

	internal bool debug;

	internal EnemySlowMouth enemySlowMouth;

	internal State state;

	internal State statePrev;

	private bool stateStart = true;

	private float stateTimer;

	internal PlayerAvatar playerTarget;

	internal bool showDebug;

	public Transform localParentTransform;

	public SemiPuke semiPuke;

	public AnimationCurve curveIntroOutro;

	public Transform pukeCapsuleTransform;

	public MeshRenderer pukeCapsuleRenderer;

	public Transform topJawTransform;

	public Transform botJawTransform;

	private Quaternion topJawStartRotation;

	private Quaternion botJawStartRotation;

	private Quaternion topJawTargetRotation;

	private Quaternion botJawTargetRotation;

	private Vector3 jawStartPosition;

	private Vector3 jawTargetPosition;

	private SpringQuaternion topJawSpring;

	private SpringQuaternion botJawSpring;

	private SpringVector3 jawPositionSpring;

	private float openAngleTarget = 125f;

	private float pukeTimer;

	public List<ParticleSystem> pukeParticles;

	public SemiPuke otherSemiPuke;

	public Transform otherTopJawTransform;

	public Transform otherBotJawTransform;

	public Transform particles;

	private SpringFloat springFloatScale;

	private float scaleTarget = 1f;

	public List<Transform> eyeTransforms;

	private float loudnessAdd;

	private SpringFloat loudnessSpring;

	private float loudnessTarget;

	private void Start()
	{
		//IL_0088: Unknown result type (might be due to invalid IL or missing references)
		//IL_008d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0099: Unknown result type (might be due to invalid IL or missing references)
		//IL_009e: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a5: Unknown result type (might be due to invalid IL or missing references)
		//IL_00aa: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b1: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b6: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c2: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c7: Unknown result type (might be due to invalid IL or missing references)
		//IL_0128: Unknown result type (might be due to invalid IL or missing references)
		//IL_0132: Unknown result type (might be due to invalid IL or missing references)
		jawPositionSpring = new SpringVector3();
		jawPositionSpring.damping = 0.5f;
		jawPositionSpring.speed = 20f;
		topJawSpring = new SpringQuaternion();
		topJawSpring.damping = 0.5f;
		topJawSpring.speed = 20f;
		botJawSpring = new SpringQuaternion();
		botJawSpring.damping = 0.5f;
		botJawSpring.speed = 20f;
		topJawStartRotation = topJawTransform.localRotation;
		botJawStartRotation = botJawTransform.localRotation;
		topJawTargetRotation = topJawStartRotation;
		botJawTargetRotation = topJawStartRotation;
		jawStartPosition = localParentTransform.localPosition;
		loudnessSpring = new SpringFloat();
		loudnessSpring.damping = 0.5f;
		loudnessSpring.speed = 20f;
		springFloatScale = new SpringFloat();
		springFloatScale.damping = 0.35f;
		springFloatScale.speed = 10f;
		otherTopJawTransform.localScale = Vector3.one * 2f;
		springFloatScale.lastPosition = 2f;
	}

	private void StateIntro()
	{
		//IL_0155: Unknown result type (might be due to invalid IL or missing references)
		//IL_016a: Unknown result type (might be due to invalid IL or missing references)
		//IL_016f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0174: Unknown result type (might be due to invalid IL or missing references)
		//IL_017b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0191: Unknown result type (might be due to invalid IL or missing references)
		//IL_0196: Unknown result type (might be due to invalid IL or missing references)
		//IL_019b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0054: Unknown result type (might be due to invalid IL or missing references)
		//IL_0070: Unknown result type (might be due to invalid IL or missing references)
		//IL_0086: Unknown result type (might be due to invalid IL or missing references)
		//IL_008b: Unknown result type (might be due to invalid IL or missing references)
		//IL_009c: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a1: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a8: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ad: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b9: Unknown result type (might be due to invalid IL or missing references)
		//IL_00cd: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d2: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e8: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ed: Unknown result type (might be due to invalid IL or missing references)
		if (stateStart)
		{
			stateStart = false;
			stateTimer = 1f;
			if (Object.op_Implicit((Object)(object)playerTarget) && playerTarget.isLocal)
			{
				float num = 125f;
				topJawTransform.localRotation = Quaternion.Euler(num, 0f, 0f);
				botJawTransform.localRotation = Quaternion.Euler(0f - num, 0f, 0f);
				topJawSpring.lastRotation = topJawTransform.localRotation;
				botJawSpring.lastRotation = botJawTransform.localRotation;
				jawTargetPosition = jawStartPosition;
				localParentTransform.localPosition = jawTargetPosition + new Vector3(0f, -1f, -1f);
				jawPositionSpring.lastPosition = localParentTransform.localPosition;
			}
		}
		loudnessTarget = 0f;
		scaleTarget = 1f;
		if (Object.op_Implicit((Object)(object)playerTarget) && playerTarget.isLocal)
		{
			float num2 = curveIntroOutro.Evaluate(1f - stateTimer);
			openAngleTarget = Mathf.LerpUnclamped(125f, 0f, num2);
			topJawTargetRotation = topJawStartRotation * Quaternion.Euler(openAngleTarget, 0f, 0f);
			botJawTargetRotation = botJawStartRotation * Quaternion.Euler(0f - openAngleTarget, 0f, 0f);
		}
		if (stateTimer < 0f)
		{
			StateSet(State.Idle);
		}
	}

	private void StateIdle()
	{
		//IL_00f3: Unknown result type (might be due to invalid IL or missing references)
		//IL_0118: Unknown result type (might be due to invalid IL or missing references)
		//IL_011d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0122: Unknown result type (might be due to invalid IL or missing references)
		//IL_0129: Unknown result type (might be due to invalid IL or missing references)
		//IL_014e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0153: Unknown result type (might be due to invalid IL or missing references)
		//IL_0158: Unknown result type (might be due to invalid IL or missing references)
		//IL_0034: Unknown result type (might be due to invalid IL or missing references)
		//IL_0039: Unknown result type (might be due to invalid IL or missing references)
		//IL_0040: Unknown result type (might be due to invalid IL or missing references)
		//IL_0045: Unknown result type (might be due to invalid IL or missing references)
		//IL_004c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0051: Unknown result type (might be due to invalid IL or missing references)
		//IL_01bf: Unknown result type (might be due to invalid IL or missing references)
		//IL_01e7: Unknown result type (might be due to invalid IL or missing references)
		//IL_01ec: Unknown result type (might be due to invalid IL or missing references)
		//IL_01f1: Unknown result type (might be due to invalid IL or missing references)
		//IL_01f8: Unknown result type (might be due to invalid IL or missing references)
		//IL_0220: Unknown result type (might be due to invalid IL or missing references)
		//IL_0225: Unknown result type (might be due to invalid IL or missing references)
		//IL_022a: Unknown result type (might be due to invalid IL or missing references)
		//IL_007e: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ac: Unknown result type (might be due to invalid IL or missing references)
		//IL_0242: Unknown result type (might be due to invalid IL or missing references)
		//IL_024c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0251: Unknown result type (might be due to invalid IL or missing references)
		//IL_025c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0266: Unknown result type (might be due to invalid IL or missing references)
		//IL_026b: Unknown result type (might be due to invalid IL or missing references)
		if (stateStart)
		{
			stateStart = false;
			if (Object.op_Implicit((Object)(object)playerTarget) && playerTarget.isLocal)
			{
				botJawTargetRotation = botJawStartRotation;
				topJawTargetRotation = topJawStartRotation;
				jawTargetPosition = jawStartPosition;
				if (statePrev == State.Puke)
				{
					GameDirector.instance.CameraShake.ShakeDistance(2f, 3f, 8f, localParentTransform.position, 0.1f);
					GameDirector.instance.CameraImpact.ShakeDistance(3f, 3f, 8f, localParentTransform.position, 0.1f);
				}
			}
		}
		loudnessTarget = 0f;
		scaleTarget = 1f;
		if (Object.op_Implicit((Object)(object)playerTarget) && playerTarget.isLocal)
		{
			botJawTargetRotation = botJawStartRotation * Quaternion.Euler(-2f * Mathf.Sin(Time.time * 2f), 0f, 0f);
			topJawTargetRotation = topJawStartRotation * Quaternion.Euler(2f * Mathf.Sin(Time.time * 2f), 0f, 0f);
			float num = 10f;
			botJawSpring.speed = 20f;
			topJawSpring.speed = 20f;
			if (Object.op_Implicit((Object)(object)playerTarget.voiceChat))
			{
				num = playerTarget.voiceChat.clipLoudness * 100f;
			}
			num = Mathf.Clamp(num, 0f, 10f);
			topJawTargetRotation *= Quaternion.Euler(topJawStartRotation.x + num, topJawStartRotation.y, topJawStartRotation.z);
			botJawTargetRotation *= Quaternion.Euler(botJawStartRotation.x - num, botJawStartRotation.y, botJawStartRotation.z);
			if (SemiFunc.PerSecond(15f, (Object)(object)this))
			{
				topJawSpring.springVelocity = Random.insideUnitSphere * 0.2f;
				botJawSpring.springVelocity = Random.insideUnitSphere * 0.2f;
			}
		}
	}

	private void StatePuke()
	{
		//IL_010b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0036: Unknown result type (might be due to invalid IL or missing references)
		//IL_003b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0067: Unknown result type (might be due to invalid IL or missing references)
		//IL_0095: Unknown result type (might be due to invalid IL or missing references)
		//IL_00aa: Unknown result type (might be due to invalid IL or missing references)
		//IL_016f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0184: Unknown result type (might be due to invalid IL or missing references)
		//IL_013d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0152: Unknown result type (might be due to invalid IL or missing references)
		//IL_01ab: Unknown result type (might be due to invalid IL or missing references)
		//IL_01bf: Unknown result type (might be due to invalid IL or missing references)
		//IL_01c4: Unknown result type (might be due to invalid IL or missing references)
		//IL_01c9: Unknown result type (might be due to invalid IL or missing references)
		//IL_01d0: Unknown result type (might be due to invalid IL or missing references)
		//IL_01e4: Unknown result type (might be due to invalid IL or missing references)
		//IL_01e9: Unknown result type (might be due to invalid IL or missing references)
		//IL_01ee: Unknown result type (might be due to invalid IL or missing references)
		//IL_0206: Unknown result type (might be due to invalid IL or missing references)
		//IL_0210: Unknown result type (might be due to invalid IL or missing references)
		//IL_0215: Unknown result type (might be due to invalid IL or missing references)
		//IL_0220: Unknown result type (might be due to invalid IL or missing references)
		//IL_022a: Unknown result type (might be due to invalid IL or missing references)
		//IL_022f: Unknown result type (might be due to invalid IL or missing references)
		if (!Object.op_Implicit((Object)(object)playerTarget))
		{
			return;
		}
		if (stateStart)
		{
			stateStart = false;
			if (playerTarget.isLocal)
			{
				Vector3 localScale = pukeCapsuleTransform.localScale;
				localScale.x = 0f;
				GameDirector.instance.CameraShake.ShakeDistance(4f, 3f, 8f, localParentTransform.position, 0.1f);
				GameDirector.instance.CameraImpact.ShakeDistance(6f, 3f, 8f, localParentTransform.position, 0.1f);
				pukeCapsuleTransform.localScale = localScale;
			}
		}
		float num = Mathf.Sin(Time.time * 40f) * 0.05f;
		loudnessTarget = 0.2f + num;
		scaleTarget = 1f;
		if (playerTarget.isLocal)
		{
			GameDirector.instance.CameraShake.ShakeDistance(4f, 3f, 8f, localParentTransform.position, 0.1f);
		}
		if (((Component)semiPuke).gameObject.activeInHierarchy)
		{
			semiPuke.PukeActive(((Component)semiPuke).transform.position, ((Component)playerTarget.localCamera).transform.rotation);
		}
		else
		{
			otherSemiPuke.PukeActive(((Component)otherSemiPuke).transform.position, playerTarget.localCamera.GetOverrideTransform().rotation);
		}
		pukeTimer = 0.2f;
		if (playerTarget.isLocal)
		{
			botJawTargetRotation = botJawStartRotation * Quaternion.Euler(-25f, 0f, 0f);
			topJawTargetRotation = topJawStartRotation * Quaternion.Euler(25f, 0f, 0f);
			if (SemiFunc.PerSecond(15f, (Object)(object)this))
			{
				topJawSpring.springVelocity = Random.insideUnitSphere * 5f;
				botJawSpring.springVelocity = Random.insideUnitSphere * 5f;
			}
		}
	}

	private void StateOutro()
	{
		//IL_00dd: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f2: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f7: Unknown result type (might be due to invalid IL or missing references)
		//IL_00fc: Unknown result type (might be due to invalid IL or missing references)
		//IL_0103: Unknown result type (might be due to invalid IL or missing references)
		//IL_0119: Unknown result type (might be due to invalid IL or missing references)
		//IL_011e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0123: Unknown result type (might be due to invalid IL or missing references)
		//IL_012a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0130: Unknown result type (might be due to invalid IL or missing references)
		//IL_0144: Unknown result type (might be due to invalid IL or missing references)
		//IL_0149: Unknown result type (might be due to invalid IL or missing references)
		//IL_014f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0154: Unknown result type (might be due to invalid IL or missing references)
		if (stateStart)
		{
			stateStart = false;
			stateTimer = 1f;
			((Component)particles).gameObject.SetActive(true);
			if (Object.op_Implicit((Object)(object)playerTarget) && playerTarget.isLocal)
			{
				GameDirector.instance.CameraShake.Shake(1f, 0.1f);
				GameDirector.instance.CameraImpact.Shake(2f, 0.05f);
			}
		}
		loudnessTarget = 0f;
		scaleTarget = 0f;
		if (Object.op_Implicit((Object)(object)playerTarget) && playerTarget.isLocal)
		{
			float num = curveIntroOutro.Evaluate(1f - stateTimer);
			openAngleTarget = Mathf.LerpUnclamped(0f, 125f, num);
			topJawTargetRotation = topJawStartRotation * Quaternion.Euler(openAngleTarget, 0f, 0f);
			botJawTargetRotation = botJawStartRotation * Quaternion.Euler(0f - openAngleTarget, 0f, 0f);
			jawTargetPosition = Vector3.LerpUnclamped(jawStartPosition, jawStartPosition + new Vector3(0f, 0.2f, -0.4f), num);
		}
		if (stateTimer < 0f)
		{
			if (Object.op_Implicit((Object)(object)enemySlowMouth) && enemySlowMouth.currentState != EnemySlowMouth.State.Detach && enemySlowMouth.currentState != EnemySlowMouth.State.Leave)
			{
				enemySlowMouth.UpdateState(EnemySlowMouth.State.Detach);
			}
			Object.Destroy((Object)(object)((Component)otherTopJawTransform).gameObject);
			Object.Destroy((Object)(object)((Component)otherBotJawTransform).gameObject);
			Object.Destroy((Object)(object)((Component)localParentTransform).gameObject);
			Object.Destroy((Object)(object)((Component)this).gameObject);
		}
	}

	private void StateSynchingWithParentEnemy()
	{
		if (!Object.op_Implicit((Object)(object)enemySlowMouth) && !debug)
		{
			StateSet(State.Outro);
			return;
		}
		bool flag = Object.op_Implicit((Object)(object)enemySlowMouth) && enemySlowMouth.currentState == EnemySlowMouth.State.Puke;
		bool flag2 = Object.op_Implicit((Object)(object)enemySlowMouth) && (enemySlowMouth.currentState == EnemySlowMouth.State.Attached || enemySlowMouth.currentState == EnemySlowMouth.State.Puke || enemySlowMouth.currentState == EnemySlowMouth.State.Detach);
		if (debug | flag2)
		{
			if (flag)
			{
				StateSet(State.Puke);
			}
			else if (state != State.Intro)
			{
				StateSet(State.Idle);
			}
		}
		else
		{
			StateSet(State.Outro);
		}
	}

	private void StateMachine()
	{
		if (stateTimer > 0f)
		{
			stateTimer -= Time.deltaTime;
		}
		switch (state)
		{
		case State.Intro:
			StateIntro();
			break;
		case State.Idle:
			StateIdle();
			break;
		case State.Puke:
			StatePuke();
			break;
		case State.Outro:
			StateOutro();
			break;
		}
	}

	public void StateSet(State newState)
	{
		if (state != newState)
		{
			statePrev = state;
			state = newState;
			stateStart = true;
			stateTimer = 0f;
		}
	}

	private void PukeParticles(bool _play)
	{
		foreach (ParticleSystem pukeParticle in pukeParticles)
		{
			if (_play)
			{
				if (!pukeParticle.isPlaying)
				{
					pukeParticle.Play();
				}
			}
			else if (pukeParticle.isPlaying)
			{
				pukeParticle.Stop();
			}
		}
	}

	private void Update()
	{
		//IL_00ca: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e5: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f5: Unknown result type (might be due to invalid IL or missing references)
		//IL_0110: Unknown result type (might be due to invalid IL or missing references)
		//IL_0073: Unknown result type (might be due to invalid IL or missing references)
		//IL_0078: Unknown result type (might be due to invalid IL or missing references)
		//IL_008e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0093: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a0: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b2: Unknown result type (might be due to invalid IL or missing references)
		//IL_02a4: Unknown result type (might be due to invalid IL or missing references)
		//IL_02a9: Unknown result type (might be due to invalid IL or missing references)
		//IL_02b9: Unknown result type (might be due to invalid IL or missing references)
		//IL_02c9: Unknown result type (might be due to invalid IL or missing references)
		//IL_031a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0324: Unknown result type (might be due to invalid IL or missing references)
		//IL_033b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0345: Unknown result type (might be due to invalid IL or missing references)
		//IL_035c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0366: Unknown result type (might be due to invalid IL or missing references)
		//IL_0184: Unknown result type (might be due to invalid IL or missing references)
		//IL_0189: Unknown result type (might be due to invalid IL or missing references)
		//IL_0199: Unknown result type (might be due to invalid IL or missing references)
		//IL_01aa: Unknown result type (might be due to invalid IL or missing references)
		//IL_01af: Unknown result type (might be due to invalid IL or missing references)
		//IL_01c4: Unknown result type (might be due to invalid IL or missing references)
		//IL_01ce: Unknown result type (might be due to invalid IL or missing references)
		//IL_01d3: Unknown result type (might be due to invalid IL or missing references)
		//IL_01e4: Unknown result type (might be due to invalid IL or missing references)
		//IL_01e9: Unknown result type (might be due to invalid IL or missing references)
		//IL_01fe: Unknown result type (might be due to invalid IL or missing references)
		//IL_0208: Unknown result type (might be due to invalid IL or missing references)
		//IL_020d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0227: Unknown result type (might be due to invalid IL or missing references)
		//IL_022c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0253: Unknown result type (might be due to invalid IL or missing references)
		//IL_02f2: Unknown result type (might be due to invalid IL or missing references)
		//IL_0274: Unknown result type (might be due to invalid IL or missing references)
		if (Object.op_Implicit((Object)(object)playerTarget) && Object.op_Implicit((Object)(object)playerTarget.voiceChat))
		{
			playerTarget.voiceChat.OverrideClipLoudnessAnimationValue(loudnessAdd);
		}
		loudnessAdd = SemiFunc.SpringFloatGet(loudnessSpring, loudnessTarget);
		if (Object.op_Implicit((Object)(object)playerTarget))
		{
			Quaternion rotation = playerTarget.playerAvatarVisuals.playerEyes.eyeLeft.rotation;
			Quaternion rotation2 = playerTarget.playerAvatarVisuals.playerEyes.eyeRight.rotation;
			eyeTransforms[0].rotation = rotation;
			eyeTransforms[1].rotation = rotation2;
		}
		StateSynchingWithParentEnemy();
		StateMachine();
		otherTopJawTransform.localScale = Vector3.one * SemiFunc.SpringFloatGet(springFloatScale, scaleTarget);
		otherBotJawTransform.localScale = Vector3.one * SemiFunc.SpringFloatGet(springFloatScale, scaleTarget);
		if (Object.op_Implicit((Object)(object)playerTarget) && playerTarget.isLocal)
		{
			if (pukeTimer > 0f && ((Component)localParentTransform).gameObject.activeInHierarchy)
			{
				PukeParticles(_play: true);
				pukeTimer -= Time.deltaTime;
				pukeCapsuleTransform.localScale = Vector3.Lerp(pukeCapsuleTransform.localScale, Vector3.one, Time.deltaTime * 5f);
				Transform val = pukeCapsuleTransform;
				val.localScale += Vector3.one * Mathf.Sin(Time.time * 30f) * 0.01f;
				Transform val2 = pukeCapsuleTransform;
				val2.localScale += Vector3.one * Mathf.Sin(Time.time * 60f) * 0.01f;
				Vector2 textureOffset = ((Renderer)pukeCapsuleRenderer).material.GetTextureOffset("_MainTex");
				textureOffset.x -= Time.deltaTime * 1.5f;
				((Renderer)pukeCapsuleRenderer).material.SetTextureOffset("_MainTex", textureOffset);
				if (!((Component)pukeCapsuleTransform).gameObject.activeSelf)
				{
					pukeCapsuleTransform.localScale = Vector3.zero;
					((Component)pukeCapsuleTransform).gameObject.SetActive(true);
				}
			}
			else
			{
				PukeParticles(_play: false);
				pukeCapsuleTransform.localScale = Vector3.Lerp(pukeCapsuleTransform.localScale, Vector3.zero, Time.deltaTime * 5f);
				if (pukeCapsuleTransform.localScale.x < 0.01f && ((Component)pukeCapsuleTransform).gameObject.activeSelf)
				{
					pukeCapsuleTransform.localScale = Vector3.zero;
					((Component)pukeCapsuleTransform).gameObject.SetActive(false);
				}
			}
			localParentTransform.localPosition = SemiFunc.SpringVector3Get(jawPositionSpring, jawTargetPosition);
			topJawTransform.localRotation = SemiFunc.SpringQuaternionGet(topJawSpring, topJawTargetRotation);
			botJawTransform.localRotation = SemiFunc.SpringQuaternionGet(botJawSpring, botJawTargetRotation);
		}
		if (Object.op_Implicit((Object)(object)playerTarget) && playerTarget.isLocal)
		{
			bool flag = showDebug || playerTarget.localCamera.GetOverrideActive() || playerTarget.playerAvatarVisuals.showSelfOverrideTimer > 0f;
			((Component)localParentTransform).gameObject.SetActive(!flag);
			((Component)otherTopJawTransform).gameObject.SetActive(flag);
			((Component)otherBotJawTransform).gameObject.SetActive(flag);
		}
	}

	private void OnDisable()
	{
		//IL_0052: Unknown result type (might be due to invalid IL or missing references)
		//IL_0057: Unknown result type (might be due to invalid IL or missing references)
		//IL_0063: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		if (Object.op_Implicit((Object)(object)playerTarget) && playerTarget.isDisabled)
		{
			if (Object.op_Implicit((Object)(object)enemySlowMouth))
			{
				enemySlowMouth.UpdateState(EnemySlowMouth.State.Detach);
				Transform overrideTransform = playerTarget.localCamera.GetOverrideTransform();
				enemySlowMouth.detachPosition = overrideTransform.position;
				enemySlowMouth.detachRotation = overrideTransform.rotation;
			}
			Object.Destroy((Object)(object)((Component)otherTopJawTransform).gameObject);
			Object.Destroy((Object)(object)((Component)otherBotJawTransform).gameObject);
			Object.Destroy((Object)(object)((Component)localParentTransform).gameObject);
			Object.Destroy((Object)(object)((Component)this).gameObject);
		}
	}
}
