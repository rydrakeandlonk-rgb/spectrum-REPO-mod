using System;
using System.Collections;
using Photon.Pun;
using UnityEngine;

public class PhysGrabHinge : MonoBehaviour
{
	public enum BounceEffect
	{
		Light,
		Medium,
		Heavy
	}

	private PhotonView photon;

	public HingeAudio hingeAudio;

	public AudioSource audioSource;

	[Space]
	public Transform hingePoint;

	private Rigidbody hingePointRb;

	private bool hingePointHasRb;

	[Space]
	public float hingeOffsetPositiveThreshold = 15f;

	public float hingeOffsetNegativeThreshold = -15f;

	public float hingeOffsetSpeed = 5f;

	public Vector3 hingeOffsetPositive;

	public Vector3 hingeOffsetNegative;

	private Vector3 hingePointPosition;

	[Space]
	public float hingeBreakShake = 3f;

	[Space]
	public float closeThreshold = 10f;

	public float closeMaxSpeed = 1f;

	public float closeHeavySpeed = 5f;

	public float closeShake = 3f;

	private bool closeHeavy;

	private float closeSpeed;

	internal bool closed = true;

	private float closedForceTimer;

	private bool closing;

	private float closeDisableTimer;

	[Space]
	public float openHeavyThreshold = 3f;

	private float openForceNeeded = 0.04f;

	public float openShake = 3f;

	internal HingeJoint joint;

	private PhysGrabObject physGrabObject;

	private PhysGrabObjectImpactDetector impactDetector;

	private bool moveLoopActive;

	private float moveLoopEndDisableTimer;

	[HideInInspector]
	public Sound moveLoop;

	private Vector3 restPosition;

	private Quaternion restRotation;

	internal bool dead;

	private float deadTimer = 0.1f;

	internal bool broken;

	internal float brokenTimer;

	[Space]
	public float drag;

	[Space]
	public float bounceAmount = 0.2f;

	public BounceEffect bounceEffect = BounceEffect.Medium;

	private Vector3 bounceVelocity;

	private float bounceCooldown;

	[Space]
	public bool springy;

	public float springyStrength = 0.1f;

	public float springyStrengthColliding = 0.025f;

	private float springyCollidingTimer;

	private Quaternion springyTargetRotation;

	private float springyDeltaCloseTimer;

	[Space]
	public PhysGrabHinge[] wallTagHinges;

	public GameObject[] wallTagObjects;

	public LowPassTrigger[] lowPassTriggers;

	private float investigateDelay;

	private float investigateRadius;

	private bool fadeOutFast;

	private void Awake()
	{
		//IL_006f: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a5: Unknown result type (might be due to invalid IL or missing references)
		//IL_00aa: Unknown result type (might be due to invalid IL or missing references)
		//IL_00dd: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e2: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ee: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f3: Unknown result type (might be due to invalid IL or missing references)
		//IL_012e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0171: Unknown result type (might be due to invalid IL or missing references)
		//IL_0176: Unknown result type (might be due to invalid IL or missing references)
		photon = ((Component)this).GetComponent<PhotonView>();
		Sound.CopySound(hingeAudio.moveLoop, moveLoop);
		moveLoop.Source = audioSource;
		joint = ((Component)this).GetComponent<HingeJoint>();
		physGrabObject = ((Component)this).GetComponent<PhysGrabObject>();
		impactDetector = ((Component)this).GetComponent<PhysGrabObjectImpactDetector>();
		impactDetector.particleDisable = true;
		((Joint)joint).anchor = hingePoint.localPosition;
		hingePointRb = ((Component)hingePoint).GetComponent<Rigidbody>();
		if (Object.op_Implicit((Object)(object)hingePointRb))
		{
			hingePointHasRb = true;
			hingePointPosition = hingePoint.position;
		}
		if (SemiFunc.IsMultiplayer() && SemiFunc.IsNotMasterClient())
		{
			Object.Destroy((Object)(object)joint);
			joint = null;
			hingePointHasRb = false;
		}
		restPosition = ((Component)this).transform.position;
		restRotation = ((Component)this).transform.rotation;
		((MonoBehaviour)this).StartCoroutine(RigidBodyGet());
		((Component)this).gameObject.layer = LayerMask.NameToLayer("PhysGrabObjectHinge");
		foreach (Transform item in ((Component)this).transform)
		{
			((Component)item).gameObject.layer = LayerMask.NameToLayer("PhysGrabObjectHinge");
		}
		if (springy)
		{
			springyTargetRotation = ((Component)this).transform.rotation;
		}
	}

	private IEnumerator RigidBodyGet()
	{
		while (!physGrabObject.spawned)
		{
			yield return (object)new WaitForSeconds(0.1f);
		}
		((Component)hingePoint).transform.parent = ((Component)this).transform.parent;
		WallTagSet();
	}

	private void OnCollisionStay(Collision other)
	{
		if (other.gameObject.CompareTag("Player"))
		{
			closeDisableTimer = 0.1f;
		}
		else if (closing && other.gameObject.CompareTag("Phys Grab Object"))
		{
			closing = false;
		}
	}

	private void OnJointBreak(float breakForce)
	{
		//IL_0029: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0038: Unknown result type (might be due to invalid IL or missing references)
		//IL_0059: Unknown result type (might be due to invalid IL or missing references)
		//IL_005e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		if (GameManager.instance.gameMode == 0 || PhotonNetwork.IsMasterClient)
		{
			physGrabObject.rb.AddForce(-physGrabObject.rb.linearVelocity * 2f, (ForceMode)1);
			physGrabObject.rb.AddTorque(-physGrabObject.rb.angularVelocity * 10f, (ForceMode)1);
			HingeBreakImpulse();
			broken = true;
		}
	}

	private void FixedUpdate()
	{
		//IL_008a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0096: Unknown result type (might be due to invalid IL or missing references)
		//IL_009b: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a0: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a5: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b1: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b6: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c8: Unknown result type (might be due to invalid IL or missing references)
		//IL_00cf: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d4: Unknown result type (might be due to invalid IL or missing references)
		//IL_016f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0175: Unknown result type (might be due to invalid IL or missing references)
		//IL_0186: Unknown result type (might be due to invalid IL or missing references)
		//IL_018b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0104: Unknown result type (might be due to invalid IL or missing references)
		//IL_0110: Unknown result type (might be due to invalid IL or missing references)
		//IL_0115: Unknown result type (might be due to invalid IL or missing references)
		//IL_011a: Unknown result type (might be due to invalid IL or missing references)
		//IL_011f: Unknown result type (might be due to invalid IL or missing references)
		//IL_012b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0130: Unknown result type (might be due to invalid IL or missing references)
		//IL_013d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0142: Unknown result type (might be due to invalid IL or missing references)
		//IL_0149: Unknown result type (might be due to invalid IL or missing references)
		//IL_014e: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e5: Unknown result type (might be due to invalid IL or missing references)
		//IL_01a3: Unknown result type (might be due to invalid IL or missing references)
		//IL_01a8: Unknown result type (might be due to invalid IL or missing references)
		//IL_0196: Unknown result type (might be due to invalid IL or missing references)
		//IL_019b: Unknown result type (might be due to invalid IL or missing references)
		//IL_015c: Unknown result type (might be due to invalid IL or missing references)
		//IL_01ff: Unknown result type (might be due to invalid IL or missing references)
		//IL_0204: Unknown result type (might be due to invalid IL or missing references)
		//IL_0208: Unknown result type (might be due to invalid IL or missing references)
		//IL_0213: Unknown result type (might be due to invalid IL or missing references)
		//IL_0218: Unknown result type (might be due to invalid IL or missing references)
		//IL_0228: Unknown result type (might be due to invalid IL or missing references)
		//IL_022d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0231: Unknown result type (might be due to invalid IL or missing references)
		//IL_0248: Unknown result type (might be due to invalid IL or missing references)
		//IL_024d: Unknown result type (might be due to invalid IL or missing references)
		//IL_01b7: Unknown result type (might be due to invalid IL or missing references)
		//IL_0603: Unknown result type (might be due to invalid IL or missing references)
		//IL_0608: Unknown result type (might be due to invalid IL or missing references)
		//IL_041d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0422: Unknown result type (might be due to invalid IL or missing references)
		//IL_031e: Unknown result type (might be due to invalid IL or missing references)
		//IL_032e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0333: Unknown result type (might be due to invalid IL or missing references)
		//IL_0337: Unknown result type (might be due to invalid IL or missing references)
		//IL_033c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0341: Unknown result type (might be due to invalid IL or missing references)
		//IL_0343: Unknown result type (might be due to invalid IL or missing references)
		//IL_034b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0350: Unknown result type (might be due to invalid IL or missing references)
		//IL_035d: Unknown result type (might be due to invalid IL or missing references)
		//IL_02bb: Unknown result type (might be due to invalid IL or missing references)
		//IL_02c0: Unknown result type (might be due to invalid IL or missing references)
		//IL_0290: Unknown result type (might be due to invalid IL or missing references)
		//IL_0295: Unknown result type (might be due to invalid IL or missing references)
		//IL_0542: Unknown result type (might be due to invalid IL or missing references)
		//IL_0547: Unknown result type (might be due to invalid IL or missing references)
		//IL_0476: Unknown result type (might be due to invalid IL or missing references)
		//IL_047c: Unknown result type (might be due to invalid IL or missing references)
		//IL_05f9: Unknown result type (might be due to invalid IL or missing references)
		//IL_05fb: Unknown result type (might be due to invalid IL or missing references)
		//IL_04b1: Unknown result type (might be due to invalid IL or missing references)
		//IL_04c7: Unknown result type (might be due to invalid IL or missing references)
		//IL_04dc: Unknown result type (might be due to invalid IL or missing references)
		//IL_04f1: Unknown result type (might be due to invalid IL or missing references)
		//IL_0493: Unknown result type (might be due to invalid IL or missing references)
		//IL_0499: Unknown result type (might be due to invalid IL or missing references)
		//IL_059e: Unknown result type (might be due to invalid IL or missing references)
		//IL_05a3: Unknown result type (might be due to invalid IL or missing references)
		//IL_05a8: Unknown result type (might be due to invalid IL or missing references)
		//IL_0760: Unknown result type (might be due to invalid IL or missing references)
		//IL_0766: Unknown result type (might be due to invalid IL or missing references)
		//IL_0724: Unknown result type (might be due to invalid IL or missing references)
		//IL_073a: Unknown result type (might be due to invalid IL or missing references)
		//IL_073f: Unknown result type (might be due to invalid IL or missing references)
		//IL_074c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0782: Unknown result type (might be due to invalid IL or missing references)
		//IL_0787: Unknown result type (might be due to invalid IL or missing references)
		//IL_07e5: Unknown result type (might be due to invalid IL or missing references)
		//IL_07fb: Unknown result type (might be due to invalid IL or missing references)
		//IL_0800: Unknown result type (might be due to invalid IL or missing references)
		//IL_080d: Unknown result type (might be due to invalid IL or missing references)
		if (broken)
		{
			brokenTimer += Time.fixedDeltaTime;
		}
		if (dead || broken || !Object.op_Implicit((Object)(object)physGrabObject) || !physGrabObject.spawned || !SemiFunc.IsMasterClientOrSingleplayer())
		{
			return;
		}
		if (GameManager.Multiplayer())
		{
			physGrabObject.photonTransformView.KinematicClientForce(0.1f);
		}
		if (hingePointHasRb)
		{
			if (joint.angle >= hingeOffsetPositiveThreshold)
			{
				Vector3 val = hingePointPosition + hingePoint.TransformDirection(hingeOffsetPositive);
				Vector3 val2 = Vector3.Lerp(((Component)hingePointRb).transform.position, val, hingeOffsetSpeed * Time.fixedDeltaTime);
				if (hingePointRb.position != val2)
				{
					hingePointRb.MovePosition(val2);
				}
			}
			else if (joint.angle <= hingeOffsetNegativeThreshold)
			{
				Vector3 val3 = hingePointPosition + hingePoint.TransformDirection(hingeOffsetNegative);
				Vector3 val4 = Vector3.Lerp(((Component)hingePointRb).transform.position, val3, hingeOffsetSpeed * Time.fixedDeltaTime);
				if (hingePointRb.position != val4)
				{
					hingePointRb.MovePosition(val4);
				}
			}
			else
			{
				Vector3 val5 = Vector3.Lerp(((Component)hingePointRb).transform.position, hingePointPosition, hingeOffsetSpeed * Time.fixedDeltaTime);
				if (closed)
				{
					val5 = hingePointPosition;
				}
				if (hingePointRb.position != val5)
				{
					hingePointRb.MovePosition(val5);
				}
			}
		}
		Vector3 val6;
		if (!closed && closeDisableTimer <= 0f && Object.op_Implicit((Object)(object)joint))
		{
			if (!closing)
			{
				val6 = physGrabObject.rb.angularVelocity;
				Vector3 normalized = val6.normalized;
				val6 = -((Joint)joint).axis * joint.angle;
				float num = Vector3.Dot(normalized, val6.normalized);
				val6 = physGrabObject.rb.angularVelocity;
				if (val6.magnitude < closeMaxSpeed && Mathf.Abs(joint.angle) < closeThreshold)
				{
					if (!(num > 0f))
					{
						val6 = physGrabObject.rb.angularVelocity;
						if (!(val6.magnitude < 0.1f))
						{
							goto IL_039b;
						}
					}
					closeHeavy = false;
					val6 = physGrabObject.rb.angularVelocity;
					closeSpeed = Mathf.Max(val6.magnitude, 0.2f);
					if (closeSpeed > closeHeavySpeed)
					{
						closeHeavy = true;
					}
					closing = true;
				}
			}
			else if (physGrabObject.playerGrabbing.Count > 0)
			{
				closing = false;
			}
			else
			{
				Vector3 eulerAngles = restRotation.eulerAngles;
				Quaternion rotation = physGrabObject.rb.rotation;
				Vector3 val7 = eulerAngles - rotation.eulerAngles;
				val7 = Vector3.ClampMagnitude(val7, closeSpeed);
				physGrabObject.rb.AddRelativeTorque(val7, (ForceMode)5);
				if (Mathf.Abs(joint.angle) < 2f)
				{
					closedForceTimer = 0.25f;
					closing = false;
					CloseImpulse(closeHeavy, _sound: true);
				}
			}
		}
		goto IL_039b;
		IL_07b6:
		if (springyDeltaCloseTimer >= 0.2f)
		{
			closed = true;
			closedForceTimer = 0.25f;
			CloseImpulse(heavy: false, _sound: false);
		}
		else
		{
			Vector3 val8 = SemiFunc.PhysFollowRotation(((Component)this).transform, springyTargetRotation, physGrabObject.rb, springyStrength);
			physGrabObject.rb.AddTorque(val8, (ForceMode)1);
		}
		return;
		IL_039b:
		if (physGrabObject.playerGrabbing.Count > 0)
		{
			closeDisableTimer = 0.1f;
		}
		else if (closeDisableTimer > 0f)
		{
			closeDisableTimer -= 1f * Time.fixedDeltaTime;
		}
		if (closed)
		{
			if (closedForceTimer > 0f)
			{
				closedForceTimer -= 1f * Time.fixedDeltaTime;
			}
			else
			{
				val6 = physGrabObject.rb.angularVelocity;
				if (val6.magnitude > openForceNeeded)
				{
					OpenImpulse();
					closeDisableTimer = 2f;
					closing = false;
				}
			}
			if (closed && !physGrabObject.rb.isKinematic && (physGrabObject.rb.position != restPosition || physGrabObject.rb.rotation != restRotation))
			{
				physGrabObject.rb.MovePosition(restPosition);
				physGrabObject.rb.MoveRotation(restRotation);
				physGrabObject.rb.angularVelocity = Vector3.zero;
				physGrabObject.rb.linearVelocity = Vector3.zero;
			}
		}
		if (Object.op_Implicit((Object)(object)physGrabObject) && physGrabObject.playerGrabbing.Count <= 0 && !closing && !closed)
		{
			Vector3 angularVelocity = physGrabObject.rb.angularVelocity;
			if (angularVelocity.magnitude <= 0.1f && bounceVelocity.magnitude > 0.5f && bounceCooldown <= 0f)
			{
				bounceCooldown = 1f;
				physGrabObject.rb.AddTorque(bounceAmount * -bounceVelocity.normalized, (ForceMode)1);
				if (bounceEffect == BounceEffect.Heavy)
				{
					physGrabObject.heavyImpactImpulse = true;
				}
				else if (bounceEffect == BounceEffect.Medium)
				{
					physGrabObject.mediumImpactImpulse = true;
				}
				else
				{
					physGrabObject.lightImpactImpulse = true;
				}
				moveLoopEndDisableTimer = 1f;
			}
			bounceVelocity = angularVelocity;
		}
		else
		{
			bounceVelocity = Vector3.zero;
		}
		if (bounceCooldown > 0f)
		{
			bounceCooldown -= 1f * Time.fixedDeltaTime;
		}
		if (!closing && Object.op_Implicit((Object)(object)physGrabObject))
		{
			physGrabObject.OverrideDrag(drag);
			physGrabObject.OverrideAngularDrag(drag);
		}
		if (!springy)
		{
			return;
		}
		if (!closing && !closed)
		{
			closeDisableTimer = 0.1f;
			if (Object.op_Implicit((Object)(object)physGrabObject) && ((Object.op_Implicit((Object)(object)physGrabObject.impactDetector) && physGrabObject.impactDetector.isCollidingTimer > 0f) || physGrabObject.playerGrabbing.Count > 0))
			{
				springyCollidingTimer = Mathf.Max(springyCollidingTimer, 0.5f);
			}
			if (springyCollidingTimer > 0f)
			{
				springyCollidingTimer -= Time.fixedDeltaTime;
				Vector3 val9 = SemiFunc.PhysFollowRotation(((Component)this).transform, springyTargetRotation, physGrabObject.rb, springyStrengthColliding);
				physGrabObject.rb.AddTorque(val9, (ForceMode)1);
				return;
			}
			if (Quaternion.Angle(((Component)physGrabObject).transform.rotation, springyTargetRotation) <= 2f)
			{
				val6 = physGrabObject.rb.angularVelocity;
				if (val6.magnitude < 0.25f)
				{
					springyDeltaCloseTimer += Time.fixedDeltaTime;
					goto IL_07b6;
				}
			}
			springyDeltaCloseTimer = 0f;
			goto IL_07b6;
		}
		springyCollidingTimer = 1f;
		springyDeltaCloseTimer = 0f;
	}

	private void Update()
	{
		//IL_0165: Unknown result type (might be due to invalid IL or missing references)
		//IL_0299: Unknown result type (might be due to invalid IL or missing references)
		if (dead)
		{
			deadTimer -= 1f * Time.deltaTime;
			if (deadTimer <= 0f && Object.op_Implicit((Object)(object)impactDetector))
			{
				impactDetector.DestroyObject();
			}
			return;
		}
		if (broken)
		{
			moveLoop.PlayLoop(playing: false, 1f, 1f);
			return;
		}
		if (hingeAudio.moveLoopEnabled)
		{
			if (Object.op_Implicit((Object)(object)physGrabObject) && physGrabObject.rbVelocity.magnitude > hingeAudio.moveLoopThreshold)
			{
				if (!moveLoopActive)
				{
					fadeOutFast = false;
					moveLoopActive = true;
				}
				moveLoop.PlayLoop(playing: true, hingeAudio.moveLoopFadeInSpeed, hingeAudio.moveLoopFadeOutSpeed);
				moveLoop.LoopPitch = Mathf.Max(moveLoop.Pitch + physGrabObject.rbVelocity.magnitude * hingeAudio.moveLoopVelocityMult, 0.1f);
			}
			else
			{
				if (moveLoopActive)
				{
					if (moveLoopEndDisableTimer <= 0f)
					{
						hingeAudio.moveLoopEnd.Play(((Component)moveLoop.Source).transform.position);
						moveLoopEndDisableTimer = 3f;
					}
					moveLoopActive = false;
				}
				if (fadeOutFast)
				{
					moveLoop.PlayLoop(playing: false, hingeAudio.moveLoopFadeInSpeed, 20f);
				}
				else
				{
					moveLoop.PlayLoop(playing: false, hingeAudio.moveLoopFadeInSpeed, hingeAudio.moveLoopFadeOutSpeed);
				}
				moveLoopEndDisableTimer = 0.5f;
			}
			if (moveLoopEndDisableTimer > 0f)
			{
				moveLoopEndDisableTimer -= 1f * Time.deltaTime;
			}
		}
		if (SemiFunc.IsMasterClientOrSingleplayer() && investigateDelay > 0f)
		{
			investigateDelay -= 1f * Time.deltaTime;
			if (investigateDelay <= 0f && Object.op_Implicit((Object)(object)impactDetector) && Object.op_Implicit((Object)(object)physGrabObject) && physGrabObject.enemyInteractTimer <= 0f)
			{
				impactDetector.EnemyInvestigate(investigateRadius, physGrabObject.midPoint);
			}
		}
	}

	private void WallTagSet()
	{
		string text = "Untagged";
		if (closed && !broken && !dead)
		{
			text = "Wall";
		}
		if (text == "Wall" && wallTagHinges.Length != 0)
		{
			PhysGrabHinge[] array = wallTagHinges;
			foreach (PhysGrabHinge physGrabHinge in array)
			{
				if (!Object.op_Implicit((Object)(object)physGrabHinge) || !physGrabHinge.closed)
				{
					return;
				}
			}
		}
		if (wallTagObjects.Length != 0)
		{
			GameObject[] array2 = wallTagObjects;
			foreach (GameObject val in array2)
			{
				if (Object.op_Implicit((Object)(object)val))
				{
					val.tag = text;
				}
			}
		}
		if (lowPassTriggers.Length == 0)
		{
			return;
		}
		LowPassTrigger[] array3 = lowPassTriggers;
		foreach (LowPassTrigger lowPassTrigger in array3)
		{
			if (Object.op_Implicit((Object)(object)lowPassTrigger))
			{
				if (text == "Wall")
				{
					((Component)lowPassTrigger).gameObject.SetActive(true);
				}
				else
				{
					((Component)lowPassTrigger).gameObject.SetActive(false);
				}
			}
		}
	}

	private void EnemyInvestigate(float radius)
	{
		investigateDelay = 0.1f;
		investigateRadius = radius;
	}

	private void CloseImpulse(bool heavy, bool _sound)
	{
		//IL_001c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0022: Unknown result type (might be due to invalid IL or missing references)
		EnemyInvestigate(1f);
		if (GameManager.instance.gameMode == 0)
		{
			CloseImpulseRPC(heavy, _sound);
		}
		else if (PhotonNetwork.IsMasterClient)
		{
			photon.RPC("CloseImpulseRPC", (RpcTarget)0, new object[2] { heavy, _sound });
		}
	}

	[PunRPC]
	private void CloseImpulseRPC(bool heavy, bool _sound, PhotonMessageInfo _info = default(PhotonMessageInfo))
	{
		//IL_0000: Unknown result type (might be due to invalid IL or missing references)
		//IL_0036: Unknown result type (might be due to invalid IL or missing references)
		//IL_0065: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c7: Unknown result type (might be due to invalid IL or missing references)
		//IL_0090: Unknown result type (might be due to invalid IL or missing references)
		if (!SemiFunc.MasterOnlyRPC(_info))
		{
			return;
		}
		fadeOutFast = true;
		GameDirector.instance.CameraImpact.ShakeDistance(closeShake * 0.5f, 3f, 10f, ((Component)this).transform.position, 0.1f);
		GameDirector.instance.CameraShake.ShakeDistance(closeShake, 3f, 10f, ((Component)this).transform.position, 0.1f);
		if (_sound)
		{
			if (heavy)
			{
				hingeAudio.CloseHeavy.Play(((Component)audioSource).transform.position);
			}
			else
			{
				hingeAudio.Close.Play(((Component)audioSource).transform.position);
			}
		}
		moveLoopEndDisableTimer = 1f;
		closed = true;
		WallTagSet();
	}

	private void OpenImpulse()
	{
		//IL_001a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0020: Unknown result type (might be due to invalid IL or missing references)
		EnemyInvestigate(0.5f);
		if (GameManager.instance.gameMode == 0)
		{
			OpenImpulseRPC();
		}
		else if (PhotonNetwork.IsMasterClient)
		{
			photon.RPC("OpenImpulseRPC", (RpcTarget)0, Array.Empty<object>());
		}
	}

	[PunRPC]
	private void OpenImpulseRPC(PhotonMessageInfo _info = default(PhotonMessageInfo))
	{
		//IL_0000: Unknown result type (might be due to invalid IL or missing references)
		//IL_002f: Unknown result type (might be due to invalid IL or missing references)
		//IL_005e: Unknown result type (might be due to invalid IL or missing references)
		//IL_00df: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a8: Unknown result type (might be due to invalid IL or missing references)
		if (SemiFunc.MasterOnlyRPC(_info))
		{
			GameDirector.instance.CameraImpact.ShakeDistance(openShake * 0.5f, 3f, 10f, ((Component)this).transform.position, 0.1f);
			GameDirector.instance.CameraShake.ShakeDistance(openShake, 3f, 10f, ((Component)this).transform.position, 0.1f);
			if (Object.op_Implicit((Object)(object)physGrabObject) && physGrabObject.rbAngularVelocity.magnitude > openHeavyThreshold)
			{
				hingeAudio.OpenHeavy.Play(((Component)audioSource).transform.position);
			}
			else
			{
				hingeAudio.Open.Play(((Component)audioSource).transform.position);
			}
			closed = false;
			WallTagSet();
		}
	}

	private void HingeBreakImpulse()
	{
		//IL_000f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0015: Unknown result type (might be due to invalid IL or missing references)
		if (GameManager.instance.gameMode == 0)
		{
			HingeBreakRPC();
		}
		else if (PhotonNetwork.IsMasterClient)
		{
			photon.RPC("HingeBreakRPC", (RpcTarget)0, Array.Empty<object>());
		}
	}

	[PunRPC]
	private void HingeBreakRPC(PhotonMessageInfo _info = default(PhotonMessageInfo))
	{
		//IL_0000: Unknown result type (might be due to invalid IL or missing references)
		//IL_002f: Unknown result type (might be due to invalid IL or missing references)
		//IL_005e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0083: Unknown result type (might be due to invalid IL or missing references)
		//IL_0124: Unknown result type (might be due to invalid IL or missing references)
		if (!SemiFunc.MasterOnlyRPC(_info))
		{
			return;
		}
		GameDirector.instance.CameraImpact.ShakeDistance(hingeBreakShake * 0.5f, 3f, 10f, ((Component)this).transform.position, 0.1f);
		GameDirector.instance.CameraShake.ShakeDistance(hingeBreakShake, 3f, 10f, ((Component)this).transform.position, 0.1f);
		hingeAudio.HingeBreak.Play(((Component)audioSource).transform.position);
		if (Object.op_Implicit((Object)(object)physGrabObject))
		{
			physGrabObject.heavyBreakImpulse = true;
		}
		if (Object.op_Implicit((Object)(object)impactDetector))
		{
			impactDetector.isHinge = false;
			impactDetector.isBrokenHinge = true;
			impactDetector.particleDisable = false;
		}
		broken = true;
		WallTagSet();
		int layer = LayerMask.NameToLayer("PhysGrabObject");
		((Component)this).gameObject.layer = layer;
		foreach (Transform item in ((Component)this).transform)
		{
			((Component)item).gameObject.layer = layer;
		}
	}

	public void DestroyHinge()
	{
		//IL_000f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0015: Unknown result type (might be due to invalid IL or missing references)
		if (GameManager.instance.gameMode == 0)
		{
			DestroyHingeRPC();
		}
		else if (PhotonNetwork.IsMasterClient)
		{
			photon.RPC("DestroyHingeRPC", (RpcTarget)0, Array.Empty<object>());
		}
	}

	[PunRPC]
	private void DestroyHingeRPC(PhotonMessageInfo _info = default(PhotonMessageInfo))
	{
		//IL_0000: Unknown result type (might be due to invalid IL or missing references)
		if (SemiFunc.MasterOnlyRPC(_info))
		{
			dead = true;
			WallTagSet();
		}
	}
}
