using System;
using System.Collections.Generic;
using Photon.Pun;
using UnityEngine;

public class EnemyHeartHugger : MonoBehaviour
{
	public enum State
	{
		Spawn,
		Idle,
		Roam,
		Grow,
		AggroStart,
		Aggro,
		LureStart,
		Lure,
		LureStop,
		ChompGasp,
		Chomp,
		Degrow,
		Stunned,
		AggroGrow,
		AggroDegrow,
		IdleBreaker,
		AggroBreaker
	}

	[Serializable]
	public class SpringLimb
	{
		public SpringQuaternion spring;

		public string name;

		public Transform transform;

		public Transform target;

		[HideInInspector]
		public Quaternion originalQuaternion;

		[HideInInspector]
		public float growAmount;
	}

	[Serializable]
	public class MeshTransform
	{
		public Transform transform;

		[HideInInspector]
		public float eval;

		[HideInInspector]
		public bool soundPlayed;
	}

	[Serializable]
	public class CuteMeshTransform
	{
		public Transform transform;

		[HideInInspector]
		public float eval;

		[HideInInspector]
		public bool soundPlayed;
	}

	public class PlayersInGas
	{
		public int photonViewId;

		public PlayerAvatar playerAvatar;

		public float inGasTime;

		public bool isCaught;

		public float outsideGasTime;

		public Vector3 lastPositionInsideGas;
	}

	private PhotonView photonView;

	public Transform followTarget;

	public Transform headLook;

	private List<PlayersInGas> playersInGas = new List<PlayersInGas>();

	private List<PlayersInGas> playersInGasPrevious = new List<PlayersInGas>();

	private List<PlayerAvatar> playersInGasClient = new List<PlayerAvatar>();

	private Dictionary<PlayerAvatar, float> playersOnCooldown = new Dictionary<PlayerAvatar, float>();

	[Space]
	public List<SpringLimb> springLimbs = new List<SpringLimb>();

	[Space]
	public List<Transform> vineTransforms = new List<Transform>();

	[Space]
	public List<MeshTransform> meshTransforms = new List<MeshTransform>();

	[Space]
	public List<CuteMeshTransform> cuteMeshTransforms = new List<CuteMeshTransform>();

	public State currentState = State.Idle;

	private bool stateStart;

	private float stateTimer;

	private float stateTimerMax;

	private float lureTimerMax;

	private bool isFixedUpdate;

	private PlayerAvatar currentTarget;

	private bool hasTarget;

	private PlayerAvatar networkTargetPending;

	private int networkTargetViewID = -1;

	private bool networkTargetDirty;

	private float hugVOTimer;

	public AnimationCurve growAnimationCurve;

	public AnimationCurve popAwayMeshesCurve;

	public AnimationCurve popBackMeshesCurve;

	public AnimationCurve biteCurve;

	public AnimationCurve biteScaleBounceCurve;

	public AnimationCurve idleBreakerCurve;

	[Space(30f)]
	public Sound popAwaySound;

	[Space(5f)]
	public Sound soundIdleLoop;

	public Sound soundStunLoop;

	public Sound soundGrow;

	public Sound soundDegrow;

	public Sound soundChompThrust;

	public Sound soundChompBite;

	public Sound soundGasLoop;

	public Sound soundAggroLoop;

	public Sound soundGasStart;

	public Sound soundGasTell;

	public Sound soundScare;

	public Sound soundScareGlobal;

	public Sound soundMove;

	public Sound soundMoveHead;

	public Sound soundGasStop;

	[Space(5f)]
	public Sound soundIdleBreaker01;

	public Sound soundIdleBreaker02;

	public Sound soundIdleBreaker03;

	[Space(5f)]
	public Sound soundAggroBreaker01;

	public Sound soundAggroBreaker02;

	public Sound soundAggroBreaker03;

	[Space(5f)]
	public Sound soundAggroStart;

	[Space(5f)]
	public Sound soundEnchantedVO;

	public Sound soundEnchantedLoop;

	[Space(5f)]
	public Sound soundHurt;

	public Sound soundDeath;

	private bool growDone = true;

	private float vineRotation;

	private float vineRotationSpeed = 50f;

	private float baseRotation;

	private float overrideSpringValuesTimer;

	private float overrideSpringValuesSpeed = 15f;

	private float overrideSpringValuesDamping = 0.5f;

	private float localGameTime;

	private float canAggroTimer;

	private bool canAggro;

	private Vector3 investigatePosition;

	[Space(30f)]
	public GameObject horrorMesh1;

	public GameObject horrorMesh2;

	public GameObject normalMesh1;

	public GameObject normalMesh2;

	[Space(10f)]
	public GameObject biteMesh;

	public Transform headSegment1TargetTransform;

	public Transform headSegment2TargetTransform;

	public Transform headCenterTransform;

	public GameObject biteHurtCollider;

	[Space(10f)]
	public Transform breatheScaleParent1;

	public Transform breatheScaleParent2;

	public Transform holeScaleParent1;

	public Transform holeScaleParent2;

	[Space(10f)]
	public GameObject gasChecker;

	public Transform mouthTransform;

	[Space(10f)]
	public Rigidbody rb;

	[Space(10f)]
	public Transform baseMeshScale;

	public Transform baseMeshScaleTarget;

	[Space(10f)]
	public Transform cuteMeshRightClosedMouth;

	public Transform cuteMeshLeftClosedMouth;

	public Transform cuteMeshRightOpenMouth;

	public Transform cuteMeshLeftOpenMouth;

	[Space(30f)]
	public Light headLight;

	public ParticleSystem headParticles;

	public ParticleSystem gasParticles;

	public ParticleSystem particlesShatteredDream;

	public ParticleSystem particlesHearts;

	public List<ParticleSystem> particlesDeath;

	private SpringVector3 scaleBreathing;

	private Vector3 scaleBreathingTarget;

	private Vector3 scaleBreathingCurrent;

	private SpringVector3 holeScaleBreathing;

	private Vector3 holeScaleBreathingTarget;

	private Vector3 holeScaleBreathingCurrent;

	private float lookAtActiveTimer;

	[Space(30f)]
	public List<AudioSource> audioSources = new List<AudioSource>();

	private float shootGasTimer;

	internal bool isShootingGas;

	private float gasCheckerEmissionTimer;

	private bool playingLoopSound;

	private float playLoopSoundTimer;

	private Sound currentLoopSound;

	internal bool disabled;

	private int bites;

	private Quaternion prevHeadLookRotation;

	private Quaternion prevRigidBodyRotation;

	private float turnRandomTimer;

	private float turnRandomTimerMax;

	private float turnRandomTimerMin;

	private float moveSoundHeadTimer;

	private float moveSoundRigidBodyTimer;

	private List<LevelPoint> levelPoints = new List<LevelPoint>();

	private bool doAttack;

	private bool doLeave;

	private bool doDespawn;

	private int attacksInARow;

	private int aggroBreakersInARow;

	internal Enemy enemy;

	private int idleBreakerIndex;

	private float overrideActivateHorrorMeshesTimer;

	private bool horrorMeshesActive;

	private SpringVector3 baseScaleSpring = new SpringVector3();

	private float overrideVisualsToEnchantedTimer;

	private bool overrideVisualsToEnchantedTransitioning;

	private bool overrideVisualsToEnchanted;

	private bool overrideVisualsToEnchantedInstantTransition;

	private float particlePlayHeartsTimer;

	private float particlePlayGasTimer;

	private int instanceID;

	private float releaseGrabTimer;

	private void Awake()
	{
		//IL_004a: Unknown result type (might be due to invalid IL or missing references)
		//IL_004f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0067: Unknown result type (might be due to invalid IL or missing references)
		//IL_006c: Unknown result type (might be due to invalid IL or missing references)
		baseScaleSpring = new SpringVector3();
		scaleBreathing = new SpringVector3();
		holeScaleBreathing = new SpringVector3();
		photonView = ((Component)this).GetComponent<PhotonView>();
		foreach (SpringLimb springLimb in springLimbs)
		{
			springLimb.originalQuaternion = springLimb.transform.localRotation;
			if (springLimb.name == "head look")
			{
				springLimb.originalQuaternion = Quaternion.identity;
			}
		}
		enemy = ((Component)this).GetComponent<Enemy>();
		hasTarget = true;
		if (SemiFunc.IsMultiplayer())
		{
			instanceID = photonView.ViewID;
		}
		else
		{
			instanceID = ((Object)((Component)this).gameObject).GetInstanceID();
		}
		ResetLocalGameTime();
	}

	private void Update()
	{
		localGameTime += Time.deltaTime;
		EnemySystemStateTriggers();
		StateMachine();
		if (stateTimer <= stateTimerMax)
		{
			stateTimer += Time.deltaTime;
		}
		VisualUpdateSprings();
		VisualRotateVines();
		OverrideSpringValuesTick();
		PlayLoopSoundLogic();
		VisualScaleBreathing();
		ShootGasLogic();
		TurnSoundLogic();
		PlayersInGasLogic();
		OverrideVisualsToEnchantedLogic();
		OverrideActivateHorrorMeshesTick();
		OverrideVisualsToEnchantedTick();
		PlayersOnCooldownTick();
		ParticlePlayGasTick();
		ParticlePlayHeartsTick();
		OverrideCanAggroTick();
		InvestigatePositionReset();
		AttacksInARowReset();
		AggroBreakersInARowReset();
		LeaveReset();
		DespawnReset();
		GrowDoneReset();
		LookAtTargetReset();
		ReleaseGrabLogic();
		PhysGrabberDisable();
	}

	private void FixedUpdate()
	{
		if (SemiFunc.IsMasterClientOrSingleplayer())
		{
			isFixedUpdate = true;
			StateMachine();
			isFixedUpdate = false;
		}
	}

	private void LateUpdate()
	{
		NetworkTargetFlush();
	}

	private void NetworkTargetFlush()
	{
		if (networkTargetDirty)
		{
			networkTargetDirty = false;
			if (SemiFunc.IsMasterClientOrSingleplayer() && GameManager.Multiplayer() && Object.op_Implicit((Object)(object)networkTargetPending))
			{
				NetworkTargetSend(networkTargetPending);
			}
		}
	}

	private void NetworkTargetSend(PlayerAvatar _target)
	{
		int viewID = _target.photonView.ViewID;
		if (networkTargetViewID != viewID)
		{
			networkTargetViewID = viewID;
			photonView.RPC("UpdateCurrentTargetRPC", (RpcTarget)0, new object[1] { viewID });
		}
	}

	private void OnEnable()
	{
		networkTargetPending = null;
		networkTargetViewID = -1;
		networkTargetDirty = false;
		ParticleSystem val = headParticles;
		if (val != null)
		{
			val.Play(true);
		}
	}

	private void OnDisable()
	{
		ParticleSystem val = headParticles;
		if (val != null)
		{
			val.Stop(true);
		}
		gasParticles.Stop(true);
		particlesShatteredDream.Stop(true);
		particlesHearts.Stop(true);
	}

	private void StateSpawn()
	{
		//IL_003f: Unknown result type (might be due to invalid IL or missing references)
		if (stateStart && !isFixedUpdate)
		{
			stateStart = false;
			stateTimerMax = 3f;
			stateTimer = 0f;
			GrowStart();
			soundGrow.Play(((Component)this).transform.position);
		}
		if (!isFixedUpdate)
		{
			enemy.StateStunned.OverrideDisable(0.5f);
			VisualGrowAnimation();
			VisualGrowDance();
			if (growDone)
			{
				StateSet(State.Idle);
			}
		}
		_ = isFixedUpdate;
	}

	private void StateIdle()
	{
		//IL_0094: Unknown result type (might be due to invalid IL or missing references)
		if (stateStart && !isFixedUpdate)
		{
			stateStart = false;
			stateTimerMax = Random.Range(5f, 15f);
			stateTimer = 0f;
			doAttack = true;
			TurnRandomTimer(5f, 10f);
		}
		if (!isFixedUpdate)
		{
			OverrideCanAggro();
			VisualStateNormal();
			TurnRandomFull();
			if (SemiFunc.EnemySpawnIdlePause())
			{
				return;
			}
			if (SemiFunc.IsMasterClientOrSingleplayer() && stateTimer >= stateTimerMax)
			{
				if (Random.Range(0, 2) == 0 && SemiFunc.PlayerNearestDistance(((Component)this).transform.position) <= 20f)
				{
					int idleBreaker = Random.Range(0, 2);
					StateSetIdleBreaker(idleBreaker);
				}
				else
				{
					StateSet(State.Roam);
				}
			}
		}
		_ = isFixedUpdate;
	}

	private void StateRoam()
	{
		if (stateStart && !isFixedUpdate)
		{
			stateStart = false;
			stateTimerMax = Random.Range(5f, 10f);
			stateTimer = 0f;
			doAttack = true;
			TurnRandomTimer(3f, 6f);
		}
		if (!isFixedUpdate)
		{
			VisualStateNormal();
			TurnRandomFull();
			OverrideCanAggro();
			if (stateTimer >= stateTimerMax)
			{
				StateSet(State.Degrow);
			}
		}
		_ = isFixedUpdate;
	}

	private void StateGrow()
	{
		//IL_0047: Unknown result type (might be due to invalid IL or missing references)
		//IL_004c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0072: Unknown result type (might be due to invalid IL or missing references)
		if (stateStart && !isFixedUpdate)
		{
			stateStart = false;
			stateTimerMax = 3f;
			stateTimer = 0f;
			GrowStart();
			if (doLeave)
			{
				LevelPointsLeave();
			}
			else if (investigatePosition != Vector3.zero)
			{
				LevelPointsInvestigate();
			}
			else
			{
				LevelPointsRoam();
			}
			soundGrow.Play(((Component)this).transform.position);
		}
		if (!isFixedUpdate)
		{
			VisualGrowAnimation();
			VisualGrowDance();
			enemy.StateStunned.OverrideDisable(0.5f);
			if (growDone)
			{
				StateSet(State.Idle);
			}
		}
		_ = isFixedUpdate;
	}

	private void StateAggro()
	{
		if (stateStart && !isFixedUpdate)
		{
			stateStart = false;
			stateTimer = 0f;
			stateTimerMax = Random.Range(0.2f, 1f);
		}
		if (!isFixedUpdate)
		{
			OverrideCanAggro();
			VisualStateAggro();
			LookAtTarget();
			if (stateTimer >= stateTimerMax)
			{
				if (aggroBreakersInARow < 1 && Random.Range(0, 2) == 0)
				{
					aggroBreakersInARow++;
					int idleBreaker = Random.Range(0, 2);
					StateSetIdleBreaker(idleBreaker, _aggro: true);
					return;
				}
				aggroBreakersInARow = 0;
				if (doAttack && Object.op_Implicit((Object)(object)currentTarget))
				{
					StateSet(State.LureStart);
				}
				if (!doAttack)
				{
					StateSet(State.AggroDegrow);
				}
			}
		}
		_ = isFixedUpdate;
	}

	private void StateLureStart()
	{
		//IL_0052: Unknown result type (might be due to invalid IL or missing references)
		//IL_0080: Unknown result type (might be due to invalid IL or missing references)
		if (stateStart && !isFixedUpdate)
		{
			stateStart = false;
			stateTimerMax = 0.8f;
			stateTimer = 0f;
			GameDirector.instance.CameraShake.ShakeDistance(1f, 3f, 8f, ((Component)this).transform.position, 0.5f);
			GameDirector.instance.CameraImpact.ShakeDistance(2f, 3f, 8f, ((Component)this).transform.position, 0.5f);
			soundGasTell.Play(mouthTransform);
			doAttack = false;
		}
		if (!isFixedUpdate)
		{
			VisualStateLureStart();
			hasTarget = true;
			LookAtTarget();
			if (stateTimer >= stateTimerMax)
			{
				StateSet(State.Lure);
			}
		}
		_ = isFixedUpdate;
	}

	private void StateLure()
	{
		//IL_006b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0099: Unknown result type (might be due to invalid IL or missing references)
		if (stateStart && !isFixedUpdate)
		{
			attacksInARow++;
			stateStart = false;
			stateTimerMax = 5f;
			stateTimer = 0f;
			lureTimerMax = 0f;
			GameDirector.instance.CameraShake.ShakeDistance(2f, 3f, 8f, ((Component)this).transform.position, 0.5f);
			GameDirector.instance.CameraImpact.ShakeDistance(4f, 3f, 8f, ((Component)this).transform.position, 0.5f);
			soundGasStart.Play(mouthTransform);
		}
		if (!isFixedUpdate)
		{
			lureTimerMax += Time.deltaTime;
			VisualStateLure();
			hasTarget = true;
			LookAtTarget();
			ShootGas();
			if (stateTimer >= stateTimerMax)
			{
				if (playersInGas.Count <= 0)
				{
					StateSet(State.LureStop);
					return;
				}
				stateTimer = 0f;
			}
			if (lureTimerMax > 25f)
			{
				StateSet(State.LureStop);
				return;
			}
		}
		_ = isFixedUpdate;
	}

	private void StateLureStop()
	{
		//IL_0052: Unknown result type (might be due to invalid IL or missing references)
		//IL_0080: Unknown result type (might be due to invalid IL or missing references)
		if (stateStart && !isFixedUpdate)
		{
			stateStart = false;
			stateTimerMax = 0.5f;
			stateTimer = 0f;
			GameDirector.instance.CameraShake.ShakeDistance(1f, 3f, 8f, ((Component)this).transform.position, 0.5f);
			GameDirector.instance.CameraImpact.ShakeDistance(2f, 3f, 8f, ((Component)this).transform.position, 0.5f);
			soundGasStop.Play(mouthTransform);
		}
		if (!isFixedUpdate)
		{
			VisualStateLureStop();
			LookAtTarget();
			if (stateTimer >= stateTimerMax)
			{
				if (attacksInARow > 3 || Random.Range(0, 2) == 0)
				{
					LeaveStart();
				}
				else
				{
					StateSet(State.AggroDegrow);
				}
			}
		}
		_ = isFixedUpdate;
	}

	private void StateChompGasp()
	{
		//IL_0052: Unknown result type (might be due to invalid IL or missing references)
		//IL_0080: Unknown result type (might be due to invalid IL or missing references)
		if (stateStart && !isFixedUpdate)
		{
			stateStart = false;
			stateTimerMax = 1f;
			stateTimer = 0f;
			GameDirector.instance.CameraShake.ShakeDistance(2f, 3f, 8f, ((Component)this).transform.position, 3f);
			GameDirector.instance.CameraImpact.ShakeDistance(4f, 3f, 8f, ((Component)this).transform.position, 0.5f);
			soundScare.Play(mouthTransform);
			soundScareGlobal.Play(mouthTransform);
			bites = Random.Range(3, 6);
			JumpScareAtChompStart();
		}
		if (!isFixedUpdate)
		{
			JumpScareAtChompStartForceLookAtHead();
			VisualStateChompGasp();
			LookAtTarget();
			ShootGas();
			OverrideActivateHorrorMeshes();
			if (stateTimer >= stateTimerMax)
			{
				StateSet(State.Chomp);
			}
		}
		_ = isFixedUpdate;
	}

	private void StateChomp()
	{
		//IL_00bf: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ff: Unknown result type (might be due to invalid IL or missing references)
		//IL_01af: Unknown result type (might be due to invalid IL or missing references)
		if (stateStart && !isFixedUpdate)
		{
			stateStart = false;
			stateTimerMax = 0.5f;
			stateTimer = 0f;
			soundChompThrust.Play(mouthTransform);
		}
		if (!isFixedUpdate)
		{
			VisualStateChomp();
			ShootGas();
			LookAtTarget();
			float num = biteCurve.Evaluate(stateTimer / stateTimerMax);
			headSegment1TargetTransform.localRotation = Quaternion.Euler(Mathf.Lerp(0f, 10f, num), Mathf.Lerp(0f, -60f, num), Mathf.Lerp(0f, 10f, num));
			headSegment2TargetTransform.localRotation = Quaternion.Euler(Mathf.Lerp(0f, 10f, num), Mathf.Lerp(0f, 60f, num), Mathf.Lerp(0f, -10f, num));
			if (stateTimer > stateTimerMax * 0.3f && stateTimer < stateTimerMax * 0.7f)
			{
				if (!biteMesh.activeSelf)
				{
					ActivateBiteMesh(_active: true);
					soundChompBite.Play(mouthTransform);
				}
				float num2 = biteScaleBounceCurve.Evaluate((stateTimer - stateTimerMax * 0.3f) / (stateTimerMax * 0.7f));
				biteMesh.transform.localScale = new Vector3(num2, 1f, num2);
			}
			else if (biteMesh.activeSelf)
			{
				ActivateBiteMesh(_active: false);
			}
			VisualBiteAnimation();
			if (stateTimer >= stateTimerMax)
			{
				if (bites <= 0)
				{
					playersInGas.Clear();
					if (attacksInARow > 3 || Random.Range(0, 3) == 0)
					{
						LeaveStart();
					}
					else
					{
						StateSet(State.Aggro);
					}
				}
				else
				{
					stateTimer = 0f;
					stateStart = true;
					bites--;
				}
			}
		}
		_ = isFixedUpdate;
	}

	private void StateDegrow()
	{
		//IL_0039: Unknown result type (might be due to invalid IL or missing references)
		if (stateStart && !isFixedUpdate)
		{
			stateStart = false;
			stateTimerMax = 3f;
			stateTimer = 0f;
			soundDegrow.Play(((Component)this).transform.position);
			DegrowStart();
			ResetLocalGameTime();
		}
		if (!isFixedUpdate)
		{
			enemy.StateStunned.OverrideDisable(0.5f);
			VisualDegrowAnimation();
			VisualGrowDance();
			if (growDone)
			{
				if (doDespawn)
				{
					enemy.EnemyParent.Despawn();
					doDespawn = false;
				}
				else
				{
					StateSet(State.Grow);
				}
			}
		}
		_ = isFixedUpdate;
	}

	private void StateStunned()
	{
		//IL_0059: Unknown result type (might be due to invalid IL or missing references)
		//IL_005e: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ae: Unknown result type (might be due to invalid IL or missing references)
		//IL_008c: Unknown result type (might be due to invalid IL or missing references)
		if (stateStart && !isFixedUpdate)
		{
			stateStart = false;
			stateTimerMax = 0f;
			stateTimer = 0f;
			playersInGas.Clear();
		}
		if (!isFixedUpdate)
		{
			VisualStateStunned();
			if (!enemy.IsStunned())
			{
				RaycastHit val = default;
				if (Physics.Raycast(headCenterTransform.position, Vector3.down, ref val, 100f, LayerMask.GetMask(new string[1] { "Default" })))
				{
					((Component)this).transform.position = val.point;
				}
				else
				{
					((Component)this).transform.position = ((Component)enemy.Rigidbody).transform.position;
				}
				StateSet(State.Idle);
			}
		}
		_ = isFixedUpdate;
	}

	private void StateAggroGrow()
	{
		//IL_0045: Unknown result type (might be due to invalid IL or missing references)
		if (stateStart && !isFixedUpdate)
		{
			stateStart = false;
			stateTimerMax = 1f;
			stateTimer = 0f;
			GrowStart();
			LevelPointsRoamAggro();
			soundGrow.Play(((Component)this).transform.position).pitch = 2f;
			doAttack = true;
		}
		if (!isFixedUpdate)
		{
			enemy.StateStunned.OverrideDisable(0.5f);
			VisualGrowAnimation(3f);
			VisualGrowDance();
			if (growDone)
			{
				StateSet(State.Aggro);
			}
		}
		_ = isFixedUpdate;
	}

	private void StateAggroDegrow()
	{
		//IL_0039: Unknown result type (might be due to invalid IL or missing references)
		if (stateStart && !isFixedUpdate)
		{
			stateStart = false;
			stateTimerMax = 1f;
			stateTimer = 0f;
			soundDegrow.Play(((Component)this).transform.position).pitch = 2f;
			DegrowStart();
			doAttack = true;
			ResetLocalGameTime();
		}
		if (!isFixedUpdate)
		{
			enemy.StateStunned.OverrideDisable(0.5f);
			VisualDegrowAnimation(5f);
			VisualGrowDance();
			if (growDone)
			{
				StateSet(State.AggroGrow);
			}
		}
		_ = isFixedUpdate;
	}

	private void StateIdleBreaker()
	{
		if (stateStart && !isFixedUpdate)
		{
			stateStart = false;
			stateTimerMax = 0f;
			stateTimer = 0f;
			doAttack = true;
			if (idleBreakerIndex == 0)
			{
				AudioSource val = soundIdleBreaker01.Play(mouthTransform);
				stateTimerMax = val.clip.length;
				audioSources.Add(val);
			}
			if (idleBreakerIndex == 1)
			{
				AudioSource val2 = soundIdleBreaker02.Play(mouthTransform);
				stateTimerMax = val2.clip.length;
				audioSources.Add(val2);
			}
			if (idleBreakerIndex == 2)
			{
				AudioSource val3 = soundIdleBreaker03.Play(mouthTransform);
				stateTimerMax = val3.clip.length;
				audioSources.Add(val3);
			}
		}
		if (!isFixedUpdate)
		{
			VisualStateIdleBreaker();
			if (stateTimer >= stateTimerMax)
			{
				StateSet(State.Idle);
			}
		}
		_ = isFixedUpdate;
	}

	private void StateAggroBreaker()
	{
		if (stateStart && !isFixedUpdate)
		{
			stateStart = false;
			stateTimerMax = 0f;
			stateTimer = 0f;
			if (idleBreakerIndex == 0)
			{
				AudioSource val = soundAggroBreaker01.Play(mouthTransform);
				stateTimerMax = val.clip.length;
			}
			if (idleBreakerIndex == 1)
			{
				AudioSource val2 = soundAggroBreaker02.Play(mouthTransform);
				stateTimerMax = val2.clip.length;
			}
			if (idleBreakerIndex == 2)
			{
				AudioSource val3 = soundAggroBreaker03.Play(mouthTransform);
				stateTimerMax = val3.clip.length;
			}
		}
		if (!isFixedUpdate)
		{
			VisualStateAggroBreaker();
			if (stateTimer >= stateTimerMax)
			{
				StateSet(State.Aggro);
			}
		}
		_ = isFixedUpdate;
	}

	private void StateAggroStart()
	{
		if (stateStart && !isFixedUpdate)
		{
			stateStart = false;
			stateTimerMax = 1f;
			stateTimer = 0f;
			soundAggroStart.Play(mouthTransform);
			aggroBreakersInARow = 2;
			doAttack = true;
		}
		if (!isFixedUpdate)
		{
			VisualStateAggroBreaker();
			LookAtTarget();
			if (stateTimer >= stateTimerMax)
			{
				StateSet(State.Aggro);
			}
		}
		_ = isFixedUpdate;
	}

	private void VisualStateNormal()
	{
		VisualAnimateBaseMeshScale(15f, 0.4f, 30f, -0.15f, 20f, 0.1f, 35f, 0.15f);
		VisualSineDanceTargets();
	}

	private void VisualStateNormalToEnchanting()
	{
		overrideVisualsToEnchantedTransitioning = VisualPopAwayMeshes();
	}

	private void VisualStateEnchanting()
	{
		//IL_007b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0086: Unknown result type (might be due to invalid IL or missing references)
		//IL_0092: Unknown result type (might be due to invalid IL or missing references)
		//IL_00dc: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e7: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f4: Unknown result type (might be due to invalid IL or missing references)
		hugVOTimer += Time.deltaTime;
		float num = 0.2f;
		float num2 = 0.6f;
		float num3 = 1.2f;
		if (hugVOTimer < num)
		{
			SetMouthState(closed: true);
		}
		else if (hugVOTimer >= num && hugVOTimer < num2)
		{
			SetMouthState(closed: false);
			Vector3 localScale = new Vector3(1f, 1f + Mathf.Sin(localGameTime * 65f) * 0.3f, 1f);
			cuteMeshRightOpenMouth.localScale = localScale;
			cuteMeshLeftOpenMouth.localScale = localScale;
		}
		else if (hugVOTimer >= num2 && hugVOTimer < num3)
		{
			SetMouthState(closed: true);
			Vector3 localScale2 = new Vector3(1f, 1f - Mathf.Sin(localGameTime * 35f) * 0.15f, 1f);
			cuteMeshRightClosedMouth.localScale = localScale2;
			cuteMeshLeftClosedMouth.localScale = localScale2;
		}
		if (hugVOTimer >= num3)
		{
			hugVOTimer = 0f;
		}
		VisualSineDanceTargets();
		void SetMouthState(bool closed)
		{
			//IL_00b4: Unknown result type (might be due to invalid IL or missing references)
			bool activeSelf = ((Component)cuteMeshRightClosedMouth).gameObject.activeSelf;
			if (closed && !activeSelf)
			{
				((Component)cuteMeshRightClosedMouth).gameObject.SetActive(true);
				((Component)cuteMeshLeftClosedMouth).gameObject.SetActive(true);
				((Component)cuteMeshRightOpenMouth).gameObject.SetActive(false);
				((Component)cuteMeshLeftOpenMouth).gameObject.SetActive(false);
			}
			else if (!closed & activeSelf)
			{
				((Component)cuteMeshRightClosedMouth).gameObject.SetActive(false);
				((Component)cuteMeshLeftClosedMouth).gameObject.SetActive(false);
				((Component)cuteMeshRightOpenMouth).gameObject.SetActive(true);
				((Component)cuteMeshLeftOpenMouth).gameObject.SetActive(true);
				soundEnchantedVO.Play(cuteMeshRightOpenMouth.position);
			}
		}
	}

	private void VisualStateEnchantingToNormal()
	{
		overrideVisualsToEnchantedTransitioning = VisualPopBackMeshes();
	}

	private void VisualStateChompGasp()
	{
		OverrideActivateHorrorMeshes();
		OverrideSpringValues(50f, 0.3f);
		VisualCatchDance();
	}

	private void VisualStateChomp()
	{
		OverrideActivateHorrorMeshes();
		OverrideSpringValues(50f, 0.3f);
	}

	private void VisualStateLureStart()
	{
		//IL_0036: Unknown result type (might be due to invalid IL or missing references)
		//IL_0059: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a0: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a5: Unknown result type (might be due to invalid IL or missing references)
		//IL_00da: Unknown result type (might be due to invalid IL or missing references)
		//IL_0100: Unknown result type (might be due to invalid IL or missing references)
		//IL_0105: Unknown result type (might be due to invalid IL or missing references)
		//IL_0128: Unknown result type (might be due to invalid IL or missing references)
		//IL_0172: Unknown result type (might be due to invalid IL or missing references)
		//IL_0177: Unknown result type (might be due to invalid IL or missing references)
		//IL_019a: Unknown result type (might be due to invalid IL or missing references)
		//IL_01c0: Unknown result type (might be due to invalid IL or missing references)
		//IL_01c5: Unknown result type (might be due to invalid IL or missing references)
		OverrideSpringValues(30f, 0.5f);
		int num = 0;
		foreach (SpringLimb springLimb in springLimbs)
		{
			num++;
			springLimb.target.localRotation = springLimb.originalQuaternion;
			if (springLimb.name == "body")
			{
				springLimb.target.localRotation = springLimb.originalQuaternion * Quaternion.Euler((float)num * -1.5f + Mathf.Sin(localGameTime * 24f + (float)num) * 5f, 0f, Mathf.Sin(localGameTime * 16f + (float)num) * 5f);
			}
			if (springLimb.name == "arm" || springLimb.name == "arm base")
			{
				springLimb.target.localRotation = springLimb.originalQuaternion * Quaternion.Euler(0f, 0f, Mathf.Sin(localGameTime * 16f) * 80f);
			}
			if (springLimb.name == "leaf")
			{
				springLimb.target.localRotation = springLimb.originalQuaternion * Quaternion.Euler(Mathf.Sin(localGameTime * 30f) * 20f, Mathf.Sin(localGameTime * 30f) * 20f, Mathf.Sin(localGameTime * 30f) * 20f);
			}
			if (springLimb.name == "head")
			{
				springLimb.target.localRotation = springLimb.originalQuaternion * Quaternion.Euler(0f, Mathf.Sin(localGameTime * 42f) * 30f, 0f);
			}
		}
		vineRotationSpeed = 2000f;
	}

	private void VisualStateLure()
	{
		//IL_0032: Unknown result type (might be due to invalid IL or missing references)
		//IL_0059: Unknown result type (might be due to invalid IL or missing references)
		//IL_009a: Unknown result type (might be due to invalid IL or missing references)
		//IL_009f: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d4: Unknown result type (might be due to invalid IL or missing references)
		//IL_00fa: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ff: Unknown result type (might be due to invalid IL or missing references)
		//IL_0122: Unknown result type (might be due to invalid IL or missing references)
		//IL_0175: Unknown result type (might be due to invalid IL or missing references)
		//IL_017a: Unknown result type (might be due to invalid IL or missing references)
		//IL_019d: Unknown result type (might be due to invalid IL or missing references)
		//IL_01c3: Unknown result type (might be due to invalid IL or missing references)
		//IL_01c8: Unknown result type (might be due to invalid IL or missing references)
		//IL_01eb: Unknown result type (might be due to invalid IL or missing references)
		//IL_01ff: Unknown result type (might be due to invalid IL or missing references)
		//IL_0204: Unknown result type (might be due to invalid IL or missing references)
		OverrideSpringValues(15f, 0.5f);
		int num = 0;
		foreach (SpringLimb springLimb in springLimbs)
		{
			springLimb.target.localRotation = springLimb.originalQuaternion;
			num++;
			if (springLimb.name == "body")
			{
				springLimb.target.localRotation = springLimb.originalQuaternion * Quaternion.Euler((float)num + Mathf.Sin(localGameTime * 24f + (float)num) * 5f, 0f, Mathf.Sin(localGameTime * 16f + (float)num) * 5f);
			}
			if (springLimb.name == "arm" || springLimb.name == "arm base")
			{
				springLimb.target.localRotation = springLimb.originalQuaternion * Quaternion.Euler(0f, 0f, Mathf.Sin(localGameTime * 16f) * 80f);
			}
			if (springLimb.name == "leaf")
			{
				springLimb.target.localRotation = springLimb.originalQuaternion * Quaternion.Euler(Mathf.Sin(localGameTime * 20f) * (float)num * 2f, Mathf.Sin(localGameTime * 20f) * (float)num * 2f, Mathf.Sin(localGameTime * 20f) * (float)num * 2f);
			}
			if (springLimb.name == "head")
			{
				springLimb.target.localRotation = springLimb.originalQuaternion * Quaternion.Euler(0f, Mathf.Sin(localGameTime * 42f) * 100f, 0f);
			}
			if (springLimb.name == "head look")
			{
				springLimb.target.localRotation = springLimb.originalQuaternion * Quaternion.Euler(0f, 0f, 0f);
			}
		}
		vineRotationSpeed = 1000f;
	}

	private void VisualStateLureStop()
	{
	}

	private void VisualStateAggro()
	{
		//IL_0036: Unknown result type (might be due to invalid IL or missing references)
		//IL_0059: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a0: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a5: Unknown result type (might be due to invalid IL or missing references)
		//IL_00da: Unknown result type (might be due to invalid IL or missing references)
		//IL_0100: Unknown result type (might be due to invalid IL or missing references)
		//IL_0105: Unknown result type (might be due to invalid IL or missing references)
		//IL_0128: Unknown result type (might be due to invalid IL or missing references)
		//IL_0172: Unknown result type (might be due to invalid IL or missing references)
		//IL_0177: Unknown result type (might be due to invalid IL or missing references)
		//IL_019a: Unknown result type (might be due to invalid IL or missing references)
		//IL_01c0: Unknown result type (might be due to invalid IL or missing references)
		//IL_01c5: Unknown result type (might be due to invalid IL or missing references)
		OverrideSpringValues(30f, 0.5f);
		int num = 0;
		foreach (SpringLimb springLimb in springLimbs)
		{
			num++;
			springLimb.target.localRotation = springLimb.originalQuaternion;
			if (springLimb.name == "body")
			{
				springLimb.target.localRotation = springLimb.originalQuaternion * Quaternion.Euler((float)num * 0.5f + Mathf.Sin(localGameTime * 2f + (float)num) * 2f, 0f, Mathf.Sin(localGameTime * 5f + (float)num) * 5f);
			}
			if (springLimb.name == "arm" || springLimb.name == "arm base")
			{
				springLimb.target.localRotation = springLimb.originalQuaternion * Quaternion.Euler(0f, 0f, Mathf.Sin(localGameTime * 5f) * 20f);
			}
			if (springLimb.name == "leaf")
			{
				springLimb.target.localRotation = springLimb.originalQuaternion * Quaternion.Euler(Mathf.Sin(localGameTime * 30f) * 20f, Mathf.Sin(localGameTime * 30f) * 20f, Mathf.Sin(localGameTime * 30f) * 20f);
			}
			if (springLimb.name == "head")
			{
				springLimb.target.localRotation = springLimb.originalQuaternion * Quaternion.Euler(0f, Mathf.Sin(localGameTime * 20f) * 10f, 0f);
			}
		}
		vineRotationSpeed = 2000f;
	}

	private void VisualStateStunned()
	{
		//IL_006b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0091: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f0: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f5: Unknown result type (might be due to invalid IL or missing references)
		//IL_011b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0144: Unknown result type (might be due to invalid IL or missing references)
		//IL_0149: Unknown result type (might be due to invalid IL or missing references)
		//IL_016f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0198: Unknown result type (might be due to invalid IL or missing references)
		//IL_019d: Unknown result type (might be due to invalid IL or missing references)
		//IL_01c7: Unknown result type (might be due to invalid IL or missing references)
		//IL_0211: Unknown result type (might be due to invalid IL or missing references)
		//IL_0216: Unknown result type (might be due to invalid IL or missing references)
		//IL_023c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0250: Unknown result type (might be due to invalid IL or missing references)
		//IL_0255: Unknown result type (might be due to invalid IL or missing references)
		//IL_027b: Unknown result type (might be due to invalid IL or missing references)
		//IL_02ad: Unknown result type (might be due to invalid IL or missing references)
		//IL_02b2: Unknown result type (might be due to invalid IL or missing references)
		VisualAnimateBaseMeshScale(30f, 0.5f, 30f, -0.2f, 20f, 0.1f, 35f, 0.2f);
		OverrideSpringValues(40f, 0.5f);
		int num = 0;
		int num2 = -1;
		int num3 = -1;
		foreach (SpringLimb springLimb in springLimbs)
		{
			num++;
			springLimb.target.localRotation = springLimb.originalQuaternion;
			if (springLimb.name == "body")
			{
				springLimb.target.localRotation = springLimb.originalQuaternion * Quaternion.Euler(0.5f + Mathf.Sin(localGameTime * 20f + (float)num) * 2f - (float)num * 0.5f, Mathf.Sin(localGameTime * 20f) * 5f, Mathf.Sin(localGameTime * 5f + (float)num) * 2f);
			}
			if (springLimb.name == "arm")
			{
				springLimb.target.localRotation = springLimb.originalQuaternion * Quaternion.Euler(0f, Mathf.Sin(localGameTime * 8f) * 40f * (float)num3, -40f);
			}
			if (springLimb.name == "arm base")
			{
				springLimb.target.localRotation = springLimb.originalQuaternion * Quaternion.Euler(0f, -80f * (float)num3, Mathf.Sin(localGameTime * 5f) * 20f);
				num3 *= -1;
			}
			if (springLimb.name == "leaf")
			{
				springLimb.target.localRotation = springLimb.originalQuaternion * Quaternion.Euler(Mathf.Sin(localGameTime * 30f) * 20f, Mathf.Sin(localGameTime * 30f) * 20f, Mathf.Sin(localGameTime * 30f) * 20f);
			}
			if (springLimb.name == "head look")
			{
				springLimb.target.localRotation = springLimb.originalQuaternion * Quaternion.Euler(-40f, 0f, 0f);
			}
			if (springLimb.name == "head")
			{
				springLimb.target.localRotation = springLimb.originalQuaternion * Quaternion.Euler(10f, (70f - Mathf.Sin(localGameTime * 25f) * 2f) * (float)num2, 10f * (float)num2);
				num2 *= -1;
			}
		}
		vineRotationSpeed = 1000f;
	}

	private void VisualStateIdleBreaker()
	{
		//IL_008b: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b9: Unknown result type (might be due to invalid IL or missing references)
		//IL_00fc: Unknown result type (might be due to invalid IL or missing references)
		//IL_0101: Unknown result type (might be due to invalid IL or missing references)
		//IL_013a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0168: Unknown result type (might be due to invalid IL or missing references)
		//IL_016d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0193: Unknown result type (might be due to invalid IL or missing references)
		//IL_01a9: Unknown result type (might be due to invalid IL or missing references)
		//IL_01ae: Unknown result type (might be due to invalid IL or missing references)
		//IL_01d4: Unknown result type (might be due to invalid IL or missing references)
		//IL_021e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0223: Unknown result type (might be due to invalid IL or missing references)
		//IL_025c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0276: Unknown result type (might be due to invalid IL or missing references)
		//IL_027b: Unknown result type (might be due to invalid IL or missing references)
		float num = idleBreakerCurve.Evaluate(stateTimer / stateTimerMax);
		if (num < 0f)
		{
			num = 0f;
		}
		OverrideSpringValues(20f + 20f * num, 0.5f - 0.05f * num);
		num = idleBreakerCurve.Evaluate(stateTimer / stateTimerMax);
		int num2 = 0;
		int num3 = -1;
		foreach (SpringLimb springLimb in springLimbs)
		{
			num2++;
			springLimb.target.localRotation = springLimb.originalQuaternion;
			float num4 = (float)(num2 / 5) * num;
			if (springLimb.name == "body")
			{
				springLimb.target.localRotation = springLimb.originalQuaternion * Quaternion.Euler((0f - num4) * 20f, Mathf.Sin(localGameTime * 16f) * 5f * num, Mathf.Sin(localGameTime * 16f + (float)num2) * 2f * num);
			}
			if (springLimb.name == "arm" || springLimb.name == "arm base")
			{
				springLimb.target.localRotation = springLimb.originalQuaternion * Quaternion.Euler(0f, 0f, Mathf.Sin(localGameTime * 16f) * 20f - 20f * num);
			}
			if (springLimb.name == "head look")
			{
				springLimb.target.localRotation = springLimb.originalQuaternion * Quaternion.Euler(20f * num, 0f, 0f);
			}
			if (springLimb.name == "leaf")
			{
				springLimb.target.localRotation = springLimb.originalQuaternion * Quaternion.Euler(Mathf.Sin(localGameTime * 30f) * 20f, Mathf.Sin(localGameTime * 30f) * 20f, Mathf.Sin(localGameTime * 30f) * 20f);
			}
			if (springLimb.name == "head")
			{
				float num5 = num;
				if (num5 < 0f)
				{
					num5 = 0f;
				}
				springLimb.target.localRotation = springLimb.originalQuaternion * Quaternion.Euler(0f, num5 * (40f * (float)num3), 0f);
				num3 += 2;
			}
			vineRotationSpeed = 200f + 800f * num;
		}
	}

	private void VisualStateAggroBreaker()
	{
		//IL_00c0: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ee: Unknown result type (might be due to invalid IL or missing references)
		//IL_0130: Unknown result type (might be due to invalid IL or missing references)
		//IL_0135: Unknown result type (might be due to invalid IL or missing references)
		//IL_016e: Unknown result type (might be due to invalid IL or missing references)
		//IL_019c: Unknown result type (might be due to invalid IL or missing references)
		//IL_01a1: Unknown result type (might be due to invalid IL or missing references)
		//IL_01c7: Unknown result type (might be due to invalid IL or missing references)
		//IL_01dd: Unknown result type (might be due to invalid IL or missing references)
		//IL_01e2: Unknown result type (might be due to invalid IL or missing references)
		//IL_0208: Unknown result type (might be due to invalid IL or missing references)
		//IL_0252: Unknown result type (might be due to invalid IL or missing references)
		//IL_0257: Unknown result type (might be due to invalid IL or missing references)
		//IL_0290: Unknown result type (might be due to invalid IL or missing references)
		//IL_02aa: Unknown result type (might be due to invalid IL or missing references)
		//IL_02af: Unknown result type (might be due to invalid IL or missing references)
		if (stateTimer > stateTimerMax * 0.3f && stateTimer < stateTimerMax - stateTimerMax * 0.3f)
		{
			OverrideActivateHorrorMeshes();
		}
		float num = idleBreakerCurve.Evaluate(stateTimer / stateTimerMax);
		if (num < 0f)
		{
			num = 0f;
		}
		OverrideSpringValues(20f + 20f * num, 0.5f - 0.05f * num);
		num = idleBreakerCurve.Evaluate(stateTimer / stateTimerMax);
		int num2 = 0;
		int num3 = -1;
		foreach (SpringLimb springLimb in springLimbs)
		{
			num2++;
			springLimb.target.localRotation = springLimb.originalQuaternion;
			float num4 = (float)(num2 / 5) * num;
			if (springLimb.name == "body")
			{
				springLimb.target.localRotation = springLimb.originalQuaternion * Quaternion.Euler(num4 * 20f, Mathf.Sin(localGameTime * 16f) * 5f * num, Mathf.Sin(localGameTime * 16f + (float)num2) * 2f * num);
			}
			if (springLimb.name == "arm" || springLimb.name == "arm base")
			{
				springLimb.target.localRotation = springLimb.originalQuaternion * Quaternion.Euler(0f, 0f, Mathf.Sin(localGameTime * 16f) * 20f - 20f * num);
			}
			if (springLimb.name == "head look")
			{
				springLimb.target.localRotation = springLimb.originalQuaternion * Quaternion.Euler(-20f * num, 0f, 0f);
			}
			if (springLimb.name == "leaf")
			{
				springLimb.target.localRotation = springLimb.originalQuaternion * Quaternion.Euler(Mathf.Sin(localGameTime * 30f) * 20f, Mathf.Sin(localGameTime * 30f) * 20f, Mathf.Sin(localGameTime * 30f) * 20f);
			}
			if (springLimb.name == "head")
			{
				float num5 = num;
				if (num5 < 0f)
				{
					num5 = 0f;
				}
				springLimb.target.localRotation = springLimb.originalQuaternion * Quaternion.Euler(0f, num5 * (40f * (float)num3), 0f);
				num3 += 2;
			}
			vineRotationSpeed = 200f + 800f * num;
		}
	}

	private void VisualSineDanceTargets()
	{
		//IL_0041: Unknown result type (might be due to invalid IL or missing references)
		//IL_007f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0084: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a7: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d0: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d5: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f8: Unknown result type (might be due to invalid IL or missing references)
		//IL_0122: Unknown result type (might be due to invalid IL or missing references)
		//IL_0127: Unknown result type (might be due to invalid IL or missing references)
		//IL_015c: Unknown result type (might be due to invalid IL or missing references)
		//IL_019a: Unknown result type (might be due to invalid IL or missing references)
		//IL_019f: Unknown result type (might be due to invalid IL or missing references)
		//IL_01c2: Unknown result type (might be due to invalid IL or missing references)
		//IL_0200: Unknown result type (might be due to invalid IL or missing references)
		//IL_0205: Unknown result type (might be due to invalid IL or missing references)
		if (!growDone)
		{
			return;
		}
		int num = 0;
		foreach (SpringLimb springLimb in springLimbs)
		{
			num++;
			if (springLimb.name == "body")
			{
				springLimb.target.localRotation = springLimb.originalQuaternion * Quaternion.Euler(Mathf.Sin(localGameTime * 2f + (float)num) * 4f, 0f, Mathf.Sin(localGameTime * 1f + (float)num) * 4f);
			}
			if (springLimb.name == "head")
			{
				springLimb.target.localRotation = springLimb.originalQuaternion * Quaternion.Euler(0f, Mathf.Sin(localGameTime * 2f + (float)num) * 30f, 0f);
			}
			if (springLimb.name == "head look")
			{
				springLimb.target.localRotation = springLimb.originalQuaternion * Quaternion.Euler(0f, 0f, (0f - Mathf.Sin(localGameTime * 1f + (float)num)) * 5f);
			}
			if (springLimb.name == "arm" || springLimb.name == "arm base")
			{
				springLimb.target.localRotation = springLimb.originalQuaternion * Quaternion.Euler(0f, Mathf.Sin(localGameTime * 2f + (float)num) * 30f, Mathf.Sin(localGameTime * 2f + (float)num) * 15f);
			}
			if (springLimb.name == "leaf")
			{
				springLimb.target.localRotation = springLimb.originalQuaternion * Quaternion.Euler(0f, Mathf.Sin(localGameTime * 2f + (float)num) * 10f, Mathf.Sin(localGameTime * 2f + (float)num) * 5f);
			}
			vineRotationSpeed = Mathf.Lerp(vineRotationSpeed, 50f, Time.deltaTime * 0.1f);
		}
	}

	private void VisualGrowDance()
	{
		//IL_0038: Unknown result type (might be due to invalid IL or missing references)
		//IL_0076: Unknown result type (might be due to invalid IL or missing references)
		//IL_007b: Unknown result type (might be due to invalid IL or missing references)
		//IL_009e: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f1: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f6: Unknown result type (might be due to invalid IL or missing references)
		//IL_0119: Unknown result type (might be due to invalid IL or missing references)
		//IL_0142: Unknown result type (might be due to invalid IL or missing references)
		//IL_0147: Unknown result type (might be due to invalid IL or missing references)
		int num = 0;
		foreach (SpringLimb springLimb in springLimbs)
		{
			num++;
			if (springLimb.name == "body")
			{
				springLimb.target.localRotation = springLimb.originalQuaternion * Quaternion.Euler(Mathf.Sin(localGameTime * 24f + (float)num) * 5f, 0f, Mathf.Sin(localGameTime * 16f + (float)num) * 5f);
			}
			if (springLimb.name == "leaf")
			{
				springLimb.target.localRotation = springLimb.originalQuaternion * Quaternion.Euler(Mathf.Sin(localGameTime * 24f + (float)num) * 5f, Mathf.Sin(localGameTime * 16f + (float)num) * 10f, Mathf.Sin(localGameTime * 16f + (float)num) * 5f);
			}
			if (springLimb.name == "head")
			{
				springLimb.target.localRotation = springLimb.originalQuaternion * Quaternion.Euler(0f, Mathf.Sin(localGameTime * 24f + (float)num) * 10f, 0f);
			}
		}
		vineRotationSpeed = 1000f;
	}

	private void VisualCatchDance()
	{
		//IL_0048: Unknown result type (might be due to invalid IL or missing references)
		//IL_008e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0093: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b9: Unknown result type (might be due to invalid IL or missing references)
		//IL_0118: Unknown result type (might be due to invalid IL or missing references)
		//IL_011d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0143: Unknown result type (might be due to invalid IL or missing references)
		//IL_0170: Unknown result type (might be due to invalid IL or missing references)
		//IL_0175: Unknown result type (might be due to invalid IL or missing references)
		int num = 0;
		float num2 = 4f;
		float num3 = 0.5f;
		foreach (SpringLimb springLimb in springLimbs)
		{
			num++;
			if (springLimb.name == "body")
			{
				springLimb.target.localRotation = springLimb.originalQuaternion * Quaternion.Euler(Mathf.Sin(localGameTime * (24f * num2) + (float)num) * (5f * num3), 0f, Mathf.Sin(localGameTime * (16f * num2) + (float)num) * (5f * num3));
			}
			if (springLimb.name == "leaf")
			{
				springLimb.target.localRotation = springLimb.originalQuaternion * Quaternion.Euler(Mathf.Sin(localGameTime * (24f * num2) + (float)num) * (5f * num3), Mathf.Sin(localGameTime * (16f * num2) + (float)num) * (10f * num3), Mathf.Sin(localGameTime * (16f * num2) + (float)num) * (5f * num3));
			}
			if (springLimb.name == "head")
			{
				springLimb.target.localRotation = springLimb.originalQuaternion * Quaternion.Euler(0f, Mathf.Sin(localGameTime * (24f * num2) + (float)num) * (40f * num3), 0f);
			}
		}
		vineRotationSpeed = 1000f;
	}

	private void VisualUpdateSprings()
	{
		//IL_00e1: Unknown result type (might be due to invalid IL or missing references)
		//IL_00eb: Unknown result type (might be due to invalid IL or missing references)
		//IL_0123: Unknown result type (might be due to invalid IL or missing references)
		//IL_012d: Unknown result type (might be due to invalid IL or missing references)
		float num = 15f;
		float num2 = 0.5f;
		if (!growDone)
		{
			num = 25f;
			num2 = 0.5f;
		}
		float num3 = num;
		float num4 = num2;
		if (overrideSpringValuesTimer > 0f)
		{
			num3 = overrideSpringValuesSpeed;
			num4 = overrideSpringValuesDamping;
		}
		foreach (SpringLimb springLimb in springLimbs)
		{
			if (growDone)
			{
				if (springLimb.name == "leaf" && overrideSpringValuesTimer <= 0f)
				{
					num = 5f;
					num2 = 0.25f;
				}
				else
				{
					num = num3;
					num2 = num4;
				}
			}
			springLimb.spring.speed = num;
			springLimb.spring.damping = num2;
			springLimb.spring.maxAngle = 5f;
			springLimb.spring.clamp = false;
			springLimb.transform.rotation = SemiFunc.SpringQuaternionGet(springLimb.spring, springLimb.target.rotation);
		}
		baseMeshScale.localScale = SemiFunc.SpringVector3Get(baseScaleSpring, baseMeshScaleTarget.localScale);
	}

	private void VisualGrowAnimation(float _growSpeed = 1f)
	{
		//IL_007b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0097: Unknown result type (might be due to invalid IL or missing references)
		//IL_009c: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a0: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b1: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c2: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00de: Unknown result type (might be due to invalid IL or missing references)
		GrowSpin();
		SpringLimb springLimb = null;
		bool flag = false;
		foreach (SpringLimb springLimb2 in springLimbs)
		{
			if (!(springLimb2.name == "head look") && (springLimb == null || springLimb.growAmount > 0.2f))
			{
				springLimb2.growAmount += Time.deltaTime * _growSpeed;
				if (springLimb2.growAmount >= 1f)
				{
					springLimb2.growAmount = 1f;
				}
				else
				{
					flag = true;
				}
				Vector3 val = Vector3.one * (1f * growAnimationCurve.Evaluate(springLimb2.growAmount));
				val = new Vector3(Mathf.Max(val.x, 0.01f), Mathf.Max(val.y, 0.01f), Mathf.Max(val.z, 0.01f));
				springLimb2.transform.localScale = val;
				springLimb = springLimb2;
			}
		}
		if (!flag)
		{
			growDone = true;
		}
	}

	private void VisualDegrowAnimation(float _growSpeed = 1f)
	{
		//IL_0099: Unknown result type (might be due to invalid IL or missing references)
		//IL_00bb: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c0: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c2: Unknown result type (might be due to invalid IL or missing references)
		//IL_00dc: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f6: Unknown result type (might be due to invalid IL or missing references)
		//IL_0116: Unknown result type (might be due to invalid IL or missing references)
		GrowSpin();
		SpringLimb springLimb = null;
		bool flag = false;
		for (int num = springLimbs.Count - 1; num >= 0; num--)
		{
			SpringLimb springLimb2 = springLimbs[num];
			if (!(springLimb2.name == "head look") && (springLimb == null || springLimb.growAmount > 0.2f))
			{
				springLimb2.growAmount += Time.deltaTime * _growSpeed;
				if (springLimb2.growAmount >= 1f)
				{
					springLimb2.growAmount = 1f;
					((Component)springLimb2.transform).gameObject.SetActive(false);
				}
				else
				{
					flag = true;
				}
				if (flag)
				{
					Vector3 val = Vector3.one * (1f - 1f * growAnimationCurve.Evaluate(springLimb2.growAmount));
					if (val.x < 0.01f)
					{
						val.x = 0.01f;
					}
					if (val.y < 0.01f)
					{
						val.y = 0.01f;
					}
					if (val.z < 0.01f)
					{
						val.z = 0.01f;
					}
					springLimb2.transform.localScale = val;
				}
				springLimb = springLimb2;
			}
		}
		if (!flag)
		{
			growDone = true;
		}
	}

	private void VisualRotateVines()
	{
		//IL_00b1: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ea: Unknown result type (might be due to invalid IL or missing references)
		vineRotation += vineRotationSpeed * Time.deltaTime;
		baseRotation += vineRotationSpeed * 0.5f * Time.deltaTime;
		vineRotation %= 360f;
		baseRotation %= 360f;
		if (float.IsNaN(vineRotation))
		{
			vineRotation = 0f;
		}
		if (float.IsNaN(baseRotation))
		{
			baseRotation = 0f;
		}
		foreach (Transform vineTransform in vineTransforms)
		{
			vineTransform.localRotation = Quaternion.Euler(0f, vineRotation, 0f);
		}
		baseMeshScale.localRotation = Quaternion.Euler(0f, baseRotation, 0f);
	}

	private void VisualPopAwayMeshesStart()
	{
		//IL_0038: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a3: Unknown result type (might be due to invalid IL or missing references)
		meshTransforms.Shuffle();
		foreach (MeshTransform meshTransform in meshTransforms)
		{
			meshTransform.eval = 0f;
			meshTransform.soundPlayed = false;
			meshTransform.transform.localScale = Vector3.one;
			((Component)meshTransform.transform).gameObject.SetActive(true);
		}
		cuteMeshTransforms.Shuffle();
		foreach (CuteMeshTransform cuteMeshTransform in cuteMeshTransforms)
		{
			cuteMeshTransform.eval = 0f;
			cuteMeshTransform.soundPlayed = false;
			cuteMeshTransform.transform.localScale = Vector3.zero;
			((Component)cuteMeshTransform.transform).gameObject.SetActive(true);
		}
	}

	private bool VisualPopAwayMeshes()
	{
		//IL_00d1: Unknown result type (might be due to invalid IL or missing references)
		//IL_0077: Unknown result type (might be due to invalid IL or missing references)
		//IL_0171: Unknown result type (might be due to invalid IL or missing references)
		//IL_0176: Unknown result type (might be due to invalid IL or missing references)
		//IL_017c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0181: Unknown result type (might be due to invalid IL or missing references)
		//IL_019f: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e6: Unknown result type (might be due to invalid IL or missing references)
		//IL_00fd: Unknown result type (might be due to invalid IL or missing references)
		//IL_021d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0269: Unknown result type (might be due to invalid IL or missing references)
		//IL_0280: Unknown result type (might be due to invalid IL or missing references)
		//IL_02e5: Unknown result type (might be due to invalid IL or missing references)
		//IL_032e: Unknown result type (might be due to invalid IL or missing references)
		float num = 1f;
		bool flag = false;
		MeshTransform meshTransform = null;
		foreach (MeshTransform meshTransform2 in meshTransforms)
		{
			if (meshTransform == null || meshTransform.eval > 0.3f)
			{
				meshTransform2.eval += Time.deltaTime * 10f * num;
				if (meshTransform2.eval > 0.2f && !meshTransform2.soundPlayed)
				{
					popAwaySound.Play(meshTransform2.transform.position);
					meshTransform2.soundPlayed = true;
				}
				if (meshTransform2.eval >= 1f)
				{
					meshTransform2.eval = 1f;
					((Component)meshTransform2.transform).gameObject.SetActive(false);
					meshTransform2.transform.localScale = Vector3.one;
				}
				else
				{
					flag = true;
				}
				meshTransform2.transform.localScale = Vector3.one * popAwayMeshesCurve.Evaluate(meshTransform2.eval);
				meshTransform = meshTransform2;
			}
		}
		if (Object.op_Implicit((Object)(object)headLight))
		{
			headLight.intensity = Mathf.Lerp(headLight.intensity, 2f, Time.deltaTime * 2f);
		}
		if (Object.op_Implicit((Object)(object)headParticles))
		{
			EmissionModule emission = headParticles.emission;
			MinMaxCurve rateOverTime = emission.rateOverTime;
			emission.rateOverTime = MinMaxCurve.op_Implicit(Mathf.Lerp(rateOverTime.constant, 20f, Time.deltaTime * 2f));
		}
		bool flag2 = false;
		CuteMeshTransform cuteMeshTransform = null;
		foreach (CuteMeshTransform cuteMeshTransform2 in cuteMeshTransforms)
		{
			if (cuteMeshTransform == null || cuteMeshTransform.eval > 0.3f)
			{
				cuteMeshTransform2.eval += Time.deltaTime * 10f * num;
				if (cuteMeshTransform2.eval > 0.2f && !cuteMeshTransform2.soundPlayed)
				{
					popAwaySound.Play(cuteMeshTransform2.transform.position);
					cuteMeshTransform2.soundPlayed = true;
				}
				if (cuteMeshTransform2.eval >= 1f)
				{
					cuteMeshTransform2.eval = 1f;
				}
				else
				{
					flag2 = true;
				}
				cuteMeshTransform2.transform.localScale = Vector3.one * popBackMeshesCurve.Evaluate(cuteMeshTransform2.eval);
				cuteMeshTransform = cuteMeshTransform2;
			}
		}
		VisualGrowDance();
		if (!flag && !flag2)
		{
			foreach (CuteMeshTransform cuteMeshTransform3 in cuteMeshTransforms)
			{
				cuteMeshTransform3.eval = 0f;
				cuteMeshTransform3.transform.localScale = Vector3.one;
			}
			foreach (MeshTransform meshTransform3 in meshTransforms)
			{
				meshTransform3.eval = 0f;
				meshTransform3.transform.localScale = Vector3.one;
			}
		}
		return flag | flag2;
	}

	private bool VisualPopBackMeshes()
	{
		//IL_00bb: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d2: Unknown result type (might be due to invalid IL or missing references)
		//IL_019a: Unknown result type (might be due to invalid IL or missing references)
		//IL_019f: Unknown result type (might be due to invalid IL or missing references)
		//IL_01a5: Unknown result type (might be due to invalid IL or missing references)
		//IL_01aa: Unknown result type (might be due to invalid IL or missing references)
		//IL_01c8: Unknown result type (might be due to invalid IL or missing references)
		//IL_0112: Unknown result type (might be due to invalid IL or missing references)
		//IL_008d: Unknown result type (might be due to invalid IL or missing references)
		//IL_01dc: Unknown result type (might be due to invalid IL or missing references)
		//IL_026f: Unknown result type (might be due to invalid IL or missing references)
		//IL_02bc: Unknown result type (might be due to invalid IL or missing references)
		//IL_02d3: Unknown result type (might be due to invalid IL or missing references)
		bool flag = overrideVisualsToEnchantedInstantTransition;
		float num = 1f;
		bool flag2 = true;
		CuteMeshTransform cuteMeshTransform = null;
		foreach (CuteMeshTransform cuteMeshTransform2 in cuteMeshTransforms)
		{
			if (cuteMeshTransform == null || cuteMeshTransform.eval > 0.3f)
			{
				cuteMeshTransform2.eval += Time.deltaTime * 10f * num;
				if (flag)
				{
					cuteMeshTransform2.eval = 1f;
				}
				if (cuteMeshTransform2.eval > 0.2f && !cuteMeshTransform2.soundPlayed)
				{
					popAwaySound.Play(cuteMeshTransform2.transform.position);
					cuteMeshTransform2.soundPlayed = true;
				}
				cuteMeshTransform2.transform.localScale = Vector3.one * popAwayMeshesCurve.Evaluate(cuteMeshTransform2.eval);
				cuteMeshTransform = cuteMeshTransform2;
				if (cuteMeshTransform2.eval >= 1f)
				{
					cuteMeshTransform2.eval = 1f;
					((Component)cuteMeshTransform2.transform).gameObject.SetActive(false);
					cuteMeshTransform2.transform.localScale = Vector3.one;
				}
				else
				{
					flag2 = false;
				}
			}
		}
		if (Object.op_Implicit((Object)(object)headLight))
		{
			headLight.intensity = Mathf.Lerp(headLight.intensity, 0.2f, Time.deltaTime * 2f);
			if (flag)
			{
				headLight.intensity = 0.2f;
			}
		}
		if (Object.op_Implicit((Object)(object)headParticles))
		{
			EmissionModule emission = headParticles.emission;
			MinMaxCurve rateOverTime = emission.rateOverTime;
			emission.rateOverTime = MinMaxCurve.op_Implicit(Mathf.Lerp(rateOverTime.constant, 5f, Time.deltaTime * 2f));
			if (flag)
			{
				emission.rateOverTime = MinMaxCurve.op_Implicit(5f);
			}
		}
		if (!flag2)
		{
			return true;
		}
		bool result = false;
		MeshTransform meshTransform = null;
		foreach (MeshTransform meshTransform2 in meshTransforms)
		{
			if (meshTransform == null || meshTransform.eval > 0.3f)
			{
				meshTransform2.eval += Time.deltaTime * 10f * num;
				if (flag)
				{
					meshTransform2.eval = 1f;
				}
				if (meshTransform2.eval > 0.2f && !meshTransform2.soundPlayed)
				{
					popAwaySound.Play(meshTransform2.transform.position);
					meshTransform2.soundPlayed = true;
				}
				if (meshTransform2.eval >= 1f)
				{
					meshTransform2.eval = 1f;
				}
				else
				{
					result = true;
				}
				meshTransform2.transform.localScale = Vector3.one * popBackMeshesCurve.Evaluate(meshTransform2.eval);
				meshTransform = meshTransform2;
			}
		}
		return result;
	}

	private void VisualPopBackMeshesStart()
	{
		//IL_0043: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a3: Unknown result type (might be due to invalid IL or missing references)
		meshTransforms.Shuffle();
		cuteMeshTransforms.Shuffle();
		foreach (MeshTransform meshTransform in meshTransforms)
		{
			meshTransform.eval = 0f;
			meshTransform.soundPlayed = false;
			meshTransform.transform.localScale = Vector3.zero;
			((Component)meshTransform.transform).gameObject.SetActive(true);
		}
		foreach (CuteMeshTransform cuteMeshTransform in cuteMeshTransforms)
		{
			cuteMeshTransform.eval = 0f;
			cuteMeshTransform.soundPlayed = false;
			cuteMeshTransform.transform.localScale = Vector3.one;
			((Component)cuteMeshTransform.transform).gameObject.SetActive(true);
		}
	}

	private void VisualBiteAnimation()
	{
		//IL_004a: Unknown result type (might be due to invalid IL or missing references)
		//IL_006c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0071: Unknown result type (might be due to invalid IL or missing references)
		float num = biteCurve.Evaluate(stateTimer / stateTimerMax);
		int num2 = 1;
		foreach (SpringLimb springLimb in springLimbs)
		{
			if (springLimb.name == "body")
			{
				springLimb.target.localRotation = springLimb.originalQuaternion * Quaternion.Euler(Mathf.Lerp(0f, (float)num2 * 1.5f, num), 0f, 0f);
			}
			num2++;
		}
	}

	private void VisualScaleBreathing()
	{
		//IL_016e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0173: Unknown result type (might be due to invalid IL or missing references)
		//IL_01a0: Unknown result type (might be due to invalid IL or missing references)
		//IL_01a5: Unknown result type (might be due to invalid IL or missing references)
		//IL_01b2: Unknown result type (might be due to invalid IL or missing references)
		//IL_01bc: Unknown result type (might be due to invalid IL or missing references)
		//IL_01c1: Unknown result type (might be due to invalid IL or missing references)
		//IL_01ce: Unknown result type (might be due to invalid IL or missing references)
		//IL_01d8: Unknown result type (might be due to invalid IL or missing references)
		//IL_01dd: Unknown result type (might be due to invalid IL or missing references)
		//IL_01e9: Unknown result type (might be due to invalid IL or missing references)
		//IL_01fa: Unknown result type (might be due to invalid IL or missing references)
		//IL_020b: Unknown result type (might be due to invalid IL or missing references)
		//IL_021c: Unknown result type (might be due to invalid IL or missing references)
		scaleBreathing.speed = 60f;
		scaleBreathing.damping = 0.3f;
		holeScaleBreathing.speed = 60f;
		holeScaleBreathing.damping = 0.1f;
		float num = 0f;
		foreach (AudioSource audioSource in audioSources)
		{
			if (Object.op_Implicit((Object)(object)audioSource) && audioSource.isPlaying)
			{
				float[] array = new float[256];
				audioSource.GetSpectrumData(array, 0, (FFTWindow)5);
				num += array[0];
			}
		}
		if (SemiFunc.PerSecond(1f, (Object)(object)this))
		{
			List<AudioSource> list = new List<AudioSource>();
			foreach (AudioSource audioSource2 in audioSources)
			{
				if (!Object.op_Implicit((Object)(object)audioSource2))
				{
					list.Add(audioSource2);
				}
			}
			if (list.Count > 0)
			{
				foreach (AudioSource item in list)
				{
					audioSources.Remove(item);
				}
			}
		}
		num *= 3f;
		if (num > 0.3f)
		{
			num = 0.3f;
		}
		scaleBreathingTarget = new Vector3(1f + num, 1f - num, 1f - num * 2f);
		holeScaleBreathingTarget = new Vector3(1f + num * 2f, 1f + num * 2f, 1f + num * 3f);
		scaleBreathingCurrent = SemiFunc.SpringVector3Get(scaleBreathing, scaleBreathingTarget);
		holeScaleBreathingCurrent = SemiFunc.SpringVector3Get(holeScaleBreathing, holeScaleBreathingTarget);
		breatheScaleParent1.localScale = scaleBreathingCurrent;
		breatheScaleParent2.localScale = scaleBreathingCurrent;
		holeScaleParent1.localScale = holeScaleBreathingCurrent;
		holeScaleParent2.localScale = holeScaleBreathingCurrent;
	}

	private void VisualAnimateBaseMeshScale(float _springSpeed, float _springDamping, float _xSpeed, float _xAmount, float _ySpeed, float _yAmount, float _zSpeed, float _zAmount)
	{
		//IL_0098: Unknown result type (might be due to invalid IL or missing references)
		baseScaleSpring.speed = Mathf.Lerp(baseScaleSpring.speed, _springSpeed, Time.deltaTime * 0.1f);
		baseScaleSpring.damping = Mathf.Lerp(baseScaleSpring.damping, _springDamping, Time.deltaTime * 0.1f);
		baseMeshScaleTarget.localScale = new Vector3(1f + Mathf.Sin(localGameTime * _xSpeed) * _xAmount, 1f + Mathf.Sin(localGameTime * _ySpeed) * _yAmount, 1f + Mathf.Sin(localGameTime * _zSpeed) * _zAmount);
	}

	private void StateMachine()
	{
		switch (currentState)
		{
		case State.Spawn:
			StateSpawn();
			break;
		case State.Idle:
			StateIdle();
			break;
		case State.Roam:
			StateRoam();
			break;
		case State.Grow:
			StateGrow();
			break;
		case State.AggroStart:
			StateAggroStart();
			break;
		case State.Aggro:
			StateAggro();
			break;
		case State.LureStart:
			StateLureStart();
			break;
		case State.Lure:
			StateLure();
			break;
		case State.LureStop:
			StateLureStop();
			break;
		case State.ChompGasp:
			StateChompGasp();
			break;
		case State.Chomp:
			StateChomp();
			break;
		case State.Degrow:
			StateDegrow();
			break;
		case State.Stunned:
			StateStunned();
			break;
		case State.AggroGrow:
			StateAggroGrow();
			break;
		case State.AggroDegrow:
			StateAggroDegrow();
			break;
		case State.IdleBreaker:
			StateIdleBreaker();
			break;
		case State.AggroBreaker:
			StateAggroBreaker();
			break;
		}
	}

	public void StateSet(State newState)
	{
		//IL_0044: Unknown result type (might be due to invalid IL or missing references)
		//IL_004a: Unknown result type (might be due to invalid IL or missing references)
		if (currentState != newState && SemiFunc.IsMasterClientOrSingleplayer())
		{
			NetworkTargetFlush();
			if (SemiFunc.IsMultiplayer())
			{
				photonView.RPC("StateSetRPC", (RpcTarget)0, new object[1] { (int)newState });
			}
			else
			{
				StateSetRPC((int)newState);
			}
		}
	}

	[PunRPC]
	private void StateSetRPC(int _newState, PhotonMessageInfo info = default(PhotonMessageInfo))
	{
		//IL_0000: Unknown result type (might be due to invalid IL or missing references)
		if (SemiFunc.MasterOnlyRPC(info))
		{
			if (currentState != (State)_newState)
			{
				currentState = (State)_newState;
				stateStart = true;
			}
		}
	}

	private void StateSetIdleBreaker(int _idleBreaker, bool _aggro = false)
	{
		//IL_0014: Unknown result type (might be due to invalid IL or missing references)
		//IL_001a: Unknown result type (might be due to invalid IL or missing references)
		if (SemiFunc.IsMasterClientOrSingleplayer())
		{
			if (!SemiFunc.IsMultiplayer())
			{
				StateSetIdleBreakerRPC(_idleBreaker, _aggro);
				return;
			}
			photonView.RPC("StateSetIdleBreakerRPC", (RpcTarget)0, new object[2] { _idleBreaker, _aggro });
		}
	}

	[PunRPC]
	private void StateSetIdleBreakerRPC(int _idleBreaker, bool _aggro, PhotonMessageInfo info = default(PhotonMessageInfo))
	{
		//IL_0000: Unknown result type (might be due to invalid IL or missing references)
		if (SemiFunc.MasterOnlyRPC(info))
		{
			idleBreakerIndex = _idleBreaker;
			if (!_aggro)
			{
				StateSet(State.IdleBreaker);
			}
			else
			{
				StateSet(State.AggroBreaker);
			}
		}
	}

	private void EnemySystemStateTriggers()
	{
		if (SemiFunc.IsMasterClientOrSingleplayer())
		{
			if (enemy.IsStunned())
			{
				StateSet(State.Stunned);
			}
			if (enemy.CurrentState == EnemyState.Despawn && (currentState == State.Idle || currentState == State.Roam))
			{
				DespawnStart();
			}
			if (SemiFunc.EnemyForceLeave(enemy) && (currentState == State.Idle || currentState == State.Roam))
			{
				LeaveStart();
			}
		}
	}

	private void PhysGrabberDisable()
	{
		if (currentState != State.LureStart && currentState != State.Lure && currentState != State.LureStop && currentState != State.ChompGasp && currentState != State.Chomp)
		{
			return;
		}
		foreach (PlayerAvatar item in playersInGasClient)
		{
			if (Object.op_Implicit((Object)(object)item) && item.isLocal)
			{
				item.physGrabber.OverrideDisableSpecialGrabPowers();
				break;
			}
		}
	}

	private void LookAtTarget()
	{
		//IL_002d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0032: Unknown result type (might be due to invalid IL or missing references)
		//IL_003c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0041: Unknown result type (might be due to invalid IL or missing references)
		//IL_0046: Unknown result type (might be due to invalid IL or missing references)
		//IL_004d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0052: Unknown result type (might be due to invalid IL or missing references)
		//IL_0059: Unknown result type (might be due to invalid IL or missing references)
		//IL_0065: Unknown result type (might be due to invalid IL or missing references)
		//IL_006a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0071: Unknown result type (might be due to invalid IL or missing references)
		//IL_0072: Unknown result type (might be due to invalid IL or missing references)
		//IL_007e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0088: Unknown result type (might be due to invalid IL or missing references)
		//IL_008f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0094: Unknown result type (might be due to invalid IL or missing references)
		//IL_0099: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a6: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a7: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ac: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c9: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ce: Unknown result type (might be due to invalid IL or missing references)
		//IL_00db: Unknown result type (might be due to invalid IL or missing references)
		hasTarget = true;
		if (hasTarget && Object.op_Implicit((Object)(object)currentTarget))
		{
			Vector3 val = currentTarget.PlayerVisionTarget.VisionTransform.position + Vector3.down * 0.2f;
			Quaternion localRotation = headLook.localRotation;
			headLook.LookAt(val);
			Quaternion localRotation2 = headLook.localRotation;
			headLook.localRotation = Quaternion.Slerp(localRotation, localRotation2, Time.deltaTime * 10f);
			Vector3 val2 = val - headLook.position;
			val2.y = 0f;
			Quaternion val3 = Quaternion.LookRotation(val2);
			if (!(val2.sqrMagnitude < 0.01f))
			{
				followTarget.rotation = Quaternion.Slerp(followTarget.rotation, val3, Time.deltaTime * 5f);
				lookAtActiveTimer = 1f;
			}
		}
	}

	private void LookAtTargetReset()
	{
		//IL_0019: Unknown result type (might be due to invalid IL or missing references)
		//IL_002d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0032: Unknown result type (might be due to invalid IL or missing references)
		//IL_0042: Unknown result type (might be due to invalid IL or missing references)
		if (lookAtActiveTimer <= 0f)
		{
			headLook.localRotation = Quaternion.Slerp(headLook.localRotation, Quaternion.Euler(new Vector3(-30f, 0f, 0f)), Time.deltaTime * 5f);
		}
		else
		{
			lookAtActiveTimer -= Time.deltaTime;
		}
	}

	private void GrowStart()
	{
		//IL_0040: Unknown result type (might be due to invalid IL or missing references)
		growDone = false;
		foreach (SpringLimb springLimb in springLimbs)
		{
			if (!(springLimb.name == "head look"))
			{
				springLimb.growAmount = 0f;
				springLimb.transform.localScale = Vector3.zero;
				((Component)springLimb.transform).gameObject.SetActive(true);
			}
		}
	}

	private void DegrowStart()
	{
		//IL_0040: Unknown result type (might be due to invalid IL or missing references)
		growDone = false;
		foreach (SpringLimb springLimb in springLimbs)
		{
			if (!(springLimb.name == "head look"))
			{
				springLimb.growAmount = 0f;
				springLimb.transform.localScale = Vector3.one;
			}
		}
	}

	private void ActivateHorrorMeshes(bool _activate)
	{
		if (_activate)
		{
			horrorMesh1.SetActive(true);
			horrorMesh2.SetActive(true);
			normalMesh1.SetActive(false);
			normalMesh2.SetActive(false);
			headLight.intensity = 1f;
			horrorMeshesActive = true;
		}
		else
		{
			horrorMesh1.SetActive(false);
			horrorMesh2.SetActive(false);
			normalMesh1.SetActive(true);
			normalMesh2.SetActive(true);
			headLight.intensity = 0.2f;
			horrorMeshesActive = false;
		}
	}

	private void ActivateBiteMesh(bool _active)
	{
		//IL_0025: Unknown result type (might be due to invalid IL or missing references)
		//IL_0053: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b3: Unknown result type (might be due to invalid IL or missing references)
		//IL_013a: Unknown result type (might be due to invalid IL or missing references)
		if (_active)
		{
			GameDirector.instance.CameraShake.ShakeDistance(2f, 3f, 8f, ((Component)this).transform.position, 0.1f);
			GameDirector.instance.CameraImpact.ShakeDistance(4f, 3f, 8f, ((Component)this).transform.position, 0.1f);
			biteMesh.SetActive(true);
			NudgeSpring("head look", new Vector3(30f, ((double)Random.value > 0.5) ? (-10f) : 10f, ((double)Random.value > 0.5) ? (-10f) : 10f));
			horrorMesh1.SetActive(false);
			horrorMesh2.SetActive(false);
			biteHurtCollider.SetActive(true);
		}
		else
		{
			NudgeAllSprings(new Vector3(((double)Random.value > 0.5) ? (-2f) : 2f, ((double)Random.value > 0.5) ? (-2f) : 2f, ((double)Random.value > 0.5) ? (-2f) : 2f));
			biteMesh.SetActive(false);
			horrorMesh1.SetActive(true);
			horrorMesh2.SetActive(true);
		}
	}

	private void NudgeSpring(string _name, Vector3 _nudgeAmount)
	{
		//IL_002a: Unknown result type (might be due to invalid IL or missing references)
		//IL_002b: Unknown result type (might be due to invalid IL or missing references)
		foreach (SpringLimb springLimb in springLimbs)
		{
			if (springLimb.name == _name)
			{
				springLimb.spring.springVelocity = _nudgeAmount;
			}
		}
	}

	public void NudgeAllSprings(Vector3 _nudgeAmount)
	{
		//IL_001c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0025: Unknown result type (might be due to invalid IL or missing references)
		//IL_002a: Unknown result type (might be due to invalid IL or missing references)
		int num = 1;
		foreach (SpringLimb springLimb in springLimbs)
		{
			springLimb.spring.springVelocity = _nudgeAmount * ((float)num / 4f);
			num++;
		}
	}

	private void ShootGasLogic()
	{
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0064: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ba: Unknown result type (might be due to invalid IL or missing references)
		//IL_00bf: Unknown result type (might be due to invalid IL or missing references)
		//IL_00de: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e4: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e9: Unknown result type (might be due to invalid IL or missing references)
		//IL_00eb: Unknown result type (might be due to invalid IL or missing references)
		//IL_00fb: Unknown result type (might be due to invalid IL or missing references)
		//IL_0100: Unknown result type (might be due to invalid IL or missing references)
		if (shootGasTimer <= 0f && isShootingGas)
		{
			gasParticles.Stop(true);
			playersInGas.Clear();
			isShootingGas = false;
		}
		if (shootGasTimer > 0f)
		{
			if (gasCheckerEmissionTimer > 0.1f)
			{
				EnemyHeartHuggerGasChecker component = Object.Instantiate<GameObject>(gasChecker, mouthTransform.position, Quaternion.identity).GetComponent<EnemyHeartHuggerGasChecker>();
				component.scaleTarget = Random.Range(1.5f, 2f);
				component.lifeTimeMax = Random.Range(1f, 2f);
				((Component)component).transform.localScale = Vector3.zero;
				component.enemyHeartHugger = this;
				Vector3 forward = mouthTransform.forward;
				float num = 10f;
				forward = Quaternion.Euler(Random.Range(0f - num, num), Random.Range(0f - num, num), Random.Range(0f - num, num)) * forward;
				component.velocity = forward * Random.Range(2f, 8f);
				gasCheckerEmissionTimer = 0f;
				((Component)component).gameObject.SetActive(true);
			}
			gasCheckerEmissionTimer += Time.deltaTime;
			isShootingGas = true;
			shootGasTimer -= Time.deltaTime;
		}
	}

	private void ShootGas()
	{
		ParticlePlayGas();
		shootGasTimer = 0.2f;
	}

	private void PlayersInGasLogic()
	{
		//IL_00a3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b3: Unknown result type (might be due to invalid IL or missing references)
		//IL_0224: Unknown result type (might be due to invalid IL or missing references)
		//IL_022a: Unknown result type (might be due to invalid IL or missing references)
		//IL_031d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0323: Unknown result type (might be due to invalid IL or missing references)
		if (!SemiFunc.IsMasterClientOrSingleplayer())
		{
			return;
		}
		if (playersInGas.Count > 0)
		{
			List<PlayersInGas> list = new List<PlayersInGas>();
			foreach (PlayersInGas playersInGa in playersInGas)
			{
				if (!Object.op_Implicit((Object)(object)playersInGa.playerAvatar))
				{
					list.Add(playersInGa);
					continue;
				}
				playersInGa.playerAvatar.OverrideTumbleWings(pink: true, 1f);
				if (playersInGa.inGasTime >= 2f)
				{
					playersInGa.isCaught = true;
				}
				playersInGa.inGasTime += Time.deltaTime;
				if (!Object.op_Implicit((Object)(object)playersInGa.playerAvatar) || playersInGa.outsideGasTime >= 3f || Vector3.Distance(playersInGa.lastPositionInsideGas, ((Component)playersInGa.playerAvatar).transform.position) > 2f)
				{
					list.Add(playersInGa);
				}
				playersInGa.outsideGasTime += Time.deltaTime;
			}
			foreach (PlayersInGas item in list)
			{
				if (Object.op_Implicit((Object)(object)item.playerAvatar))
				{
					playersOnCooldown[item.playerAvatar] = Time.time;
				}
				playersInGas.Remove(item);
			}
		}
		if (!SemiFunc.PerSecond(5f, (Object)(object)this))
		{
			return;
		}
		foreach (PlayersInGas playersInGa2 in playersInGas)
		{
			bool flag = true;
			foreach (PlayersInGas playersInGasPreviou in playersInGasPrevious)
			{
				if ((Object)(object)playersInGa2.playerAvatar == (Object)(object)playersInGasPreviou.playerAvatar)
				{
					flag = false;
					break;
				}
			}
			if (flag)
			{
				if (SemiFunc.IsMultiplayer())
				{
					photonView.RPC("PlayerInGasClientRPC", (RpcTarget)0, new object[2]
					{
						playersInGa2.playerAvatar.photonView.ViewID,
						true
					});
				}
				else
				{
					PlayerInGasClientRPC(playersInGa2.playerAvatar.photonView.ViewID, _add: true);
				}
			}
		}
		foreach (PlayersInGas playersInGasPreviou2 in playersInGasPrevious)
		{
			if (!Object.op_Implicit((Object)(object)playersInGasPreviou2.playerAvatar))
			{
				continue;
			}
			bool flag2 = true;
			foreach (PlayersInGas playersInGa3 in playersInGas)
			{
				if ((Object)(object)playersInGa3.playerAvatar == (Object)(object)playersInGasPreviou2.playerAvatar)
				{
					flag2 = false;
					break;
				}
			}
			if (flag2)
			{
				if (SemiFunc.IsMultiplayer())
				{
					photonView.RPC("PlayerInGasClientRPC", (RpcTarget)0, new object[2]
					{
						playersInGasPreviou2.playerAvatar.photonView.ViewID,
						false
					});
				}
				else
				{
					PlayerInGasClientRPC(playersInGasPreviou2.playerAvatar.photonView.ViewID, _add: false);
				}
			}
		}
		playersInGasPrevious.Clear();
		playersInGasPrevious.AddRange(playersInGas);
	}

	[PunRPC]
	private void PlayerInGasClientRPC(int _photonViewID, bool _add, PhotonMessageInfo _info = default(PhotonMessageInfo))
	{
		//IL_0000: Unknown result type (might be due to invalid IL or missing references)
		if (!SemiFunc.MasterOnlyRPC(_info))
		{
			return;
		}
		foreach (PlayerAvatar item in SemiFunc.PlayerGetList())
		{
			if (item.photonView.ViewID != _photonViewID)
			{
				continue;
			}
			if (_add)
			{
				if (!playersInGasClient.Contains(item))
				{
					playersInGasClient.Add(item);
				}
			}
			else
			{
				playersInGasClient.Remove(item);
			}
			break;
		}
	}

	private void PlayersOnCooldownTick()
	{
		if (!SemiFunc.IsMasterClientOrSingleplayer() || playersOnCooldown.Count == 0)
		{
			return;
		}
		List<PlayerAvatar> list = new List<PlayerAvatar>();
		foreach (KeyValuePair<PlayerAvatar, float> item in playersOnCooldown)
		{
			if (item.Value + 5f < Time.time)
			{
				list.Add(item.Key);
			}
		}
		foreach (PlayerAvatar item2 in list)
		{
			playersOnCooldown.Remove(item2);
		}
	}

	public void PlayerInGas(PlayerAvatar _player)
	{
		//IL_0036: Unknown result type (might be due to invalid IL or missing references)
		//IL_003b: Unknown result type (might be due to invalid IL or missing references)
		//IL_007a: Unknown result type (might be due to invalid IL or missing references)
		//IL_007f: Unknown result type (might be due to invalid IL or missing references)
		foreach (PlayersInGas playersInGa in this.playersInGas)
		{
			if ((Object)(object)playersInGa.playerAvatar == (Object)(object)_player)
			{
				playersInGa.outsideGasTime = 0f;
				playersInGa.lastPositionInsideGas = ((Component)_player).transform.position;
				return;
			}
		}
		PlayersInGas playersInGas = new PlayersInGas();
		playersInGas.playerAvatar = _player;
		playersInGas.outsideGasTime = 0f;
		playersInGas.lastPositionInsideGas = ((Component)_player).transform.position;
		this.playersInGas.Add(playersInGas);
	}

	public bool PlayerInGasCheck(PlayerAvatar _player)
	{
		foreach (PlayersInGas playersInGa in playersInGas)
		{
			if ((Object)(object)playersInGa.playerAvatar == (Object)(object)_player)
			{
				return true;
			}
		}
		return false;
	}

	private void TurnRandomTimer(float min, float max)
	{
		turnRandomTimer = Random.Range(min, max);
		turnRandomTimerMin = min;
		turnRandomTimerMax = max;
	}

	private void TurnRandomFull()
	{
		//IL_004f: Unknown result type (might be due to invalid IL or missing references)
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0071: Unknown result type (might be due to invalid IL or missing references)
		//IL_007b: Unknown result type (might be due to invalid IL or missing references)
		if (SemiFunc.IsMasterClientOrSingleplayer())
		{
			if (turnRandomTimer <= 0f)
			{
				float num = ((Random.value > 0.5f) ? 1f : (-1f));
				float num2 = Random.Range(35f, 65f) * num;
				((Component)this).transform.rotation = Quaternion.Euler(((Component)this).transform.rotation.x, ((Component)this).transform.rotation.y + num2, ((Component)this).transform.rotation.y);
				turnRandomTimer = Random.Range(turnRandomTimerMin, turnRandomTimerMax);
			}
			else
			{
				turnRandomTimer -= Time.deltaTime;
			}
		}
	}

	private void LevelPointsRoam()
	{
		//IL_0038: Unknown result type (might be due to invalid IL or missing references)
		//IL_001a: Unknown result type (might be due to invalid IL or missing references)
		levelPoints.Clear();
		List<LevelPoint> list = ((Random.Range(0, 4) != 0) ? SemiFunc.LevelPointGetWithinDistance(((Component)this).transform.position, 10f, 25f) : SemiFunc.LevelPointsGetPlayerDistance(((Component)this).transform.position, 0f, 20f));
		List<LevelPoint> list2 = SemiFunc.LevelPointListPurgeObstructed(list, ((Component)rb).GetComponentInChildren<CapsuleCollider>());
		if (list2.Count > 0)
		{
			levelPoints = list2;
		}
		SetPositionToRandomLevelPoint();
	}

	private void LevelPointsInvestigate()
	{
		//IL_000c: Unknown result type (might be due to invalid IL or missing references)
		levelPoints.Clear();
		List<LevelPoint> list = SemiFunc.LevelPointGetWithinDistance(investigatePosition, 0f, 10f);
		List<LevelPoint> list2 = new List<LevelPoint>();
		list2 = SemiFunc.LevelPointListPurgeObstructed(list, ((Component)rb).GetComponentInChildren<CapsuleCollider>());
		if (list2.Count > 0)
		{
			levelPoints = list2;
			SetPositionToRandomLevelPoint();
		}
		else
		{
			LevelPointsRoam();
		}
	}

	private void LevelPointsLeave()
	{
		//IL_0011: Unknown result type (might be due to invalid IL or missing references)
		//IL_0035: Unknown result type (might be due to invalid IL or missing references)
		levelPoints.Clear();
		List<LevelPoint> list = SemiFunc.LevelPointsGetPlayerDistance(((Component)this).transform.position, 30f, 999f);
		if (list.Count == 0)
		{
			LevelPoint levelPoint = SemiFunc.LevelPointGetFurthestFromPlayer(((Component)this).transform.position, 5f);
			if (Object.op_Implicit((Object)(object)levelPoint))
			{
				list.Add(levelPoint);
			}
		}
		List<LevelPoint> list2 = new List<LevelPoint>();
		list2 = SemiFunc.LevelPointListPurgeObstructed(list, ((Component)rb).GetComponentInChildren<CapsuleCollider>());
		if (list2.Count > 0)
		{
			levelPoints = list2;
			SetPositionToRandomLevelPoint();
		}
		else
		{
			LevelPointsRoam();
		}
		doLeave = false;
	}

	private void LevelPointsRoamAggro()
	{
		//IL_004e: Unknown result type (might be due to invalid IL or missing references)
		levelPoints.Clear();
		List<LevelPoint> list = SemiFunc.LevelPointListPurgeObstructed(SemiFunc.LevelPointsGetVisiblePointsBehindPlayers(1f, 10f, 0.5f, currentTarget), ((Component)rb).GetComponentInChildren<CapsuleCollider>());
		if (list.Count > 0)
		{
			levelPoints = list;
		}
		else
		{
			List<LevelPoint> list2 = SemiFunc.LevelPointGetWithinDistance(((Component)this).transform.position, 3f, 10f);
			list.Clear();
			list = SemiFunc.LevelPointListPurgeObstructed(list2, ((Component)rb).GetComponentInChildren<CapsuleCollider>());
			if (list.Count > 0)
			{
				levelPoints = list;
			}
		}
		SetPositionToRandomLevelPoint();
	}

	private void SetPositionToRandomLevelPoint()
	{
		//IL_0038: Unknown result type (might be due to invalid IL or missing references)
		//IL_003d: Unknown result type (might be due to invalid IL or missing references)
		//IL_005d: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		if (SemiFunc.IsMasterClientOrSingleplayer() && levelPoints.Count > 0)
		{
			Vector3 position = ((Component)levelPoints[Random.Range(0, levelPoints.Count)]).transform.position;
			((Component)this).transform.rotation = Quaternion.Euler(0f, Random.Range(0f, 360f), 0f);
			enemy.EnemyTeleported(position);
		}
	}

	private void GrowSpin()
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		if (SemiFunc.IsMasterClientOrSingleplayer())
		{
			float num = 1000f;
			float num2 = stateTimer / stateTimerMax * num;
			((Component)this).transform.Rotate(Vector3.up, num2 * Time.deltaTime, (Space)1);
		}
	}

	private void JumpScareAtChompStart()
	{
		//IL_006b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0099: Unknown result type (might be due to invalid IL or missing references)
		foreach (PlayerAvatar item in playersInGasClient)
		{
			if (Object.op_Implicit((Object)(object)item) && item.isLocal)
			{
				CameraGlitch.Instance.PlayLong();
				AudioScare.instance.PlayImpact();
				particlesShatteredDream.Play(true);
				GameDirector.instance.CameraShake.ShakeDistance(2f, 3f, 8f, ((Component)this).transform.position, 0.1f);
				GameDirector.instance.CameraImpact.ShakeDistance(4f, 3f, 8f, ((Component)this).transform.position, 0.1f);
				break;
			}
		}
	}

	private void JumpScareAtChompStartForceLookAtHead()
	{
		//IL_003a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0045: Unknown result type (might be due to invalid IL or missing references)
		//IL_004a: Unknown result type (might be due to invalid IL or missing references)
		//IL_004f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0050: Unknown result type (might be due to invalid IL or missing references)
		//IL_0057: Unknown result type (might be due to invalid IL or missing references)
		//IL_007f: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a1: Unknown result type (might be due to invalid IL or missing references)
		foreach (PlayerAvatar item in playersInGasClient)
		{
			if (Object.op_Implicit((Object)(object)item) && item.isLocal)
			{
				Vector3 val = item.localCamera.GetOverrideTransform().position - headCenterTransform.position;
				float num = Vector3.Dot(Vector3.down, val.normalized);
				float strengthNoAim = 40f;
				if (num > 0.9f)
				{
					strengthNoAim = 20f;
				}
				CameraAim.Instance.AimTargetSoftSet(headCenterTransform.position, 0.1f, 2f, strengthNoAim, ((Component)this).gameObject, 100);
				PostProcessing.Instance.VignetteOverride(Color.black, 0.5f, 1f, 1f, 0.5f, 0.1f, ((Component)this).gameObject);
				CameraZoom.Instance.OverrideZoomSet(40f, 0.1f, 1f, 1f, ((Component)this).gameObject, 50);
				break;
			}
		}
	}

	public bool PlayerIsOnCooldown(PlayerAvatar _player)
	{
		if (playersOnCooldown.ContainsKey(_player) && playersOnCooldown[_player] + 5f > Time.time)
		{
			return true;
		}
		return false;
	}

	public void RemovePlayerFromGas(PlayerAvatar _player)
	{
		if (!SemiFunc.IsMasterClientOrSingleplayer())
		{
			return;
		}
		List<PlayersInGas> list = new List<PlayersInGas>();
		foreach (PlayersInGas playersInGa in playersInGas)
		{
			if ((Object)(object)playersInGa.playerAvatar == (Object)(object)_player)
			{
				list.Add(playersInGa);
				break;
			}
		}
		foreach (PlayersInGas item in list)
		{
			playersInGas.Remove(item);
		}
	}

	private void ResetLocalGameTime()
	{
		float num = 50f;
		if (!SemiFunc.IsMultiplayer())
		{
			num = 0.0001f;
		}
		localGameTime = Math.Abs((float)instanceID * num);
	}

	[PunRPC]
	private void UpdateCurrentTargetRPC(int _photonViewID, PhotonMessageInfo _info = default(PhotonMessageInfo))
	{
		//IL_0000: Unknown result type (might be due to invalid IL or missing references)
		if (!SemiFunc.MasterOnlyRPC(_info))
		{
			return;
		}
		foreach (PlayerAvatar item in SemiFunc.PlayerGetList())
		{
			if (item.photonView.ViewID == _photonViewID)
			{
				currentTarget = item;
				hasTarget = true;
				break;
			}
		}
	}

	private void InvestigatePositionReset()
	{
		//IL_0001: Unknown result type (might be due to invalid IL or missing references)
		//IL_0006: Unknown result type (might be due to invalid IL or missing references)
		//IL_0026: Unknown result type (might be due to invalid IL or missing references)
		//IL_002b: Unknown result type (might be due to invalid IL or missing references)
		if (investigatePosition != Vector3.zero && currentState != State.Degrow && currentState != State.Grow)
		{
			investigatePosition = Vector3.zero;
		}
	}

	private void LeaveReset()
	{
		if (doLeave && currentState != State.Degrow && currentState != State.Grow)
		{
			doLeave = false;
		}
	}

	private void DespawnReset()
	{
		if (doDespawn && currentState != State.Degrow)
		{
			doDespawn = false;
		}
	}

	private void AttacksInARowReset()
	{
		if (attacksInARow > 0 && (currentState == State.Spawn || currentState == State.Degrow))
		{
			attacksInARow = 0;
		}
	}

	private void AggroBreakersInARowReset()
	{
		if (aggroBreakersInARow > 0 && (currentState == State.Spawn || currentState == State.Degrow))
		{
			aggroBreakersInARow = 0;
		}
	}

	private void LeaveStart()
	{
		attacksInARow = 0;
		doLeave = true;
		StateSet(State.Degrow);
	}

	private void DespawnStart()
	{
		attacksInARow = 0;
		doDespawn = true;
		StateSet(State.Degrow);
	}

	private void GrowDoneReset()
	{
		if (!growDone && currentState != State.Spawn && currentState != State.Degrow && currentState != State.Grow && currentState != State.AggroDegrow && currentState != State.AggroGrow)
		{
			growDone = true;
		}
	}

	private void ReleaseGrabLogic()
	{
		if (!SemiFunc.IsMasterClientOrSingleplayer())
		{
			return;
		}
		bool flag = false;
		if ((currentState == State.Spawn || currentState == State.Degrow || currentState == State.Grow || currentState == State.AggroDegrow || currentState == State.AggroGrow) && enemy.Rigidbody.physGrabObject.playerGrabbing.Count > 0)
		{
			flag = true;
		}
		if (flag)
		{
			releaseGrabTimer += Time.deltaTime;
			if (releaseGrabTimer > 0.5f)
			{
				enemy.Rigidbody.GrabRelease(_effects: false, 1f);
				releaseGrabTimer = 0f;
			}
		}
		else
		{
			releaseGrabTimer -= Time.deltaTime;
		}
		releaseGrabTimer = Mathf.Max(releaseGrabTimer, 0f);
	}

	private void PlayLoopSoundLogic()
	{
		bool playing = currentState == State.Idle || currentState == State.Roam;
		soundIdleLoop.PlayLoop(playing, 1f, 3f);
		bool playing2 = currentState == State.Aggro;
		soundAggroLoop.PlayLoop(playing2, 1f, 3f);
		bool flag = currentState == State.Lure || currentState == State.ChompGasp || currentState == State.Chomp;
		if (flag && overrideVisualsToEnchanted)
		{
			flag = false;
		}
		soundGasLoop.PlayLoop(flag, 1f, 3f);
		bool playing3 = currentState == State.Stunned;
		soundStunLoop.PlayLoop(playing3, 1f, 3f);
		bool playing4 = overrideVisualsToEnchanted;
		soundEnchantedLoop.PlayLoop(playing4, 1f, 3f);
	}

	private void TurnSoundLogic()
	{
		//IL_0067: Unknown result type (might be due to invalid IL or missing references)
		//IL_0072: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d8: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e3: Unknown result type (might be due to invalid IL or missing references)
		//IL_014f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0154: Unknown result type (might be due to invalid IL or missing references)
		//IL_0160: Unknown result type (might be due to invalid IL or missing references)
		//IL_0165: Unknown result type (might be due to invalid IL or missing references)
		//IL_009c: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c2: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c7: Unknown result type (might be due to invalid IL or missing references)
		//IL_0118: Unknown result type (might be due to invalid IL or missing references)
		//IL_013e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0143: Unknown result type (might be due to invalid IL or missing references)
		if (SemiFunc.PerSecond(5f, (Object)(object)this) && currentState != State.Spawn && currentState != State.Grow && currentState != State.Degrow && currentState != State.AggroGrow && currentState != State.AggroDegrow && currentState != State.Stunned && !overrideVisualsToEnchanted)
		{
			if (Quaternion.Angle(prevHeadLookRotation, headLook.rotation) > 30f && moveSoundHeadTimer <= 0f)
			{
				soundMoveHead.Play(headLook.position);
				prevHeadLookRotation = headLook.rotation;
				moveSoundHeadTimer = 0.2f;
			}
			if (Quaternion.Angle(prevRigidBodyRotation, rb.rotation) > 20f && moveSoundRigidBodyTimer <= 0f)
			{
				moveSoundRigidBodyTimer = 0.5f;
				soundMove.Play(followTarget.position);
				prevRigidBodyRotation = rb.rotation;
			}
			prevHeadLookRotation = headLook.rotation;
			prevRigidBodyRotation = rb.rotation;
		}
		if (moveSoundRigidBodyTimer > 0f)
		{
			moveSoundRigidBodyTimer -= Time.deltaTime;
		}
		if (moveSoundHeadTimer > 0f)
		{
			moveSoundHeadTimer -= Time.deltaTime;
		}
	}

	private void OverrideSpringValues(float _speed, float _damping)
	{
		overrideSpringValuesTimer = 0.1f;
		overrideSpringValuesSpeed = _speed;
		overrideSpringValuesDamping = _damping;
	}

	private void OverrideSpringValuesTick()
	{
		if (overrideSpringValuesTimer > 0f)
		{
			overrideSpringValuesTimer -= Time.deltaTime;
		}
	}

	private void OverrideActivateHorrorMeshes()
	{
		overrideActivateHorrorMeshesTimer = 0.05f;
	}

	private void OverrideActivateHorrorMeshesTick()
	{
		if (overrideActivateHorrorMeshesTimer <= 0f && horrorMeshesActive)
		{
			ActivateHorrorMeshes(_activate: false);
		}
		if (overrideActivateHorrorMeshesTimer > 0f)
		{
			if (!horrorMeshesActive)
			{
				ActivateHorrorMeshes(_activate: true);
			}
			overrideActivateHorrorMeshesTimer -= Time.deltaTime;
		}
	}

	private void OverrideVisualsToEnchantedLogic()
	{
		OverrideVisualToEnchantedForAllCapturedLocalPlayers();
		if (overrideVisualsToEnchantedTimer > 0f)
		{
			if (overrideVisualsToEnchantedTransitioning)
			{
				VisualStateNormalToEnchanting();
			}
			else
			{
				VisualStateEnchanting();
			}
		}
		else if (overrideVisualsToEnchantedTransitioning)
		{
			VisualStateEnchantingToNormal();
		}
	}

	private void OverrideVisualsToEnchanted()
	{
		if (!overrideVisualsToEnchanted)
		{
			overrideVisualsToEnchantedTransitioning = true;
			overrideVisualsToEnchanted = true;
			VisualPopAwayMeshesStart();
			particlesShatteredDream.Play(true);
			overrideVisualsToEnchantedInstantTransition = false;
		}
		overrideVisualsToEnchantedTimer = 0.05f;
	}

	private void OverrideVisualsToEnchantedTick()
	{
		if (overrideVisualsToEnchantedTimer <= 0f && overrideVisualsToEnchanted)
		{
			overrideVisualsToEnchanted = false;
			overrideVisualsToEnchantedTransitioning = true;
			VisualPopBackMeshesStart();
		}
		if (overrideVisualsToEnchantedTimer > 0f)
		{
			overrideVisualsToEnchantedTimer -= Time.deltaTime;
			ParticlePlayHearts();
			if (currentState == State.ChompGasp)
			{
				VisualPopBackMeshesStart();
				overrideVisualsToEnchantedInstantTransition = true;
				overrideVisualsToEnchantedTimer = 0f;
				overrideVisualsToEnchantedTransitioning = true;
				overrideVisualsToEnchanted = false;
			}
		}
	}

	private void OverrideVisualToEnchantedForAllCapturedLocalPlayers()
	{
		if (currentState != State.Lure)
		{
			return;
		}
		foreach (PlayerAvatar item in playersInGasClient)
		{
			if (Object.op_Implicit((Object)(object)item) && item.isLocal)
			{
				OverrideVisualsToEnchanted();
				break;
			}
		}
	}

	private void OverrideCanAggro()
	{
		canAggro = true;
		canAggroTimer = 0.05f;
	}

	private void OverrideCanAggroTick()
	{
		if (canAggroTimer <= 0f)
		{
			canAggro = false;
		}
		if (canAggroTimer > 0f)
		{
			canAggroTimer -= Time.deltaTime;
		}
	}

	private void ParticlePlayHearts()
	{
		if (particlePlayHeartsTimer <= 0f)
		{
			particlesHearts.Play(true);
		}
		particlePlayHeartsTimer = 0.2f;
	}

	private void ParticlePlayHeartsTick()
	{
		if (particlePlayHeartsTimer <= 0f && particlesHearts.isPlaying)
		{
			particlesHearts.Stop(true);
		}
		if (particlePlayHeartsTimer > 0f)
		{
			particlePlayHeartsTimer -= Time.deltaTime;
		}
	}

	private void ParticlePlayGas()
	{
		if (!(particlePlayHeartsTimer > 0f))
		{
			if (particlePlayGasTimer <= 0f)
			{
				gasParticles.Play(true);
			}
			particlePlayGasTimer = 0.2f;
		}
	}

	private void ParticlePlayGasTick()
	{
		if (particlePlayGasTimer <= 0f && gasParticles.isPlaying)
		{
			gasParticles.Stop(true);
		}
		if (particlePlayGasTimer > 0f)
		{
			particlePlayGasTimer -= Time.deltaTime;
		}
	}

	public void OnSpawn()
	{
		if (SemiFunc.IsMasterClientOrSingleplayer() && SemiFunc.EnemySpawn(enemy))
		{
			StateSet(State.Spawn);
		}
	}

	public void OnHurt()
	{
		//IL_0006: Unknown result type (might be due to invalid IL or missing references)
		//IL_000b: Unknown result type (might be due to invalid IL or missing references)
		//IL_002d: Unknown result type (might be due to invalid IL or missing references)
		//IL_001c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0026: Unknown result type (might be due to invalid IL or missing references)
		//IL_002b: Unknown result type (might be due to invalid IL or missing references)
		Vector3 nudgeAmount = rb.linearVelocity;
		if (nudgeAmount.magnitude > 5f)
		{
			nudgeAmount = nudgeAmount.normalized * 5f;
		}
		NudgeAllSprings(nudgeAmount);
		soundHurt.Play(mouthTransform);
	}

	public void OnDeath()
	{
		//IL_001f: Unknown result type (might be due to invalid IL or missing references)
		//IL_004d: Unknown result type (might be due to invalid IL or missing references)
		GameDirector.instance.CameraShake.ShakeDistance(2f, 3f, 8f, ((Component)this).transform.position, 0.1f);
		GameDirector.instance.CameraImpact.ShakeDistance(4f, 3f, 8f, ((Component)this).transform.position, 0.1f);
		foreach (ParticleSystem item in particlesDeath)
		{
			((Component)item).gameObject.SetActive(true);
		}
		soundDeath.Play(mouthTransform);
		if (SemiFunc.IsMasterClientOrSingleplayer())
		{
			enemy.EnemyParent.Despawn();
		}
	}

	public void OnVision()
	{
		if (SemiFunc.IsMasterClientOrSingleplayer() && canAggro)
		{
			currentTarget = enemy.Vision.onVisionTriggeredPlayer;
			hasTarget = Object.op_Implicit((Object)(object)currentTarget);
			if (GameManager.Multiplayer() && Object.op_Implicit((Object)(object)currentTarget))
			{
				networkTargetPending = currentTarget;
				networkTargetDirty = true;
				NetworkTargetFlush();
			}
			if (currentState != State.Aggro)
			{
				StateSet(State.AggroStart);
			}
		}
	}

	public void OnInvestigate()
	{
		//IL_002b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0030: Unknown result type (might be due to invalid IL or missing references)
		//IL_003b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0041: Unknown result type (might be due to invalid IL or missing references)
		//IL_005c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0067: Unknown result type (might be due to invalid IL or missing references)
		//IL_006c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0071: Unknown result type (might be due to invalid IL or missing references)
		//IL_0087: Unknown result type (might be due to invalid IL or missing references)
		//IL_0092: Unknown result type (might be due to invalid IL or missing references)
		//IL_0097: Unknown result type (might be due to invalid IL or missing references)
		//IL_009c: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b7: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c6: Unknown result type (might be due to invalid IL or missing references)
		if (!SemiFunc.IsMasterClientOrSingleplayer() || (currentState != State.Idle && currentState != State.Roam))
		{
			return;
		}
		investigatePosition = enemy.StateInvestigate.onInvestigateTriggeredPosition;
		if (Vector3.Distance(((Component)this).transform.position, investigatePosition) > 10f)
		{
			StateSet(State.Degrow);
			return;
		}
		Vector3 val = investigatePosition - ((Component)this).transform.position;
		if (val.magnitude > 0.01f)
		{
			((Component)this).transform.rotation = Quaternion.LookRotation(investigatePosition - ((Component)this).transform.position);
			((Component)this).transform.localEulerAngles = new Vector3(0f, ((Component)this).transform.localEulerAngles.y, 0f);
		}
		turnRandomTimer = Random.Range(turnRandomTimerMin, turnRandomTimerMax);
	}
}
