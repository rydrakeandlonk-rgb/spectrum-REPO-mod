using UnityEngine;

public class EnemyHeartHuggerGasGuider : MonoBehaviour
{
	internal Vector3 startPosition;

	internal Transform targetTransform;

	internal EnemyHeartHugger enemyHeartHugger;

	internal Transform headTransform;

	internal PlayerTumble playerTumble;

	internal PhysGrabObject physGrabObject;

	private float moveAlongEval;

	private float bringPlayerInTimer;

	internal PlayerAvatar player;

	private int tries;

	private float targetOutOfRangeTimer;

	private void Update()
	{
		//IL_009c: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b1: Unknown result type (might be due to invalid IL or missing references)
		//IL_00bb: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c0: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c4: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c9: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d0: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d5: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d7: Unknown result type (might be due to invalid IL or missing references)
		//IL_00dc: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e1: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e8: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f3: Unknown result type (might be due to invalid IL or missing references)
		//IL_0104: Unknown result type (might be due to invalid IL or missing references)
		//IL_0109: Unknown result type (might be due to invalid IL or missing references)
		//IL_0110: Unknown result type (might be due to invalid IL or missing references)
		//IL_01d1: Unknown result type (might be due to invalid IL or missing references)
		//IL_01d6: Unknown result type (might be due to invalid IL or missing references)
		//IL_0196: Unknown result type (might be due to invalid IL or missing references)
		//IL_019b: Unknown result type (might be due to invalid IL or missing references)
		if (!SemiFunc.IsMasterClientOrSingleplayer() || !Object.op_Implicit((Object)(object)player) || player.isDisabled || !Object.op_Implicit((Object)(object)enemyHeartHugger) || !enemyHeartHugger.enemy.EnemyParent.Spawned || enemyHeartHugger.enemy.Health.dead)
		{
			enemyHeartHugger?.RemovePlayerFromGas(player);
			Object.Destroy((Object)(object)((Component)this).gameObject);
			return;
		}
		enemyHeartHugger.PlayerInGas(player);
		float num = 1.5f;
		Vector3 val = new Vector3(headTransform.forward.x, 0f, headTransform.forward.z);
		Vector3 normalized = val.normalized;
		Vector3 val2 = headTransform.position + normalized * num;
		float num2 = Vector3.Distance(((Component)this).transform.position, targetTransform.position);
		((Component)this).transform.position = Vector3.Lerp(startPosition, val2, moveAlongEval);
		playerTumble.TumbleOverrideTime(1f);
		if (moveAlongEval < 1f)
		{
			moveAlongEval += Time.deltaTime * 0.15f;
		}
		else
		{
			moveAlongEval = 1f;
		}
		if (num2 > 2f)
		{
			targetOutOfRangeTimer += Time.deltaTime;
		}
		else
		{
			targetOutOfRangeTimer = 0f;
		}
		if (targetOutOfRangeTimer > 1.5f)
		{
			startPosition = targetTransform.position;
			moveAlongEval = 0f;
			tries++;
		}
		bringPlayerInTimer += Time.deltaTime;
		if (Vector3.Distance(targetTransform.position, val2) < 0.5f && enemyHeartHugger.currentState == EnemyHeartHugger.State.Lure)
		{
			enemyHeartHugger.StateSet(EnemyHeartHugger.State.ChompGasp);
			bringPlayerInTimer = 0f;
		}
		bool flag = enemyHeartHugger.currentState == EnemyHeartHugger.State.Lure || enemyHeartHugger.currentState == EnemyHeartHugger.State.ChompGasp || enemyHeartHugger.currentState == EnemyHeartHugger.State.Chomp;
		if (bringPlayerInTimer > 8f || tries > 2 || !enemyHeartHugger.isShootingGas || !flag)
		{
			enemyHeartHugger.RemovePlayerFromGas(player);
			Object.Destroy((Object)(object)((Component)this).gameObject);
		}
	}

	private void FixedUpdate()
	{
		//IL_003a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0040: Unknown result type (might be due to invalid IL or missing references)
		//IL_0045: Unknown result type (might be due to invalid IL or missing references)
		//IL_004a: Unknown result type (might be due to invalid IL or missing references)
		//IL_004e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0053: Unknown result type (might be due to invalid IL or missing references)
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_006a: Unknown result type (might be due to invalid IL or missing references)
		//IL_006f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0096: Unknown result type (might be due to invalid IL or missing references)
		//IL_009d: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a2: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a4: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ab: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b6: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b8: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c2: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c7: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ca: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d1: Unknown result type (might be due to invalid IL or missing references)
		if (SemiFunc.IsMasterClientOrSingleplayer())
		{
			if (!playerTumble.isTumbling)
			{
				playerTumble.TumbleRequest(_isTumbling: true, _playerInput: false);
				return;
			}
			Rigidbody rb = playerTumble.rb;
			Vector3 val = enemyHeartHugger.headCenterTransform.position - startPosition;
			Vector3 normalized = val.normalized;
			Vector3 position = playerTumble.rb.position;
			Vector3 position2 = ((Component)this).transform.position;
			physGrabObject.OverrideZeroGravity();
			playerTumble.TumbleOverrideTime(2f);
			Vector3 val2 = SemiFunc.PhysFollowDirection(((Component)rb).transform, normalized, rb, 0.5f);
			rb.AddTorque(val2 / rb.mass, (ForceMode)0);
			Vector3 val3 = SemiFunc.PhysFollowPosition(position, position2, rb.linearVelocity, 5f);
			rb.AddForce(val3 * 1f, (ForceMode)5);
		}
	}
}
