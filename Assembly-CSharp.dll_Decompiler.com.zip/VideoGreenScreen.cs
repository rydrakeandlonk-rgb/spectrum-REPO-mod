using UnityEngine;

public class VideoGreenScreen : MonoBehaviour
{
	private float distFromPlayer = 2f;

	private Vector3 flatForward = Vector3.forward;

	public Transform greenScreenFloor;

	public static VideoGreenScreen instance;

	[RuntimeInitializeOnLoadMethod(/*Could not decode attribute arguments.*/)]
	private static void RuntimeInitializeOnLoad()
	{
		instance = null;
	}

	private void Start()
	{
		instance = this;
	}

	private void Update()
	{
		//IL_0095: Unknown result type (might be due to invalid IL or missing references)
		//IL_012c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0131: Unknown result type (might be due to invalid IL or missing references)
		//IL_0141: Unknown result type (might be due to invalid IL or missing references)
		//IL_0146: Unknown result type (might be due to invalid IL or missing references)
		//IL_014b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0150: Unknown result type (might be due to invalid IL or missing references)
		//IL_001f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_0172: Unknown result type (might be due to invalid IL or missing references)
		//IL_0174: Unknown result type (might be due to invalid IL or missing references)
		//IL_017f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0184: Unknown result type (might be due to invalid IL or missing references)
		//IL_0195: Unknown result type (might be due to invalid IL or missing references)
		//IL_019a: Unknown result type (might be due to invalid IL or missing references)
		//IL_019f: Unknown result type (might be due to invalid IL or missing references)
		//IL_01a4: Unknown result type (might be due to invalid IL or missing references)
		//IL_01b4: Unknown result type (might be due to invalid IL or missing references)
		//IL_01b9: Unknown result type (might be due to invalid IL or missing references)
		//IL_0162: Unknown result type (might be due to invalid IL or missing references)
		//IL_0167: Unknown result type (might be due to invalid IL or missing references)
		//IL_0071: Unknown result type (might be due to invalid IL or missing references)
		//IL_0086: Unknown result type (might be due to invalid IL or missing references)
		//IL_0040: Unknown result type (might be due to invalid IL or missing references)
		//IL_0055: Unknown result type (might be due to invalid IL or missing references)
		//IL_01ea: Unknown result type (might be due to invalid IL or missing references)
		//IL_01ef: Unknown result type (might be due to invalid IL or missing references)
		//IL_021e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0223: Unknown result type (might be due to invalid IL or missing references)
		//IL_022d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0232: Unknown result type (might be due to invalid IL or missing references)
		if (Input.GetKeyUp((KeyCode)268))
		{
			if (((Component)greenScreenFloor).GetComponent<Renderer>().material.color == Color.green)
			{
				((Component)greenScreenFloor).GetComponent<Renderer>().material.color = Color.blue;
				((Component)this).GetComponentInChildren<Renderer>().material.color = Color.blue;
			}
			else
			{
				((Component)greenScreenFloor).GetComponent<Renderer>().material.color = Color.green;
				((Component)this).GetComponentInChildren<Renderer>().material.color = Color.green;
			}
		}
		PostProcessing.Instance.VignetteOverride(Color.black, 0f, 1f, 10f, 10f, 0.2f, ((Component)this).gameObject);
		PostProcessing.Instance.BloomDisable(0.2f);
		PostProcessing.Instance.GrainDisable(0.2f);
		GameplayManager.instance.OverrideCameraAnimation(0f, 0.2f);
		GameplayManager.instance.OverrideCameraNoise(0f, 0.2f);
		GameplayManager.instance.OverrideCameraShake(0f, 0.2f);
		Vector3 position = ((Component)PlayerAvatar.instance.localCamera).transform.position;
		Vector3 val = Vector3.ProjectOnPlane(((Component)PlayerAvatar.instance.localCamera).transform.forward, Vector3.up);
		if (val.sqrMagnitude > 0.001f)
		{
			flatForward = val.normalized;
		}
		((Component)this).transform.position = position + flatForward * distFromPlayer;
		((Component)this).transform.rotation = Quaternion.LookRotation(-flatForward, Vector3.up);
		RaycastHit[] array = Physics.RaycastAll(((Component)this).transform.position, Vector3.down, 100f, LayerMask.GetMask(new string[1] { "Default" }));
		float num = float.MaxValue;
		RaycastHit[] array2 = array;
		for (int i = 0; i < array2.Length; i++)
		{
			RaycastHit val2 = array2[i];
			if (((Component)val2.collider).CompareTag("Wall") && val2.distance < num)
			{
				num = val2.distance;
				greenScreenFloor.position = val2.point + Vector3.up * 0.01f;
			}
		}
		if (Input.GetAxis("Mouse ScrollWheel") < 0f)
		{
			distFromPlayer -= 0.1f;
		}
		if (Input.GetAxis("Mouse ScrollWheel") > 0f)
		{
			distFromPlayer += 0.1f;
		}
		distFromPlayer = Mathf.Clamp(distFromPlayer, 1f, 10f);
	}

	public VideoGreenScreen()
	{
		//IL_000c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0011: Unknown result type (might be due to invalid IL or missing references)
	}
}
