using UnityEngine;

public class PumpkinDeathVisual : MonoBehaviour
{
	private enum State
	{
		Ready,
		Spent
	}

	public MeshRenderer pumpkinRenderer;

	public PumpkinDeathBurst deathEffect;

	private EnemyHealth enemyHealth;

	private MeshFilter meshFilter;

	private State currentState;

	private void Awake()
	{
		if (!Object.op_Implicit((Object)(object)pumpkinRenderer))
		{
			pumpkinRenderer = ((Component)this).GetComponent<MeshRenderer>();
		}
		meshFilter = ((Component)pumpkinRenderer).GetComponent<MeshFilter>();
		EnemyParent componentInParent = ((Component)this).GetComponentInParent<EnemyParent>(true);
		if (Object.op_Implicit((Object)(object)componentInParent))
		{
			enemyHealth = ((Component)componentInParent).GetComponentInChildren<EnemyHealth>(true);
			if (Object.op_Implicit((Object)(object)enemyHealth))
			{
				enemyHealth.onDeathVisuals += Death;
			}
		}
	}

	private void OnEnable()
	{
		if (!Object.op_Implicit((Object)(object)enemyHealth) || !enemyHealth.dead)
		{
			currentState = State.Ready;
			if (Object.op_Implicit((Object)(object)pumpkinRenderer))
			{
				((Renderer)pumpkinRenderer).enabled = true;
			}
		}
	}

	private void OnDestroy()
	{
		if (Object.op_Implicit((Object)(object)enemyHealth))
		{
			enemyHealth.onDeathVisuals -= Death;
		}
	}

	private void Death()
	{
		//IL_006c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0071: Unknown result type (might be due to invalid IL or missing references)
		//IL_0074: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00aa: Unknown result type (might be due to invalid IL or missing references)
		//IL_00af: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b2: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c2: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c7: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ca: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ec: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ed: Unknown result type (might be due to invalid IL or missing references)
		//IL_00fe: Unknown result type (might be due to invalid IL or missing references)
		//IL_0091: Unknown result type (might be due to invalid IL or missing references)
		//IL_0096: Unknown result type (might be due to invalid IL or missing references)
		//IL_0099: Unknown result type (might be due to invalid IL or missing references)
		//IL_009e: Unknown result type (might be due to invalid IL or missing references)
		if (currentState == State.Ready && ((Behaviour)this).isActiveAndEnabled && SemiFunc.GameEventIsHalloween() && Object.op_Implicit((Object)(object)pumpkinRenderer) && ((Renderer)pumpkinRenderer).enabled && Object.op_Implicit((Object)(object)deathEffect))
		{
			currentState = State.Spent;
			Bounds bounds;
			Vector3 val;
			if (!Object.op_Implicit((Object)(object)meshFilter) || !Object.op_Implicit((Object)(object)meshFilter.sharedMesh))
			{
				bounds = ((Renderer)pumpkinRenderer).bounds;
				val = bounds.center;
			}
			else
			{
				Transform transform = ((Component)meshFilter).transform;
				bounds = meshFilter.sharedMesh.bounds;
				val = transform.TransformPoint(bounds.center);
			}
			Vector3 val2 = val;
			bounds = ((Renderer)pumpkinRenderer).bounds;
			float x = bounds.size.x;
			bounds = ((Renderer)pumpkinRenderer).bounds;
			float diameter = Mathf.Max(x, bounds.size.z);
			((Renderer)pumpkinRenderer).enabled = false;
			Object.Instantiate<PumpkinDeathBurst>(deathEffect, val2, Quaternion.identity).Play(diameter, ((Component)this).transform.forward);
		}
	}
}
