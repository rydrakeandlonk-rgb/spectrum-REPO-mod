using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

public class MenuElementCosmeticPreset : MonoBehaviour
{
	private MenuPageCosmetics menuPageCosmetics;

	public int presetIndex;

	public Image iconImage;

	private Sprite icon;

	private int iconGeneration;

	private readonly object iconCacheLock = new object();

	private TextMeshProUGUI iconText;

	private bool wasHovering;

	private bool wasHoveringNoCooldown;

	private bool wasEquipped;

	public MenuButton menuButton;

	public MenuButton deleteButton;

	public RawImage bgBorder;

	public RawImage bgMain;

	public GameObject playerAvatarIconPrefab;

	private GameObject spawnedAvatar;

	private Color32 bgColorMain = new Color32((byte)0, (byte)0, (byte)0, byte.MaxValue);

	private Color32 bgColorSelected = new Color32((byte)0, (byte)0, (byte)0, (byte)175);

	private SemiUI mainSemiUI;

	[Space]
	private float flashLerp = 1f;

	public RawImage bgFlash;

	public AnimationCurve flashAnimationCurve;

	[Space]
	public ShakeAnimation shakeAnimationX;

	public ShakeAnimation shakeAnimationY;

	public ShakeAnimation shakeAnimationRotation;

	public RectTransform shakeTransform;

	[Space]
	public Sound soundAdd;

	public Sound soundRemove;

	private void Awake()
	{
		menuPageCosmetics = ((Component)this).GetComponentInParent<MenuPageCosmetics>();
		iconText = ((Component)this).GetComponentInChildren<TextMeshProUGUI>();
		mainSemiUI = ((Component)this).GetComponentInChildren<SemiUI>();
	}

	private void Start()
	{
		UpdateIcon();
	}

	private void Update()
	{
		//IL_02c9: Unknown result type (might be due to invalid IL or missing references)
		//IL_02d9: Unknown result type (might be due to invalid IL or missing references)
		//IL_02e9: Unknown result type (might be due to invalid IL or missing references)
		//IL_0313: Unknown result type (might be due to invalid IL or missing references)
		bool flag = false;
		bool flag2 = IsEquipped();
		if (wasEquipped != flag2)
		{
			wasEquipped = flag2;
			menuButton.disabled = wasEquipped;
			flag = true;
		}
		if (menuButton.hovering)
		{
			menuPageCosmetics.pendingHoveredPresetButton = this;
		}
		if (wasHoveringNoCooldown != menuButton.hovering)
		{
			wasHoveringNoCooldown = menuButton.hovering;
			if (wasHoveringNoCooldown)
			{
				mainSemiUI.SemiUISpringShakeY(5f, 2f, 0.25f);
			}
			flag = true;
		}
		if (wasHovering != menuButton.hovering && menuPageCosmetics.cosmeticHoverCooldown <= 0f)
		{
			wasHovering = menuButton.hovering;
			if (wasHovering)
			{
				menuPageCosmetics.cosmeticHoverCooldown = 0.2f;
				if (!menuButton.disabled && !wasEquipped && (MetaManager.instance.cosmeticPresets[presetIndex].Count > 0 || MetaManager.instance.colorPresets[presetIndex].Count > 0))
				{
					MetaManager.instance.colorsEquippedPreview = MetaManager.instance.colorsEquipped.ToArray();
					MetaManager.instance.cosmeticEquippedPreview.Clear();
					foreach (int item in MetaManager.instance.cosmeticPresets[presetIndex])
					{
						if (item >= 0 && item < MetaManager.instance.cosmeticAssets.Count)
						{
							CosmeticAsset cosmeticAssetNew = MetaManager.instance.cosmeticAssets[item];
							MetaManager.instance.CosmeticEquip(cosmeticAssetNew, _isPreview: true);
							menuPageCosmetics.shouldSave = true;
						}
					}
					for (int i = 0; i < MetaManager.instance.colorPresets[presetIndex].Count; i++)
					{
						if (i >= 0 && i < MetaManager.instance.colorsEquippedPreview.Length)
						{
							int num = MetaManager.instance.colorPresets[presetIndex][i];
							MetaManager.instance.colorsEquippedPreview[i] = num;
						}
					}
					MetaManager.instance.CosmeticPreviewSet(_state: true);
				}
				else
				{
					MetaManager.instance.CosmeticPreviewSet(_state: false);
				}
				MetaManager.instance.CosmeticPlayerUpdateLocal(_synced: false);
			}
		}
		if (flag)
		{
			UpdateIcon();
		}
		ShakeLogic();
		if (flashLerp < 1f)
		{
			flashLerp += 5f * Time.deltaTime;
			flashLerp = Mathf.Clamp01(flashLerp);
			((Graphic)bgFlash).color = new Color(((Graphic)bgFlash).color.r, ((Graphic)bgFlash).color.g, ((Graphic)bgFlash).color.b, Mathf.Lerp(0.75f, 0f, flashAnimationCurve.Evaluate(flashLerp)));
			if (flashLerp >= 1f)
			{
				((Component)bgFlash).gameObject.SetActive(false);
			}
		}
	}

	private void OnDisable()
	{
		ForceDisableHover();
	}

	private void OnDestroy()
	{
		ReleaseIcon();
		ForceDisableHover();
		if (Object.op_Implicit((Object)(object)spawnedAvatar))
		{
			Object.Destroy((Object)(object)spawnedAvatar);
		}
	}

	private void ForceDisableHover()
	{
		if ((Object)(object)menuPageCosmetics.hoveredPresetButton == (Object)(object)this)
		{
			menuPageCosmetics.hoveredPresetButton = null;
			MetaManager.instance.CosmeticPreviewSet(_state: false);
			MetaManager.instance.CosmeticPlayerUpdateLocal(_synced: false);
		}
	}

	private void UpdateIcon(bool _generated = false)
	{
		//IL_0037: Unknown result type (might be due to invalid IL or missing references)
		//IL_003c: Unknown result type (might be due to invalid IL or missing references)
		//IL_001f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_0060: Unknown result type (might be due to invalid IL or missing references)
		((TMP_Text)iconText).text = "";
		if (IsEquipped())
		{
			((Graphic)bgMain).color = Color32.op_Implicit(bgColorSelected);
		}
		else
		{
			((Graphic)bgMain).color = Color32.op_Implicit(bgColorMain);
		}
		((Graphic)iconImage).color = new Color(255f, 255f, 255f, 255f);
		if (MetaManager.instance.cosmeticPresets[presetIndex].Count > 0 || MetaManager.instance.colorPresets[presetIndex].Count > 0)
		{
			iconImage.sprite = GetIcon(_generated);
			if (Object.op_Implicit((Object)(object)iconImage.sprite))
			{
				((Component)iconImage).gameObject.SetActive(true);
			}
			else
			{
				((Component)iconImage).gameObject.SetActive(false);
				((TMP_Text)iconText).text = presetIndex.ToString();
			}
			((Component)deleteButton).gameObject.SetActive(true);
		}
		else
		{
			((Component)iconImage).gameObject.SetActive(false);
			((TMP_Text)iconText).text = "+";
			((Component)deleteButton).gameObject.SetActive(false);
		}
	}

	private bool CheckCosmeticsEquipped()
	{
		List<int> list = MetaManager.instance.cosmeticPresets[presetIndex];
		List<int> cosmeticEquipped = MetaManager.instance.cosmeticEquipped;
		if (list.Count != cosmeticEquipped.Count)
		{
			return false;
		}
		for (int i = 0; i < list.Count; i++)
		{
			if (list[i] != cosmeticEquipped[i])
			{
				return false;
			}
		}
		return true;
	}

	private bool CheckColorsEquipped()
	{
		List<int> list = MetaManager.instance.colorPresets[presetIndex];
		int[] colorsEquipped = MetaManager.instance.colorsEquipped;
		if (list.Count != colorsEquipped.Length)
		{
			return false;
		}
		for (int i = 0; i < list.Count; i++)
		{
			if (list[i] != colorsEquipped[i])
			{
				return false;
			}
		}
		return true;
	}

	private bool IsEquipped()
	{
		List<int> list = MetaManager.instance.cosmeticPresets[presetIndex];
		List<int> list2 = MetaManager.instance.colorPresets[presetIndex];
		if ((list.Count > 0 || list2.Count > 0) && CheckCosmeticsEquipped())
		{
			return CheckColorsEquipped();
		}
		return false;
	}

	private bool CheckCosmeticsPreviewing()
	{
		if (!MetaManager.instance.cosmeticPreviewEnabled)
		{
			return false;
		}
		List<int> list = MetaManager.instance.cosmeticPresets[presetIndex];
		List<int> cosmeticEquippedPreview = MetaManager.instance.cosmeticEquippedPreview;
		if (list.Count != cosmeticEquippedPreview.Count)
		{
			return false;
		}
		for (int i = 0; i < list.Count; i++)
		{
			if (list[i] != cosmeticEquippedPreview[i])
			{
				return false;
			}
		}
		return true;
	}

	private bool CheckColorsPreviewing()
	{
		if (!MetaManager.instance.colorsPreviewEnabled)
		{
			return false;
		}
		List<int> list = MetaManager.instance.colorPresets[presetIndex];
		int[] colorsEquippedPreview = MetaManager.instance.colorsEquippedPreview;
		if (list.Count != colorsEquippedPreview.Length)
		{
			return false;
		}
		for (int i = 0; i < list.Count; i++)
		{
			if (list[i] != colorsEquippedPreview[i])
			{
				return false;
			}
		}
		return true;
	}

	private bool IsPreviewing()
	{
		List<int> list = MetaManager.instance.cosmeticPresets[presetIndex];
		List<int> list2 = MetaManager.instance.colorPresets[presetIndex];
		if ((list.Count > 0 || list2.Count > 0) && CheckCosmeticsPreviewing())
		{
			return CheckColorsPreviewing();
		}
		return false;
	}

	private void TriggerClickAnimations()
	{
		mainSemiUI.SemiUISpringScale(-0.3f, 2f, 0.25f);
		shakeAnimationX.Set(5f, 3f);
		shakeAnimationY.Set(5f, 3f);
		shakeAnimationRotation.Set(5f, 2f);
		((Component)bgFlash).gameObject.SetActive(true);
		flashLerp = 0f;
	}

	public void TogglePreset()
	{
		//IL_0028: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ac: Unknown result type (might be due to invalid IL or missing references)
		//IL_0281: Unknown result type (might be due to invalid IL or missing references)
		MenuManager.instance.MenuEffectClick(MenuManager.MenuClickEffectType.Action, menuPageCosmetics.menuPage, -1f, 0f);
		((Graphic)bgFlash).color = Color.white;
		TriggerClickAnimations();
		if (MetaManager.instance.cosmeticPresets[presetIndex].Count > 0 || MetaManager.instance.colorPresets[presetIndex].Count > 0)
		{
			soundAdd.Volume = soundAdd.VolumeDefault / 2f;
			soundAdd.Pitch = 0.75f;
			soundAdd.Play(MenuManager.instance.soundPosition);
			if (!IsEquipped())
			{
				foreach (int item in MetaManager.instance.cosmeticEquipped.ToList())
				{
					if (item >= 0 && item < MetaManager.instance.cosmeticAssets.Count)
					{
						CosmeticAsset cosmeticAsset = MetaManager.instance.cosmeticAssets[item];
						MetaManager.instance.CosmeticUnequip(cosmeticAsset, _isPreview: false);
						menuPageCosmetics.shouldSave = true;
					}
				}
				foreach (int item2 in MetaManager.instance.cosmeticPresets[presetIndex])
				{
					if (item2 >= 0 && item2 < MetaManager.instance.cosmeticAssets.Count)
					{
						CosmeticAsset cosmeticAssetNew = MetaManager.instance.cosmeticAssets[item2];
						MetaManager.instance.CosmeticEquip(cosmeticAssetNew, _isPreview: false);
						menuPageCosmetics.shouldSave = true;
					}
				}
				for (int i = 0; i < MetaManager.instance.colorPresets[presetIndex].Count; i++)
				{
					if (i >= 0 && i < MetaManager.instance.colorsEquipped.Length)
					{
						int colorID = MetaManager.instance.colorPresets[presetIndex][i];
						MetaManager.instance.CosmeticColorSet(i, colorID);
						menuPageCosmetics.shouldSave = true;
					}
				}
			}
		}
		else
		{
			soundAdd.Volume = soundAdd.VolumeDefault;
			soundAdd.Pitch = soundAdd.PitchDefault;
			soundAdd.Play(MenuManager.instance.soundPosition);
			MetaManager.instance.CosmeticPresetSet(presetIndex, MetaManager.instance.cosmeticEquipped.ToList(), MetaManager.instance.colorsEquipped.ToList());
			menuPageCosmetics.shouldSave = true;
			ResetIcon();
		}
		MetaManager.instance.CosmeticPreviewSet(_state: false);
		MetaManager.instance.CosmeticPlayerUpdateLocal(_synced: false);
		UpdateIcon();
	}

	public void DeletePreset()
	{
		//IL_002d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0052: Unknown result type (might be due to invalid IL or missing references)
		MenuManager.instance.MenuEffectClick(MenuManager.MenuClickEffectType.Action, menuPageCosmetics.menuPage, -1f, 0f);
		soundRemove.Play(MenuManager.instance.soundPosition);
		((Graphic)bgFlash).color = Color.red;
		TriggerClickAnimations();
		MetaManager.instance.CosmeticPresetSet(presetIndex, new List<int>(), new List<int>());
		menuPageCosmetics.shouldSave = true;
		ResetIcon();
		UpdateIcon();
		MenuManager.instance.lastHoverMenuID = menuButton.MenuID;
	}

	private IEnumerator GetIconCoroutine(SemiIconMaker _iconMaker, string filePath)
	{
		GameObject _avatar = spawnedAvatar;
		int _generation = iconGeneration;
		yield return null;
		Task _capture = CaptureIcon(_iconMaker, _avatar, _generation, filePath);
		while (!_capture.IsCompleted)
		{
			yield return null;
		}
	}

	private async Task CaptureIcon(SemiIconMaker _iconMaker, GameObject _avatar, int _generation, string _filePath)
	{
		Sprite _sprite = null;
		try
		{
			await Task.Yield();
			if (!Object.op_Implicit((Object)(object)this) || !Object.op_Implicit((Object)(object)_avatar) || _generation != iconGeneration)
			{
				return;
			}
			_sprite = await _iconMaker.CreateIconAsync(null, () => Object.op_Implicit((Object)(object)this) && Object.op_Implicit((Object)(object)_avatar) && _generation == iconGeneration, (byte[] _bytes) =>
			{
				lock (iconCacheLock)
				{
					if (_generation == iconGeneration)
					{
						Directory.CreateDirectory(Path.GetDirectoryName(_filePath));
						File.WriteAllBytes(_filePath, _bytes);
					}
				}
			});
			if (Object.op_Implicit((Object)(object)this) && _generation == iconGeneration)
			{
				icon = _sprite;
				_sprite = null;
				if (Object.op_Implicit((Object)(object)icon))
				{
					UpdateIcon(_generated: true);
				}
			}
		}
		catch (Exception ex)
		{
			Debug.LogException(ex);
		}
		finally
		{
			if (Object.op_Implicit((Object)(object)_sprite))
			{
				Object.Destroy((Object)(object)_sprite.texture);
				Object.Destroy((Object)(object)_sprite);
			}
			if (Object.op_Implicit((Object)(object)_avatar))
			{
				Object.Destroy((Object)(object)_avatar);
			}
			if ((Object)(object)spawnedAvatar == (Object)(object)_avatar)
			{
				spawnedAvatar = null;
			}
		}
	}

	private void ReleaseIcon()
	{
		lock (iconCacheLock)
		{
			iconGeneration++;
		}
		if (Object.op_Implicit((Object)(object)spawnedAvatar))
		{
			Object.Destroy((Object)(object)spawnedAvatar);
		}
		spawnedAvatar = null;
		if (Object.op_Implicit((Object)(object)icon))
		{
			Object.Destroy((Object)(object)icon.texture);
			Object.Destroy((Object)(object)icon);
			icon = null;
		}
	}

	private Sprite GetIcon(bool _generated = false)
	{
		//IL_0104: Unknown result type (might be due to invalid IL or missing references)
		//IL_0109: Unknown result type (might be due to invalid IL or missing references)
		bool flag = Object.op_Implicit((Object)(object)DebugComputerCheck.instance) && !DebugComputerCheck.instance.DebugDisable && DebugComputerCheck.instance.ItemDebug && DebugComputerCheck.instance.DisableItemIconCache;
		if (flag && !_generated && Object.op_Implicit((Object)(object)icon))
		{
			ReleaseIcon();
		}
		if (!Object.op_Implicit((Object)(object)icon))
		{
			string text = (Application.isEditor ? Path.Combine("Cache", "Editor") : "Cache");
			string text2 = presetIndex.ToString();
			string text3 = Path.Combine(new string[5]
			{
				Application.persistentDataPath,
				text,
				"Icons",
				MetaManager.instance.presetCacheFolder,
				text2.ToLowerInvariant() + ".png"
			});
			if (!flag | _generated)
			{
				icon = SemiFunc.LoadSpriteFromFile(text3);
			}
			if (!Object.op_Implicit((Object)(object)icon))
			{
				if (Object.op_Implicit((Object)(object)spawnedAvatar))
				{
					return icon;
				}
				spawnedAvatar = Object.Instantiate<GameObject>(playerAvatarIconPrefab, Vector3.zero, Quaternion.identity);
				PlayerCosmetics componentInChildren = spawnedAvatar.GetComponentInChildren<PlayerCosmetics>();
				if (Object.op_Implicit((Object)(object)componentInChildren))
				{
					List<int> list = new List<int>();
					foreach (int item2 in MetaManager.instance.cosmeticPresets[presetIndex])
					{
						if (item2 < 0 || item2 >= MetaManager.instance.cosmeticAssets.Count)
						{
							continue;
						}
						list.Add(item2);
						CosmeticAsset cosmeticAssetNew = MetaManager.instance.cosmeticAssets[item2];
						foreach (CosmeticAsset item3 in MetaManager.instance.GetCosmeticsToUnequip(list, cosmeticAssetNew))
						{
							int item = MetaManager.instance.cosmeticAssets.IndexOf(item3);
							list.Remove(item);
						}
					}
					componentInChildren.SetupCosmeticsLogic(list.ToArray(), _forced: false);
					componentInChildren.SetupColorsLogic(MetaManager.instance.colorPresets[presetIndex].ToArray());
					PlayerAvatarMenu componentInChildren2 = spawnedAvatar.GetComponentInChildren<PlayerAvatarMenu>();
					SemiIconMaker semiIconMaker = ((componentInChildren2 != null) ? ((Component)componentInChildren2.cameraAndStuff).GetComponentInChildren<SemiIconMaker>(true) : null);
					if (Object.op_Implicit((Object)(object)semiIconMaker))
					{
						SemiIconMaker[] componentsInChildren = spawnedAvatar.GetComponentsInChildren<SemiIconMaker>();
						foreach (SemiIconMaker semiIconMaker2 in componentsInChildren)
						{
							if (!((Object)(object)semiIconMaker2 == (Object)(object)semiIconMaker))
							{
								((Component)semiIconMaker2).gameObject.SetActive(false);
							}
						}
						((MonoBehaviour)this).StartCoroutine(GetIconCoroutine(semiIconMaker, text3));
					}
					else
					{
						Debug.LogWarning((object)("No IconMaker found in " + ((Object)playerAvatarIconPrefab).name + ", add SemiIconMaker prefab and align the camera to make a proper icon"));
						Object.Destroy((Object)(object)spawnedAvatar);
					}
				}
				else
				{
					Object.Destroy((Object)(object)spawnedAvatar);
				}
			}
		}
		return icon;
	}

	private void ResetIcon()
	{
		ReleaseIcon();
		string text = (Application.isEditor ? Path.Combine("Cache", "Editor") : "Cache");
		string text2 = presetIndex.ToString();
		string path = Path.Combine(new string[5]
		{
			Application.persistentDataPath,
			text,
			"Icons",
			MetaManager.instance.presetCacheFolder,
			text2.ToLowerInvariant() + ".png"
		});
		if (File.Exists(path))
		{
			try
			{
				File.Delete(path);
			}
			catch (Exception ex)
			{
				Debug.LogError((object)ex);
			}
		}
	}

	private void ShakeLogic()
	{
		//IL_0079: Unknown result type (might be due to invalid IL or missing references)
		//IL_007e: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a6: Unknown result type (might be due to invalid IL or missing references)
		bool num = shakeAnimationX.lerp < 1f || shakeAnimationY.lerp < 1f;
		bool flag = shakeAnimationRotation.lerp < 1f;
		shakeAnimationX.UpdateShake();
		shakeAnimationY.UpdateShake();
		shakeAnimationRotation.UpdateShake();
		if (num)
		{
			((Transform)shakeTransform).localPosition = Vector2.op_Implicit(new Vector2(shakeAnimationX.Get(), shakeAnimationY.Get()));
		}
		if (flag)
		{
			((Transform)shakeTransform).localEulerAngles = new Vector3(0f, 0f, shakeAnimationRotation.Get());
		}
	}

	public MenuElementCosmeticPreset()
	{
		//IL_0014: Unknown result type (might be due to invalid IL or missing references)
		//IL_0019: Unknown result type (might be due to invalid IL or missing references)
		//IL_0027: Unknown result type (might be due to invalid IL or missing references)
		//IL_002c: Unknown result type (might be due to invalid IL or missing references)
	}
}
