using TMPro;
using UnityEngine;
using UnityEngine.UI;

public class WorldSpaceUITTS : WorldSpaceUIChild
{
	internal enum Source
	{
		PlayerVoice,
		WorldText
	}

	internal Source source;

	internal SemiWorldText worldText;

	internal float displayTimer;

	internal TextMeshProUGUI text;

	internal float wordTime;

	internal TTSVoice ttsVoice;

	internal Transform followTransform;

	internal PlayerAvatar playerAvatar;

	internal Vector3 offsetPosition;

	private float flashTimer = 0.1f;

	private Color textColor = Color.yellow;

	private Color textColorTarget = Color.white;

	private bool flashDone;

	public AnimationCurve curveIntro;

	private float curveLerp;

	internal Vector3 followPosition;

	private float alphaCheckTimer;

	private float textAlphaTarget;

	private float textAlpha;

	private Camera cameraMain;

	private void Awake()
	{
		//IL_004f: Unknown result type (might be due to invalid IL or missing references)
		text = ((Component)this).GetComponent<TextMeshProUGUI>();
		((TMP_Text)text).OnPreRenderText += WrappedRowsOffset;
		((Graphic)text).color = new Color(textColor.r, textColor.g, textColor.b, 0f);
		cameraMain = Camera.main;
	}

	private void OnDestroy()
	{
		if (Object.op_Implicit((Object)(object)text))
		{
			((TMP_Text)text).OnPreRenderText -= WrappedRowsOffset;
		}
	}

	private void WrappedRowsOffset(TMP_TextInfo _textInfo)
	{
		//IL_0035: Unknown result type (might be due to invalid IL or missing references)
		//IL_003a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0049: Unknown result type (might be due to invalid IL or missing references)
		//IL_004e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0054: Unknown result type (might be due to invalid IL or missing references)
		//IL_005a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0089: Unknown result type (might be due to invalid IL or missing references)
		//IL_008e: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b5: Unknown result type (might be due to invalid IL or missing references)
		//IL_0095: Unknown result type (might be due to invalid IL or missing references)
		if (source != Source.WorldText || !Object.op_Implicit((Object)(object)worldText) || _textInfo.lineCount <= 1 || worldText.rowGrowth == SemiWorldText.RowGrowth.Middle)
		{
			return;
		}
		TMP_LineInfo val = _textInfo.lineInfo[0];
		TMP_LineInfo val2 = _textInfo.lineInfo[_textInfo.lineCount - 1];
		float num = Mathf.Max(0f, val.baseline - val2.baseline) * 0.5f;
		if (worldText.rowGrowth == SemiWorldText.RowGrowth.Downwards)
		{
			num = 0f - num;
		}
		for (int i = 0; i < _textInfo.meshInfo.Length; i++)
		{
			TMP_MeshInfo val3 = _textInfo.meshInfo[i];
			for (int j = 0; j < val3.vertexCount; j++)
			{
				val3.vertices[j].y += num;
			}
		}
	}

	private bool SourceActive()
	{
		if (!Object.op_Implicit((Object)(object)followTransform))
		{
			return false;
		}
		if (source == Source.WorldText)
		{
			if (Object.op_Implicit((Object)(object)worldText) && ((Behaviour)worldText).isActiveAndEnabled)
			{
				return displayTimer > 0f;
			}
			return false;
		}
		if (Object.op_Implicit((Object)(object)ttsVoice) && ttsVoice.isSpeaking && Object.op_Implicit((Object)(object)playerAvatar))
		{
			if (playerAvatar.isDisabled)
			{
				return playerAvatar.playerDeathHead.spectated;
			}
			return true;
		}
		return false;
	}

	protected override void Update()
	{
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0065: Unknown result type (might be due to invalid IL or missing references)
		//IL_01f1: Unknown result type (might be due to invalid IL or missing references)
		//IL_023c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0252: Unknown result type (might be due to invalid IL or missing references)
		//IL_0257: Unknown result type (might be due to invalid IL or missing references)
		//IL_0261: Unknown result type (might be due to invalid IL or missing references)
		//IL_0266: Unknown result type (might be due to invalid IL or missing references)
		//IL_026b: Unknown result type (might be due to invalid IL or missing references)
		//IL_020a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0215: Unknown result type (might be due to invalid IL or missing references)
		//IL_021b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0220: Unknown result type (might be due to invalid IL or missing references)
		//IL_0230: Unknown result type (might be due to invalid IL or missing references)
		//IL_0235: Unknown result type (might be due to invalid IL or missing references)
		//IL_0187: Unknown result type (might be due to invalid IL or missing references)
		//IL_018d: Unknown result type (might be due to invalid IL or missing references)
		//IL_019b: Unknown result type (might be due to invalid IL or missing references)
		//IL_01a1: Unknown result type (might be due to invalid IL or missing references)
		//IL_01b1: Unknown result type (might be due to invalid IL or missing references)
		//IL_01b6: Unknown result type (might be due to invalid IL or missing references)
		base.Update();
		if (alphaCheckTimer <= 0f)
		{
			textAlphaTarget = 1f;
			alphaCheckTimer = 0.1f;
			if (!Object.op_Implicit((Object)(object)SpectateCamera.instance) || !SpectateCamera.instance.CheckState(SpectateCamera.State.Death))
			{
				float num = 5f;
				float num2 = 20f;
				float num3 = Vector3.Distance(((Component)cameraMain).transform.position, worldPosition);
				if (num3 > num)
				{
					num3 = Mathf.Clamp(num3, num, num2);
					textAlphaTarget = 1f - (num3 - num) / (num2 - num);
				}
				if (Object.op_Implicit((Object)(object)ttsVoice) && ttsVoice.playerAvatar.voiceChat.lowPassLogicTTS.LowPass)
				{
					textAlphaTarget *= 0.5f;
				}
			}
		}
		else
		{
			alphaCheckTimer -= Time.deltaTime;
		}
		if (!SourceActive())
		{
			textAlphaTarget = 0f;
			if (textAlpha < 0.01f)
			{
				Object.Destroy((Object)(object)((Component)this).gameObject);
				return;
			}
		}
		textAlpha = Mathf.Lerp(textAlpha, textAlphaTarget, 30f * Time.deltaTime);
		if (source == Source.WorldText && displayTimer > 0f)
		{
			displayTimer = Mathf.Max(0f, displayTimer - Time.deltaTime);
		}
		if (!flashDone)
		{
			flashTimer -= Time.deltaTime;
			if (flashTimer <= 0f)
			{
				if (textColor != textColorTarget)
				{
					textColor = Color.Lerp(textColor, textColorTarget, 20f * Time.deltaTime);
				}
				else
				{
					flashDone = true;
				}
			}
		}
		((Graphic)text).color = new Color(textColor.r, textColor.g, textColor.b, textAlpha);
		if (Object.op_Implicit((Object)(object)followTransform))
		{
			followPosition = Vector3.Lerp(followPosition, followTransform.position + offsetPosition, 10f * Time.deltaTime);
		}
		worldPosition = followPosition + curveIntro.Evaluate(curveLerp) * Vector3.up * 0.025f;
		curveLerp += Time.deltaTime * 4f;
		curveLerp = Mathf.Clamp01(curveLerp);
		if (source == Source.PlayerVoice && Object.op_Implicit((Object)(object)ttsVoice) && ttsVoice.currentWordTime != wordTime)
		{
			Object.Destroy((Object)(object)((Component)this).gameObject);
		}
	}

	public WorldSpaceUITTS()
	{
		//IL_000c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0011: Unknown result type (might be due to invalid IL or missing references)
		//IL_0017: Unknown result type (might be due to invalid IL or missing references)
		//IL_001c: Unknown result type (might be due to invalid IL or missing references)
	}
}
