using UnityEngine;

public class MenuPagePublicGameChoice : MonoBehaviour
{
	private void Update()
	{
		if (SemiFunc.InputDown(InputKey.Back) && MenuManager.instance.currentMenuPageIndex == MenuPageIndex.PublicGameChoice)
		{
			ExitPage();
		}
	}

	public void ButtonRandomMatchmaking()
	{
		SemiFunc.MenuActionRandomMatchmaking();
	}

	public void ButtonServerList()
	{
		MenuManager.instance.PageCloseAll();
		MenuManager.instance.PageOpen(MenuPageIndex.ServerList);
	}

	public void ExitPage()
	{
		MenuManager.instance.PageCloseAll();
		((Component)MenuManager.instance.PageOpen(MenuPageIndex.Regions)).GetComponent<MenuPageRegions>().type = MenuPageRegions.Type.PlayRandom;
	}
}
