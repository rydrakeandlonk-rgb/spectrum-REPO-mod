using TMPro;
using UnityEngine;
using UnityEngine.UI;

public class ShopCostUI : SemiUI
{
	public static ShopCostUI instance;

	private TextMeshProUGUI Text;

	public int animatedValue;

	private Color originalColor;

	private int currentValue;

	private int prevValue;

	[RuntimeInitializeOnLoadMethod(/*Could not decode attribute arguments.*/)]
	private static void RuntimeInitializeOnLoad()
	{
		instance = null;
	}

	protected override void Start()
	{
		//IL_001f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		base.Start();
		Text = ((Component)this).GetComponent<TextMeshProUGUI>();
		instance = this;
		originalColor = ((Graphic)Text).color;
	}

	protected override void Update()
	{
		//IL_0057: Unknown result type (might be due to invalid IL or missing references)
		//IL_005d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0097: Unknown result type (might be due to invalid IL or missing references)
		//IL_009c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0070: Unknown result type (might be due to invalid IL or missing references)
		//IL_0150: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c7: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ab: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b0: Unknown result type (might be due to invalid IL or missing references)
		//IL_01b1: Unknown result type (might be due to invalid IL or missing references)
		//IL_01b6: Unknown result type (might be due to invalid IL or missing references)
		//IL_01c8: Unknown result type (might be due to invalid IL or missing references)
		base.Update();
		if (SemiFunc.RunIsShop())
		{
			int num = SemiFunc.ShopGetTotalCost();
			string text = SemiFunc.DollarGetString(num);
			if (num > 0)
			{
				string text2 = "-$" + text + "K";
				if (((TMP_Text)Text).text != text2)
				{
					((TMP_Text)Text).text = text2;
				}
				if (((Graphic)Text).color != originalColor)
				{
					((Graphic)Text).color = originalColor;
				}
			}
			else
			{
				Hide();
			}
			currentValue = num;
			if (currentValue != prevValue)
			{
				Color color = Color.white;
				if (currentValue > prevValue)
				{
					color = Color.red;
				}
				SemiUISpringShakeY(20f, 10f, 0.3f);
				SemiUITextFlashColor(color, 0.2f);
				SemiUISpringScale(0.4f, 5f, 0.2f);
				prevValue = currentValue;
			}
		}
		if (!SemiFunc.RunIsShop())
		{
			Hide();
		}
		if (CurrencyUI.instance.showTimer > 0f && ((CosmeticWorldObjectUI.instance.showTimer > 0f && CosmeticWorldObjectUI.instance.elements.Count > 0) || ShopIncreaseUI.instance.showTimer > 0f))
		{
			SemiUIScoot(new Vector2(0f, -30f));
		}
		if (showTimer > 0f && SemiFunc.RunIsLevel())
		{
			string text3 = $"+${animatedValue}K";
			if (((TMP_Text)Text).text != text3)
			{
				((TMP_Text)Text).text = text3;
			}
			if (((Graphic)Text).color != Color.green)
			{
				((Graphic)Text).color = Color.green;
			}
		}
	}
}
