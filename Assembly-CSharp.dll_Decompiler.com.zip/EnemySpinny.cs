using System;
using Photon.Pun;
using UnityEngine;
using UnityEngine.AI;

public class EnemySpinny : MonoBehaviour
{
	public enum State
	{
		Spawn,
		Idle,
		Roam,
		Investigate,
		PlayerNotice,
		GoToPlayer,
		Leave,
		WaitForRoulette,
		Roulette,
		RouletteEndPause,
		RouletteEnd,
		RouletteEffect,
		CloseMouth,
		Stunned,
		Despawn
	}

	public enum Colors
	{
		Red,
		Yellow,
		Green,
		White,
		Black
	}

	public State currentState;

	public readonly float[] SliceBorders = new float[9] { 22f, 67f, 90f, 112f, 157f, 202f, 247f, 292f, 337f };

	public readonly Colors[] SliceColours = new Colors[9]
	{
		Colors.Red,
		Colors.White,
		Colors.Black,
		Colors.Red,
		Colors.Green,
		Colors.Red,
		Colors.Yellow,
		Colors.Red,
		Colors.Green
	};

	public Color[] colors = new Color[9]
	{
		Color.red,
		Color.white,
		Color.black,
		Color.red,
		Color.green,
		Color.red,
		Color.yellow,
		Color.red,
		Color.green
	};

	[Header("Components")]
	public Transform spinnyWheel;

	[Space]
	public Transform[] pieces;

	[Space]
	public Transform playerLockPoint;

	public SemiLine semiLine1;

	public SemiLine semiLine2;

	[Space]
	public GameObject moneyBag;

	public GameObject surplusValuableSmall;

	public Transform moneyBagSpawnPoint;

	[Space]
	public EnemySpinnyAnim enemySpinnyAnim;

	[Header("Collision check")]
	public Transform collisionCheck;

	public Transform moneyCollisionCheck;

	[Header("Spin variables")]
	public float spinDurationSeconds = 3.8f;

	[Space]
	public Transform lineOfSightChecker;

	[Header("Lock in variables")]
	public float _torqueMultiplier = 0.5f;

	public float _followForceMultiplier = 0.5f;

	private float _grabbedTorqueMultiplier = 0.025f;

	private float _followForceGrabbedMultiplier = 0.025f;

	[HideInInspector]
	public PlayerAvatar playerTarget;

	[HideInInspector]
	public int extraSpins;

	[HideInInspector]
	public float targetAngleDegrees;

	private float stateTimer;

	private float lockPointTimer;

	private float offLockPointTimer;

	private float grabAggroTimer;

	private float minZPosition = 0.784f;

	private float maxStateTimer;

	private int minExtraSpins = 2;

	private int maxExtraSpins = 4;

	private bool stateImpulse;

	private bool reachedPoint;

	private bool jinglePlayed;

	private bool effectDone;

	private bool isColliding;

	private bool isCollidingOffset;

	private bool moneyToBeSpawned;

	private bool isCollidingMoney;

	private Vector3 agentDestination;

	private Vector3 playerLockPointOriginalPosition;

	private Enemy enemy;

	private PhotonView photonView;

	[HideInInspector]
	public ParticleScriptExplosion explosionParticle;

	private float lockLerpSpeed = 1f;

	private float lockHoldSpeed = 0.3f;

	private float lockLerp;

	private float lockResetTimer;

	private void Awake()
	{
		//IL_001f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		enemy = ((Component)this).GetComponent<Enemy>();
		photonView = ((Component)this).GetComponent<PhotonView>();
		playerLockPointOriginalPosition = playerLockPoint.localPosition;
		explosionParticle = ((Component)this).GetComponent<ParticleScriptExplosion>();
	}

	private void FixedUpdate()
	{
		if (!SemiFunc.IsMasterClientOrSingleplayer())
		{
			return;
		}
		if (currentState == State.WaitForRoulette)
		{
			if (stateTimer <= 2f && !reachedPoint)
			{
				LockInPlayer(_horizontalPull: true, _fixedUpdate: true);
			}
			else
			{
				LockInPlayer(_horizontalPull: false, _fixedUpdate: true);
			}
		}
		else if (RouletteGoingOn())
		{
			LockInPlayer(_horizontalPull: false, _fixedUpdate: true);
		}
	}

	private void Update()
	{
		//IL_00c7: Unknown result type (might be due to invalid IL or missing references)
		//IL_0154: Unknown result type (might be due to invalid IL or missing references)
		//IL_01a1: Unknown result type (might be due to invalid IL or missing references)
		//IL_01ef: Unknown result type (might be due to invalid IL or missing references)
		//IL_0224: Unknown result type (might be due to invalid IL or missing references)
		//IL_0272: Unknown result type (might be due to invalid IL or missing references)
		//IL_02bd: Unknown result type (might be due to invalid IL or missing references)
		if (RouletteGoingOn() && Object.op_Implicit((Object)(object)playerTarget) && Object.op_Implicit((Object)(object)playerTarget.tumble))
		{
			playerTarget.tumble.OverrideEnemyHurt(1f);
			if (playerTarget.isLocal)
			{
				playerTarget.physGrabber.OverrideDisableSpecialGrabPowers();
			}
			semiLine1.LineActive(((Component)playerTarget.tumble.physGrabObject.rb).transform);
			semiLine2.LineActive(((Component)playerTarget.tumble.physGrabObject.rb).transform);
			SemiFunc.PlayerEyesOverride(playerTarget, enemy.Vision.VisionTransform.position, 0.1f, ((Component)this).gameObject);
			if (playerTarget.isLocal)
			{
				OverrideTargetPlayerCameraAim(7f, 10f);
			}
			if (currentState == State.WaitForRoulette)
			{
				jinglePlayed = false;
				effectDone = false;
			}
			else if (currentState == State.RouletteEnd)
			{
				if (!jinglePlayed)
				{
					switch (GetCurrentColorbyAngle(targetAngleDegrees))
					{
					case Colors.Green:
						enemySpinnyAnim.jingleGreen.Play(enemy.CenterTransform.position);
						enemySpinnyAnim.healParticle.PlayParticles();
						break;
					case Colors.Red:
						enemySpinnyAnim.jingleRed.Play(enemy.CenterTransform.position);
						enemySpinnyAnim.hurtParticle.PlayParticles();
						break;
					case Colors.Black:
						enemySpinnyAnim.jingleBlackGlobal.Play(enemy.CenterTransform.position);
						enemySpinnyAnim.jingleBlack.Play(enemy.CenterTransform.position);
						enemySpinnyAnim.deathParticle.PlayParticles();
						break;
					case Colors.White:
						enemySpinnyAnim.jingleWhite.Play(enemy.CenterTransform.position);
						enemySpinnyAnim.fullHealParticle.PlayParticles();
						break;
					case Colors.Yellow:
						enemySpinnyAnim.jingleYellow.Play(enemy.CenterTransform.position);
						enemySpinnyAnim.moneyPrizeParticle.PlayParticles();
						break;
					}
					jinglePlayed = true;
				}
			}
			else if (currentState == State.RouletteEffect)
			{
				Colors currentColorbyAngle = GetCurrentColorbyAngle(targetAngleDegrees);
				if (!effectDone)
				{
					switch (currentColorbyAngle)
					{
					case Colors.Green:
						if (playerTarget.isLocal)
						{
							playerTarget.playerHealth.Heal(25);
						}
						else
						{
							enemySpinnyAnim.healingSmokeParticle.Play(true);
						}
						break;
					case Colors.Red:
						if (playerTarget.isLocal)
						{
							playerTarget.playerHealth.Hurt(50, savingGrace: false);
						}
						else
						{
							enemySpinnyAnim.smallhurtParticle.Play(true);
						}
						break;
					case Colors.Black:
						if (playerTarget.isLocal)
						{
							int damage = playerTarget.playerHealth.health - 1;
							playerTarget.playerHealth.Hurt(damage, savingGrace: false);
						}
						enemySpinnyAnim.lightningParticle.Play(true);
						break;
					case Colors.White:
						if (playerTarget.isLocal)
						{
							int maxHealth = playerTarget.playerHealth.maxHealth;
							playerTarget.playerHealth.HealOther(maxHealth, effect: true);
						}
						enemySpinnyAnim.fullHealSmokeParticle.Play(true);
						break;
					case Colors.Yellow:
						moneyToBeSpawned = true;
						isCollidingMoney = IsCollidingMoneyBag();
						break;
					}
					CameraShake(currentColorbyAngle);
					effectDone = true;
				}
			}
		}
		if (GameManager.Multiplayer() && !PhotonNetwork.IsMasterClient)
		{
			return;
		}
		if (currentState == State.PlayerNotice)
		{
			LerpToFaceTargetPlayer(6f);
		}
		else if (RouletteGoingOn() || currentState == State.GoToPlayer)
		{
			LerpToFaceTargetPlayer();
		}
		MovePlayerLockPoint();
		if (moneyToBeSpawned)
		{
			if (SemiFunc.PerSecond(1f, (Object)(object)this))
			{
				isCollidingMoney = IsCollidingMoneyBag();
			}
			if (!isCollidingMoney)
			{
				SpawnMoneyBag();
			}
		}
		if (grabAggroTimer > 0f)
		{
			grabAggroTimer -= Time.deltaTime;
		}
		if (enemy.CurrentState == EnemyState.Despawn)
		{
			UpdateState(State.Despawn);
		}
		else if (enemy.IsStunned())
		{
			if (Interruptable())
			{
				InterruptExplosion();
			}
			UpdateState(State.Stunned);
		}
		else if (RouletteGoingOn() && (!Object.op_Implicit((Object)(object)playerTarget) || playerTarget.isDisabled))
		{
			UpdateState(State.CloseMouth);
		}
		switch (currentState)
		{
		case State.Spawn:
			StateSpawn();
			break;
		case State.Idle:
			StateIdle();
			break;
		case State.Roam:
			StateRoam();
			break;
		case State.Investigate:
			StateInvestigate();
			break;
		case State.PlayerNotice:
			StatePlayerNotice();
			break;
		case State.GoToPlayer:
			StateGoToPlayer();
			break;
		case State.Leave:
			StateLeave();
			break;
		case State.Roulette:
			StateRoulette();
			break;
		case State.WaitForRoulette:
			StateWaitForRoulette();
			break;
		case State.RouletteEndPause:
			StateRouletteEndPause();
			break;
		case State.RouletteEnd:
			StateRouletteEnd();
			break;
		case State.RouletteEffect:
			StateRouletteEffect();
			break;
		case State.CloseMouth:
			StateCloseMouth();
			break;
		case State.Stunned:
			StateStunned();
			break;
		case State.Despawn:
			StateDespawn();
			break;
		}
	}

	private void StateSpawn()
	{
		if (stateImpulse)
		{
			stateImpulse = false;
			stateTimer = 1f;
		}
		stateTimer -= Time.deltaTime;
		if (stateTimer <= 0f)
		{
			UpdateState(State.Idle);
		}
	}

	private void StateIdle()
	{
		if (stateImpulse)
		{
			ResetNavMesh();
			stateTimer = Random.Range(2f, 4f);
			stateImpulse = false;
		}
		if (SemiFunc.EnemySpawnIdlePause())
		{
			return;
		}
		stateTimer -= Time.deltaTime;
		if (stateTimer <= 0f)
		{
			UpdateState(State.Roam);
			return;
		}
		if (enemy.IsStunned())
		{
			UpdateState(State.Stunned);
		}
		if (SemiFunc.EnemyForceLeave(enemy))
		{
			UpdateState(State.Leave);
		}
	}

	private void StateRoam()
	{
		//IL_00fa: Unknown result type (might be due to invalid IL or missing references)
		//IL_0017: Unknown result type (might be due to invalid IL or missing references)
		//IL_003a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0147: Unknown result type (might be due to invalid IL or missing references)
		//IL_014d: Unknown result type (might be due to invalid IL or missing references)
		//IL_005d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0062: Unknown result type (might be due to invalid IL or missing references)
		//IL_006c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0071: Unknown result type (might be due to invalid IL or missing references)
		//IL_0087: Unknown result type (might be due to invalid IL or missing references)
		//IL_008c: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b8: Unknown result type (might be due to invalid IL or missing references)
		if (stateImpulse)
		{
			ResetNavMesh();
			LevelPoint levelPoint = SemiFunc.LevelPointGet(((Component)this).transform.position, 5f, 15f);
			if (!Object.op_Implicit((Object)(object)levelPoint))
			{
				levelPoint = SemiFunc.LevelPointGet(((Component)this).transform.position, 0f, 999f);
			}
			NavMeshHit val = default;
			if (!Object.op_Implicit((Object)(object)levelPoint) || !NavMesh.SamplePosition(((Component)levelPoint).transform.position + Random.insideUnitSphere * 3f, ref val, 5f, -1))
			{
				UpdateState(State.Idle);
				return;
			}
			if (Physics.Raycast(val.position, Vector3.down, 5f, LayerMask.GetMask(new string[1] { "Default" })))
			{
				agentDestination = val.position;
			}
			stateTimer = 5f;
			stateImpulse = false;
			enemy.Rigidbody.notMovingTimer = 0f;
		}
		enemy.NavMeshAgent.SetDestination(agentDestination);
		JumpIfStuck();
		if (enemy.Rigidbody.notMovingTimer > 2f)
		{
			stateTimer -= Time.deltaTime;
		}
		if (stateTimer <= 0f || Vector3.Distance(((Component)this).transform.position, agentDestination) < 1f)
		{
			SemiFunc.EnemyCartJumpReset(enemy);
			UpdateState(State.Idle);
			return;
		}
		if (enemy.IsStunned())
		{
			UpdateState(State.Stunned);
		}
		if (SemiFunc.EnemyForceLeave(enemy))
		{
			UpdateState(State.Leave);
		}
	}

	private void StateInvestigate()
	{
		//IL_003b: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a7: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ad: Unknown result type (might be due to invalid IL or missing references)
		if (stateImpulse)
		{
			stateTimer = 5f;
			enemy.Rigidbody.notMovingTimer = 0f;
			stateImpulse = false;
		}
		enemy.NavMeshAgent.SetDestination(agentDestination);
		JumpIfStuck();
		enemy.NavMeshAgent.OverrideAgent(2.5f, 12f, 0.25f);
		if (enemy.Rigidbody.notMovingTimer > 2f)
		{
			stateTimer -= Time.deltaTime;
		}
		if (stateTimer <= 0f || Vector3.Distance(((Component)this).transform.position, agentDestination) < 2f)
		{
			SemiFunc.EnemyCartJumpReset(enemy);
			UpdateState(State.Idle);
			return;
		}
		if (enemy.IsStunned())
		{
			UpdateState(State.Stunned);
		}
		if (SemiFunc.EnemyForceLeave(enemy))
		{
			UpdateState(State.Leave);
		}
	}

	private void StatePlayerNotice()
	{
		if (stateImpulse)
		{
			stateTimer = 1f;
			stateImpulse = false;
		}
		enemy.NavMeshAgent.ResetPath();
		enemy.NavMeshAgent.Stop(0.1f);
		stateTimer -= Time.deltaTime;
		if (stateTimer <= 0f && !enemy.IsStunned())
		{
			enemy.NavMeshAgent.Stop(0f);
			stateTimer = 4f;
			UpdateState(State.GoToPlayer);
		}
		else if (enemy.IsStunned())
		{
			UpdateState(State.Stunned);
		}
	}

	private void StateGoToPlayer()
	{
		//IL_007b: Unknown result type (might be due to invalid IL or missing references)
		//IL_004f: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e7: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f7: Unknown result type (might be due to invalid IL or missing references)
		//IL_011b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0130: Unknown result type (might be due to invalid IL or missing references)
		//IL_0158: Unknown result type (might be due to invalid IL or missing references)
		//IL_016d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0172: Unknown result type (might be due to invalid IL or missing references)
		if (!Object.op_Implicit((Object)(object)playerTarget))
		{
			UpdateState(State.Idle);
			return;
		}
		if (stateImpulse)
		{
			stateImpulse = false;
			enemy.Rigidbody.notMovingTimer = 0f;
			enemy.NavMeshAgent.SetDestination(((Component)playerTarget).transform.position);
			maxStateTimer = 7f;
			return;
		}
		enemy.NavMeshAgent.SetDestination(((Component)playerTarget).transform.position);
		if (CloseToPlayerTarget() && !enemy.IsStunned() && PlayerTargetInSight())
		{
			enemy.NavMeshAgent.ResetPath();
			GetAndSyncRandomRotation();
			SemiFunc.EnemyCartJumpReset(enemy);
			UpdateState(State.WaitForRoulette);
			return;
		}
		JumpIfStuck();
		if (Vector3.Distance(((Component)enemy.Rigidbody).transform.position, enemy.NavMeshAgent.GetDestination()) < 1f && ((Component)enemy.Rigidbody).transform.position.y - ((Component)playerTarget).transform.position.y < -0.5f)
		{
			enemy.Jump.StuckTrigger(((Component)playerTarget).transform.position - ((Component)enemy.Rigidbody).transform.position);
			enemy.Rigidbody.DisableFollowPosition(1f, 10f);
		}
		enemy.NavMeshAgent.OverrideAgent(4f, 10f, 0.25f);
		stateTimer -= Time.deltaTime;
		maxStateTimer -= Time.deltaTime;
		if (stateTimer <= 0f || maxStateTimer <= 0f)
		{
			SemiFunc.EnemyCartJumpReset(enemy);
			UpdateState(State.Idle);
		}
	}

	private void StateWaitForRoulette()
	{
		//IL_00ae: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b9: Unknown result type (might be due to invalid IL or missing references)
		float num = 1.5f;
		if (stateImpulse)
		{
			stateTimer = 5f;
			lockPointTimer = 2f;
			offLockPointTimer = 0f;
			reachedPoint = false;
			stateImpulse = false;
		}
		stateTimer -= Time.deltaTime;
		if (stateTimer <= 2f && !reachedPoint)
		{
			LockInPlayer(_horizontalPull: true);
		}
		else
		{
			LockInPlayer();
		}
		if (!Object.op_Implicit((Object)(object)playerTarget) || !Object.op_Implicit((Object)(object)playerTarget.tumble))
		{
			UpdateState(State.CloseMouth);
			return;
		}
		if (Vector3.Distance(playerTarget.tumble.rb.position, playerLockPoint.position) < 1f)
		{
			reachedPoint = true;
			offLockPointTimer = 0f;
			lockPointTimer -= Time.deltaTime;
			if (lockPointTimer <= 0f)
			{
				if (HasLineOfSight())
				{
					UpdateState(State.Roulette);
				}
				else
				{
					UpdateState(State.CloseMouth);
				}
				return;
			}
		}
		else if (reachedPoint)
		{
			offLockPointTimer += Time.deltaTime;
			lockPointTimer = 3f;
		}
		if (enemy.Rigidbody.physGrabObject.grabbed && enemySpinnyAnim.mouthOpened)
		{
			UpdateState(State.Roulette);
		}
		else if (stateTimer <= 0f && !reachedPoint)
		{
			UpdateState(State.CloseMouth);
		}
		else if (enemy.IsStunned() || offLockPointTimer > num)
		{
			UpdateState(State.CloseMouth);
		}
	}

	private void StateRoulette()
	{
		LockInPlayer();
		if (stateImpulse)
		{
			stateTimer = spinDurationSeconds;
			stateImpulse = false;
		}
		stateTimer -= Time.deltaTime;
		if (stateTimer < 0f)
		{
			UpdateState(State.RouletteEndPause);
		}
	}

	private void StateRouletteEndPause()
	{
		LockInPlayer();
		if (stateImpulse)
		{
			stateTimer = 1.5f;
			stateImpulse = false;
		}
		stateTimer -= Time.deltaTime;
		if (stateTimer < 0f)
		{
			UpdateState(State.RouletteEnd);
		}
	}

	private void StateRouletteEnd()
	{
		LockInPlayer();
		if (stateImpulse)
		{
			stateTimer = 0.5f;
			stateImpulse = false;
		}
		stateTimer -= Time.deltaTime;
		if (stateTimer < 0f)
		{
			UpdateState(State.RouletteEffect);
		}
	}

	private void StateRouletteEffect()
	{
		if (stateImpulse)
		{
			stateTimer = 1f;
			stateImpulse = false;
		}
		stateTimer -= Time.deltaTime;
		LockInPlayer();
		if (stateTimer <= 0f)
		{
			UpdateState(State.CloseMouth);
		}
	}

	private void StateCloseMouth()
	{
		if (stateImpulse)
		{
			stateTimer = 1.5f;
			stateImpulse = false;
		}
		stateTimer -= Time.deltaTime;
		if (stateTimer < 0f)
		{
			UpdateState(State.Leave);
		}
	}

	private void StateLeave()
	{
		//IL_00ed: Unknown result type (might be due to invalid IL or missing references)
		//IL_0011: Unknown result type (might be due to invalid IL or missing references)
		//IL_0035: Unknown result type (might be due to invalid IL or missing references)
		//IL_0159: Unknown result type (might be due to invalid IL or missing references)
		//IL_015f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0066: Unknown result type (might be due to invalid IL or missing references)
		//IL_0054: Unknown result type (might be due to invalid IL or missing references)
		//IL_0059: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a5: Unknown result type (might be due to invalid IL or missing references)
		//IL_00aa: Unknown result type (might be due to invalid IL or missing references)
		//IL_0089: Unknown result type (might be due to invalid IL or missing references)
		if (stateImpulse)
		{
			LevelPoint levelPoint = SemiFunc.LevelPointGetPlayerDistance(((Component)this).transform.position, 25f, 50f);
			if (!Object.op_Implicit((Object)(object)levelPoint))
			{
				levelPoint = SemiFunc.LevelPointGetFurthestFromPlayer(((Component)this).transform.position, 5f);
			}
			if (Object.op_Implicit((Object)(object)levelPoint))
			{
				agentDestination = ((Component)levelPoint).transform.position;
			}
			else
			{
				levelPoint = SemiFunc.LevelPointGet(((Component)this).transform.position, 20f, 999f);
				if (!Object.op_Implicit((Object)(object)levelPoint))
				{
					levelPoint = SemiFunc.LevelPointGet(((Component)this).transform.position, 0f, 999f);
				}
				agentDestination = ((Component)levelPoint).transform.position;
			}
			stateTimer = 10f;
			stateImpulse = false;
			SemiFunc.EnemyLeaveStart(enemy);
			enemy.Rigidbody.notMovingTimer = 0f;
		}
		enemy.NavMeshAgent.SetDestination(agentDestination);
		JumpIfStuck();
		if (enemy.Rigidbody.notMovingTimer > 2f)
		{
			stateTimer -= Time.deltaTime;
		}
		enemy.NavMeshAgent.OverrideAgent(6f, 12f, 0.25f);
		if (stateTimer <= 0f || Vector3.Distance(((Component)this).transform.position, agentDestination) < 1f)
		{
			UpdateState(State.Idle);
		}
	}

	private void StateStunned()
	{
		if (stateImpulse)
		{
			stateImpulse = false;
			ResetNavMesh();
		}
		if (!enemy.IsStunned())
		{
			UpdateState(State.Idle);
		}
	}

	private void StateDespawn()
	{
		if (stateImpulse)
		{
			stateImpulse = false;
			ResetNavMesh();
		}
	}

	private bool Interruptable()
	{
		if (currentState != State.Roulette && currentState != State.RouletteEnd && currentState != State.RouletteEndPause)
		{
			return currentState == State.RouletteEffect;
		}
		return true;
	}

	private void LockInPlayer(bool _horizontalPull = false, bool _fixedUpdate = false)
	{
		//IL_0097: Unknown result type (might be due to invalid IL or missing references)
		//IL_009c: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a8: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a9: Unknown result type (might be due to invalid IL or missing references)
		//IL_00aa: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ab: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b0: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b4: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b9: Unknown result type (might be due to invalid IL or missing references)
		//IL_00cf: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d6: Unknown result type (might be due to invalid IL or missing references)
		//IL_00db: Unknown result type (might be due to invalid IL or missing references)
		//IL_00dd: Unknown result type (might be due to invalid IL or missing references)
		//IL_00de: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e0: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ea: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ef: Unknown result type (might be due to invalid IL or missing references)
		//IL_011d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0122: Unknown result type (might be due to invalid IL or missing references)
		//IL_012a: Unknown result type (might be due to invalid IL or missing references)
		//IL_012f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0131: Unknown result type (might be due to invalid IL or missing references)
		//IL_0136: Unknown result type (might be due to invalid IL or missing references)
		//IL_013e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0143: Unknown result type (might be due to invalid IL or missing references)
		//IL_0145: Unknown result type (might be due to invalid IL or missing references)
		//IL_0146: Unknown result type (might be due to invalid IL or missing references)
		//IL_020e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0213: Unknown result type (might be due to invalid IL or missing references)
		//IL_01c5: Unknown result type (might be due to invalid IL or missing references)
		//IL_01cd: Unknown result type (might be due to invalid IL or missing references)
		//IL_01d8: Unknown result type (might be due to invalid IL or missing references)
		//IL_01e4: Unknown result type (might be due to invalid IL or missing references)
		//IL_01ec: Unknown result type (might be due to invalid IL or missing references)
		//IL_018d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0195: Unknown result type (might be due to invalid IL or missing references)
		//IL_01a0: Unknown result type (might be due to invalid IL or missing references)
		//IL_01ac: Unknown result type (might be due to invalid IL or missing references)
		//IL_01b4: Unknown result type (might be due to invalid IL or missing references)
		//IL_0221: Unknown result type (might be due to invalid IL or missing references)
		//IL_022c: Unknown result type (might be due to invalid IL or missing references)
		//IL_02ca: Unknown result type (might be due to invalid IL or missing references)
		//IL_02d4: Unknown result type (might be due to invalid IL or missing references)
		//IL_02e0: Unknown result type (might be due to invalid IL or missing references)
		//IL_02ea: Unknown result type (might be due to invalid IL or missing references)
		if (!Object.op_Implicit((Object)(object)playerTarget) || !Object.op_Implicit((Object)(object)playerTarget.tumble))
		{
			return;
		}
		if (!playerTarget.isTumbling)
		{
			playerTarget.tumble.TumbleRequest(_isTumbling: true, _playerInput: false);
			lockLerp = 0f;
			lockResetTimer = 0f;
			return;
		}
		playerTarget.tumble.TumbleOverrideTime(1f);
		((Component)playerTarget.tumble).GetComponent<PhysGrabObject>().OverrideZeroGravity();
		Rigidbody rb = playerTarget.tumble.rb;
		Vector3 position = rb.position;
		Vector3 position2 = playerLockPoint.position;
		Vector3 val = position2 - position;
		Vector3 normalized = val.normalized;
		if (_horizontalPull)
		{
			normalized.y = 0f;
		}
		Vector3 val2 = SemiFunc.PhysFollowDirection(((Component)rb).transform, normalized, rb, 10f);
		Vector3 val3 = SemiFunc.PhysFollowPosition(position, position2, rb.linearVelocity, 5f);
		float num = (_fixedUpdate ? Time.fixedDeltaTime : Time.deltaTime);
		lockLerp = Mathf.Clamp01(lockLerp + lockLerpSpeed * num);
		Vector3 val4 = Vector3.Lerp(Vector3.zero, val3, lockLerp);
		Vector3 val5 = Vector3.Lerp(Vector3.zero, val2, lockLerp);
		bool flag = Vector3.Distance(position, position2) > 0.2f || ((playerTarget.rbVelocity.magnitude > lockHoldSpeed) & _fixedUpdate);
		if (_fixedUpdate && !playerTarget.tumble.physGrabObject.grabbed)
		{
			rb.AddTorque(val5 / rb.mass * _torqueMultiplier, (ForceMode)0);
			rb.AddForce(val4 * _followForceMultiplier, (ForceMode)1);
		}
		else if (_fixedUpdate)
		{
			rb.AddTorque(val5 / rb.mass * _grabbedTorqueMultiplier, (ForceMode)0);
			rb.AddForce(val4 * _followForceGrabbedMultiplier, (ForceMode)1);
			lockLerp = 0f;
			lockResetTimer = 0f;
		}
		bool flag2 = Vector3.Distance(rb.position, position2) > 0.1f || Quaternion.Angle(rb.rotation, playerLockPoint.rotation) > 1f;
		if ((lockLerp >= 1f) & flag2)
		{
			lockResetTimer += Time.fixedDeltaTime;
			if (lockResetTimer > 3f)
			{
				lockResetTimer = 0f;
				lockLerp = 0f;
			}
		}
		else
		{
			lockResetTimer = 0f;
		}
		if (playerTarget.tumble.physGrabObject.playerGrabbing.Count <= 0 || currentState != State.WaitForRoulette)
		{
			if (!flag & _fixedUpdate)
			{
				rb.linearVelocity *= 0.98f;
				rb.angularVelocity *= 0.98f;
			}
			playerTarget.tumble.physGrabObject.OverrideGrabForceZero();
		}
	}

	private Collider[] GetCollidingColliders(float _zOffset = 0f)
	{
		//IL_0006: Unknown result type (might be due to invalid IL or missing references)
		//IL_000b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0018: Unknown result type (might be due to invalid IL or missing references)
		//IL_001f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0029: Unknown result type (might be due to invalid IL or missing references)
		//IL_0034: Unknown result type (might be due to invalid IL or missing references)
		Vector3 position = collisionCheck.position;
		position.z += _zOffset;
		return Physics.OverlapBox(position, collisionCheck.lossyScale / 2f, collisionCheck.rotation);
	}

	private Collider[] GetCollidingCollidersMoneyBag()
	{
		//IL_0006: Unknown result type (might be due to invalid IL or missing references)
		//IL_0011: Unknown result type (might be due to invalid IL or missing references)
		//IL_001b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0026: Unknown result type (might be due to invalid IL or missing references)
		return Physics.OverlapBox(moneyCollisionCheck.position, moneyCollisionCheck.lossyScale / 2f, moneyCollisionCheck.rotation);
	}

	private bool IsColliding(float _zOffset = 0f)
	{
		Collider[] collidingColliders = GetCollidingColliders(_zOffset);
		foreach (Collider val in collidingColliders)
		{
			if (((Component)val).gameObject.layer != LayerMask.NameToLayer("RoomVolume") && !((Component)val).transform.IsChildOf(((Component)this).transform) && ((Component)val).gameObject.layer != LayerMask.NameToLayer("CollisionCheck") && ((Component)val).gameObject.layer != LayerMask.NameToLayer("Triggers") && ((Component)val).gameObject.layer != LayerMask.NameToLayer("PlayerVisuals") && !HasParentWithTag(((Component)val).transform, "Player"))
			{
				return true;
			}
		}
		return false;
	}

	private bool IsCollidingMoneyBag()
	{
		Collider[] collidingCollidersMoneyBag = GetCollidingCollidersMoneyBag();
		foreach (Collider val in collidingCollidersMoneyBag)
		{
			if (((Component)val).gameObject.layer != LayerMask.NameToLayer("RoomVolume") && ((Component)val).gameObject.layer != LayerMask.NameToLayer("Triggers"))
			{
				return true;
			}
		}
		return false;
	}

	private void LerpToFaceTargetPlayer(float _speed = 3f)
	{
		//IL_0019: Unknown result type (might be due to invalid IL or missing references)
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_0029: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Unknown result type (might be due to invalid IL or missing references)
		//IL_003b: Unknown result type (might be due to invalid IL or missing references)
		//IL_003c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0041: Unknown result type (might be due to invalid IL or missing references)
		//IL_004e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0053: Unknown result type (might be due to invalid IL or missing references)
		//IL_005b: Unknown result type (might be due to invalid IL or missing references)
		if (Object.op_Implicit((Object)(object)playerTarget))
		{
			Vector3 val = ((Component)playerTarget).transform.position - ((Component)this).transform.position;
			val.y = 0f;
			Quaternion val2 = Quaternion.LookRotation(val);
			((Component)this).transform.rotation = Quaternion.Slerp(((Component)this).transform.rotation, val2, Time.deltaTime * _speed);
		}
	}

	private void OverrideTargetPlayerCameraAim(float _strenght = 3f, float _strenghtNoAim = 1.5f)
	{
		//IL_000b: Unknown result type (might be due to invalid IL or missing references)
		CameraAim.Instance.AimTargetSoftSet(spinnyWheel.position, 0.1f, _strenght, _strenghtNoAim, ((Component)this).gameObject, 100);
	}

	public float GetRotation360()
	{
		//IL_0006: Unknown result type (might be due to invalid IL or missing references)
		float num = spinnyWheel.localEulerAngles.z;
		if (num < 0f)
		{
			num += 360f;
		}
		if (num >= 360f)
		{
			num -= 360f;
		}
		return num;
	}

	private void MovePlayerLockPoint(float _lerpSpeed = 0.1f)
	{
		//IL_0046: Unknown result type (might be due to invalid IL or missing references)
		//IL_004b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0052: Unknown result type (might be due to invalid IL or missing references)
		//IL_0057: Unknown result type (might be due to invalid IL or missing references)
		//IL_006b: Unknown result type (might be due to invalid IL or missing references)
		//IL_006c: Unknown result type (might be due to invalid IL or missing references)
		//IL_006e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0087: Unknown result type (might be due to invalid IL or missing references)
		//IL_008c: Unknown result type (might be due to invalid IL or missing references)
		//IL_008e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0093: Unknown result type (might be due to invalid IL or missing references)
		//IL_009a: Unknown result type (might be due to invalid IL or missing references)
		//IL_009b: Unknown result type (might be due to invalid IL or missing references)
		//IL_009d: Unknown result type (might be due to invalid IL or missing references)
		if (SemiFunc.PerSecond(1f, (Object)(object)this))
		{
			isColliding = IsColliding();
			isCollidingOffset = IsColliding(0.1f);
		}
		if (!Interruptable())
		{
			if (isColliding)
			{
				Vector3 localPosition = playerLockPoint.localPosition;
				Vector3 localPosition2 = playerLockPoint.localPosition;
				localPosition2.z = minZPosition;
				playerLockPoint.localPosition = Vector3.Lerp(localPosition, localPosition2, _lerpSpeed);
			}
			else if (!isCollidingOffset)
			{
				Vector3 localPosition3 = playerLockPoint.localPosition;
				Vector3 val = playerLockPointOriginalPosition;
				playerLockPoint.localPosition = Vector3.Lerp(localPosition3, val, _lerpSpeed);
			}
		}
	}

	public bool RouletteGoingOn()
	{
		if (currentState != State.WaitForRoulette && currentState != State.Roulette && currentState != State.RouletteEndPause && currentState != State.RouletteEnd)
		{
			return currentState == State.RouletteEffect;
		}
		return true;
	}

	private void CameraShake(Colors _color)
	{
		//IL_006a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0094: Unknown result type (might be due to invalid IL or missing references)
		if (!Object.op_Implicit((Object)(object)playerTarget) || !playerTarget.isLocal || (_color != Colors.Red && _color != Colors.Black))
		{
			float strength = 2f;
			float strength2 = 2f;
			switch (_color)
			{
			case Colors.Black:
				strength = 8f;
				strength2 = 10f;
				break;
			case Colors.Red:
				strength = 5f;
				strength2 = 5f;
				break;
			}
			GameDirector.instance.CameraShake.ShakeDistance(strength, 3f, 8f, ((Component)this).transform.position, 0.5f);
			GameDirector.instance.CameraImpact.ShakeDistance(strength2, 3f, 8f, ((Component)this).transform.position, 0.1f);
		}
	}

	private void ResetNavMesh()
	{
		//IL_002b: Unknown result type (might be due to invalid IL or missing references)
		enemy.NavMeshAgent.ResetPath();
		enemy.NavMeshAgent.Warp(((Component)enemy.Rigidbody).transform.position);
	}

	private void JumpIfStuck(bool _cartJump = true)
	{
		//IL_0019: Unknown result type (might be due to invalid IL or missing references)
		//IL_001e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0060: Unknown result type (might be due to invalid IL or missing references)
		//IL_0071: Unknown result type (might be due to invalid IL or missing references)
		//IL_0076: Unknown result type (might be due to invalid IL or missing references)
		if (_cartJump)
		{
			SemiFunc.EnemyCartJump(enemy);
		}
		Vector3 destination = enemy.NavMeshAgent.GetDestination();
		if (!enemy.Jump.jumping && !enemy.IsStunned() && enemy.Rigidbody.notMovingTimer > 2f)
		{
			enemy.Jump.StuckTrigger(destination - ((Component)enemy.Rigidbody).transform.position);
		}
	}

	private bool HasLineOfSight()
	{
		//IL_0006: Unknown result type (might be due to invalid IL or missing references)
		return SemiFunc.PlayerVisionCheck(lineOfSightChecker.position, 10f, playerTarget, _previouslySeen: false);
	}

	private bool CloseToPlayerTarget(float _treshold = 1.5f)
	{
		//IL_0010: Unknown result type (might be due to invalid IL or missing references)
		//IL_0020: Unknown result type (might be due to invalid IL or missing references)
		return Vector3.Distance(((Component)enemy.Rigidbody).transform.position, ((Component)playerTarget).transform.position) < _treshold;
	}

	private bool PlayerTargetInSight()
	{
		return enemy.Vision.VisionsTriggered[playerTarget.photonView.ViewID] != 0;
	}

	private bool HasParentWithTag(Transform _transform, string _tag)
	{
		Transform parent = _transform.parent;
		while ((Object)(object)parent != (Object)null)
		{
			if (((Component)parent).CompareTag(_tag))
			{
				return true;
			}
			parent = parent.parent;
		}
		return false;
	}

	private void SpawnMoneyBag()
	{
		//IL_004e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0053: Unknown result type (might be due to invalid IL or missing references)
		//IL_0026: Unknown result type (might be due to invalid IL or missing references)
		//IL_002b: Unknown result type (might be due to invalid IL or missing references)
		MoneyEffect();
		moneyToBeSpawned = false;
		GameObject val = AssetManager.instance.surplusValuableSmall;
		GameObject val2 = (SemiFunc.IsMultiplayer() ? PhotonNetwork.InstantiateRoomObject("Valuables/" + ((Object)val).name, moneyBagSpawnPoint.position, Quaternion.identity, (byte)0, (object[])null) : Object.Instantiate<GameObject>(val, moneyBagSpawnPoint.position, Quaternion.identity));
		if (Object.op_Implicit((Object)(object)val2))
		{
			val2.GetComponent<ValuableObject>().dollarValueOverride = 5000;
		}
	}

	public Color GetCurrentColorColor(float _angle = -1f)
	{
		//IL_0000: Unknown result type (might be due to invalid IL or missing references)
		//IL_0005: Unknown result type (might be due to invalid IL or missing references)
		//IL_004b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0050: Unknown result type (might be due to invalid IL or missing references)
		//IL_0053: Unknown result type (might be due to invalid IL or missing references)
		//IL_0058: Unknown result type (might be due to invalid IL or missing references)
		//IL_005b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0060: Unknown result type (might be due to invalid IL or missing references)
		//IL_003b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0040: Unknown result type (might be due to invalid IL or missing references)
		//IL_0043: Unknown result type (might be due to invalid IL or missing references)
		//IL_0048: Unknown result type (might be due to invalid IL or missing references)
		//IL_0061: Unknown result type (might be due to invalid IL or missing references)
		Color result = Color.blue;
		switch ((_angle != -1f) ? GetCurrentColorbyAngle(_angle) : GetCurrentColor())
		{
		case Colors.White:
			result = Color.white;
			break;
		case Colors.Black:
			result = Color.black;
			break;
		case Colors.Red:
			result = Color.red;
			break;
		case Colors.Yellow:
			result = Color.yellow;
			break;
		case Colors.Green:
			result = Color.green;
			break;
		}
		return result;
	}

	public Colors GetCurrentColor()
	{
		return GetSliceAndColour(GetRotation360()).colour;
	}

	public Colors GetCurrentColorbyAngle(float _angle)
	{
		return GetSliceAndColour(_angle).colour;
	}

	public (int sliceIndex, Colors colour) GetSliceAndColour(float zAngle360)
	{
		zAngle360 = Mathf.Repeat(zAngle360, 360f);
		int i = 0;
		if (zAngle360 < 22f)
		{
			return (sliceIndex: 8, colour: SliceColours[8]);
		}
		for (; i < SliceBorders.Length - 1 && zAngle360 >= SliceBorders[i + 1]; i++)
		{
		}
		return (sliceIndex: i, colour: SliceColours[i]);
	}

	private void InterruptExplosion()
	{
		//IL_0012: Unknown result type (might be due to invalid IL or missing references)
		//IL_0018: Unknown result type (might be due to invalid IL or missing references)
		if (SemiFunc.IsMasterClientOrSingleplayer())
		{
			if (!SemiFunc.IsMultiplayer())
			{
				InterruptExplosionRPC();
			}
			else
			{
				photonView.RPC("InterruptExplosionRPC", (RpcTarget)0, Array.Empty<object>());
			}
		}
	}

	[PunRPC]
	private void InterruptExplosionRPC(PhotonMessageInfo _info = default(PhotonMessageInfo))
	{
		//IL_0000: Unknown result type (might be due to invalid IL or missing references)
		//IL_0015: Unknown result type (might be due to invalid IL or missing references)
		//IL_005a: Unknown result type (might be due to invalid IL or missing references)
		if (SemiFunc.MasterOnlyRPC(_info))
		{
			explosionParticle.Spawn(spinnyWheel.position, 1.3f, 60, 0);
			enemySpinnyAnim.interruptParticle.PlayParticles();
			enemySpinnyAnim.interruptionSound.Play(((Component)this).transform.position);
		}
	}

	private void MoneyEffect()
	{
		//IL_0012: Unknown result type (might be due to invalid IL or missing references)
		//IL_0018: Unknown result type (might be due to invalid IL or missing references)
		if (SemiFunc.IsMasterClientOrSingleplayer())
		{
			if (!SemiFunc.IsMultiplayer())
			{
				MoneyEffectRPC();
			}
			else
			{
				photonView.RPC("MoneyEffectRPC", (RpcTarget)0, Array.Empty<object>());
			}
		}
	}

	[PunRPC]
	private void MoneyEffectRPC(PhotonMessageInfo _info = default(PhotonMessageInfo))
	{
		//IL_0000: Unknown result type (might be due to invalid IL or missing references)
		if (SemiFunc.MasterOnlyRPC(_info))
		{
			enemySpinnyAnim.moneyParticle.Play(true);
		}
	}

	private void GetAndSyncRandomRotation()
	{
		//IL_0038: Unknown result type (might be due to invalid IL or missing references)
		//IL_003e: Unknown result type (might be due to invalid IL or missing references)
		if (SemiFunc.IsMasterClientOrSingleplayer())
		{
			int num = Random.Range(minExtraSpins, maxExtraSpins + 1);
			float num2 = Random.Range(0f, 360f);
			if (!SemiFunc.IsMultiplayer())
			{
				GetAndSyncRandomRotationRPC(num, num2);
				return;
			}
			photonView.RPC("GetAndSyncRandomRotationRPC", (RpcTarget)0, new object[2] { num, num2 });
		}
	}

	[PunRPC]
	private void GetAndSyncRandomRotationRPC(int _extraSpins, float _targetAngleDegrees, PhotonMessageInfo _info = default(PhotonMessageInfo))
	{
		//IL_0000: Unknown result type (might be due to invalid IL or missing references)
		if (SemiFunc.MasterOnlyRPC(_info))
		{
			extraSpins = _extraSpins;
			targetAngleDegrees = _targetAngleDegrees;
		}
	}

	private void UpdateState(State _nextState)
	{
		if (SemiFunc.IsMasterClientOrSingleplayer() && _nextState != currentState)
		{
			stateImpulse = true;
			currentState = _nextState;
			if (GameManager.Multiplayer())
			{
				photonView.RPC("UpdateStateRPC", (RpcTarget)1, new object[1] { _nextState });
			}
		}
	}

	[PunRPC]
	private void UpdateStateRPC(State _nextState, PhotonMessageInfo _info = default(PhotonMessageInfo))
	{
		//IL_0000: Unknown result type (might be due to invalid IL or missing references)
		if (SemiFunc.MasterOnlyRPC(_info))
		{
			currentState = _nextState;
		}
	}

	private void UpdatePlayerTarget(int photonViewID)
	{
		//IL_0013: Unknown result type (might be due to invalid IL or missing references)
		//IL_0019: Unknown result type (might be due to invalid IL or missing references)
		if (SemiFunc.IsMasterClientOrSingleplayer())
		{
			if (!SemiFunc.IsMultiplayer())
			{
				UpdatePlayerTargetRPC(photonViewID);
				return;
			}
			photonView.RPC("UpdatePlayerTargetRPC", (RpcTarget)0, new object[1] { photonViewID });
		}
	}

	[PunRPC]
	private void UpdatePlayerTargetRPC(int photonViewID, PhotonMessageInfo _info = default(PhotonMessageInfo))
	{
		//IL_0000: Unknown result type (might be due to invalid IL or missing references)
		if (SemiFunc.MasterOnlyRPC(_info))
		{
			playerTarget = SemiFunc.PlayerAvatarGetFromPhotonID(photonViewID);
		}
	}

	public void OnSpawn()
	{
		if (SemiFunc.IsMasterClientOrSingleplayer() && SemiFunc.EnemySpawn(enemy))
		{
			UpdateState(State.Spawn);
		}
		if (((Behaviour)enemySpinnyAnim).isActiveAndEnabled)
		{
			enemySpinnyAnim.SetSpawn();
		}
	}

	public void OnHurt()
	{
		if (SemiFunc.IsMasterClientOrSingleplayer() && currentState == State.Leave)
		{
			UpdateState(State.Idle);
		}
		enemySpinnyAnim.HurtSound();
	}

	public void OnDeath()
	{
		//IL_001c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0091: Unknown result type (might be due to invalid IL or missing references)
		//IL_00bf: Unknown result type (might be due to invalid IL or missing references)
		enemySpinnyAnim.DeathSound();
		enemySpinnyAnim.deathJingleSound.Play(((Component)this).transform.position);
		enemySpinnyAnim.PlayDeathParticles();
		enemySpinnyAnim.animator.SetBool("close_mouth_bool", true);
		enemySpinnyAnim.animator.SetBool("open_mouth_bool", false);
		GameDirector.instance.CameraShake.ShakeDistance(5f, 3f, 8f, ((Component)this).transform.position, 0.5f);
		GameDirector.instance.CameraImpact.ShakeDistance(5f, 3f, 8f, ((Component)this).transform.position, 0.1f);
		if (SemiFunc.IsMasterClientOrSingleplayer())
		{
			enemy.EnemyParent.Despawn();
		}
	}

	public void OnVision()
	{
		if (currentState == State.GoToPlayer)
		{
			stateTimer = 4f;
		}
		else if (currentState == State.Idle || currentState == State.Roam || currentState == State.Investigate)
		{
			playerTarget = enemy.Vision.onVisionTriggeredPlayer;
			if (SemiFunc.IsMultiplayer())
			{
				UpdatePlayerTarget(playerTarget.photonView.ViewID);
			}
			SemiFunc.EnemyCartJumpReset(enemy);
			UpdateState(State.PlayerNotice);
		}
	}

	public void OnInvestigate()
	{
		//IL_002e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0033: Unknown result type (might be due to invalid IL or missing references)
		if (currentState == State.Roam || currentState == State.Idle || currentState == State.Investigate)
		{
			UpdateState(State.Investigate);
			agentDestination = enemy.StateInvestigate.onInvestigateTriggeredPosition;
		}
	}

	public void OnGrabbed()
	{
		if (SemiFunc.IsMasterClientOrSingleplayer() && !(grabAggroTimer > 0f) && currentState == State.Leave)
		{
			grabAggroTimer = 60f;
			playerTarget = enemy.Rigidbody.onGrabbedPlayerAvatar;
			if (SemiFunc.IsMultiplayer())
			{
				UpdatePlayerTarget(playerTarget.photonView.ViewID);
			}
			UpdateState(State.PlayerNotice);
		}
	}

	public EnemySpinny()
	{
		//IL_003a: Unknown result type (might be due to invalid IL or missing references)
		//IL_003f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0046: Unknown result type (might be due to invalid IL or missing references)
		//IL_004b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0052: Unknown result type (might be due to invalid IL or missing references)
		//IL_0057: Unknown result type (might be due to invalid IL or missing references)
		//IL_005e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0063: Unknown result type (might be due to invalid IL or missing references)
		//IL_006a: Unknown result type (might be due to invalid IL or missing references)
		//IL_006f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0076: Unknown result type (might be due to invalid IL or missing references)
		//IL_007b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0082: Unknown result type (might be due to invalid IL or missing references)
		//IL_0087: Unknown result type (might be due to invalid IL or missing references)
		//IL_008e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0093: Unknown result type (might be due to invalid IL or missing references)
		//IL_009a: Unknown result type (might be due to invalid IL or missing references)
		//IL_009f: Unknown result type (might be due to invalid IL or missing references)
	}
}
