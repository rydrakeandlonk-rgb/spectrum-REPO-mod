using System;
using System.Collections.Generic;
using Photon.Pun;
using UnityEngine;

public class StaticGrabObject : MonoBehaviour
{
	internal PhotonView photonView;

	public Transform colliderTransform;

	public Transform uiPosition;

	public string hoverText;

	[HideInInspector]
	public Vector3 velocity;

	[HideInInspector]
	public bool grabbed;

	public List<PhysGrabber> playerGrabbing = new List<PhysGrabber>();

	[HideInInspector]
	public bool dead;

	private void Start()
	{
		photonView = ((Component)this).GetComponent<PhotonView>();
		if (GameManager.instance.gameMode == 1 && PhotonNetwork.IsMasterClient)
		{
			photonView.TransferOwnership(PhotonNetwork.MasterClient);
		}
	}

	private void Update()
	{
		//IL_004c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0051: Unknown result type (might be due to invalid IL or missing references)
		//IL_0082: Unknown result type (might be due to invalid IL or missing references)
		//IL_008d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0092: Unknown result type (might be due to invalid IL or missing references)
		//IL_009c: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a1: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a4: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a9: Unknown result type (might be due to invalid IL or missing references)
		//IL_00af: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b4: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b9: Unknown result type (might be due to invalid IL or missing references)
		if (grabbed)
		{
			for (int i = 0; i < playerGrabbing.Count; i++)
			{
				if (!Object.op_Implicit((Object)(object)playerGrabbing[i]))
				{
					playerGrabbing.RemoveAt(i);
					i--;
				}
			}
		}
		if (!SemiFunc.IsMasterClientOrSingleplayer())
		{
			return;
		}
		velocity = Vector3.zero;
		foreach (PhysGrabber item in playerGrabbing)
		{
			if (Object.op_Implicit((Object)(object)item) && Object.op_Implicit((Object)(object)item.physGrabPoint))
			{
				Vector3 val = (item.physGrabPointPullerPosition - item.physGrabPoint.position) * 5f;
				velocity += val * Time.deltaTime;
			}
		}
		if (dead && playerGrabbing.Count == 0)
		{
			DestroyPhysGrabObject();
		}
	}

	private void OnDisable()
	{
		playerGrabbing.Clear();
		grabbed = false;
	}

	public void GrabLink(int playerPhotonID, Vector3 point, int _grabRevision)
	{
		//IL_001d: Unknown result type (might be due to invalid IL or missing references)
		photonView.RPC("GrabLinkRPC", (RpcTarget)0, new object[3] { playerPhotonID, point, _grabRevision });
	}

	[PunRPC]
	private void GrabLinkRPC(int playerPhotonID, Vector3 point, int _grabRevision, PhotonMessageInfo _info = default(PhotonMessageInfo))
	{
		//IL_001b: Unknown result type (might be due to invalid IL or missing references)
		//IL_003d: Unknown result type (might be due to invalid IL or missing references)
		//IL_004a: Unknown result type (might be due to invalid IL or missing references)
		//IL_004b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0050: Unknown result type (might be due to invalid IL or missing references)
		//IL_007b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0080: Unknown result type (might be due to invalid IL or missing references)
		//IL_009e: Unknown result type (might be due to invalid IL or missing references)
		PhotonView val = PhotonView.Find(playerPhotonID);
		PhysGrabber physGrabber = ((val != null) ? ((Component)val).GetComponent<PhysGrabber>() : null);
		if (Object.op_Implicit((Object)(object)physGrabber) && SemiFunc.MasterAndOwnerOnlyRPC(_info, physGrabber.photonView) && _grabRevision > 0)
		{
			physGrabber.grabRevision = _grabRevision;
			physGrabber.physGrabPoint.position = point;
			physGrabber.localGrabPosition = colliderTransform.InverseTransformPoint(point);
			physGrabber.grabbedObjectTransform = colliderTransform;
			physGrabber.grabbed = true;
			if (physGrabber.photonView.IsMine)
			{
				Vector3 localPosition = physGrabber.physGrabPoint.localPosition;
				photonView.RPC("GrabPointSyncRPC", (RpcTarget)2, new object[2] { playerPhotonID, localPosition });
			}
		}
	}

	[PunRPC]
	private void GrabPointSyncRPC(int playerPhotonID, Vector3 localPointInBox, PhotonMessageInfo _info = default(PhotonMessageInfo))
	{
		//IL_001b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0030: Unknown result type (might be due to invalid IL or missing references)
		PhotonView val = PhotonView.Find(playerPhotonID);
		PhysGrabber physGrabber = ((val != null) ? ((Component)val).GetComponent<PhysGrabber>() : null);
		if (Object.op_Implicit((Object)(object)physGrabber) && SemiFunc.OwnerOnlyRPC(_info, physGrabber.photonView))
		{
			physGrabber.physGrabPoint.localPosition = localPointInBox;
		}
	}

	public void GrabStarted(PhysGrabber player)
	{
		if (grabbed)
		{
			return;
		}
		grabbed = true;
		if (!SemiFunc.IsMultiplayer())
		{
			if (!playerGrabbing.Contains(player))
			{
				playerGrabbing.Add(player);
			}
		}
		else
		{
			photonView.RPC("GrabStartedRPC", (RpcTarget)2, new object[1] { player.photonView.ViewID });
		}
	}

	[PunRPC]
	private void GrabStartedRPC(int playerPhotonID, PhotonMessageInfo _info = default(PhotonMessageInfo))
	{
		//IL_0023: Unknown result type (might be due to invalid IL or missing references)
		if (SemiFunc.IsMasterClientOrSingleplayer())
		{
			PhotonView val = PhotonView.Find(playerPhotonID);
			PhysGrabber physGrabber = ((val != null) ? ((Component)val).GetComponent<PhysGrabber>() : null);
			if (Object.op_Implicit((Object)(object)physGrabber) && SemiFunc.MasterAndOwnerOnlyRPC(_info, physGrabber.photonView) && !playerGrabbing.Contains(physGrabber))
			{
				playerGrabbing.Add(physGrabber);
			}
		}
	}

	public void GrabEnded(PhysGrabber player)
	{
		if (!grabbed)
		{
			return;
		}
		grabbed = false;
		if (GameManager.instance.gameMode == 0)
		{
			if (playerGrabbing.Contains(player))
			{
				playerGrabbing.Remove(player);
			}
		}
		else
		{
			photonView.RPC("GrabEndedRPC", (RpcTarget)2, new object[1] { player.photonView.ViewID });
		}
	}

	[PunRPC]
	private void GrabEndedRPC(int playerPhotonID, PhotonMessageInfo _info = default(PhotonMessageInfo))
	{
		//IL_0023: Unknown result type (might be due to invalid IL or missing references)
		if (!SemiFunc.IsMasterClientOrSingleplayer())
		{
			return;
		}
		PhotonView val = PhotonView.Find(playerPhotonID);
		PhysGrabber physGrabber = ((val != null) ? ((Component)val).GetComponent<PhysGrabber>() : null);
		if (Object.op_Implicit((Object)(object)physGrabber) && SemiFunc.MasterAndOwnerOnlyRPC(_info, physGrabber.photonView))
		{
			physGrabber.grabbed = false;
			if (playerGrabbing.Contains(physGrabber))
			{
				playerGrabbing.Remove(physGrabber);
			}
		}
	}

	private void DestroyPhysGrabObject()
	{
		if (!SemiFunc.IsMultiplayer())
		{
			DestroyPhysObjectFailsafe();
			Object.Destroy((Object)(object)((Component)this).gameObject);
		}
		else
		{
			photonView.RPC("DestroyPhysGrabObjectRPC", (RpcTarget)0, Array.Empty<object>());
		}
	}

	[PunRPC]
	private void DestroyPhysGrabObjectRPC(PhotonMessageInfo _info = default(PhotonMessageInfo))
	{
		//IL_0000: Unknown result type (might be due to invalid IL or missing references)
		if (SemiFunc.MasterOnlyRPC(_info))
		{
			DestroyPhysObjectFailsafe();
			Object.Destroy((Object)(object)((Component)this).gameObject);
		}
	}

	private void DestroyPhysObjectFailsafe()
	{
		//IL_0014: Unknown result type (might be due to invalid IL or missing references)
		//IL_001a: Expected Obj, but got Unknown
		foreach (Transform item in ((Component)this).transform)
		{
			Transform val = item;
			if (((Component)val).CompareTag("Phys Grab Controller"))
			{
				val.SetParent((Transform)null);
			}
		}
	}

	public void ShowHoverText()
	{
		if (!string.IsNullOrEmpty(hoverText))
		{
			ItemInfoUI.instance.ItemInfoText(null, hoverText);
		}
	}
}
