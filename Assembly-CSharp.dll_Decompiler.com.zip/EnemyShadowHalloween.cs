using UnityEngine;

[DefaultExecutionOrder(-100)]
public class EnemyShadowHalloween : MonoBehaviour
{
	public Transform meshParent;

	public Material originalMaterial;

	public Material halloweenMaterial;

	public Material originalHairMaterial;

	public Material halloweenHairMaterial;

	public GameObject witchHat;

	private void Awake()
	{
		bool flag = Object.op_Implicit((Object)(object)GameManager.instance) && SemiFunc.GameEventIsHalloween();
		if (Object.op_Implicit((Object)(object)witchHat))
		{
			witchHat.SetActive(flag);
		}
		if (!flag || !Object.op_Implicit((Object)(object)meshParent))
		{
			return;
		}
		Renderer[] componentsInChildren = ((Component)meshParent).GetComponentsInChildren<Renderer>(true);
		foreach (Renderer val in componentsInChildren)
		{
			Material[] sharedMaterials = val.sharedMaterials;
			for (int j = 0; j < sharedMaterials.Length; j++)
			{
				if (Object.op_Implicit((Object)(object)originalMaterial) && Object.op_Implicit((Object)(object)halloweenMaterial) && (Object)(object)sharedMaterials[j] == (Object)(object)originalMaterial)
				{
					sharedMaterials[j] = halloweenMaterial;
				}
				else if (Object.op_Implicit((Object)(object)originalHairMaterial) && Object.op_Implicit((Object)(object)halloweenHairMaterial) && (Object)(object)sharedMaterials[j] == (Object)(object)originalHairMaterial)
				{
					sharedMaterials[j] = halloweenHairMaterial;
				}
			}
			val.sharedMaterials = sharedMaterials;
		}
	}
}
