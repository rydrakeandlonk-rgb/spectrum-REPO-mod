using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using TMPro;
using UnityEngine;
using UnityEngine.AddressableAssets;
using UnityEngine.UI;

public class MenuPageCosmetics : MonoBehaviour
{
	public enum CosmeticPageTab
	{
		Cosmetics,
		Presets
	}

	public CosmeticPageTab selectedTab;

	public MenuScrollBox menuScrollBox;

	internal bool scrollGradientTopHidden;

	public CanvasGroup scrollGradientTopCanvasGroup;

	public GameObject scrollGradientBottom;

	internal MenuPage menuPage;

	internal CosmeticCategoryAsset selectedCategory;

	internal SemiFunc.CosmeticType selectedSubCategory;

	public Transform categoriesTransform;

	public MenuElementCosmeticCategoryScroll categoriesHolder;

	public GameObject categoryButtonPrefab;

	public Transform sectionRootTransform;

	public GameObject sectionPrefab;

	internal List<MenuElementCosmeticSection> sections = new List<MenuElementCosmeticSection>();

	private bool avatarControlsHidden;

	public CanvasGroup topButtonsCanvasGroup;

	public MenuElementCosmeticButtonPopup colorPopup;

	public MenuElementCosmeticButtonPopup randomizePopup;

	public MenuElementCosmeticButtonPopup resetPopup;

	public CanvasGroup confirmButtonCanvasGroup;

	private MenuSelectableElement resetButtonSelectable;

	private MenuSelectableElement confirmButtonSelectable;

	internal float cosmeticHoverCooldown;

	internal bool subCategoriesReady;

	internal bool subCategoriesScrolling;

	private bool subCategoryScrollPending;

	internal MenuElementCosmeticButton hoveredCosmeticButton;

	internal MenuElementCosmeticButton pendingHoveredCosmeticButton;

	public GameObject sectionButtonPrefab;

	public MenuElementCosmeticSection stickyHeader;

	public Transform subCategoriesTransform;

	public MenuElementCosmeticCategoryScroll subCategoriesHolder;

	internal MenuElementCosmeticPreset hoveredPresetButton;

	internal MenuElementCosmeticPreset pendingHoveredPresetButton;

	public GameObject presetButtonPrefab;

	private Vector2 scrollerRestingPosition;

	private float scrollerLerp = 1f;

	public AnimationCurve scrollerAnimationCurve;

	public RectTransform topDivider;

	private float topDividerLerp = 1f;

	private Vector2 topDividerRestingPositionCurrent;

	private Vector2 topDividerRestingPositionEndNew;

	private Vector2 topDividerRestingPositionStart;

	private Vector2 topDividerRestingPositionEnd;

	public AnimationCurve topDividerAnimationCurve;

	internal bool shouldSave;

	private Coroutine animateSubCategoriesCoroutine;

	private Coroutine recalculateScrollHeightAfterFrameCoroutine;

	private Coroutine selectSectionEntryCoroutine;

	private void Awake()
	{
		menuPage = ((Component)this).GetComponent<MenuPage>();
	}

	private void Start()
	{
		//IL_001e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0023: Unknown result type (might be due to invalid IL or missing references)
		//IL_002f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0034: Unknown result type (might be due to invalid IL or missing references)
		//IL_0040: Unknown result type (might be due to invalid IL or missing references)
		//IL_0045: Unknown result type (might be due to invalid IL or missing references)
		//IL_0051: Unknown result type (might be due to invalid IL or missing references)
		//IL_0056: Unknown result type (might be due to invalid IL or missing references)
		//IL_0062: Unknown result type (might be due to invalid IL or missing references)
		//IL_0067: Unknown result type (might be due to invalid IL or missing references)
		//IL_04d5: Unknown result type (might be due to invalid IL or missing references)
		//IL_04da: Unknown result type (might be due to invalid IL or missing references)
		//IL_04eb: Unknown result type (might be due to invalid IL or missing references)
		//IL_061a: Unknown result type (might be due to invalid IL or missing references)
		//IL_061f: Unknown result type (might be due to invalid IL or missing references)
		//IL_065c: Unknown result type (might be due to invalid IL or missing references)
		//IL_06ef: Unknown result type (might be due to invalid IL or missing references)
		//IL_06f4: Unknown result type (might be due to invalid IL or missing references)
		//IL_0705: Unknown result type (might be due to invalid IL or missing references)
		//IL_0756: Unknown result type (might be due to invalid IL or missing references)
		//IL_075b: Unknown result type (might be due to invalid IL or missing references)
		//IL_077a: Unknown result type (might be due to invalid IL or missing references)
		menuScrollBox.restoreSelectionOnEnter = true;
		scrollerRestingPosition = menuScrollBox.scroller.anchoredPosition;
		topDividerRestingPositionEnd = topDivider.anchoredPosition;
		topDividerRestingPositionEndNew = topDivider.anchoredPosition;
		topDividerRestingPositionStart = topDivider.anchoredPosition;
		topDividerRestingPositionCurrent = topDivider.anchoredPosition;
		if (DataDirector.instance.SettingValueFetch(DataDirector.Setting.PopupCosmeticsColorAll) > 0)
		{
			colorPopup.dropdownButtons[0].menuButtonPopUp.disabled = true;
		}
		if (DataDirector.instance.SettingValueFetch(DataDirector.Setting.PopupCosmeticsColorBody) > 0)
		{
			colorPopup.dropdownButtons[1].menuButtonPopUp.disabled = true;
		}
		if (DataDirector.instance.SettingValueFetch(DataDirector.Setting.PopupCosmeticsColorCosmetics) > 0)
		{
			colorPopup.dropdownButtons[2].menuButtonPopUp.disabled = true;
		}
		if (DataDirector.instance.SettingValueFetch(DataDirector.Setting.PopupCosmeticsRandomizeAll) > 0)
		{
			randomizePopup.dropdownButtons[0].menuButtonPopUp.disabled = true;
		}
		if (DataDirector.instance.SettingValueFetch(DataDirector.Setting.PopupCosmeticsRandomizeBody) > 0)
		{
			randomizePopup.dropdownButtons[1].menuButtonPopUp.disabled = true;
		}
		if (DataDirector.instance.SettingValueFetch(DataDirector.Setting.PopupCosmeticsRandomizeCosmetics) > 0)
		{
			randomizePopup.dropdownButtons[2].menuButtonPopUp.disabled = true;
		}
		if (DataDirector.instance.SettingValueFetch(DataDirector.Setting.PopupCosmeticsResetAll) > 0)
		{
			resetPopup.dropdownButtons[0].menuButtonPopUp.disabled = true;
		}
		if (DataDirector.instance.SettingValueFetch(DataDirector.Setting.PopupCosmeticsResetBody) > 0)
		{
			resetPopup.dropdownButtons[1].menuButtonPopUp.disabled = true;
		}
		if (DataDirector.instance.SettingValueFetch(DataDirector.Setting.PopupCosmeticsResetCosmetics) > 0)
		{
			resetPopup.dropdownButtons[2].menuButtonPopUp.disabled = true;
		}
		colorPopup.SetState(_state: false, _skipAnim: true);
		randomizePopup.SetState(_state: false, _skipAnim: true);
		resetPopup.SetState(_state: false, _skipAnim: true);
		List<SemiFunc.CosmeticType> _unlockedTypes = (from cosmeticAsset in MetaManager.instance.cosmeticAssets
			where Object.op_Implicit((Object)(object)cosmeticAsset)
			select cosmeticAsset.type).Distinct().ToList();
		if (Object.op_Implicit((Object)(object)menuPage) && Object.op_Implicit((Object)(object)menuPage.playerAvatarMenu))
		{
			foreach (PlayerMaterial playerMaterial in menuPage.playerAvatarMenu.playerCosmetics.playerMaterials)
			{
				if (Object.op_Implicit((Object)(object)playerMaterial) && playerMaterial.tintable && !_unlockedTypes.Contains(playerMaterial.cosmeticType))
				{
					_unlockedTypes.Add(playerMaterial.cosmeticType);
					break;
				}
			}
		}
		foreach (CosmeticCategoryAsset cosmeticCategoryAsset in MetaManager.instance.CosmeticCategoryAssets)
		{
			if (cosmeticCategoryAsset.typeList.Any((SemiFunc.CosmeticType t) => _unlockedTypes.Contains(t)))
			{
				if (!Object.op_Implicit((Object)(object)selectedCategory))
				{
					selectedCategory = cosmeticCategoryAsset;
				}
				GameObject val = Object.Instantiate<GameObject>(categoryButtonPrefab, categoriesTransform);
				val.GetComponent<MenuElementButtonCosmeticCategory>().category = cosmeticCategoryAsset;
				TextMeshProUGUI componentInChildren = val.GetComponentInChildren<TextMeshProUGUI>();
				((TMP_Text)componentInChildren).fontSize = 20f;
				((TMP_Text)componentInChildren).text = cosmeticCategoryAsset.localizedName?.GetLocalizedString() ?? cosmeticCategoryAsset.categoryName;
				if (!Object.op_Implicit((Object)(object)cosmeticCategoryAsset.localizedName))
				{
					Debug.LogError((object)("Cosmetic category localized name not found for: " + ((Object)cosmeticCategoryAsset).name));
				}
			}
		}
		categoriesHolder.UpdateButtons();
		resetButtonSelectable = ((Object.op_Implicit((Object)(object)resetPopup) && Object.op_Implicit((Object)(object)resetPopup.toggleButton)) ? resetPopup.toggleButton.menuSelectableElement : null);
		confirmButtonSelectable = FindConfirmButtonSelectable();
		if (Object.op_Implicit((Object)(object)confirmButtonSelectable))
		{
			confirmButtonSelectable.skipRegionSelectionRestore = true;
		}
		MenuElementButtonCosmeticCategory menuElementButtonCosmeticCategory = ((Component)categoriesTransform).GetComponentsInChildren<MenuElementButtonCosmeticCategory>(true).FirstOrDefault((MenuElementButtonCosmeticCategory b) => b.buttonType == MenuElementButtonCosmeticCategory.ButtonType.Presets);
		if (Object.op_Implicit((Object)(object)menuElementButtonCosmeticCategory) && Object.op_Implicit((Object)(object)resetButtonSelectable))
		{
			MenuSelectableElement menuSelectableElement = ((Component)menuElementButtonCosmeticCategory).GetComponent<MenuButton>().menuSelectableElement;
			if (Object.op_Implicit((Object)(object)menuSelectableElement))
			{
				Navigation navigation = ((Selectable)resetButtonSelectable).navigation;
				navigation.selectOnRight = (Selectable)(object)menuSelectableElement;
				((Selectable)resetButtonSelectable).navigation = navigation;
			}
		}
		RowNavigationLink((from b in ((Component)categoriesTransform).GetComponentsInChildren<MenuElementButtonCosmeticCategory>(true)
			select ((Component)b).GetComponent<MenuButton>() into b
			where Object.op_Implicit((Object)(object)b) && Object.op_Implicit((Object)(object)b.menuSelectableElement)
			select b.menuSelectableElement).ToList(), resetButtonSelectable);
		List<MenuSelectableElement> list = (from p in new MenuElementCosmeticButtonPopup[3] { colorPopup, randomizePopup, resetPopup }
			where Object.op_Implicit((Object)(object)p) && Object.op_Implicit((Object)(object)p.toggleButton) && Object.op_Implicit((Object)(object)p.toggleButton.menuSelectableElement)
			select p.toggleButton.menuSelectableElement).OrderBy((MenuSelectableElement s) =>
		{
			//IL_0006: Unknown result type (might be due to invalid IL or missing references)
			return ((Transform)s.rectTransform).position.x;
		}).ToList();
		for (int num = 0; num < list.Count; num++)
		{
			Navigation navigation2 = ((Selectable)list[num]).navigation;
			if (num > 0)
			{
				navigation2.selectOnLeft = (Selectable)(object)list[num - 1];
			}
			if (num < list.Count - 1)
			{
				navigation2.selectOnRight = (Selectable)(object)list[num + 1];
			}
			((Selectable)list[num]).navigation = navigation2;
		}
		if (Object.op_Implicit((Object)(object)confirmButtonSelectable))
		{
			MenuElementCosmeticButtonPopup[] array = new MenuElementCosmeticButtonPopup[3] { colorPopup, randomizePopup, resetPopup };
			foreach (MenuElementCosmeticButtonPopup menuElementCosmeticButtonPopup in array)
			{
				if (Object.op_Implicit((Object)(object)menuElementCosmeticButtonPopup) && Object.op_Implicit((Object)(object)menuElementCosmeticButtonPopup.toggleButton))
				{
					menuElementCosmeticButtonPopup.selectOnDownWhenClosed = (Selectable)(object)confirmButtonSelectable;
					MenuSelectableElement menuSelectableElement2 = menuElementCosmeticButtonPopup.toggleButton.menuSelectableElement;
					if (Object.op_Implicit((Object)(object)menuSelectableElement2))
					{
						Navigation navigation3 = ((Selectable)menuSelectableElement2).navigation;
						navigation3.selectOnDown = (Selectable)(object)confirmButtonSelectable;
						((Selectable)menuSelectableElement2).navigation = navigation3;
					}
				}
			}
			if (Object.op_Implicit((Object)(object)randomizePopup) && Object.op_Implicit((Object)(object)randomizePopup.toggleButton) && Object.op_Implicit((Object)(object)randomizePopup.toggleButton.menuSelectableElement))
			{
				Navigation navigation4 = ((Selectable)confirmButtonSelectable).navigation;
				navigation4.selectOnUp = (Selectable)(object)randomizePopup.toggleButton.menuSelectableElement;
				((Selectable)confirmButtonSelectable).navigation = navigation4;
			}
		}
		RefreshScrollContent();
	}

	private void Update()
	{
		if (cosmeticHoverCooldown > 0f)
		{
			cosmeticHoverCooldown -= Time.deltaTime;
		}
		if (Object.op_Implicit((Object)(object)menuPage) && Object.op_Implicit((Object)(object)menuPage.playerAvatarMenu))
		{
			if (Object.op_Implicit((Object)(object)menuPage.playerAvatarMenu.playerExpression) && (selectedSubCategory == SemiFunc.CosmeticType.EyeLidLeftMesh || selectedSubCategory == SemiFunc.CosmeticType.EyeLidRightMesh || (Object.op_Implicit((Object)(object)hoveredCosmeticButton) && (hoveredCosmeticButton.cosmeticSection.subCategory == SemiFunc.CosmeticType.EyeLidLeftMesh || hoveredCosmeticButton.cosmeticSection.subCategory == SemiFunc.CosmeticType.EyeLidRightMesh))))
			{
				menuPage.playerAvatarMenu.playerExpression.OverrideExpressionSet(3, 100f);
			}
			if (Object.op_Implicit((Object)(object)menuPage.playerAvatarMenu.playerVisuals) && randomizePopup.dropdownActive)
			{
				menuPage.playerAvatarMenu.playerVisuals.playerEyes.OverrideDisableMenuLookAt();
			}
		}
		topButtonsCanvasGroup.alpha = Mathf.Lerp(topButtonsCanvasGroup.alpha, avatarControlsHidden ? 0f : 1f, Time.deltaTime * 15f);
		confirmButtonCanvasGroup.alpha = Mathf.Lerp(confirmButtonCanvasGroup.alpha, avatarControlsHidden ? 0f : 1f, Time.deltaTime * 15f);
		scrollGradientTopCanvasGroup.alpha = Mathf.Lerp(scrollGradientTopCanvasGroup.alpha, scrollGradientTopHidden ? 0f : 1f, Time.deltaTime * 8f);
		if (MenuManager.instance.currentMenuPageIndex == MenuPageIndex.Cosmetics)
		{
			if (!colorPopup.toggleButton.hovering && !randomizePopup.toggleButton.hovering && !resetPopup.toggleButton.hovering && !colorPopup.dropdownButtons.Any((MenuButton x) => x.hovering) && !randomizePopup.dropdownButtons.Any((MenuButton x) => x.hovering) && !resetPopup.dropdownButtons.Any((MenuButton x) => x.hovering) && SemiFunc.InputUIClick())
			{
				colorPopup.SetState(_state: false);
				randomizePopup.SetState(_state: false);
				resetPopup.SetState(_state: false);
			}
			if (SemiFunc.InputDown(InputKey.Back))
			{
				ConfirmButton();
			}
			if (SemiFunc.InputDown(InputKey.UITabLeft))
			{
				CycleTab(-1);
			}
			if (SemiFunc.InputDown(InputKey.UITabRight))
			{
				CycleTab(1);
			}
		}
	}

	private void LateUpdate()
	{
		//IL_0121: Unknown result type (might be due to invalid IL or missing references)
		//IL_0127: Unknown result type (might be due to invalid IL or missing references)
		//IL_00fa: Unknown result type (might be due to invalid IL or missing references)
		//IL_0100: Unknown result type (might be due to invalid IL or missing references)
		//IL_0116: Unknown result type (might be due to invalid IL or missing references)
		//IL_0135: Unknown result type (might be due to invalid IL or missing references)
		//IL_013a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0141: Unknown result type (might be due to invalid IL or missing references)
		//IL_0146: Unknown result type (might be due to invalid IL or missing references)
		//IL_018e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0194: Unknown result type (might be due to invalid IL or missing references)
		//IL_01aa: Unknown result type (might be due to invalid IL or missing references)
		//IL_01af: Unknown result type (might be due to invalid IL or missing references)
		//IL_01bb: Unknown result type (might be due to invalid IL or missing references)
		MenuElementCosmeticButton menuElementCosmeticButton = hoveredCosmeticButton;
		hoveredCosmeticButton = pendingHoveredCosmeticButton;
		pendingHoveredCosmeticButton = null;
		MenuElementCosmeticPreset menuElementCosmeticPreset = hoveredPresetButton;
		hoveredPresetButton = pendingHoveredPresetButton;
		pendingHoveredPresetButton = null;
		if ((Object.op_Implicit((Object)(object)menuElementCosmeticButton) && !Object.op_Implicit((Object)(object)hoveredCosmeticButton)) || (Object.op_Implicit((Object)(object)menuElementCosmeticPreset) && !Object.op_Implicit((Object)(object)hoveredPresetButton)))
		{
			MetaManager.instance.CosmeticPreviewSet(_state: false);
			MetaManager.instance.CosmeticPlayerUpdateLocal(_synced: false);
			if (MenuManager.instance.currentMenuPageIndex == MenuPageIndex.Cosmetics)
			{
				SetGrabberActive(selectedTab == CosmeticPageTab.Cosmetics && selectedSubCategory == SemiFunc.CosmeticType.GrabberMesh);
			}
		}
		if (scrollerLerp < 1f)
		{
			scrollerLerp += 2f * Time.deltaTime;
			scrollerLerp = Mathf.Clamp01(scrollerLerp);
			menuScrollBox.scroller.anchoredPosition = Vector2.LerpUnclamped(new Vector2(scrollerRestingPosition.x, scrollerRestingPosition.y - 320f), scrollerRestingPosition, scrollerAnimationCurve.Evaluate(scrollerLerp));
		}
		if (topDividerRestingPositionEnd != topDividerRestingPositionEndNew)
		{
			topDividerRestingPositionStart = topDividerRestingPositionCurrent;
			topDividerRestingPositionEnd = topDividerRestingPositionEndNew;
			topDividerLerp = 0f;
		}
		if (topDividerLerp < 1f)
		{
			topDividerLerp += 2f * Time.deltaTime;
			topDividerLerp = Mathf.Clamp01(topDividerLerp);
			topDividerRestingPositionCurrent = Vector2.LerpUnclamped(topDividerRestingPositionStart, topDividerRestingPositionEnd, topDividerAnimationCurve.Evaluate(topDividerLerp));
			topDivider.anchoredPosition = topDividerRestingPositionCurrent;
		}
	}

	private void OnDestroy()
	{
		if (Object.op_Implicit((Object)(object)MetaManager.instance))
		{
			MetaManager.instance.CosmeticPreviewSet(_state: false);
			if (shouldSave)
			{
				MetaManager.instance.Save();
				shouldSave = false;
			}
		}
	}

	private void OnApplicationQuit()
	{
		if (Object.op_Implicit((Object)(object)MetaManager.instance) && shouldSave)
		{
			MetaManager.instance.Save();
			shouldSave = false;
		}
	}

	internal void RefreshScrollContent()
	{
		//IL_0117: Unknown result type (might be due to invalid IL or missing references)
		//IL_011c: Unknown result type (might be due to invalid IL or missing references)
		//IL_012d: Unknown result type (might be due to invalid IL or missing references)
		//IL_013c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0b62: Unknown result type (might be due to invalid IL or missing references)
		//IL_0b67: Unknown result type (might be due to invalid IL or missing references)
		//IL_0b7f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0b8e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0bb9: Unknown result type (might be due to invalid IL or missing references)
		//IL_0bcf: Unknown result type (might be due to invalid IL or missing references)
		//IL_0bd9: Unknown result type (might be due to invalid IL or missing references)
		//IL_0c5b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0d5d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0d69: Unknown result type (might be due to invalid IL or missing references)
		//IL_0dac: Unknown result type (might be due to invalid IL or missing references)
		//IL_0db8: Unknown result type (might be due to invalid IL or missing references)
		//IL_0deb: Unknown result type (might be due to invalid IL or missing references)
		//IL_0df7: Unknown result type (might be due to invalid IL or missing references)
		//IL_09b3: Unknown result type (might be due to invalid IL or missing references)
		//IL_09b8: Unknown result type (might be due to invalid IL or missing references)
		//IL_09c5: Unknown result type (might be due to invalid IL or missing references)
		//IL_0d19: Unknown result type (might be due to invalid IL or missing references)
		//IL_0d1e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0d2b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0d34: Unknown result type (might be due to invalid IL or missing references)
		//IL_0d39: Unknown result type (might be due to invalid IL or missing references)
		//IL_0d46: Unknown result type (might be due to invalid IL or missing references)
		//IL_0421: Unknown result type (might be due to invalid IL or missing references)
		//IL_0434: Unknown result type (might be due to invalid IL or missing references)
		//IL_043e: Unknown result type (might be due to invalid IL or missing references)
		//IL_049c: Unknown result type (might be due to invalid IL or missing references)
		//IL_04ad: Unknown result type (might be due to invalid IL or missing references)
		//IL_04b2: Unknown result type (might be due to invalid IL or missing references)
		//IL_04b6: Unknown result type (might be due to invalid IL or missing references)
		//IL_04c9: Unknown result type (might be due to invalid IL or missing references)
		//IL_04d3: Unknown result type (might be due to invalid IL or missing references)
		//IL_0aad: Unknown result type (might be due to invalid IL or missing references)
		//IL_0ab2: Unknown result type (might be due to invalid IL or missing references)
		//IL_0abd: Unknown result type (might be due to invalid IL or missing references)
		//IL_0aef: Unknown result type (might be due to invalid IL or missing references)
		//IL_0afb: Unknown result type (might be due to invalid IL or missing references)
		//IL_0b08: Unknown result type (might be due to invalid IL or missing references)
		//IL_0b16: Unknown result type (might be due to invalid IL or missing references)
		//IL_0b22: Unknown result type (might be due to invalid IL or missing references)
		//IL_0b2f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0622: Unknown result type (might be due to invalid IL or missing references)
		//IL_0673: Unknown result type (might be due to invalid IL or missing references)
		//IL_067e: Unknown result type (might be due to invalid IL or missing references)
		//IL_06ce: Unknown result type (might be due to invalid IL or missing references)
		//IL_071c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0721: Unknown result type (might be due to invalid IL or missing references)
		//IL_08a2: Unknown result type (might be due to invalid IL or missing references)
		//IL_08ae: Unknown result type (might be due to invalid IL or missing references)
		//IL_090a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0916: Unknown result type (might be due to invalid IL or missing references)
		//IL_07f7: Unknown result type (might be due to invalid IL or missing references)
		//IL_07fc: Unknown result type (might be due to invalid IL or missing references)
		//IL_0809: Unknown result type (might be due to invalid IL or missing references)
		//IL_0757: Unknown result type (might be due to invalid IL or missing references)
		//IL_0949: Unknown result type (might be due to invalid IL or missing references)
		//IL_0955: Unknown result type (might be due to invalid IL or missing references)
		//IL_082d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0832: Unknown result type (might be due to invalid IL or missing references)
		//IL_083f: Unknown result type (might be due to invalid IL or missing references)
		//IL_07ac: Unknown result type (might be due to invalid IL or missing references)
		//IL_07b1: Unknown result type (might be due to invalid IL or missing references)
		//IL_07be: Unknown result type (might be due to invalid IL or missing references)
		//IL_077c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0781: Unknown result type (might be due to invalid IL or missing references)
		//IL_078e: Unknown result type (might be due to invalid IL or missing references)
		subCategoriesReady = false;
		((Component)menuScrollBox.scroller).GetComponent<CanvasGroup>().alpha = 0f;
		if (animateSubCategoriesCoroutine != null)
		{
			((MonoBehaviour)this).StopCoroutine(animateSubCategoriesCoroutine);
			animateSubCategoriesCoroutine = null;
		}
		if (recalculateScrollHeightAfterFrameCoroutine != null)
		{
			((MonoBehaviour)this).StopCoroutine(recalculateScrollHeightAfterFrameCoroutine);
			recalculateScrollHeightAfterFrameCoroutine = null;
		}
		MenuElementButtonCosmeticCategory[] componentsInChildren = ((Component)subCategoriesTransform).GetComponentsInChildren<MenuElementButtonCosmeticCategory>();
		for (int i = 0; i < componentsInChildren.Length; i++)
		{
			Object.Destroy((Object)(object)((Component)componentsInChildren[i]).gameObject);
		}
		foreach (MenuElementCosmeticSection item in sections.ToList())
		{
			int index = sections.IndexOf(item);
			Object.Destroy((Object)(object)((Component)item).gameObject);
			sections.RemoveAt(index);
		}
		menuScrollBox.disableHiddenChildren = true;
		float num = 10f;
		float num2 = 40f;
		if (selectedTab == CosmeticPageTab.Cosmetics)
		{
			scrollGradientTopHidden = true;
			topDividerRestingPositionEndNew = new Vector2(topDividerRestingPositionEnd.x, 311f);
			RectTransform component = ((Component)scrollGradientTopCanvasGroup).GetComponent<RectTransform>();
			component.anchoredPosition = new Vector2(component.anchoredPosition.x, -133f);
			bool flag = Object.op_Implicit((Object)(object)DebugComputerCheck.instance) && !DebugComputerCheck.instance.DebugDisable && DebugComputerCheck.instance.ItemDebug && DebugComputerCheck.instance.DisableItemIconCache;
			float num3 = 0f;
			MenuSelectableElement[] array = null;
			MenuSelectableElement menuSelectableElement = null;
			MenuSelectableElement menuSelectableElement2 = null;
			List<MenuSelectableElement> list = new List<MenuSelectableElement>();
			for (int j = 0; j < selectedCategory.typeList.Count; j++)
			{
				SemiFunc.CosmeticType subCategory = selectedCategory.typeList[j];
				List<CosmeticAsset> list2 = (from item in MetaManager.instance.cosmeticAssets
					where Object.op_Implicit((Object)(object)item) && item.type == subCategory && item.prefab.IsValid()
					orderby !MetaManager.instance.cosmeticUnlocks.Contains(MetaManager.instance.cosmeticAssets.IndexOf(item))
					select item).ThenByDescending((CosmeticAsset cosmeticAsset) => cosmeticAsset.rarity).ThenBy((CosmeticAsset cosmeticAsset) => cosmeticAsset.assetName).ToList();
				bool flag2 = false;
				if (Object.op_Implicit((Object)(object)menuPage) && Object.op_Implicit((Object)(object)menuPage.playerAvatarMenu))
				{
					foreach (PlayerMaterial playerMaterial in menuPage.playerAvatarMenu.playerCosmetics.playerMaterials)
					{
						if (Object.op_Implicit((Object)(object)playerMaterial) && playerMaterial.cosmeticType == subCategory && playerMaterial.tintable)
						{
							flag2 = true;
							break;
						}
					}
				}
				if (list2.Count == 0 && !flag2)
				{
					continue;
				}
				GameObject val = Object.Instantiate<GameObject>(categoryButtonPrefab, subCategoriesTransform);
				MenuElementButtonCosmeticCategory component2 = val.GetComponent<MenuElementButtonCosmeticCategory>();
				component2.subCategory = subCategory;
				component2.buttonType = MenuElementButtonCosmeticCategory.ButtonType.SubCategory;
				MenuButton component3 = val.GetComponent<MenuButton>();
				if (Object.op_Implicit((Object)(object)component3) && Object.op_Implicit((Object)(object)component3.menuSelectableElement))
				{
					list.Add(component3.menuSelectableElement);
				}
				if (Object.op_Implicit((Object)(object)component2.canvasGroup))
				{
					component2.canvasGroup.alpha = 0f;
				}
				TextMeshProUGUI componentInChildren = val.GetComponentInChildren<TextMeshProUGUI>();
				((TMP_Text)componentInChildren).fontSize = 16f;
				CosmeticTypeAsset cosmeticTypeAsset = MetaManager.instance.cosmeticTypeAssets.FirstOrDefault((CosmeticTypeAsset cosmeticTypeAsset2) => cosmeticTypeAsset2.type == subCategory);
				if (Object.op_Implicit((Object)(object)cosmeticTypeAsset))
				{
					((TMP_Text)componentInChildren).text = cosmeticTypeAsset.localizedName?.GetLocalizedString() ?? cosmeticTypeAsset.typeName;
					if (!Object.op_Implicit((Object)(object)cosmeticTypeAsset.localizedName))
					{
						Debug.LogError((object)("Cosmetic type localized name not found for: " + ((Object)cosmeticTypeAsset).name));
					}
				}
				else
				{
					((TMP_Text)componentInChildren).text = subCategory.ToString();
				}
				GameObject val2 = Object.Instantiate<GameObject>(sectionPrefab, sectionRootTransform);
				val2.transform.localPosition = new Vector3(val2.transform.localPosition.x, num3, val2.transform.localPosition.z);
				MenuElementCosmeticSection component4 = val2.GetComponent<MenuElementCosmeticSection>();
				component4.subCategory = subCategory;
				((TMP_Text)component4.headerText).text = ((TMP_Text)componentInChildren).text;
				((TMP_Text)component4.headerText).ForceMeshUpdate(false, false);
				RectTransform component5 = ((Component)component4.highlightObj).GetComponent<RectTransform>();
				float x = ((TMP_Text)component4.headerText).rectTransform.anchoredPosition.x;
				Bounds textBounds = ((TMP_Text)component4.headerText).textBounds;
				component5.anchoredPosition = new Vector2(x + textBounds.max.x + 15f, component5.anchoredPosition.y);
				GridLayoutGroup component6 = ((Component)component4.cosmeticListTransform).GetComponent<GridLayoutGroup>();
				MenuElementCosmeticButton[] menuButtons = new MenuElementCosmeticButton[list2.Count + 1];
				menuButtons[0] = component4.unequipButton;
				int num4 = 1;
				foreach (CosmeticAsset item2 in list2)
				{
					if (flag)
					{
						item2.icon = item2.GenerateIcon();
					}
					MenuElementCosmeticButton component7 = Object.Instantiate<GameObject>(sectionButtonPrefab, component4.cosmeticListTransform).GetComponent<MenuElementCosmeticButton>();
					component7.cosmeticAsset = item2;
					menuButtons[num4] = component7;
					num4++;
				}
				int columnCount = component6.constraintCount;
				int rowCount = Mathf.Max(1, Mathf.CeilToInt((float)menuButtons.Length / (float)columnCount));
				MenuSelectableElement menuSelectableElement3 = component4.colorButton.menuSelectableElement;
				if (!Object.op_Implicit((Object)(object)menuSelectableElement))
				{
					menuSelectableElement = LookupItemSelectable(0, 0);
				}
				for (int num5 = 0; num5 < menuButtons.Length; num5++)
				{
					int num6 = num5 % columnCount;
					int num7 = num5 / columnCount;
					MenuElementCosmeticButton obj = menuButtons[num5];
					MenuSelectableElement menuSelectableElement4 = obj.menuButton.menuSelectableElement;
					MenuSelectableElement menuSelectableElement5 = obj.tintableButton.menuSelectableElement;
					Navigation navigation = default;
					navigation.mode = (Mode)4;
					navigation.selectOnUp = (Selectable)(object)menuSelectableElement5;
					navigation.selectOnDown = (Selectable)(object)LookupItemSelectableDown(num6, num7);
					navigation.selectOnLeft = (Selectable)(object)LookupItemSelectable(num6 - 1, num7);
					navigation.selectOnRight = (Selectable)(object)LookupItemSelectable(num6 + 1, num7);
					((Selectable)menuSelectableElement4).navigation = navigation;
					navigation = default;
					navigation.mode = (Mode)4;
					navigation.selectOnUp = (Selectable)(object)((num7 == 0) ? menuSelectableElement3 : LookupItemSelectable(num6, num7 - 1));
					navigation.selectOnDown = (Selectable)(object)menuSelectableElement4;
					navigation.selectOnLeft = (Selectable)(object)menuSelectableElement4;
					navigation.selectOnRight = (Selectable)(object)LookupItemSelectable(num6 + 1, num7);
					((Selectable)menuSelectableElement5).navigation = navigation;
				}
				if ((Object)(object)menuSelectableElement3 != (Object)null)
				{
					MenuSelectableElement menuSelectableElement6 = ((array == null) ? val.GetComponent<MenuButton>().menuSelectableElement : null);
					if (!Object.op_Implicit((Object)(object)menuSelectableElement2))
					{
						menuSelectableElement2 = menuSelectableElement6;
					}
					Navigation navigation2 = ((Selectable)menuSelectableElement3).navigation;
					navigation2.mode = (Mode)4;
					navigation2.selectOnDown = (Selectable)(object)LookupItemSelectable(0, 0);
					navigation2.selectOnUp = (Selectable)(object)((array != null && array.Length > 0) ? array[0] : menuSelectableElement6);
					((Selectable)menuSelectableElement3).navigation = navigation2;
					if (array != null)
					{
						MenuSelectableElement[] array2 = array;
						foreach (MenuSelectableElement menuSelectableElement7 in array2)
						{
							if (!((Object)(object)menuSelectableElement7 == (Object)null))
							{
								Navigation navigation3 = ((Selectable)menuSelectableElement7).navigation;
								navigation3.selectOnDown = (Selectable)(object)menuSelectableElement3;
								((Selectable)menuSelectableElement7).navigation = navigation3;
							}
						}
					}
					if ((Object)(object)menuSelectableElement6 != (Object)null)
					{
						Navigation navigation4 = ((Selectable)menuSelectableElement6).navigation;
						navigation4.selectOnDown = (Selectable)(object)menuSelectableElement3;
						((Selectable)menuSelectableElement6).navigation = navigation4;
					}
				}
				Selectable val3 = (Selectable)(object)(Object.op_Implicit((Object)(object)confirmButtonSelectable) ? confirmButtonSelectable : resetButtonSelectable);
				if (Object.op_Implicit((Object)(object)val3))
				{
					if ((Object)(object)menuSelectableElement3 != (Object)null)
					{
						Navigation navigation5 = ((Selectable)menuSelectableElement3).navigation;
						navigation5.selectOnLeft = val3;
						((Selectable)menuSelectableElement3).navigation = navigation5;
					}
					for (int num8 = 0; num8 < rowCount; num8++)
					{
						MenuSelectableElement menuSelectableElement8 = LookupItemSelectable(0, num8);
						if (!((Object)(object)menuSelectableElement8 == (Object)null))
						{
							Navigation navigation6 = ((Selectable)menuSelectableElement8).navigation;
							navigation6.selectOnLeft = val3;
							((Selectable)menuSelectableElement8).navigation = navigation6;
						}
					}
				}
				if (menuButtons.Length != 0)
				{
					MenuSelectableElement[] array3 = new MenuSelectableElement[columnCount];
					for (int num9 = 0; num9 < columnCount; num9++)
					{
						array3[num9] = LookupItemSelectable(num9, rowCount - 1);
					}
					array = array3;
				}
				float y = component6.cellSize.y;
				float y2 = component6.spacing.y;
				float num10 = ((LayoutGroup)component6).padding.top + ((LayoutGroup)component6).padding.bottom;
				float num11 = y * (float)rowCount + y2 * (float)(rowCount - 1) + num10;
				float num12 = num2 + num11;
				num3 -= num12 + num;
				RectTransform component8 = val2.GetComponent<RectTransform>();
				component8.sizeDelta = new Vector2(component8.sizeDelta.x, num12);
				if (Object.op_Implicit((Object)(object)component4.cosmeticListTransform))
				{
					RectTransform component9 = ((Component)component4.cosmeticListTransform).GetComponent<RectTransform>();
					if (Object.op_Implicit((Object)(object)component9))
					{
						component9.sizeDelta = new Vector2(component9.sizeDelta.x, num11);
						LayoutRebuilder.ForceRebuildLayoutImmediate(component9);
					}
				}
				LayoutRebuilder.ForceRebuildLayoutImmediate(component8);
				sections.Add(component4);
				MenuElementCosmeticButton LookupCosmeticButton(int num19, int num21)
				{
					if (num19 < 0 || num19 >= columnCount)
					{
						return null;
					}
					int num20 = num19 + num21 * columnCount;
					if (num20 < 0 || num20 >= menuButtons.Length)
					{
						return null;
					}
					return menuButtons[num20];
				}
				MenuSelectableElement LookupItemSelectable(int x2, int y5)
				{
					return LookupCosmeticButton(x2, y5)?.menuButton.menuSelectableElement;
				}
				MenuSelectableElement LookupItemSelectableDown(int x2, int num19)
				{
					MenuSelectableElement menuSelectableElement11 = LookupItemSelectable(x2, num19 + 1);
					if ((Object)(object)menuSelectableElement11 != (Object)null || num19 + 1 >= rowCount)
					{
						return menuSelectableElement11;
					}
					return menuButtons[menuButtons.Length - 1].menuButton.menuSelectableElement;
				}
			}
			if (array != null)
			{
				MenuSelectableElement[] array2 = array;
				foreach (MenuSelectableElement menuSelectableElement9 in array2)
				{
					if (!((Object)(object)menuSelectableElement9 == (Object)null))
					{
						Navigation navigation7 = ((Selectable)menuSelectableElement9).navigation;
						navigation7.selectOnDown = (Selectable)(object)menuSelectableElement9;
						((Selectable)menuSelectableElement9).navigation = navigation7;
					}
				}
			}
			ToolbarRightTargetSet(menuSelectableElement);
			CategoryTabsDownTargetSet(menuSelectableElement2);
			RowNavigationLink(list, null);
			RowUpTargetSet(list, SelectedCategoryTabSelectableGet());
			if (sections.Count > 0 && Object.op_Implicit((Object)(object)stickyHeader) && Object.op_Implicit((Object)(object)stickyHeader.viewport))
			{
				MenuElementCosmeticSection menuElementCosmeticSection = sections[sections.Count - 1];
				RectTransform component10 = ((Component)menuElementCosmeticSection).GetComponent<RectTransform>();
				Transform cosmeticListTransform = menuElementCosmeticSection.cosmeticListTransform;
				RectTransform val4 = ((cosmeticListTransform != null) ? ((Component)cosmeticListTransform).GetComponent<RectTransform>() : null);
				Transform cosmeticListTransform2 = menuElementCosmeticSection.cosmeticListTransform;
				GridLayoutGroup val5 = ((cosmeticListTransform2 != null) ? ((Component)cosmeticListTransform2).GetComponent<GridLayoutGroup>() : null);
				if (Object.op_Implicit((Object)(object)component10) && Object.op_Implicit((Object)(object)val4) && Object.op_Implicit((Object)(object)val5))
				{
					Rect rect = stickyHeader.viewport.rect;
					float num13 = Mathf.Max(0f, rect.height - component10.sizeDelta.y - 10f);
					RectOffset padding = ((LayoutGroup)val5).padding;
					padding.bottom += (int)num13;
					val4.sizeDelta = new Vector2(val4.sizeDelta.x, val4.sizeDelta.y + num13);
					component10.sizeDelta = new Vector2(component10.sizeDelta.x, component10.sizeDelta.y + num13);
				}
			}
		}
		else if (selectedTab == CosmeticPageTab.Presets)
		{
			scrollGradientTopHidden = true;
			topDividerRestingPositionEndNew = new Vector2(topDividerRestingPositionEnd.x, 330f);
			SetGrabberActive(_state: false);
			RectTransform component11 = ((Component)scrollGradientTopCanvasGroup).GetComponent<RectTransform>();
			component11.anchoredPosition = new Vector2(component11.anchoredPosition.x, -103f);
			GameObject val6 = Object.Instantiate<GameObject>(sectionPrefab, sectionRootTransform);
			val6.transform.localPosition = new Vector3(val6.transform.localPosition.x, 0f, val6.transform.localPosition.z);
			MenuElementCosmeticSection component12 = val6.GetComponent<MenuElementCosmeticSection>();
			Object.Destroy((Object)(object)((Component)component12.headerCanvasGroup).gameObject);
			for (int num14 = 0; num14 < MetaManager.instance.cosmeticPresets.Count; num14++)
			{
				Object.Instantiate<GameObject>(presetButtonPrefab, component12.cosmeticListTransform).GetComponent<MenuElementCosmeticPreset>().presetIndex = num14;
			}
			GridLayoutGroup component13 = ((Component)component12.cosmeticListTransform).GetComponent<GridLayoutGroup>();
			component13.constraintCount = 7;
			component13.cellSize = new Vector2(60f, 140f);
			int num15 = Mathf.Max(1, Mathf.CeilToInt((float)MetaManager.instance.cosmeticPresets.Count / (float)component13.constraintCount));
			int num16 = (num15 - 1) * component13.constraintCount;
			MenuElementCosmeticPreset[] componentsInChildren2 = ((Component)component12.cosmeticListTransform).GetComponentsInChildren<MenuElementCosmeticPreset>(true);
			foreach (MenuElementCosmeticPreset menuElementCosmeticPreset in componentsInChildren2)
			{
				if (menuElementCosmeticPreset.presetIndex >= num16)
				{
					MenuSelectableElement menuSelectableElement10 = menuElementCosmeticPreset.menuButton.menuSelectableElement;
					MenuSelectableElement component14 = ((Component)(Object.op_Implicit((Object)(object)menuElementCosmeticPreset.deleteButton.rectTransformSelection) ? ((object)menuElementCosmeticPreset.deleteButton.rectTransformSelection) : ((object)((Component)menuElementCosmeticPreset.deleteButton).transform))).GetComponent<MenuSelectableElement>();
					if (Object.op_Implicit((Object)(object)menuSelectableElement10) && Object.op_Implicit((Object)(object)component14))
					{
						Navigation navigation8 = ((Selectable)menuSelectableElement10).navigation;
						navigation8.selectOnDown = (Selectable)(object)component14;
						((Selectable)menuSelectableElement10).navigation = navigation8;
						Navigation navigation9 = ((Selectable)component14).navigation;
						navigation9.selectOnDown = (Selectable)(object)component14;
						((Selectable)component14).navigation = navigation9;
					}
				}
			}
			float y3 = component13.cellSize.y;
			float y4 = component13.spacing.y;
			float num17 = ((LayoutGroup)component13).padding.top + ((LayoutGroup)component13).padding.bottom;
			float num18 = y3 * (float)num15 + y4 * (float)(num15 - 1) + num17;
			RectTransform component15 = val6.GetComponent<RectTransform>();
			component15.sizeDelta = new Vector2(component15.sizeDelta.x, num18);
			if (Object.op_Implicit((Object)(object)component12.cosmeticListTransform))
			{
				RectTransform component16 = ((Component)component12.cosmeticListTransform).GetComponent<RectTransform>();
				if (Object.op_Implicit((Object)(object)component16))
				{
					component16.sizeDelta = new Vector2(component16.sizeDelta.x, num18);
					LayoutRebuilder.ForceRebuildLayoutImmediate(component16);
				}
			}
			LayoutRebuilder.ForceRebuildLayoutImmediate(component15);
			sections.Add(component12);
			MenuElementCosmeticPreset componentInChildren2 = ((Component)component12.cosmeticListTransform).GetComponentInChildren<MenuElementCosmeticPreset>();
			MenuSelectableElement target = (Object.op_Implicit((Object)(object)componentInChildren2) ? ((Component)componentInChildren2).GetComponentInChildren<MenuSelectableElement>() : null);
			ToolbarRightTargetSet(target);
			CategoryTabsDownTargetSet(target);
		}
		recalculateScrollHeightAfterFrameCoroutine = ((MonoBehaviour)this).StartCoroutine(RecalculateScrollHeightAfterFrame());
	}

	private IEnumerator RecalculateScrollHeightAfterFrame()
	{
		yield return null;
		subCategoriesHolder.UpdateButtons();
		menuScrollBox.RecalculateScrollHeight();
		stickyHeader.SetSections();
		animateSubCategoriesCoroutine = ((MonoBehaviour)this).StartCoroutine(AnimateSubCategories());
		menuScrollBox.scroller.anchoredPosition = new Vector2(scrollerRestingPosition.x, scrollerRestingPosition.y - 320f);
		yield return (object)new WaitForFixedUpdate();
		yield return (object)new WaitForEndOfFrame();
		float _timeout = Time.unscaledTime + 2f;
		yield return (object)new WaitUntil((Func<bool>)(() =>
		{
			if (Time.unscaledTime >= _timeout)
			{
				return true;
			}
			List<MenuElementCosmeticButton> list = ((Component)sectionRootTransform).GetComponentsInChildren<MenuElementCosmeticButton>().ToList();
			return list.Count == 0 || list.All((MenuElementCosmeticButton b) => !Object.op_Implicit((Object)(object)b) || !Object.op_Implicit((Object)(object)b.cosmeticAsset) || Object.op_Implicit((Object)(object)b.cosmeticAsset.icon) || b.cosmeticAsset.iconRef == null || !((AssetReference)b.cosmeticAsset.iconRef).RuntimeKeyIsValid());
		}));
		scrollerLerp = 0f;
		menuScrollBox.disableHiddenChildren = true;
		((Component)menuScrollBox.scroller).GetComponent<CanvasGroup>().alpha = 1f;
		subCategoriesReady = true;
	}

	private IEnumerator SelectSectionEntry(MenuSelectableElement _target)
	{
		string _menuIDAtStart = MenuManager.instance.lastHoverMenuID;
		float _timeout = Time.unscaledTime + 2f;
		while (Object.op_Implicit((Object)(object)_target) && !((Component)_target).gameObject.activeInHierarchy)
		{
			if (MenuManager.instance.lastHoverMenuID != _menuIDAtStart || (SemiFunc.InputMode() != InputModes.Gamepad && !MenuManager.instance.isKeyboardNavigating) || Time.unscaledTime >= _timeout)
			{
				yield break;
			}
			yield return null;
		}
		if (Object.op_Implicit((Object)(object)_target))
		{
			MenuManager.instance.lastHoverMenuID = _target.menuID;
		}
		selectSectionEntryCoroutine = null;
	}

	private IEnumerator AnimateSubCategories()
	{
		foreach (Transform item in subCategoriesTransform)
		{
			Transform val = item;
			if (!Object.op_Implicit((Object)(object)val))
			{
				continue;
			}
			MenuElementButtonCosmeticCategory btn = ((Component)val).GetComponent<MenuElementButtonCosmeticCategory>();
			if (Object.op_Implicit((Object)(object)btn) && btn.buttonType == MenuElementButtonCosmeticCategory.ButtonType.SubCategory)
			{
				yield return (object)new WaitForSeconds(0.05f);
				if (Object.op_Implicit((Object)(object)btn.canvasGroup))
				{
					btn.canvasGroup.alpha = 1f;
					btn.semiUI.SemiUISpringShakeY(5f, 2f, 0.25f);
				}
			}
		}
	}

	public void CycleTab(int direction)
	{
		List<MenuElementButtonCosmeticCategory> list = (from b in ((Component)categoriesTransform).GetComponentsInChildren<MenuElementButtonCosmeticCategory>(true)
			where b.buttonType == MenuElementButtonCosmeticCategory.ButtonType.Category || b.buttonType == MenuElementButtonCosmeticCategory.ButtonType.Presets
			select b).ToList();
		if (list.Count == 0)
		{
			return;
		}
		int num = list.FindIndex((MenuElementButtonCosmeticCategory b) => (selectedTab != CosmeticPageTab.Presets) ? (b.buttonType == MenuElementButtonCosmeticCategory.ButtonType.Category && (Object)(object)b.category == (Object)(object)selectedCategory) : (b.buttonType == MenuElementButtonCosmeticCategory.ButtonType.Presets));
		if (num >= 0 && subCategoriesReady)
		{
			categoriesHolder.ArrowBounce(direction);
			int index = (num + direction + list.Count) % list.Count;
			SemiFunc.GamepadRumbleThockBigButton();
			list[index].ClickCategory();
			MenuButton component = ((Component)list[index]).GetComponent<MenuButton>();
			if (!Object.op_Implicit((Object)(object)component) || component.doButtonEffect)
			{
				MenuManager.instance.MenuEffectClick(MenuManager.MenuClickEffectType.Action, menuPage, -1f, -1f, soundOnly: true);
			}
			MenuSelectableElement menuSelectableElement = (Object.op_Implicit((Object)(object)component) ? component.menuSelectableElement : null);
			if (Object.op_Implicit((Object)(object)menuSelectableElement) && (SemiFunc.InputMode() == InputModes.Gamepad || MenuManager.instance.isKeyboardNavigating))
			{
				MenuManager.instance.lastHoverMenuID = menuSelectableElement.menuID;
			}
		}
	}

	public void SetCurrentCategory(CosmeticCategoryAsset _selectedCategory)
	{
		//IL_0021: Unknown result type (might be due to invalid IL or missing references)
		//IL_0027: Expected Obj, but got Unknown
		selectedCategory = _selectedCategory;
		RefreshScrollContent();
		foreach (Transform item in categoriesTransform)
		{
			Transform val = item;
			MenuElementButtonCosmeticCategory component = ((Component)val).GetComponent<MenuElementButtonCosmeticCategory>();
			if (Object.op_Implicit((Object)(object)component) && component.buttonType == MenuElementButtonCosmeticCategory.ButtonType.Category && (Object)(object)component.category == (Object)(object)selectedCategory)
			{
				categoriesHolder.ScrollToShow(((Component)val).GetComponent<RectTransform>());
				break;
			}
		}
	}

	public void SetCurrentSubCategory(SemiFunc.CosmeticType _selectedSubCategory, bool _scrollPage = true, bool _scrollButtons = true, bool _shouldAnimate = false)
	{
		//IL_01ae: Unknown result type (might be due to invalid IL or missing references)
		selectedSubCategory = _selectedSubCategory;
		MenuElementCosmeticSection menuElementCosmeticSection = sections.FirstOrDefault((MenuElementCosmeticSection x) => x.subCategory == selectedSubCategory);
		if (Object.op_Implicit((Object)(object)menuElementCosmeticSection))
		{
			stickyHeader.subCategory = menuElementCosmeticSection.subCategory;
			((TMP_Text)stickyHeader.headerText).text = ((TMP_Text)menuElementCosmeticSection.headerText).text;
			if (stickyHeader.stickyCurrentIndex >= 0 && stickyHeader.stickyCurrentIndex < sections.Count)
			{
				MenuElementCosmeticSection menuElementCosmeticSection2 = sections[stickyHeader.stickyCurrentIndex];
				if (Object.op_Implicit((Object)(object)menuElementCosmeticSection2) && Object.op_Implicit((Object)(object)menuElementCosmeticSection2.headerCanvasGroup))
				{
					menuElementCosmeticSection2.headerCanvasGroup.alpha = 1f;
				}
			}
			stickyHeader.stickyCurrentIndex = sections.IndexOf(menuElementCosmeticSection);
			menuElementCosmeticSection.UpdateColorButton(null);
			if (selectedSubCategory == menuElementCosmeticSection.subCategory)
			{
				stickyHeader.highlightObj.oldText = "";
			}
			menuElementCosmeticSection.UpdateHighlight();
			if (_scrollPage)
			{
				Transform val = ((Component)menuElementCosmeticSection).transform.Find("Header");
				RectTransform val2 = ((val != null) ? ((Component)val).GetComponent<RectTransform>() : null);
				menuScrollBox?.ScrollToChild(Object.op_Implicit((Object)(object)val2) ? val2 : ((Component)menuElementCosmeticSection).GetComponent<RectTransform>(), 0f, alignTop: true);
				MenuSelectableElement menuSelectableElement = SectionEntrySelectableGet(menuElementCosmeticSection);
				if (Object.op_Implicit((Object)(object)menuSelectableElement) && (SemiFunc.InputMode() == InputModes.Gamepad || MenuManager.instance.isKeyboardNavigating))
				{
					if (selectSectionEntryCoroutine != null)
					{
						((MonoBehaviour)this).StopCoroutine(selectSectionEntryCoroutine);
					}
					selectSectionEntryCoroutine = ((MonoBehaviour)this).StartCoroutine(SelectSectionEntry(menuSelectableElement));
				}
			}
			foreach (Transform item in subCategoriesTransform)
			{
				MenuElementButtonCosmeticCategory component = ((Component)item).GetComponent<MenuElementButtonCosmeticCategory>();
				if (!Object.op_Implicit((Object)(object)component) || component.buttonType != MenuElementButtonCosmeticCategory.ButtonType.SubCategory || component.subCategory != selectedSubCategory)
				{
					continue;
				}
				CategoryTabsDownTargetSet(((Component)component).GetComponent<MenuButton>().menuSelectableElement);
				if (_shouldAnimate)
				{
					component.semiUI.SemiUISpringShakeY(5f, 2f, 0.25f);
				}
				if (_scrollButtons || (!subCategoriesScrolling && (!Object.op_Implicit((Object)(object)menuScrollBox) || !menuScrollBox.isAnimating)))
				{
					subCategoryScrollPending = false;
					if (subCategoriesHolder.ScrollToShow(((Component)component).GetComponent<RectTransform>()) && _scrollPage)
					{
						subCategoriesScrolling = true;
					}
				}
				else if (!subCategoriesScrolling && Object.op_Implicit((Object)(object)menuScrollBox) && menuScrollBox.isAnimating)
				{
					subCategoryScrollPending = true;
				}
				break;
			}
		}
		SetGrabberActive(selectedSubCategory == SemiFunc.CosmeticType.GrabberMesh || (Object.op_Implicit((Object)(object)hoveredCosmeticButton) && hoveredCosmeticButton.cosmeticSection.subCategory == SemiFunc.CosmeticType.GrabberMesh));
	}

	public void TryShowCurrentSubCategoryButton()
	{
		//IL_0046: Unknown result type (might be due to invalid IL or missing references)
		if (!subCategoryScrollPending || subCategoriesScrolling || (Object.op_Implicit((Object)(object)menuScrollBox) && menuScrollBox.isAnimating))
		{
			return;
		}
		subCategoryScrollPending = false;
		foreach (Transform item in subCategoriesTransform)
		{
			MenuElementButtonCosmeticCategory component = ((Component)item).GetComponent<MenuElementButtonCosmeticCategory>();
			if (Object.op_Implicit((Object)(object)component) && component.buttonType == MenuElementButtonCosmeticCategory.ButtonType.SubCategory && component.subCategory == selectedSubCategory)
			{
				subCategoriesHolder.ScrollToShow(((Component)component).GetComponent<RectTransform>());
				break;
			}
		}
	}

	public void SetGrabberActive(bool _state)
	{
		if (Object.op_Implicit((Object)(object)menuPage) && Object.op_Implicit((Object)(object)menuPage.playerAvatarMenu) && Object.op_Implicit((Object)(object)menuPage.playerAvatarMenu.playerVisuals))
		{
			menuPage.playerAvatarMenu.physGrabBeamActive = _state;
			PlayerAvatarRightArm playerAvatarRightArm = menuPage.playerAvatarMenu.playerVisuals.playerAvatarRightArm;
			if (Object.op_Implicit((Object)(object)playerAvatarRightArm) && ((Component)playerAvatarRightArm.grabberTransform).gameObject.activeSelf != menuPage.playerAvatarMenu.physGrabBeamActive)
			{
				((Component)playerAvatarRightArm.grabberTransform).gameObject.SetActive(menuPage.playerAvatarMenu.playerVisuals.playerAvatarMenu.physGrabBeamActive);
				((Component)playerAvatarRightArm.grabberOrb).gameObject.SetActive(false);
			}
		}
	}

	private void ToolbarRightTargetSet(MenuSelectableElement target)
	{
		//IL_001c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0021: Unknown result type (might be due to invalid IL or missing references)
		//IL_0030: Unknown result type (might be due to invalid IL or missing references)
		if (Object.op_Implicit((Object)(object)target) && Object.op_Implicit((Object)(object)confirmButtonSelectable))
		{
			Navigation navigation = ((Selectable)confirmButtonSelectable).navigation;
			navigation.selectOnRight = (Selectable)(object)target;
			((Selectable)confirmButtonSelectable).navigation = navigation;
		}
	}

	private static void RowNavigationLink(List<MenuSelectableElement> row, MenuSelectableElement leftEdge)
	{
		//IL_000b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0010: Unknown result type (might be due to invalid IL or missing references)
		//IL_0064: Unknown result type (might be due to invalid IL or missing references)
		for (int i = 0; i < row.Count; i++)
		{
			Navigation navigation = ((Selectable)row[i]).navigation;
			navigation.selectOnLeft = (Selectable)(object)((i > 0) ? row[i - 1] : (Object.op_Implicit((Object)(object)leftEdge) ? leftEdge : row[i]));
			navigation.selectOnRight = (Selectable)(object)((i < row.Count - 1) ? row[i + 1] : row[i]);
			((Selectable)row[i]).navigation = navigation;
		}
	}

	private static void RowUpTargetSet(List<MenuSelectableElement> row, MenuSelectableElement target)
	{
		//IL_001a: Unknown result type (might be due to invalid IL or missing references)
		//IL_001f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0028: Unknown result type (might be due to invalid IL or missing references)
		if (!Object.op_Implicit((Object)(object)target))
		{
			return;
		}
		foreach (MenuSelectableElement item in row)
		{
			Navigation navigation = ((Selectable)item).navigation;
			navigation.selectOnUp = (Selectable)(object)target;
			((Selectable)item).navigation = navigation;
		}
	}

	private MenuSelectableElement SelectedCategoryTabSelectableGet()
	{
		MenuElementButtonCosmeticCategory[] componentsInChildren = ((Component)categoriesTransform).GetComponentsInChildren<MenuElementButtonCosmeticCategory>(true);
		foreach (MenuElementButtonCosmeticCategory menuElementButtonCosmeticCategory in componentsInChildren)
		{
			if (menuElementButtonCosmeticCategory.buttonType == MenuElementButtonCosmeticCategory.ButtonType.Category && !((Object)(object)menuElementButtonCosmeticCategory.category != (Object)(object)selectedCategory))
			{
				MenuButton component = ((Component)menuElementButtonCosmeticCategory).GetComponent<MenuButton>();
				if (!Object.op_Implicit((Object)(object)component))
				{
					return null;
				}
				return component.menuSelectableElement;
			}
		}
		return null;
	}

	private void CategoryTabsDownTargetSet(MenuSelectableElement target)
	{
		//IL_003e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0043: Unknown result type (might be due to invalid IL or missing references)
		//IL_004e: Unknown result type (might be due to invalid IL or missing references)
		if (!Object.op_Implicit((Object)(object)target))
		{
			return;
		}
		MenuElementButtonCosmeticCategory[] componentsInChildren = ((Component)categoriesTransform).GetComponentsInChildren<MenuElementButtonCosmeticCategory>(true);
		for (int i = 0; i < componentsInChildren.Length; i++)
		{
			MenuButton component = ((Component)componentsInChildren[i]).GetComponent<MenuButton>();
			MenuSelectableElement menuSelectableElement = (Object.op_Implicit((Object)(object)component) ? component.menuSelectableElement : null);
			if (Object.op_Implicit((Object)(object)menuSelectableElement))
			{
				Navigation navigation = ((Selectable)menuSelectableElement).navigation;
				navigation.selectOnDown = (Selectable)(object)target;
				((Selectable)menuSelectableElement).navigation = navigation;
			}
		}
	}

	private static MenuSelectableElement SectionEntrySelectableGet(MenuElementCosmeticSection _section)
	{
		if (Object.op_Implicit((Object)(object)_section.colorButton) && ((Component)_section.colorButton).gameObject.activeSelf && !_section.colorButton.disabled)
		{
			return _section.colorButton.menuSelectableElement;
		}
		if (!Object.op_Implicit((Object)(object)_section.cosmeticListTransform))
		{
			return null;
		}
		MenuElementCosmeticButton[] componentsInChildren = ((Component)_section.cosmeticListTransform).GetComponentsInChildren<MenuElementCosmeticButton>(true);
		foreach (MenuElementCosmeticButton menuElementCosmeticButton in componentsInChildren)
		{
			if (((Component)menuElementCosmeticButton).gameObject.activeSelf && Object.op_Implicit((Object)(object)menuElementCosmeticButton.menuButton) && Object.op_Implicit((Object)(object)menuElementCosmeticButton.menuButton.menuSelectableElement))
			{
				return menuElementCosmeticButton.menuButton.menuSelectableElement;
			}
		}
		return null;
	}

	private MenuSelectableElement FindConfirmButtonSelectable()
	{
		MenuButton[] componentsInChildren = ((Component)this).GetComponentsInChildren<MenuButton>(true);
		foreach (MenuButton menuButton in componentsInChildren)
		{
			if (((Object)((Component)menuButton).gameObject).name == "Menu Button - Confirm")
			{
				return menuButton.menuSelectableElement;
			}
		}
		return null;
	}

	public void ConfirmButton()
	{
		MetaManager.instance.CosmeticPreviewSet(_state: false);
		MetaManager.instance.CosmeticPlayerUpdateLocal(_synced: true);
		if (SemiFunc.IsMainMenu())
		{
			MenuManager.instance.PageCloseAllExcept(MenuPageIndex.Main);
			MenuManager.instance.PageSetCurrent(MenuPageIndex.Main, MenuPageMain.instance.menuPage);
			MenuManager.instance.PageSelectButtonByEvent(MenuPageMain.instance.menuPage, "ButtonEventChangeColor");
		}
		else if (SemiFunc.RunIsLobbyMenu())
		{
			MenuManager.instance.PageCloseAllExcept(MenuPageIndex.Lobby);
			MenuManager.instance.PageSetCurrent(MenuPageIndex.Lobby, MenuPageLobby.instance.menuPage);
		}
		else
		{
			MenuManager.instance.PageCloseAll();
			MenuPage menuPage = MenuManager.instance.PageOpen(MenuPageIndex.Escape);
			MenuManager.instance.PageSelectButtonByEvent(menuPage, "ButtonEventChangeColor");
		}
	}

	public void HideAvatarControls(bool _state)
	{
		avatarControlsHidden = _state;
	}

	public void TogglePopupColor()
	{
		TriggerClickAnimationsPopup(colorPopup.toggleSemiUI, isToggle: true);
		randomizePopup.SetState(_state: false);
		resetPopup.SetState(_state: false);
		int siblingIndex = Mathf.Max(new int[3]
		{
			colorPopup.dropdownObj.transform.GetSiblingIndex(),
			randomizePopup.dropdownObj.transform.GetSiblingIndex(),
			resetPopup.dropdownObj.transform.GetSiblingIndex()
		});
		colorPopup.dropdownObj.transform.SetSiblingIndex(siblingIndex);
		colorPopup.SetState(!colorPopup.dropdownActive);
	}

	public void ChangeAllColorButton()
	{
		if (MenuManager.instance.currentMenuPageIndex == MenuPageIndex.Cosmetics)
		{
			TriggerClickAnimationsPopup(((Component)colorPopup.dropdownButtons[0]).GetComponentInChildren<SemiUI>(), isToggle: false);
			MenuManager.instance.PageOpenOnTop(MenuPageIndex.Color);
			HideAvatarControls(_state: true);
			if (!colorPopup.dropdownButtons[0].menuButtonPopUp.disabled)
			{
				colorPopup.dropdownButtons[0].menuButtonPopUp.disabled = true;
				DataDirector.instance.SettingValueSet(DataDirector.Setting.PopupCosmeticsColorAll, 1);
				DataDirector.instance.SaveSettings();
			}
		}
	}

	public void ChangeBodyColorButton()
	{
		if (MenuManager.instance.currentMenuPageIndex == MenuPageIndex.Cosmetics)
		{
			TriggerClickAnimationsPopup(((Component)colorPopup.dropdownButtons[1]).GetComponentInChildren<SemiUI>(), isToggle: false);
			((Component)MenuManager.instance.PageOpenOnTop(MenuPageIndex.Color)).GetComponent<MenuPageColor>().pageMode = MenuPageColor.ColorPageType.Body;
			HideAvatarControls(_state: true);
			if (!colorPopup.dropdownButtons[1].menuButtonPopUp.disabled)
			{
				colorPopup.dropdownButtons[1].menuButtonPopUp.disabled = true;
				DataDirector.instance.SettingValueSet(DataDirector.Setting.PopupCosmeticsColorBody, 1);
				DataDirector.instance.SaveSettings();
			}
		}
	}

	public void ChangeCosmeticsColorButton()
	{
		if (MenuManager.instance.currentMenuPageIndex == MenuPageIndex.Cosmetics)
		{
			TriggerClickAnimationsPopup(((Component)colorPopup.dropdownButtons[2]).GetComponentInChildren<SemiUI>(), isToggle: false);
			((Component)MenuManager.instance.PageOpenOnTop(MenuPageIndex.Color)).GetComponent<MenuPageColor>().pageMode = MenuPageColor.ColorPageType.Cosmetics;
			HideAvatarControls(_state: true);
			if (!colorPopup.dropdownButtons[2].menuButtonPopUp.disabled)
			{
				colorPopup.dropdownButtons[2].menuButtonPopUp.disabled = true;
				DataDirector.instance.SettingValueSet(DataDirector.Setting.PopupCosmeticsColorCosmetics, 1);
				DataDirector.instance.SaveSettings();
			}
		}
	}

	public void TogglePopupRandomize()
	{
		TriggerClickAnimationsPopup(randomizePopup.toggleSemiUI, isToggle: true);
		colorPopup.SetState(_state: false);
		resetPopup.SetState(_state: false);
		int siblingIndex = Mathf.Max(new int[3]
		{
			colorPopup.dropdownObj.transform.GetSiblingIndex(),
			randomizePopup.dropdownObj.transform.GetSiblingIndex(),
			resetPopup.dropdownObj.transform.GetSiblingIndex()
		});
		randomizePopup.dropdownObj.transform.SetSiblingIndex(siblingIndex);
		randomizePopup.SetState(!randomizePopup.dropdownActive);
	}

	public void RandomizeAllButton()
	{
		if (MenuManager.instance.currentMenuPageIndex != MenuPageIndex.Cosmetics)
		{
			return;
		}
		TriggerClickAnimationsPopup(((Component)randomizePopup.dropdownButtons[0]).GetComponentInChildren<SemiUI>(), isToggle: false);
		foreach (int item in MetaManager.instance.cosmeticEquipped.ToList())
		{
			if (item >= 0 && item < MetaManager.instance.cosmeticAssets.Count)
			{
				CosmeticAsset cosmeticAsset = MetaManager.instance.cosmeticAssets[item];
				MetaManager.instance.CosmeticUnequip(cosmeticAsset, _isPreview: false);
				shouldSave = true;
			}
		}
		List<CosmeticAsset> list = new List<CosmeticAsset>();
		for (int i = 0; i < MetaManager.instance.cosmeticAssets.Count; i++)
		{
			if (MetaManager.instance.cosmeticUnlocks.Contains(i))
			{
				CosmeticAsset cosmeticAsset2 = MetaManager.instance.cosmeticAssets[i];
				if (Object.op_Implicit((Object)(object)cosmeticAsset2))
				{
					list.Add(cosmeticAsset2);
				}
			}
		}
		foreach (IGrouping<SemiFunc.CosmeticType, CosmeticAsset> item2 in from c in list
			group c by c.type)
		{
			if (!(Random.value < 0.25f))
			{
				CosmeticAsset cosmeticAssetNew = item2.ElementAt(Random.Range(0, item2.Count()));
				MetaManager.instance.CosmeticEquip(cosmeticAssetNew, _isPreview: false);
				shouldSave = true;
			}
		}
		for (int num = 0; num < MetaManager.instance.colorsEquipped.Length; num++)
		{
			if (!(Random.value < 0.25f))
			{
				int colorID = Random.Range(0, MetaManager.instance.colors.Count);
				MetaManager.instance.CosmeticColorSet(num, colorID);
				shouldSave = true;
			}
		}
		MetaManager.instance.CosmeticPreviewSet(_state: false);
		MetaManager.instance.CosmeticPlayerUpdateLocal(_synced: false);
		if (!randomizePopup.dropdownButtons[0].menuButtonPopUp.disabled)
		{
			randomizePopup.dropdownButtons[0].menuButtonPopUp.disabled = true;
			DataDirector.instance.SettingValueSet(DataDirector.Setting.PopupCosmeticsRandomizeAll, 1);
			DataDirector.instance.SaveSettings();
		}
	}

	public void RandomizeBodyButton()
	{
		if (MenuManager.instance.currentMenuPageIndex != MenuPageIndex.Cosmetics)
		{
			return;
		}
		TriggerClickAnimationsPopup(((Component)randomizePopup.dropdownButtons[1]).GetComponentInChildren<SemiUI>(), isToggle: false);
		List<SemiFunc.CosmeticType> deniedTypes = (from x in MetaManager.instance.cosmeticTypeAssets
			where !x.meshSwitch
			select x.type).ToList();
		foreach (int item in MetaManager.instance.cosmeticEquipped.ToList())
		{
			if (item >= 0 && item < MetaManager.instance.cosmeticAssets.Count)
			{
				CosmeticAsset cosmeticAsset = MetaManager.instance.cosmeticAssets[item];
				if (Object.op_Implicit((Object)(object)cosmeticAsset) && !deniedTypes.Contains(cosmeticAsset.type))
				{
					MetaManager.instance.CosmeticUnequip(cosmeticAsset, _isPreview: false);
					shouldSave = true;
				}
			}
		}
		List<CosmeticAsset> list = new List<CosmeticAsset>();
		for (int num = 0; num < MetaManager.instance.cosmeticAssets.Count; num++)
		{
			if (MetaManager.instance.cosmeticUnlocks.Contains(num))
			{
				CosmeticAsset cosmeticAsset2 = MetaManager.instance.cosmeticAssets[num];
				if (Object.op_Implicit((Object)(object)cosmeticAsset2) && !deniedTypes.Contains(cosmeticAsset2.type) && !MetaManager.instance.cosmeticTypeAssets[(int)cosmeticAsset2.type].disabledTypeList.Any((SemiFunc.CosmeticType x) => !deniedTypes.Contains(x)) && MetaManager.instance.GetCosmeticsToUnequip(MetaManager.instance.cosmeticEquipped, cosmeticAsset2).Count <= 0)
				{
					list.Add(cosmeticAsset2);
				}
			}
		}
		foreach (IGrouping<SemiFunc.CosmeticType, CosmeticAsset> item2 in from c in list
			group c by c.type)
		{
			if (!(Random.value < 0.25f))
			{
				CosmeticAsset cosmeticAssetNew = item2.ElementAt(Random.Range(0, item2.Count()));
				MetaManager.instance.CosmeticEquip(cosmeticAssetNew, _isPreview: false);
				shouldSave = true;
			}
		}
		for (int num2 = 0; num2 < MetaManager.instance.colorsEquipped.Length; num2++)
		{
			if (!(Random.value < 0.25f) && !deniedTypes.Contains((SemiFunc.CosmeticType)num2))
			{
				int colorID = Random.Range(0, MetaManager.instance.colors.Count);
				MetaManager.instance.CosmeticColorSet(num2, colorID);
				shouldSave = true;
			}
		}
		MetaManager.instance.CosmeticPreviewSet(_state: false);
		MetaManager.instance.CosmeticPlayerUpdateLocal(_synced: false);
		if (!randomizePopup.dropdownButtons[1].menuButtonPopUp.disabled)
		{
			randomizePopup.dropdownButtons[1].menuButtonPopUp.disabled = true;
			DataDirector.instance.SettingValueSet(DataDirector.Setting.PopupCosmeticsRandomizeBody, 1);
			DataDirector.instance.SaveSettings();
		}
	}

	public void RandomizeCosmeticsButton()
	{
		if (MenuManager.instance.currentMenuPageIndex != MenuPageIndex.Cosmetics)
		{
			return;
		}
		TriggerClickAnimationsPopup(((Component)randomizePopup.dropdownButtons[2]).GetComponentInChildren<SemiUI>(), isToggle: false);
		List<SemiFunc.CosmeticType> deniedTypes = (from x in MetaManager.instance.cosmeticTypeAssets
			where x.meshSwitch
			select x.type).ToList();
		foreach (int item in MetaManager.instance.cosmeticEquipped.ToList())
		{
			if (item >= 0 && item < MetaManager.instance.cosmeticAssets.Count)
			{
				CosmeticAsset cosmeticAsset = MetaManager.instance.cosmeticAssets[item];
				if (Object.op_Implicit((Object)(object)cosmeticAsset) && !deniedTypes.Contains(cosmeticAsset.type))
				{
					MetaManager.instance.CosmeticUnequip(cosmeticAsset, _isPreview: false);
					shouldSave = true;
				}
			}
		}
		List<CosmeticAsset> list = new List<CosmeticAsset>();
		for (int num = 0; num < MetaManager.instance.cosmeticAssets.Count; num++)
		{
			if (MetaManager.instance.cosmeticUnlocks.Contains(num))
			{
				CosmeticAsset cosmeticAsset2 = MetaManager.instance.cosmeticAssets[num];
				if (Object.op_Implicit((Object)(object)cosmeticAsset2) && !deniedTypes.Contains(cosmeticAsset2.type) && !MetaManager.instance.cosmeticTypeAssets[(int)cosmeticAsset2.type].disabledTypeList.Any((SemiFunc.CosmeticType x) => !deniedTypes.Contains(x)) && MetaManager.instance.GetCosmeticsToUnequip(MetaManager.instance.cosmeticEquipped, cosmeticAsset2).Count <= 0)
				{
					list.Add(cosmeticAsset2);
				}
			}
		}
		foreach (IGrouping<SemiFunc.CosmeticType, CosmeticAsset> item2 in from c in list
			group c by c.type)
		{
			if (!(Random.value < 0.25f))
			{
				CosmeticAsset cosmeticAssetNew = item2.ElementAt(Random.Range(0, item2.Count()));
				MetaManager.instance.CosmeticEquip(cosmeticAssetNew, _isPreview: false);
				shouldSave = true;
			}
		}
		for (int num2 = 0; num2 < MetaManager.instance.colorsEquipped.Length; num2++)
		{
			if (!(Random.value < 0.25f) && !deniedTypes.Contains((SemiFunc.CosmeticType)num2))
			{
				int colorID = Random.Range(0, MetaManager.instance.colors.Count);
				MetaManager.instance.CosmeticColorSet(num2, colorID);
				shouldSave = true;
			}
		}
		MetaManager.instance.CosmeticPreviewSet(_state: false);
		MetaManager.instance.CosmeticPlayerUpdateLocal(_synced: false);
		if (!randomizePopup.dropdownButtons[2].menuButtonPopUp.disabled)
		{
			randomizePopup.dropdownButtons[2].menuButtonPopUp.disabled = true;
			DataDirector.instance.SettingValueSet(DataDirector.Setting.PopupCosmeticsRandomizeCosmetics, 1);
			DataDirector.instance.SaveSettings();
		}
	}

	public void TogglePopupReset()
	{
		TriggerClickAnimationsPopup(resetPopup.toggleSemiUI, isToggle: true);
		colorPopup.SetState(_state: false);
		randomizePopup.SetState(_state: false);
		int siblingIndex = Mathf.Max(new int[3]
		{
			colorPopup.dropdownObj.transform.GetSiblingIndex(),
			randomizePopup.dropdownObj.transform.GetSiblingIndex(),
			resetPopup.dropdownObj.transform.GetSiblingIndex()
		});
		resetPopup.dropdownObj.transform.SetSiblingIndex(siblingIndex);
		resetPopup.SetState(!resetPopup.dropdownActive);
	}

	public void ResetAllButton()
	{
		if (MenuManager.instance.currentMenuPageIndex != MenuPageIndex.Cosmetics)
		{
			return;
		}
		TriggerClickAnimationsPopup(((Component)resetPopup.dropdownButtons[0]).GetComponentInChildren<SemiUI>(), isToggle: false);
		foreach (int item in MetaManager.instance.cosmeticEquipped.ToList())
		{
			if (item >= 0 && item < MetaManager.instance.cosmeticAssets.Count)
			{
				CosmeticAsset cosmeticAsset = MetaManager.instance.cosmeticAssets[item];
				MetaManager.instance.CosmeticUnequip(cosmeticAsset, _isPreview: false);
			}
		}
		for (int i = 0; i < MetaManager.instance.colorsEquipped.Length; i++)
		{
			MetaManager.instance.CosmeticColorSet(i, 0);
		}
		shouldSave = true;
		MetaManager.instance.CosmeticPreviewSet(_state: false);
		MetaManager.instance.CosmeticPlayerUpdateLocal(_synced: false);
		if (!resetPopup.dropdownButtons[0].menuButtonPopUp.disabled)
		{
			resetPopup.dropdownButtons[0].menuButtonPopUp.disabled = true;
			DataDirector.instance.SettingValueSet(DataDirector.Setting.PopupCosmeticsResetAll, 1);
			DataDirector.instance.SaveSettings();
		}
	}

	public void ResetBodyButton()
	{
		if (MenuManager.instance.currentMenuPageIndex != MenuPageIndex.Cosmetics)
		{
			return;
		}
		TriggerClickAnimationsPopup(((Component)resetPopup.dropdownButtons[1]).GetComponentInChildren<SemiUI>(), isToggle: false);
		List<SemiFunc.CosmeticType> list = (from x in MetaManager.instance.cosmeticTypeAssets
			where !x.meshSwitch
			select x.type).ToList();
		foreach (int item in MetaManager.instance.cosmeticEquipped.ToList())
		{
			if (item >= 0 && item < MetaManager.instance.cosmeticAssets.Count)
			{
				CosmeticAsset cosmeticAsset = MetaManager.instance.cosmeticAssets[item];
				if (Object.op_Implicit((Object)(object)cosmeticAsset) && !list.Contains(cosmeticAsset.type))
				{
					MetaManager.instance.CosmeticUnequip(cosmeticAsset, _isPreview: false);
					shouldSave = true;
				}
			}
		}
		for (int num = 0; num < MetaManager.instance.colorsEquipped.Length; num++)
		{
			if (!list.Contains((SemiFunc.CosmeticType)num))
			{
				MetaManager.instance.CosmeticColorSet(num, 0);
				shouldSave = true;
			}
		}
		MetaManager.instance.CosmeticPreviewSet(_state: false);
		MetaManager.instance.CosmeticPlayerUpdateLocal(_synced: false);
		if (!resetPopup.dropdownButtons[1].menuButtonPopUp.disabled)
		{
			resetPopup.dropdownButtons[1].menuButtonPopUp.disabled = true;
			DataDirector.instance.SettingValueSet(DataDirector.Setting.PopupCosmeticsResetBody, 1);
			DataDirector.instance.SaveSettings();
		}
	}

	public void ResetCosmeticsButton()
	{
		if (MenuManager.instance.currentMenuPageIndex != MenuPageIndex.Cosmetics)
		{
			return;
		}
		TriggerClickAnimationsPopup(((Component)resetPopup.dropdownButtons[2]).GetComponentInChildren<SemiUI>(), isToggle: false);
		List<SemiFunc.CosmeticType> list = (from x in MetaManager.instance.cosmeticTypeAssets
			where x.meshSwitch
			select x.type).ToList();
		foreach (int item in MetaManager.instance.cosmeticEquipped.ToList())
		{
			if (item >= 0 && item < MetaManager.instance.cosmeticAssets.Count)
			{
				CosmeticAsset cosmeticAsset = MetaManager.instance.cosmeticAssets[item];
				if (Object.op_Implicit((Object)(object)cosmeticAsset) && !list.Contains(cosmeticAsset.type))
				{
					MetaManager.instance.CosmeticUnequip(cosmeticAsset, _isPreview: false);
					shouldSave = true;
				}
			}
		}
		for (int num = 0; num < MetaManager.instance.colorsEquipped.Length; num++)
		{
			if (!list.Contains((SemiFunc.CosmeticType)num))
			{
				MetaManager.instance.CosmeticColorSet(num, 0);
				shouldSave = true;
			}
		}
		MetaManager.instance.CosmeticPreviewSet(_state: false);
		MetaManager.instance.CosmeticPlayerUpdateLocal(_synced: false);
		if (!resetPopup.dropdownButtons[2].menuButtonPopUp.disabled)
		{
			resetPopup.dropdownButtons[2].menuButtonPopUp.disabled = true;
			DataDirector.instance.SettingValueSet(DataDirector.Setting.PopupCosmeticsResetCosmetics, 1);
			DataDirector.instance.SaveSettings();
		}
	}

	private void TriggerClickAnimationsPopup(SemiUI _semiUI, bool isToggle)
	{
		if (isToggle)
		{
			_semiUI.SemiUISpringScale(-0.3f, 2f, 0.25f);
		}
		else
		{
			_semiUI.SemiUISpringScale(-0.3f, 2f, 0.25f);
		}
	}
}
