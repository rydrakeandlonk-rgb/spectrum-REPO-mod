using UnityEngine;
using UnityEngine.UI;

public class MenuSelectionBox : MonoBehaviour
{
	public static MenuSelectionBox instance;

	internal Vector3 targetPosition;

	internal Vector3 targetScale;

	private Vector3 currentScale;

	internal RawImage rawImage;

	internal RectTransform rectTransform;

	internal Vector3 originalPos;

	internal Vector3 originalScale;

	private float activeTargetTimer;

	private float prevPosTimer;

	private Vector3 prevPos;

	private Vector3 currentPos;

	private float clickTimer;

	private Color flashColor;

	internal MenuPage menuPage;

	internal bool firstSelection = true;

	internal bool isInScrollBox;

	internal MenuScrollBox menuScrollBox;

	internal MenuElementCosmeticCategoryScroll categoryScroll;

	private static readonly Color colorIdleDefault = new Color(0.08f, 0.2f, 0.4f, 0.75f);

	private static readonly Color colorMovingDefault = new Color(0.2f, 0.5f, 1f, 1f);

	private MenuSelectionBoxColor colorOverride;

	public AnimationCurve pulsateInCurve;

	public AnimationCurve pulsateOutCurve;

	private float pulsateLerp;

	private bool pulsateState;

	[RuntimeInitializeOnLoadMethod(/*Could not decode attribute arguments.*/)]
	private static void RuntimeInitializeOnLoad()
	{
		instance = null;
	}

	private void Awake()
	{
		rawImage = ((Component)this).GetComponentInChildren<RawImage>();
		menuPage = ((Component)this).GetComponentInParent<MenuPage>();
		rectTransform = ((Component)this).GetComponent<RectTransform>();
		menuScrollBox = ((Component)this).GetComponentInParent<MenuScrollBox>();
		categoryScroll = ((Component)this).GetComponentInParent<MenuElementCosmeticCategoryScroll>();
	}

	private void Start()
	{
		//IL_0007: Unknown result type (might be due to invalid IL or missing references)
		//IL_000c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0018: Unknown result type (might be due to invalid IL or missing references)
		//IL_0022: Unknown result type (might be due to invalid IL or missing references)
		//IL_0027: Unknown result type (might be due to invalid IL or missing references)
		//IL_0033: Unknown result type (might be due to invalid IL or missing references)
		//IL_0038: Unknown result type (might be due to invalid IL or missing references)
		//IL_0044: Unknown result type (might be due to invalid IL or missing references)
		//IL_0049: Unknown result type (might be due to invalid IL or missing references)
		targetPosition = ((Component)this).transform.localPosition;
		targetScale = ((Component)this).transform.localScale * 100f;
		originalPos = ((Component)this).transform.localPosition;
		originalScale = ((Component)this).transform.localScale;
		menuPage.selectionBox = this;
		isInScrollBox = false;
		if (Object.op_Implicit((Object)(object)menuScrollBox) || Object.op_Implicit((Object)(object)categoryScroll))
		{
			isInScrollBox = true;
		}
		else
		{
			instance = this;
		}
		MenuManager.instance.SelectionBoxAdd(this);
	}

	private void Update()
	{
		//IL_012f: Unknown result type (might be due to invalid IL or missing references)
		//IL_003b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0058: Unknown result type (might be due to invalid IL or missing references)
		//IL_005d: Unknown result type (might be due to invalid IL or missing references)
		//IL_006c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0071: Unknown result type (might be due to invalid IL or missing references)
		//IL_0085: Unknown result type (might be due to invalid IL or missing references)
		//IL_008f: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a9: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ae: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b5: Unknown result type (might be due to invalid IL or missing references)
		//IL_00bf: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c4: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d0: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d5: Unknown result type (might be due to invalid IL or missing references)
		//IL_01bd: Unknown result type (might be due to invalid IL or missing references)
		//IL_01c2: Unknown result type (might be due to invalid IL or missing references)
		//IL_01ce: Unknown result type (might be due to invalid IL or missing references)
		//IL_01d3: Unknown result type (might be due to invalid IL or missing references)
		//IL_0159: Unknown result type (might be due to invalid IL or missing references)
		//IL_01fd: Unknown result type (might be due to invalid IL or missing references)
		//IL_016b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0170: Unknown result type (might be due to invalid IL or missing references)
		//IL_017b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0180: Unknown result type (might be due to invalid IL or missing references)
		//IL_020f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0214: Unknown result type (might be due to invalid IL or missing references)
		//IL_0220: Unknown result type (might be due to invalid IL or missing references)
		//IL_01a3: Unknown result type (might be due to invalid IL or missing references)
		//IL_0192: Unknown result type (might be due to invalid IL or missing references)
		//IL_0253: Unknown result type (might be due to invalid IL or missing references)
		//IL_0259: Unknown result type (might be due to invalid IL or missing references)
		//IL_0269: Unknown result type (might be due to invalid IL or missing references)
		//IL_023b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0275: Unknown result type (might be due to invalid IL or missing references)
		//IL_027b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0285: Unknown result type (might be due to invalid IL or missing references)
		//IL_0295: Unknown result type (might be due to invalid IL or missing references)
		//IL_029a: Unknown result type (might be due to invalid IL or missing references)
		//IL_02f8: Unknown result type (might be due to invalid IL or missing references)
		//IL_02fd: Unknown result type (might be due to invalid IL or missing references)
		//IL_0302: Unknown result type (might be due to invalid IL or missing references)
		//IL_0318: Unknown result type (might be due to invalid IL or missing references)
		//IL_031d: Unknown result type (might be due to invalid IL or missing references)
		//IL_02d0: Unknown result type (might be due to invalid IL or missing references)
		//IL_02d5: Unknown result type (might be due to invalid IL or missing references)
		//IL_02da: Unknown result type (might be due to invalid IL or missing references)
		//IL_02f0: Unknown result type (might be due to invalid IL or missing references)
		//IL_02f5: Unknown result type (might be due to invalid IL or missing references)
		//IL_034c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0351: Unknown result type (might be due to invalid IL or missing references)
		//IL_0357: Unknown result type (might be due to invalid IL or missing references)
		//IL_035c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0434: Unknown result type (might be due to invalid IL or missing references)
		//IL_0445: Unknown result type (might be due to invalid IL or missing references)
		//IL_044a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0457: Unknown result type (might be due to invalid IL or missing references)
		//IL_03a2: Unknown result type (might be due to invalid IL or missing references)
		//IL_0395: Unknown result type (might be due to invalid IL or missing references)
		//IL_03a7: Unknown result type (might be due to invalid IL or missing references)
		//IL_03c2: Unknown result type (might be due to invalid IL or missing references)
		//IL_03b5: Unknown result type (might be due to invalid IL or missing references)
		//IL_03c7: Unknown result type (might be due to invalid IL or missing references)
		//IL_03cf: Unknown result type (might be due to invalid IL or missing references)
		//IL_03d5: Unknown result type (might be due to invalid IL or missing references)
		//IL_03f8: Unknown result type (might be due to invalid IL or missing references)
		//IL_03f9: Unknown result type (might be due to invalid IL or missing references)
		//IL_03fc: Unknown result type (might be due to invalid IL or missing references)
		//IL_0402: Unknown result type (might be due to invalid IL or missing references)
		//IL_0412: Unknown result type (might be due to invalid IL or missing references)
		//IL_03e8: Unknown result type (might be due to invalid IL or missing references)
		//IL_03ed: Unknown result type (might be due to invalid IL or missing references)
		if (menuPage.currentPageState != MenuPage.PageState.Active && !menuPage.addedPageOnTop)
		{
			((Graphic)rawImage).color = new Color(0.4f, 0.08f, 0.015f, 0f);
			RectTransform component = ((Component)menuPage).GetComponent<RectTransform>();
			Transform transform = ((Component)this).transform;
			Rect rect = component.rect;
			float num = rect.width / 2f;
			rect = component.rect;
			transform.localPosition = new Vector3(num, rect.height / 2f, ((Component)this).transform.localPosition.z);
			currentScale = new Vector3(0f, 0f, 1f);
			targetScale = currentScale * 100f;
			targetPosition = ((Transform)rectTransform).localPosition;
			activeTargetTimer = 0f;
			firstSelection = true;
			clickTimer = 0f;
			return;
		}
		if ((Object)(object)MenuManager.instance.activeSelectionBox != (Object)(object)this)
		{
			activeTargetTimer = 0f;
			((Graphic)rawImage).color = new Color(0.4f, 0.08f, 0.015f, 0f);
		}
		if (activeTargetTimer <= 0f && clickTimer <= 0f && ((Graphic)rawImage).color.a < 0.001f)
		{
			currentScale = Vector3.zero;
			if (((Component)this).transform.localScale != Vector3.zero)
			{
				((Component)this).transform.localScale = Vector3.zero;
			}
			((Transform)rectTransform).localPosition = targetPosition;
			return;
		}
		if (prevPosTimer <= 0f)
		{
			prevPos = currentPos;
			currentPos = ((Component)this).transform.localPosition;
			prevPosTimer = 1f / 120f;
		}
		else
		{
			prevPosTimer -= Time.deltaTime;
		}
		if (((Graphic)rawImage).color.a < 0.001f)
		{
			currentScale = Vector3.zero;
			((Transform)rectTransform).localPosition = targetPosition;
		}
		else if (isInScrollBox)
		{
			((Transform)rectTransform).localPosition = targetPosition;
		}
		else
		{
			((Transform)rectTransform).localPosition = Vector3.Lerp(((Transform)rectTransform).localPosition, targetPosition, 20f * Time.deltaTime);
		}
		currentScale = Vector3.Lerp(currentScale, targetScale / 100f, 20f * Time.deltaTime);
		pulsateLerp += 3f * Time.deltaTime;
		pulsateLerp = Mathf.Clamp01(pulsateLerp);
		Vector3 val = ((!pulsateState) ? Vector3.LerpUnclamped(Vector3.one, -Vector3.one, pulsateOutCurve.Evaluate(pulsateLerp)) : Vector3.LerpUnclamped(-Vector3.one, Vector3.one, pulsateInCurve.Evaluate(pulsateLerp)));
		if (pulsateLerp >= 1f)
		{
			pulsateLerp = 0f;
			pulsateState = !pulsateState;
		}
		((Component)this).transform.localScale = currentScale + val * 0.01f;
		if (activeTargetTimer > 0f)
		{
			activeTargetTimer -= Time.deltaTime;
			Color val2 = (Object.op_Implicit((Object)(object)colorOverride) ? colorOverride.colorIdle : colorIdleDefault);
			Color val3 = (Object.op_Implicit((Object)(object)colorOverride) ? colorOverride.colorMoving : colorMovingDefault);
			if (Vector3.Distance(((Component)this).transform.localPosition, targetPosition) <= 5f)
			{
				prevPos = currentPos;
			}
			((Graphic)rawImage).color = Color.Lerp(val2, val3, Vector3.Distance(prevPos, currentPos) * 0.5f);
		}
		else
		{
			Color val4 = new Color(0.4f, 0.08f, 0.015f, 0f);
			((Graphic)rawImage).color = Color.Lerp(((Graphic)rawImage).color, val4, 10f * Time.deltaTime);
		}
		ClickColorAnimate();
	}

	public void MenuSelectionBoxSetTarget(Vector3 pos, Vector3 scale, MenuPage parentPage, bool _isInScrollBox, MenuScrollBox _menuScrollBox, MenuElementCosmeticCategoryScroll _categoryScroll, Vector2 customScale = default(Vector2), MenuSelectionBoxColor _colorOverride = null)
	{
		//IL_005d: Unknown result type (might be due to invalid IL or missing references)
		//IL_005e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0066: Unknown result type (might be due to invalid IL or missing references)
		//IL_00de: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e4: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ef: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f5: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f6: Unknown result type (might be due to invalid IL or missing references)
		//IL_00fc: Unknown result type (might be due to invalid IL or missing references)
		//IL_00fd: Unknown result type (might be due to invalid IL or missing references)
		//IL_0104: Unknown result type (might be due to invalid IL or missing references)
		//IL_0110: Unknown result type (might be due to invalid IL or missing references)
		//IL_0115: Unknown result type (might be due to invalid IL or missing references)
		//IL_011a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0133: Unknown result type (might be due to invalid IL or missing references)
		//IL_013f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0144: Unknown result type (might be due to invalid IL or missing references)
		//IL_0149: Unknown result type (might be due to invalid IL or missing references)
		//IL_0150: Unknown result type (might be due to invalid IL or missing references)
		//IL_0164: Unknown result type (might be due to invalid IL or missing references)
		//IL_0169: Unknown result type (might be due to invalid IL or missing references)
		//IL_016e: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ab: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b2: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b7: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ce: Unknown result type (might be due to invalid IL or missing references)
		//IL_00cf: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d5: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d6: Unknown result type (might be due to invalid IL or missing references)
		if (_isInScrollBox != isInScrollBox || (_isInScrollBox && ((Object)(object)_menuScrollBox != (Object)(object)menuScrollBox || (Object)(object)_categoryScroll != (Object)(object)categoryScroll)))
		{
			MenuSelectionBox menuSelectionBox = MenuManager.instance.SelectionBoxGetCorrect(parentPage, _menuScrollBox, _categoryScroll);
			if (Object.op_Implicit((Object)(object)menuSelectionBox))
			{
				MenuManager.instance.SetActiveSelectionBox(menuSelectionBox);
				parentPage.selectionBox = menuSelectionBox;
				menuSelectionBox.Reinstate();
				menuSelectionBox.MenuSelectionBoxSetTarget(pos, scale, parentPage, _isInScrollBox, _menuScrollBox, _categoryScroll, customScale, _colorOverride);
			}
			return;
		}
		MenuManager.instance.SetActiveSelectionBox(this);
		if ((Object)(object)instance != (Object)(object)this)
		{
			Reinstate();
		}
		colorOverride = _colorOverride;
		if (firstSelection)
		{
			firstSelection = false;
			((Component)this).transform.localPosition = pos;
			currentScale = Vector3.zero;
			((Component)this).transform.localScale = currentScale;
			targetPosition = pos;
			targetScale = scale;
		}
		else
		{
			pos = new Vector3(pos.x, pos.y, 0f);
			targetPosition = pos;
			targetScale = scale + new Vector3(customScale.x, customScale.y, 0f);
			float num = targetScale.y * 0.2f;
			targetScale += new Vector3(num, num, 0f);
			targetPosition += new Vector3(0f, 0f, 0f);
			activeTargetTimer = 0.2f;
		}
	}

	public void SetClick(Color color)
	{
		//IL_0001: Unknown result type (might be due to invalid IL or missing references)
		//IL_0002: Unknown result type (might be due to invalid IL or missing references)
		flashColor = color;
		clickTimer = 1f;
	}

	private void ClickColorAnimate()
	{
		//IL_000f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0014: Unknown result type (might be due to invalid IL or missing references)
		//IL_002f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0022: Unknown result type (might be due to invalid IL or missing references)
		//IL_0034: Unknown result type (might be due to invalid IL or missing references)
		//IL_003b: Unknown result type (might be due to invalid IL or missing references)
		//IL_003c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0049: Unknown result type (might be due to invalid IL or missing references)
		if (!(clickTimer <= 0f))
		{
			Color val = flashColor;
			Color val2 = (Object.op_Implicit((Object)(object)colorOverride) ? colorOverride.colorIdle : colorIdleDefault);
			((Graphic)rawImage).color = Color.Lerp(val, val2, 1f - clickTimer);
			clickTimer -= Time.deltaTime * 10f;
		}
	}

	private void OnEnable()
	{
		//IL_0007: Unknown result type (might be due to invalid IL or missing references)
		//IL_0013: Unknown result type (might be due to invalid IL or missing references)
		//IL_0018: Unknown result type (might be due to invalid IL or missing references)
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_0030: Unknown result type (might be due to invalid IL or missing references)
		//IL_003a: Unknown result type (might be due to invalid IL or missing references)
		//IL_003f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0046: Unknown result type (might be due to invalid IL or missing references)
		//IL_004b: Unknown result type (might be due to invalid IL or missing references)
		((Component)this).transform.localPosition = originalPos;
		currentScale = originalScale;
		((Component)this).transform.localScale = originalScale;
		targetScale = originalScale * 100f;
		targetPosition = originalPos;
	}

	private void OnDestroy()
	{
		MenuManager.instance.SelectionBoxRemove(this);
	}

	public void Reinstate()
	{
		instance = this;
	}

	static MenuSelectionBox()
	{
		//IL_0014: Unknown result type (might be due to invalid IL or missing references)
		//IL_0019: Unknown result type (might be due to invalid IL or missing references)
		//IL_0032: Unknown result type (might be due to invalid IL or missing references)
		//IL_0037: Unknown result type (might be due to invalid IL or missing references)
	}
}
