using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

public class MenuElementCosmeticCategoryScroll : MonoBehaviour
{
	private class Arrow
	{
		public GameObject gameObject;

		public bool show;

		public bool initialized;

		public float animationLerp = 1f;

		public Vector3 scalePrevious;

		public Vector3 scale;

		public RectTransform rectTransform;

		public Vector2 positionOriginal;

		public float positionOffset;

		public bool positionSnap = true;

		public SpringFloat bounceSpring = new SpringFloat
		{
			damping = 0.35f,
			speed = 20f,
			lastPosition = 1f
		};
	}

	public enum ScrollAlignment
	{
		Left,
		Center,
		Right
	}

	public ScrollRect scrollRect;

	public float scrollSpeed = 5f;

	public GameObject buttonLeft;

	public GameObject buttonRight;

	public GameObject gradientLeft;

	public GameObject gradientRight;

	public MenuSelectionBox menuSelectionBox;

	[Space]
	public AnimationCurve arrowIntroCurve;

	public AnimationCurve arrowOutroCurve;

	public float tabPromptsInset;

	public float arrowBounceStrength = 12f;

	public float tabPromptsGlyphPopStrength = 6f;

	private Arrow arrowLeft;

	private Arrow arrowRight;

	private bool canScrollLeft;

	private bool canScrollRight;

	private bool canScroll;

	private bool buttonsReady;

	private RectTransform rectTransform;

	private MenuPage parentPage;

	private float scrollWidth;

	private int currentLeftIndex;

	private Coroutine scrollRoutine;

	private Vector2 smoothScrollToTargetPos;

	private MenuPageCosmetics menuPageCosmetics;

	private MenuButton buttonLeftMenuButton;

	private MenuButton buttonRightMenuButton;

	private TextMeshProUGUI buttonLeftText;

	private TextMeshProUGUI buttonRightText;

	private string buttonLeftTextOriginal;

	private string buttonRightTextOriginal;

	private bool tabPromptsDirty = true;

	private bool tabPromptsShown;

	private bool tabPromptsGlyphsChanged;

	private void Awake()
	{
		rectTransform = ((Component)this).GetComponent<RectTransform>();
		parentPage = ((Component)this).GetComponentInParent<MenuPage>();
		menuPageCosmetics = ((Component)parentPage).GetComponent<MenuPageCosmetics>();
		arrowLeft = ArrowCreate(buttonLeft);
		arrowRight = ArrowCreate(buttonRight);
		if (Object.op_Implicit((Object)(object)buttonLeft))
		{
			buttonLeft.SetActive(false);
		}
		if (Object.op_Implicit((Object)(object)buttonRight))
		{
			buttonRight.SetActive(false);
		}
		if (Object.op_Implicit((Object)(object)buttonLeft))
		{
			buttonLeftMenuButton = buttonLeft.GetComponentInChildren<MenuButton>(true);
			buttonLeftText = buttonLeft.GetComponentInChildren<TextMeshProUGUI>(true);
		}
		if (Object.op_Implicit((Object)(object)buttonRight))
		{
			buttonRightMenuButton = buttonRight.GetComponentInChildren<MenuButton>(true);
			buttonRightText = buttonRight.GetComponentInChildren<TextMeshProUGUI>(true);
		}
		if (Object.op_Implicit((Object)(object)buttonLeftText))
		{
			buttonLeftTextOriginal = ((TMP_Text)buttonLeftText).text;
		}
		if (Object.op_Implicit((Object)(object)buttonRightText))
		{
			buttonRightTextOriginal = ((TMP_Text)buttonRightText).text;
		}
	}

	private Arrow ArrowCreate(GameObject _button)
	{
		//IL_0035: Unknown result type (might be due to invalid IL or missing references)
		//IL_003a: Unknown result type (might be due to invalid IL or missing references)
		Arrow arrow = new Arrow
		{
			gameObject = _button
		};
		if (Object.op_Implicit((Object)(object)_button))
		{
			arrow.rectTransform = _button.GetComponent<RectTransform>();
			if (Object.op_Implicit((Object)(object)arrow.rectTransform))
			{
				arrow.positionOriginal = arrow.rectTransform.anchoredPosition;
			}
		}
		return arrow;
	}

	private void OnEnable()
	{
		InputGlyphs.OnGlyphsChanged += TabPromptsDirtySet;
		if (Object.op_Implicit((Object)(object)InputManager.instance))
		{
			InputManager.instance.OnDeviceTypeChanged += TabPromptsDirtySet;
		}
		tabPromptsDirty = true;
		tabPromptsGlyphsChanged = false;
	}

	private void OnDisable()
	{
		InputGlyphs.OnGlyphsChanged -= TabPromptsDirtySet;
		if (Object.op_Implicit((Object)(object)InputManager.instance))
		{
			InputManager.instance.OnDeviceTypeChanged -= TabPromptsDirtySet;
		}
	}

	private void OnDestroy()
	{
		InputGlyphs.OnGlyphsChanged -= TabPromptsDirtySet;
		if (Object.op_Implicit((Object)(object)InputManager.instance))
		{
			InputManager.instance.OnDeviceTypeChanged -= TabPromptsDirtySet;
		}
	}

	private void TabPromptsDirtySet()
	{
		tabPromptsDirty = true;
		tabPromptsGlyphsChanged = true;
	}

	private void TabPromptsDirtySet(InputDeviceType _deviceType)
	{
		TabPromptsDirtySet();
	}

	private void TabPromptsUpdate(bool isCategoryRow)
	{
		if (isCategoryRow != tabPromptsShown || tabPromptsDirty)
		{
			if (isCategoryRow && tabPromptsShown && tabPromptsGlyphsChanged)
			{
				arrowLeft.bounceSpring.springVelocity = tabPromptsGlyphPopStrength;
				arrowRight.bounceSpring.springVelocity = tabPromptsGlyphPopStrength;
			}
			tabPromptsShown = isCategoryRow;
			tabPromptsDirty = false;
			tabPromptsGlyphsChanged = false;
			ArrowTextSet(buttonLeftMenuButton, buttonLeftText, isCategoryRow ? InputGlyphs.GetSpriteTag(InputKey.UITabLeft) : buttonLeftTextOriginal);
			ArrowTextSet(buttonRightMenuButton, buttonRightText, isCategoryRow ? InputGlyphs.GetSpriteTag(InputKey.UITabRight) : buttonRightTextOriginal);
		}
	}

	private void ArrowTextSet(MenuButton menuButton, TextMeshProUGUI label, string text)
	{
		if (Object.op_Implicit((Object)(object)menuButton))
		{
			menuButton.buttonTextString = text;
		}
		if (Object.op_Implicit((Object)(object)label))
		{
			((TMP_Text)label).text = text;
		}
	}

	private void Start()
	{
		((MonoBehaviour)this).StartCoroutine(UpdateAfterLayout());
	}

	private void Update()
	{
		if (buttonsReady)
		{
			bool flag = Object.op_Implicit((Object)(object)menuPageCosmetics) && (Object)(object)menuPageCosmetics.categoriesHolder == (Object)(object)this;
			TabPromptsUpdate(flag);
			bool show = flag || canScrollLeft;
			bool show2 = flag || canScrollRight;
			ArrowAnimate(arrowLeft, show);
			ArrowAnimate(arrowRight, show2);
			ArrowPositionUpdate(flag);
			ArrowInteractableSet(buttonLeftMenuButton, !flag || canScrollLeft);
			ArrowInteractableSet(buttonRightMenuButton, !flag || canScrollRight);
			if (Object.op_Implicit((Object)(object)gradientLeft) && gradientLeft.activeSelf != canScrollLeft)
			{
				gradientLeft.SetActive(canScrollLeft);
			}
			if (Object.op_Implicit((Object)(object)gradientRight) && gradientRight.activeSelf != canScrollRight)
			{
				gradientRight.SetActive(canScrollRight);
			}
		}
	}

	private void ArrowAnimate(Arrow arrow, bool show)
	{
		//IL_003b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0034: Unknown result type (might be due to invalid IL or missing references)
		//IL_008f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0087: Unknown result type (might be due to invalid IL or missing references)
		//IL_0040: Unknown result type (might be due to invalid IL or missing references)
		//IL_0047: Unknown result type (might be due to invalid IL or missing references)
		//IL_017f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0199: Unknown result type (might be due to invalid IL or missing references)
		//IL_013f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0144: Unknown result type (might be due to invalid IL or missing references)
		//IL_015a: Unknown result type (might be due to invalid IL or missing references)
		//IL_015f: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f1: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f6: Unknown result type (might be due to invalid IL or missing references)
		//IL_010c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0111: Unknown result type (might be due to invalid IL or missing references)
		//IL_0094: Unknown result type (might be due to invalid IL or missing references)
		if (!Object.op_Implicit((Object)(object)arrow.gameObject))
		{
			return;
		}
		Transform transform = arrow.gameObject.transform;
		if (!arrow.initialized)
		{
			arrow.initialized = true;
			arrow.show = show;
			arrow.scale = (show ? Vector3.one : Vector3.zero);
			transform.localScale = arrow.scale;
			arrow.gameObject.SetActive(show);
			return;
		}
		if (arrow.show != show)
		{
			arrow.show = show;
			arrow.animationLerp = 0f;
			arrow.scalePrevious = (arrow.gameObject.activeSelf ? arrow.scale : Vector3.zero);
			if (show && !arrow.gameObject.activeSelf)
			{
				arrow.positionSnap = true;
			}
			if (show)
			{
				arrow.gameObject.SetActive(true);
			}
		}
		if (arrow.show)
		{
			if (arrow.animationLerp < 1f)
			{
				arrow.animationLerp += Time.deltaTime * 5f;
				arrow.scale = Vector3.LerpUnclamped(arrow.scalePrevious, Vector3.one, arrowIntroCurve.Evaluate(arrow.animationLerp));
			}
		}
		else if (arrow.animationLerp < 1f)
		{
			arrow.animationLerp += Time.deltaTime * 10f;
			arrow.scale = Vector3.LerpUnclamped(arrow.scalePrevious, Vector3.zero, arrowOutroCurve.Evaluate(arrow.animationLerp));
			if (arrow.animationLerp >= 1f)
			{
				arrow.gameObject.SetActive(false);
			}
		}
		transform.localScale = arrow.scale * SemiFunc.SpringFloatGet(arrow.bounceSpring, 1f);
	}

	private void ArrowInteractableSet(MenuButton menuButton, bool state)
	{
		if (Object.op_Implicit((Object)(object)menuButton))
		{
			menuButton.disabled = !state;
			if (Object.op_Implicit((Object)(object)menuButton.menuSelectableElement) && ((Selectable)menuButton.menuSelectableElement).interactable != state)
			{
				((Selectable)menuButton.menuSelectableElement).interactable = state;
			}
		}
	}

	private void ArrowPositionUpdate(bool isCategoryRow)
	{
		//IL_0057: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0083: Unknown result type (might be due to invalid IL or missing references)
		//IL_0088: Unknown result type (might be due to invalid IL or missing references)
		//IL_009c: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a1: Unknown result type (might be due to invalid IL or missing references)
		float targetOffset = 0f;
		float targetOffset2 = 0f;
		if (isCategoryRow && !canScroll && Object.op_Implicit((Object)(object)arrowLeft.rectTransform) && Object.op_Implicit((Object)(object)arrowRight.rectTransform))
		{
			float x = ((Transform)arrowLeft.rectTransform).parent.lossyScale.x;
			float x2 = ((Transform)scrollRect.viewport).lossyScale.x;
			Rect rect = scrollRect.viewport.rect;
			float width = rect.width;
			rect = scrollRect.content.rect;
			float num = (width - rect.width) / 2f;
			if (x > 0f)
			{
				num *= x2 / x;
			}
			targetOffset = Mathf.Max(0f, num + tabPromptsInset);
			targetOffset2 = Mathf.Min(0f, 0f - num - tabPromptsInset);
		}
		ArrowPositionSet(arrowLeft, targetOffset);
		ArrowPositionSet(arrowRight, targetOffset2);
	}

	private void ArrowPositionSet(Arrow arrow, float targetOffset)
	{
		//IL_0051: Unknown result type (might be due to invalid IL or missing references)
		//IL_0061: Unknown result type (might be due to invalid IL or missing references)
		//IL_0066: Unknown result type (might be due to invalid IL or missing references)
		if (Object.op_Implicit((Object)(object)arrow.rectTransform) && arrow.show)
		{
			if (arrow.positionSnap)
			{
				arrow.positionSnap = false;
				arrow.positionOffset = targetOffset;
			}
			arrow.positionOffset = Mathf.Lerp(arrow.positionOffset, targetOffset, Time.deltaTime * 15f);
			arrow.rectTransform.anchoredPosition = arrow.positionOriginal + new Vector2(arrow.positionOffset, 0f);
		}
	}

	public void ArrowBounce(int direction)
	{
		Arrow arrow = ((direction < 0) ? arrowLeft : arrowRight);
		if (arrow != null)
		{
			arrow.bounceSpring.springVelocity = arrowBounceStrength;
		}
	}

	private IEnumerator UpdateAfterLayout()
	{
		yield return null;
		UpdateButtons();
	}

	public void ScrollLeft()
	{
		ArrowBounce(-1);
		if (scrollRoutine != null)
		{
			((MonoBehaviour)this).StopCoroutine(scrollRoutine);
			FinishScroll();
		}
		UpdateCurrentLeftIndex();
		if (currentLeftIndex > 0)
		{
			currentLeftIndex--;
			List<RectTransform> children = GetChildren();
			ScrollToShow(children[currentLeftIndex], ScrollAlignment.Left);
		}
	}

	public void ScrollRight()
	{
		//IL_0035: Unknown result type (might be due to invalid IL or missing references)
		//IL_003a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0061: Unknown result type (might be due to invalid IL or missing references)
		//IL_0066: Unknown result type (might be due to invalid IL or missing references)
		ArrowBounce(1);
		if (scrollRoutine != null)
		{
			((MonoBehaviour)this).StopCoroutine(scrollRoutine);
			FinishScroll();
		}
		List<RectTransform> children = GetChildren();
		RectTransform viewport = scrollRect.viewport;
		Rect rect = viewport.rect;
		float xMax = rect.xMax;
		Vector3[] array = new Vector3[4];
		for (int i = 0; i < children.Count; i++)
		{
			children[i].GetWorldCorners(array);
			if (((Transform)viewport).InverseTransformPoint(array[3]).x > xMax + 0.5f)
			{
				ScrollToShow(children[i], ScrollAlignment.Right);
				break;
			}
		}
	}

	public void UpdateButtons()
	{
		//IL_001a: Unknown result type (might be due to invalid IL or missing references)
		//IL_001f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0028: Unknown result type (might be due to invalid IL or missing references)
		//IL_002d: Unknown result type (might be due to invalid IL or missing references)
		//IL_009b: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a0: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a9: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ae: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00cd: Unknown result type (might be due to invalid IL or missing references)
		RectTransform content = scrollRect.content;
		RectTransform viewport = scrollRect.viewport;
		Rect rect = content.rect;
		float width = rect.width;
		rect = viewport.rect;
		canScroll = width > rect.width;
		float horizontalNormalizedPosition = scrollRect.horizontalNormalizedPosition;
		scrollRect.horizontal = canScroll;
		canScrollLeft = canScroll && horizontalNormalizedPosition > 0.001f;
		canScrollRight = canScroll && horizontalNormalizedPosition < 0.999f;
		buttonsReady = true;
		if (!canScroll)
		{
			rect = viewport.rect;
			float width2 = rect.width;
			rect = content.rect;
			float num = (width2 - rect.width) / 2f;
			content.anchoredPosition = new Vector2(num, content.anchoredPosition.y);
		}
	}

	public bool ScrollToShow(RectTransform child, ScrollAlignment alignment = ScrollAlignment.Center)
	{
		//IL_0033: Unknown result type (might be due to invalid IL or missing references)
		//IL_0038: Unknown result type (might be due to invalid IL or missing references)
		//IL_0042: Unknown result type (might be due to invalid IL or missing references)
		//IL_0047: Unknown result type (might be due to invalid IL or missing references)
		//IL_0065: Unknown result type (might be due to invalid IL or missing references)
		//IL_006a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0078: Unknown result type (might be due to invalid IL or missing references)
		//IL_007d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0098: Unknown result type (might be due to invalid IL or missing references)
		//IL_009d: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a7: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ac: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e4: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e9: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ca: Unknown result type (might be due to invalid IL or missing references)
		//IL_00cf: Unknown result type (might be due to invalid IL or missing references)
		//IL_010b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0120: Unknown result type (might be due to invalid IL or missing references)
		//IL_0125: Unknown result type (might be due to invalid IL or missing references)
		//IL_012f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0134: Unknown result type (might be due to invalid IL or missing references)
		//IL_015c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0166: Unknown result type (might be due to invalid IL or missing references)
		if (scrollRoutine != null)
		{
			((MonoBehaviour)this).StopCoroutine(scrollRoutine);
			FinishScroll();
		}
		RectTransform content = scrollRect.content;
		RectTransform viewport = scrollRect.viewport;
		Rect rect = content.rect;
		float width = rect.width;
		rect = viewport.rect;
		if (width <= rect.width)
		{
			return false;
		}
		Vector3[] array = new Vector3[4];
		child.GetWorldCorners(array);
		float x = ((Transform)viewport).InverseTransformPoint(array[0]).x;
		float x2 = ((Transform)viewport).InverseTransformPoint(array[3]).x;
		float num;
		switch (alignment)
		{
		case ScrollAlignment.Center:
		{
			float num2 = (x + x2) / 2f;
			rect = viewport.rect;
			float xMin2 = rect.xMin;
			rect = viewport.rect;
			float num3 = (xMin2 + rect.xMax) / 2f;
			num = num2 - num3;
			break;
		}
		case ScrollAlignment.Right:
		{
			rect = viewport.rect;
			float xMax = rect.xMax;
			num = x2 - xMax;
			break;
		}
		default:
		{
			rect = viewport.rect;
			float xMin = rect.xMin;
			num = x - xMin;
			break;
		}
		}
		if (Mathf.Approximately(num, 0f))
		{
			return false;
		}
		float num4 = content.anchoredPosition.x - num;
		rect = content.rect;
		float width2 = rect.width;
		rect = viewport.rect;
		float num5 = Mathf.Min(0f, 0f - (width2 - rect.width));
		num4 = Mathf.Clamp(num4, num5, 0f);
		scrollRoutine = ((MonoBehaviour)this).StartCoroutine(SmoothScrollTo(new Vector2(num4, content.anchoredPosition.y)));
		return true;
	}

	private IEnumerator SmoothScrollTo(Vector2 targetPos)
	{
		//IL_000e: Unknown result type (might be due to invalid IL or missing references)
		//IL_000f: Unknown result type (might be due to invalid IL or missing references)
		smoothScrollToTargetPos = targetPos;
		RectTransform content = scrollRect.content;
		Vector2 startPos = content.anchoredPosition;
		float t = 0f;
		while (t < 1f)
		{
			t += Time.deltaTime * scrollSpeed;
			content.anchoredPosition = Vector2.Lerp(startPos, targetPos, t);
			UpdateButtons();
			yield return null;
		}
		FinishScroll();
	}

	private void FinishScroll()
	{
		//IL_000c: Unknown result type (might be due to invalid IL or missing references)
		scrollRect.content.anchoredPosition = smoothScrollToTargetPos;
		UpdateButtons();
		UpdateCurrentLeftIndex();
		menuPageCosmetics.subCategoriesScrolling = false;
	}

	private List<RectTransform> GetChildren()
	{
		//IL_001f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0025: Expected Obj, but got Unknown
		List<RectTransform> list = new List<RectTransform>();
		foreach (RectTransform item in (Transform)scrollRect.content)
		{
			RectTransform val = item;
			LayoutElement component = ((Component)val).GetComponent<LayoutElement>();
			if (!Object.op_Implicit((Object)(object)component) || !component.ignoreLayout)
			{
				list.Add(val);
			}
		}
		return list;
	}

	private void UpdateCurrentLeftIndex()
	{
		//IL_0014: Unknown result type (might be due to invalid IL or missing references)
		//IL_0019: Unknown result type (might be due to invalid IL or missing references)
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_0029: Unknown result type (might be due to invalid IL or missing references)
		//IL_0053: Unknown result type (might be due to invalid IL or missing references)
		//IL_0058: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		List<RectTransform> children = GetChildren();
		RectTransform viewport = scrollRect.viewport;
		Rect rect = viewport.rect;
		float xMin = rect.xMin;
		rect = viewport.rect;
		float xMax = rect.xMax;
		Vector3[] array = new Vector3[4];
		for (int i = 0; i < children.Count; i++)
		{
			children[i].GetWorldCorners(array);
			float x = ((Transform)viewport).InverseTransformPoint(array[0]).x;
			float x2 = ((Transform)viewport).InverseTransformPoint(array[3]).x;
			if (x >= xMin - 0.5f && x2 <= xMax + 0.5f)
			{
				currentLeftIndex = i;
				break;
			}
		}
	}
}
