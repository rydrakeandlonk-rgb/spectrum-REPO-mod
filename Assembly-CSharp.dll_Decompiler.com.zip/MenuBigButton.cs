using TMPro;
using UnityEngine;
using UnityEngine.UI;

public class MenuBigButton : MonoBehaviour
{
	public enum State
	{
		Main,
		Edit
	}

	public string buttonTitle = "";

	public string buttonName = "NewButton";

	public RawImage mainButtonBG;

	public RawImage behindButtonBG;

	public MenuButton menuButton;

	public TextMeshProUGUI buttonTitleTextMesh;

	private Color mainButtonMainColor;

	private Color behindButtonMainColor;

	public LocalizedAsset pressNewButtonLocalized;

	public State state;

	private void Start()
	{
		//IL_0007: Unknown result type (might be due to invalid IL or missing references)
		//IL_000c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0018: Unknown result type (might be due to invalid IL or missing references)
		//IL_001d: Unknown result type (might be due to invalid IL or missing references)
		behindButtonMainColor = ((Graphic)behindButtonBG).color;
		mainButtonMainColor = ((Graphic)mainButtonBG).color;
	}

	private void Update()
	{
		switch (state)
		{
		case State.Main:
			StateMain();
			break;
		case State.Edit:
			StateEdit();
			break;
		}
	}

	private void StateMain()
	{
		//IL_0052: Unknown result type (might be due to invalid IL or missing references)
		//IL_0063: Unknown result type (might be due to invalid IL or missing references)
		//IL_0023: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Unknown result type (might be due to invalid IL or missing references)
		//IL_003f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0090: Unknown result type (might be due to invalid IL or missing references)
		//IL_009b: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a7: Unknown result type (might be due to invalid IL or missing references)
		if (menuButton.hovering)
		{
			Color color = new Color(0.7f, 0.2f, 0f, 1f);
			((Graphic)mainButtonBG).color = color;
			((Graphic)behindButtonBG).color = AssetManager.instance.colorYellow;
		}
		else
		{
			((Graphic)mainButtonBG).color = mainButtonMainColor;
			((Graphic)behindButtonBG).color = behindButtonMainColor;
		}
		if (menuButton.clicked)
		{
			Color color2 = new Color(1f, 0.5f, 0f, 1f);
			((Graphic)mainButtonBG).color = color2;
			((Graphic)behindButtonBG).color = Color.white;
		}
	}

	private void StateEdit()
	{
		//IL_00ae: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b9: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d5: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e0: Unknown result type (might be due to invalid IL or missing references)
		//IL_005e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0069: Unknown result type (might be due to invalid IL or missing references)
		//IL_0085: Unknown result type (might be due to invalid IL or missing references)
		//IL_0090: Unknown result type (might be due to invalid IL or missing references)
		//IL_0109: Unknown result type (might be due to invalid IL or missing references)
		//IL_0114: Unknown result type (might be due to invalid IL or missing references)
		//IL_0120: Unknown result type (might be due to invalid IL or missing references)
		((TMP_Text)menuButton.buttonText).text = "[" + (pressNewButtonLocalized?.GetLocalizedString() ?? "Press New Button") + "]";
		if (menuButton.hovering)
		{
			Color color = new Color(0.5f, 0.1f, 0f, 1f);
			((Graphic)mainButtonBG).color = color;
			color = new Color(1f, 0.5f, 0f, 1f);
			((Graphic)behindButtonBG).color = color;
		}
		else
		{
			Color color2 = new Color(0.5f, 0.1f, 0f, 1f);
			((Graphic)mainButtonBG).color = color2;
			color2 = new Color(0.7f, 0.2f, 0f, 1f);
			((Graphic)behindButtonBG).color = color2;
		}
		if (menuButton.clicked)
		{
			Color color3 = new Color(1f, 0.5f, 0f, 1f);
			((Graphic)mainButtonBG).color = color3;
			((Graphic)behindButtonBG).color = Color.white;
		}
	}
}
