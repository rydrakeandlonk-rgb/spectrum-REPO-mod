using System.Collections.Generic;
using UnityEngine;

public class PlayerCrown : MonoBehaviour
{
	public PlayerCosmetics playerCosmetics;

	private PlayerAvatar playerAvatar;

	private bool active;

	private bool disabled;

	private bool firstSetup = true;

	private List<CosmeticPlayerCrown> cosmeticPlayerCrowns = new List<CosmeticPlayerCrown>();

	private CosmeticPlayerCrown cosmeticPlayerCrownCurrent;

	private Transform targetTransform;

	private Transform targetTransformPrevious;

	[Space]
	public Transform crownMesh;

	[Space]
	public Transform defaultPosition;

	public AnimationCurve popCurveY;

	public AnimationCurve popCurveRotation;

	public Transform popTransform;

	private float popLerp = 1f;

	public SpringQuaternionSystem spring;

	private void Awake()
	{
		targetTransform = defaultPosition;
		((Component)crownMesh).gameObject.SetActive(false);
	}

	private void Update()
	{
		if (!DisableLogic())
		{
			FetchLogic();
			AnimationLogic();
			CosmeticHideLogic();
		}
	}

	private void LateUpdate()
	{
		if (!DisableLogic())
		{
			FollowLogic();
		}
	}

	private bool DisableLogic()
	{
		if (!LevelGenerator.Instance.Generated)
		{
			return true;
		}
		if ((Object.op_Implicit((Object)(object)playerCosmetics.playerAvatarVisuals) && Object.op_Implicit((Object)(object)playerCosmetics.playerAvatarVisuals.playerAvatar) && playerCosmetics.playerAvatarVisuals.playerAvatar.isDisabled) || (Object.op_Implicit((Object)(object)playerCosmetics.deathHead) && !playerCosmetics.deathHead.triggered))
		{
			((Component)crownMesh).gameObject.SetActive(false);
			disabled = true;
			return true;
		}
		if (disabled)
		{
			disabled = false;
			firstSetup = true;
		}
		return false;
	}

	private void FetchLogic()
	{
		if (!firstSetup && !SemiFunc.PerSecond(2f, (Object)(object)this))
		{
			return;
		}
		if (Object.op_Implicit((Object)(object)playerAvatar))
		{
			active = (Object)(object)playerAvatar == (Object)(object)SessionManager.instance.CrownedPlayerGet();
			if (Object.op_Implicit((Object)(object)DebugComputerCheck.instance) && !DebugComputerCheck.instance.DebugDisable && DebugComputerCheck.instance.PlayerDebug && DebugComputerCheck.instance.DebugTinyCrown)
			{
				active = true;
			}
			if (active != ((Component)crownMesh).gameObject.activeSelf)
			{
				((Component)crownMesh).gameObject.SetActive(active);
			}
			firstSetup = false;
		}
		else if (Object.op_Implicit((Object)(object)playerCosmetics.playerAvatarVisuals))
		{
			playerAvatar = playerCosmetics.playerAvatarVisuals.playerAvatar;
		}
		else if (Object.op_Implicit((Object)(object)playerCosmetics.deathHead))
		{
			playerAvatar = playerCosmetics.deathHead.playerAvatar;
		}
	}

	private void FollowLogic()
	{
		//IL_008d: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a3: Unknown result type (might be due to invalid IL or missing references)
		targetTransform = defaultPosition;
		if (Object.op_Implicit((Object)(object)cosmeticPlayerCrownCurrent))
		{
			if (!Object.op_Implicit((Object)(object)cosmeticPlayerCrownCurrent.cosmeticBlocked))
			{
				targetTransform = cosmeticPlayerCrownCurrent.targetMain;
			}
			else if (cosmeticPlayerCrownCurrent.cosmeticBlocked.blocked)
			{
				targetTransform = cosmeticPlayerCrownCurrent.targetBlocked;
			}
			else
			{
				targetTransform = cosmeticPlayerCrownCurrent.targetUnblocked;
			}
		}
		if (Object.op_Implicit((Object)(object)targetTransform))
		{
			((Component)this).transform.position = targetTransform.position;
			((Component)this).transform.rotation = targetTransform.rotation;
		}
	}

	private void AnimationLogic()
	{
		//IL_0076: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a7: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e9: Unknown result type (might be due to invalid IL or missing references)
		if ((Object)(object)targetTransform != (Object)(object)targetTransformPrevious)
		{
			popLerp = 0f;
			targetTransformPrevious = targetTransform;
		}
		if (popLerp < 1f)
		{
			popLerp += Time.deltaTime * 3f;
			popTransform.localPosition = new Vector3(0f, popCurveY.Evaluate(popLerp) * 0.05f, 0f);
			popTransform.localEulerAngles = new Vector3(popCurveRotation.Evaluate(popLerp) * 30f, 0f, 0f);
		}
		if (Object.op_Implicit((Object)(object)cosmeticPlayerCrownCurrent) && cosmeticPlayerCrownCurrent.disableSpring && Object.op_Implicit((Object)(object)targetTransform))
		{
			spring.transform.localRotation = targetTransform.localRotation;
		}
		else
		{
			spring.UpdateWorldSpace();
		}
	}

	private void CosmeticHideLogic()
	{
		if (active)
		{
			playerCosmetics.ConditionCustomSet(CosmeticCustomCondition.Type.Player_Crown);
		}
	}

	public void UpdateTarget()
	{
		cosmeticPlayerCrownCurrent = null;
		cosmeticPlayerCrowns.Clear();
		foreach (Cosmetic item in playerCosmetics.cosmeticEquipped)
		{
			CosmeticPlayerCrown componentInChildren = ((Component)item).GetComponentInChildren<CosmeticPlayerCrown>(true);
			if (Object.op_Implicit((Object)(object)componentInChildren))
			{
				cosmeticPlayerCrowns.Add(componentInChildren);
			}
		}
		int num = -999;
		foreach (CosmeticPlayerCrown cosmeticPlayerCrown in cosmeticPlayerCrowns)
		{
			if ((!((Object)(object)cosmeticPlayerCrown.targetMain == (Object)null) || Object.op_Implicit((Object)(object)cosmeticPlayerCrown.cosmeticBlocked)) && cosmeticPlayerCrown.priority > num)
			{
				num = cosmeticPlayerCrown.priority;
				cosmeticPlayerCrownCurrent = cosmeticPlayerCrown;
			}
		}
	}
}
