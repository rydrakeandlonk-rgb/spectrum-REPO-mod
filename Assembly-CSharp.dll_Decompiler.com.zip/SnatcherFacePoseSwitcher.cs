using System;
using System.Collections.Generic;
using UnityEngine;

public class SnatcherFacePoseSwitcher : MonoBehaviour
{
	public SemiEyes semiEyes;

	public Transform eyesLeftPivot;

	public Transform eyesRightPivot;

	public int eyesLeftSemiEyesIndex;

	public int eyesRightSemiEyesIndex = 1;

	[Space]
	public Transform faceBounceTransform;

	public float faceBounceTime = 0.25f;

	[Range(0f, 0.3f)]
	public float faceBounceSquish = 0.13f;

	[Range(0f, 0.2f)]
	public float faceBounceStretch = 0.07f;

	[Range(0f, 1f)]
	public float faceBounceSettle = 0.3f;

	[Space]
	public MeshFilter faceSurfaceMeshFilter;

	public Mesh[] faceSurfacePoses;

	[Space]
	public MeshFilter eyesLeftMeshFilter;

	public MeshFilter eyesRightMeshFilter;

	public Mesh[] eyesLeftPoses;

	public Mesh[] eyesRightPoses;

	[HideInInspector]
	public string[] eyesPoseNames;

	[HideInInspector]
	public int eyesPose;

	[Space]
	[HideInInspector]
	public string[] mouthPoseNames;

	[HideInInspector]
	public int mouthPose;

	private float faceBounceTimer;

	private EnemySnatcher enemySnatcher;

	private EnemySnatcherEyes enemySnatcherEyes;

	private readonly Dictionary<string, int> eyesPoseLookup = new Dictionary<string, int>(StringComparer.OrdinalIgnoreCase);

	private readonly Dictionary<string, int> mouthPoseLookup = new Dictionary<string, int>(StringComparer.OrdinalIgnoreCase);

	private void Awake()
	{
		enemySnatcher = ((Component)this).GetComponentInParent<EnemySnatcher>(true);
		enemySnatcherEyes = ((Component)this).GetComponentInParent<EnemySnatcherEyes>(true);
		EnemySnatcherFind();
		SemiEyesFind();
		PoseLookupBuild();
		PoseApply();
	}

	private void Update()
	{
		EnemySnatcherFind();
		FaceBounceTick();
	}

	private void LateUpdate()
	{
		EyesLookUpdate();
	}

	private void OnDisable()
	{
		//IL_001e: Unknown result type (might be due to invalid IL or missing references)
		faceBounceTimer = 0f;
		if (Object.op_Implicit((Object)(object)faceBounceTransform))
		{
			faceBounceTransform.localScale = Vector3.one;
		}
	}

	public bool FacePoseSet(int eyesPoseIndex, int mouthPoseIndex)
	{
		if (eyesPoseNames == null || eyesPoseNames.Length == 0)
		{
			return false;
		}
		if (mouthPoseNames == null || mouthPoseNames.Length == 0)
		{
			return false;
		}
		int num = Mathf.Clamp(eyesPoseIndex, 0, eyesPoseNames.Length - 1);
		int num2 = Mathf.Clamp(mouthPoseIndex, 0, mouthPoseNames.Length - 1);
		if (eyesPose == num && mouthPose == num2)
		{
			return false;
		}
		eyesPose = num;
		mouthPose = num2;
		PoseApply();
		FaceBounce();
		return true;
	}

	public bool FacePoseSet(string eyesPoseName, string mouthPoseName)
	{
		int num = EyesPoseIndex(eyesPoseName);
		int num2 = MouthPoseIndex(mouthPoseName);
		if (num < 0 || num2 < 0)
		{
			return false;
		}
		return FacePoseSet(num, num2);
	}

	public void EyesPoseSet(int poseIndex)
	{
		FacePoseSet(poseIndex, mouthPose);
	}

	public void EyesPoseSet(string poseName)
	{
		int num = EyesPoseIndex(poseName);
		if (num >= 0)
		{
			EyesPoseSet(num);
		}
	}

	public void MouthPoseSet(int poseIndex)
	{
		FacePoseSet(eyesPose, poseIndex);
	}

	public void MouthPoseSet(string poseName)
	{
		int num = MouthPoseIndex(poseName);
		if (num >= 0)
		{
			MouthPoseSet(num);
		}
	}

	public int EyesPoseIndex(string poseName)
	{
		if (string.IsNullOrEmpty(poseName))
		{
			return -1;
		}
		if (!eyesPoseLookup.TryGetValue(poseName, out var value))
		{
			return -1;
		}
		return value;
	}

	public int MouthPoseIndex(string poseName)
	{
		if (string.IsNullOrEmpty(poseName))
		{
			return -1;
		}
		if (!mouthPoseLookup.TryGetValue(poseName, out var value))
		{
			return -1;
		}
		return value;
	}

	public string EyesPoseName()
	{
		if (eyesPoseNames == null || eyesPose < 0 || eyesPose >= eyesPoseNames.Length)
		{
			return string.Empty;
		}
		return eyesPoseNames[eyesPose];
	}

	public string MouthPoseName()
	{
		if (mouthPoseNames == null || mouthPose < 0 || mouthPose >= mouthPoseNames.Length)
		{
			return string.Empty;
		}
		return mouthPoseNames[mouthPose];
	}

	public void FaceBounce()
	{
		if (Application.isPlaying && Object.op_Implicit((Object)(object)faceBounceTransform))
		{
			faceBounceTimer = Mathf.Max(faceBounceTime, 0.01f);
			FaceBounceScaleApply(0f);
		}
	}

	private void PoseLookupBuild()
	{
		eyesPoseLookup.Clear();
		mouthPoseLookup.Clear();
		PoseLookupBuild(eyesPoseNames, eyesPoseLookup);
		PoseLookupBuild(mouthPoseNames, mouthPoseLookup);
	}

	private void PoseLookupBuild(string[] _poseNames, Dictionary<string, int> _lookup)
	{
		if (_poseNames == null)
		{
			return;
		}
		for (int i = 0; i < _poseNames.Length; i++)
		{
			string text = _poseNames[i];
			if (!string.IsNullOrEmpty(text) && !_lookup.ContainsKey(text))
			{
				_lookup.Add(text, i);
			}
		}
	}

	private void PoseApply()
	{
		if (eyesPoseNames != null && eyesPoseNames.Length != 0 && mouthPoseNames != null && mouthPoseNames.Length != 0)
		{
			eyesPose = Mathf.Clamp(eyesPose, 0, eyesPoseNames.Length - 1);
			mouthPose = Mathf.Clamp(mouthPose, 0, mouthPoseNames.Length - 1);
			int poseIndex = eyesPose * mouthPoseNames.Length + mouthPose;
			MeshPoseSet(faceSurfaceMeshFilter, faceSurfacePoses, poseIndex);
			MeshPoseSet(eyesLeftMeshFilter, eyesLeftPoses, eyesPose);
			MeshPoseSet(eyesRightMeshFilter, eyesRightPoses, eyesPose);
		}
	}

	private void FaceBounceTick()
	{
		//IL_0021: Unknown result type (might be due to invalid IL or missing references)
		//IL_0026: Unknown result type (might be due to invalid IL or missing references)
		//IL_0038: Unknown result type (might be due to invalid IL or missing references)
		if (!Object.op_Implicit((Object)(object)faceBounceTransform))
		{
			return;
		}
		if (faceBounceTimer <= 0f)
		{
			if (faceBounceTransform.localScale != Vector3.one)
			{
				faceBounceTransform.localScale = Vector3.one;
			}
		}
		else
		{
			faceBounceTimer = Mathf.Max(0f, faceBounceTimer - Time.deltaTime);
			float time = 1f - faceBounceTimer / Mathf.Max(faceBounceTime, 0.01f);
			FaceBounceScaleApply(time);
		}
	}

	private void FaceBounceScaleApply(float time)
	{
		//IL_002c: Unknown result type (might be due to invalid IL or missing references)
		//IL_005d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0062: Unknown result type (might be due to invalid IL or missing references)
		//IL_0067: Unknown result type (might be due to invalid IL or missing references)
		//IL_006e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0073: Unknown result type (might be due to invalid IL or missing references)
		//IL_009a: Unknown result type (might be due to invalid IL or missing references)
		//IL_009b: Unknown result type (might be due to invalid IL or missing references)
		//IL_009e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0107: Unknown result type (might be due to invalid IL or missing references)
		//IL_0108: Unknown result type (might be due to invalid IL or missing references)
		//IL_010e: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d5: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d6: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d9: Unknown result type (might be due to invalid IL or missing references)
		Vector3 val = new Vector3(1f + faceBounceSquish, 1f - faceBounceSquish * 0.2f, 1f - faceBounceSquish);
		Vector3 val2 = new Vector3(1f - faceBounceStretch, 1f + faceBounceStretch * 0.2f, 1f + faceBounceStretch);
		Vector3 val3 = Vector3.LerpUnclamped(Vector3.one, val, faceBounceSettle);
		if (time < 0.36f)
		{
			float num = Mathf.SmoothStep(0f, 1f, time / 0.36f);
			faceBounceTransform.localScale = Vector3.LerpUnclamped(val, val2, num);
		}
		else if (time < 0.72f)
		{
			float num2 = Mathf.SmoothStep(0f, 1f, (time - 0.36f) / 0.36f);
			faceBounceTransform.localScale = Vector3.LerpUnclamped(val2, val3, num2);
		}
		else
		{
			float num3 = Mathf.SmoothStep(0f, 1f, (time - 0.72f) / 0.28f);
			faceBounceTransform.localScale = Vector3.LerpUnclamped(val3, Vector3.one, num3);
		}
	}

	private void SemiEyesFind()
	{
		if (!Object.op_Implicit((Object)(object)semiEyes))
		{
			Transform parent = ((Component)this).transform.parent;
			while (Object.op_Implicit((Object)(object)parent) && !Object.op_Implicit((Object)(object)semiEyes))
			{
				semiEyes = ((Component)parent).GetComponentInChildren<SemiEyes>(true);
				parent = parent.parent;
			}
		}
	}

	private void EnemySnatcherFind()
	{
		if (!Object.op_Implicit((Object)(object)enemySnatcher))
		{
			if (!Object.op_Implicit((Object)(object)enemySnatcherEyes))
			{
				enemySnatcherEyes = ((Component)this).GetComponentInParent<EnemySnatcherEyes>(true);
			}
			if (Object.op_Implicit((Object)(object)enemySnatcherEyes))
			{
				enemySnatcher = enemySnatcherEyes.enemySnatcher;
			}
		}
	}

	private void EyesLookUpdate()
	{
		if (Object.op_Implicit((Object)(object)semiEyes))
		{
			EyeLookApply(eyesLeftPivot, eyesLeftSemiEyesIndex);
			EyeLookApply(eyesRightPivot, eyesRightSemiEyesIndex);
		}
	}

	private void EyeLookApply(Transform _pivot, int _semiEyesIndex)
	{
		//IL_0025: Unknown result type (might be due to invalid IL or missing references)
		//IL_002a: Unknown result type (might be due to invalid IL or missing references)
		//IL_002c: Unknown result type (might be due to invalid IL or missing references)
		//IL_002d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0033: Unknown result type (might be due to invalid IL or missing references)
		//IL_0038: Unknown result type (might be due to invalid IL or missing references)
		//IL_003d: Unknown result type (might be due to invalid IL or missing references)
		//IL_003e: Unknown result type (might be due to invalid IL or missing references)
		if (Object.op_Implicit((Object)(object)_pivot))
		{
			Transform val = semiEyes.EyeTransformGet(_semiEyesIndex);
			if (Object.op_Implicit((Object)(object)val))
			{
				Quaternion localRotation = ((Component)this).transform.localRotation;
				_pivot.localRotation = Quaternion.Inverse(localRotation) * val.localRotation * localRotation;
			}
		}
	}

	private void MeshPoseSet(MeshFilter _meshFilter, Mesh[] _poses, int _poseIndex)
	{
		if (Object.op_Implicit((Object)(object)_meshFilter) && _poses != null && _poseIndex >= 0 && _poseIndex < _poses.Length && !((Object)(object)_meshFilter.sharedMesh == (Object)(object)_poses[_poseIndex]))
		{
			_meshFilter.sharedMesh = _poses[_poseIndex];
		}
	}
}
