using System.Collections.Generic;
using UnityEngine;

public class EnemySpinnyParticle : MonoBehaviour
{
	private ParticleSystem _particleSystem;

	public Gradient particleColor = new Gradient();

	private List<ParticleSystem> particleSystems = new List<ParticleSystem>();

	public bool playOnStart;

	private void Start()
	{
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0070: Unknown result type (might be due to invalid IL or missing references)
		//IL_0075: Unknown result type (might be due to invalid IL or missing references)
		//IL_0097: Unknown result type (might be due to invalid IL or missing references)
		//IL_009c: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b0: Unknown result type (might be due to invalid IL or missing references)
		//IL_00bb: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c0: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c8: Unknown result type (might be due to invalid IL or missing references)
		//IL_0088: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e5: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ea: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ee: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00db: Unknown result type (might be due to invalid IL or missing references)
		//IL_010f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0114: Unknown result type (might be due to invalid IL or missing references)
		//IL_0128: Unknown result type (might be due to invalid IL or missing references)
		_particleSystem = ((Component)this).GetComponent<ParticleSystem>();
		particleSystems = new List<ParticleSystem>(((Component)this).GetComponentsInChildren<ParticleSystem>());
		if ((Object)(object)_particleSystem != (Object)null && !particleSystems.Contains(_particleSystem))
		{
			particleSystems.Add(_particleSystem);
		}
		foreach (ParticleSystem particleSystem in particleSystems)
		{
			MainModule main = particleSystem.main;
			MinMaxGradient val = main.startColor;
			if (val.gradient == null)
			{
				main.startColor = MinMaxGradient.op_Implicit(particleColor);
			}
			val = main.startColor;
			main.startColor = MinMaxGradient.op_Implicit(ChangeColorsOfGradient(val.gradient, particleColor));
			ColorOverLifetimeModule colorOverLifetime = particleSystem.colorOverLifetime;
			val = colorOverLifetime.color;
			if (val.gradient == null)
			{
				colorOverLifetime.color = MinMaxGradient.op_Implicit(particleColor);
			}
			TrailModule trails = particleSystem.trails;
			MinMaxGradient colorOverTrail = trails.colorOverTrail;
			if (colorOverTrail.gradient == null)
			{
				colorOverTrail.gradient = particleColor;
			}
			val = colorOverLifetime.color;
			colorOverLifetime.color = MinMaxGradient.op_Implicit(ChangeColorsOfGradient(val.gradient, particleColor));
			colorOverTrail.gradient = ChangeColorsOfGradient(colorOverTrail.gradient, particleColor);
		}
		if (playOnStart)
		{
			PlayParticles();
		}
	}

	private Gradient ChangeColorsOfGradient(Gradient gradient, Gradient newColor)
	{
		//IL_0000: Unknown result type (might be due to invalid IL or missing references)
		//IL_0005: Unknown result type (might be due to invalid IL or missing references)
		//IL_0011: Unknown result type (might be due to invalid IL or missing references)
		//IL_001e: Expected Obj, but got Unknown
		return new Gradient
		{
			colorKeys = newColor.colorKeys,
			alphaKeys = gradient.alphaKeys
		};
	}

	public void PlayParticles()
	{
		if (Object.op_Implicit((Object)(object)_particleSystem))
		{
			_particleSystem.Play(true);
		}
		else
		{
			Debug.LogWarning((object)("Particle system not found on " + ((Object)((Component)this).gameObject).name));
		}
	}

	public EnemySpinnyParticle()
	{
		//IL_0001: Unknown result type (might be due to invalid IL or missing references)
		//IL_000b: Expected Obj, but got Unknown
	}
}
