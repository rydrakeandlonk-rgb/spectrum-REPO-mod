using System;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;

public class ModulePropSwitch : MonoBehaviour
{
	public enum Connection
	{
		Top,
		Right,
		Bot,
		Left,
		TopLeft,
		TopRight,
		RightTop,
		RightBot,
		BotRight,
		BotLeft,
		LeftBot,
		LeftTop,
		Start
	}

	internal Module Module;

	public GameObject ConnectedParent;

	public GameObject NotConnectedParent;

	private bool Connected;

	[Space(20f)]
	public Connection ConnectionSide;

	[HideInInspector]
	public string DebugState = "...";

	[HideInInspector]
	public bool DebugSwitch;

	public void Setup()
	{
		//IL_0099: Unknown result type (might be due to invalid IL or missing references)
		//IL_009e: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a1: Unknown result type (might be due to invalid IL or missing references)
		//IL_0042: Unknown result type (might be due to invalid IL or missing references)
		//IL_0047: Unknown result type (might be due to invalid IL or missing references)
		//IL_004a: Unknown result type (might be due to invalid IL or missing references)
		Quaternion localRotation;
		if (Module.type != Module.Type.Mega)
		{
			int num = 0;
			while (true)
			{
				float num2 = num;
				localRotation = ((Component)Module).transform.localRotation;
				if (num2 < localRotation.eulerAngles.y)
				{
					num += 90;
					ConnectionSide++;
					if (ConnectionSide > Connection.Left)
					{
						ConnectionSide = Connection.Top;
					}
					continue;
				}
				break;
			}
		}
		else
		{
			int num3 = 0;
			while (true)
			{
				float num4 = num3;
				localRotation = ((Component)Module).transform.localRotation;
				if (!(num4 < localRotation.eulerAngles.y))
				{
					break;
				}
				num3 += 90;
				for (int num5 = 2; num5 > 0; num5--)
				{
					ConnectionSide++;
					if (ConnectionSide > Connection.LeftTop)
					{
						ConnectionSide = Connection.TopLeft;
					}
				}
			}
		}
		if ((ConnectionSide == Connection.Top && Module.ConnectingTop) || (ConnectionSide == Connection.Right && Module.ConnectingRight) || (ConnectionSide == Connection.Bot && Module.ConnectingBottom) || (ConnectionSide == Connection.Left && Module.ConnectingLeft) || (ConnectionSide == Connection.TopLeft && Module.ConnectingTopLeft) || (ConnectionSide == Connection.TopRight && Module.ConnectingTopRight) || (ConnectionSide == Connection.RightTop && Module.ConnectingRightTop) || (ConnectionSide == Connection.RightBot && Module.ConnectingRightBot) || (ConnectionSide == Connection.BotRight && Module.ConnectingBottomRight) || (ConnectionSide == Connection.BotLeft && Module.ConnectingBottomLeft) || (ConnectionSide == Connection.LeftBot && Module.ConnectingLeftBot) || (ConnectionSide == Connection.LeftTop && Module.ConnectingLeftTop))
		{
			Connected = true;
		}
		if (Connected)
		{
			NotConnectedParent.SetActive(false);
			ConnectedParent.SetActive(true);
		}
		else
		{
			NotConnectedParent.SetActive(true);
			ConnectedParent.SetActive(false);
		}
	}

	public void Toggle()
	{
		SetConnected(DebugSwitch);
	}

	public void SetConnected(bool _connected)
	{
		if (_connected)
		{
			DebugSwitch = false;
			DebugState = "Connected";
			NotConnectedParent.SetActive(false);
			ConnectedParent.SetActive(true);
		}
		else
		{
			DebugSwitch = true;
			DebugState = "Not Connected";
			NotConnectedParent.SetActive(true);
			ConnectedParent.SetActive(false);
		}
	}

	private void OnDrawGizmos()
	{
		//IL_0006: Unknown result type (might be due to invalid IL or missing references)
		Gizmos.DrawIcon(((Component)this).transform.position, "ModulePropSwitch.png", true);
	}

	private IEnumerable<Connection> GetConnectionTypes()
	{
		return from Connection x in Enum.GetValues(typeof(Connection))
			orderby x.ToString()
			select x;
	}
}
