using System;
using System.Linq;
using System.Runtime.InteropServices;
using Newtonsoft.Json;
using Platforms;
using Unity.Services.Authentication;
using Unity.Services.Core;
using Unity.Services.Core.Environments;
using Unity.Services.RemoteConfig;
using UnityEngine;

public class RemoteConfigManager : MonoBehaviour
{
	[StructLayout(LayoutKind.Sequential, Size = 1)]
	public struct userAttributes
	{
	}

	public struct appAttributes
	{
		public string appBranch;

		public string platformType;
	}

	public struct filterAttributes
	{
		public string[] key;

		public string[] type;

		public string[] schemaId;
	}

	public static RemoteConfigManager instance;

	public bool fetching;

	private bool firstFetch = true;

	private filterAttributes lastFilterAttributes;

	[RuntimeInitializeOnLoadMethod(/*Could not decode attribute arguments.*/)]
	private static void RuntimeInitializeOnLoad()
	{
		instance = null;
	}

	private void Awake()
	{
		if (!Object.op_Implicit((Object)(object)instance))
		{
			instance = this;
			Object.DontDestroyOnLoad((Object)(object)((Component)this).gameObject);
		}
		else
		{
			Object.Destroy((Object)(object)((Component)this).gameObject);
		}
	}

	private void Start()
	{
		if (string.IsNullOrEmpty(Application.cloudProjectId))
		{
			Debug.LogWarning((object)"[RemoteConfig] No cloud project linked, skipping initialization.");
			return;
		}
		RemoteConfigService.Instance.SetEnvironmentID("55c5c421-60c3-4d9b-a704-971bf9c83ed4");
		if (PlatformManager.instance.IsInitialised())
		{
			RemoteConfigService.Instance.SetCustomUserID(PlatformManager.instance.GetPlatformUserId());
		}
		RemoteConfigService.Instance.FetchCompleted += ApplyRemoteConfig;
		FetchRemoteConfig();
	}

	internal async void FetchRemoteConfig(filterAttributes _filterAttributes = default(filterAttributes))
	{
		_ = 1;
		try
		{
			if ((int)Application.internetReachability == 0)
			{
				return;
			}
			if ((int)UnityServices.State == 0)
			{
				InitializationOptions val = new InitializationOptions();
				EnvironmentsOptionsExtensions.SetEnvironmentName(val, "production");
				await UnityServices.InitializeAsync(val);
			}
			if (!AuthenticationService.Instance.IsSignedIn)
			{
				await AuthenticationService.Instance.SignInAnonymouslyAsync((SignInOptions)null);
				Debug.Log((object)("Unity - Player ID: " + AuthenticationService.Instance.PlayerId));
			}
			if (!fetching)
			{
				fetching = true;
				lastFilterAttributes = _filterAttributes;
				userAttributes userAttributes2 = default;
				appAttributes appAttributes2 = default;
				if (PlatformManager.instance.IsInitialised())
				{
					appAttributes2.appBranch = PlatformManager.instance.GetGameBranch();
					appAttributes2.platformType = PlatformManager.instance.GetPlatformType().ToString();
				}
				RemoteConfigService.Instance.FetchConfigs<userAttributes, appAttributes, filterAttributes>(userAttributes2, appAttributes2, _filterAttributes);
			}
		}
		catch (Exception ex)
		{
			Debug.LogError((object)ex);
		}
	}

	private void OnDestroy()
	{
		RemoteConfigService.Instance.FetchCompleted -= ApplyRemoteConfig;
	}

	private void ApplyRemoteConfig(ConfigResponse configResponse)
	{
		//IL_0007: Unknown result type (might be due to invalid IL or missing references)
		//IL_0008: Unknown result type (might be due to invalid IL or missing references)
		//IL_000e: Invalid comparison between Unknown and I4
		//IL_0011: Unknown result type (might be due to invalid IL or missing references)
		//IL_0012: Unknown result type (might be due to invalid IL or missing references)
		//IL_0017: Unknown result type (might be due to invalid IL or missing references)
		//IL_0018: Unknown result type (might be due to invalid IL or missing references)
		//IL_002a: Expected I4, but got Unknown
		fetching = false;
		if ((int)configResponse.status != 2)
		{
			return;
		}
		ConfigOrigin requestOrigin = configResponse.requestOrigin;
		switch ((int)requestOrigin)
		{
		case 0:
			Debug.Log((object)"[RemoteConfig] No settings loaded this session and no local cache file exists; using default values.");
			break;
		case 1:
			Debug.Log((object)"[RemoteConfig] No settings loaded this session; using cached values from a previous session.");
			break;
		case 2:
			Debug.Log((object)"[RemoteConfig] New settings loaded this session; update values accordingly.");
			break;
		}
		if (!Application.isEditor)
		{
			if (lastFilterAttributes.key == null || lastFilterAttributes.key.Length == 0 || Enumerable.Contains(lastFilterAttributes.key, "news_msg"))
			{
				try
				{
					string json = RemoteConfigService.Instance.appConfig.GetJson("news_msg", "{}");
					if (Object.op_Implicit((Object)(object)MenuManager.instance))
					{
						JsonConvert.PopulateObject(json, (object)MenuManager.instance.marketingMessage);
						if (Object.op_Implicit((Object)(object)MenuPageMain.instance))
						{
							MenuPageMain.instance.UpdateMarketingMessage();
						}
					}
				}
				catch (Exception ex)
				{
					Debug.LogWarning((object)ex);
				}
			}
			if (lastFilterAttributes.key == null || lastFilterAttributes.key.Length == 0 || Enumerable.Contains(lastFilterAttributes.key, "dev_flags"))
			{
				try
				{
					string json2 = RemoteConfigService.Instance.appConfig.GetJson("dev_flags", "{}");
					if (Object.op_Implicit((Object)(object)PlatformManager.instance))
					{
						bool debug_console = PlatformManager.instance.developerFlags.debug_console;
						bool debug_overlay = PlatformManager.instance.developerFlags.debug_overlay;
						JsonConvert.PopulateObject(json2, (object)PlatformManager.instance.developerFlags);
						if (Enum.TryParse<SemiFunc.User>(PlatformManager.instance.developerFlags.debug_user, ignoreCase: true, out var result) && result != PlatformManager.instance.developerUser)
						{
							PlatformManager.instance.developerUser = result;
							Debug.Log((object)("DEVELOPER MODE: " + result.ToString().ToUpper() + " (REMOTE CONFIG)"));
						}
						if (Object.op_Implicit((Object)(object)DebugCommandHandler.instance))
						{
							if (debug_console != PlatformManager.instance.developerFlags.debug_console)
							{
								DebugCommandHandler.instance.RegisterDevCommands();
							}
							if (firstFetch && !Debug.isDebugBuild)
							{
								if (PlatformManager.instance.developerFlags.debug_overlay)
								{
									DebugCommandHandler.instance.debugOverlay = true;
								}
							}
							else if (!firstFetch && !PlatformManager.instance.developerFlags.debug_console && debug_overlay != PlatformManager.instance.developerFlags.debug_overlay)
							{
								DebugCommandHandler.instance.debugOverlay = PlatformManager.instance.developerFlags.debug_overlay;
							}
						}
					}
				}
				catch (Exception ex2)
				{
					Debug.LogWarning((object)ex2);
				}
			}
		}
		firstFetch = false;
	}
}
