using UnityEngine;

public class LowPassTrigger : MonoBehaviour
{
	private void Awake()
	{
		ColliderSetup(((Component)this).GetComponent<Collider>());
		Collider[] componentsInChildren = ((Component)this).GetComponentsInChildren<Collider>();
		foreach (Collider collider in componentsInChildren)
		{
			ColliderSetup(collider);
		}
	}

	private void ColliderSetup(Collider _collider)
	{
		if (Object.op_Implicit((Object)(object)_collider))
		{
			_collider.isTrigger = true;
			((Component)_collider).tag = "LowPassTrigger";
			((Component)_collider).gameObject.layer = LayerMask.NameToLayer("LowPassTrigger");
		}
	}

	private void OnDrawGizmos()
	{
		//IL_0006: Unknown result type (might be due to invalid IL or missing references)
		//IL_0033: Unknown result type (might be due to invalid IL or missing references)
		//IL_003e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0044: Unknown result type (might be due to invalid IL or missing references)
		//IL_0062: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0073: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a2: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ad: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d1: Unknown result type (might be due to invalid IL or missing references)
		//IL_00dc: Unknown result type (might be due to invalid IL or missing references)
		Gizmos.matrix = ((Component)this).transform.localToWorldMatrix;
		BoxCollider component = ((Component)this).GetComponent<BoxCollider>();
		if (Object.op_Implicit((Object)(object)component))
		{
			Gizmos.color = new Color(0.23f, 1f, 0.47f, 0.52f);
			Gizmos.DrawWireCube(component.center, component.size);
			Gizmos.color = new Color(0.19f, 1f, 0.68f, 0.27f);
			Gizmos.DrawCube(component.center, component.size);
			return;
		}
		SphereCollider component2 = ((Component)this).GetComponent<SphereCollider>();
		if (Object.op_Implicit((Object)(object)component2))
		{
			Gizmos.color = new Color(0.23f, 1f, 0.47f, 0.52f);
			Gizmos.DrawWireSphere(component2.center, component2.radius);
			Gizmos.color = new Color(0.19f, 1f, 0.68f, 0.27f);
			Gizmos.DrawSphere(component2.center, component2.radius);
		}
	}
}
