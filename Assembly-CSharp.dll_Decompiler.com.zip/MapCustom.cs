using System.Collections;
using UnityEngine;

public class MapCustom : MonoBehaviour
{
	public bool autoAdd = true;

	[Space]
	public Sprite sprite;

	public Color color = new Color(0f, 1f, 0.92f);

	internal MapCustomEntity mapCustomEntity;

	public float fadeAlpha = 0.3f;

	private void Start()
	{
		if (autoAdd)
		{
			((MonoBehaviour)this).StartCoroutine(AddToMap());
		}
	}

	private IEnumerator AddToMap()
	{
		while (!LevelGenerator.Instance.Generated)
		{
			yield return (object)new WaitForSeconds(0.1f);
		}
		Add();
	}

	public void Add()
	{
		//IL_000d: Unknown result type (might be due to invalid IL or missing references)
		Map.Instance.AddCustom(this, sprite, color);
	}

	public void Hide()
	{
		if (Object.op_Implicit((Object)(object)mapCustomEntity))
		{
			mapCustomEntity.Hide();
		}
	}

	public MapCustom()
	{
		//IL_0017: Unknown result type (might be due to invalid IL or missing references)
		//IL_001c: Unknown result type (might be due to invalid IL or missing references)
	}
}
