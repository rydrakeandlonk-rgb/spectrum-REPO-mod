using System.Collections;
using UnityEngine;

public class AnimatedOffset : MonoBehaviour
{
	internal bool Animating;

	private float ActiveTimer;

	public Vector3 PositionOffset;

	public Vector3 RotationOffset;

	[Space]
	public AnimationCurve IntroCurve;

	public float IntroSpeed;

	public Sound IntroSound;

	private float IntroLerp;

	[Space]
	public AnimationCurve OutroCurve;

	public float OutroSpeed;

	public Sound OutroSound;

	private float OutroLerp;

	private Coroutine animateCoroutine;

	public void Active(float time)
	{
		ActiveTimer = time;
		if (!Animating)
		{
			Animating = true;
			if (animateCoroutine != null)
			{
				((MonoBehaviour)this).StopCoroutine(animateCoroutine);
			}
			animateCoroutine = ((MonoBehaviour)this).StartCoroutine(Animate());
		}
	}

	private IEnumerator Animate()
	{
		while (Animating)
		{
			if (ActiveTimer > 0f)
			{
				if (IntroLerp == 0f)
				{
					IntroSound.Play(((Component)this).transform.position);
				}
				IntroLerp = Mathf.Clamp01(IntroLerp + IntroSpeed * Time.deltaTime);
				((Component)this).transform.localPosition = Vector3.Lerp(Vector3.zero, PositionOffset, IntroCurve.Evaluate(IntroLerp));
				((Component)this).transform.localRotation = Quaternion.Lerp(Quaternion.identity, Quaternion.Euler(RotationOffset), IntroCurve.Evaluate(IntroLerp));
				if (IntroLerp >= 1f)
				{
					ActiveTimer -= Time.deltaTime;
				}
				OutroLerp = 0f;
			}
			else
			{
				if (OutroLerp == 0f)
				{
					OutroSound.Play(((Component)this).transform.position);
				}
				OutroLerp = Mathf.Clamp01(OutroLerp + OutroSpeed * Time.deltaTime);
				((Component)this).transform.localPosition = Vector3.Lerp(PositionOffset, Vector3.zero, OutroCurve.Evaluate(OutroLerp));
				((Component)this).transform.localRotation = Quaternion.Lerp(Quaternion.Euler(RotationOffset), Quaternion.identity, OutroCurve.Evaluate(OutroLerp));
				if (OutroLerp >= 1f)
				{
					Animating = false;
				}
				IntroLerp = 0f;
			}
			yield return null;
		}
	}

	private void ResetAnimation()
	{
		//IL_0028: Unknown result type (might be due to invalid IL or missing references)
		//IL_0038: Unknown result type (might be due to invalid IL or missing references)
		if (animateCoroutine != null)
		{
			((MonoBehaviour)this).StopCoroutine(animateCoroutine);
			animateCoroutine = null;
		}
		Animating = false;
		((Component)this).transform.localPosition = Vector3.zero;
		((Component)this).transform.localRotation = Quaternion.identity;
		IntroLerp = 0f;
		OutroLerp = 0f;
		ActiveTimer = 0f;
	}

	private void OnEnable()
	{
		ResetAnimation();
	}
}
