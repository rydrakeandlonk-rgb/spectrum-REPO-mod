using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using Photon.Pun;
using Photon.Realtime;
using Unity.AI.Navigation;
using Unity.Profiling;
using UnityEngine;
using UnityEngine.AI;
using UnityEngine.SceneManagement;

public class LevelGenerator : MonoBehaviourPunCallbacks, IPunObservable
{
	public enum LevelState
	{
		Start,
		Load,
		Tiles,
		StartRoom,
		ModuleGeneration,
		ConnectObjects,
		BlockObjects,
		ModuleSpawnLocal,
		ModuleSpawnRemote,
		LevelPoint,
		Item,
		Valuable,
		PlayerSetup,
		PlayerSpawn,
		Enemy,
		Done
	}

	private enum NavMeshBuildState
	{
		Idle,
		Collecting,
		Building,
		Validating,
		Ready,
		Failed,
		Cancelled
	}

	[Serializable]
	public class Tile
	{
		public int x;

		public int y;

		public bool active;

		public bool first;

		public int connections;

		public bool connectedTop;

		public bool connectedRight;

		public bool connectedBot;

		public bool connectedLeft;

		public Module.Type type;

		public Module module;
	}

	[Serializable]
	public class MegaTile
	{
		public Tile[] tiles;
	}

	private sealed class ModuleSpawn
	{
		public PrefabRef prefab;

		public int x;

		public int y;

		public Vector3 position;

		public Vector3 rotation;

		public Module.Type type;

		public MegaTile megaTile;
	}

	public LevelState State;

	public static LevelGenerator Instance;

	[HideInInspector]
	public PhotonView PhotonView;

	internal PrefabRef DebugModule;

	internal PrefabRef DebugStartRoom;

	internal bool DebugNormal;

	internal bool DebugPassage;

	internal bool DebugDeadEnd;

	internal bool DebugExtraction;

	internal bool DebugMega;

	internal bool DebugSpecial;

	internal int DebugAmount;

	internal bool DebugNoEnemy;

	internal float DebugLevelSize = 1f;

	internal bool AllPlayersReady;

	public bool Generated;

	internal int ModulesSpawned;

	internal int ModulesSpawnedTarget;

	private bool moduleAmountReceived;

	private List<Player> ModulesReadyPlayerList = new List<Player>();

	private int ModulesReadyPlayers;

	[Space]
	internal int EnemiesSpawnTarget;

	internal int EnemiesSpawned;

	private bool enemySpawnTargetReceived;

	private bool enemyReadySent;

	private int EnemyReadyPlayers;

	internal List<Player> EnemyReadyPlayerList = new List<Player>();

	private bool EnemyReady;

	internal int playerSpawned;

	private List<Player> SpawnedReadyPlayerList = new List<Player>();

	[Space]
	public Level Level;

	internal int ModuleAmount;

	private int PassageAmount;

	private int DeadEndAmount;

	private int ExtractionAmount;

	private int SpecialAmount;

	private List<MegaTile> MegaTiles = new List<MegaTile>();

	public static float TileSize = 5f;

	public static float ModuleWidth = 3f;

	public static float ModuleHeight = 1f;

	[Space]
	public GameObject LevelParent;

	public GameObject EnemyParent;

	public GameObject ItemParent;

	private List<PrefabRef> ModulesNormalShuffled_1;

	private List<PrefabRef> ModulesNormalShuffled_2;

	private List<PrefabRef> ModulesNormalShuffled_3;

	private int ModulesNormalIndex_1;

	private int ModulesNormalIndex_2;

	private int ModulesNormalIndex_3;

	private int ModulesNormalIndexLoops_1;

	private int ModulesNormalIndexLoops_2;

	private int ModulesNormalIndexLoops_3;

	private List<PrefabRef> ModulesPassageShuffled_1;

	private List<PrefabRef> ModulesPassageShuffled_2;

	private List<PrefabRef> ModulesPassageShuffled_3;

	private int ModulesPassageIndex_1;

	private int ModulesPassageIndex_2;

	private int ModulesPassageIndex_3;

	private int ModulesPassageIndexLoops_1;

	private int ModulesPassageIndexLoops_2;

	private int ModulesPassageIndexLoops_3;

	private List<PrefabRef> ModulesDeadEndShuffled_1;

	private List<PrefabRef> ModulesDeadEndShuffled_2;

	private List<PrefabRef> ModulesDeadEndShuffled_3;

	private int ModulesDeadEndIndex_1;

	private int ModulesDeadEndIndex_2;

	private int ModulesDeadEndIndex_3;

	private int ModulesDeadEndIndexLoops_1;

	private int ModulesDeadEndIndexLoops_2;

	private int ModulesDeadEndIndexLoops_3;

	private List<PrefabRef> ModulesExtractionShuffled_1;

	private List<PrefabRef> ModulesExtractionShuffled_2;

	private List<PrefabRef> ModulesExtractionShuffled_3;

	private int ModulesExtractionIndex_1;

	private int ModulesExtractionIndex_2;

	private int ModulesExtractionIndex_3;

	private int ModulesExtractionIndexLoops_1;

	private int ModulesExtractionIndexLoops_2;

	private int ModulesExtractionIndexLoops_3;

	private List<PrefabRef> ModulesSpecialShuffled;

	private int ModulesSpecialIndex;

	private int ModulesSpecialIndexLoops;

	private List<PrefabRef> ModulesMegaShuffled_1;

	private List<PrefabRef> ModulesMegaShuffled_2;

	private List<PrefabRef> ModulesMegaShuffled_3;

	private int ModulesMegaIndex_1;

	private int ModulesMegaIndex_2;

	private int ModulesMegaIndex_3;

	private int ModulesMegaIndexLoops_1;

	private int ModulesMegaIndexLoops_2;

	private int ModulesMegaIndexLoops_3;

	[Space]
	public AnimationCurve DifficultyCurve1;

	public AnimationCurve DifficultyCurve2;

	public AnimationCurve DifficultyCurve3;

	private float ModuleRarity1;

	private float ModuleRarity2;

	private float ModuleRarity3;

	[Space]
	public int LevelWidth = 3;

	public int LevelHeight = 3;

	private Tile[,] LevelGrid;

	private Vector3[] ModuleRotations = new Vector3[4]
	{
		new Vector3(0f, 0f, 0f),
		new Vector3(0f, 90f, 0f),
		new Vector3(0f, 180f, 0f),
		new Vector3(0f, 270f, 0f)
	};

	[Space]
	public List<LevelPoint> LevelPathPoints;

	public LevelPoint LevelPathTruck;

	private NavMeshSurface NavMeshSurface;

	private NavMeshBuildState navMeshBuildState;

	private NavMeshData navMeshBuildData;

	private NavMeshData navMeshOwnedData;

	private AsyncOperation navMeshBuildOperation;

	private readonly List<NavMeshBuildSource> navMeshSources = new List<NavMeshBuildSource>();

	private readonly List<NavMeshBuildSource> navMeshGroupSources = new List<NavMeshBuildSource>();

	private readonly Dictionary<Transform, List<NavMeshBuildMarkup>> navMeshGroupMarkups = new Dictionary<Transform, List<NavMeshBuildMarkup>>();

	private readonly List<Transform> navMeshGroupsPending = new List<Transform>();

	private readonly HashSet<Transform> navMeshGroupsCollected = new HashSet<Transform>();

	private readonly Dictionary<Transform, bool> navMeshModuleCache = new Dictionary<Transform, bool>();

	private int navMeshModifierCount;

	private Bounds navMeshSourceBounds;

	private const float navMeshCollectTimeMs = 10f;

	private bool generateDonePending;

	private static readonly ProfilerMarker navMeshBuildProfilerMarker = new ProfilerMarker("LevelGenerator.BuildNavMesh");

	private static readonly ProfilerMarker navMeshCollectProfilerMarker = new ProfilerMarker("LevelGenerator.CollectNavMeshSources");

	private static readonly ProfilerMarker navMeshValidationProfilerMarker = new ProfilerMarker("LevelGenerator.ValidateNavMesh");

	[Space]
	public GameObject PlayerDeathHeadPrefab;

	public GameObject PlayerTumblePrefab;

	private bool waitingForSubCoroutine;

	internal List<ParticleDistance> particleDistances = new List<ParticleDistance>();

	private readonly List<PunManager.ItemSpawn> itemSpawns = new List<PunManager.ItemSpawn>();

	private readonly List<ModuleSpawn> moduleSpawns = new List<ModuleSpawn>();

	private const int prefabLoadRequestsPerFrame = 4;

	private const float spareIntegrationTimeMs = 4f;

	private const double prefabPrepareTimeoutDuration = 120.0;

	private Coroutine prefabLoadCoroutine;

	private IDisposable prefabLoadPause;

	internal IReadOnlyList<NavMeshBuildSource> NavMeshSources => navMeshSources;

	internal Bounds NavMeshSourceBounds
	{
		get
		{
			//IL_0001: Unknown result type (might be due to invalid IL or missing references)
			return navMeshSourceBounds;
		}
	}

	internal bool NavMeshReady => navMeshBuildState == NavMeshBuildState.Ready;

	internal bool GenerationStopped
	{
		get
		{
			if (navMeshBuildState != NavMeshBuildState.Cancelled)
			{
				return navMeshBuildState == NavMeshBuildState.Failed;
			}
			return true;
		}
	}

	internal bool LocalSetupReady
	{
		get
		{
			//IL_0026: Unknown result type (might be due to invalid IL or missing references)
			//IL_002b: Unknown result type (might be due to invalid IL or missing references)
			//IL_002e: Unknown result type (might be due to invalid IL or missing references)
			if (NavMeshReady && (!Object.op_Implicit((Object)(object)Map.Instance) || Map.Instance.GenerationReady))
			{
				Scene scene = ((Component)this).gameObject.scene;
				return ItemAttributes.IconsReady(SceneHandle.op_Implicit(scene.handle));
			}
			return false;
		}
	}

	private bool NavMeshCollectSpread
	{
		get
		{
			//IL_0006: Unknown result type (might be due to invalid IL or missing references)
			//IL_000c: Invalid comparison between Unknown and I4
			return (int)NavMeshSurface.collectObjects == 3;
		}
	}

	[RuntimeInitializeOnLoadMethod(/*Could not decode attribute arguments.*/)]
	private static void RuntimeInitializeOnLoad()
	{
		Instance = null;
		TileSize = 5f;
		ModuleWidth = 3f;
		ModuleHeight = 1f;
	}

	private void Awake()
	{
		Instance = this;
		PhotonView = ((Component)this).GetComponent<PhotonView>();
	}

	private void Start()
	{
		if (Object.op_Implicit((Object)(object)RunManager.instance) && RunManager.instance.SceneHandoffCancelling)
		{
			GenerateCancel();
			return;
		}
		if (Object.op_Implicit((Object)(object)RunManager.instance) && SemiFunc.IsSplashScreen())
		{
			SemiFunc.SplashScreenSkip();
		}
		if (RunManager.instance.singleplayerPool.Count > 0)
		{
			RunManager.instance.singleplayerPool.Clear();
		}
		if (RunManager.instance.multiplayerPool.ResourceCache.Count > 0)
		{
			RunManager.instance.multiplayerPool.ResourceCache.Clear();
		}
		RunManager.instance.multiplayerPool.SpareClear();
		PhotonNetwork.PrefabPool = (IPunPrefabPool)(object)RunManager.instance.multiplayerPool;
		RunManager.instance.multiplayerPool.ResourceCache[((Object)PlayerDeathHeadPrefab).name] = PlayerDeathHeadPrefab;
		RunManager.instance.multiplayerPool.ResourceCache[((Object)PlayerTumblePrefab).name] = PlayerTumblePrefab;
		PhotonNetwork.DispatchTimeBudget = 0.004f;
		if (navMeshBuildState != NavMeshBuildState.Cancelled && (!Object.op_Implicit((Object)(object)NetworkManager.instance) || !NetworkManager.instance.leavePhotonRoom))
		{
			GenerateRun(Generate());
		}
	}

	private IEnumerator Generate()
	{
		yield return (object)new WaitForSeconds(0.2f);
		if (!SemiFunc.IsMultiplayer())
		{
			AllPlayersReady = true;
		}
		while (!AllPlayersReady)
		{
			State = LevelState.Load;
			yield return (object)new WaitForSeconds(0.1f);
		}
		_ = RunManager.instance.levelPrevious;
		Level = RunManager.instance.levelCurrent;
		RunManager.instance.levelPrevious = Level;
		if (SemiFunc.IsMasterClientOrSingleplayer())
		{
			ModuleAmount = Level.ModuleAmount;
			if (DebugAmount > 0)
			{
				ModuleAmount = DebugAmount;
			}
			GenerateRun(TileGeneration());
			while (waitingForSubCoroutine)
			{
				yield return null;
			}
			GenerateRun(StartRoomGeneration());
			while (waitingForSubCoroutine)
			{
				yield return null;
			}
			GenerateRun(ModuleGeneration());
			while (waitingForSubCoroutine)
			{
				yield return null;
			}
			GenerateRun(GenerateConnectObjects());
			while (waitingForSubCoroutine)
			{
				yield return null;
			}
			GenerateRun(GenerateBlockObjects());
			while (waitingForSubCoroutine)
			{
				yield return null;
			}
			if (GameManager.instance.gameMode == 1)
			{
				PhotonView.RPC("ModuleAmountRPC", (RpcTarget)3, new object[1] { ModulesSpawnedTarget });
			}
		}
		while ((SemiFunc.IsMultiplayer() && !moduleAmountReceived) || ModulesSpawned < ModulesSpawnedTarget)
		{
			State = LevelState.ModuleSpawnLocal;
			yield return (object)new WaitForSeconds(0.1f);
		}
		if (Object.op_Implicit((Object)(object)Map.Instance))
		{
			Map.Instance.GenerationStart();
		}
		if (GameManager.instance.gameMode == 1)
		{
			PhotonView.RPC("ModulesReadyRPC", (RpcTarget)3, Array.Empty<object>());
		}
		while (GameManager.instance.gameMode == 1 && !PlayersReadyCheck(ModulesReadyPlayerList, out ModulesReadyPlayers))
		{
			State = LevelState.ModuleSpawnRemote;
			yield return null;
		}
		EnvironmentDirector.Instance.Setup();
		PostProcessing.Instance.Setup();
		LevelMusic.instance.Setup();
		ConstantMusic.instance.Setup();
		if (SemiFunc.IsMasterClientOrSingleplayer())
		{
			double _levelPointDeadline = Time.realtimeSinceStartupAsDouble + 10.0;
			while (LevelPathPoints.Count == 0 && !SemiFunc.RunIsArena())
			{
				State = LevelState.LevelPoint;
				if (Time.realtimeSinceStartupAsDouble > _levelPointDeadline)
				{
					throw new InvalidOperationException("level " + ((Object)Level).name + " has no level points... every level needs modules with level point objects so enemies and items can be placed");
				}
				yield return (object)new WaitForSeconds(0.1f);
			}
			State = LevelState.Item;
			if (!SemiFunc.IsMultiplayer())
			{
				ItemSetup();
			}
			else
			{
				PhotonView.RPC("ItemSetup", (RpcTarget)3, Array.Empty<object>());
			}
			yield return PrefabsPrepare(itemSpawns.Select((PunManager.ItemSpawn _spawn) => _spawn.prefab));
			double realtimeSinceStartupAsDouble = Time.realtimeSinceStartupAsDouble;
			for (int _index = 0; _index < itemSpawns.Count; _index++)
			{
				PunManager.instance.ItemSpawnApply(itemSpawns[_index]);
				if (Time.realtimeSinceStartupAsDouble - realtimeSinceStartupAsDouble >= 0.002)
				{
					yield return null;
					realtimeSinceStartupAsDouble = Time.realtimeSinceStartupAsDouble;
				}
			}
			itemSpawns.Clear();
			GenerateRun(ValuableDirector.instance.SetupHost());
			while (!ValuableDirector.instance.setupComplete)
			{
				State = LevelState.Valuable;
				yield return null;
			}
			NavMeshSetup();
			while (!LocalSetupReady)
			{
				if (navMeshBuildState == NavMeshBuildState.Failed || navMeshBuildState == NavMeshBuildState.Cancelled)
				{
					yield break;
				}
				yield return null;
			}
			yield return null;
			while (GameDirector.instance.PlayerList.Count == 0)
			{
				State = LevelState.PlayerSetup;
				yield return (object)new WaitForSeconds(0.1f);
			}
			PlayerSpawn();
			yield return null;
			while (!PlayerSpawnReadyCheck())
			{
				State = LevelState.PlayerSpawn;
				yield return null;
			}
			if (Level.HasEnemies && !DebugNoEnemy)
			{
				yield return EnemySetup();
				if (GameManager.Multiplayer())
				{
					while (!EnemyReady)
					{
						State = LevelState.Enemy;
						if (PlayersReadyCheck(EnemyReadyPlayerList, out EnemyReadyPlayers) || EnemiesSpawnTarget <= 0)
						{
							PhotonView.RPC("EnemyReadyAllRPC", (RpcTarget)3, Array.Empty<object>());
							EnemyReady = true;
						}
						yield return null;
					}
				}
				else
				{
					while (EnemiesSpawned < EnemiesSpawnTarget)
					{
						yield return (object)new WaitForSeconds(0.1f);
					}
				}
			}
			State = LevelState.Done;
			if (!SemiFunc.IsMultiplayer())
			{
				GenerateDone();
			}
			else
			{
				PhotonView.RPC("GenerateDone", (RpcTarget)3, Array.Empty<object>());
			}
			SessionManager.instance.CrownPlayer();
		}
		else
		{
			while (!Generated)
			{
				yield return (object)new WaitForSeconds(0.1f);
			}
		}
		if (!Object.op_Implicit((Object)(object)TruckSafetySpawnPoint.instance))
		{
			Debug.LogError((object)"Level has no TruckSafetySpawnPoint!");
		}
		RunManager.instance.UpdateSteamRichPresence();
	}

	public void PlayerSpawn()
	{
		//IL_0096: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a8: Unknown result type (might be due to invalid IL or missing references)
		//IL_016b: Unknown result type (might be due to invalid IL or missing references)
		//IL_017d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0220: Unknown result type (might be due to invalid IL or missing references)
		//IL_0225: Unknown result type (might be due to invalid IL or missing references)
		//IL_01fd: Unknown result type (might be due to invalid IL or missing references)
		//IL_0202: Unknown result type (might be due to invalid IL or missing references)
		//IL_0296: Unknown result type (might be due to invalid IL or missing references)
		//IL_029b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0273: Unknown result type (might be due to invalid IL or missing references)
		//IL_0278: Unknown result type (might be due to invalid IL or missing references)
		SpawnPoint[] array = Object.FindObjectsByType<SpawnPoint>((FindObjectsSortMode)0);
		List<SpawnPoint> list = new List<SpawnPoint>();
		List<SpawnPoint> list2 = new List<SpawnPoint>();
		bool flag = false;
		SpawnPoint[] array2 = array;
		foreach (SpawnPoint spawnPoint in array2)
		{
			if (spawnPoint.debug)
			{
				if (spawnPoint.debugUser == SemiFunc.User.None || SemiFunc.DebugUser(spawnPoint.debugUser))
				{
					list2.Add(spawnPoint);
					flag = true;
				}
			}
			else
			{
				list.Add(spawnPoint);
			}
		}
		if (flag)
		{
			int num = 0;
			foreach (PlayerAvatar player in GameDirector.instance.PlayerList)
			{
				player.Spawn(((Component)list2[num]).transform.position, ((Component)list2[num]).transform.rotation, _debug: true);
				num++;
				if (num >= list2.Count)
				{
					num = 0;
				}
			}
		}
		else
		{
			if (list.Count == 0)
			{
				list.AddRange(array);
			}
			if (list.Count == 0)
			{
				Debug.LogError((object)("level " + (Object.op_Implicit((Object)(object)Level) ? ((Object)Level).name : "?") + " has no spawn points... players were not moved"), (Object)(object)this);
			}
			list.Shuffle();
			int num2 = 0;
			foreach (PlayerAvatar player2 in GameDirector.instance.PlayerList)
			{
				if (list.Count == 0)
				{
					break;
				}
				player2.Spawn(((Component)list[num2]).transform.position, ((Component)list[num2]).transform.rotation);
				num2++;
				if (num2 >= list.Count)
				{
					num2 = 0;
				}
			}
		}
		if (SemiFunc.MenuLevel())
		{
			return;
		}
		foreach (PlayerAvatar player3 in GameDirector.instance.PlayerList)
		{
			if (!Object.op_Implicit((Object)(object)player3.playerDeathHead))
			{
				GameObject val = (GameManager.Multiplayer() ? PhotonNetwork.Instantiate(((Object)PlayerDeathHeadPrefab).name, AssetManager.instance.physDisabledPosition, Quaternion.identity, (byte)0, (object[])null) : Object.Instantiate<GameObject>(PlayerDeathHeadPrefab, AssetManager.instance.physDisabledPosition, Quaternion.identity));
				PlayerDeathHead component = val.GetComponent<PlayerDeathHead>();
				component.playerAvatar = player3;
				component.playerAvatar.playerDeathHead = component;
			}
			if (!Object.op_Implicit((Object)(object)player3.tumble))
			{
				GameObject val2 = (GameManager.Multiplayer() ? PhotonNetwork.Instantiate(((Object)PlayerTumblePrefab).name, AssetManager.instance.physDisabledPosition, Quaternion.identity, (byte)0, (object[])null) : Object.Instantiate<GameObject>(PlayerTumblePrefab, AssetManager.instance.physDisabledPosition, Quaternion.identity));
				PlayerTumble component2 = val2.GetComponent<PlayerTumble>();
				component2.playerAvatar = player3;
				component2.playerAvatar.tumble = component2;
			}
		}
	}

	public void NavMeshSetup()
	{
		//IL_003d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0043: Unknown result type (might be due to invalid IL or missing references)
		if (navMeshBuildState != NavMeshBuildState.Cancelled && SemiFunc.IsMasterClientOrSingleplayer() && navMeshBuildState != NavMeshBuildState.Collecting && navMeshBuildState != NavMeshBuildState.Building && navMeshBuildState != NavMeshBuildState.Validating)
		{
			if (GameManager.instance.gameMode == 0)
			{
				NavMeshSetupRPC();
			}
			else
			{
				PhotonView.RPC("NavMeshSetupRPC", (RpcTarget)3, Array.Empty<object>());
			}
		}
	}

	public void MeshColliderFinder()
	{
		List<MeshCollider> list = new List<MeshCollider>();
		Debug.LogWarning((object)"");
		Debug.LogWarning((object)"Mesh Colliders:");
		MeshCollider[] array = Object.FindObjectsByType<MeshCollider>((FindObjectsSortMode)0);
		foreach (MeshCollider val in array)
		{
			bool flag = false;
			foreach (MeshCollider item in list)
			{
				if ((Object)(object)item.sharedMesh == (Object)(object)val.sharedMesh)
				{
					flag = true;
					break;
				}
			}
			if (!flag)
			{
				list.Add(val);
			}
		}
		foreach (MeshCollider item2 in list)
		{
			Debug.LogWarning((object)("    " + ((Object)item2.sharedMesh).name), (Object)(object)((Component)item2).gameObject);
		}
	}

	[PunRPC]
	public void ItemSetup(PhotonMessageInfo _info = default(PhotonMessageInfo))
	{
		//IL_0000: Unknown result type (might be due to invalid IL or missing references)
		if (!SemiFunc.MasterOnlyRPC(_info))
		{
			return;
		}
		itemSpawns.Clear();
		if (SemiFunc.RunIsArena())
		{
			if (Object.op_Implicit((Object)(object)Arena.instance))
			{
				Arena.instance.ItemsPrepare(itemSpawns);
			}
			else if (!Object.op_Implicit((Object)(object)ArenaRace.instance))
			{
				object obj;
				if (!Object.op_Implicit((Object)(object)Level))
				{
					Level levelCurrent = RunManager.instance.levelCurrent;
					obj = ((levelCurrent != null) ? ((Object)levelCurrent).name : null);
				}
				else
				{
					obj = ((Object)Level).name;
				}
				Debug.LogWarning((object)("arena level " + (string?)obj + " has no Arena or ArenaRace component... no items will spawn in it"), (Object)(object)this);
			}
		}
		else
		{
			ShopManager.instance.ShopInitialize(itemSpawns);
			ItemManager.instance.ItemsInitialize(itemSpawns);
		}
	}

	private void Update()
	{
		NavMeshBuildTick();
		if (generateDonePending && LocalSetupReady)
		{
			GenerateDoneApply();
		}
	}

	public void GenerateCancel()
	{
		navMeshBuildState = NavMeshBuildState.Cancelled;
		PhotonNetwork.DispatchTimeBudget = 0f;
		((MonoBehaviour)this).StopAllCoroutines();
		moduleSpawns.Clear();
		if (Object.op_Implicit((Object)(object)RunManager.instance) && (!Object.op_Implicit((Object)(object)Instance) || (Object)(object)Instance == (Object)(object)this))
		{
			RunManager.instance.multiplayerPool.SpareClear();
		}
		itemSpawns.Clear();
		PrefabLoadRelease();
		prefabLoadCoroutine = null;
		if (Object.op_Implicit((Object)(object)Map.Instance))
		{
			Map.Instance.GenerationCancel();
		}
		generateDonePending = false;
		NavMeshBuildCancel();
	}

	public override void OnDisable()
	{
		((MonoBehaviourPunCallbacks)this).OnDisable();
		if ((Object)(object)Instance == (Object)(object)this && !Generated && !GenerationStopped)
		{
			GenerateCancel();
		}
		else
		{
			PrefabLoadRelease();
		}
	}

	private void OnDestroy()
	{
		PhotonNetwork.DispatchTimeBudget = 0f;
		PrefabLoadRelease();
		if (Object.op_Implicit((Object)(object)RunManager.instance) && (!Object.op_Implicit((Object)(object)Instance) || (Object)(object)Instance == (Object)(object)this))
		{
			RunManager.instance.multiplayerPool.SpareClear();
		}
		navMeshBuildState = NavMeshBuildState.Idle;
		NavMeshBuildCancel();
		if (Object.op_Implicit((Object)(object)navMeshOwnedData))
		{
			if (Object.op_Implicit((Object)(object)NavMeshSurface) && (Object)(object)NavMeshSurface.navMeshData == (Object)(object)navMeshOwnedData)
			{
				NavMeshSurface.RemoveData();
				NavMeshSurface.navMeshData = null;
			}
			Object.Destroy((Object)(object)navMeshOwnedData);
			navMeshOwnedData = null;
		}
	}

	private void NavMeshBuildCancel()
	{
		if (Object.op_Implicit((Object)(object)navMeshBuildData))
		{
			NavMeshBuilder.Cancel(navMeshBuildData);
			if (Object.op_Implicit((Object)(object)NavMeshSurface) && (Object)(object)NavMeshSurface.navMeshData == (Object)(object)navMeshBuildData)
			{
				NavMeshSurface.RemoveData();
				NavMeshSurface.navMeshData = null;
			}
			Object.Destroy((Object)(object)navMeshBuildData);
			navMeshBuildData = null;
		}
		navMeshBuildOperation = null;
		NavMeshCollectReset();
	}

	private void NavMeshBuildStart()
	{
		try
		{
			if (NavMeshCollectSpread && NavMeshCollectBegin())
			{
				navMeshBuildState = NavMeshBuildState.Collecting;
				return;
			}
			NavMeshCollectReset();
			NavMeshBuildLaunchSurface();
		}
		catch (Exception ex)
		{
			Debug.LogException(ex, (Object)(object)this);
			NavMeshBuildCancel();
			NavMeshBuildFallback();
		}
	}

	private void NavMeshBuildLaunchSurface()
	{
		//IL_0006: Unknown result type (might be due to invalid IL or missing references)
		//IL_000b: Unknown result type (might be due to invalid IL or missing references)
		//IL_000e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0013: Unknown result type (might be due to invalid IL or missing references)
		NavMeshBuildDataCreate();
		ProfilerMarker val = navMeshBuildProfilerMarker;
		AutoScope val2 = val.Auto();
		try
		{
			navMeshBuildOperation = NavMeshSurface.UpdateNavMesh(navMeshBuildData);
		}
		finally
		{
			((IDisposable)val2/*cast due to constrained. prefix*/).Dispose();
		}
		NavMeshBuildLaunched();
	}

	private void NavMeshBuildDataCreate()
	{
		//IL_000c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0011: Unknown result type (might be due to invalid IL or missing references)
		//IL_0022: Unknown result type (might be due to invalid IL or missing references)
		//IL_0029: Unknown result type (might be due to invalid IL or missing references)
		//IL_0033: Unknown result type (might be due to invalid IL or missing references)
		//IL_003a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0049: Expected Obj, but got Unknown
		navMeshBuildData = new NavMeshData(NavMeshSurface.agentTypeID)
		{
			name = ((Object)((Component)this).gameObject).name,
			position = ((Component)this).transform.position,
			rotation = ((Component)this).transform.rotation
		};
	}

	private void NavMeshBuildLaunched()
	{
		if (navMeshBuildOperation == null)
		{
			throw new InvalidOperationException("navmesh build did not start..");
		}
		navMeshBuildState = NavMeshBuildState.Building;
	}

	private bool NavMeshCollectBegin()
	{
		NavMeshCollectReset();
		return NavMeshGroupsBuild();
	}

	private bool NavMeshGroupsBuild()
	{
		//IL_00e1: Unknown result type (might be due to invalid IL or missing references)
		//IL_0142: Unknown result type (might be due to invalid IL or missing references)
		navMeshGroupMarkups.Clear();
		navMeshGroupsPending.Clear();
		navMeshModuleCache.Clear();
		navMeshModifierCount = NavMeshModifier.activeModifiers.Count;
		foreach (NavMeshModifier activeModifier in NavMeshModifier.activeModifiers)
		{
			if (!Object.op_Implicit((Object)(object)activeModifier) || !((Behaviour)activeModifier).isActiveAndEnabled || !NavMeshModifierIncluded(activeModifier))
			{
				continue;
			}
			Transform val = NavMeshGroupOf(((Component)activeModifier).transform);
			if ((Object)(object)val == (Object)(object)((Component)activeModifier).transform.root && Object.op_Implicit((Object)(object)((Component)activeModifier).GetComponentInChildren<Module>(true)))
			{
				return false;
			}
			if (!navMeshGroupMarkups.TryGetValue(val, out var value))
			{
				value = new List<NavMeshBuildMarkup>();
				navMeshGroupMarkups.Add(val, value);
				if (!navMeshGroupsCollected.Contains(val))
				{
					navMeshGroupsPending.Add(val);
				}
			}
			List<NavMeshBuildMarkup> list = value;
			NavMeshBuildMarkup item = default;
			item.root = ((Component)activeModifier).transform;
			item.overrideArea = activeModifier.overrideArea;
			item.area = activeModifier.area;
			item.ignoreFromBuild = activeModifier.ignoreFromBuild;
			item.applyToChildren = activeModifier.applyToChildren;
			item.overrideGenerateLinks = activeModifier.overrideGenerateLinks;
			item.generateLinks = activeModifier.generateLinks;
			list.Add(item);
		}
		return true;
	}

	private Transform NavMeshGroupOf(Transform _transform)
	{
		Transform val = _transform;
		while (Object.op_Implicit((Object)(object)val))
		{
			if (!navMeshModuleCache.TryGetValue(val, out var value))
			{
				value = Object.op_Implicit((Object)(object)((Component)val).GetComponent<Module>());
				navMeshModuleCache.Add(val, value);
			}
			if (value)
			{
				return val;
			}
			val = val.parent;
		}
		return _transform.root;
	}

	private void NavMeshCollectReset()
	{
		navMeshSources.Clear();
		navMeshGroupMarkups.Clear();
		navMeshGroupsPending.Clear();
		navMeshGroupsCollected.Clear();
		navMeshModuleCache.Clear();
	}

	private void NavMeshCollectTick()
	{
		//IL_0006: Unknown result type (might be due to invalid IL or missing references)
		//IL_000b: Unknown result type (might be due to invalid IL or missing references)
		//IL_000e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0013: Unknown result type (might be due to invalid IL or missing references)
		try
		{
			double realtimeSinceStartupAsDouble = Time.realtimeSinceStartupAsDouble;
			ProfilerMarker val = navMeshCollectProfilerMarker;
			AutoScope val2 = val.Auto();
			try
			{
				while (navMeshGroupsPending.Count > 0)
				{
					Transform val3 = navMeshGroupsPending[navMeshGroupsPending.Count - 1];
					navMeshGroupsPending.RemoveAt(navMeshGroupsPending.Count - 1);
					NavMeshCollectGroup(val3);
					if ((Time.realtimeSinceStartupAsDouble - realtimeSinceStartupAsDouble) * 1000.0 >= 10.0)
					{
						break;
					}
				}
			}
			finally
			{
				((IDisposable)val2/*cast due to constrained. prefix*/).Dispose();
			}
			if (navMeshGroupsPending.Count <= 0)
			{
				NavMeshBuildLaunch();
			}
		}
		catch (Exception ex)
		{
			Debug.LogException(ex, (Object)(object)this);
			NavMeshBuildCancel();
			NavMeshBuildFallback();
		}
	}

	private void NavMeshBuildLaunch()
	{
		//IL_0000: Unknown result type (might be due to invalid IL or missing references)
		//IL_0005: Unknown result type (might be due to invalid IL or missing references)
		//IL_0008: Unknown result type (might be due to invalid IL or missing references)
		//IL_000d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0081: Unknown result type (might be due to invalid IL or missing references)
		//IL_0086: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a1: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a6: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a9: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ae: Unknown result type (might be due to invalid IL or missing references)
		//IL_00bc: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c8: Unknown result type (might be due to invalid IL or missing references)
		ProfilerMarker val = navMeshCollectProfilerMarker;
		AutoScope val2 = val.Auto();
		try
		{
			if (NavMeshModifier.activeModifiers.Count != navMeshModifierCount)
			{
				if (!NavMeshGroupsBuild())
				{
					throw new InvalidOperationException("navmesh modifier above a module showed up while collecting..");
				}
				while (navMeshGroupsPending.Count > 0)
				{
					Transform val3 = navMeshGroupsPending[navMeshGroupsPending.Count - 1];
					navMeshGroupsPending.RemoveAt(navMeshGroupsPending.Count - 1);
					NavMeshCollectGroup(val3);
				}
			}
			NavMeshModifierVolumesAppend();
			navMeshSourceBounds = NavMeshSourceBoundsCalculate();
		}
		finally
		{
			((IDisposable)val2/*cast due to constrained. prefix*/).Dispose();
		}
		NavMeshBuildDataCreate();
		val = navMeshBuildProfilerMarker;
		val2 = val.Auto();
		try
		{
			navMeshBuildOperation = NavMeshBuilder.UpdateNavMeshDataAsync(navMeshBuildData, NavMeshSurface.GetBuildSettings(), navMeshSources, navMeshSourceBounds);
		}
		finally
		{
			((IDisposable)val2/*cast due to constrained. prefix*/).Dispose();
		}
		NavMeshBuildLaunched();
	}

	private void NavMeshCollectGroup(Transform _group)
	{
		//IL_002e: Unknown result type (might be due to invalid IL or missing references)
		//IL_003e: Unknown result type (might be due to invalid IL or missing references)
		//IL_006c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0071: Unknown result type (might be due to invalid IL or missing references)
		//IL_00bc: Unknown result type (might be due to invalid IL or missing references)
		if (!Object.op_Implicit((Object)(object)_group) || !navMeshGroupsCollected.Add(_group) || !navMeshGroupMarkups.TryGetValue(_group, out var value))
		{
			return;
		}
		NavMeshBuilder.CollectSources(_group, LayerMask.op_Implicit(NavMeshSurface.layerMask), NavMeshSurface.useGeometry, NavMeshSurface.defaultArea, false, value, true, navMeshGroupSources);
		foreach (NavMeshBuildSource navMeshGroupSource in navMeshGroupSources)
		{
			NavMeshBuildSource current = navMeshGroupSource;
			Component component = current.component;
			if (!Object.op_Implicit((Object)(object)component) || ((!NavMeshSurface.ignoreNavMeshAgent || !Object.op_Implicit((Object)(object)component.GetComponent<NavMeshAgent>())) && (!NavMeshSurface.ignoreNavMeshObstacle || !Object.op_Implicit((Object)(object)component.GetComponent<NavMeshObstacle>()))))
			{
				navMeshSources.Add(current);
			}
		}
		navMeshGroupSources.Clear();
	}

	private bool NavMeshModifierIncluded(NavMeshModifier _modifier)
	{
		//IL_0006: Unknown result type (might be due to invalid IL or missing references)
		if ((LayerMask.op_Implicit(NavMeshSurface.layerMask) & (1 << ((Component)_modifier).gameObject.layer)) != 0)
		{
			return _modifier.AffectsAgentType(NavMeshSurface.agentTypeID);
		}
		return false;
	}

	private void NavMeshModifierVolumesAppend()
	{
		//IL_001e: Unknown result type (might be due to invalid IL or missing references)
		//IL_005b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0060: Unknown result type (might be due to invalid IL or missing references)
		//IL_0065: Unknown result type (might be due to invalid IL or missing references)
		//IL_006c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0071: Unknown result type (might be due to invalid IL or missing references)
		//IL_0075: Unknown result type (might be due to invalid IL or missing references)
		//IL_007f: Unknown result type (might be due to invalid IL or missing references)
		//IL_008c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0096: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ad: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b9: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c6: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d6: Unknown result type (might be due to invalid IL or missing references)
		//IL_00dd: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e2: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e7: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f3: Unknown result type (might be due to invalid IL or missing references)
		//IL_0107: Unknown result type (might be due to invalid IL or missing references)
		foreach (NavMeshModifierVolume activeModifier in NavMeshModifierVolume.activeModifiers)
		{
			if ((LayerMask.op_Implicit(NavMeshSurface.layerMask) & (1 << ((Component)activeModifier).gameObject.layer)) != 0 && activeModifier.AffectsAgentType(NavMeshSurface.agentTypeID))
			{
				Vector3 val = ((Component)activeModifier).transform.TransformPoint(activeModifier.center);
				Vector3 lossyScale = ((Component)activeModifier).transform.lossyScale;
				Vector3 size = new Vector3(activeModifier.size.x * Mathf.Abs(lossyScale.x), activeModifier.size.y * Mathf.Abs(lossyScale.y), activeModifier.size.z * Mathf.Abs(lossyScale.z));
				List<NavMeshBuildSource> list = navMeshSources;
				NavMeshBuildSource item = default;
				item.shape = (NavMeshBuildSourceShape)5;
				item.transform = Matrix4x4.TRS(val, ((Component)activeModifier).transform.rotation, Vector3.one);
				item.size = size;
				item.area = activeModifier.area;
				list.Add(item);
			}
		}
	}

	private Bounds NavMeshSourceBoundsCalculate()
	{
		//IL_0006: Unknown result type (might be due to invalid IL or missing references)
		//IL_0011: Unknown result type (might be due to invalid IL or missing references)
		//IL_0016: Unknown result type (might be due to invalid IL or missing references)
		//IL_001b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0020: Unknown result type (might be due to invalid IL or missing references)
		//IL_0023: Unknown result type (might be due to invalid IL or missing references)
		//IL_0028: Unknown result type (might be due to invalid IL or missing references)
		//IL_002b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0041: Unknown result type (might be due to invalid IL or missing references)
		//IL_0046: Unknown result type (might be due to invalid IL or missing references)
		//IL_004a: Unknown result type (might be due to invalid IL or missing references)
		//IL_008c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0092: Invalid comparison between Unknown and I4
		//IL_00e6: Unknown result type (might be due to invalid IL or missing references)
		//IL_0096: Unknown result type (might be due to invalid IL or missing references)
		//IL_0099: Unknown result type (might be due to invalid IL or missing references)
		//IL_009e: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00aa: Unknown result type (might be due to invalid IL or missing references)
		//IL_00af: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b4: Unknown result type (might be due to invalid IL or missing references)
		//IL_006a: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0072: Unknown result type (might be due to invalid IL or missing references)
		//IL_0079: Unknown result type (might be due to invalid IL or missing references)
		//IL_007e: Unknown result type (might be due to invalid IL or missing references)
		Matrix4x4 val = Matrix4x4.TRS(((Component)this).transform.position, ((Component)this).transform.rotation, Vector3.one);
		Matrix4x4 inverse = val.inverse;
		Bounds result = default;
		foreach (NavMeshBuildSource navMeshSource in navMeshSources)
		{
			NavMeshBuildSource current = navMeshSource;
			if ((int)current.shape == 0)
			{
				Object sourceObject = current.sourceObject;
				Mesh val2 = (Mesh)(object)((sourceObject is Mesh) ? sourceObject : null);
				if (Object.op_Implicit((Object)(object)val2))
				{
					result.Encapsulate(NavMeshWorldBounds(inverse * current.transform, val2.bounds));
				}
			}
			else if ((int)current.shape != 1)
			{
				result.Encapsulate(NavMeshWorldBounds(inverse * current.transform, new Bounds(Vector3.zero, current.size)));
			}
		}
		result.Expand(0.1f);
		return result;
	}

	private static Bounds NavMeshWorldBounds(Matrix4x4 _matrix, Bounds _bounds)
	{
		//IL_0002: Unknown result type (might be due to invalid IL or missing references)
		//IL_0007: Unknown result type (might be due to invalid IL or missing references)
		//IL_000c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0011: Unknown result type (might be due to invalid IL or missing references)
		//IL_0014: Unknown result type (might be due to invalid IL or missing references)
		//IL_0019: Unknown result type (might be due to invalid IL or missing references)
		//IL_001e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0023: Unknown result type (might be due to invalid IL or missing references)
		//IL_0026: Unknown result type (might be due to invalid IL or missing references)
		//IL_002b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0030: Unknown result type (might be due to invalid IL or missing references)
		//IL_0035: Unknown result type (might be due to invalid IL or missing references)
		//IL_003a: Unknown result type (might be due to invalid IL or missing references)
		//IL_003f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0044: Unknown result type (might be due to invalid IL or missing references)
		//IL_0047: Unknown result type (might be due to invalid IL or missing references)
		//IL_0051: Unknown result type (might be due to invalid IL or missing references)
		//IL_0056: Unknown result type (might be due to invalid IL or missing references)
		//IL_0059: Unknown result type (might be due to invalid IL or missing references)
		//IL_0063: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0070: Unknown result type (might be due to invalid IL or missing references)
		//IL_007a: Unknown result type (might be due to invalid IL or missing references)
		//IL_007f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0084: Unknown result type (might be due to invalid IL or missing references)
		//IL_0085: Unknown result type (might be due to invalid IL or missing references)
		//IL_0086: Unknown result type (might be due to invalid IL or missing references)
		Vector3 val = NavMeshAbs(_matrix.MultiplyVector(Vector3.right));
		Vector3 val2 = NavMeshAbs(_matrix.MultiplyVector(Vector3.up));
		Vector3 val3 = NavMeshAbs(_matrix.MultiplyVector(Vector3.forward));
		Vector3 val4 = _matrix.MultiplyPoint(_bounds.center);
		Vector3 val5 = val * _bounds.size.x + val2 * _bounds.size.y + val3 * _bounds.size.z;
		return new Bounds(val4, val5);
	}

	private static Vector3 NavMeshAbs(Vector3 _value)
	{
		//IL_0000: Unknown result type (might be due to invalid IL or missing references)
		//IL_000b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0016: Unknown result type (might be due to invalid IL or missing references)
		//IL_0021: Unknown result type (might be due to invalid IL or missing references)
		return new Vector3(Mathf.Abs(_value.x), Mathf.Abs(_value.y), Mathf.Abs(_value.z));
	}

	private void NavMeshBuildFallback()
	{
		//IL_000c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0011: Unknown result type (might be due to invalid IL or missing references)
		//IL_0014: Unknown result type (might be due to invalid IL or missing references)
		//IL_0019: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a3: Unknown result type (might be due to invalid IL or missing references)
		try
		{
			NavMeshData navMeshData = NavMeshSurface.navMeshData;
			ProfilerMarker val = navMeshBuildProfilerMarker;
			AutoScope val2 = val.Auto();
			try
			{
				NavMeshSurface.BuildNavMesh();
			}
			finally
			{
				((IDisposable)val2/*cast due to constrained. prefix*/).Dispose();
			}
			if (!Object.op_Implicit((Object)(object)NavMeshSurface.navMeshData) || (Object)(object)NavMeshSurface.navMeshData == (Object)(object)navMeshData)
			{
				throw new InvalidOperationException("navmesh fallback did not finish..");
			}
			if (Object.op_Implicit((Object)(object)navMeshOwnedData))
			{
				Object.Destroy((Object)(object)navMeshOwnedData);
			}
			navMeshOwnedData = NavMeshSurface.navMeshData;
			((Component)this).transform.localPosition = new Vector3(0f, 0.001f, 0f);
			navMeshBuildState = NavMeshBuildState.Validating;
		}
		catch (Exception exception)
		{
			GenerationFailed(exception);
		}
	}

	private void NavMeshBuildTick()
	{
		switch (navMeshBuildState)
		{
		case NavMeshBuildState.Collecting:
			NavMeshCollectTick();
			break;
		case NavMeshBuildState.Building:
			if (navMeshBuildOperation.isDone)
			{
				NavMeshBuildInstall();
			}
			break;
		case NavMeshBuildState.Validating:
			NavMeshBuildValidate();
			break;
		}
	}

	private void NavMeshBuildInstall()
	{
		//IL_007b: Unknown result type (might be due to invalid IL or missing references)
		try
		{
			NavMeshSurface.RemoveData();
			NavMeshSurface.navMeshData = navMeshBuildData;
			if (((Behaviour)NavMeshSurface).isActiveAndEnabled)
			{
				NavMeshSurface.AddData();
			}
			if (Object.op_Implicit((Object)(object)navMeshOwnedData))
			{
				Object.Destroy((Object)(object)navMeshOwnedData);
			}
			navMeshOwnedData = navMeshBuildData;
			navMeshBuildData = null;
			navMeshBuildOperation = null;
			((Component)this).transform.localPosition = new Vector3(0f, 0.001f, 0f);
			navMeshBuildState = NavMeshBuildState.Validating;
		}
		catch (Exception exception)
		{
			GenerationFailed(exception);
		}
	}

	private void NavMeshBuildValidate()
	{
		//IL_0007: Unknown result type (might be due to invalid IL or missing references)
		//IL_000c: Unknown result type (might be due to invalid IL or missing references)
		//IL_000f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0014: Unknown result type (might be due to invalid IL or missing references)
		try
		{
			if (Debug.isDebugBuild)
			{
				ProfilerMarker val = navMeshValidationProfilerMarker;
				AutoScope val2 = val.Auto();
				try
				{
					NavMeshValidator.SafetyCheck();
				}
				finally
				{
					((IDisposable)val2/*cast due to constrained. prefix*/).Dispose();
				}
			}
		}
		catch (Exception ex)
		{
			Debug.LogException(ex, (Object)(object)this);
		}
		navMeshBuildState = NavMeshBuildState.Ready;
		if (generateDonePending && LocalSetupReady)
		{
			GenerateDoneApply();
		}
	}

	internal void GenerationFailed(Exception _exception)
	{
		if (navMeshBuildState != NavMeshBuildState.Failed && navMeshBuildState != NavMeshBuildState.Cancelled)
		{
			navMeshBuildState = NavMeshBuildState.Failed;
			PhotonNetwork.DispatchTimeBudget = 0f;
			((MonoBehaviour)this).StopAllCoroutines();
			PrefabLoadRelease();
			prefabLoadCoroutine = null;
			if (Object.op_Implicit((Object)(object)RunManager.instance) && (!Object.op_Implicit((Object)(object)Instance) || (Object)(object)Instance == (Object)(object)this))
			{
				RunManager.instance.multiplayerPool.SpareClear();
			}
			if (Object.op_Implicit((Object)(object)Map.Instance))
			{
				Map.Instance.GenerationCancel();
			}
			generateDonePending = false;
			Debug.LogError((object)("level loading failed on this machine... " + _exception.Message + "... the exception below shows where... leaving to the menu"), (Object)(object)this);
			Debug.LogException(_exception, (Object)(object)this);
			try
			{
				NavMeshBuildCancel();
			}
			catch (Exception ex)
			{
				Debug.LogException(ex, (Object)(object)this);
			}
			if (SemiFunc.IsMultiplayer())
			{
				NetworkManager.instance.TriggerLeavePhotonRoomForcedStuckInLoading();
			}
			else
			{
				((MonoBehaviour)RunManager.instance).StartCoroutine(RunManager.instance.LeaveToMainMenu());
			}
		}
	}

	private Coroutine GenerateRun(IEnumerator _routine)
	{
		return ((MonoBehaviour)this).StartCoroutine(GenerateGuarded(_routine));
	}

	private IEnumerator GenerateGuarded(IEnumerator _routine)
	{
		while (true)
		{
			object obj = null;
			bool flag = false;
			try
			{
				flag = _routine.MoveNext();
				if (flag)
				{
					obj = _routine.Current;
				}
			}
			catch (Exception exception)
			{
				GenerateRoutineFailed(exception);
			}
			if (!flag)
			{
				break;
			}
			if (obj is IEnumerator routine)
			{
				obj = GenerateGuarded(routine);
			}
			yield return obj;
		}
	}

	private void GenerateRoutineFailed(Exception _exception)
	{
		if (Generated)
		{
			Debug.LogError((object)"a level generation routine broke after the level was already done... the exception below shows where... the level keeps running", (Object)(object)this);
			Debug.LogException(_exception, (Object)(object)this);
		}
		else if (navMeshBuildState == NavMeshBuildState.Failed || navMeshBuildState == NavMeshBuildState.Cancelled)
		{
			Debug.LogException(_exception, (Object)(object)this);
		}
		else
		{
			GenerationFailed(_exception);
		}
	}

	[PunRPC]
	private void NavMeshSetupRPC(PhotonMessageInfo _info = default(PhotonMessageInfo))
	{
		//IL_0000: Unknown result type (might be due to invalid IL or missing references)
		if (SemiFunc.MasterOnlyRPC(_info) && navMeshBuildState != NavMeshBuildState.Cancelled && navMeshBuildState != NavMeshBuildState.Failed && (!Object.op_Implicit((Object)(object)NetworkManager.instance) || !NetworkManager.instance.leavePhotonRoom))
		{
			NavMeshBuildCancel();
			NavMeshSurface = ((Component)this).GetComponent<NavMeshSurface>();
			NavMeshBuildStart();
		}
	}

	internal IEnumerator PrefabsPrepare(IEnumerable<PrefabRef> _prefabs, IEnumerable<string> _resourcePaths = null, IEnumerable<string> _sparePaths = null)
	{
		HashSet<string> hashSet = new HashSet<string>();
		if (_resourcePaths != null)
		{
			foreach (string _resourcePath in _resourcePaths)
			{
				if (!string.IsNullOrEmpty(_resourcePath))
				{
					hashSet.Add(_resourcePath);
				}
			}
		}
		foreach (PrefabRef _prefab in _prefabs)
		{
			if (_prefab != null && !string.IsNullOrEmpty(_prefab.ResourcePath))
			{
				hashSet.Add(_prefab.ResourcePath);
			}
		}
		if (hashSet.Count != 0)
		{
			string[] array = hashSet.ToArray();
			string[] array2 = ((_sparePaths != null) ? _sparePaths.ToArray() : new string[0]);
			RunManager.instance.multiplayerPool.SparesReserve(array2);
			if (SemiFunc.IsMultiplayer())
			{
				PhotonView.RPC("PrefabsLoadRPC", (RpcTarget)1, new object[2] { array, array2 });
			}
			yield return PrefabsLoad(array, array2);
		}
	}

	private IEnumerator SparesPrepare(IEnumerable<string> _paths, double _deadline)
	{
		RunManager _owner = RunManager.instance;
		int _requests = 0;
		AsyncInstantiateOperation.SetIntegrationTimeMS(4f);
		foreach (string _path in _paths)
		{
			if (Object.op_Implicit((Object)(object)_owner) && !((Object)(object)Instance != (Object)(object)this) && !GenerationStopped)
			{
				PrefabLoadCheck(_deadline);
				if (string.IsNullOrEmpty(_path))
				{
					throw new InvalidOperationException("missing module prefab path...");
				}
				_owner.multiplayerPool.SpareAddAsync(_path, ((Component)this).transform);
				_requests++;
				if (_requests % 4 == 0)
				{
					yield return null;
				}
				continue;
			}
			yield break;
		}
		while (Object.op_Implicit((Object)(object)_owner) && !((Object)(object)Instance != (Object)(object)this) && !GenerationStopped)
		{
			PrefabLoadCheck(_deadline);
			if (_owner.multiplayerPool.SparesPending())
			{
				yield return null;
				continue;
			}
			break;
		}
	}

	private void PrefabLoadCheck(double _deadline)
	{
		if (Time.realtimeSinceStartupAsDouble >= _deadline)
		{
			throw new TimeoutException("prefab preparation took too long...");
		}
		if (prefabLoadPause != null && !PhotonNetwork.IncomingMessagesPauseRefresh(prefabLoadPause))
		{
			throw new InvalidOperationException("prefab preparation lost its network pause...");
		}
	}

	private IEnumerator PrefabsLoad(string[] _paths, string[] _sparePaths)
	{
		RunManager _owner = RunManager.instance;
		double _deadline = Time.realtimeSinceStartupAsDouble + 120.0;
		Dictionary<string, AsyncOperation> _requests = new Dictionary<string, AsyncOperation>();
		int num = 0;
		while (true)
		{
			if (num < _paths.Length)
			{
				string text = _paths[num];
				if (!Object.op_Implicit((Object)(object)_owner) || (Object)(object)Instance != (Object)(object)this || GenerationStopped)
				{
					break;
				}
				PrefabLoadCheck(_deadline);
				if (!string.IsNullOrEmpty(text) && !_requests.ContainsKey(text) && (!_owner.multiplayerPool.ResourceCache.TryGetValue(text, out var value) || !Object.op_Implicit((Object)(object)value)))
				{
					if (_owner.singleplayerPool.TryGetValue(text, out var value2))
					{
						GameObject val = (GameObject)(object)((value2 is GameObject) ? value2 : null);
						if (val != null && Object.op_Implicit((Object)(object)val))
						{
							_owner.multiplayerPool.ResourceCache[text] = val;
							goto IL_0222;
						}
					}
					if (text.StartsWith("AssetBundles/", StringComparison.Ordinal))
					{
						foreach (AssetBundle allLoadedAssetBundle in AssetBundle.GetAllLoadedAssetBundles())
						{
							string text2 = "AssetBundles/" + ((Object)allLoadedAssetBundle).name + "/";
							if (text.StartsWith(text2, StringComparison.Ordinal))
							{
								_requests.Add(text, (AsyncOperation)(object)allLoadedAssetBundle.LoadAssetAsync<GameObject>(text.Substring(text2.Length)));
								break;
							}
						}
						if (!_requests.ContainsKey(text))
						{
							throw new InvalidOperationException("missing asset bundle for prefab... " + text);
						}
					}
					else
					{
						_requests.Add(text, (AsyncOperation)(object)Resources.LoadAsync<GameObject>(text));
					}
					if (_requests.Count % 4 == 0)
					{
						yield return null;
					}
				}
				goto IL_0222;
			}
			foreach (KeyValuePair<string, AsyncOperation> _entry in _requests)
			{
				AsyncOperation _request = _entry.Value;
				if (_request == null)
				{
					throw new InvalidOperationException("prefab load did not start... " + _entry.Key);
				}
				while (true)
				{
					if (Object.op_Implicit((Object)(object)_owner) && !((Object)(object)Instance != (Object)(object)this) && !GenerationStopped)
					{
						PrefabLoadCheck(_deadline);
						if (_request.isDone)
						{
							break;
						}
						yield return null;
						continue;
					}
					yield break;
				}
				GameObject val2 = null;
				ResourceRequest val3 = (ResourceRequest)(object)((_request is ResourceRequest) ? _request : null);
				if (val3 != null)
				{
					Object asset = val3.asset;
					val2 = (GameObject)(object)((asset is GameObject) ? asset : null);
				}
				AssetBundleRequest val4 = (AssetBundleRequest)(object)((_request is AssetBundleRequest) ? _request : null);
				if (val4 != null)
				{
					Object asset2 = val4.asset;
					val2 = (GameObject)(object)((asset2 is GameObject) ? asset2 : null);
				}
				if (!Object.op_Implicit((Object)(object)val2))
				{
					throw new InvalidOperationException("couldn't load prefab... " + _entry.Key);
				}
				_owner.singleplayerPool[_entry.Key] = (Object)(object)val2;
				_owner.multiplayerPool.ResourceCache[_entry.Key] = val2;
			}
			if (_sparePaths != null && _sparePaths.Length != 0)
			{
				yield return SparesPrepare(_sparePaths, _deadline);
			}
			break;
			IL_0222:
			num++;
		}
	}

	[PunRPC]
	private void PrefabsLoadRPC(string[] _paths, string[] _sparePaths, PhotonMessageInfo _info = default(PhotonMessageInfo))
	{
		//IL_0000: Unknown result type (might be due to invalid IL or missing references)
		if (SemiFunc.MasterOnlyRPC(_info) && !SemiFunc.IsMasterClientOrSingleplayer() && !Generated && navMeshBuildState != NavMeshBuildState.Cancelled && navMeshBuildState != NavMeshBuildState.Failed && ((Behaviour)this).isActiveAndEnabled && _paths != null && _paths.Length != 0)
		{
			if (prefabLoadCoroutine != null)
			{
				((MonoBehaviour)this).StopCoroutine(prefabLoadCoroutine);
			}
			PrefabLoadRelease();
			IDisposable pause = (prefabLoadPause = PhotonNetwork.IncomingMessagesPause((Behaviour)(object)this, 10.0));
			if (_sparePaths != null)
			{
				RunManager.instance.multiplayerPool.SparesReserve(_sparePaths);
			}
			prefabLoadCoroutine = GenerateRun(PrefabsLoadRemote(_paths, _sparePaths, pause));
		}
	}

	private IEnumerator PrefabsLoadRemote(string[] _paths, string[] _sparePaths, IDisposable _pause)
	{
		try
		{
			yield return PrefabsLoad(_paths, _sparePaths);
		}
		finally
		{
			LevelGenerator levelGenerator = this;
			_pause.Dispose();
			if (levelGenerator.prefabLoadPause == _pause)
			{
				levelGenerator.prefabLoadPause = null;
				levelGenerator.prefabLoadCoroutine = null;
			}
		}
	}

	private void PrefabLoadRelease()
	{
		prefabLoadPause?.Dispose();
		prefabLoadPause = null;
	}

	private IEnumerator StartRoomGeneration()
	{
		waitingForSubCoroutine = true;
		State = LevelState.StartRoom;
		List<PrefabRef> startRooms = new List<PrefabRef>();
		startRooms.AddRange(FilterModulesWIP(Level.StartRooms));
		startRooms.Shuffle();
		if (DebugStartRoom != null)
		{
			startRooms[0] = DebugStartRoom;
		}
		string[] resourcePaths = ((!SemiFunc.RunIsShop()) ? null : new string[1] { "Items/Item Mine Stun" });
		Coroutine _preload = GenerateRun(PrefabsPrepare(new PrefabRef[1] { startRooms[0] }, resourcePaths));
		yield return (object)new WaitForSeconds(0.2f);
		yield return _preload;
		GameObject val = ((GameManager.instance.gameMode != 0) ? PhotonNetwork.InstantiateRoomObject(startRooms[0].ResourcePath, Vector3.zero, Quaternion.identity, (byte)0, (object[])null) : Object.Instantiate<GameObject>(startRooms[0].Prefab, Vector3.zero, Quaternion.identity));
		val.transform.parent = LevelParent.transform;
		yield return null;
		waitingForSubCoroutine = false;
	}

	private IEnumerator TileGeneration()
	{
		waitingForSubCoroutine = true;
		State = LevelState.Tiles;
		if (DebugMega)
		{
			LevelWidth = 5;
			LevelHeight = 2 * Mathf.Max(1, DebugAmount);
		}
		else
		{
			LevelWidth = Mathf.Max(2, Mathf.CeilToInt((float)LevelWidth * DebugLevelSize));
			LevelHeight = Mathf.Max(2, Mathf.CeilToInt((float)LevelHeight * DebugLevelSize));
		}
		LevelGrid = new Tile[LevelWidth, LevelHeight];
		for (int i = 0; i < LevelWidth; i++)
		{
			for (int j = 0; j < LevelHeight; j++)
			{
				LevelGrid[i, j] = new Tile
				{
					x = i,
					y = j,
					active = false
				};
			}
		}
		ExtractionAmount = 0;
		SpecialAmount = Level.ModulesSpecialAmount;
		if (ModuleAmount > 4)
		{
			ModuleAmount = Mathf.Min(5 + RunManager.instance.levelsCompleted, 10);
			if (RunManager.instance.levelsCompleted >= 10)
			{
				ModuleAmount += Mathf.Min(RunManager.instance.levelsCompleted - 9, 5);
			}
			ModuleAmount = Mathf.CeilToInt((float)ModuleAmount * DebugLevelSize);
			if (DebugModule == null)
			{
				DeadEndAmount = Mathf.CeilToInt((float)(ModuleAmount / 3));
				if (ModuleAmount >= 15)
				{
					ExtractionAmount = 4;
				}
				else if (ModuleAmount >= 10)
				{
					ExtractionAmount = 3;
				}
				else if (ModuleAmount >= 8)
				{
					ExtractionAmount = 2;
				}
				else if (ModuleAmount >= 6)
				{
					ExtractionAmount = 1;
				}
				else
				{
					ExtractionAmount = 0;
				}
			}
		}
		if (SemiFunc.IsLevelShop(Level))
		{
			DeadEndAmount = 1;
		}
		if (DebugMega)
		{
			ExtractionAmount = 0;
			DeadEndAmount = 0;
			SpecialAmount = 0;
		}
		LevelGrid[LevelWidth / 2, 0].active = true;
		LevelGrid[LevelWidth / 2, 0].first = true;
		if (!DebugMega)
		{
			int moduleAmount = ModuleAmount;
			moduleAmount--;
			int num = LevelWidth / 2;
			int num2 = 0;
			while (moduleAmount > 0)
			{
				int num3 = -999;
				int num4 = -999;
				while (num + num3 < 0 || num + num3 >= LevelWidth || num2 + num4 < 0 || num2 + num4 >= LevelHeight)
				{
					num3 = 0;
					num4 = 0;
					int num5 = Random.Range(0, 4);
					if (num2 == 1)
					{
						num5 = Random.Range(0, 3);
					}
					if (DebugPassage)
					{
						num5 = 2;
					}
					switch (num5)
					{
					case 0:
						num3--;
						break;
					case 1:
						num3++;
						break;
					case 2:
						num4++;
						break;
					case 3:
						num4--;
						break;
					}
				}
				num += num3;
				num2 += num4;
				if (!LevelGrid[num, num2].active)
				{
					LevelGrid[num, num2].active = true;
					moduleAmount--;
				}
			}
		}
		else
		{
			int num6 = Mathf.Max(1, DebugAmount);
			for (int k = 0; k < num6; k++)
			{
				int num7 = k * 2;
				int num8 = 1 + k * 2;
				LevelGrid[1, num7].active = true;
				LevelGrid[1, num8].active = true;
				LevelGrid[2, num7].active = true;
				LevelGrid[2, num8].active = true;
			}
		}
		yield return null;
		List<Tile> possibleExtractionTiles = new List<Tile>();
		if (!DebugNormal && !DebugPassage && !DebugDeadEnd && !DebugExtraction)
		{
			for (int l = 0; l < LevelWidth; l++)
			{
				for (int m = 0; m < LevelHeight; m++)
				{
					if (!LevelGrid[l, m].active)
					{
						int num9 = 0;
						Tile tile = GridGetTile(l, m + 1);
						if (tile != null && tile.active)
						{
							num9++;
						}
						Tile tile2 = GridGetTile(l + 1, m);
						if (tile2 != null && tile2.active)
						{
							num9++;
						}
						Tile tile3 = GridGetTile(l, m - 1);
						if (tile3 != null && tile3.active)
						{
							num9++;
						}
						Tile tile4 = GridGetTile(l - 1, m);
						if (tile4 != null && tile4.active)
						{
							num9++;
						}
						if (num9 == 1)
						{
							possibleExtractionTiles.Add(LevelGrid[l, m]);
						}
					}
				}
			}
		}
		yield return null;
		int num10 = ExtractionAmount;
		Tile tile5 = new Tile();
		tile5.x = LevelWidth / 2;
		tile5.y = -1;
		List<Tile> _extractionTiles = new List<Tile> { tile5 };
		while (num10 > 0 && possibleExtractionTiles.Count > 0)
		{
			Tile tile6 = null;
			float num11 = 0f;
			foreach (Tile item in possibleExtractionTiles)
			{
				float num12 = 9999999f;
				foreach (Tile item2 in _extractionTiles)
				{
					float num13 = Vector2.Distance(new Vector2((float)item2.x, (float)item2.y), new Vector2((float)item.x, (float)item.y));
					if (num13 < num12)
					{
						num12 = num13;
					}
				}
				if (num12 > num11)
				{
					num11 = num12;
					tile6 = item;
				}
			}
			SetDeadEndTile(Module.Type.Extraction, tile6, ref _extractionTiles, ref possibleExtractionTiles);
			num10--;
		}
		yield return null;
		int num14 = SpecialAmount;
		while (num14 > 0 && possibleExtractionTiles.Count > 0)
		{
			Tile tile7 = possibleExtractionTiles[Random.Range(0, possibleExtractionTiles.Count)];
			SetDeadEndTile(Module.Type.Special, tile7, ref _extractionTiles, ref possibleExtractionTiles);
			num14--;
		}
		yield return null;
		int num15 = DeadEndAmount;
		while (num15 > 0 && possibleExtractionTiles.Count > 0)
		{
			Tile tile8 = possibleExtractionTiles[Random.Range(0, possibleExtractionTiles.Count)];
			SetDeadEndTile(Module.Type.DeadEnd, tile8, ref _extractionTiles, ref possibleExtractionTiles);
			num15--;
		}
		yield return null;
		for (int n = 0; n < LevelWidth; n++)
		{
			for (int num16 = 0; num16 < LevelHeight; num16++)
			{
				Tile tile9 = GridGetTile(n, num16);
				if (tile9.active && tile9.type == Module.Type.Normal)
				{
					Tile tile10 = GridGetTile(n, num16 - 1);
					Tile tile11 = GridGetTile(n + 1, num16);
					Tile tile12 = GridGetTile(n + 1, num16 - 1);
					if (tile10 != null && tile10.active && tile10.type == Module.Type.Normal && tile11 != null && tile11.active && tile11.type == Module.Type.Normal && tile12 != null && tile12.active && tile12.type == Module.Type.Normal)
					{
						MegaTiles.Add(new MegaTile
						{
							tiles = new Tile[4] { tile9, tile10, tile11, tile12 }
						});
					}
				}
			}
		}
		if (DebugMega)
		{
			List<MegaTile> list = new List<MegaTile>();
			foreach (MegaTile item3 in from _m in MegaTiles
				orderby _m.tiles[0].y, _m.tiles[0].x
				select _m)
			{
				bool flag = false;
				foreach (MegaTile item4 in list)
				{
					if (item4.tiles.Intersect(item3.tiles).Any())
					{
						flag = true;
						break;
					}
				}
				if (!flag)
				{
					list.Add(item3);
				}
			}
			MegaTiles = list;
		}
		yield return null;
		waitingForSubCoroutine = false;
	}

	private void SetDeadEndTile(Module.Type _type, Tile _tile, ref List<Tile> _extractionTiles, ref List<Tile> _possibleExtractionTiles)
	{
		_tile.type = _type;
		_tile.active = true;
		_extractionTiles.Add(_tile);
		_possibleExtractionTiles.Remove(_tile);
		bool flag = false;
		while (!flag)
		{
			flag = true;
			foreach (Tile _possibleExtractionTile in _possibleExtractionTiles)
			{
				if (GridGetTile(_possibleExtractionTile.x, _possibleExtractionTile.y - 1) == _tile || GridGetTile(_possibleExtractionTile.x + 1, _possibleExtractionTile.y) == _tile || GridGetTile(_possibleExtractionTile.x, _possibleExtractionTile.y + 1) == _tile || GridGetTile(_possibleExtractionTile.x - 1, _possibleExtractionTile.y) == _tile)
				{
					_possibleExtractionTiles.Remove(_possibleExtractionTile);
					flag = false;
					break;
				}
			}
		}
	}

	private List<PrefabRef> FilterModulesWIP(List<PrefabRef> _modules)
	{
		if (Object.op_Implicit((Object)(object)GameManager.instance) && GameManager.instance.IsWIPActive(DebugCommandHandler.WIPTypes.Module))
		{
			List<PrefabRef> list = _modules.Where((PrefabRef x) => !x.IsFinalized).ToList();
			if (list.Count > 0)
			{
				return list;
			}
		}
		return _modules;
	}

	private IEnumerator ModuleGeneration()
	{
		moduleSpawns.Clear();
		waitingForSubCoroutine = true;
		State = LevelState.ModuleGeneration;
		ModulesNormalShuffled_1 = new List<PrefabRef>();
		ModulesNormalShuffled_2 = new List<PrefabRef>();
		ModulesNormalShuffled_3 = new List<PrefabRef>();
		ModulesPassageShuffled_1 = new List<PrefabRef>();
		ModulesPassageShuffled_2 = new List<PrefabRef>();
		ModulesPassageShuffled_3 = new List<PrefabRef>();
		ModulesDeadEndShuffled_1 = new List<PrefabRef>();
		ModulesDeadEndShuffled_2 = new List<PrefabRef>();
		ModulesDeadEndShuffled_3 = new List<PrefabRef>();
		ModulesExtractionShuffled_1 = new List<PrefabRef>();
		ModulesExtractionShuffled_2 = new List<PrefabRef>();
		ModulesExtractionShuffled_3 = new List<PrefabRef>();
		ModulesSpecialShuffled = new List<PrefabRef>();
		ModulesMegaShuffled_1 = new List<PrefabRef>();
		ModulesMegaShuffled_2 = new List<PrefabRef>();
		ModulesMegaShuffled_3 = new List<PrefabRef>();
		ModuleRarity1 = DifficultyCurve1.Evaluate(SemiFunc.RunGetDifficultyMultiplier1());
		ModuleRarity2 = DifficultyCurve2.Evaluate(SemiFunc.RunGetDifficultyMultiplier1());
		ModuleRarity3 = DifficultyCurve3.Evaluate(SemiFunc.RunGetDifficultyMultiplier1());
		if (DebugModule == null)
		{
			ModulesNormalShuffled_1.AddRange(FilterModulesWIP(Level.ModulesNormal1));
			ModulesNormalShuffled_1.Shuffle();
			ModulesNormalShuffled_2.AddRange(FilterModulesWIP(Level.ModulesNormal2));
			ModulesNormalShuffled_2.Shuffle();
			ModulesNormalShuffled_3.AddRange(FilterModulesWIP(Level.ModulesNormal3));
			ModulesNormalShuffled_3.Shuffle();
			ModulesPassageShuffled_1.AddRange(FilterModulesWIP(Level.ModulesPassage1));
			ModulesPassageShuffled_1.Shuffle();
			ModulesPassageShuffled_2.AddRange(FilterModulesWIP(Level.ModulesPassage2));
			ModulesPassageShuffled_2.Shuffle();
			ModulesPassageShuffled_3.AddRange(FilterModulesWIP(Level.ModulesPassage3));
			ModulesPassageShuffled_3.Shuffle();
			ModulesDeadEndShuffled_1.AddRange(FilterModulesWIP(Level.ModulesDeadEnd1));
			ModulesDeadEndShuffled_1.Shuffle();
			ModulesDeadEndShuffled_2.AddRange(FilterModulesWIP(Level.ModulesDeadEnd2));
			ModulesDeadEndShuffled_2.Shuffle();
			ModulesDeadEndShuffled_3.AddRange(FilterModulesWIP(Level.ModulesDeadEnd3));
			ModulesDeadEndShuffled_3.Shuffle();
			ModulesExtractionShuffled_1.AddRange(FilterModulesWIP(Level.ModulesExtraction1));
			ModulesExtractionShuffled_1.Shuffle();
			ModulesExtractionShuffled_2.AddRange(FilterModulesWIP(Level.ModulesExtraction2));
			ModulesExtractionShuffled_2.Shuffle();
			ModulesExtractionShuffled_3.AddRange(FilterModulesWIP(Level.ModulesExtraction3));
			ModulesExtractionShuffled_3.Shuffle();
			ModulesSpecialShuffled.AddRange(FilterModulesWIP(Level.ModulesSpecial));
			ModulesSpecialShuffled.Shuffle();
			ModulesMegaShuffled_1.AddRange(FilterModulesWIP(Level.ModulesMega1));
			ModulesMegaShuffled_1.Shuffle();
			ModulesMegaShuffled_2.AddRange(FilterModulesWIP(Level.ModulesMega2));
			ModulesMegaShuffled_2.Shuffle();
			ModulesMegaShuffled_3.AddRange(FilterModulesWIP(Level.ModulesMega3));
			ModulesMegaShuffled_3.Shuffle();
		}
		else
		{
			ModulesNormalShuffled_1.Add(DebugModule);
			if (DebugMega)
			{
				ModulesPassageShuffled_1.AddRange(FilterModulesWIP(Level.ModulesPassage1));
				ModulesPassageShuffled_1.Shuffle();
			}
			else
			{
				ModulesPassageShuffled_1.Add(DebugModule);
			}
			ModulesDeadEndShuffled_1.Add(DebugModule);
			ModulesExtractionShuffled_1.Add(DebugModule);
			ModulesSpecialShuffled.Add(DebugModule);
			ModulesMegaShuffled_1.Add(DebugModule);
		}
		if (ModulesNormalShuffled_1.Count == 0)
		{
			waitingForSubCoroutine = false;
			yield break;
		}
		MegaTiles.Shuffle();
		List<MegaTile> list = new List<MegaTile>();
		bool flag = false;
		foreach (MegaTile megaTile in MegaTiles)
		{
			bool flag2 = false;
			Tile[] tiles = megaTile.tiles;
			for (int i = 0; i < tiles.Length; i++)
			{
				if (tiles[i].type == Module.Type.Mega)
				{
					flag2 = true;
					break;
				}
			}
			float num = 10f;
			if (DebugMega)
			{
				num = 999f;
			}
			else if (RunManager.instance.megaModuleCooldownCount > 0 || DebugNormal || DebugPassage || DebugDeadEnd || DebugExtraction)
			{
				num = -1f;
			}
			else if (RunManager.instance.megaModuleBadLuckCount > 0)
			{
				num *= (float)(1 + RunManager.instance.megaModuleBadLuckCount);
			}
			if (flag2 || (float)Random.Range(0, 100) > num)
			{
				list.Add(megaTile);
				continue;
			}
			tiles = megaTile.tiles;
			for (int i = 0; i < tiles.Length; i++)
			{
				tiles[i].type = Module.Type.Mega;
			}
			Vector3[] array = new Vector3[megaTile.tiles.Length];
			array[0] = GridGetTilePosition(megaTile.tiles[0].x, megaTile.tiles[0].y);
			array[1] = GridGetTilePosition(megaTile.tiles[1].x, megaTile.tiles[1].y);
			array[2] = GridGetTilePosition(megaTile.tiles[2].x, megaTile.tiles[2].y);
			array[3] = GridGetTilePosition(megaTile.tiles[3].x, megaTile.tiles[3].y);
			Vector3 position = (array[0] + array[1] + array[2] + array[3]) / 4f;
			Vector3 rotation = ModuleRotations[Random.Range(0, ModuleRotations.Length)];
			if (!PlanModule(megaTile.tiles[0].x, megaTile.tiles[0].y, position, rotation, Module.Type.Mega, megaTile))
			{
				tiles = megaTile.tiles;
				for (int i = 0; i < tiles.Length; i++)
				{
					tiles[i].type = Module.Type.Normal;
				}
				list.Add(megaTile);
			}
			else
			{
				flag = true;
			}
		}
		foreach (MegaTile item in list)
		{
			MegaTiles.Remove(item);
		}
		if (SemiFunc.RunIsLevel())
		{
			if (flag)
			{
				RunManager.instance.megaModuleBadLuckCount = 0;
				RunManager.instance.megaModuleCooldownCount = 2;
			}
			else if (RunManager.instance.megaModuleCooldownCount > 0)
			{
				RunManager.instance.megaModuleCooldownCount--;
			}
			else
			{
				RunManager.instance.megaModuleBadLuckCount++;
			}
		}
		for (int j = 0; j < LevelWidth; j++)
		{
			for (int k = 0; k < LevelHeight; k++)
			{
				if (!LevelGrid[j, k].active || (!DebugNormal && !DebugPassage && !DebugDeadEnd && !DebugExtraction && LevelGrid[j, k].type == Module.Type.Mega))
				{
					continue;
				}
				Vector3 rotation2 = Vector3.zero;
				Vector3 position2 = GridGetTilePosition(j, k);
				if (!DebugNormal && !DebugPassage && !DebugDeadEnd && !DebugExtraction && LevelGrid[j, k].type == Module.Type.Extraction)
				{
					if (GridCheckActive(j, k - 1))
					{
						rotation2 = Vector3.zero;
					}
					if (GridCheckActive(j - 1, k))
					{
						rotation2 = new Vector3(0f, 90f, 0f);
					}
					if (GridCheckActive(j, k + 1))
					{
						rotation2 = new Vector3(0f, 180f, 0f);
					}
					if (GridCheckActive(j + 1, k))
					{
						rotation2 = new Vector3(0f, -90f, 0f);
					}
					PlanModule(j, k, position2, rotation2, Module.Type.Extraction);
					continue;
				}
				if (DebugDeadEnd || DebugExtraction || (!DebugNormal && !DebugPassage && LevelGrid[j, k].type == Module.Type.DeadEnd))
				{
					if (GridCheckActive(j, k - 1))
					{
						rotation2 = Vector3.zero;
					}
					if (GridCheckActive(j - 1, k))
					{
						rotation2 = new Vector3(0f, 90f, 0f);
					}
					if (GridCheckActive(j, k + 1))
					{
						rotation2 = new Vector3(0f, 180f, 0f);
					}
					if (GridCheckActive(j + 1, k))
					{
						rotation2 = new Vector3(0f, -90f, 0f);
					}
					PlanModule(j, k, position2, rotation2, Module.Type.DeadEnd);
					continue;
				}
				if (!DebugDeadEnd && !DebugExtraction && !DebugNormal && !DebugPassage && LevelGrid[j, k].type == Module.Type.Special)
				{
					if (GridCheckActive(j, k - 1))
					{
						rotation2 = Vector3.zero;
					}
					if (GridCheckActive(j - 1, k))
					{
						rotation2 = new Vector3(0f, 90f, 0f);
					}
					if (GridCheckActive(j, k + 1))
					{
						rotation2 = new Vector3(0f, 180f, 0f);
					}
					if (GridCheckActive(j + 1, k))
					{
						rotation2 = new Vector3(0f, -90f, 0f);
					}
					PlanModule(j, k, position2, rotation2, Module.Type.Special);
					continue;
				}
				if (!DebugNormal && (DebugPassage || PassageAmount < Level.PassageMaxAmount))
				{
					if (DebugPassage || (GridCheckActive(j, k + 1) && (GridCheckActive(j, k - 1) || LevelGrid[j, k].first) && !GridCheckActive(j + 1, k) && !GridCheckActive(j - 1, k)))
					{
						if (Random.Range(0, 100) < 50)
						{
							rotation2 = new Vector3(0f, 180f, 0f);
						}
						PlanModule(j, k, position2, rotation2, Module.Type.Passage);
						PassageAmount++;
						continue;
					}
					if (!LevelGrid[j, k].first && GridCheckActive(j + 1, k) && GridCheckActive(j - 1, k) && !GridCheckActive(j, k + 1) && !GridCheckActive(j, k - 1))
					{
						rotation2 = new Vector3(0f, 90f, 0f);
						if (Random.Range(0, 100) < 50)
						{
							rotation2 = new Vector3(0f, -90f, 0f);
						}
						PlanModule(j, k, position2, rotation2, Module.Type.Passage);
						PassageAmount++;
						continue;
					}
				}
				rotation2 = ModuleRotations[Random.Range(0, ModuleRotations.Length)];
				PlanModule(j, k, position2, rotation2, Module.Type.Normal);
			}
		}
		List<PrefabRef> list2 = moduleSpawns.Select((ModuleSpawn _spawn) => _spawn.prefab).ToList();
		list2.Add(Level.ConnectObject);
		list2.Add(Level.BlockObject);
		List<string> sparePaths = moduleSpawns.Select((ModuleSpawn _spawn) => _spawn.prefab.ResourcePath).ToList();
		yield return PrefabsPrepare(list2, null, sparePaths);
		foreach (ModuleSpawn moduleSpawn in moduleSpawns)
		{
			SpawnModule(moduleSpawn);
			yield return null;
		}
		moduleSpawns.Clear();
		waitingForSubCoroutine = false;
	}

	private bool GridCheckActive(int x, int y)
	{
		if (x >= 0 && x < LevelWidth && y >= 0 && y < LevelHeight)
		{
			return LevelGrid[x, y].active;
		}
		return false;
	}

	private Tile GridGetTile(int x, int y)
	{
		if (x >= 0 && x < LevelWidth && y >= 0 && y < LevelHeight)
		{
			return LevelGrid[x, y];
		}
		return null;
	}

	private Vector3 GridGetTilePosition(int _x, int _y)
	{
		//IL_0049: Unknown result type (might be due to invalid IL or missing references)
		return new Vector3((float)_x * ModuleWidth * TileSize - (float)(LevelWidth / 2) * ModuleWidth * TileSize, 0f, (float)_y * ModuleWidth * TileSize + ModuleWidth * TileSize / 2f);
	}

	public bool TryGetModuleAtPosition(Vector3 _worldPosition, out Module _module)
	{
		//IL_0023: Unknown result type (might be due to invalid IL or missing references)
		//IL_003b: Unknown result type (might be due to invalid IL or missing references)
		_module = null;
		if (LevelGrid == null)
		{
			return false;
		}
		float num = ModuleWidth * TileSize;
		if (num <= 0f)
		{
			return false;
		}
		int x = Mathf.RoundToInt(_worldPosition.x / num + (float)(LevelWidth / 2));
		int y = Mathf.FloorToInt(_worldPosition.z / num);
		Tile tile = GridGetTile(x, y);
		if (tile == null || !Object.op_Implicit((Object)(object)tile.module))
		{
			return false;
		}
		_module = tile.module;
		return true;
	}

	private PrefabRef PickModule(List<PrefabRef> _list1, List<PrefabRef> _list2, List<PrefabRef> _list3, ref int _index1, ref int _index2, ref int _index3, ref int _loops1, ref int _loops2, ref int _loops3, bool _loopsAllowed = true)
	{
		PrefabRef result = null;
		float[] array = new float[3] { ModuleRarity1, ModuleRarity2, ModuleRarity3 };
		if (_list1.Count <= 0 || (!_loopsAllowed && _loops1 > 0))
		{
			array[0] = 0f;
		}
		if (_list2.Count <= 0 || (!_loopsAllowed && _loops2 > 0))
		{
			array[1] = 0f;
		}
		if (_list3.Count <= 0 || (!_loopsAllowed && _loops3 > 0))
		{
			array[2] = 0f;
		}
		int num = Mathf.Max(new int[3] { _loops1, _loops2, _loops3 });
		int num2 = Mathf.Min(new int[3] { _loops1, _loops2, _loops3 });
		if (num != num2)
		{
			if (_loops1 == num2 && array[0] > 0f)
			{
				if (_loops1 != _loops2)
				{
					array[1] = 0f;
				}
				if (_loops1 != _loops3)
				{
					array[2] = 0f;
				}
			}
			else if (_loops2 == num2 && array[1] > 0f)
			{
				if (_loops2 != _loops1)
				{
					array[0] = 0f;
				}
				if (_loops2 != _loops3)
				{
					array[2] = 0f;
				}
			}
			else if (_loops3 == num2 && array[2] > 0f)
			{
				if (_loops3 != _loops1)
				{
					array[0] = 0f;
				}
				if (_loops3 != _loops2)
				{
					array[1] = 0f;
				}
			}
		}
		float num3 = -1f;
		int num4 = -1;
		for (int i = 0; i < array.Length; i++)
		{
			if (array[i] > 0f)
			{
				float num5 = Random.Range(0f, array[i]);
				if (num5 > num3)
				{
					num3 = num5;
					num4 = i;
				}
			}
		}
		switch (num4)
		{
		case 0:
			result = _list1[_index1];
			_index1++;
			if (_index1 >= _list1.Count)
			{
				_list1.Shuffle();
				_index1 = 0;
				_loops1++;
			}
			break;
		case 1:
			result = _list2[_index2];
			_index2++;
			if (_index2 >= _list2.Count)
			{
				_list2.Shuffle();
				_index2 = 0;
				_loops2++;
			}
			break;
		case 2:
			result = _list3[_index3];
			_index3++;
			if (_index3 >= _list3.Count)
			{
				_list3.Shuffle();
				_index3 = 0;
				_loops3++;
			}
			break;
		}
		return result;
	}

	private bool PlanModule(int _x, int _y, Vector3 _position, Vector3 _rotation, Module.Type _type, MegaTile _megaTile = null)
	{
		//IL_0233: Unknown result type (might be due to invalid IL or missing references)
		//IL_0234: Unknown result type (might be due to invalid IL or missing references)
		//IL_023a: Unknown result type (might be due to invalid IL or missing references)
		//IL_023c: Unknown result type (might be due to invalid IL or missing references)
		PrefabRef prefabRef = null;
		switch (_type)
		{
		case Module.Type.Normal:
			prefabRef = PickModule(ModulesNormalShuffled_1, ModulesNormalShuffled_2, ModulesNormalShuffled_3, ref ModulesNormalIndex_1, ref ModulesNormalIndex_2, ref ModulesNormalIndex_3, ref ModulesNormalIndexLoops_1, ref ModulesNormalIndexLoops_2, ref ModulesNormalIndexLoops_3);
			LevelGrid[_x, _y].type = Module.Type.Normal;
			break;
		case Module.Type.Passage:
			prefabRef = PickModule(ModulesPassageShuffled_1, ModulesPassageShuffled_2, ModulesPassageShuffled_3, ref ModulesPassageIndex_1, ref ModulesPassageIndex_2, ref ModulesPassageIndex_3, ref ModulesPassageIndexLoops_1, ref ModulesPassageIndexLoops_2, ref ModulesPassageIndexLoops_3);
			LevelGrid[_x, _y].type = Module.Type.Passage;
			break;
		case Module.Type.DeadEnd:
			prefabRef = PickModule(ModulesDeadEndShuffled_1, ModulesDeadEndShuffled_2, ModulesDeadEndShuffled_3, ref ModulesDeadEndIndex_1, ref ModulesDeadEndIndex_2, ref ModulesDeadEndIndex_3, ref ModulesDeadEndIndexLoops_1, ref ModulesDeadEndIndexLoops_2, ref ModulesDeadEndIndexLoops_3);
			LevelGrid[_x, _y].type = Module.Type.DeadEnd;
			break;
		case Module.Type.Extraction:
			prefabRef = PickModule(ModulesExtractionShuffled_1, ModulesExtractionShuffled_2, ModulesExtractionShuffled_3, ref ModulesExtractionIndex_1, ref ModulesExtractionIndex_2, ref ModulesExtractionIndex_3, ref ModulesExtractionIndexLoops_1, ref ModulesExtractionIndexLoops_2, ref ModulesExtractionIndexLoops_3);
			LevelGrid[_x, _y].type = Module.Type.Extraction;
			break;
		case Module.Type.Special:
			prefabRef = PickModule(ModulesSpecialShuffled, ModulesSpecialShuffled, ModulesSpecialShuffled, ref ModulesSpecialIndex, ref ModulesSpecialIndex, ref ModulesSpecialIndex, ref ModulesSpecialIndexLoops, ref ModulesSpecialIndexLoops, ref ModulesSpecialIndexLoops);
			LevelGrid[_x, _y].type = Module.Type.Special;
			break;
		case Module.Type.Mega:
			prefabRef = PickModule(ModulesMegaShuffled_1, ModulesMegaShuffled_2, ModulesMegaShuffled_3, ref ModulesMegaIndex_1, ref ModulesMegaIndex_2, ref ModulesMegaIndex_3, ref ModulesMegaIndexLoops_1, ref ModulesMegaIndexLoops_2, ref ModulesMegaIndexLoops_3, DebugMega);
			break;
		}
		if (prefabRef == null)
		{
			return false;
		}
		moduleSpawns.Add(new ModuleSpawn
		{
			prefab = prefabRef,
			x = _x,
			y = _y,
			position = _position,
			rotation = _rotation,
			type = _type,
			megaTile = _megaTile
		});
		return true;
	}

	private void SpawnModule(ModuleSpawn _spawn)
	{
		//IL_000f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0014: Unknown result type (might be due to invalid IL or missing references)
		//IL_0016: Unknown result type (might be due to invalid IL or missing references)
		//IL_001b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0079: Unknown result type (might be due to invalid IL or missing references)
		//IL_007a: Unknown result type (might be due to invalid IL or missing references)
		//IL_007b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0051: Unknown result type (might be due to invalid IL or missing references)
		//IL_0052: Unknown result type (might be due to invalid IL or missing references)
		//IL_0053: Unknown result type (might be due to invalid IL or missing references)
		int x = _spawn.x;
		int y = _spawn.y;
		Vector3 position = _spawn.position;
		Vector3 rotation = _spawn.rotation;
		Module.Type type = _spawn.type;
		MegaTile megaTile = _spawn.megaTile;
		PrefabRef prefab = _spawn.prefab;
		GameObject val;
		if (GameManager.instance.gameMode == 0)
		{
			val = RunManager.instance.multiplayerPool.SpareTake(prefab.ResourcePath, position, Quaternion.Euler(rotation));
			if (Object.op_Implicit((Object)(object)val))
			{
				val.SetActive(true);
			}
		}
		else
		{
			val = PhotonNetwork.InstantiateRoomObject(prefab.ResourcePath, position, Quaternion.Euler(rotation), (byte)0, (object[])null);
		}
		if (!Object.op_Implicit((Object)(object)val))
		{
			throw new InvalidOperationException("couldn't spawn module " + prefab.ResourcePath + " at grid " + x + ", " + y + "... check its prefab ref in level " + ((Object)Level).name + "... it needs a prefab inside a Resources folder or a loaded asset bundle");
		}
		val.transform.parent = LevelParent.transform;
		Module component = val.GetComponent<Module>();
		component.GridX = x;
		component.GridY = y;
		if (type == Module.Type.Mega && megaTile != null)
		{
			Tile[] tiles = megaTile.tiles;
			for (int i = 0; i < tiles.Length; i++)
			{
				tiles[i].module = component;
			}
		}
		else
		{
			LevelGrid[x, y].module = component;
		}
		if (type == Module.Type.Mega)
		{
			bool first = false;
			bool topLeft = false;
			bool topRight = false;
			bool rightTop = false;
			bool rightBot = false;
			bool botRight = false;
			bool botLeft = false;
			bool leftBot = false;
			bool leftTop = false;
			if (GridCheckActive(megaTile.tiles[0].x, megaTile.tiles[0].y + 1) && !Enumerable.Contains(megaTile.tiles, GridGetTile(megaTile.tiles[0].x, megaTile.tiles[0].y + 1)))
			{
				topLeft = true;
			}
			if (GridCheckActive(megaTile.tiles[2].x, megaTile.tiles[2].y + 1) && !Enumerable.Contains(megaTile.tiles, GridGetTile(megaTile.tiles[2].x, megaTile.tiles[2].y + 1)))
			{
				topRight = true;
			}
			if (GridCheckActive(megaTile.tiles[2].x + 1, megaTile.tiles[2].y) && !Enumerable.Contains(megaTile.tiles, GridGetTile(megaTile.tiles[2].x + 1, megaTile.tiles[2].y)))
			{
				rightTop = true;
			}
			if (GridCheckActive(megaTile.tiles[3].x + 1, megaTile.tiles[3].y) && !Enumerable.Contains(megaTile.tiles, GridGetTile(megaTile.tiles[3].x + 1, megaTile.tiles[3].y)))
			{
				rightBot = true;
			}
			if (GridCheckActive(megaTile.tiles[3].x, megaTile.tiles[3].y - 1) && !Enumerable.Contains(megaTile.tiles, GridGetTile(megaTile.tiles[3].x, megaTile.tiles[3].y - 1)))
			{
				botRight = true;
			}
			if (GridCheckActive(megaTile.tiles[1].x, megaTile.tiles[1].y - 1) && !Enumerable.Contains(megaTile.tiles, GridGetTile(megaTile.tiles[1].x, megaTile.tiles[1].y - 1)))
			{
				botLeft = true;
			}
			if (GridCheckActive(megaTile.tiles[1].x - 1, megaTile.tiles[1].y) && !Enumerable.Contains(megaTile.tiles, GridGetTile(megaTile.tiles[1].x - 1, megaTile.tiles[1].y)))
			{
				leftBot = true;
			}
			if (GridCheckActive(megaTile.tiles[0].x - 1, megaTile.tiles[0].y) && !Enumerable.Contains(megaTile.tiles, GridGetTile(megaTile.tiles[0].x - 1, megaTile.tiles[0].y)))
			{
				leftTop = true;
			}
			if (megaTile.tiles[0].first || megaTile.tiles[1].first || megaTile.tiles[2].first || megaTile.tiles[3].first)
			{
				first = true;
				if (megaTile.tiles[1].x == LevelWidth / 2 && megaTile.tiles[1].y == 0)
				{
					botLeft = true;
				}
				else if (megaTile.tiles[3].x == LevelWidth / 2 && megaTile.tiles[3].y == 0)
				{
					botRight = true;
				}
			}
			component.ModuleConnectionSetMega(topRight, topLeft, rightTop, rightBot, botRight, botLeft, leftTop, leftBot, first);
		}
		else
		{
			bool first2 = LevelGrid[x, y].first;
			bool top = false;
			bool bottom = false;
			bool right = false;
			bool left = false;
			if (GridCheckActive(x, y + 1))
			{
				top = true;
			}
			if (GridCheckActive(x, y - 1) | first2)
			{
				bottom = true;
			}
			if (GridCheckActive(x + 1, y))
			{
				right = true;
			}
			if (GridCheckActive(x - 1, y))
			{
				left = true;
			}
			component.ModuleConnectionSet(top, bottom, right, left, first2);
		}
		ModulesSpawnedTarget++;
	}

	private IEnumerator GenerateConnectObjects()
	{
		waitingForSubCoroutine = true;
		State = LevelState.ConnectObjects;
		float moduleWidth = ModuleWidth * TileSize;
		double realtimeSinceStartupAsDouble = Time.realtimeSinceStartupAsDouble;
		for (int x = 0; x < LevelWidth; x++)
		{
			for (int y = 0; y < LevelHeight; y++)
			{
				if (!LevelGrid[x, y].active)
				{
					continue;
				}
				MegaTile _megaTile = null;
				if (LevelGrid[x, y].type == Module.Type.Mega)
				{
					foreach (MegaTile megaTile in MegaTiles)
					{
						if (Enumerable.Contains(megaTile.tiles, LevelGrid[x, y]))
						{
							_megaTile = megaTile;
							break;
						}
					}
				}
				if (GridCheckActive(x, y + 1))
				{
					LevelGrid[x, y].connections++;
				}
				if (GridCheckActive(x, y - 1))
				{
					LevelGrid[x, y].connections++;
				}
				if (GridCheckActive(x + 1, y))
				{
					LevelGrid[x, y].connections++;
				}
				if (GridCheckActive(x - 1, y))
				{
					LevelGrid[x, y].connections++;
				}
				float xmid = (float)x * moduleWidth - (float)(LevelWidth / 2) * moduleWidth;
				float ymid = (float)y * moduleWidth + moduleWidth / 2f;
				if (y + 1 < LevelHeight && LevelGrid[x, y + 1].active && !LevelGrid[x, y + 1].connectedBot && (_megaTile == null || !Enumerable.Contains(_megaTile.tiles, LevelGrid[x, y + 1])))
				{
					SpawnConnectObject(new Vector3(xmid, 0f, ymid + moduleWidth / 2f), Vector3.zero);
					LevelGrid[x, y].connectedTop = true;
					if (Time.realtimeSinceStartupAsDouble - realtimeSinceStartupAsDouble >= 0.002)
					{
						yield return null;
						realtimeSinceStartupAsDouble = Time.realtimeSinceStartupAsDouble;
					}
				}
				if (x + 1 < LevelWidth && LevelGrid[x + 1, y].active && !LevelGrid[x + 1, y].connectedLeft && (_megaTile == null || !Enumerable.Contains(_megaTile.tiles, LevelGrid[x + 1, y])))
				{
					SpawnConnectObject(new Vector3(xmid + moduleWidth / 2f, 0f, ymid), new Vector3(0f, 90f, 0f));
					LevelGrid[x, y].connectedRight = true;
					if (Time.realtimeSinceStartupAsDouble - realtimeSinceStartupAsDouble >= 0.002)
					{
						yield return null;
						realtimeSinceStartupAsDouble = Time.realtimeSinceStartupAsDouble;
					}
				}
				if ((y - 1 >= 0 && LevelGrid[x, y - 1].active && !LevelGrid[x, y - 1].connectedTop && (_megaTile == null || !Enumerable.Contains(_megaTile.tiles, LevelGrid[x, y - 1]))) || (x == LevelWidth / 2 && y == 0))
				{
					SpawnConnectObject(new Vector3(xmid, 0f, ymid - moduleWidth / 2f), Vector3.zero);
					LevelGrid[x, y].connectedBot = true;
					if (Time.realtimeSinceStartupAsDouble - realtimeSinceStartupAsDouble >= 0.002)
					{
						yield return null;
						realtimeSinceStartupAsDouble = Time.realtimeSinceStartupAsDouble;
					}
				}
				if (x - 1 >= 0 && LevelGrid[x - 1, y].active && !LevelGrid[x - 1, y].connectedRight && (_megaTile == null || !Enumerable.Contains(_megaTile.tiles, LevelGrid[x - 1, y])))
				{
					SpawnConnectObject(new Vector3(xmid - moduleWidth / 2f, 0f, ymid), Vector3.zero);
					LevelGrid[x, y].connectedLeft = true;
					if (Time.realtimeSinceStartupAsDouble - realtimeSinceStartupAsDouble >= 0.002)
					{
						yield return null;
						realtimeSinceStartupAsDouble = Time.realtimeSinceStartupAsDouble;
					}
				}
			}
		}
		yield return null;
		waitingForSubCoroutine = false;
	}

	private GameObject SpawnConnectObject(Vector3 position, Vector3 rotation)
	{
		//IL_004f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0050: Unknown result type (might be due to invalid IL or missing references)
		//IL_0051: Unknown result type (might be due to invalid IL or missing references)
		//IL_0030: Unknown result type (might be due to invalid IL or missing references)
		//IL_0031: Unknown result type (might be due to invalid IL or missing references)
		//IL_0032: Unknown result type (might be due to invalid IL or missing references)
		if (!Level.ConnectObject.IsValid())
		{
			return null;
		}
		GameObject val = ((GameManager.instance.gameMode != 0) ? PhotonNetwork.InstantiateRoomObject(Level.ConnectObject.ResourcePath, position, Quaternion.Euler(rotation), (byte)0, (object[])null) : Object.Instantiate<GameObject>(Level.ConnectObject.Prefab, position, Quaternion.Euler(rotation)));
		if (!Object.op_Implicit((Object)(object)val))
		{
			return null;
		}
		val.transform.parent = LevelParent.transform;
		ModuleConnectObject component = val.GetComponent<ModuleConnectObject>();
		component.ModuleConnecting = true;
		component.MasterSetup = true;
		return val;
	}

	private IEnumerator GenerateBlockObjects()
	{
		waitingForSubCoroutine = true;
		State = LevelState.BlockObjects;
		float moduleWidth = ModuleWidth * TileSize;
		double realtimeSinceStartupAsDouble = Time.realtimeSinceStartupAsDouble;
		for (int x = 0; x < LevelWidth; x++)
		{
			for (int y = 0; y < LevelHeight; y++)
			{
				if (!LevelGrid[x, y].active || LevelGrid[x, y].type != Module.Type.Normal)
				{
					continue;
				}
				float xmid = (float)x * moduleWidth - (float)(LevelWidth / 2) * moduleWidth;
				float ymid = (float)y * moduleWidth + moduleWidth / 2f;
				if (y + 1 >= LevelHeight || !LevelGrid[x, y + 1].active)
				{
					SpawnBlockObject(new Vector3(xmid, 0f, ymid + moduleWidth / 2f), new Vector3(0f, 180f, 0f));
					if (Time.realtimeSinceStartupAsDouble - realtimeSinceStartupAsDouble >= 0.002)
					{
						yield return null;
						realtimeSinceStartupAsDouble = Time.realtimeSinceStartupAsDouble;
					}
				}
				if (x + 1 >= LevelWidth || !LevelGrid[x + 1, y].active)
				{
					SpawnBlockObject(new Vector3(xmid + moduleWidth / 2f, 0f, ymid), new Vector3(0f, -90f, 0f));
					if (Time.realtimeSinceStartupAsDouble - realtimeSinceStartupAsDouble >= 0.002)
					{
						yield return null;
						realtimeSinceStartupAsDouble = Time.realtimeSinceStartupAsDouble;
					}
				}
				if ((y - 1 < 0 || !LevelGrid[x, y - 1].active) && (x != LevelWidth / 2 || y != 0))
				{
					SpawnBlockObject(new Vector3(xmid, 0f, ymid - moduleWidth / 2f), new Vector3(0f, 0f, 0f));
					if (Time.realtimeSinceStartupAsDouble - realtimeSinceStartupAsDouble >= 0.002)
					{
						yield return null;
						realtimeSinceStartupAsDouble = Time.realtimeSinceStartupAsDouble;
					}
				}
				if (x - 1 < 0 || !LevelGrid[x - 1, y].active)
				{
					SpawnBlockObject(new Vector3(xmid - moduleWidth / 2f, 0f, ymid), new Vector3(0f, 90f, 0f));
					if (Time.realtimeSinceStartupAsDouble - realtimeSinceStartupAsDouble >= 0.002)
					{
						yield return null;
						realtimeSinceStartupAsDouble = Time.realtimeSinceStartupAsDouble;
					}
				}
			}
		}
		yield return null;
		waitingForSubCoroutine = false;
	}

	private void SpawnBlockObject(Vector3 position, Vector3 rotation)
	{
		//IL_004e: Unknown result type (might be due to invalid IL or missing references)
		//IL_004f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0050: Unknown result type (might be due to invalid IL or missing references)
		//IL_002f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0030: Unknown result type (might be due to invalid IL or missing references)
		//IL_0031: Unknown result type (might be due to invalid IL or missing references)
		if (Level.BlockObject.IsValid())
		{
			GameObject val = ((GameManager.instance.gameMode != 0) ? PhotonNetwork.InstantiateRoomObject(Level.BlockObject.ResourcePath, position, Quaternion.Euler(rotation), (byte)0, (object[])null) : Object.Instantiate<GameObject>(Level.BlockObject.Prefab, position, Quaternion.Euler(rotation)));
			val.transform.parent = LevelParent.transform;
		}
	}

	private IEnumerator EnemySetup()
	{
		RoomVolume roomVolume = null;
		foreach (RoomVolume item2 in Object.FindObjectsByType<RoomVolume>((FindObjectsSortMode)0).ToList())
		{
			if (item2.Truck)
			{
				roomVolume = item2;
				break;
			}
		}
		LevelPoint furthestPoint = null;
		float num = 0f;
		foreach (LevelPoint levelPathPoint in LevelPathPoints)
		{
			if (Object.op_Implicit((Object)(object)roomVolume))
			{
				float num2 = Vector3.Distance(((Component)levelPathPoint).transform.position, ((Component)roomVolume).transform.position);
				if (num2 > num)
				{
					num = num2;
					furthestPoint = levelPathPoint;
				}
			}
		}
		RunManager.instance.EnemiesSpawnedRemoveStart();
		List<EnemySetup> _enemiesToSpawn = new List<EnemySetup>();
		bool flag = false;
		if (EnemyDirector.instance.debugEnemy != null)
		{
			flag = true;
			if (Object.op_Implicit((Object)(object)furthestPoint))
			{
				EnemySetup[] debugEnemy = EnemyDirector.instance.debugEnemy;
				foreach (EnemySetup item in debugEnemy)
				{
					_enemiesToSpawn.Add(item);
				}
			}
		}
		if (!flag)
		{
			EnemyDirector.instance.AmountSetup();
			if (Object.op_Implicit((Object)(object)furthestPoint))
			{
				for (int j = 0; j < EnemyDirector.instance.totalAmount; j++)
				{
					_enemiesToSpawn.Add(EnemyDirector.instance.GetEnemy());
				}
			}
			EnemyDirector.instance.DebugResult();
		}
		yield return PrefabsPrepare(_enemiesToSpawn.SelectMany((EnemySetup _enemy) => _enemy.spawnObjects));
		foreach (EnemySetup item3 in _enemiesToSpawn)
		{
			yield return EnemySpawnBudgeted(item3, ((Component)furthestPoint).transform.position);
			yield return null;
		}
		RunManager.instance.EnemiesSpawnedRemoveEnd();
		if (GameManager.Multiplayer())
		{
			PhotonView.RPC("EnemySpawnTargetRPC", (RpcTarget)3, new object[1] { EnemiesSpawnTarget });
		}
	}

	private IEnumerator EnemySpawnBudgeted(EnemySetup _enemySetup, Vector3 _position)
	{
		//IL_0015: Unknown result type (might be due to invalid IL or missing references)
		//IL_0016: Unknown result type (might be due to invalid IL or missing references)
		double realtimeSinceStartupAsDouble = Time.realtimeSinceStartupAsDouble;
		for (int _index = 0; _index < _enemySetup.spawnObjects.Count; _index++)
		{
			EnemySpawnObject(_enemySetup.spawnObjects[_index], _position, _enemySetup);
			if (_index + 1 < _enemySetup.spawnObjects.Count && Time.realtimeSinceStartupAsDouble - realtimeSinceStartupAsDouble >= 0.002)
			{
				yield return null;
				realtimeSinceStartupAsDouble = Time.realtimeSinceStartupAsDouble;
			}
		}
	}

	public void EnemySpawn(EnemySetup enemySetup, Vector3 position)
	{
		//IL_0018: Unknown result type (might be due to invalid IL or missing references)
		foreach (PrefabRef spawnObject in enemySetup.spawnObjects)
		{
			EnemySpawnObject(spawnObject, position, enemySetup);
		}
	}

	private void EnemySpawnObject(PrefabRef _enemy, Vector3 _position, EnemySetup _setup = null)
	{
		//IL_0026: Unknown result type (might be due to invalid IL or missing references)
		//IL_0027: Unknown result type (might be due to invalid IL or missing references)
		//IL_0012: Unknown result type (might be due to invalid IL or missing references)
		//IL_0013: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c7: Unknown result type (might be due to invalid IL or missing references)
		//IL_0086: Unknown result type (might be due to invalid IL or missing references)
		GameObject val = ((GameManager.instance.gameMode != 0) ? PhotonNetwork.InstantiateRoomObject(_enemy.ResourcePath, _position, Quaternion.identity, (byte)0, EnemyFloaterHalloweenState.SpawnData(_enemy)) : Object.Instantiate<GameObject>(_enemy.Prefab, _position, Quaternion.identity));
		if (!Object.op_Implicit((Object)(object)val))
		{
			string text = (Object.op_Implicit((Object)(object)_setup) ? (" from enemy setup " + ((Object)_setup).name) : "");
			Debug.LogError((object)("couldn't spawn enemy " + _enemy.ResourcePath + text + " in module " + SemiFunc.ModuleNameGet(_position) + "... check its prefab ref in the enemy setup... it needs a prefab inside a Resources folder or a loaded asset bundle... skipping it so the level can finish loading"), (Object)(object)_setup);
			return;
		}
		EnemyParent component = val.GetComponent<EnemyParent>();
		if (Object.op_Implicit((Object)(object)component))
		{
			component.SetupDone = true;
			Enemy componentInChildren = val.GetComponentInChildren<Enemy>();
			if (Object.op_Implicit((Object)(object)componentInChildren))
			{
				componentInChildren.EnemyTeleported(_position);
			}
			else
			{
				Debug.LogError((object)("enemy " + ((Object)val).name + (Object.op_Implicit((Object)(object)_setup) ? (" from enemy setup " + ((Object)_setup).name) : "") + " has no Enemy component on a child... fix the prefab... it still counts as spawned so loading can finish"), (Object)(object)val);
			}
			EnemiesSpawnTarget++;
			EnemyDirector.instance.FirstSpawnPointAdd(component);
		}
	}

	[PunRPC]
	private void GenerateDone(PhotonMessageInfo _info = default(PhotonMessageInfo))
	{
		//IL_0000: Unknown result type (might be due to invalid IL or missing references)
		if (SemiFunc.MasterOnlyRPC(_info) && !Generated && navMeshBuildState != NavMeshBuildState.Cancelled && navMeshBuildState != NavMeshBuildState.Failed)
		{
			generateDonePending = true;
			if (LocalSetupReady)
			{
				GenerateDoneApply();
			}
		}
	}

	private void GenerateDoneApply()
	{
		generateDonePending = false;
		PhotonNetwork.DispatchTimeBudget = 0f;
		RunManager.instance.multiplayerPool.SpareClear();
		SemiFunc.OnLevelGenDone();
		GameDirector.instance.SetStart();
		Generated = true;
	}

	private bool PlayerReadySenderCheck(Player _player)
	{
		Room currentRoom = PhotonNetwork.CurrentRoom;
		if (_player != null && currentRoom != null)
		{
			return currentRoom.GetPlayer(_player.ActorNumber, false) == _player;
		}
		return false;
	}

	private bool PlayersReadyCheck(List<Player> _players, out int _ready)
	{
		_ready = 0;
		Room currentRoom = PhotonNetwork.CurrentRoom;
		if (currentRoom == null || currentRoom.PlayerCount == 0)
		{
			return false;
		}
		foreach (Player value in currentRoom.Players.Values)
		{
			if (_players.Contains(value))
			{
				_ready++;
			}
		}
		return _ready == currentRoom.PlayerCount;
	}

	private bool PlayerSpawnReadyCheck()
	{
		if (!SemiFunc.IsMultiplayer())
		{
			return playerSpawned >= GameDirector.instance.PlayerList.Count;
		}
		return PlayersReadyCheck(SpawnedReadyPlayerList, out playerSpawned);
	}

	internal void EnemySpawnReady()
	{
		if (GameManager.Multiplayer() && !Generated && enemySpawnTargetReceived && !enemyReadySent && EnemiesSpawnTarget > 0 && EnemiesSpawned >= EnemiesSpawnTarget)
		{
			enemyReadySent = true;
			PhotonView.RPC("EnemyReadyRPC", (RpcTarget)0, Array.Empty<object>());
		}
	}

	[PunRPC]
	private void EnemySpawnTargetRPC(int _amount, PhotonMessageInfo _info = default(PhotonMessageInfo))
	{
		//IL_0000: Unknown result type (might be due to invalid IL or missing references)
		if (SemiFunc.MasterOnlyRPC(_info))
		{
			EnemiesSpawnTarget = _amount;
			enemySpawnTargetReceived = true;
			EnemySpawnReady();
		}
	}

	[PunRPC]
	private void EnemyReadyRPC(PhotonMessageInfo _info = default(PhotonMessageInfo))
	{
		//IL_0001: Unknown result type (might be due to invalid IL or missing references)
		//IL_0015: Unknown result type (might be due to invalid IL or missing references)
		//IL_0028: Unknown result type (might be due to invalid IL or missing references)
		if (PlayerReadySenderCheck(_info.Sender) && !EnemyReadyPlayerList.Contains(_info.Sender))
		{
			EnemyReadyPlayerList.Add(_info.Sender);
			EnemyReadyPlayers++;
		}
	}

	[PunRPC]
	private void EnemyReadyAllRPC(PhotonMessageInfo _info = default(PhotonMessageInfo))
	{
		//IL_0000: Unknown result type (might be due to invalid IL or missing references)
		if (SemiFunc.MasterOnlyRPC(_info))
		{
			EnemyReady = true;
		}
	}

	[PunRPC]
	private void PlayerSpawnedRPC(PhotonMessageInfo _info = default(PhotonMessageInfo))
	{
		//IL_0001: Unknown result type (might be due to invalid IL or missing references)
		//IL_0015: Unknown result type (might be due to invalid IL or missing references)
		//IL_0028: Unknown result type (might be due to invalid IL or missing references)
		if (PlayerReadySenderCheck(_info.Sender) && !SpawnedReadyPlayerList.Contains(_info.Sender))
		{
			SpawnedReadyPlayerList.Add(_info.Sender);
			playerSpawned++;
		}
	}

	[PunRPC]
	private void ModulesReadyRPC(PhotonMessageInfo _info = default(PhotonMessageInfo))
	{
		//IL_0001: Unknown result type (might be due to invalid IL or missing references)
		//IL_0015: Unknown result type (might be due to invalid IL or missing references)
		//IL_0028: Unknown result type (might be due to invalid IL or missing references)
		if (PlayerReadySenderCheck(_info.Sender) && !ModulesReadyPlayerList.Contains(_info.Sender))
		{
			ModulesReadyPlayerList.Add(_info.Sender);
			ModulesReadyPlayers++;
		}
	}

	[PunRPC]
	private void ModuleAmountRPC(int amount, PhotonMessageInfo _info = default(PhotonMessageInfo))
	{
		//IL_0000: Unknown result type (might be due to invalid IL or missing references)
		if (SemiFunc.MasterOnlyRPC(_info))
		{
			ModulesSpawnedTarget = amount;
			moduleAmountReceived = true;
		}
	}

	public void RestartParticleDistances()
	{
		foreach (ParticleDistance particleDistance in particleDistances)
		{
			if (((Behaviour)particleDistance).isActiveAndEnabled)
			{
				particleDistance.Restart();
			}
		}
	}

	public void OnPhotonSerializeView(PhotonStream stream, PhotonMessageInfo info)
	{
		//IL_0000: Unknown result type (might be due to invalid IL or missing references)
		if (SemiFunc.MasterOnlyRPC(info))
		{
			if (stream.IsWriting)
			{
				stream.SendNext((object)ModulesReadyPlayers);
			}
			else
			{
				ModulesReadyPlayers = (int)stream.ReceiveNext();
			}
		}
	}

	public LevelGenerator()
	{
		//IL_005d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0062: Unknown result type (might be due to invalid IL or missing references)
		//IL_0078: Unknown result type (might be due to invalid IL or missing references)
		//IL_007d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0093: Unknown result type (might be due to invalid IL or missing references)
		//IL_0098: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ae: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b3: Unknown result type (might be due to invalid IL or missing references)
	}

	static LevelGenerator()
	{
		//IL_0023: Unknown result type (might be due to invalid IL or missing references)
		//IL_0028: Unknown result type (might be due to invalid IL or missing references)
		//IL_0032: Unknown result type (might be due to invalid IL or missing references)
		//IL_0037: Unknown result type (might be due to invalid IL or missing references)
		//IL_0041: Unknown result type (might be due to invalid IL or missing references)
		//IL_0046: Unknown result type (might be due to invalid IL or missing references)
	}
}
