using System;
using System.Collections;
using TMPro;
using UnityEngine;
using UnityEngine.Events;
using UnityEngine.InputSystem;
using UnityEngine.InputSystem.Controls;
using UnityEngine.InputSystem.Utilities;

public class MenuKeybind : MonoBehaviour
{
	public KeyType keyType;

	public InputKey inputKey;

	public MovementDirection movementDirection;

	public int bindingOccurrence;

	[Tooltip("Pressing Delete while rebinding clears this binding. When off, Delete can be bound like any other key.")]
	public bool canBeUnbinded;

	private MenuBigButton menuBigButton;

	private MenuPage parentPage;

	private MenuSettingElement settingElement;

	private InputAction action;

	private int rebindingBindingIndex = -1;

	private bool actionWasEnabled;

	private InputAction[] uiActions;

	private Coroutine unmaskUICoroutine;

	private string TargetScheme
	{
		get
		{
			if (!((Object)(object)parentPage != (Object)null) || parentPage.menuPageIndex != MenuPageIndex.SettingsGamepad)
			{
				return "Keyboard&Mouse";
			}
			return "Gamepad";
		}
	}

	private string OtherScheme
	{
		get
		{
			if (!(TargetScheme == "Gamepad"))
			{
				return "Gamepad";
			}
			return "Keyboard&Mouse";
		}
	}

	private void Start()
	{
		menuBigButton = ((Component)this).GetComponent<MenuBigButton>();
		parentPage = ((Component)this).GetComponentInParent<MenuPage>();
		settingElement = ((Component)this).GetComponent<MenuSettingElement>();
	}

	private void OnEnable()
	{
		InputManager.instance.keyboardLayoutChangedEvents.AddListener((UnityAction<string>)InputLayoutChanged);
		((MonoBehaviour)this).StartCoroutine(LateStart());
	}

	private void OnDisable()
	{
		InputManager.instance.keyboardLayoutChangedEvents.RemoveListener((UnityAction<string>)InputLayoutChanged);
		UnmaskUI();
	}

	private void InputLayoutChanged(string _keyboardLayout)
	{
		UpdateBindingDisplay();
	}

	private IEnumerator LateStart()
	{
		yield return null;
		UpdateBindingDisplay();
	}

	private void LateUpdate()
	{
		//IL_00a5: Unknown result type (might be due to invalid IL or missing references)
		//IL_00aa: Unknown result type (might be due to invalid IL or missing references)
		if (!((Object)(object)menuBigButton == (Object)null) && menuBigButton.state == MenuBigButton.State.Edit && InputManager.instance.rebindingOperation != null)
		{
			string currentMenuID = MenuManager.instance.currentMenuID;
			if ((TargetScheme == "Gamepad" || SemiFunc.InputMode() == InputModes.Gamepad) && !string.IsNullOrEmpty(currentMenuID) && currentMenuID != menuBigButton.menuButton.MenuID)
			{
				StopRebinding(null, isDestroy: false, playConfirm: false);
			}
			else if (canBeUnbinded && Keyboard.current != null && ((ButtonControl)Keyboard.current.deleteKey).wasPressedThisFrame)
			{
				ClearBinding();
			}
			else if (!(SemiFunc.InputUINavigate() != Vector2.zero) && ((TargetScheme == "Gamepad") ? AnyKeyboardOrMouseButtonPressedThisFrame() : AnyGamepadButtonPressedThisFrame()))
			{
				MenuManager.instance.MenuEffectClick(MenuManager.MenuClickEffectType.Deny, parentPage);
			}
		}
	}

	private static bool AnyGamepadButtonPressedThisFrame()
	{
		//IL_000c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0011: Unknown result type (might be due to invalid IL or missing references)
		//IL_0014: Unknown result type (might be due to invalid IL or missing references)
		//IL_0019: Unknown result type (might be due to invalid IL or missing references)
		Gamepad current = Gamepad.current;
		if (current == null)
		{
			return false;
		}
		Enumerator<InputControl> enumerator = ((InputDevice)current).allControls.GetEnumerator();
		try
		{
			while (enumerator.MoveNext())
			{
				InputControl current2 = enumerator.Current;
				ButtonControl val = (ButtonControl)(object)((current2 is ButtonControl) ? current2 : null);
				if (val != null && val.wasPressedThisFrame)
				{
					return true;
				}
			}
		}
		finally
		{
			((IDisposable)enumerator/*cast due to constrained. prefix*/).Dispose();
		}
		return false;
	}

	private static bool AnyKeyboardOrMouseButtonPressedThisFrame()
	{
		if (Keyboard.current != null && ((ButtonControl)Keyboard.current.anyKey).wasPressedThisFrame)
		{
			return true;
		}
		Mouse current = Mouse.current;
		if (current != null && (current.leftButton.wasPressedThisFrame || current.rightButton.wasPressedThisFrame || current.middleButton.wasPressedThisFrame))
		{
			return true;
		}
		return false;
	}

	private void UpdateBindingDisplay()
	{
		string text = InputManager.instance.InputDisplayGet(inputKey, keyType, movementDirection, TargetScheme, bindingOccurrence);
		menuBigButton.buttonName = text;
		((TMP_Text)menuBigButton.menuButton.buttonText).text = text;
		if (inputKey == InputKey.Chat && Object.op_Implicit((Object)(object)MenuPageLobby.instance))
		{
			MenuPageLobby.instance.UpdateChatPrompt();
		}
	}

	public void OnClick()
	{
		if (InputManager.instance.rebindingOperation == null && parentPage.SettingElementActiveCheckFree(settingElement.settingElementID))
		{
			menuBigButton.state = MenuBigButton.State.Edit;
			parentPage.SettingElementActiveSet(settingElement.settingElementID);
			StartRebinding();
		}
	}

	private void StartRebinding()
	{
		if (keyType == KeyType.InputKey)
		{
			action = InputManager.instance.GetAction(inputKey);
			if (action == null)
			{
				return;
			}
			int activeBindingIndexForScheme = InputManager.instance.GetActiveBindingIndexForScheme(action, TargetScheme, bindingOccurrence);
			if (activeBindingIndexForScheme < 0)
			{
				return;
			}
			rebindingBindingIndex = activeBindingIndexForScheme;
			MaskUIToOtherDevice();
			actionWasEnabled = action.enabled;
			action.Disable();
			InputManager.instance.rebindingOperation = InputActionRebindingExtensions.PerformInteractiveRebinding(action, activeBindingIndexForScheme);
			InputManager.ExcludedControlEntry excludedControlEntry = InputManager.instance.excludedControls.Find((InputManager.ExcludedControlEntry x) => x.inputKey == inputKey);
			if (excludedControlEntry != null)
			{
				foreach (string excludedPath in excludedControlEntry.excludedPaths)
				{
					InputManager.instance.rebindingOperation = InputManager.instance.rebindingOperation.WithControlsExcluding(excludedPath);
				}
			}
			string text = (string.IsNullOrEmpty(action.expectedControlType) ? "Axis" : action.expectedControlType);
			InputManager.instance.rebindingOperation = ApplyDeviceRestriction(InputManager.instance.rebindingOperation.WithExpectedControlType(text)).WithCancelingThrough("").OnComplete((Action<RebindingOperation>)((RebindingOperation op) =>
			{
				StopRebinding(op.selectedControl);
			})).Start();
		}
		else
		{
			if (keyType != KeyType.MovementKey)
			{
				return;
			}
			MaskUIToOtherDevice();
			action = InputManager.instance.GetMovementAction();
			int movementBindingIndex = InputManager.instance.GetMovementBindingIndex(movementDirection);
			if (action != null && movementBindingIndex >= 0)
			{
				rebindingBindingIndex = movementBindingIndex;
				actionWasEnabled = action.enabled;
				action.Disable();
				InputManager.instance.rebindingOperation = ApplyDeviceRestriction(InputActionRebindingExtensions.PerformInteractiveRebinding(action, movementBindingIndex)).WithCancelingThrough("").OnComplete((Action<RebindingOperation>)((RebindingOperation op) =>
				{
					StopRebinding(op.selectedControl);
				})).Start();
			}
		}
	}

	private void MaskUIToOtherDevice()
	{
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0081: Unknown result type (might be due to invalid IL or missing references)
		if (unmaskUICoroutine != null)
		{
			((MonoBehaviour)this).StopCoroutine(unmaskUICoroutine);
			unmaskUICoroutine = null;
		}
		uiActions = new InputAction[4]
		{
			InputManager.instance.GetAction(InputKey.UIClick),
			InputManager.instance.GetAction(InputKey.UINavigate),
			InputManager.instance.GetAction(InputKey.Back),
			InputManager.instance.GetAction(InputKey.Menu)
		};
		InputBinding value = InputBinding.MaskByGroup(OtherScheme);
		InputAction[] array = uiActions;
		foreach (InputAction val in array)
		{
			if (val != null)
			{
				val.bindingMask = value;
			}
		}
	}

	private void UnmaskUI()
	{
		if (uiActions == null)
		{
			return;
		}
		InputAction[] array = uiActions;
		foreach (InputAction val in array)
		{
			if (val != null)
			{
				val.bindingMask = null;
			}
		}
		uiActions = null;
		unmaskUICoroutine = null;
		if (((Behaviour)this).isActiveAndEnabled)
		{
			UpdateBindingDisplay();
		}
	}

	private IEnumerator UnmaskUIAfterRelease(InputControl control)
	{
		while (control.device.added && InputControlExtensions.IsActuated(control, 0.2f))
		{
			yield return null;
		}
		UnmaskUI();
	}

	private RebindingOperation ApplyDeviceRestriction(RebindingOperation operation)
	{
		operation = operation.WithActionEventNotificationsBeingSuppressed(true);
		if (TargetScheme == "Gamepad")
		{
			return operation.WithControlsHavingToMatchPath("<Gamepad>").WithControlsExcluding("<Gamepad>/leftTriggerButton").WithControlsExcluding("<Gamepad>/rightTriggerButton");
		}
		operation = operation.WithControlsHavingToMatchPath("<Keyboard>").WithControlsHavingToMatchPath("<Mouse>");
		if (!canBeUnbinded)
		{
			return operation;
		}
		return operation.WithControlsExcluding("<Keyboard>/delete");
	}

	private void ClearBinding()
	{
		if (action != null && rebindingBindingIndex >= 0)
		{
			InputActionRebindingExtensions.ApplyBindingOverride(action, rebindingBindingIndex, "");
			StopRebinding((InputControl)(object)Keyboard.current.deleteKey);
		}
	}

	private void StopRebinding(InputControl heldControl = null, bool isDestroy = false, bool playConfirm = true)
	{
		if (actionWasEnabled)
		{
			InputAction val = action;
			if (val != null)
			{
				val.Enable();
			}
		}
		if (heldControl != null && !isDestroy && ((Behaviour)this).isActiveAndEnabled)
		{
			unmaskUICoroutine = ((MonoBehaviour)this).StartCoroutine(UnmaskUIAfterRelease(heldControl));
		}
		else
		{
			UnmaskUI();
		}
		if (inputKey == InputKey.Movement)
		{
			InputManager.instance.SyncUINavigateWithMovement();
		}
		if (!isDestroy)
		{
			menuBigButton.state = MenuBigButton.State.Main;
			UpdateBindingDisplay();
			if (playConfirm)
			{
				MenuManager.instance.MenuEffectClick(MenuManager.MenuClickEffectType.Confirm, parentPage, 0.2f);
			}
		}
		RebindingOperation rebindingOperation = InputManager.instance.rebindingOperation;
		if (rebindingOperation != null)
		{
			rebindingOperation.Dispose();
		}
		InputManager.instance.rebindingOperation = null;
	}

	private void OnDestroy()
	{
		if (Object.op_Implicit((Object)(object)menuBigButton) && menuBigButton.state == MenuBigButton.State.Edit)
		{
			StopRebinding(null, isDestroy: true);
		}
	}
}
