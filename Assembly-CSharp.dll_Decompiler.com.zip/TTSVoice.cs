using System.Text;
using Strobotnik.Klattersynth;
using UnityEngine;
using UnityEngine.UI;

public class TTSVoice : MonoBehaviour
{
	internal PlayerAvatar playerAvatar;

	internal bool isPlayerAvatarDisabledPrev;

	public Text baseFreqHzLabel;

	public Speech[] voices;

	internal string voiceText;

	internal int voiceTextWordIndex;

	internal bool isSpeaking;

	internal AudioSource audioSource;

	private Speech activeVoice;

	private int activeVoiceNum;

	private int voiceBaseFrequency;

	private VoicingSource voicingSource;

	internal float currentWordTime;

	private float tumbleCooldown;

	private float noClipLoudnessTimer;

	private void Init()
	{
		if (voices.Length != 0)
		{
			setVoice(0);
			return;
		}
		Debug.LogError((object)"Empty voices array!", (Object)(object)this);
		((Component)this).gameObject.SetActive(false);
	}

	internal void PlayerAvatarBind(PlayerAvatar _playerAvatar)
	{
		if (playerAvatar != _playerAvatar)
		{
			playerAvatar = _playerAvatar;
			if (Object.op_Implicit((Object)(object)playerAvatar))
			{
				isPlayerAvatarDisabledPrev = playerAvatar.isDisabled;
			}
		}
	}

	public void TTSSpeakNow(string text, bool crouch, string localeCode)
	{
		StartSpeakingWithHighlight(text, crouch, localeCode);
	}

	public void StopAndClearVoice()
	{
		voices[0].stop(allScheduled: true);
		voices[0].cacheClear();
		voices[0].scheduleClear();
		voices[1].stop(allScheduled: true);
		voices[1].cacheClear();
		voices[1].scheduleClear();
	}

	public void StartSpeakingWithHighlight(string text, bool crouch, string localeCode)
	{
		//IL_001b: Unknown result type (might be due to invalid IL or missing references)
		//IL_000b: Unknown result type (might be due to invalid IL or missing references)
		StopAndClearVoice();
		if (crouch)
		{
			voicingSource = (VoicingSource)1;
			setVoice(1);
		}
		else
		{
			voicingSource = (VoicingSource)0;
			setVoice(0);
		}
		if (!Object.op_Implicit((Object)(object)activeVoice))
		{
			Debug.LogError((object)"Active voice is not set.");
			return;
		}
		foreach (TTSFormatting.SpeechPart speechPart in TTSFormatting.GetSpeechParts(text, localeCode))
		{
			if (!string.IsNullOrWhiteSpace(speechPart.speechText))
			{
				activeVoice.schedule(TranslateSpecialLetters(speechPart.speechText), bracketsAsPhonemes: true, speechPart.displayText);
			}
		}
	}

	public void setVoice(int num)
	{
		if (num >= 0 && num < voices.Length)
		{
			activeVoice = voices[num];
			activeVoiceNum = num;
		}
		else
		{
			Debug.LogWarning((object)("Invalid voice: " + num), (Object)(object)this);
		}
	}

	public void VoiceText(string text, float wordTime)
	{
		if (Object.op_Implicit((Object)(object)playerAvatar) && Object.op_Implicit((Object)(object)WorldSpaceUIParent.instance))
		{
			WorldSpaceUIParent.instance.TTS(playerAvatar, text, wordTime);
		}
		voiceText = text;
		currentWordTime = wordTime;
	}

	private void Awake()
	{
		Init();
		audioSource = ((Component)this).GetComponent<AudioSource>();
	}

	private string TranslateSpecialLetters(string _text)
	{
		StringBuilder stringBuilder = new StringBuilder(_text.Length + 8);
		foreach (char c in _text)
		{
			switch (char.ToLowerInvariant(c))
			{
			case 'ö':
			case 'ø':
				stringBuilder.Append("ur");
				break;
			case 'ä':
				stringBuilder.Append("eh");
				break;
			case 'æ':
				stringBuilder.Append('a');
				break;
			case 'å':
				stringBuilder.Append("aw");
				break;
			case 'ü':
				stringBuilder.Append('u');
				break;
			case 'ß':
				stringBuilder.Append("ss");
				break;
			case 'à':
			case 'á':
			case 'â':
			case 'ã':
				stringBuilder.Append('a');
				break;
			case 'è':
			case 'é':
			case 'ê':
			case 'ë':
				stringBuilder.Append('e');
				break;
			case 'ì':
			case 'í':
			case 'î':
			case 'ï':
				stringBuilder.Append('i');
				break;
			case 'ò':
			case 'ó':
			case 'ô':
			case 'õ':
				stringBuilder.Append('o');
				break;
			case 'ù':
			case 'ú':
			case 'û':
				stringBuilder.Append('u');
				break;
			case 'ç':
				stringBuilder.Append('s');
				break;
			case 'ñ':
			case 'ń':
				stringBuilder.Append('n');
				break;
			case 'ś':
			case 'ş':
			case 'š':
				stringBuilder.Append("sh");
				break;
			case 'ź':
			case 'ż':
			case 'ž':
				stringBuilder.Append('z');
				break;
			case 'ć':
			case 'č':
				stringBuilder.Append("ch");
				break;
			case 'ł':
				stringBuilder.Append('w');
				break;
			case 'ą':
				stringBuilder.Append("on");
				break;
			case 'ę':
				stringBuilder.Append("en");
				break;
			case 'ı':
				stringBuilder.Append('i');
				break;
			case 'œ':
				stringBuilder.Append("ur");
				break;
			case 'ý':
				stringBuilder.Append('i');
				break;
			default:
				stringBuilder.Append(c);
				break;
			case 'ğ':
				break;
			}
		}
		return stringBuilder.ToString();
	}

	private void Update()
	{
		if (Object.op_Implicit((Object)(object)playerAvatar) && isPlayerAvatarDisabledPrev != playerAvatar.isDisabled)
		{
			StopAndClearVoice();
			isPlayerAvatarDisabledPrev = playerAvatar.isDisabled;
		}
		isSpeaking = audioSource.isPlaying;
		if (isSpeaking && Object.op_Implicit((Object)(object)playerAvatar) && Object.op_Implicit((Object)(object)playerAvatar.voiceChat) && playerAvatar.voiceChat.clipLoudnessTTS <= 0.01f)
		{
			if (noClipLoudnessTimer > 2f)
			{
				StopAndClearVoice();
			}
			noClipLoudnessTimer += Time.deltaTime;
		}
		else
		{
			noClipLoudnessTimer = 0f;
		}
	}
}
