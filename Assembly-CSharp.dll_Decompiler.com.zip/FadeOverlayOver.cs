using UnityEngine;
using UnityEngine.UI;

public class FadeOverlayOver : MonoBehaviour
{
	public static FadeOverlayOver Instance;

	public Image Image;

	[RuntimeInitializeOnLoadMethod(/*Could not decode attribute arguments.*/)]
	private static void RuntimeInitializeOnLoad()
	{
		Instance = null;
	}

	private void Awake()
	{
		Instance = this;
	}

	private void Update()
	{
		//IL_002c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0031: Unknown result type (might be due to invalid IL or missing references)
		//IL_0043: Unknown result type (might be due to invalid IL or missing references)
		//IL_0054: Unknown result type (might be due to invalid IL or missing references)
		//IL_0059: Unknown result type (might be due to invalid IL or missing references)
		//IL_006b: Unknown result type (might be due to invalid IL or missing references)
		if (GameDirector.instance.currentState == GameDirector.gameState.Load || GameDirector.instance.currentState == GameDirector.gameState.End || GameDirector.instance.currentState == GameDirector.gameState.EndWait)
		{
			if (((Graphic)Image).color != Color.black)
			{
				((Graphic)Image).color = Color.black;
			}
		}
		else if (((Graphic)Image).color != Color.clear)
		{
			((Graphic)Image).color = Color.clear;
		}
	}
}
