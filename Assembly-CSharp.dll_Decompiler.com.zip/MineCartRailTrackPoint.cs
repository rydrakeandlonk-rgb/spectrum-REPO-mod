using UnityEngine;

public class MineCartRailTrackPoint : MonoBehaviour
{
	[Tooltip("how round the curve is coming into this point. 1 = tight, 5 = round.")]
	[Range(1f, 5f)]
	public float introMultiplier = 2.5f;

	[Tooltip("how round the curve is leaving this point. 1 = tight, 5 = round.")]
	[Range(1f, 5f)]
	public float outroMultiplier = 2.5f;

	[Tooltip("tilts the rail into the curve here. degrees, blended along the span.")]
	[Range(-89f, 89f)]
	public float bankAngle;

	[Tooltip("cuts a gap in the rail here. rest of the track stays whole.")]
	public bool broken;

	[Tooltip("how far the gap eats backward from this point. meters.")]
	public float backGapDistance = 1f;

	[Tooltip("how far the gap eats forward from this point. meters.")]
	public float forwardGapDistance = 1f;

	[Tooltip("raises (+) or lowers (-) the rail on the back side of the gap. the main track ramps into this as it nears the break. meters.")]
	public float backElevation;

	[Tooltip("how many meters of track the back side takes to ramp into its elevation. bigger = longer, gentler transition. 0 = no ramp.")]
	public float backElevationTransition = 2f;

	[Tooltip("raises (+) or lowers (-) the rail on the front side of the gap. the main track ramps into this as it nears the break. meters.")]
	public float frontElevation;

	[Tooltip("how many meters of track the front side takes to ramp into its elevation. bigger = longer, gentler transition. 0 = no ramp.")]
	public float frontElevationTransition = 2f;
}
