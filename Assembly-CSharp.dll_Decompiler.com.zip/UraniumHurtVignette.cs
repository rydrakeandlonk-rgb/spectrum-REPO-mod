using UnityEngine;

public class UraniumHurtVignette : MonoBehaviour
{
	private HurtCollider hurtCollider;

	private void Start()
	{
		hurtCollider = ((Component)this).GetComponent<HurtCollider>();
	}

	public void HurtVignette()
	{
		//IL_0026: Unknown result type (might be due to invalid IL or missing references)
		if (hurtCollider.onImpactPlayerAvatar.isLocal)
		{
			PostProcessing.Instance.VignetteOverride(new Color(0f, 0.6f, 0f), 0.5f, 0.5f, 5f, 2f, 0.33f, ((Component)this).gameObject);
			CameraZoom.Instance.OverrideZoomSet(80f, 0.33f, 3f, 1f, ((Component)this).gameObject, 50);
			CameraGlitch.Instance.PlayLong();
		}
	}
}
