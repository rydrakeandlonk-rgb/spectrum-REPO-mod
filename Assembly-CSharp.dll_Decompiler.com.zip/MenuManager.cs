using System;
using System.Collections.Generic;
using System.Linq;
using Photon.Pun;
using TMPro;
using UnityEngine;
using UnityEngine.Events;
using UnityEngine.UI;

public class MenuManager : MonoBehaviour
{
	[Serializable]
	public class MenuPages
	{
		public MenuPageIndex menuPageIndex;

		public GameObject menuPage;
	}

	public enum MenuState
	{
		Open,
		Closed
	}

	public enum MenuClickEffectType
	{
		Action,
		Confirm,
		Deny,
		Dud,
		Tick
	}

	public static MenuManager instance;

	internal MenuSelectionBox selectionBox;

	internal MenuSelectionBox activeSelectionBox;

	internal List<MenuPlayerHead> playerHeads = new List<MenuPlayerHead>();

	private List<MenuSelectionBox> selectionBoxes = new List<MenuSelectionBox>();

	internal bool textInputActive;

	private float textInputActiveTimer;

	internal string currentMenuID = "";

	internal string lastHoverMenuID = string.Empty;

	private string lastHoverSkippedMenuID = string.Empty;

	internal RectTransform currentMenuIDTransform;

	private readonly Dictionary<Object, MenuSelectableElement> lastSelectedPerRegion = new Dictionary<Object, MenuSelectableElement>();

	internal bool currentTargetChangedThisFrame;

	private string previousMenuID = string.Empty;

	private const float NAVIGATION_REPEAT_DELAY = 0.3f;

	private const float NAVIGATION_FAST_REPEAT_DELAY = 0.1f;

	private const int NAVIGATION_FAST_REPEAT_THRESHOLD = 3;

	private const float NAVIGATION_DIRECTION_DEADZONE = 0.5f;

	private const float KEYBOARD_NAV_MOUSE_MOVE_THRESHOLD = 0.01f;

	internal bool isKeyboardNavigating;

	private Vector2 navigationHeldDirection;

	private float navigationRepeatTimer;

	private int navigationRepeatCount;

	public List<MenuPages> menuPages;

	internal MenuPageIndex currentMenuPageIndex;

	internal MenuPage currentMenuPage;

	internal int currentMenuState;

	private bool stateStart;

	internal MenuButton currentButton;

	internal int fetchSetting;

	internal Vector3 soundPosition;

	private float menuHover;

	[Space]
	public AudioManager.AudioType defaultSoundType;

	public AudioManager.AudioType cutsceneSoundType;

	private bool cutsceneSoundOverride;

	private float cutsceneSoundOverrideTimer;

	[Space]
	public Sound soundAction;

	public Sound soundConfirm;

	public Sound soundDeny;

	public Sound soundDud;

	public Sound soundTick;

	public Sound soundHover;

	public Sound soundPageIntro;

	public Sound soundPageOutro;

	public Sound soundWindowPopUp;

	public Sound soundWindowPopUpClose;

	public Sound soundMove;

	private int soundPageOutroFrame = -1;

	internal Vector2 mouseHoldPosition;

	internal int screenUIWidth = 720;

	internal int screenUIHeight = 405;

	internal List<MenuPage> allPages = new List<MenuPage>();

	internal List<MenuPage> inactivePages = new List<MenuPage>();

	internal List<MenuPage> addedPagesOnTop = new List<MenuPage>();

	internal bool pagePopUpScheduled;

	private string pagePopUpScheduledHeaderText;

	private Color pagePopUpScheduledHeaderColor;

	private string pagePopUpScheduledBodyText;

	private string pagePopUpScheduledButtonText;

	private bool pagePopUpScheduledRichText;

	private List<MenuButton> allMenuButtons = new List<MenuButton>();

	private List<MenuElementHover> allMenuHovers = new List<MenuElementHover>();

	private List<MenuSelectableElement> allSelectableElements = new List<MenuSelectableElement>();

	private bool marketingMessageLoading;

	public MarketingMessage marketingMessage;

	private static readonly Vector3[] navigationCorners = new Vector3[4];

	private Selectable[] navigationSelectablesBuffer = new Selectable[64];

	public void RegisterButton(MenuButton button)
	{
		allMenuButtons.Add(button);
	}

	public void UnregisterButton(MenuButton button)
	{
		allMenuButtons.Remove(button);
	}

	public void RegisterHoverElement(MenuElementHover hover)
	{
		allMenuHovers.Add(hover);
	}

	public void UnregisterHoverElement(MenuElementHover hover)
	{
		allMenuHovers.Remove(hover);
	}

	public void RegisterSelectableElement(MenuSelectableElement selectable)
	{
		allSelectableElements.Add(selectable);
	}

	public void UnregisterSelectableElement(MenuSelectableElement selectable)
	{
		allSelectableElements.Remove(selectable);
	}

	[RuntimeInitializeOnLoadMethod(/*Could not decode attribute arguments.*/)]
	private static void RuntimeInitializeOnLoad()
	{
		instance = null;
	}

	private void Awake()
	{
		if (!Object.op_Implicit((Object)(object)instance))
		{
			instance = this;
			Object.DontDestroyOnLoad((Object)(object)((Component)this).gameObject);
			soundAction.StoreDefault();
			soundConfirm.StoreDefault();
			soundDeny.StoreDefault();
			soundDud.StoreDefault();
			soundTick.StoreDefault();
		}
		else
		{
			Object.Destroy((Object)(object)((Component)this).gameObject);
		}
	}

	private void Start()
	{
		StateSet(MenuState.Closed);
	}

	private void Update()
	{
		//IL_00c8: Unknown result type (might be due to invalid IL or missing references)
		//IL_00cd: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b5: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ba: Unknown result type (might be due to invalid IL or missing references)
		//IL_01dd: Unknown result type (might be due to invalid IL or missing references)
		//IL_01e2: Unknown result type (might be due to invalid IL or missing references)
		//IL_01be: Unknown result type (might be due to invalid IL or missing references)
		//IL_01c3: Unknown result type (might be due to invalid IL or missing references)
		//IL_01d0: Unknown result type (might be due to invalid IL or missing references)
		//IL_01d5: Unknown result type (might be due to invalid IL or missing references)
		previousMenuID = currentMenuID;
		currentMenuID = "";
		currentMenuIDTransform = null;
		RefreshPageInteractivity();
		List<MenuButton> list = allMenuButtons.ToList();
		foreach (MenuButton item in list)
		{
			if (item.hovering || !Object.op_Implicit((Object)(object)item.parentPage) || item.parentPage.addedPageOnTop || (item.parentPage.currentPageState != MenuPage.PageState.Inactive && item.parentPage.currentPageState != MenuPage.PageState.Closing))
			{
				item.RegisterHover();
			}
		}
		if (Object.op_Implicit((Object)(object)PlayerController.instance))
		{
			soundPosition = ((Component)PlayerController.instance).transform.position;
		}
		else
		{
			soundPosition = ((Component)this).transform.position;
		}
		int num = currentMenuState;
		switch (currentMenuState)
		{
		case 0:
			StateOpen();
			break;
		case 1:
			StateClosed();
			break;
		}
		currentTargetChangedThisFrame = !string.IsNullOrEmpty(previousMenuID) && !string.IsNullOrEmpty(currentMenuID) && currentMenuID != previousMenuID;
		foreach (MenuButton item2 in list)
		{
			if (item2.hovering || !Object.op_Implicit((Object)(object)item2.parentPage) || item2.parentPage.addedPageOnTop || (item2.parentPage.currentPageState != MenuPage.PageState.Inactive && item2.parentPage.currentPageState != MenuPage.PageState.Closing))
			{
				item2.ProcessHover();
			}
		}
		stateStart = num != currentMenuState;
		if (Input.GetMouseButton(0))
		{
			if (mouseHoldPosition == Vector2.zero)
			{
				mouseHoldPosition = SemiFunc.UIMousePosToUIPos();
			}
		}
		else
		{
			mouseHoldPosition = Vector2.zero;
		}
		if (textInputActive)
		{
			if (textInputActiveTimer <= 0f)
			{
				textInputActive = false;
			}
			textInputActiveTimer -= Time.deltaTime;
		}
		if (cutsceneSoundOverride)
		{
			if (cutsceneSoundOverrideTimer <= 0f)
			{
				cutsceneSoundOverride = false;
				soundAction.Type = defaultSoundType;
				soundConfirm.Type = defaultSoundType;
				soundDeny.Type = defaultSoundType;
				soundDud.Type = defaultSoundType;
				soundTick.Type = defaultSoundType;
				soundHover.Type = defaultSoundType;
				soundPageIntro.Type = defaultSoundType;
				soundPageOutro.Type = defaultSoundType;
				soundWindowPopUp.Type = defaultSoundType;
				soundWindowPopUpClose.Type = defaultSoundType;
				soundMove.Type = defaultSoundType;
			}
			cutsceneSoundOverrideTimer -= Time.deltaTime;
		}
	}

	private void LateUpdate()
	{
		if (SemiFunc.InputMode() == InputModes.MouseAndKeyboard && !isKeyboardNavigating && !string.IsNullOrEmpty(currentMenuID) && currentMenuID != lastHoverMenuID)
		{
			if (currentMenuID != lastHoverSkippedMenuID)
			{
				lastHoverSkippedMenuID = (MenuIDNavigable(currentMenuID) ? string.Empty : currentMenuID);
			}
			if (currentMenuID != lastHoverSkippedMenuID)
			{
				lastHoverMenuID = currentMenuID;
			}
		}
	}

	private bool MenuIDNavigable(string menuID)
	{
		foreach (MenuButton allMenuButton in allMenuButtons)
		{
			if (Object.op_Implicit((Object)(object)allMenuButton) && allMenuButton.MenuID == menuID && Object.op_Implicit((Object)(object)allMenuButton.menuSelectableElement))
			{
				return allMenuButton.menuSelectableElement.IsNavigable();
			}
		}
		foreach (MenuElementHover allMenuHover in allMenuHovers)
		{
			if (Object.op_Implicit((Object)(object)allMenuHover) && allMenuHover.menuID == menuID && Object.op_Implicit((Object)(object)allMenuHover.menuSelectableElement))
			{
				return allMenuHover.menuSelectableElement.IsNavigable();
			}
		}
		foreach (MenuSelectableElement allSelectableElement in allSelectableElements)
		{
			if (Object.op_Implicit((Object)(object)allSelectableElement) && allSelectableElement.menuID == menuID)
			{
				return allSelectableElement.IsNavigable();
			}
		}
		return true;
	}

	public void MenuEffectHover(float pitch = -1f, float volume = -1f)
	{
		//IL_0049: Unknown result type (might be due to invalid IL or missing references)
		soundHover.Pitch = ((pitch != -1f) ? pitch : soundHover.PitchDefault);
		soundHover.Volume = ((volume != -1f) ? volume : soundHover.VolumeDefault);
		soundHover.Play(soundPosition);
	}

	public void MenuEffectClick(MenuClickEffectType effectType, MenuPage parentPage = null, float pitch = -1f, float volume = -1f, bool soundOnly = false, bool rumble = true)
	{
		//IL_01f2: Unknown result type (might be due to invalid IL or missing references)
		//IL_028a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0040: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d5: Unknown result type (might be due to invalid IL or missing references)
		//IL_016a: Unknown result type (might be due to invalid IL or missing references)
		//IL_02c3: Unknown result type (might be due to invalid IL or missing references)
		//IL_02a8: Unknown result type (might be due to invalid IL or missing references)
		//IL_0095: Unknown result type (might be due to invalid IL or missing references)
		//IL_012a: Unknown result type (might be due to invalid IL or missing references)
		//IL_01bf: Unknown result type (might be due to invalid IL or missing references)
		//IL_0247: Unknown result type (might be due to invalid IL or missing references)
		//IL_0314: Unknown result type (might be due to invalid IL or missing references)
		switch (effectType)
		{
		case MenuClickEffectType.Action:
			if (rumble)
			{
				SemiFunc.GamepadRumbleThockBigButton();
			}
			if (!soundOnly && Object.op_Implicit((Object)(object)activeSelectionBox))
			{
				activeSelectionBox.SetClick(AssetManager.instance.colorYellow);
			}
			soundAction.Pitch = ((pitch != -1f) ? pitch : soundAction.PitchDefault);
			soundAction.Volume = ((volume != -1f) ? volume : soundAction.VolumeDefault);
			soundAction.Play(soundPosition);
			break;
		case MenuClickEffectType.Confirm:
			if (rumble)
			{
				SemiFunc.GamepadRumbleThockConfirmTap();
			}
			if (!soundOnly && Object.op_Implicit((Object)(object)activeSelectionBox))
			{
				activeSelectionBox.SetClick(Color.green);
			}
			soundConfirm.Pitch = ((pitch != -1f) ? pitch : soundConfirm.PitchDefault);
			soundConfirm.Volume = ((volume != -1f) ? volume : soundConfirm.VolumeDefault);
			soundConfirm.Play(soundPosition);
			break;
		case MenuClickEffectType.Deny:
			if (rumble)
			{
				SemiFunc.GamepadRumbleThockDeny();
			}
			if (!soundOnly && Object.op_Implicit((Object)(object)activeSelectionBox))
			{
				activeSelectionBox.SetClick(Color.red);
			}
			soundDeny.Pitch = ((pitch != -1f) ? pitch : soundDeny.PitchDefault);
			soundDeny.Volume = ((volume != -1f) ? volume : soundDeny.VolumeDefault);
			soundDeny.Play(soundPosition);
			break;
		case MenuClickEffectType.Dud:
			if (rumble)
			{
				SemiFunc.GamepadRumbleThockLetterTap();
			}
			if (!soundOnly)
			{
				activeSelectionBox.SetClick(Color.gray);
			}
			soundDud.Pitch = ((pitch != -1f) ? pitch : soundDud.PitchDefault);
			soundDud.Volume = ((volume != -1f) ? volume : soundDud.VolumeDefault);
			soundDud.Play(soundPosition);
			break;
		case MenuClickEffectType.Tick:
			if (rumble)
			{
				SemiFunc.GamepadRumbleThockLetterTap();
			}
			if (!soundOnly)
			{
				Color click = new Color(0f, 0.5f, 1f, 1f);
				if (!Object.op_Implicit((Object)(object)parentPage))
				{
					if (Object.op_Implicit((Object)(object)MenuSelectionBox.instance))
					{
						MenuSelectionBox.instance.SetClick(click);
					}
				}
				else if (Object.op_Implicit((Object)(object)parentPage.selectionBox))
				{
					parentPage.selectionBox.SetClick(click);
				}
			}
			soundTick.Pitch = ((pitch != -1f) ? pitch : soundTick.PitchDefault);
			soundTick.Volume = ((volume != -1f) ? volume : soundTick.VolumeDefault);
			soundTick.Play(soundPosition);
			break;
		}
	}

	public void MenuEffectPopUpOpen()
	{
		//IL_000c: Unknown result type (might be due to invalid IL or missing references)
		SemiFunc.GamepadRumbleThockMenuUp();
		soundWindowPopUp.Play(soundPosition);
	}

	public void MenuEffectPopUpClose()
	{
		//IL_000c: Unknown result type (might be due to invalid IL or missing references)
		SemiFunc.GamepadRumbleThockMenuDown();
		soundWindowPopUpClose.Play(soundPosition);
	}

	public void MenuEffectPageIntro()
	{
		//IL_000c: Unknown result type (might be due to invalid IL or missing references)
		SemiFunc.GamepadRumbleThockMenuUp();
		soundPageIntro.Play(soundPosition);
	}

	public void MenuEffectPageOutro()
	{
		//IL_0025: Unknown result type (might be due to invalid IL or missing references)
		if (soundPageOutroFrame != Time.frameCount)
		{
			soundPageOutroFrame = Time.frameCount;
			SemiFunc.GamepadRumbleThockMenuDown();
			soundPageOutro.Play(soundPosition);
		}
	}

	public void MenuEffectMove()
	{
		//IL_000c: Unknown result type (might be due to invalid IL or missing references)
		SemiFunc.GamepadRumbleThockLetterTap();
		soundMove.Play(soundPosition);
	}

	public void MenuEffectMove(float pitch)
	{
		MenuEffectMove(pitch, 1f);
	}

	public void MenuEffectMove(float pitch, float volumeMultiplier)
	{
		//IL_0040: Unknown result type (might be due to invalid IL or missing references)
		SemiFunc.GamepadRumbleThockLetterTap();
		float pitch2 = soundMove.Pitch;
		float pitchRandom = soundMove.PitchRandom;
		try
		{
			soundMove.Pitch = pitch;
			soundMove.PitchRandom = 0f;
			soundMove.Play(soundPosition, volumeMultiplier);
		}
		finally
		{
			soundMove.Pitch = pitch2;
			soundMove.PitchRandom = pitchRandom;
		}
	}

	private bool IsBackgroundPage(MenuPage page)
	{
		if (!Object.op_Implicit((Object)(object)page))
		{
			return false;
		}
		if (page.currentPageState == MenuPage.PageState.Closing)
		{
			return true;
		}
		if (!page.addedPageOnTop)
		{
			if (page.currentPageState != MenuPage.PageState.Inactive)
			{
				return !page.isInteractable;
			}
			return true;
		}
		return false;
	}

	private Selectable ResolveNeighbour(Selectable from, Vector2 navigateDir, out bool isManual)
	{
		//IL_0001: Unknown result type (might be due to invalid IL or missing references)
		//IL_0006: Unknown result type (might be due to invalid IL or missing references)
		//IL_0007: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006e: Invalid comparison between Unknown and I4
		//IL_0034: Unknown result type (might be due to invalid IL or missing references)
		//IL_0074: Unknown result type (might be due to invalid IL or missing references)
		Navigation navigation = from.navigation;
		float x = navigateDir.x;
		Selectable val;
		if (x > 0f)
		{
			val = navigation.selectOnRight;
		}
		else if (x < 0f)
		{
			val = navigation.selectOnLeft;
		}
		else
		{
			val = ((navigateDir.y > 0f) ? navigation.selectOnUp : navigation.selectOnDown);
		}
		Selectable val2 = val;
		isManual = Object.op_Implicit((Object)(object)val2);
		if (Object.op_Implicit((Object)(object)val2))
		{
			return val2;
		}
		if ((int)navigation.mode == 4)
		{
			return null;
		}
		return FindSelectableByEdges(from, navigateDir);
	}

	private static (Vector2 min, Vector2 max) NavigationRect(Selectable selectable, bool horizontal)
	{
		//IL_0006: Unknown result type (might be due to invalid IL or missing references)
		//IL_000b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0010: Unknown result type (might be due to invalid IL or missing references)
		//IL_0011: Unknown result type (might be due to invalid IL or missing references)
		//IL_0012: Unknown result type (might be due to invalid IL or missing references)
		//IL_0033: Unknown result type (might be due to invalid IL or missing references)
		//IL_0038: Unknown result type (might be due to invalid IL or missing references)
		//IL_003d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0044: Unknown result type (might be due to invalid IL or missing references)
		//IL_0049: Unknown result type (might be due to invalid IL or missing references)
		//IL_004e: Unknown result type (might be due to invalid IL or missing references)
		//IL_005a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0060: Unknown result type (might be due to invalid IL or missing references)
		//IL_0066: Unknown result type (might be due to invalid IL or missing references)
		//IL_006b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0071: Unknown result type (might be due to invalid IL or missing references)
		//IL_0077: Unknown result type (might be due to invalid IL or missing references)
		//IL_0052: Unknown result type (might be due to invalid IL or missing references)
		//IL_0053: Unknown result type (might be due to invalid IL or missing references)
		Vector2 val = Vector2.op_Implicit(((Component)selectable).transform.position);
		Vector2 val2 = val;
		Transform transform = ((Component)selectable).transform;
		RectTransform val3 = (RectTransform)(object)((transform is RectTransform) ? transform : null);
		if (val3 != null)
		{
			val3.GetWorldCorners(navigationCorners);
			val = Vector2.op_Implicit(navigationCorners[0]);
			val2 = Vector2.op_Implicit(navigationCorners[2]);
		}
		if (!horizontal)
		{
			return (min: val, max: val2);
		}
		return (min: new Vector2(val.y, val.x), max: new Vector2(val2.y, val2.x));
	}

	private Selectable FindSelectableByEdges(Selectable from, Vector2 navigateDir)
	{
		//IL_0000: Unknown result type (might be due to invalid IL or missing references)
		//IL_001c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0014: Unknown result type (might be due to invalid IL or missing references)
		//IL_0030: Unknown result type (might be due to invalid IL or missing references)
		//IL_0035: Unknown result type (might be due to invalid IL or missing references)
		//IL_0036: Unknown result type (might be due to invalid IL or missing references)
		//IL_003b: Unknown result type (might be due to invalid IL or missing references)
		//IL_004c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0044: Unknown result type (might be due to invalid IL or missing references)
		//IL_0054: Unknown result type (might be due to invalid IL or missing references)
		//IL_005a: Unknown result type (might be due to invalid IL or missing references)
		//IL_00de: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e7: Unknown result type (might be due to invalid IL or missing references)
		//IL_00fa: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ff: Unknown result type (might be due to invalid IL or missing references)
		//IL_0101: Unknown result type (might be due to invalid IL or missing references)
		//IL_0106: Unknown result type (might be due to invalid IL or missing references)
		//IL_0108: Unknown result type (might be due to invalid IL or missing references)
		//IL_010f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0135: Unknown result type (might be due to invalid IL or missing references)
		//IL_013c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0146: Unknown result type (might be due to invalid IL or missing references)
		//IL_014c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0167: Unknown result type (might be due to invalid IL or missing references)
		//IL_016e: Unknown result type (might be due to invalid IL or missing references)
		bool flag = navigateDir.x != 0f;
		float num = Mathf.Sign(flag ? navigateDir.x : navigateDir.y);
		(Vector2 min, Vector2 max) tuple = NavigationRect(from, flag);
		Vector2 item = tuple.min;
		Vector2 item2 = tuple.max;
		float num2 = ((num > 0f) ? item2.y : item.y);
		float num3 = (item.x + item2.x) * 0.5f;
		if (navigationSelectablesBuffer.Length < Selectable.allSelectableCount)
		{
			navigationSelectablesBuffer = new Selectable[Mathf.NextPowerOfTwo(Selectable.allSelectableCount)];
		}
		int num4 = Selectable.AllSelectablesNoAlloc(navigationSelectablesBuffer);
		Selectable result = null;
		float num5 = float.PositiveInfinity;
		for (int i = 0; i < num4; i++)
		{
			Selectable val = navigationSelectablesBuffer[i];
			if ((Object)(object)val == (Object)(object)from || !Object.op_Implicit((Object)(object)val) || !val.IsInteractable())
			{
				continue;
			}
			Navigation navigation = val.navigation;
			if ((int)navigation.mode == 0)
			{
				continue;
			}
			(Vector2 min, Vector2 max) tuple2 = NavigationRect(val, flag);
			Vector2 item3 = tuple2.min;
			Vector2 item4 = tuple2.max;
			float num6 = ((item3.y + item4.y) * 0.5f - num2) * num;
			if (!(num6 <= 0f))
			{
				float num7 = Mathf.Max(new float[3]
				{
					0f,
					item3.x - item2.x,
					item.x - item4.x
				});
				float num8 = num6 + num7 * 2f + Mathf.Abs((item3.x + item4.x) * 0.5f - num3) * 0.1f;
				if (num8 < num5)
				{
					num5 = num8;
					result = val;
				}
			}
		}
		return result;
	}

	private void StateOpen()
	{
		//IL_0056: Unknown result type (might be due to invalid IL or missing references)
		//IL_005b: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a5: Unknown result type (might be due to invalid IL or missing references)
		//IL_00aa: Unknown result type (might be due to invalid IL or missing references)
		//IL_0109: Unknown result type (might be due to invalid IL or missing references)
		//IL_010e: Unknown result type (might be due to invalid IL or missing references)
		//IL_010f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0110: Unknown result type (might be due to invalid IL or missing references)
		//IL_0138: Unknown result type (might be due to invalid IL or missing references)
		//IL_02ad: Unknown result type (might be due to invalid IL or missing references)
		//IL_02b8: Unknown result type (might be due to invalid IL or missing references)
		//IL_0442: Unknown result type (might be due to invalid IL or missing references)
		//IL_0456: Unknown result type (might be due to invalid IL or missing references)
		if (stateStart)
		{
			InputManager.instance.SwitchToUIInputs();
		}
		SemiFunc.CursorUnlock(0.1f);
		PlayerController.instance.InputDisableTimer = 0.1f;
		if (!Object.op_Implicit((Object)(object)currentMenuPage))
		{
			StateSet(MenuState.Closed);
			return;
		}
		if (SemiFunc.InputMode() == InputModes.MouseAndKeyboard)
		{
			if (!isKeyboardNavigating && SemiFunc.NoTextInputsActive() && (SemiFunc.InputUINavigate() != Vector2.zero || InputManager.instance.IsUIClickFromKeyboardThisFrame()))
			{
				isKeyboardNavigating = true;
			}
			else if (isKeyboardNavigating)
			{
				if (SemiFunc.NoTextInputsActive() && (!SemiFunc.InputDown(InputKey.UIClick) || InputManager.instance.IsUIClickFromKeyboardThisFrame()))
				{
					Vector2 menuMouseDelta = InputManager.instance.GetMenuMouseDelta();
					if (!(menuMouseDelta.sqrMagnitude > 0.0001f))
					{
						goto IL_00c0;
					}
				}
				isKeyboardNavigating = false;
			}
		}
		goto IL_00c0;
		IL_00c0:
		if ((SemiFunc.InputMode() != InputModes.Gamepad && !isKeyboardNavigating) || InputManager.instance.IsUIClickFromMouseThisFrame() || !SemiFunc.NoExternalTextInputActive() || !TryDetermineCurrentSelectedElement(out var currentSelectedElement))
		{
			return;
		}
		lastHoverMenuID = currentSelectedElement.menuID;
		MenuSelectableElement menuSelectableElement = null;
		Vector2 repeatedNavigationDirection = GetRepeatedNavigationDirection();
		if (!PunExtensions.AlmostEquals(repeatedNavigationDirection, Vector2.zero, float.Epsilon))
		{
			Selectable val = null;
			Selectable val2 = (Selectable)(object)currentSelectedElement;
			bool isManual = false;
			for (int i = 0; i < 16; i++)
			{
				Selectable val3 = ResolveNeighbour(val2, repeatedNavigationDirection, out isManual);
				if ((Object)(object)val3 == (Object)null)
				{
					break;
				}
				if ((((Component)val3).gameObject.activeInHierarchy || HiddenByScrollBox(val3)) && val3.IsInteractable())
				{
					MenuSelectableElement menuSelectableElement2 = null;
					MenuButton menuButton = ((Component)val3).GetComponent<MenuButton>() ?? ((Component)val3).GetComponentInParent<MenuButton>();
					if (!Object.op_Implicit((Object)(object)menuButton))
					{
						MenuBigButton menuBigButton = ((Component)val3).GetComponent<MenuBigButton>() ?? ((Component)val3).GetComponentInParent<MenuBigButton>();
						if (Object.op_Implicit((Object)(object)menuBigButton))
						{
							menuButton = menuBigButton.menuButton;
						}
						MenuTwoOptions menuTwoOptions = ((Component)val3).GetComponent<MenuTwoOptions>() ?? ((Component)val3).GetComponentInParent<MenuTwoOptions>();
						if (Object.op_Implicit((Object)(object)menuTwoOptions))
						{
							menuButton = menuTwoOptions.currentButton;
						}
					}
					if (Object.op_Implicit((Object)(object)menuButton) && Object.op_Implicit((Object)(object)menuButton.menuSelectableElement))
					{
						menuSelectableElement2 = menuButton.menuSelectableElement;
					}
					MenuElementHover menuElementHover = ((Component)val3).GetComponent<MenuElementHover>() ?? ((Component)val3).GetComponentInParent<MenuElementHover>();
					bool flag = Object.op_Implicit((Object)(object)menuElementHover) && Object.op_Implicit((Object)(object)menuElementHover.menuSelectableElement);
					if (flag)
					{
						menuSelectableElement2 = menuElementHover.menuSelectableElement;
					}
					if (!Object.op_Implicit((Object)(object)menuSelectableElement2))
					{
						menuSelectableElement2 = ((Component)val3).GetComponent<MenuSelectableElement>();
					}
					if (!Object.op_Implicit((Object)(object)menuSelectableElement2) || ((Selectable)menuSelectableElement2).IsInteractable())
					{
						val = val3;
						menuSelectableElement = menuSelectableElement2;
						if (flag)
						{
							menuElementHover.OnHoverStart();
						}
						break;
					}
				}
				val2 = val3;
			}
			if ((Object)(object)val != (Object)null && (Object)(object)menuSelectableElement == (Object)null)
			{
				Debug.LogWarning((object)$"MenuManager, attempted to select next element but no valid candidates, {val}", (Object)(object)val);
			}
			bool flag2 = Mathf.Abs(repeatedNavigationDirection.x) > Mathf.Abs(repeatedNavigationDirection.y);
			bool flag3 = (Object)(object)menuSelectableElement != (Object)null && Object.op_Implicit((Object)(object)menuSelectableElement.menuScrollBox) && menuSelectableElement.menuScrollBox.restoreSelectionOnEnter;
			if ((Object)(object)menuSelectableElement != (Object)null && !menuSelectableElement.skipRegionSelectionRestore && (flag2 | flag3))
			{
				Object val4 = NavigationRegionGet(menuSelectableElement);
				if (Object.op_Implicit(val4) && val4 != NavigationRegionGet(currentSelectedElement))
				{
					if (lastSelectedPerRegion.TryGetValue(val4, out var value) && RememberedSelectionValid(value))
					{
						menuSelectableElement = value;
					}
					else if (flag2 && !isManual && (Object)(object)menuSelectableElement.menuScrollBox != (Object)null)
					{
						MenuSelectableElement topmostVisibleSelectable = menuSelectableElement.menuScrollBox.GetTopmostVisibleSelectable();
						if ((Object)(object)topmostVisibleSelectable != (Object)null)
						{
							menuSelectableElement = topmostVisibleSelectable;
						}
					}
				}
			}
		}
		if ((Object)(object)menuSelectableElement == (Object)null)
		{
			menuSelectableElement = currentSelectedElement;
		}
		if (!((Object)(object)menuSelectableElement != (Object)null))
		{
			return;
		}
		bool flag4 = (Object)(object)currentSelectedElement != (Object)(object)menuSelectableElement;
		if (flag4 && (Object)(object)menuSelectableElement.menuScrollBox != (Object)null && !((Component)menuSelectableElement).gameObject.activeInHierarchy)
		{
			RectTransform scroller = menuSelectableElement.menuScrollBox.scroller;
			Transform val5 = ((Component)menuSelectableElement).transform;
			while (Object.op_Implicit((Object)(object)val5) && (Object)(object)val5.parent != (Object)(object)scroller)
			{
				val5 = val5.parent;
			}
			if (Object.op_Implicit((Object)(object)val5) && !((Component)val5).gameObject.activeSelf)
			{
				((Component)val5).gameObject.SetActive(true);
			}
		}
		RememberSelection(menuSelectableElement);
		lastHoverMenuID = menuSelectableElement.menuID;
		currentMenuID = menuSelectableElement.menuID;
		currentMenuIDTransform = menuSelectableElement.rectTransform;
		if (flag4)
		{
			if (repeatedNavigationDirection.y > 0f)
			{
				SemiFunc.GamepadRumbleThockMenuUp();
			}
			else if (repeatedNavigationDirection.y < 0f)
			{
				SemiFunc.GamepadRumbleThockMenuDown();
			}
			else
			{
				SemiFunc.GamepadRumbleThockLetterTap();
			}
			MenuElementCosmeticCategoryScroll componentInParent = ((Component)currentMenuIDTransform).GetComponentInParent<MenuElementCosmeticCategoryScroll>();
			if (Object.op_Implicit((Object)(object)componentInParent))
			{
				componentInParent.ScrollToShow(currentMenuIDTransform);
			}
			MenuScrollBox componentInParent2 = ((Component)currentMenuIDTransform).GetComponentInParent<MenuScrollBox>();
			if ((Object)(object)componentInParent2 != (Object)null && componentInParent2.ShouldScrollToChild(currentMenuIDTransform))
			{
				componentInParent2.ScrollToChild(currentMenuIDTransform);
			}
		}
	}

	private static bool HiddenByScrollBox(Selectable candidate)
	{
		if (!(candidate is MenuSelectableElement menuSelectableElement) || !Object.op_Implicit((Object)(object)menuSelectableElement.menuScrollBox) || !((Behaviour)menuSelectableElement.menuScrollBox).isActiveAndEnabled)
		{
			return false;
		}
		RectTransform scroller = menuSelectableElement.menuScrollBox.scroller;
		Transform val = ((Component)menuSelectableElement).transform;
		while (Object.op_Implicit((Object)(object)val) && (Object)(object)val.parent != (Object)(object)scroller)
		{
			if (!((Component)val).gameObject.activeSelf)
			{
				return false;
			}
			val = val.parent;
		}
		if (Object.op_Implicit((Object)(object)val) && !((Component)val).gameObject.activeSelf)
		{
			return ((Component)scroller).gameObject.activeInHierarchy;
		}
		return false;
	}

	private static Object NavigationRegionGet(MenuSelectableElement element)
	{
		if (!Object.op_Implicit((Object)(object)element))
		{
			return null;
		}
		if (!Object.op_Implicit((Object)(object)element.menuScrollBox))
		{
			return (Object)(object)element.parentPage;
		}
		return (Object)(object)element.menuScrollBox;
	}

	private void RememberSelection(MenuSelectableElement element)
	{
		Object val = NavigationRegionGet(element);
		if (!Object.op_Implicit(val))
		{
			return;
		}
		if (lastSelectedPerRegion.Count > 32)
		{
			foreach (Object item in lastSelectedPerRegion.Keys.Where((Object k) => !Object.op_Implicit(k)).ToList())
			{
				lastSelectedPerRegion.Remove(item);
			}
		}
		lastSelectedPerRegion[val] = element;
	}

	private static bool RememberedSelectionValid(MenuSelectableElement element)
	{
		if (!Object.op_Implicit((Object)(object)element) || !((Selectable)element).IsInteractable())
		{
			return false;
		}
		if (!((Component)element).gameObject.activeInHierarchy)
		{
			return (Object)(object)element.menuScrollBox != (Object)null;
		}
		return true;
	}

	private Vector2 GetRepeatedNavigationDirection()
	{
		//IL_0000: Unknown result type (might be due to invalid IL or missing references)
		//IL_0005: Unknown result type (might be due to invalid IL or missing references)
		//IL_0006: Unknown result type (might be due to invalid IL or missing references)
		//IL_000b: Unknown result type (might be due to invalid IL or missing references)
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0060: Unknown result type (might be due to invalid IL or missing references)
		//IL_001a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0025: Unknown result type (might be due to invalid IL or missing references)
		//IL_008f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0091: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0072: Unknown result type (might be due to invalid IL or missing references)
		//IL_0089: Unknown result type (might be due to invalid IL or missing references)
		//IL_0049: Unknown result type (might be due to invalid IL or missing references)
		//IL_0059: Unknown result type (might be due to invalid IL or missing references)
		//IL_0037: Unknown result type (might be due to invalid IL or missing references)
		//IL_0042: Unknown result type (might be due to invalid IL or missing references)
		//IL_009e: Unknown result type (might be due to invalid IL or missing references)
		//IL_009f: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b6: Unknown result type (might be due to invalid IL or missing references)
		//IL_005e: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d7: Unknown result type (might be due to invalid IL or missing references)
		//IL_0106: Unknown result type (might be due to invalid IL or missing references)
		Vector2 val = SemiFunc.InputUINavigate();
		Vector2 val2 = Vector2.zero;
		if (val.sqrMagnitude >= 0.25f)
		{
			val2 = ((Mathf.Abs(val.x) > Mathf.Abs(val.y)) ? new Vector2(Mathf.Sign(val.x), 0f) : new Vector2(0f, Mathf.Sign(val.y)));
		}
		if (val2 == Vector2.zero)
		{
			navigationHeldDirection = Vector2.zero;
			navigationRepeatTimer = 0f;
			navigationRepeatCount = 0;
			return Vector2.zero;
		}
		if (val2 != navigationHeldDirection)
		{
			navigationHeldDirection = val2;
			navigationRepeatTimer = 0.3f;
			navigationRepeatCount = 0;
			return val2;
		}
		navigationRepeatTimer -= Time.deltaTime;
		if (navigationRepeatTimer > 0f)
		{
			return Vector2.zero;
		}
		navigationRepeatCount++;
		navigationRepeatTimer = ((navigationRepeatCount >= 3) ? 0.1f : 0.3f);
		return val2;
	}

	private bool TryDetermineCurrentSelectedElement(out MenuSelectableElement currentSelectedElement)
	{
		foreach (MenuButton allMenuButton in allMenuButtons)
		{
			if (!IsBackgroundPage(allMenuButton.parentPage) && allMenuButton.MenuID == lastHoverMenuID && (Object)(object)allMenuButton.menuSelectableElement != (Object)null && ((Selectable)allMenuButton.menuSelectableElement).IsInteractable())
			{
				currentSelectedElement = allMenuButton.menuSelectableElement;
				return true;
			}
		}
		foreach (MenuElementHover allMenuHover in allMenuHovers)
		{
			if (!IsBackgroundPage(allMenuHover.parentPage) && allMenuHover.menuID == lastHoverMenuID && (Object)(object)allMenuHover.menuSelectableElement != (Object)null && ((Selectable)allMenuHover.menuSelectableElement).IsInteractable())
			{
				currentSelectedElement = allMenuHover.menuSelectableElement;
				return true;
			}
		}
		foreach (MenuSelectableElement allSelectableElement in allSelectableElements)
		{
			if (!IsBackgroundPage(allSelectableElement.parentPage) && allSelectableElement.menuID == lastHoverMenuID && ((Selectable)allSelectableElement).IsInteractable())
			{
				currentSelectedElement = allSelectableElement;
				return true;
			}
		}
		foreach (MenuButton allMenuButton2 in allMenuButtons)
		{
			if (!IsBackgroundPage(allMenuButton2.parentPage) && allMenuButton2.hovering && (Object)(object)allMenuButton2.menuSelectableElement != (Object)null && allMenuButton2.menuSelectableElement.IsNavigable())
			{
				currentSelectedElement = allMenuButton2.menuSelectableElement;
				return true;
			}
		}
		foreach (MenuElementHover allMenuHover2 in allMenuHovers)
		{
			if (!IsBackgroundPage(allMenuHover2.parentPage) && allMenuHover2.isHovering && (Object)(object)allMenuHover2.menuSelectableElement != (Object)null && allMenuHover2.menuSelectableElement.IsNavigable())
			{
				currentSelectedElement = allMenuHover2.menuSelectableElement;
				return true;
			}
		}
		foreach (MenuButton allMenuButton3 in allMenuButtons)
		{
			if (!IsBackgroundPage(allMenuButton3.parentPage) && !((Object)(object)allMenuButton3.menuSelectableElement == (Object)null) && ((Selectable)allMenuButton3.menuSelectableElement).IsInteractable())
			{
				allMenuButton3.ProcessHover();
				currentSelectedElement = allMenuButton3.menuSelectableElement;
				return true;
			}
		}
		foreach (MenuElementHover allMenuHover3 in allMenuHovers)
		{
			if (!IsBackgroundPage(allMenuHover3.parentPage) && !((Object)(object)allMenuHover3.menuSelectableElement == (Object)null) && ((Selectable)allMenuHover3.menuSelectableElement).IsInteractable())
			{
				allMenuHover3.OnHoverStart();
				currentSelectedElement = allMenuHover3.menuSelectableElement;
				return true;
			}
		}
		currentSelectedElement = null;
		return false;
	}

	private void StateClosed()
	{
		if (stateStart)
		{
			InputManager.instance.SwitchToPlayerInputs();
			isKeyboardNavigating = false;
		}
		if (Object.op_Implicit((Object)(object)currentMenuPage))
		{
			StateSet(MenuState.Open);
		}
	}

	public void PageAdd(MenuPage menuPage)
	{
		if (!allPages.Contains(menuPage))
		{
			allPages.Add(menuPage);
		}
	}

	public void PageRemove(MenuPage menuPage)
	{
		allPages.Remove(menuPage);
		addedPagesOnTop.Remove(menuPage);
	}

	internal int HighestOpenPriority()
	{
		int num = 0;
		foreach (MenuPage allPage in allPages)
		{
			if (Object.op_Implicit((Object)(object)allPage) && allPage.currentPageState != MenuPage.PageState.Closing && allPage.currentPageState != MenuPage.PageState.Closed && allPage.interactionPriority > num)
			{
				num = allPage.interactionPriority;
			}
		}
		return num;
	}

	internal void RefreshPageInteractivity()
	{
		int num = HighestOpenPriority();
		foreach (MenuPage allPage in allPages)
		{
			if (Object.op_Implicit((Object)(object)allPage))
			{
				bool flag = allPage.currentPageState == MenuPage.PageState.Closing || allPage.currentPageState == MenuPage.PageState.Closed;
				allPage.SetInteractable(!flag && !allPage.interactionBlocked && allPage.interactionPriority >= num);
			}
		}
	}

	public bool PageIsOnTop(MenuPageIndex _menuPageIndex)
	{
		foreach (MenuPage item in addedPagesOnTop)
		{
			if (item.menuPageIndex == _menuPageIndex)
			{
				return true;
			}
		}
		return false;
	}

	public MenuPage PageOpen(MenuPageIndex menuPageIndex, bool addedPageOnTop = false)
	{
		//IL_0080: Unknown result type (might be due to invalid IL or missing references)
		//IL_0085: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a4: Unknown result type (might be due to invalid IL or missing references)
		MenuPages menuPages = this.menuPages.Find((MenuPages x) => x.menuPageIndex == menuPageIndex);
		if (menuPages == null)
		{
			Debug.LogError((object)"Page not found");
			return null;
		}
		PlayerExpressionsUI playerExpressionsUI = PlayerExpressionsUI.instance;
		if (Object.op_Implicit((Object)(object)playerExpressionsUI) && Object.op_Implicit((Object)(object)playerExpressionsUI.wheel))
		{
			playerExpressionsUI.wheel.CloseForMenu();
		}
		GameObject val = Object.Instantiate<GameObject>(menuPages.menuPage, ((Component)MenuHolder.instance).transform, true);
		((Transform)val.GetComponent<RectTransform>()).localPosition = Vector2.op_Implicit(new Vector2(0f, 0f));
		((Transform)val.GetComponent<RectTransform>()).localScale = new Vector3(1f, 1f, 1f);
		MenuPage component = val.GetComponent<MenuPage>();
		component.addedPageOnTop = addedPageOnTop;
		if (!addedPageOnTop)
		{
			PageSetCurrent(menuPageIndex, component);
		}
		else
		{
			component.parentPage = currentMenuPage;
		}
		return component;
	}

	public void PageClose(MenuPageIndex menuPageIndex)
	{
		if (menuPages.Find((MenuPages x) => x.menuPageIndex == menuPageIndex) != null)
		{
			MenuPage menuPage = allPages.Find((MenuPage x) => x.menuPageIndex == menuPageIndex);
			if (!((Object)(object)menuPage == (Object)null))
			{
				menuPage.PageStateSet(MenuPage.PageState.Closing);
				allPages.Remove(menuPage);
			}
		}
	}

	public bool PageCheck(MenuPageIndex menuPageIndex)
	{
		return (Object)(object)allPages.Find((MenuPage x) => x.menuPageIndex == menuPageIndex) != (Object)null;
	}

	public void PageSwap(MenuPageIndex menuPageIndex)
	{
		if (Object.op_Implicit((Object)(object)currentMenuPage) && currentMenuPage.menuPageIndex != menuPageIndex && currentMenuPage.currentPageState == MenuPage.PageState.Active)
		{
			currentMenuPage.PageStateSet(MenuPage.PageState.Closing);
			PageOpen(menuPageIndex);
		}
	}

	public MenuPage PageOpenOnTop(MenuPageIndex menuPageIndex)
	{
		MenuPage menuPage = currentMenuPage;
		PageInactiveAdd(menuPage);
		currentMenuPage.PageStateSet(MenuPage.PageState.Inactive);
		MenuPage menuPage2 = PageOpen(menuPageIndex);
		menuPage2.pageIsOnTopOfOtherPage = true;
		menuPage2.pageUnderThisPage = menuPage;
		menuPage2.interactionPriority = HighestOpenPriority() + 1;
		return menuPage2;
	}

	public MenuPage PageAddOnTop(MenuPageIndex menuPageIndex)
	{
		if (addedPagesOnTop.Contains(currentMenuPage))
		{
			return null;
		}
		MenuPage menuPage = PageOpen(menuPageIndex, addedPageOnTop: true);
		if (!addedPagesOnTop.Contains(menuPage))
		{
			addedPagesOnTop.Add(menuPage);
		}
		menuPage.interactionPriority = HighestOpenPriority();
		return menuPage;
	}

	public void PagePopUpTwoOptions(MenuButtonPopUp menuButtonPopUp, string popUpHeader, LocalizedAsset localizedHeader, Color popUpHeaderColor, string popUpText, LocalizedAsset localizedBody, string option1Text, LocalizedAsset localizedOption1, string option2Text, LocalizedAsset localizedOption2, bool richText)
	{
		//IL_0093: Unknown result type (might be due to invalid IL or missing references)
		if (Object.op_Implicit((Object)(object)currentMenuPage))
		{
			MenuPageIndex menuPageIndex = MenuPageIndex.PopUpTwoOptions;
			MenuPage pageUnderThisPage = currentMenuPage;
			currentMenuPage.PageStateSet(MenuPage.PageState.Inactive);
			MenuPage menuPage = PageOpen(menuPageIndex, addedPageOnTop: true);
			menuPage.pageIsOnTopOfOtherPage = true;
			menuPage.pageUnderThisPage = pageUnderThisPage;
			menuPage.interactionPriority = HighestOpenPriority() + 1;
			MenuPageTwoOptions component = ((Component)menuPage).GetComponent<MenuPageTwoOptions>();
			((TMP_Text)menuPage.menuHeader).text = localizedHeader?.GetLocalizedString() ?? popUpHeader;
			((TMP_Text)menuPage.menuHeader).isRightToLeftText = Object.op_Implicit((Object)(object)localizedHeader) && localizedHeader.IsRightToLeft();
			menuPage.menuHeaderName = popUpHeader;
			((Graphic)menuPage.menuHeader).color = popUpHeaderColor;
			component.option1Event = menuButtonPopUp.option1Event;
			component.option2Event = menuButtonPopUp.option2Event;
			((TMP_Text)component.bodyTextMesh).text = localizedBody?.GetLocalizedString() ?? popUpText;
			((TMP_Text)component.bodyTextMesh).isRightToLeftText = Object.op_Implicit((Object)(object)localizedBody) && localizedBody.IsRightToLeft();
			component.option1Button.buttonTextString = localizedOption1?.GetLocalizedString() ?? option1Text;
			((TMP_Text)component.option1Button.buttonText).isRightToLeftText = Object.op_Implicit((Object)(object)localizedOption1) && localizedOption1.IsRightToLeft();
			component.option2Button.buttonTextString = localizedOption2?.GetLocalizedString() ?? option2Text;
			((TMP_Text)component.option2Button.buttonText).isRightToLeftText = Object.op_Implicit((Object)(object)localizedOption2) && localizedOption2.IsRightToLeft();
			component.richText = richText;
		}
	}

	public void PagePopUpTextInput(string popUpHeader, LocalizedAsset localizedHeader, Color popUpHeaderColor, string popUpText, LocalizedAsset localizedBody, string defaultText, string confirmText, LocalizedAsset localizedConfirm, bool upperOnly, int maxLength, bool allowEmpty, UnityAction<string> confirmEvent, UnityAction cancelEvent)
	{
		//IL_0094: Unknown result type (might be due to invalid IL or missing references)
		//IL_014d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0157: Expected Obj, but got Unknown
		if (Object.op_Implicit((Object)(object)currentMenuPage))
		{
			MenuPageIndex menuPageIndex = MenuPageIndex.PopUpTextInput;
			MenuPage pageUnderThisPage = currentMenuPage;
			currentMenuPage.PageStateSet(MenuPage.PageState.Inactive);
			MenuPage menuPage = PageOpen(menuPageIndex, addedPageOnTop: true);
			menuPage.pageIsOnTopOfOtherPage = true;
			menuPage.pageUnderThisPage = pageUnderThisPage;
			menuPage.interactionPriority = HighestOpenPriority() + 1;
			MenuPagePopUpTextInput component = ((Component)menuPage).GetComponent<MenuPagePopUpTextInput>();
			((TMP_Text)menuPage.menuHeader).text = localizedHeader?.GetLocalizedString() ?? popUpHeader;
			((TMP_Text)menuPage.menuHeader).isRightToLeftText = Object.op_Implicit((Object)(object)localizedHeader) && localizedHeader.IsRightToLeft();
			menuPage.menuHeaderName = popUpHeader;
			((Graphic)menuPage.menuHeader).color = popUpHeaderColor;
			((TMP_Text)component.bodyTextMesh).text = localizedBody?.GetLocalizedString() ?? popUpText;
			((TMP_Text)component.bodyTextMesh).isRightToLeftText = Object.op_Implicit((Object)(object)localizedBody) && localizedBody.IsRightToLeft();
			component.confirmButton.buttonTextString = localizedConfirm?.GetLocalizedString() ?? confirmText;
			component.menuTextInput.upperOnly = upperOnly;
			component.menuTextInput.maxLength = maxLength;
			component.menuTextInput.textCurrent = defaultText ?? "";
			component.allowEmpty = allowEmpty;
			component.confirmEvent = new UnityEvent<string>();
			if (confirmEvent != null)
			{
				component.confirmEvent.AddListener(confirmEvent);
			}
			component.cancelEvent = new UnityEvent();
			if (cancelEvent != null)
			{
				component.cancelEvent.AddListener(cancelEvent);
			}
		}
	}

	public void PageSelectButtonByEvent(MenuPage _menuPage, string _methodName)
	{
		if (!Object.op_Implicit((Object)(object)_menuPage))
		{
			return;
		}
		MenuButton[] componentsInChildren = ((Component)_menuPage).GetComponentsInChildren<MenuButton>(true);
		foreach (MenuButton menuButton in componentsInChildren)
		{
			if (!string.IsNullOrEmpty(menuButton.MenuID))
			{
				Button component = ((Component)menuButton).GetComponent<Button>();
				MenuButtonPopUp component2 = ((Component)menuButton).GetComponent<MenuButtonPopUp>();
				if ((Object.op_Implicit((Object)(object)component) && EventCallsMethod((UnityEventBase)(object)component.onClick, _methodName)) || (Object.op_Implicit((Object)(object)component2) && (EventCallsMethod((UnityEventBase)(object)component2.option1Event, _methodName) || EventCallsMethod((UnityEventBase)(object)component2.option2Event, _methodName))))
				{
					lastHoverMenuID = menuButton.MenuID;
					break;
				}
			}
		}
	}

	private static bool EventCallsMethod(UnityEventBase _event, string _methodName)
	{
		if (_event == null)
		{
			return false;
		}
		for (int i = 0; i < _event.GetPersistentEventCount(); i++)
		{
			if (_event.GetPersistentMethodName(i) == _methodName)
			{
				return true;
			}
		}
		return false;
	}

	public void PageSetCurrent(MenuPageIndex menuPageIndex, MenuPage menuPage)
	{
		if (Object.op_Implicit((Object)(object)currentMenuPage) && (Object)(object)currentMenuPage != (Object)(object)menuPage && (currentMenuPage.currentPageState == MenuPage.PageState.Opening || currentMenuPage.currentPageState == MenuPage.PageState.Active))
		{
			currentMenuPage.PageStateSet(MenuPage.PageState.Closing);
		}
		if (Object.op_Implicit((Object)(object)menuPage) && (Object)(object)menuPage != (Object)(object)currentMenuPage && menuPage.currentPageState == MenuPage.PageState.Inactive && !string.IsNullOrEmpty(menuPage.menuIDBeforeInactive))
		{
			lastHoverMenuID = menuPage.menuIDBeforeInactive;
		}
		currentMenuPageIndex = menuPageIndex;
		currentMenuPage = menuPage;
	}

	public void StateSet(MenuState state)
	{
		currentMenuState = (int)state;
	}

	private void PageInactiveAdd(MenuPage menuPage)
	{
		if (!inactivePages.Contains(menuPage))
		{
			inactivePages.Add(menuPage);
		}
	}

	private void PageInactiveRemove(MenuPage menuPage)
	{
		if (inactivePages.Contains(menuPage))
		{
			inactivePages.Remove(menuPage);
		}
	}

	public void PageReactivatePageUnderThisPage(MenuPage _menuPage)
	{
		if (!Object.op_Implicit((Object)(object)_menuPage))
		{
			return;
		}
		MenuPage pageUnderThisPage = _menuPage.pageUnderThisPage;
		if ((!((Object)(object)currentMenuPage != (Object)(object)_menuPage) || (Object.op_Implicit((Object)(object)pageUnderThisPage) && !((Object)(object)currentMenuPage != (Object)(object)pageUnderThisPage))) && Object.op_Implicit((Object)(object)pageUnderThisPage))
		{
			if (pageUnderThisPage.currentPageState == MenuPage.PageState.Inactive)
			{
				pageUnderThisPage.PageStateSet(MenuPage.PageState.Activating);
			}
			if (!string.IsNullOrEmpty(pageUnderThisPage.menuIDBeforeInactive))
			{
				lastHoverMenuID = pageUnderThisPage.menuIDBeforeInactive;
			}
			PageSetCurrent(pageUnderThisPage.menuPageIndex, pageUnderThisPage);
		}
	}

	public void PageCloseAllExcept(MenuPageIndex menuPageIndex)
	{
		foreach (MenuPage allPage in allPages)
		{
			if (allPage.menuPageIndex != menuPageIndex)
			{
				allPage.PageStateSet(MenuPage.PageState.Closing);
			}
		}
	}

	public void PageCloseAll()
	{
		foreach (MenuPage allPage in allPages)
		{
			allPage.PageStateSet(MenuPage.PageState.Closing);
		}
	}

	public void PageCloseAllAddedOnTop()
	{
		foreach (MenuPage item in addedPagesOnTop)
		{
			item.PageStateSet(MenuPage.PageState.Closing);
		}
	}

	public void PlayerHeadAdd(MenuPlayerHead head)
	{
		if (!playerHeads.Contains(head))
		{
			playerHeads.Add(head);
		}
		for (int i = 0; i < playerHeads.Count; i++)
		{
			if ((Object)(object)playerHeads[i] == (Object)null)
			{
				playerHeads.RemoveAt(i);
			}
		}
	}

	public void SetActiveSelectionBox(MenuSelectionBox selectBox)
	{
		activeSelectionBox = selectBox;
	}

	public void PlayerHeadRemove(MenuPlayerHead head)
	{
		if (playerHeads.Contains(head))
		{
			playerHeads.Remove(head);
		}
		for (int i = 0; i < playerHeads.Count; i++)
		{
			if ((Object)(object)playerHeads[i] == (Object)null)
			{
				playerHeads.RemoveAt(i);
			}
		}
	}

	public void PagePopUpScheduled(string headerText, Color headerColor, string bodyText, string buttonText, bool richText)
	{
		//IL_000f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0010: Unknown result type (might be due to invalid IL or missing references)
		pagePopUpScheduled = true;
		pagePopUpScheduledHeaderText = headerText;
		pagePopUpScheduledHeaderColor = headerColor;
		pagePopUpScheduledBodyText = bodyText;
		pagePopUpScheduledButtonText = buttonText;
		pagePopUpScheduledRichText = richText;
	}

	public void PagePopUpScheduledShow()
	{
		//IL_0011: Unknown result type (might be due to invalid IL or missing references)
		if (pagePopUpScheduled)
		{
			PagePopUp(pagePopUpScheduledHeaderText, pagePopUpScheduledHeaderColor, pagePopUpScheduledBodyText, pagePopUpScheduledButtonText, pagePopUpScheduledRichText);
			PagePopUpScheduledReset();
		}
	}

	public void PagePopUpScheduledReset()
	{
		pagePopUpScheduled = false;
	}

	public void SelectionBoxAdd(MenuSelectionBox selectBox)
	{
		if (!selectionBoxes.Contains(selectBox))
		{
			selectionBoxes.Add(selectBox);
		}
		for (int i = 0; i < selectionBoxes.Count; i++)
		{
			if ((Object)(object)selectionBoxes[i] == (Object)null)
			{
				selectionBoxes.RemoveAt(i);
			}
		}
	}

	public void SelectionBoxRemove(MenuSelectionBox selectBox)
	{
		if (selectionBoxes.Contains(selectBox))
		{
			selectionBoxes.Remove(selectBox);
		}
		for (int i = 0; i < selectionBoxes.Count; i++)
		{
			if ((Object)(object)selectionBoxes[i] == (Object)null)
			{
				selectionBoxes.RemoveAt(i);
			}
		}
	}

	public MenuSelectionBox SelectionBoxGetCorrect(MenuPage parentPage, MenuScrollBox menuScrollBox, MenuElementCosmeticCategoryScroll categoryScroll)
	{
		return selectionBoxes.Find((MenuSelectionBox x) => (Object)(object)x.menuPage == (Object)(object)parentPage && (Object)(object)x.menuScrollBox == (Object)(object)menuScrollBox && (Object)(object)x.categoryScroll == (Object)(object)categoryScroll);
	}

	public void PagePopUp(string headerText, Color headerColor, string bodyText, string buttonText, bool richText)
	{
		//IL_0076: Unknown result type (might be due to invalid IL or missing references)
		MenuPageIndex menuPageIndex = MenuPageIndex.PopUp;
		MenuPage menuPage = currentMenuPage;
		if (currentMenuPage.menuPageIndex == MenuPageIndex.PopUpTwoOptions)
		{
			menuPage = (currentMenuPage = currentMenuPage.pageUnderThisPage);
		}
		menuPage.PageStateSet(MenuPage.PageState.Inactive);
		MenuPage menuPage2 = PageOpen(menuPageIndex, addedPageOnTop: true);
		menuPage2.pageIsOnTopOfOtherPage = true;
		menuPage2.pageUnderThisPage = menuPage;
		menuPage2.interactionPriority = HighestOpenPriority() + 1;
		MenuPagePopUp component = ((Component)menuPage2).GetComponent<MenuPagePopUp>();
		menuPage2.menuHeaderName = headerText;
		((TMP_Text)menuPage2.menuHeader).text = headerText;
		((Graphic)menuPage2.menuHeader).color = headerColor;
		((TMP_Text)component.bodyTextMesh).text = bodyText;
		component.okButton.buttonTextString = buttonText;
		component.richText = richText;
		currentMenuPage = menuPage2;
		MenuEffectPopUpOpen();
	}

	public void TextInputActive()
	{
		textInputActive = true;
		textInputActiveTimer = 0.1f;
	}

	public void CutsceneSoundOverride()
	{
		if (!cutsceneSoundOverride)
		{
			soundAction.Type = cutsceneSoundType;
			soundConfirm.Type = cutsceneSoundType;
			soundDeny.Type = cutsceneSoundType;
			soundDud.Type = cutsceneSoundType;
			soundTick.Type = cutsceneSoundType;
			soundHover.Type = cutsceneSoundType;
			soundPageIntro.Type = cutsceneSoundType;
			soundPageOutro.Type = cutsceneSoundType;
			soundWindowPopUp.Type = cutsceneSoundType;
			soundWindowPopUpClose.Type = cutsceneSoundType;
			soundMove.Type = cutsceneSoundType;
			cutsceneSoundOverride = true;
		}
		cutsceneSoundOverrideTimer = 0.1f;
	}
}
