using UnityEngine;

public class EnemyBombThrowerAnim : MonoBehaviour
{
	public Enemy enemy;

	public EnemyBombThrower controller;

	public bool headGrownVisually;

	public float headAdditiveIdleAmount;

	public bool torsoHeadsScreaming;

	internal Materials.MaterialTrigger material = new Materials.MaterialTrigger();

	internal Animator animator;

	private int animSpawn = Animator.StringToHash("spawn");

	private int animMoving = Animator.StringToHash("moving");

	private int animMovingFast = Animator.StringToHash("movingFast");

	private int animBackingAway = Animator.StringToHash("backingAway");

	private int animJump = Animator.StringToHash("jump");

	private int animFalling = Animator.StringToHash("falling");

	private int animLand = Animator.StringToHash("land");

	private int animNotice = Animator.StringToHash("notice");

	private int animAttack = Animator.StringToHash("attack");

	private int animMelee = Animator.StringToHash("melee");

	private int animStun = Animator.StringToHash("stun");

	private int animStunned = Animator.StringToHash("stunned");

	private int animDespawning = Animator.StringToHash("despawning");

	private int animBodyHeadGrown = Animator.StringToHash("bodyHeadGrown");

	private int animTorsoHeadsScreaming = Animator.StringToHash("torsoHeadsScreaming");

	private int animTorsoHeadsScream = Animator.StringToHash("torsoHeadsScream");

	private int animTorsoHeadsMelee = Animator.StringToHash("torsoHeadsMelee");

	private int animTorsoHeadsHurt = Animator.StringToHash("torsoHeadsHurt");

	private int animTorsoHeadsBreaker00 = Animator.StringToHash("torsoHeadsBreaker00");

	private int animTorsoHeadsBreaker01 = Animator.StringToHash("torsoHeadsBreaker01");

	private int animTorsoHeadsBreaker02 = Animator.StringToHash("torsoHeadsBreaker02");

	private int animTorsoHeadsBreaker03 = Animator.StringToHash("torsoHeadsBreaker03");

	private int animTorsoHeadsBreaker04 = Animator.StringToHash("torsoHeadsBreaker04");

	private int animTorsoHeadsBreaker05 = Animator.StringToHash("torsoHeadsBreaker05");

	private int animTorsoHeadsBreaker06 = Animator.StringToHash("torsoHeadsBreaker06");

	private int animTorsoHeadsBreaker07 = Animator.StringToHash("torsoHeadsBreaker07");

	private int animTorsoHeadsBreaker08 = Animator.StringToHash("torsoHeadsBreaker08");

	private int animTorsoHeadsBreaker09 = Animator.StringToHash("torsoHeadsBreaker09");

	private int animTorsoHeadsBreaker10 = Animator.StringToHash("torsoHeadsBreaker10");

	private int animTorsoHeadsBreaker11 = Animator.StringToHash("torsoHeadsBreaker11");

	private bool spawnImpulse = true;

	private bool jumpImpulse = true;

	private bool landImpulse = true;

	private bool noticeImpulse = true;

	private bool attackImpulse = true;

	private bool meleeImpulse = true;

	private bool stunImpulse = true;

	private bool torsoHeadsScreamingImpulse = true;

	private float moveTimer;

	private float backAwayTimer;

	public SpringQuaternionSystem springHead;

	public SpringQuaternionSystem springArmRight;

	public SpringQuaternionSystem springArmLeft;

	[Space]
	public SpringQuaternionSystem[] springTorsoHeads;

	public Transform headLookTransform;

	public Transform headLookPositionTransform;

	[Space]
	public GenericEyeLookAt eyeLookAt;

	[Space]
	public Transform footSkinTransform;

	public Transform footBootTransform;

	public ParticleSystem[] teleportParticles;

	public ParticleSystem[] headDetachParticles;

	public ParticleSystem[] deathParticles;

	public Sound soundIdleLoop;

	[Space]
	public Sound soundTeleportIn;

	public Sound soundTeleportOut;

	[Space]
	public Sound soundLand;

	public Sound soundJump;

	[Space]
	public Sound soundFootstepSkinLight;

	public Sound soundFootstepSkinHeavy;

	[Space]
	public Sound soundFootstepBootLight;

	public Sound soundFootstepBootHeavy;

	[Space]
	public Sound soundMoveShort;

	public Sound soundMoveLong;

	[Space]
	public Sound soundHurt;

	public Sound soundDeath;

	[Space]
	public Sound soundHeadGrow01;

	public Sound soundHeadGrow02;

	public Sound soundHeadGrow03;

	[Space]
	public Sound soundHeadDetachTell;

	[Space]
	public Sound soundTorsoHeadsOpenSolo;

	public Sound soundTorsoHeadsOpenMultiple;

	[Space]
	public Sound soundTorsoHeadsCloseSolo;

	public Sound soundTorsoHeadsCloseMultiple;

	[Space]
	public Sound soundTorsoHeadsMelee;

	public Sound soundTorsoHeadsMeleeGlobal;

	[Space]
	public Sound soundTorsoHeadsScream;

	public Sound soundTorsoHeadsScreamGlobal;

	[Space]
	public Sound soundTorsoHeadsScreamingIntro;

	public Sound soundTorsoHeadsScreamingLoop;

	public Sound soundTorsoHeadsScreamingOutro;

	[Space]
	public Sound soundTorsoHeadsBreaker00;

	public Sound soundTorsoHeadsBreaker01;

	public Sound soundTorsoHeadsBreaker02;

	public Sound soundTorsoHeadsBreaker03;

	public Sound soundTorsoHeadsBreaker04;

	public Sound soundTorsoHeadsBreaker05;

	public Sound soundTorsoHeadsBreaker06;

	public Sound soundTorsoHeadsBreaker07;

	public Sound soundTorsoHeadsBreaker08;

	public Sound soundTorsoHeadsBreaker09;

	public Sound soundTorsoHeadsBreaker10;

	public Sound soundTorsoHeadsBreaker11;

	private void Awake()
	{
		animator = ((Component)this).GetComponent<Animator>();
		animator.keepAnimatorStateOnDisable = true;
		SpringQuaternionSystem[] array = springTorsoHeads;
		foreach (SpringQuaternionSystem obj in array)
		{
			obj.spring.speed = 8f + Random.Range(-2f, 2f);
			obj.spring.damping = 0.2f + Random.Range(-0.05f, 0.05f);
		}
	}

	private void Update()
	{
		AnimatorLogic();
		SpringLogic();
		HeadLookAtLogic();
		IdleLoopLogic();
	}

	private void AnimatorLogic()
	{
		//IL_00a8: Unknown result type (might be due to invalid IL or missing references)
		//IL_0067: Unknown result type (might be due to invalid IL or missing references)
		if (enemy.Rigidbody.frozen)
		{
			animator.speed = 0f;
		}
		else
		{
			animator.speed = 1f;
		}
		animator.SetLayerWeight(3, headAdditiveIdleAmount);
		if (torsoHeadsScreaming)
		{
			if (torsoHeadsScreamingImpulse)
			{
				soundTorsoHeadsScreamingIntro.Play(enemy.CenterTransform.position);
				torsoHeadsScreamingImpulse = false;
			}
		}
		else if (!torsoHeadsScreamingImpulse)
		{
			soundTorsoHeadsScreamingOutro.Play(enemy.CenterTransform.position);
			torsoHeadsScreamingImpulse = true;
		}
		soundTorsoHeadsScreamingLoop.PlayLoop(torsoHeadsScreaming, 5f, 10f);
		animator.SetBool(animTorsoHeadsScreaming, torsoHeadsScreaming);
		if (controller.currentState == EnemyBombThrower.State.Spawn)
		{
			if (spawnImpulse)
			{
				spawnImpulse = false;
				animator.SetTrigger(animSpawn);
			}
		}
		else
		{
			spawnImpulse = true;
		}
		if ((controller.currentState == EnemyBombThrower.State.Roam || controller.currentState == EnemyBombThrower.State.Investigate || controller.currentState == EnemyBombThrower.State.GotoPlayer || controller.currentState == EnemyBombThrower.State.Leave) && (enemy.Rigidbody.velocity.magnitude >= 0.5f || enemy.Rigidbody.physGrabObject.rbAngularVelocity.magnitude > 5f))
		{
			moveTimer = 0.2f;
		}
		if (moveTimer > 0f)
		{
			moveTimer -= Time.deltaTime;
			if (controller.currentState == EnemyBombThrower.State.BackAwayHead)
			{
				animator.SetBool(animMoving, false);
				animator.SetBool(animMovingFast, false);
			}
			else if (controller.currentState == EnemyBombThrower.State.GotoPlayer || controller.currentState == EnemyBombThrower.State.Leave)
			{
				animator.SetBool(animMoving, false);
				animator.SetBool(animMovingFast, true);
			}
			else
			{
				animator.SetBool(animMoving, true);
				animator.SetBool(animMovingFast, false);
			}
		}
		else
		{
			animator.SetBool(animMoving, false);
			animator.SetBool(animMovingFast, false);
		}
		if ((controller.currentState == EnemyBombThrower.State.BackAwayPlayer || controller.currentState == EnemyBombThrower.State.BackAwayHead) && (enemy.Rigidbody.velocity.magnitude >= 0.1f || enemy.Rigidbody.physGrabObject.rbAngularVelocity.magnitude > 1f))
		{
			backAwayTimer = 0.2f;
		}
		if (backAwayTimer > 0f)
		{
			backAwayTimer -= Time.deltaTime;
			animator.SetBool(animBackingAway, true);
		}
		else
		{
			animator.SetBool(animBackingAway, false);
		}
		if (enemy.Jump.jumping || enemy.Jump.jumpingDelay)
		{
			if (jumpImpulse)
			{
				if (!enemy.IsStunned())
				{
					animator.SetTrigger(animJump);
					animator.SetBool(animFalling, false);
				}
				jumpImpulse = false;
				landImpulse = true;
			}
			else if (controller.enemy.Rigidbody.physGrabObject.rbVelocity.y < -0.5f)
			{
				animator.SetBool(animFalling, true);
			}
			if (animator.GetBool(animFalling))
			{
				controller.rotationStopTimer = 0.25f;
			}
		}
		else
		{
			if (landImpulse)
			{
				if (!enemy.IsStunned())
				{
					animator.SetTrigger(animLand);
				}
				moveTimer = 0f;
				landImpulse = false;
			}
			animator.SetBool(animFalling, false);
			jumpImpulse = true;
		}
		if (controller.currentState == EnemyBombThrower.State.Notice)
		{
			if (noticeImpulse)
			{
				if (!enemy.IsStunned())
				{
					animator.SetTrigger(animNotice);
				}
				noticeImpulse = false;
			}
		}
		else
		{
			noticeImpulse = true;
		}
		if (controller.currentState == EnemyBombThrower.State.Attack)
		{
			if (attackImpulse)
			{
				if (!enemy.IsStunned())
				{
					animator.SetTrigger(animAttack);
				}
				attackImpulse = false;
			}
		}
		else
		{
			attackImpulse = true;
		}
		if (controller.currentState == EnemyBombThrower.State.Melee)
		{
			if (meleeImpulse)
			{
				if (!enemy.IsStunned())
				{
					animator.SetTrigger(animMelee);
				}
				meleeImpulse = false;
			}
		}
		else
		{
			meleeImpulse = true;
		}
		if (controller.headGrown && controller.head.currentState == EnemyBombThrowerHead.State.Disabled)
		{
			animator.SetBool(animBodyHeadGrown, true);
		}
		else
		{
			animator.SetBool(animBodyHeadGrown, false);
		}
		if (enemy.IsStunned())
		{
			if (stunImpulse)
			{
				animator.SetTrigger(animStun);
				stunImpulse = false;
			}
			animator.SetBool(animStunned, true);
		}
		else
		{
			animator.SetBool(animStunned, false);
			stunImpulse = true;
		}
		if (controller.currentState == EnemyBombThrower.State.Despawn)
		{
			animator.SetBool(animDespawning, true);
		}
		else
		{
			animator.SetBool(animDespawning, false);
		}
	}

	private void SpringLogic()
	{
		springHead.UpdateWorldSpace();
		springArmRight.UpdateWorldSpace();
		springArmLeft.UpdateWorldSpace();
		SpringQuaternionSystem[] array = springTorsoHeads;
		for (int i = 0; i < array.Length; i++)
		{
			array[i].UpdateWorldSpace();
		}
	}

	private void HeadLookAtLogic()
	{
		//IL_0000: Unknown result type (might be due to invalid IL or missing references)
		//IL_0005: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b8: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b9: Unknown result type (might be due to invalid IL or missing references)
		//IL_016f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0174: Unknown result type (might be due to invalid IL or missing references)
		//IL_0184: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ce: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00da: Unknown result type (might be due to invalid IL or missing references)
		//IL_00df: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ec: Unknown result type (might be due to invalid IL or missing references)
		//IL_00fc: Unknown result type (might be due to invalid IL or missing references)
		//IL_010e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0119: Unknown result type (might be due to invalid IL or missing references)
		//IL_0123: Unknown result type (might be due to invalid IL or missing references)
		//IL_0133: Unknown result type (might be due to invalid IL or missing references)
		//IL_0138: Unknown result type (might be due to invalid IL or missing references)
		//IL_013f: Unknown result type (might be due to invalid IL or missing references)
		//IL_014b: Unknown result type (might be due to invalid IL or missing references)
		//IL_014c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0158: Unknown result type (might be due to invalid IL or missing references)
		Vector3 zero = Vector3.zero;
		if (controller.headGrown && (controller.currentState == EnemyBombThrower.State.Notice || controller.currentState == EnemyBombThrower.State.GotoPlayer || controller.currentState == EnemyBombThrower.State.BackAwayPlayer || controller.currentState == EnemyBombThrower.State.Attack || controller.currentState == EnemyBombThrower.State.Melee || controller.currentState == EnemyBombThrower.State.Stun) && Object.op_Implicit((Object)(object)controller.playerTarget) && !controller.playerTarget.isDisabled && !controller.VisionBlocked())
		{
			eyeLookAt.SetTargetPlayer(controller.playerTarget);
		}
		if (zero != Vector3.zero)
		{
			Quaternion localRotation = headLookTransform.localRotation;
			Vector3 localPosition = headLookTransform.localPosition;
			headLookTransform.position = headLookPositionTransform.position;
			headLookTransform.LookAt(zero);
			headLookTransform.forward = SemiFunc.ClampDirection(headLookTransform.forward, ((Component)this).transform.forward, 75f);
			Quaternion localRotation2 = headLookTransform.localRotation;
			headLookTransform.localPosition = localPosition;
			headLookTransform.localRotation = Quaternion.Slerp(localRotation, localRotation2, Time.deltaTime * 5f);
		}
		else
		{
			headLookTransform.localRotation = Quaternion.Slerp(headLookTransform.localRotation, Quaternion.identity, Time.deltaTime * 5f);
		}
	}

	private void IdleLoopLogic()
	{
		soundIdleLoop.PlayLoop(enemy.EnemyParent.playerClose, 0.5f, 0.5f);
	}

	public void TorsoHeadBreakerTrigger(int _index)
	{
		switch (_index)
		{
		case 0:
			animator.SetTrigger(animTorsoHeadsBreaker00);
			break;
		case 1:
			animator.SetTrigger(animTorsoHeadsBreaker01);
			break;
		case 2:
			animator.SetTrigger(animTorsoHeadsBreaker02);
			break;
		case 3:
			animator.SetTrigger(animTorsoHeadsBreaker03);
			break;
		case 4:
			animator.SetTrigger(animTorsoHeadsBreaker04);
			break;
		case 5:
			animator.SetTrigger(animTorsoHeadsBreaker05);
			break;
		case 6:
			animator.SetTrigger(animTorsoHeadsBreaker06);
			break;
		case 7:
			animator.SetTrigger(animTorsoHeadsBreaker07);
			break;
		case 8:
			animator.SetTrigger(animTorsoHeadsBreaker08);
			break;
		case 9:
			animator.SetTrigger(animTorsoHeadsBreaker09);
			break;
		case 10:
			animator.SetTrigger(animTorsoHeadsBreaker10);
			break;
		case 11:
			animator.SetTrigger(animTorsoHeadsBreaker11);
			break;
		}
	}

	public void EventTeleportIn()
	{
		//IL_0016: Unknown result type (might be due to invalid IL or missing references)
		//IL_0059: Unknown result type (might be due to invalid IL or missing references)
		//IL_008c: Unknown result type (might be due to invalid IL or missing references)
		soundTeleportIn.Play(controller.enemy.CenterTransform.position);
		GameDirector.instance.CameraShake.ShakeDistance(3f, 3f, 8f, enemy.CenterTransform.position, 0.5f);
		GameDirector.instance.CameraImpact.ShakeDistance(3f, 3f, 8f, enemy.CenterTransform.position, 0.05f);
		ParticleSystem[] array = teleportParticles;
		for (int i = 0; i < array.Length; i++)
		{
			((Component)array[i]).gameObject.SetActive(true);
		}
	}

	public void EventFootstepSkinLight()
	{
		//IL_000c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0036: Unknown result type (might be due to invalid IL or missing references)
		//IL_003b: Unknown result type (might be due to invalid IL or missing references)
		soundFootstepSkinLight.Play(footSkinTransform.position);
		Materials.Instance.Impulse(footSkinTransform.position, Vector3.down, Materials.SoundType.Medium, footstep: true, footstepParticles: true, material, Materials.HostType.Enemy);
	}

	public void EventFootstepSkinHeavy()
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_0057: Unknown result type (might be due to invalid IL or missing references)
		//IL_0072: Unknown result type (might be due to invalid IL or missing references)
		//IL_009c: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a1: Unknown result type (might be due to invalid IL or missing references)
		GameDirector.instance.CameraShake.ShakeDistance(0.5f, 3f, 5f, enemy.CenterTransform.position, 0.1f);
		GameDirector.instance.CameraImpact.ShakeDistance(1f, 3f, 5f, enemy.CenterTransform.position, 0.05f);
		soundFootstepSkinHeavy.Play(footSkinTransform.position);
		Materials.Instance.Impulse(footSkinTransform.position, Vector3.down, Materials.SoundType.Heavy, footstep: true, footstepParticles: true, material, Materials.HostType.Enemy);
	}

	public void EventFootstepBootLight()
	{
		//IL_000c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0036: Unknown result type (might be due to invalid IL or missing references)
		//IL_003b: Unknown result type (might be due to invalid IL or missing references)
		soundFootstepBootLight.Play(footBootTransform.position);
		Materials.Instance.Impulse(footBootTransform.position, Vector3.down, Materials.SoundType.Medium, footstep: true, footstepParticles: true, material, Materials.HostType.Enemy);
	}

	public void EventFootstepBootHeavy()
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_0057: Unknown result type (might be due to invalid IL or missing references)
		//IL_0072: Unknown result type (might be due to invalid IL or missing references)
		//IL_009c: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a1: Unknown result type (might be due to invalid IL or missing references)
		GameDirector.instance.CameraShake.ShakeDistance(0.5f, 3f, 5f, enemy.CenterTransform.position, 0.1f);
		GameDirector.instance.CameraImpact.ShakeDistance(1f, 3f, 5f, enemy.CenterTransform.position, 0.05f);
		soundFootstepBootHeavy.Play(footBootTransform.position);
		Materials.Instance.Impulse(footBootTransform.position, Vector3.down, Materials.SoundType.Heavy, footstep: true, footstepParticles: true, material, Materials.HostType.Enemy);
	}

	public void EventMoveShort()
	{
		//IL_0011: Unknown result type (might be due to invalid IL or missing references)
		soundMoveShort.Play(enemy.CenterTransform.position);
	}

	public void EventMoveLong()
	{
		//IL_0011: Unknown result type (might be due to invalid IL or missing references)
		soundMoveLong.Play(enemy.CenterTransform.position);
	}

	public void EventLand()
	{
		//IL_0011: Unknown result type (might be due to invalid IL or missing references)
		//IL_0054: Unknown result type (might be due to invalid IL or missing references)
		//IL_0087: Unknown result type (might be due to invalid IL or missing references)
		soundLand.Play(enemy.CenterTransform.position);
		GameDirector.instance.CameraShake.ShakeDistance(1f, 8f, 12f, enemy.CenterTransform.position, 1f);
		GameDirector.instance.CameraImpact.ShakeDistance(2f, 8f, 12f, enemy.CenterTransform.position, 0.1f);
	}

	public void EventJump()
	{
		//IL_0011: Unknown result type (might be due to invalid IL or missing references)
		//IL_0054: Unknown result type (might be due to invalid IL or missing references)
		//IL_0087: Unknown result type (might be due to invalid IL or missing references)
		soundJump.Play(enemy.CenterTransform.position);
		GameDirector.instance.CameraShake.ShakeDistance(1f, 8f, 12f, enemy.CenterTransform.position, 0.5f);
		GameDirector.instance.CameraImpact.ShakeDistance(2f, 8f, 12f, enemy.CenterTransform.position, 0.1f);
	}

	public void EventHeadDetachTell()
	{
		//IL_0011: Unknown result type (might be due to invalid IL or missing references)
		soundHeadDetachTell.Play(enemy.CenterTransform.position);
	}

	public void EventAttack()
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_0057: Unknown result type (might be due to invalid IL or missing references)
		GameDirector.instance.CameraShake.ShakeDistance(1f, 8f, 12f, enemy.CenterTransform.position, 0.5f);
		GameDirector.instance.CameraImpact.ShakeDistance(2f, 8f, 12f, enemy.CenterTransform.position, 0.1f);
		ParticleSystem[] array = headDetachParticles;
		for (int i = 0; i < array.Length; i++)
		{
			((Component)array[i]).gameObject.SetActive(true);
		}
		if (SemiFunc.IsMasterClientOrSingleplayer())
		{
			controller.HeadGrownSet(_state: false);
		}
	}

	public void EventMelee()
	{
		//IL_0011: Unknown result type (might be due to invalid IL or missing references)
		//IL_0041: Unknown result type (might be due to invalid IL or missing references)
		//IL_0084: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b7: Unknown result type (might be due to invalid IL or missing references)
		soundTorsoHeadsMelee.Play(enemy.CenterTransform.position);
		soundTorsoHeadsMeleeGlobal.Play(enemy.CenterTransform.position);
		GameDirector.instance.CameraShake.ShakeDistance(1f, 8f, 12f, enemy.CenterTransform.position, 0.5f);
		GameDirector.instance.CameraImpact.ShakeDistance(2f, 8f, 12f, enemy.CenterTransform.position, 0.1f);
	}

	public void EventMeleeEnd()
	{
		//IL_0011: Unknown result type (might be due to invalid IL or missing references)
		//IL_0054: Unknown result type (might be due to invalid IL or missing references)
		//IL_0087: Unknown result type (might be due to invalid IL or missing references)
		soundTorsoHeadsCloseMultiple.Play(enemy.CenterTransform.position);
		GameDirector.instance.CameraShake.ShakeDistance(0.5f, 3f, 5f, enemy.CenterTransform.position, 0.1f);
		GameDirector.instance.CameraImpact.ShakeDistance(1f, 3f, 5f, enemy.CenterTransform.position, 0.05f);
	}

	public void EventTorsoHeadGrow01()
	{
		//IL_0011: Unknown result type (might be due to invalid IL or missing references)
		//IL_0054: Unknown result type (might be due to invalid IL or missing references)
		//IL_0087: Unknown result type (might be due to invalid IL or missing references)
		soundHeadGrow01.Play(enemy.CenterTransform.position);
		GameDirector.instance.CameraShake.ShakeDistance(0.5f, 5f, 10f, enemy.CenterTransform.position, 0.1f);
		GameDirector.instance.CameraImpact.ShakeDistance(1f, 5f, 10f, enemy.CenterTransform.position, 0.05f);
	}

	public void EventTorsoHeadGrow02()
	{
		//IL_0011: Unknown result type (might be due to invalid IL or missing references)
		//IL_0054: Unknown result type (might be due to invalid IL or missing references)
		//IL_0087: Unknown result type (might be due to invalid IL or missing references)
		soundHeadGrow02.Play(enemy.CenterTransform.position);
		GameDirector.instance.CameraShake.ShakeDistance(0.5f, 5f, 10f, enemy.CenterTransform.position, 0.1f);
		GameDirector.instance.CameraImpact.ShakeDistance(1f, 5f, 10f, enemy.CenterTransform.position, 0.05f);
	}

	public void EventTorsoHeadGrow03()
	{
		//IL_0011: Unknown result type (might be due to invalid IL or missing references)
		//IL_0054: Unknown result type (might be due to invalid IL or missing references)
		//IL_0087: Unknown result type (might be due to invalid IL or missing references)
		soundHeadGrow03.Play(enemy.CenterTransform.position);
		GameDirector.instance.CameraShake.ShakeDistance(0.5f, 5f, 10f, enemy.CenterTransform.position, 0.1f);
		GameDirector.instance.CameraImpact.ShakeDistance(1f, 5f, 10f, enemy.CenterTransform.position, 0.05f);
	}

	public void EventTorsoHeadsOpenSolo()
	{
		//IL_0011: Unknown result type (might be due to invalid IL or missing references)
		soundTorsoHeadsOpenSolo.Play(enemy.CenterTransform.position);
	}

	public void EventTorsoHeadsOpenMultiple()
	{
		//IL_0011: Unknown result type (might be due to invalid IL or missing references)
		soundTorsoHeadsOpenMultiple.Play(enemy.CenterTransform.position);
	}

	public void EventTorsoHeadsCloseSolo()
	{
		//IL_0011: Unknown result type (might be due to invalid IL or missing references)
		soundTorsoHeadsCloseSolo.Play(enemy.CenterTransform.position);
	}

	public void EventTorsoHeadsCloseMultiple()
	{
		//IL_0011: Unknown result type (might be due to invalid IL or missing references)
		soundTorsoHeadsCloseMultiple.Play(enemy.CenterTransform.position);
	}

	public void EventTorsoHeadsMeleeTrigger()
	{
		animator.SetTrigger(animTorsoHeadsMelee);
	}

	public void EventTorsoHeadsScreamTrigger()
	{
		animator.SetTrigger(animTorsoHeadsScream);
	}

	public void EventTorsoHeadsScream()
	{
		//IL_0011: Unknown result type (might be due to invalid IL or missing references)
		//IL_0041: Unknown result type (might be due to invalid IL or missing references)
		//IL_0084: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b7: Unknown result type (might be due to invalid IL or missing references)
		soundTorsoHeadsScream.Play(enemy.CenterTransform.position);
		soundTorsoHeadsScreamGlobal.Play(enemy.CenterTransform.position);
		GameDirector.instance.CameraShake.ShakeDistance(1f, 8f, 12f, enemy.CenterTransform.position, 1f);
		GameDirector.instance.CameraImpact.ShakeDistance(2f, 8f, 12f, enemy.CenterTransform.position, 0.25f);
	}

	public void EventTorsoHeadsBreakerShake()
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_0057: Unknown result type (might be due to invalid IL or missing references)
		GameDirector.instance.CameraShake.ShakeDistance(0.5f, 5f, 10f, enemy.CenterTransform.position, 0.05f);
		GameDirector.instance.CameraImpact.ShakeDistance(1f, 5f, 10f, enemy.CenterTransform.position, 0.05f);
	}

	public void EventTorsoHeadsBreaker00()
	{
		//IL_0017: Unknown result type (might be due to invalid IL or missing references)
		EventTorsoHeadsBreakerShake();
		soundTorsoHeadsBreaker00.Play(enemy.CenterTransform.position);
	}

	public void EventTorsoHeadsBreaker01()
	{
		//IL_0017: Unknown result type (might be due to invalid IL or missing references)
		EventTorsoHeadsBreakerShake();
		soundTorsoHeadsBreaker01.Play(enemy.CenterTransform.position);
	}

	public void EventTorsoHeadsBreaker02()
	{
		//IL_0017: Unknown result type (might be due to invalid IL or missing references)
		EventTorsoHeadsBreakerShake();
		soundTorsoHeadsBreaker02.Play(enemy.CenterTransform.position);
	}

	public void EventTorsoHeadsBreaker03()
	{
		//IL_0017: Unknown result type (might be due to invalid IL or missing references)
		EventTorsoHeadsBreakerShake();
		soundTorsoHeadsBreaker03.Play(enemy.CenterTransform.position);
	}

	public void EventTorsoHeadsBreaker04()
	{
		//IL_0017: Unknown result type (might be due to invalid IL or missing references)
		EventTorsoHeadsBreakerShake();
		soundTorsoHeadsBreaker04.Play(enemy.CenterTransform.position);
	}

	public void EventTorsoHeadsBreaker05()
	{
		//IL_0017: Unknown result type (might be due to invalid IL or missing references)
		EventTorsoHeadsBreakerShake();
		soundTorsoHeadsBreaker05.Play(enemy.CenterTransform.position);
	}

	public void EventTorsoHeadsBreaker06()
	{
		//IL_0017: Unknown result type (might be due to invalid IL or missing references)
		EventTorsoHeadsBreakerShake();
		soundTorsoHeadsBreaker06.Play(enemy.CenterTransform.position);
	}

	public void EventTorsoHeadsBreaker07()
	{
		//IL_0017: Unknown result type (might be due to invalid IL or missing references)
		EventTorsoHeadsBreakerShake();
		soundTorsoHeadsBreaker07.Play(enemy.CenterTransform.position);
	}

	public void EventTorsoHeadsBreaker08()
	{
		//IL_0017: Unknown result type (might be due to invalid IL or missing references)
		EventTorsoHeadsBreakerShake();
		soundTorsoHeadsBreaker08.Play(enemy.CenterTransform.position);
	}

	public void EventTorsoHeadsBreaker09()
	{
		//IL_0017: Unknown result type (might be due to invalid IL or missing references)
		EventTorsoHeadsBreakerShake();
		soundTorsoHeadsBreaker09.Play(enemy.CenterTransform.position);
	}

	public void EventTorsoHeadsBreaker10()
	{
		//IL_0017: Unknown result type (might be due to invalid IL or missing references)
		EventTorsoHeadsBreakerShake();
		soundTorsoHeadsBreaker10.Play(enemy.CenterTransform.position);
	}

	public void EventTorsoHeadsBreaker11()
	{
		//IL_0017: Unknown result type (might be due to invalid IL or missing references)
		EventTorsoHeadsBreakerShake();
		soundTorsoHeadsBreaker11.Play(enemy.CenterTransform.position);
	}

	public void EventTeleportOut()
	{
		//IL_0016: Unknown result type (might be due to invalid IL or missing references)
		//IL_0059: Unknown result type (might be due to invalid IL or missing references)
		//IL_008c: Unknown result type (might be due to invalid IL or missing references)
		soundTeleportOut.Play(controller.enemy.CenterTransform.position);
		GameDirector.instance.CameraShake.ShakeDistance(3f, 3f, 8f, enemy.CenterTransform.position, 0.5f);
		GameDirector.instance.CameraImpact.ShakeDistance(3f, 3f, 8f, enemy.CenterTransform.position, 0.05f);
		ParticleSystem[] array = teleportParticles;
		for (int i = 0; i < array.Length; i++)
		{
			((Component)array[i]).gameObject.SetActive(true);
		}
	}

	public void EventHurt()
	{
		//IL_0011: Unknown result type (might be due to invalid IL or missing references)
		soundHurt.Play(enemy.CenterTransform.position);
		animator.SetTrigger(animTorsoHeadsHurt);
	}

	public void EventDeath()
	{
		//IL_0011: Unknown result type (might be due to invalid IL or missing references)
		//IL_0077: Unknown result type (might be due to invalid IL or missing references)
		//IL_00aa: Unknown result type (might be due to invalid IL or missing references)
		soundDeath.Play(enemy.CenterTransform.position);
		ParticleSystem[] array = deathParticles;
		for (int i = 0; i < array.Length; i++)
		{
			((Component)array[i]).gameObject.SetActive(true);
		}
		GameDirector.instance.CameraShake.ShakeDistance(5f, 5f, 10f, enemy.CenterTransform.position, 0.5f);
		GameDirector.instance.CameraImpact.ShakeDistance(5f, 5f, 10f, enemy.CenterTransform.position, 0.05f);
	}

	public void EventDespawn()
	{
		if (SemiFunc.IsMasterClientOrSingleplayer())
		{
			enemy.EnemyParent.Despawn();
		}
	}
}
