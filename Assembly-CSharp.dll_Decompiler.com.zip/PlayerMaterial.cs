using System.Collections.Generic;
using UnityEngine;

public class PlayerMaterial : MonoBehaviour
{
	public enum TintType
	{
		Albedo,
		Emission,
		Both
	}

	public SemiFunc.CosmeticType cosmeticType;

	internal Cosmetic cosmetic;

	[Space(20f)]
	public bool tintable;

	public TintType tintType;

	public bool tintFresnel;

	internal Material material;

	private bool materialFetched;

	public void Setup()
	{
		//IL_007b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0085: Expected Obj, but got Unknown
		if (materialFetched)
		{
			return;
		}
		Renderer component = ((Component)this).GetComponent<Renderer>();
		if (!Object.op_Implicit((Object)(object)component))
		{
			Debug.LogError((object)("<b><color=yellow>" + ((Object)cosmetic).name.Replace("(Clone)", "") + "</color></b> is missing renderer on " + ((Object)((Component)this).gameObject).name + "!"), (Object)(object)((Component)this).gameObject);
			return;
		}
		material = new Material(component.sharedMaterial);
		component.material = material;
		Collider[] componentsInChildren = ((Component)this).GetComponentsInChildren<Collider>(true);
		for (int i = 0; i < componentsInChildren.Length; i++)
		{
			componentsInChildren[i].isTrigger = true;
		}
		materialFetched = true;
	}

	private void OnDestroy()
	{
		DestroyMaterialInstance();
	}

	internal void DestroyMaterialInstance()
	{
		if (Object.op_Implicit((Object)(object)material))
		{
			Object.Destroy((Object)(object)material);
			material = null;
			materialFetched = false;
		}
	}

	public void ColorSet(int _albedoColor, int _emissionColor, int _fresnelColor, int _colorIndex)
	{
		//IL_003a: Unknown result type (might be due to invalid IL or missing references)
		//IL_003f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0058: Unknown result type (might be due to invalid IL or missing references)
		//IL_005d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0065: Unknown result type (might be due to invalid IL or missing references)
		//IL_006b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0071: Unknown result type (might be due to invalid IL or missing references)
		//IL_0077: Unknown result type (might be due to invalid IL or missing references)
		//IL_007d: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a0: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a5: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ad: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b9: Unknown result type (might be due to invalid IL or missing references)
		//IL_00bf: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c5: Unknown result type (might be due to invalid IL or missing references)
		//IL_00de: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e4: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ea: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f0: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f6: Unknown result type (might be due to invalid IL or missing references)
		if (tintable && (!Object.op_Implicit((Object)(object)cosmetic) || cosmetic.cosmeticAsset.tintable))
		{
			Color color = MetaManager.instance.colors[_colorIndex].color;
			if (tintType == TintType.Albedo || tintType == TintType.Both)
			{
				Color color2 = material.GetColor(_albedoColor);
				material.SetColor(_albedoColor, new Color(color.r, color.g, color.b, color2.a));
			}
			if (tintType == TintType.Emission || tintType == TintType.Both)
			{
				Color color3 = material.GetColor(_emissionColor);
				material.SetColor(_emissionColor, new Color(color.r, color.g, color.b, color3.a));
			}
			if (tintFresnel)
			{
				material.SetColor(_fresnelColor, new Color(color.r, color.g, color.b, color.a));
			}
		}
	}

	private IEnumerable<SemiFunc.CosmeticType> GetCosmeticTypes()
	{
		return SemiFunc.CosmeticGetTypes();
	}
}
