using System;
using Photon.Pun;
using UnityEngine;

public class EnemyBombThrowerHead : MonoBehaviour
{
	public enum State
	{
		Disabled,
		Spawn,
		Active,
		Explode
	}

	public EnemyBombThrower controller;

	public GameObject uraniumCloudPrefab;

	public GenericEyeLookAt eyeLookAt;

	internal PhysGrabObject physGrabObject;

	private PhotonView photonView;

	private ParticleScriptExplosion particleScriptExplosion;

	internal PlayerAvatar playerTarget;

	internal State currentState;

	private float stateTimer;

	private bool stateImpulse;

	private float jumpCooldown;

	private float lookAtLerp;

	private float activeDisableTimer;

	private Animator animator;

	private int animActive = Animator.StringToHash("active");

	private int animExplode = Animator.StringToHash("explode");

	public PhysicsMaterial colliderMaterial;

	private bool setColliderMaterial = true;

	public ParticleSystem particleSplash;

	public Sound soundHeadDetach;

	public Sound soundLaugh;

	public Sound soundExplosionTell;

	public Sound soundExplosion;

	private void Awake()
	{
		physGrabObject = ((Component)this).GetComponent<PhysGrabObject>();
		photonView = ((Component)this).GetComponent<PhotonView>();
		particleScriptExplosion = ((Component)this).GetComponent<ParticleScriptExplosion>();
		animator = ((Component)this).GetComponent<Animator>();
		animator.keepAnimatorStateOnDisable = true;
	}

	private void Update()
	{
		if (LevelGenerator.Instance.Generated)
		{
			StateMachine(_fixedUpdate: false);
			SetColliderMaterial();
			EyeLogic();
			SoundLoopLogic();
			GrabberSharedLogic();
		}
	}

	private void FixedUpdate()
	{
		if (LevelGenerator.Instance.Generated)
		{
			StateMachine(_fixedUpdate: true);
			CustomGravity();
		}
	}

	private void StateMachine(bool _fixedUpdate)
	{
		switch (currentState)
		{
		case State.Disabled:
			StateDisabled(_fixedUpdate);
			break;
		case State.Spawn:
			StateSpawn(_fixedUpdate);
			break;
		case State.Active:
			StateActive(_fixedUpdate);
			break;
		case State.Explode:
			StateExplode(_fixedUpdate);
			break;
		}
	}

	public void UpdateState(State _state)
	{
		//IL_003d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0043: Unknown result type (might be due to invalid IL or missing references)
		if (SemiFunc.IsMasterClientOrSingleplayer() && _state != currentState)
		{
			if (GameManager.Multiplayer())
			{
				photonView.RPC("UpdateStateRPC", (RpcTarget)0, new object[1] { _state });
			}
			else
			{
				UpdateStateRPC(_state);
			}
		}
	}

	private void StateDisabled(bool _fixedUpdate)
	{
		if (stateImpulse)
		{
			stateImpulse = false;
		}
		if (!_fixedUpdate)
		{
			animator.SetBool(animActive, false);
			if (SemiFunc.IsMasterClientOrSingleplayer())
			{
				physGrabObject.OverrideDeactivate(0.25f);
			}
		}
	}

	private void StateSpawn(bool _fixedUpdate)
	{
		//IL_00e2: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f2: Unknown result type (might be due to invalid IL or missing references)
		//IL_0107: Unknown result type (might be due to invalid IL or missing references)
		//IL_010c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0116: Unknown result type (might be due to invalid IL or missing references)
		//IL_011b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0127: Unknown result type (might be due to invalid IL or missing references)
		//IL_012d: Unknown result type (might be due to invalid IL or missing references)
		//IL_014e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0158: Unknown result type (might be due to invalid IL or missing references)
		//IL_0084: Unknown result type (might be due to invalid IL or missing references)
		//IL_008f: Unknown result type (might be due to invalid IL or missing references)
		if (stateImpulse)
		{
			animator.speed = 1f;
			if (SemiFunc.IsMasterClientOrSingleplayer())
			{
				PlayerAvatar playerAvatar = controller.playerTarget;
				if (!Object.op_Implicit((Object)(object)playerAvatar) || playerAvatar.isDisabled || controller.enemy.Health.dead)
				{
					float num = float.PositiveInfinity;
					foreach (PlayerAvatar item in SemiFunc.PlayerGetList())
					{
						if (!item.isDisabled)
						{
							float num2 = Vector3.Distance(((Component)item).transform.position, ((Component)this).transform.position);
							if (num2 < num)
							{
								playerAvatar = item;
								num = num2;
							}
						}
					}
				}
				UpdatePlayerTarget(playerAvatar);
				physGrabObject.OverrideDeactivateReset();
				physGrabObject.Teleport(controller.headSpawnTransform.position, controller.headSpawnTransform.rotation);
				Vector3 val = Vector3.Lerp(controller.headSpawnTransform.forward, Vector3.up, 0.3f);
				physGrabObject.rb.AddForce(val * 20f, (ForceMode)1);
				physGrabObject.rb.AddTorque(controller.headSpawnTransform.right * 0.25f, (ForceMode)1);
			}
			stateImpulse = false;
			stateTimer = 2f;
		}
		if (_fixedUpdate)
		{
			return;
		}
		animator.SetBool(animActive, true);
		if (SemiFunc.IsMasterClientOrSingleplayer())
		{
			stateTimer -= Time.deltaTime;
			GrabbedLogic();
			if (stateTimer <= 0f)
			{
				UpdateState(State.Active);
			}
		}
	}

	private void StateActive(bool _fixedUpdate)
	{
		//IL_012f: Unknown result type (might be due to invalid IL or missing references)
		//IL_013a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0159: Unknown result type (might be due to invalid IL or missing references)
		//IL_0164: Unknown result type (might be due to invalid IL or missing references)
		//IL_0169: Unknown result type (might be due to invalid IL or missing references)
		//IL_016e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0171: Unknown result type (might be due to invalid IL or missing references)
		//IL_0176: Unknown result type (might be due to invalid IL or missing references)
		//IL_017d: Unknown result type (might be due to invalid IL or missing references)
		//IL_018e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0198: Unknown result type (might be due to invalid IL or missing references)
		//IL_019d: Unknown result type (might be due to invalid IL or missing references)
		//IL_01a9: Unknown result type (might be due to invalid IL or missing references)
		//IL_01ba: Unknown result type (might be due to invalid IL or missing references)
		//IL_01d8: Unknown result type (might be due to invalid IL or missing references)
		//IL_01ef: Unknown result type (might be due to invalid IL or missing references)
		//IL_01f0: Unknown result type (might be due to invalid IL or missing references)
		//IL_01fa: Unknown result type (might be due to invalid IL or missing references)
		//IL_01ff: Unknown result type (might be due to invalid IL or missing references)
		//IL_020b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0211: Unknown result type (might be due to invalid IL or missing references)
		if (stateImpulse)
		{
			jumpCooldown = 0.5f;
			lookAtLerp = 0f;
			stateImpulse = false;
			stateTimer = 5f;
		}
		if (!_fixedUpdate)
		{
			animator.speed = Mathf.Clamp(physGrabObject.rbAngularVelocity.magnitude * 0.25f, 2f, 2.5f);
			animator.SetBool(animActive, true);
			if (SemiFunc.IsMasterClientOrSingleplayer())
			{
				stateTimer -= Time.deltaTime;
				jumpCooldown -= Time.deltaTime;
				GrabbedLogic();
				if (stateTimer <= 0f)
				{
					UpdateState(State.Explode);
				}
			}
		}
		else
		{
			if (!SemiFunc.IsMasterClientOrSingleplayer())
			{
				return;
			}
			if (activeDisableTimer > 0f)
			{
				activeDisableTimer -= Time.deltaTime;
			}
			else
			{
				if (!Object.op_Implicit((Object)(object)playerTarget) || playerTarget.isDisabled)
				{
					return;
				}
				if (physGrabObject.playerGrabbing.Count <= 0 && Vector3.Distance(((Component)playerTarget).transform.position, ((Component)this).transform.position) > 2f)
				{
					Vector3 val = ((Component)playerTarget).transform.position - ((Component)this).transform.position;
					Vector3 normalized = val.normalized;
					Vector3 val2 = SemiFunc.PhysFollowDirection(((Component)this).transform, normalized, physGrabObject.rb, 5f) * 1.5f;
					physGrabObject.rb.AddTorque(val2 / physGrabObject.rb.mass, (ForceMode)0);
					if (jumpCooldown <= 0f)
					{
						if (SemiFunc.OnGroundCheck(physGrabObject.centerPoint, 0.5f, physGrabObject))
						{
							normalized = Vector3.Lerp(normalized, Vector3.up, 0.8f);
							physGrabObject.rb.AddForce(normalized * 15f, (ForceMode)1);
						}
						jumpCooldown = 1f;
					}
					lookAtLerp = 0f;
				}
				else
				{
					LookAtPlayerLogic();
				}
			}
		}
	}

	private void StateExplode(bool _fixedUpdate)
	{
		if (stateImpulse)
		{
			animator.speed = 1f;
			animator.SetTrigger(animExplode);
			stateImpulse = false;
			stateTimer = 1f;
		}
		if (!_fixedUpdate)
		{
			if (SemiFunc.IsMasterClientOrSingleplayer())
			{
				stateTimer -= Time.deltaTime;
				if (stateTimer <= 0f)
				{
					UpdateState(State.Disabled);
				}
			}
		}
		else if (SemiFunc.IsMasterClientOrSingleplayer())
		{
			LookAtPlayerLogic();
		}
	}

	private void SetColliderMaterial()
	{
		if (SemiFunc.IsMasterClientOrSingleplayer() && setColliderMaterial && LevelGenerator.Instance.Generated)
		{
			((Component)this).GetComponentInChildren<Collider>().material = colliderMaterial;
			setColliderMaterial = false;
		}
	}

	private void CustomGravity()
	{
		//IL_004a: Unknown result type (might be due to invalid IL or missing references)
		//IL_004f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0059: Unknown result type (might be due to invalid IL or missing references)
		if (SemiFunc.IsMasterClientOrSingleplayer() && !physGrabObject.rb.isKinematic && physGrabObject.playerGrabbing.Count <= 0 && !Object.op_Implicit((Object)(object)physGrabObject.deathPitEffect))
		{
			physGrabObject.rb.AddForce(-Vector3.up * 15f, (ForceMode)0);
		}
	}

	private void EyeLogic()
	{
		if (Object.op_Implicit((Object)(object)playerTarget) && !playerTarget.isDisabled)
		{
			eyeLookAt.SetTargetPlayer(playerTarget);
		}
	}

	private void UpdatePlayerTarget(PlayerAvatar _player)
	{
		playerTarget = _player;
		int num = -1;
		if (Object.op_Implicit((Object)(object)playerTarget))
		{
			num = playerTarget.photonView.ViewID;
		}
		if (GameManager.Multiplayer())
		{
			photonView.RPC("UpdatePlayerTargetRPC", (RpcTarget)1, new object[1] { num });
		}
	}

	private void SoundLoopLogic()
	{
		soundLaugh.PlayLoop(currentState == State.Active, 5f, 5f, 0.75f + physGrabObject.rbAngularVelocity.magnitude * 0.02f);
	}

	private void GrabberSharedLogic()
	{
		foreach (PhysGrabber item in physGrabObject.playerGrabbing)
		{
			item.OverrideGrabPoint(((Component)physGrabObject).transform);
			item.OverrideGrabDistance(1f);
		}
		if (physGrabObject.playerGrabbing.Count > 0)
		{
			SemiFunc.EnemyOvercharge(physGrabObject, EnemyParent.Difficulty.Difficulty3, 1f);
		}
	}

	private void GrabbedLogic()
	{
		if (physGrabObject.playerGrabbing.Count > 0)
		{
			stateTimer -= 1f * Time.deltaTime;
			physGrabObject.OverrideTorqueStrength(0f, 0.2f);
			physGrabObject.OverrideGrabVerticalPosition(0.25f);
			if ((Object)(object)physGrabObject.playerGrabbing[0].playerAvatar != (Object)(object)playerTarget)
			{
				UpdatePlayerTarget(physGrabObject.playerGrabbing[0].playerAvatar);
			}
		}
	}

	private void LookAtPlayerLogic()
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0034: Unknown result type (might be due to invalid IL or missing references)
		//IL_0039: Unknown result type (might be due to invalid IL or missing references)
		//IL_003c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0041: Unknown result type (might be due to invalid IL or missing references)
		//IL_0048: Unknown result type (might be due to invalid IL or missing references)
		//IL_0049: Unknown result type (might be due to invalid IL or missing references)
		//IL_005e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0063: Unknown result type (might be due to invalid IL or missing references)
		//IL_0064: Unknown result type (might be due to invalid IL or missing references)
		//IL_0069: Unknown result type (might be due to invalid IL or missing references)
		//IL_0071: Unknown result type (might be due to invalid IL or missing references)
		//IL_0076: Unknown result type (might be due to invalid IL or missing references)
		//IL_0077: Unknown result type (might be due to invalid IL or missing references)
		//IL_007c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0083: Unknown result type (might be due to invalid IL or missing references)
		//IL_0088: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b1: Unknown result type (might be due to invalid IL or missing references)
		if (Object.op_Implicit((Object)(object)playerTarget))
		{
			float num = 5f;
			Vector3 val = playerTarget.PlayerVisionTarget.VisionTransform.position - ((Component)this).transform.position;
			Vector3 normalized = val.normalized;
			Vector3 val2 = SemiFunc.PhysFollowRotation(((Component)this).transform, Quaternion.LookRotation(normalized), physGrabObject.rb, 10f);
			val2 = Vector3.Lerp(Vector3.zero, val2, num * Time.fixedDeltaTime);
			val2 = Vector3.Lerp(Vector3.zero, val2, lookAtLerp);
			lookAtLerp = Mathf.Clamp01(lookAtLerp + 2f * Time.fixedDeltaTime);
			physGrabObject.rb.AddTorque(val2, (ForceMode)1);
		}
	}

	public void OnHurtColliderHit()
	{
		if (physGrabObject.impactDetector.onHurtColliderHitForce.magnitude > 1f)
		{
			lookAtLerp = 0f;
			activeDisableTimer = 1f;
		}
	}

	[PunRPC]
	private void UpdateStateRPC(State _state, PhotonMessageInfo _info = default(PhotonMessageInfo))
	{
		//IL_0000: Unknown result type (might be due to invalid IL or missing references)
		if (SemiFunc.MasterOnlyRPC(_info))
		{
			currentState = _state;
			stateImpulse = true;
			stateTimer = 0f;
			StateMachine(_fixedUpdate: false);
		}
	}

	[PunRPC]
	private void UpdatePlayerTargetRPC(int _photonViewID, PhotonMessageInfo _info = default(PhotonMessageInfo))
	{
		//IL_0000: Unknown result type (might be due to invalid IL or missing references)
		if (!SemiFunc.MasterOnlyRPC(_info))
		{
			return;
		}
		foreach (PlayerAvatar item in SemiFunc.PlayerGetList())
		{
			if (item.photonView.ViewID == _photonViewID)
			{
				playerTarget = item;
				break;
			}
		}
	}

	[PunRPC]
	private void ExplodeRPC(PhotonMessageInfo _info = default(PhotonMessageInfo))
	{
		//IL_0000: Unknown result type (might be due to invalid IL or missing references)
		//IL_0015: Unknown result type (might be due to invalid IL or missing references)
		//IL_0051: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d4: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d9: Unknown result type (might be due to invalid IL or missing references)
		if (SemiFunc.MasterOnlyRPC(_info))
		{
			soundExplosion.Play(physGrabObject.centerPoint);
			((Component)particleSplash).gameObject.SetActive(true);
			ParticlePrefabExplosion particlePrefabExplosion = particleScriptExplosion.Spawn(((Component)this).transform.position, 2f, 75, 30, 4f);
			particlePrefabExplosion.HurtCollider.ignoreObjects.Add(physGrabObject);
			particlePrefabExplosion.HurtCollider.enemyHost = controller.enemy;
			particlePrefabExplosion.particleSizeMultiplier = 0.8f;
			particlePrefabExplosion.HurtCollider.playerTumbleImpactHurtDamage = 10;
			particlePrefabExplosion.HurtCollider.playerTumbleImpactHurtTime = 2f;
			UraniumScript component = Object.Instantiate<GameObject>(uraniumCloudPrefab, ((Component)this).transform.position, Quaternion.identity).GetComponent<UraniumScript>();
			component.hurtCollider.ignoreObjects.Add(controller.enemy.Rigidbody.physGrabObject);
			component.hurtCollider.enemyHost = controller.enemy;
		}
	}

	public void AnimationEventSpawn()
	{
		//IL_000c: Unknown result type (might be due to invalid IL or missing references)
		((Component)soundHeadDetach.Play(physGrabObject.centerPoint)).transform.SetParent(((Component)this).transform, true);
	}

	public void AnimationEventExplosionTell()
	{
		//IL_001f: Unknown result type (might be due to invalid IL or missing references)
		//IL_004d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		GameDirector.instance.CameraShake.ShakeDistance(0.5f, 3f, 5f, physGrabObject.centerPoint, 0.1f);
		GameDirector.instance.CameraImpact.ShakeDistance(1f, 3f, 5f, physGrabObject.centerPoint, 0.05f);
		((Component)soundExplosionTell.Play(physGrabObject.centerPoint)).transform.SetParent(((Component)this).transform, true);
	}

	public void AnimationEventExplode()
	{
		//IL_0029: Unknown result type (might be due to invalid IL or missing references)
		//IL_002f: Unknown result type (might be due to invalid IL or missing references)
		if (SemiFunc.IsMasterClientOrSingleplayer())
		{
			if (SemiFunc.IsMultiplayer())
			{
				photonView.RPC("ExplodeRPC", (RpcTarget)0, Array.Empty<object>());
			}
			else
			{
				ExplodeRPC();
			}
			stateTimer = 0f;
		}
	}
}
