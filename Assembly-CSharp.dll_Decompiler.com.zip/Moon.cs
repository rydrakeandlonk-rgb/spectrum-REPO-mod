using System;
using System.Collections.Generic;
using UnityEngine;

[CreateAssetMenu(fileName = "NewMoon", menuName = "Other/Moon")]
public class Moon : ScriptableObject
{
	[Serializable]
	public class MoonAttribute
	{
		public string text;

		public LocalizedAsset LocalizedText;
	}

	[Space]
	public string moonName = "N/A";

	public LocalizedAsset localizedMoonName;

	public Texture moonIcon;

	[Space]
	public List<MoonAttribute> moonAttributes;
}
