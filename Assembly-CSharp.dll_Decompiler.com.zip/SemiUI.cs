using System;
using System.Collections.Generic;
using TMPro;
using UnityEngine;
using UnityEngine.Events;
using UnityEngine.UI;

public class SemiUI : MonoBehaviour
{
	internal Vector3 initialPosition;

	private float shakeTimeX;

	private float shakeTimeY;

	private float shakeAmountX;

	private float shakeAmountY;

	private float shakeFrequencyX;

	private float shakeFrequencyY;

	private float shakeDurationX;

	private float shakeDurationY;

	public bool animateTheEntireObject;

	[HideInInspector]
	public TextMeshProUGUI uiText;

	private Color originalTextColor;

	private Color originalFontColor = Color.clear;

	private Color originalGlowColor = Color.clear;

	private Color flashColor;

	private float flashColorTime;

	private Material textMaterial;

	public float defaultHideTimer = 0.2f;

	internal float hideTimer;

	internal float showTimer;

	private bool uiTextEnabledPrevious;

	private float scaleTime;

	private float scaleAmount;

	private float scaleFrequency;

	internal float scaleDuration;

	internal Vector3 originalScale;

	[HideInInspector]
	public Transform textRectTransform;

	private AnimationCurve animationCurveWooshAway;

	private AnimationCurve animationCurveWooshIn;

	private AnimationCurve animationCurveInOut;

	private float hideAnimationEvaluation;

	private float showAnimationEvaluation;

	public Vector2 hidePosition = new Vector2(0f, 0f);

	[HideInInspector]
	public Vector2 showPosition = new Vector2(0f, 0f);

	internal Vector2 hidePositionCurrent = new Vector2(0f, 0f);

	private float initializedTimer = 0.2f;

	private Vector2 scootPosition = new Vector2(0f, 0f);

	private Vector2 scootPositionStart = new Vector2(0f, 0f);

	private float scootTimer = -123f;

	private Vector2 scootPositionPrev = new Vector2(0f, 0f);

	private bool scootHideImpulse = true;

	private float scootAnimationEvaluation;

	private Vector2 originalScootPosition = new Vector2(0f, 0f);

	private Vector2 scootPositionCurrent = new Vector2(0f, 0f);

	[HideInInspector]
	public bool isHidden;

	private List<GameObject> allChildren = new List<GameObject>();

	private float SpringShakeX;

	private float SpringShakeY;

	private float stopScootingTimer;

	private float stopHidingTimer;

	private float stopShowingTimer;

	private float prevShowTimer;

	private float prevHideTimer;

	private float prevScootTimer;

	private float animationEval;

	private float prevStopHidingTimer;

	private float prevStopShowingTimer;

	private float scootEval;

	public List<GameObject> doNotDisable;

	internal bool shrinkAndHide;

	public AnimationCurve animationCurveShrink;

	public UnityEvent shrinkComplete;

	protected virtual void Start()
	{
		//IL_003b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0040: Unknown result type (might be due to invalid IL or missing references)
		//IL_0059: Unknown result type (might be due to invalid IL or missing references)
		//IL_005e: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a1: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a6: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e8: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f7: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b4: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c3: Unknown result type (might be due to invalid IL or missing references)
		//IL_011b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0121: Unknown result type (might be due to invalid IL or missing references)
		//IL_0126: Unknown result type (might be due to invalid IL or missing references)
		//IL_012b: Unknown result type (might be due to invalid IL or missing references)
		//IL_010a: Unknown result type (might be due to invalid IL or missing references)
		//IL_010f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0114: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d6: Unknown result type (might be due to invalid IL or missing references)
		//IL_00db: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e0: Unknown result type (might be due to invalid IL or missing references)
		//IL_0157: Unknown result type (might be due to invalid IL or missing references)
		//IL_015c: Unknown result type (might be due to invalid IL or missing references)
		//IL_013f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0144: Unknown result type (might be due to invalid IL or missing references)
		//IL_0168: Unknown result type (might be due to invalid IL or missing references)
		//IL_016d: Unknown result type (might be due to invalid IL or missing references)
		//IL_01e1: Unknown result type (might be due to invalid IL or missing references)
		//IL_01e7: Expected Obj, but got Unknown
		if ((Object)(object)uiText == (Object)null)
		{
			uiText = ((Component)this).GetComponent<TextMeshProUGUI>();
		}
		if ((Object)(object)uiText == (Object)null)
		{
			uiText = ((Component)this).GetComponentInChildren<TextMeshProUGUI>();
		}
		initialPosition = ((Component)this).transform.localPosition;
		if (Object.op_Implicit((Object)(object)uiText))
		{
			originalTextColor = ((Graphic)uiText).color;
		}
		if (Object.op_Implicit((Object)(object)uiText))
		{
			uiTextEnabledPrevious = ((Behaviour)uiText).enabled;
		}
		if (!Object.op_Implicit((Object)(object)textRectTransform))
		{
			textRectTransform = (Transform)(object)((Component)this).GetComponent<RectTransform>();
		}
		originalScale = textRectTransform.localScale;
		if (!animateTheEntireObject)
		{
			if (showPosition == new Vector2(0f, 0f))
			{
				showPosition = Vector2.op_Implicit(textRectTransform.localPosition);
			}
		}
		else if (showPosition == new Vector2(0f, 0f))
		{
			showPosition = Vector2.op_Implicit(((Component)this).transform.localPosition);
		}
		hidePosition += showPosition;
		if (!animateTheEntireObject)
		{
			textRectTransform.localPosition = Vector2.op_Implicit(hidePosition);
		}
		else
		{
			((Component)this).transform.localPosition = Vector2.op_Implicit(hidePosition);
		}
		hidePositionCurrent = hidePosition;
		hideAnimationEvaluation = 1f;
		if (Object.op_Implicit((Object)(object)uiText) && !animateTheEntireObject && !doNotDisable.Contains(((Component)uiText).gameObject))
		{
			((Behaviour)uiText).enabled = false;
		}
		hideTimer = defaultHideTimer;
		allChildren = new List<GameObject>();
		foreach (Transform item in ((Component)this).transform)
		{
			Transform val = item;
			allChildren.Add(((Component)val).gameObject);
		}
		animationCurveWooshAway = AssetManager.instance.animationCurveWooshAway;
		animationCurveWooshIn = AssetManager.instance.animationCurveWooshIn;
		animationCurveInOut = AssetManager.instance.animationCurveInOut;
	}

	protected virtual void OnDestroy()
	{
	}

	private void AllChildrenSetActive(bool active)
	{
		foreach (GameObject allChild in allChildren)
		{
			bool flag = false;
			foreach (GameObject item in doNotDisable)
			{
				if ((Object)(object)allChild == (Object)(object)item)
				{
					flag = true;
				}
			}
			if (!flag)
			{
				allChild.SetActive(active);
			}
		}
	}

	protected virtual void Update()
	{
		if (initializedTimer > 0f)
		{
			initializedTimer -= Time.deltaTime;
			return;
		}
		float num = Mathf.Min(Time.deltaTime, 0.05f);
		if (scootTimer >= 0f)
		{
			scootTimer -= num;
		}
		FlashColorLogic(num);
		HideAnimationLogic(num);
		HideTimer(num);
		SpringScaleLogic(num);
		ScootPositionLogic(num);
		SpringShakeLogic(num);
		UpdatePositionLogic();
		prevShowTimer = showTimer;
		prevHideTimer = hideTimer;
		prevScootTimer = scootTimer;
		prevStopHidingTimer = stopHidingTimer;
		prevStopShowingTimer = stopShowingTimer;
		if (hideTimer >= 0f)
		{
			hideTimer -= num;
		}
		if (showTimer >= 0f)
		{
			showTimer -= num;
		}
		if (stopShowingTimer >= 0f)
		{
			stopShowingTimer -= num;
		}
		if (stopHidingTimer >= 0f)
		{
			stopHidingTimer -= num;
		}
		if (stopScootingTimer >= 0f)
		{
			stopScootingTimer -= num;
		}
	}

	public void SemiUISpringScale(float amount, float frequency, float time)
	{
		scaleTime = 0f;
		scaleAmount = amount;
		scaleFrequency = frequency;
		scaleDuration = time;
	}

	public void SemiUISpringShrinkAndHide(float time)
	{
		scaleTime = 0f;
		scaleDuration = time;
		shrinkAndHide = true;
	}

	private void ScootPositionLogic(float deltaTime)
	{
		//IL_0021: Unknown result type (might be due to invalid IL or missing references)
		//IL_0026: Unknown result type (might be due to invalid IL or missing references)
		//IL_0116: Unknown result type (might be due to invalid IL or missing references)
		//IL_011c: Unknown result type (might be due to invalid IL or missing references)
		//IL_003f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0044: Unknown result type (might be due to invalid IL or missing references)
		//IL_00be: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ce: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d3: Unknown result type (might be due to invalid IL or missing references)
		//IL_005e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0063: Unknown result type (might be due to invalid IL or missing references)
		//IL_0199: Unknown result type (might be due to invalid IL or missing references)
		//IL_019f: Unknown result type (might be due to invalid IL or missing references)
		//IL_01aa: Unknown result type (might be due to invalid IL or missing references)
		//IL_01af: Unknown result type (might be due to invalid IL or missing references)
		//IL_013a: Unknown result type (might be due to invalid IL or missing references)
		//IL_013f: Unknown result type (might be due to invalid IL or missing references)
		if (scootTimer <= 0f && prevScootTimer <= 0f)
		{
			if (scootPositionCurrent != Vector2.zero)
			{
				if (scootHideImpulse)
				{
					scootPositionStart = scootPositionCurrent;
					scootHideImpulse = false;
				}
				if (scootEval >= 1f)
				{
					scootPositionCurrent = Vector2.zero;
					scootAnimationEvaluation = 0f;
					scootEval = 0f;
				}
				else
				{
					scootAnimationEvaluation += 4f * deltaTime;
					scootAnimationEvaluation = Mathf.Clamp01(scootAnimationEvaluation);
					scootEval = animationCurveInOut.Evaluate(scootAnimationEvaluation);
					scootPositionCurrent = Vector2.LerpUnclamped(scootPositionStart, Vector2.zero, scootEval);
				}
			}
			else
			{
				scootHideImpulse = true;
			}
		}
		else
		{
			scootHideImpulse = true;
		}
		if (!(scootTimer > 0f) || !(prevScootTimer > 0f))
		{
			return;
		}
		stopScootingTimer = 0.1f;
		if (scootPositionCurrent != scootPosition)
		{
			if (scootEval >= 1f)
			{
				scootPositionCurrent = scootPosition;
				scootAnimationEvaluation = 0f;
				scootEval = 0f;
			}
			else
			{
				scootAnimationEvaluation += 4f * deltaTime;
				scootAnimationEvaluation = Mathf.Clamp01(scootAnimationEvaluation);
				scootEval = animationCurveInOut.Evaluate(scootAnimationEvaluation);
				scootPositionCurrent = Vector2.LerpUnclamped(scootPositionStart, scootPosition, scootEval);
			}
		}
	}

	private void UpdatePositionLogic()
	{
		//IL_0001: Unknown result type (might be due to invalid IL or missing references)
		//IL_0007: Unknown result type (might be due to invalid IL or missing references)
		//IL_000c: Unknown result type (might be due to invalid IL or missing references)
		//IL_001d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0022: Unknown result type (might be due to invalid IL or missing references)
		//IL_0027: Unknown result type (might be due to invalid IL or missing references)
		//IL_002c: Unknown result type (might be due to invalid IL or missing references)
		//IL_005b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0060: Unknown result type (might be due to invalid IL or missing references)
		//IL_003b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0040: Unknown result type (might be due to invalid IL or missing references)
		//IL_006e: Unknown result type (might be due to invalid IL or missing references)
		//IL_004e: Unknown result type (might be due to invalid IL or missing references)
		Vector3 val = Vector2.op_Implicit(hidePositionCurrent + scootPositionCurrent + new Vector2(SpringShakeX, SpringShakeY));
		if (!animateTheEntireObject)
		{
			if (textRectTransform.localPosition != val)
			{
				textRectTransform.localPosition = val;
			}
		}
		else if (((Component)this).transform.localPosition != val)
		{
			((Component)this).transform.localPosition = val;
		}
	}

	private void SpringScaleLogic(float deltaTime)
	{
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_0074: Unknown result type (might be due to invalid IL or missing references)
		//IL_0079: Unknown result type (might be due to invalid IL or missing references)
		//IL_0035: Unknown result type (might be due to invalid IL or missing references)
		//IL_003a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0040: Unknown result type (might be due to invalid IL or missing references)
		//IL_0045: Unknown result type (might be due to invalid IL or missing references)
		//IL_015c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0162: Unknown result type (might be due to invalid IL or missing references)
		//IL_0132: Unknown result type (might be due to invalid IL or missing references)
		//IL_0138: Unknown result type (might be due to invalid IL or missing references)
		//IL_007c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0087: Unknown result type (might be due to invalid IL or missing references)
		//IL_0092: Unknown result type (might be due to invalid IL or missing references)
		//IL_009d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0175: Unknown result type (might be due to invalid IL or missing references)
		//IL_014b: Unknown result type (might be due to invalid IL or missing references)
		//IL_011a: Unknown result type (might be due to invalid IL or missing references)
		//IL_011f: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d1: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d6: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b0: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b5: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e4: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c3: Unknown result type (might be due to invalid IL or missing references)
		if (scaleTime < scaleDuration)
		{
			Vector3 val;
			if (shrinkAndHide)
			{
				float num = scaleTime / scaleDuration;
				float num2 = animationCurveShrink.Evaluate(num);
				val = Vector3.LerpUnclamped(originalScale, Vector3.zero, num2);
			}
			else
			{
				float num3 = CalculateSpringOffset(scaleTime, scaleAmount, scaleFrequency, scaleDuration);
				val = originalScale * (1f + num3);
			}
			val = new Vector3(Mathf.Abs(val.x), Mathf.Abs(val.y), Mathf.Abs(val.z));
			if (!animateTheEntireObject)
			{
				if (textRectTransform.localScale != val)
				{
					textRectTransform.localScale = val;
				}
			}
			else if (((Component)this).transform.localScale != val)
			{
				((Component)this).transform.localScale = val;
			}
			scaleTime += deltaTime;
			return;
		}
		if (shrinkAndHide)
		{
			shrinkAndHide = false;
			UnityEvent val2 = shrinkComplete;
			if (val2 != null)
			{
				val2.Invoke();
			}
			originalScale = Vector3.zero;
		}
		if (!animateTheEntireObject)
		{
			if (textRectTransform.localScale != originalScale)
			{
				textRectTransform.localScale = originalScale;
			}
		}
		else if (((Component)this).transform.localScale != originalScale)
		{
			((Component)this).transform.localScale = originalScale;
		}
	}

	private void HideAnimationLogic(float deltaTime)
	{
		//IL_008c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0092: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a9: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ae: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b4: Unknown result type (might be due to invalid IL or missing references)
		//IL_00bf: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c4: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d8: Unknown result type (might be due to invalid IL or missing references)
		//IL_00dd: Unknown result type (might be due to invalid IL or missing references)
		//IL_0182: Unknown result type (might be due to invalid IL or missing references)
		//IL_0188: Unknown result type (might be due to invalid IL or missing references)
		//IL_0199: Unknown result type (might be due to invalid IL or missing references)
		//IL_019f: Unknown result type (might be due to invalid IL or missing references)
		//IL_01aa: Unknown result type (might be due to invalid IL or missing references)
		//IL_01af: Unknown result type (might be due to invalid IL or missing references)
		//IL_01c3: Unknown result type (might be due to invalid IL or missing references)
		//IL_01c8: Unknown result type (might be due to invalid IL or missing references)
		if (hideTimer <= 0f && prevHideTimer <= 0f)
		{
			if (showTimer <= 0f && prevShowTimer <= 0f)
			{
				animationEval = 0f;
				showAnimationEvaluation = 0f;
				hideAnimationEvaluation = 0f;
			}
			showTimer = 0.1f;
		}
		if (showTimer > 0f && prevShowTimer > 0f)
		{
			stopShowingTimer = 0.1f;
			if (hidePositionCurrent != showPosition)
			{
				hidePositionCurrent = Vector2.LerpUnclamped(hidePosition + scootPositionCurrent, showPosition, animationEval);
				if (showAnimationEvaluation >= 1f)
				{
					hidePositionCurrent = showPosition;
					showAnimationEvaluation = 0f;
					animationEval = 0f;
				}
				else
				{
					showAnimationEvaluation += 4f * deltaTime;
					showAnimationEvaluation = Mathf.Clamp01(showAnimationEvaluation);
					animationEval = animationCurveWooshIn.Evaluate(showAnimationEvaluation);
				}
			}
		}
		if (!(hideTimer > 0f) || !(prevHideTimer > 0f) || !(showTimer <= 0f) || !(prevShowTimer <= 0f))
		{
			return;
		}
		stopHidingTimer = 0.1f;
		if (hidePositionCurrent != hidePosition)
		{
			hidePositionCurrent = Vector2.LerpUnclamped(showPosition, hidePosition, animationEval);
			if (hideAnimationEvaluation >= 1f)
			{
				hidePositionCurrent = hidePosition;
				hideAnimationEvaluation = 0f;
				animationEval = 0f;
			}
			else
			{
				hideAnimationEvaluation += 4f * deltaTime;
				hideAnimationEvaluation = Mathf.Clamp01(hideAnimationEvaluation);
				animationEval = animationCurveWooshAway.Evaluate(hideAnimationEvaluation);
			}
		}
	}

	private void HideTimer(float deltaTime)
	{
		if (showTimer > 0f && prevShowTimer > 0f && hideTimer <= 0f && prevHideTimer <= 0f)
		{
			if (!animateTheEntireObject)
			{
				if (Object.op_Implicit((Object)(object)uiText) && !((Behaviour)uiText).enabled)
				{
					((Behaviour)uiText).enabled = true;
					isHidden = false;
					AllChildrenSetActive(active: true);
				}
			}
			else
			{
				isHidden = false;
				AllChildrenSetActive(active: true);
			}
			hideTimer = 0f;
			return;
		}
		if (hideTimer <= 0f && prevHideTimer <= 0f && stopHidingTimer <= 0f && prevStopHidingTimer <= 0f && hideAnimationEvaluation == 0f)
		{
			if (!animateTheEntireObject)
			{
				if (Object.op_Implicit((Object)(object)uiText) && !((Behaviour)uiText).enabled)
				{
					((Behaviour)uiText).enabled = true;
					isHidden = false;
					AllChildrenSetActive(active: true);
				}
			}
			else
			{
				isHidden = true;
				AllChildrenSetActive(active: true);
			}
		}
		if (!(hideTimer > 0f) || !(hideAnimationEvaluation >= 1f))
		{
			return;
		}
		if (!animateTheEntireObject)
		{
			if (Object.op_Implicit((Object)(object)uiText) && ((Behaviour)uiText).enabled)
			{
				((Behaviour)uiText).enabled = false;
				AllChildrenSetActive(active: false);
				isHidden = true;
			}
		}
		else
		{
			AllChildrenSetActive(active: false);
			isHidden = true;
		}
	}

	public void SemiUIResetAllShakeEffects()
	{
		shakeTimeX = 0f;
		shakeTimeY = 0f;
		shakeAmountX = 0f;
		shakeAmountY = 0f;
		shakeFrequencyX = 0f;
		shakeFrequencyY = 0f;
		shakeDurationX = 0f;
		shakeDurationY = 0f;
		SpringShakeX = 0f;
		SpringShakeY = 0f;
	}

	private void FlashColorLogic(float deltaTime)
	{
		//IL_0032: Unknown result type (might be due to invalid IL or missing references)
		//IL_0038: Unknown result type (might be due to invalid IL or missing references)
		//IL_0062: Unknown result type (might be due to invalid IL or missing references)
		//IL_0067: Unknown result type (might be due to invalid IL or missing references)
		//IL_004b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0085: Unknown result type (might be due to invalid IL or missing references)
		//IL_008a: Unknown result type (might be due to invalid IL or missing references)
		//IL_007a: Unknown result type (might be due to invalid IL or missing references)
		//IL_007f: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ae: Unknown result type (might be due to invalid IL or missing references)
		//IL_00bf: Unknown result type (might be due to invalid IL or missing references)
		//IL_009d: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a2: Unknown result type (might be due to invalid IL or missing references)
		//IL_00dc: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e2: Unknown result type (might be due to invalid IL or missing references)
		//IL_0106: Unknown result type (might be due to invalid IL or missing references)
		//IL_0117: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f5: Unknown result type (might be due to invalid IL or missing references)
		if (!Object.op_Implicit((Object)(object)uiText) || !(flashColorTime > 0f))
		{
			return;
		}
		flashColorTime -= deltaTime;
		if (((Graphic)uiText).color != flashColor)
		{
			((Graphic)uiText).color = flashColor;
		}
		Material fontMaterial = ((TMP_Text)uiText).fontMaterial;
		if (originalFontColor == Color.clear)
		{
			originalFontColor = fontMaterial.GetColor(ShaderUtilities.ID_FaceColor);
		}
		if (originalGlowColor == Color.clear)
		{
			originalGlowColor = fontMaterial.GetColor(ShaderUtilities.ID_GlowColor);
		}
		fontMaterial.SetColor(ShaderUtilities.ID_FaceColor, flashColor);
		fontMaterial.SetColor(ShaderUtilities.ID_GlowColor, flashColor);
		if (flashColorTime <= 0f)
		{
			if (((Graphic)uiText).color != originalTextColor)
			{
				((Graphic)uiText).color = originalTextColor;
			}
			fontMaterial.SetColor(ShaderUtilities.ID_FaceColor, originalFontColor);
			fontMaterial.SetColor(ShaderUtilities.ID_GlowColor, originalGlowColor);
		}
	}

	public void SemiUISpringShakeY(float amount, float frequency, float time)
	{
		shakeTimeY = 0f;
		shakeAmountY = amount;
		shakeFrequencyY = frequency;
		shakeDurationY = time;
	}

	public void SemiUISpringShakeX(float amount, float frequency, float time)
	{
		shakeTimeX = 0f;
		shakeAmountX = amount;
		shakeFrequencyX = frequency;
		shakeDurationX = time;
	}

	public void SemiUITextFlashColor(Color color, float time)
	{
		//IL_0001: Unknown result type (might be due to invalid IL or missing references)
		//IL_0002: Unknown result type (might be due to invalid IL or missing references)
		flashColor = color;
		flashColorTime = time;
	}

	private void SpringShakeLogic(float deltaTime)
	{
		float num = 0f;
		float num2 = 0f;
		if (shakeTimeX < shakeDurationX)
		{
			num = CalculateSpringOffset(shakeTimeX, shakeAmountX, shakeFrequencyX, shakeDurationX);
			SpringShakeX = num;
			shakeTimeX += deltaTime;
			if (shakeTimeX >= shakeDurationX)
			{
				SpringShakeX = 0f;
			}
		}
		else
		{
			SpringShakeX = 0f;
		}
		if (shakeTimeY < shakeDurationY)
		{
			num2 = CalculateSpringOffset(shakeTimeY, shakeAmountY, shakeFrequencyY, shakeDurationY);
			SpringShakeY = num2;
			shakeTimeY += deltaTime;
			if (shakeTimeY >= shakeDurationY)
			{
				SpringShakeY = 0f;
			}
		}
		else
		{
			SpringShakeY = 0f;
		}
	}

	private float CalculateSpringOffset(float currentTime, float amount, float frequency, float duration)
	{
		float num = currentTime / duration;
		float num2 = frequency * (1f - num);
		return amount * Mathf.Sin(num2 * num * MathF.PI * 2f) * (1f - num);
	}

	public void Hide()
	{
		//IL_0079: Unknown result type (might be due to invalid IL or missing references)
		//IL_007e: Unknown result type (might be due to invalid IL or missing references)
		if (hideTimer <= 0f && prevHideTimer <= 0f)
		{
			hideAnimationEvaluation = 0f;
			showAnimationEvaluation = 0f;
			animationEval = 0f;
			if (!animateTheEntireObject && Object.op_Implicit((Object)(object)uiText) && !((Behaviour)uiText).enabled)
			{
				((Behaviour)uiText).enabled = false;
				AllChildrenSetActive(active: false);
				isHidden = true;
			}
			hidePositionCurrent = showPosition;
		}
		hideTimer = 0.1f;
	}

	public void Show()
	{
		//IL_008c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0091: Unknown result type (might be due to invalid IL or missing references)
		if (showTimer <= 0f && prevShowTimer <= 0f)
		{
			showAnimationEvaluation = 0f;
			hideAnimationEvaluation = 0f;
			animationEval = 0f;
			if (!animateTheEntireObject)
			{
				if (Object.op_Implicit((Object)(object)uiText) && !((Behaviour)uiText).enabled)
				{
					((Behaviour)uiText).enabled = true;
					AllChildrenSetActive(active: true);
					isHidden = false;
				}
			}
			else
			{
				AllChildrenSetActive(active: true);
				isHidden = false;
			}
			hidePositionCurrent = hidePosition;
		}
		showTimer = 0.1f;
	}

	public void SemiUIScoot(Vector2 position, float duration = 0.2f)
	{
		//IL_0001: Unknown result type (might be due to invalid IL or missing references)
		//IL_0002: Unknown result type (might be due to invalid IL or missing references)
		//IL_0022: Unknown result type (might be due to invalid IL or missing references)
		//IL_0028: Unknown result type (might be due to invalid IL or missing references)
		//IL_004c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0051: Unknown result type (might be due to invalid IL or missing references)
		//IL_0058: Unknown result type (might be due to invalid IL or missing references)
		//IL_005d: Unknown result type (might be due to invalid IL or missing references)
		scootPosition = position;
		if ((scootTimer <= 0f && prevScootTimer <= 0f) || scootPositionPrev != scootPosition)
		{
			scootEval = 0f;
			scootAnimationEvaluation = 0f;
			scootPositionStart = scootPositionCurrent;
			scootPositionPrev = scootPosition;
		}
		scootTimer = duration;
	}

	public void RefreshShowPosition()
	{
		//IL_0001: Unknown result type (might be due to invalid IL or missing references)
		//IL_0007: Unknown result type (might be due to invalid IL or missing references)
		//IL_0047: Unknown result type (might be due to invalid IL or missing references)
		//IL_004c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0051: Unknown result type (might be due to invalid IL or missing references)
		//IL_002f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0034: Unknown result type (might be due to invalid IL or missing references)
		//IL_0039: Unknown result type (might be due to invalid IL or missing references)
		//IL_005b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0060: Unknown result type (might be due to invalid IL or missing references)
		bool flag = hidePositionCurrent == showPosition;
		if (!animateTheEntireObject)
		{
			if (!Object.op_Implicit((Object)(object)textRectTransform))
			{
				return;
			}
			showPosition = Vector2.op_Implicit(textRectTransform.localPosition);
		}
		else
		{
			showPosition = Vector2.op_Implicit(((Component)this).transform.localPosition);
		}
		if (flag)
		{
			hidePosition = showPosition;
		}
	}

	public SemiUI()
	{
		//IL_0001: Unknown result type (might be due to invalid IL or missing references)
		//IL_0006: Unknown result type (might be due to invalid IL or missing references)
		//IL_000c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0011: Unknown result type (might be due to invalid IL or missing references)
		//IL_002c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0031: Unknown result type (might be due to invalid IL or missing references)
		//IL_0041: Unknown result type (might be due to invalid IL or missing references)
		//IL_0046: Unknown result type (might be due to invalid IL or missing references)
		//IL_0056: Unknown result type (might be due to invalid IL or missing references)
		//IL_005b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0076: Unknown result type (might be due to invalid IL or missing references)
		//IL_007b: Unknown result type (might be due to invalid IL or missing references)
		//IL_008b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0090: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ab: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b0: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c7: Unknown result type (might be due to invalid IL or missing references)
		//IL_00cc: Unknown result type (might be due to invalid IL or missing references)
		//IL_00dc: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e1: Unknown result type (might be due to invalid IL or missing references)
	}
}
