using UnityEngine;

public class PlayerCollisionGrounded : MonoBehaviour
{
	public static PlayerCollisionGrounded instance;

	public PlayerCollisionController CollisionController;

	internal bool Grounded;

	private float GroundedTimer;

	public LayerMask LayerMask;

	private SphereCollider Collider;

	private float ColliderRadiusDefault;

	private float ColliderRadiusScaleTimer;

	[HideInInspector]
	public bool physRiding;

	[HideInInspector]
	public int physRidingID;

	[HideInInspector]
	public Vector3 physRidingPosition;

	private PhysGrabObject physRidingOverrideObject;

	private float physRidingOverrideTimer;

	internal bool onPhysObject;

	[RuntimeInitializeOnLoadMethod(/*Could not decode attribute arguments.*/)]
	private static void RuntimeInitializeOnLoad()
	{
		instance = null;
	}

	private void Awake()
	{
		instance = this;
		Collider = ((Component)this).GetComponent<SphereCollider>();
		ColliderRadiusDefault = Collider.radius;
	}

	private void GroundedCheck()
	{
		//IL_0041: Unknown result type (might be due to invalid IL or missing references)
		//IL_0052: Unknown result type (might be due to invalid IL or missing references)
		//IL_0170: Unknown result type (might be due to invalid IL or missing references)
		//IL_0175: Unknown result type (might be due to invalid IL or missing references)
		//IL_017a: Unknown result type (might be due to invalid IL or missing references)
		GroundedTimer -= 1f * Time.deltaTime;
		physRiding = false;
		onPhysObject = false;
		if (CollisionController.GroundedDisableTimer <= 0f)
		{
			Collider[] array = Physics.OverlapSphere(((Component)this).transform.position, Collider.radius, LayerMask.op_Implicit(LayerMask), (QueryTriggerInteraction)1);
			if (array.Length != 0)
			{
				int num = 0;
				if (LevelGenerator.Instance.Generated)
				{
					Collider[] array2 = array;
					foreach (Collider val in array2)
					{
						if (!((Component)val).gameObject.CompareTag("Phys Grab Object"))
						{
							continue;
						}
						onPhysObject = true;
						PhysGrabObject physGrabObject = ((Component)val).gameObject.GetComponent<PhysGrabObject>();
						if (!Object.op_Implicit((Object)(object)physGrabObject))
						{
							physGrabObject = ((Component)val).gameObject.GetComponentInParent<PhysGrabObject>();
						}
						if (!Object.op_Implicit((Object)(object)physGrabObject) || physGrabObject.physRidingDisabled)
						{
							continue;
						}
						if (!PlayerController.instance.JumpGroundedObjects.Contains(physGrabObject))
						{
							PlayerController.instance.JumpGroundedObjects.Add(physGrabObject);
						}
						if (Object.op_Implicit((Object)(object)((Component)physGrabObject).GetComponent<PlayerTumble>()))
						{
							num++;
							continue;
						}
						RoomVolumeCheck roomVolumeCheck = physGrabObject.roomVolumeCheck;
						if (Object.op_Implicit((Object)(object)roomVolumeCheck) && roomVolumeCheck.currentSize.magnitude > 1f)
						{
							physRiding = true;
							physRidingID = physGrabObject.photonView.ViewID;
							physRidingPosition = ((Component)physGrabObject.photonView).transform.InverseTransformPoint(((Component)PlayerController.instance).transform.position);
						}
					}
				}
				if (num != array.Length)
				{
					GroundedTimer = 0.1f;
					Grounded = true;
				}
			}
		}
		PhysRidingOverrideTick();
		if (GroundedTimer < 0f)
		{
			Grounded = false;
		}
	}

	public void OverridePhysRiding(PhysGrabObject _physGrabObject)
	{
		physRidingOverrideObject = _physGrabObject;
		physRidingOverrideTimer = 0.1f;
	}

	private void PhysRidingOverrideTick()
	{
		//IL_0053: Unknown result type (might be due to invalid IL or missing references)
		//IL_0058: Unknown result type (might be due to invalid IL or missing references)
		//IL_005d: Unknown result type (might be due to invalid IL or missing references)
		if (!(physRidingOverrideTimer <= 0f))
		{
			if (Object.op_Implicit((Object)(object)physRidingOverrideObject))
			{
				physRiding = true;
				physRidingID = physRidingOverrideObject.photonView.ViewID;
				physRidingPosition = ((Component)physRidingOverrideObject.photonView).transform.InverseTransformPoint(((Component)PlayerController.instance).transform.position);
			}
			physRidingOverrideTimer -= Time.deltaTime;
		}
	}

	private void Update()
	{
		//IL_0090: Unknown result type (might be due to invalid IL or missing references)
		//IL_0095: Unknown result type (might be due to invalid IL or missing references)
		//IL_0029: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Unknown result type (might be due to invalid IL or missing references)
		GroundedCheck();
		CollisionController.Grounded = Grounded;
		Vector3 linearVelocity;
		if (!Grounded)
		{
			linearVelocity = PlayerController.instance.rb.linearVelocity;
			if (linearVelocity.magnitude < 0.1f)
			{
				ColliderRadiusScaleTimer += Time.deltaTime;
			}
			else
			{
				ColliderRadiusScaleTimer = 0f;
			}
			if (ColliderRadiusScaleTimer >= 0.5f)
			{
				SphereCollider collider = Collider;
				collider.radius += 0.05f * Time.deltaTime;
			}
		}
		linearVelocity = PlayerController.instance.rb.linearVelocity;
		if (linearVelocity.magnitude > 0.1f)
		{
			Collider.radius = ColliderRadiusDefault;
		}
	}
}
