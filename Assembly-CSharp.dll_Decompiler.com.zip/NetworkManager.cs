using System;
using System.Collections.Generic;
using ExitGames.Client.Photon;
using Photon.Pun;
using Photon.Realtime;
using Photon.Voice.PUN;
using UnityEngine;
using UnityEngine.SceneManagement;

public class NetworkManager : MonoBehaviourPunCallbacks, IPunObservable
{
	public static NetworkManager instance;

	public float gameTime;

	public GameObject playerAvatarPrefab;

	public LocalizedAsset disconnectedHeaderLocalized;

	public LocalizedAsset disconnectedCausePrefixLocalized;

	public LocalizedAsset reasonStuckInLoadingLocalized;

	public LocalizedAsset reasonHostDisconnectedLocalized;

	public LocalizedAsset disconnectedButtonLocalized;

	public LocalizedAsset kickedHeaderLocalized;

	public LocalizedAsset kickedCauseLocalized;

	public LocalizedAsset kickedButtonLocalized;

	private List<Player> instantiatedPlayerAvatarsList = new List<Player>();

	private int instantiatedPlayerAvatars;

	private bool LoadingDone;

	internal bool leavePhotonRoom;

	internal float loadingScreenTimer;

	private bool wasKickedByServer;

	[RuntimeInitializeOnLoadMethod(/*Could not decode attribute arguments.*/)]
	private static void RuntimeInitializeOnLoad()
	{
		instance = null;
	}

	private void Start()
	{
		//IL_00af: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b4: Unknown result type (might be due to invalid IL or missing references)
		//IL_0106: Unknown result type (might be due to invalid IL or missing references)
		//IL_010b: Unknown result type (might be due to invalid IL or missing references)
		instance = this;
		RunManager.instance.SceneHandoffMessagesSet(this);
		if (RunManager.instance.SceneHandoffCancelling)
		{
			if (Object.op_Implicit((Object)(object)LevelGenerator.Instance))
			{
				LevelGenerator.Instance.GenerateCancel();
			}
		}
		else if (GameManager.instance.gameMode == 1 && !PhotonNetwork.InRoom)
		{
			Debug.LogWarning((object)"the level scene started without a photon room... the connection dropped while it was loading... leaving to the menu");
			if (Object.op_Implicit((Object)(object)LevelGenerator.Instance))
			{
				LevelGenerator.Instance.GenerateCancel();
			}
			LeavePhotonRoom();
		}
		else
		{
			if (GameManager.instance.gameMode != 1)
			{
				return;
			}
			RunManager.instance.multiplayerPool.ResourceCache[((Object)playerAvatarPrefab).name] = playerAvatarPrefab;
			PhotonNetwork.Instantiate(((Object)playerAvatarPrefab).name, Vector3.zero, Quaternion.identity, (byte)0, (object[])null);
			PhotonNetwork.SerializationRate = 25;
			PhotonNetwork.SendRate = 25;
			bool flag = true;
			PhotonVoiceView[] array = Object.FindObjectsByType<PhotonVoiceView>((FindObjectsSortMode)0);
			for (int i = 0; i < array.Length; i++)
			{
				if (((Component)array[i]).GetComponent<PhotonView>().Owner == PhotonNetwork.LocalPlayer)
				{
					flag = false;
					break;
				}
			}
			if (flag)
			{
				PhotonNetwork.InstantiatePersistent("Voice", Vector3.zero, Quaternion.identity, (byte)0, (object[])null);
			}
			((MonoBehaviourPun)this).photonView.RPC("PlayerSpawnedRPC", (RpcTarget)2, Array.Empty<object>());
		}
	}

	public override void OnEnable()
	{
		((MonoBehaviourPunCallbacks)this).OnEnable();
		PhotonNetwork.NetworkingClient.EventReceived += OnEventReceivedCustom;
	}

	public override void OnDisable()
	{
		((MonoBehaviourPunCallbacks)this).OnDisable();
		PhotonNetwork.NetworkingClient.EventReceived -= OnEventReceivedCustom;
	}

	[PunRPC]
	public void PlayerSpawnedRPC(PhotonMessageInfo _info = default(PhotonMessageInfo))
	{
		//IL_000d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0019: Unknown result type (might be due to invalid IL or missing references)
		//IL_002a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0039: Unknown result type (might be due to invalid IL or missing references)
		//IL_004c: Unknown result type (might be due to invalid IL or missing references)
		Room currentRoom = PhotonNetwork.CurrentRoom;
		if (PhotonNetwork.IsMasterClient && _info.Sender != null && currentRoom != null && currentRoom.GetPlayer(_info.Sender.ActorNumber, false) == _info.Sender && !instantiatedPlayerAvatarsList.Contains(_info.Sender))
		{
			instantiatedPlayerAvatarsList.Add(_info.Sender);
			instantiatedPlayerAvatars++;
		}
	}

	[PunRPC]
	private void GameEventSetRPC(int _event, PhotonMessageInfo _info = default(PhotonMessageInfo))
	{
		//IL_0000: Unknown result type (might be due to invalid IL or missing references)
		if (SemiFunc.MasterOnlyRPC(_info) && !LevelGenerator.Instance.AllPlayersReady && Enum.IsDefined(typeof(GameManager.GameEvents), _event))
		{
			GameManager.instance.GameEventHostSet((GameManager.GameEvents)_event);
		}
	}

	[PunRPC]
	public void AllPlayerSpawnedRPC(PhotonMessageInfo _info = default(PhotonMessageInfo))
	{
		//IL_0000: Unknown result type (might be due to invalid IL or missing references)
		if (SemiFunc.MasterOnlyRPC(_info))
		{
			LevelGenerator.Instance.AllPlayersReady = true;
		}
	}

	public void OnPhotonSerializeView(PhotonStream stream, PhotonMessageInfo info)
	{
		//IL_0000: Unknown result type (might be due to invalid IL or missing references)
		if (SemiFunc.MasterOnlyRPC(info))
		{
			if (stream.IsWriting)
			{
				stream.SendNext((object)instantiatedPlayerAvatars);
			}
			else
			{
				instantiatedPlayerAvatars = (int)stream.ReceiveNext();
			}
		}
	}

	private bool PlayerAvatarsReady()
	{
		instantiatedPlayerAvatars = 0;
		Room currentRoom = PhotonNetwork.CurrentRoom;
		if (currentRoom == null || currentRoom.PlayerCount == 0)
		{
			return false;
		}
		foreach (Player value in currentRoom.Players.Values)
		{
			if (instantiatedPlayerAvatarsList.Contains(value))
			{
				instantiatedPlayerAvatars++;
			}
		}
		return instantiatedPlayerAvatars == currentRoom.PlayerCount;
	}

	private void Update()
	{
		if (RunManager.instance.SceneHandoffCancelling)
		{
			return;
		}
		if (GameManager.instance.gameMode == 1 && PhotonNetwork.IsMasterClient && !LoadingDone && PlayerAvatarsReady())
		{
			((MonoBehaviourPun)this).photonView.RPC("GameEventSetRPC", (RpcTarget)4, new object[1] { (int)GameManager.instance.currentGameEvent });
			((MonoBehaviourPun)this).photonView.RPC("AllPlayerSpawnedRPC", (RpcTarget)3, Array.Empty<object>());
			LoadingDone = true;
		}
		if (LoadingScreenActive())
		{
			loadingScreenTimer += Time.deltaTime;
			if (StuckInLoading() && SemiFunc.InputDown(InputKey.Back))
			{
				TriggerLeavePhotonRoomForcedStuckInLoading();
			}
		}
		else
		{
			loadingScreenTimer = 0f;
		}
	}

	private bool LoadingScreenActive()
	{
		if (GameDirector.instance.currentState == GameDirector.gameState.Load || GameDirector.instance.currentState == GameDirector.gameState.EndWait || (GameDirector.instance.currentState == GameDirector.gameState.Start && !LoadingUI.instance.levelAnimationCompleted))
		{
			return !Object.op_Implicit((Object)(object)MenuPagePassword.instance);
		}
		return false;
	}

	internal bool StuckInLoading()
	{
		if (!RunManager.instance.SceneHandoffCancelling && loadingScreenTimer >= 25f)
		{
			return LoadingScreenActive();
		}
		return false;
	}

	public void LeavePhotonRoom()
	{
		leavePhotonRoom = false;
		RunManager.instance.LeavePhotonRoom();
	}

	public override void OnPlayerEnteredRoom(Player newPlayer)
	{
		SemiFunc.PlayerCameraRemoteRevisionImpulse();
		Debug.Log((object)("Player entered room: " + newPlayer.NickName + " (" + newPlayer.UserId + ")"));
		if (Object.op_Implicit((Object)(object)MenuPageLobby.instance))
		{
			MenuPageLobby.instance.JoiningPlayer(newPlayer.NickName);
		}
		if (PhotonNetwork.IsMasterClient && Object.op_Implicit((Object)(object)StatsManager.instance))
		{
			StatsManager.instance.NetworkSyncShadowReset();
		}
		PlayerAvatar playerAvatar = SemiFunc.PlayerAvatarGetFromPhotonPlayer(newPlayer);
		if (Object.op_Implicit((Object)(object)playerAvatar) && !string.IsNullOrEmpty(newPlayer.UserId) && !GameManager.instance.localTest)
		{
			playerAvatar.AddToStatsManagerForced(newPlayer.NickName, newPlayer.UserId);
		}
	}

	public override void OnPlayerLeftRoom(Player otherPlayer)
	{
		PlayerObjectsLeave(otherPlayer);
		SemiFunc.PlayerCameraRemoteRevisionImpulse();
		Debug.Log((object)("Player left room: " + otherPlayer.NickName + " (" + otherPlayer.UserId + ")"));
	}

	private void PlayerObjectsLeave(Player _player)
	{
		if (_player == null || _player.IsInactive || leavePhotonRoom || !PhotonNetwork.InRoom)
		{
			return;
		}
		PlayerAvatar playerAvatar = SemiFunc.PlayerAvatarGetFromPhotonPlayer(_player);
		if (!Object.op_Implicit((Object)(object)playerAvatar))
		{
			return;
		}
		if (Object.op_Implicit((Object)(object)playerAvatar.playerDeathHead))
		{
			((Component)playerAvatar.playerDeathHead).transform.SetParent((Transform)null, true);
			((Component)playerAvatar.playerDeathHead).gameObject.SetActive(false);
		}
		if (Object.op_Implicit((Object)(object)playerAvatar.tumble))
		{
			((Component)playerAvatar.tumble).transform.SetParent((Transform)null, true);
			((Component)playerAvatar.tumble).gameObject.SetActive(false);
		}
		if (PhotonNetwork.IsMasterClient)
		{
			if (Object.op_Implicit((Object)(object)playerAvatar.playerDeathHead))
			{
				PhotonNetwork.Destroy(((Component)playerAvatar.playerDeathHead).gameObject);
			}
			if (Object.op_Implicit((Object)(object)playerAvatar.tumble))
			{
				PhotonNetwork.Destroy(((Component)playerAvatar.tumble).gameObject);
			}
		}
	}

	public override void OnMasterClientSwitched(Player _newMasterClient)
	{
		//IL_0084: Unknown result type (might be due to invalid IL or missing references)
		Debug.Log((object)"Master client left...");
		string headerText = disconnectedHeaderLocalized?.GetLocalizedString() ?? "Disconnected";
		string text = disconnectedCausePrefixLocalized?.GetLocalizedString() ?? "Cause:";
		string text2 = reasonHostDisconnectedLocalized?.GetLocalizedString() ?? "Host disconnected";
		string buttonText = disconnectedButtonLocalized?.GetLocalizedString() ?? "Ok Dang";
		MenuManager.instance.PagePopUpScheduled(headerText, Color.red, "<b>" + text + "</b>\n" + text2, buttonText, richText: true);
		TriggerLeavePhotonRoomForced();
	}

	public void TriggerLeavePhotonRoomForcedStuckInLoading()
	{
		//IL_0080: Unknown result type (might be due to invalid IL or missing references)
		TriggerLeavePhotonRoomForced();
		string headerText = disconnectedHeaderLocalized?.GetLocalizedString() ?? "Disconnected";
		string text = disconnectedCausePrefixLocalized?.GetLocalizedString() ?? "Cause:";
		string text2 = reasonStuckInLoadingLocalized?.GetLocalizedString() ?? "Stuck in loading";
		string buttonText = disconnectedButtonLocalized?.GetLocalizedString() ?? "Ok Dang";
		MenuManager.instance.PagePopUpScheduled(headerText, Color.red, "<b>" + text + "</b>\n" + text2, buttonText, richText: true);
	}

	public void TriggerLeavePhotonRoomForced()
	{
		if (RunManager.instance.SceneHandoffActive)
		{
			RunManager.instance.SceneHandoffCancel((string)null);
			return;
		}
		leavePhotonRoom = true;
		if (Object.op_Implicit((Object)(object)LevelGenerator.Instance))
		{
			LevelGenerator.Instance.GenerateCancel();
		}
		GameDirector.instance.currentState = GameDirector.gameState.Main;
		GameDirector.instance.OutroStart();
		ResultScreenUI.instance.Disable();
	}

	public override void OnDisconnected(DisconnectCause cause)
	{
		//IL_0005: Unknown result type (might be due to invalid IL or missing references)
		//IL_0015: Unknown result type (might be due to invalid IL or missing references)
		//IL_0018: Invalid comparison between Unknown and I4
		//IL_0033: Unknown result type (might be due to invalid IL or missing references)
		//IL_0036: Invalid comparison between Unknown and I4
		//IL_002c: Unknown result type (might be due to invalid IL or missing references)
		//IL_003b: Unknown result type (might be due to invalid IL or missing references)
		//IL_003e: Invalid comparison between Unknown and I4
		//IL_0043: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a0: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a3: Invalid comparison between Unknown and I4
		//IL_00c5: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c8: Invalid comparison between Unknown and I4
		//IL_0136: Unknown result type (might be due to invalid IL or missing references)
		//IL_010e: Unknown result type (might be due to invalid IL or missing references)
		Debug.Log((object)$"Disconnected from server for reason {cause}");
		if ((int)cause == 20)
		{
			return;
		}
		if (RunManager.instance.SceneHandoffActive)
		{
			RunManager.instance.SceneHandoffCancel(cause);
		}
		else
		{
			if ((int)cause == 17 || (int)cause == 9)
			{
				return;
			}
			NetworkDisconnectReport(cause);
			string headerText = disconnectedHeaderLocalized?.GetLocalizedString() ?? "Disconnected";
			string text = disconnectedCausePrefixLocalized?.GetLocalizedString() ?? "Cause:";
			string buttonText = disconnectedButtonLocalized?.GetLocalizedString() ?? "Ok Dang";
			bool flag = (int)cause == 19 && wasKickedByServer;
			wasKickedByServer = false;
			string text2 = ((object)cause/*cast due to constrained. prefix*/).ToString();
			if ((int)cause == 19 && !string.IsNullOrEmpty(PhotonNetwork.NetworkingClient.DisconnectMessage))
			{
				text2 = PhotonNetwork.NetworkingClient.DisconnectMessage;
			}
			if (SemiFunc.IsMainMenu())
			{
				MenuManager.instance.PageCloseAll();
				MenuManager.instance.PageOpen(MenuPageIndex.Main);
				if (!flag)
				{
					MenuManager.instance.PagePopUp(headerText, Color.red, "<b>" + text + "\n</b>" + text2, buttonText, richText: true);
				}
				return;
			}
			if (!flag)
			{
				MenuManager.instance.PagePopUpScheduled(headerText, Color.red, "<b>" + text + "\n</b>" + text2, buttonText, richText: true);
			}
			leavePhotonRoom = true;
			if (Object.op_Implicit((Object)(object)LevelGenerator.Instance))
			{
				LevelGenerator.Instance.GenerateCancel();
			}
			LeavePhotonRoom();
		}
	}

	private void OnEventReceivedCustom(EventData photonEvent)
	{
		//IL_007e: Unknown result type (might be due to invalid IL or missing references)
		if (photonEvent.Code == 199)
		{
			Debug.Log((object)"You were kicked by the server.");
			wasKickedByServer = true;
			string headerText = kickedHeaderLocalized?.GetLocalizedString() ?? "Kicked";
			string bodyText = kickedCauseLocalized?.GetLocalizedString() ?? "You were kicked by the host.";
			string buttonText = kickedButtonLocalized?.GetLocalizedString() ?? "Ok Dang";
			MenuManager.instance.PagePopUpScheduled(headerText, Color.red, bodyText, buttonText, richText: true);
			TriggerLeavePhotonRoomForced();
		}
	}

	public void DestroyRunObjects()
	{
		if (SemiFunc.IsMultiplayer())
		{
			Debug.Log((object)"destroyed the run network objects");
			PhotonNetwork.DestroyNonPersistent();
		}
	}

	public void DestroyAll()
	{
		if (SemiFunc.IsMultiplayer())
		{
			Debug.Log((object)"Destroyed all network objects.");
			PhotonNetwork.DestroyAll();
		}
	}

	public void KickPlayer(Player _playerAvatar)
	{
		//IL_001c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0021: Unknown result type (might be due to invalid IL or missing references)
		//IL_0023: Unknown result type (might be due to invalid IL or missing references)
		//IL_0029: Expected Obj, but got Unknown
		//IL_002d: Unknown result type (might be due to invalid IL or missing references)
		if (SemiFunc.IsMasterClient())
		{
			object[] array = new object[1] { _playerAvatar.ActorNumber };
			RaiseEventOptions val = new RaiseEventOptions
			{
				Receivers = (ReceiverGroup)1
			};
			PhotonNetwork.RaiseEvent((byte)123, (object)array, val, SendOptions.SendReliable);
		}
	}

	public void BanPlayer(Player _playerAvatar)
	{
		//IL_001c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0021: Unknown result type (might be due to invalid IL or missing references)
		//IL_0023: Unknown result type (might be due to invalid IL or missing references)
		//IL_0029: Expected Obj, but got Unknown
		//IL_002d: Unknown result type (might be due to invalid IL or missing references)
		if (SemiFunc.IsMasterClient())
		{
			object[] array = new object[1] { _playerAvatar.ActorNumber };
			RaiseEventOptions val = new RaiseEventOptions
			{
				Receivers = (ReceiverGroup)1
			};
			PhotonNetwork.RaiseEvent((byte)124, (object)array, val, SendOptions.SendReliable);
		}
	}

	private void OnApplicationQuit()
	{
	}

	private static void NetworkDisconnectReport(DisconnectCause _cause)
	{
		//IL_00b5: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ca: Unknown result type (might be due to invalid IL or missing references)
		//IL_00cf: Unknown result type (might be due to invalid IL or missing references)
		try
		{
			LoadBalancingClient networkingClient = PhotonNetwork.NetworkingClient;
			LoadBalancingPeer val = ((networkingClient != null) ? networkingClient.LoadBalancingPeer : null);
			if (val != null)
			{
				SystemConnectionSummary systemConnectionSummary = networkingClient.SystemConnectionSummary;
				string text = ((systemConnectionSummary != null) ? $"{systemConnectionSummary} ({systemConnectionSummary.ToInt()})" : "none");
				int num = ((((PhotonPeer)val).TimestampOfLastSocketReceive > 0) ? (((PhotonPeer)val).ConnectionTime - ((PhotonPeer)val).TimestampOfLastSocketReceive) : (-1));
				string text2 = (Object.op_Implicit((Object)(object)GameDirector.instance) ? GameDirector.instance.currentState.ToString() : "none");
				float num2 = (Object.op_Implicit((Object)(object)instance) ? instance.loadingScreenTimer : 0f);
				object[] array = new object[10]
				{
					_cause,
					text,
					Application.version,
					null,
					null,
					null,
					null,
					null,
					null,
					null
				};
				Scene activeScene = SceneManager.GetActiveScene();
				array[3] = activeScene.name;
				array[4] = text2;
				array[5] = num2;
				array[6] = num;
				array[7] = ((PhotonPeer)val).RoundTripTime;
				array[8] = ((PhotonPeer)val).RoundTripTimeVariance;
				array[9] = ((PhotonPeer)val).ResentReliableCommands;
				Debug.LogError((object)string.Format("network disconnect report: cause={0}, summary={1}, build={2}, scene={3}, game={4}, loading={5:0.0}s, receiveGap={6}ms, rtt={7}ms, rttVariance={8}ms, resends={9}", array));
			}
		}
		catch (Exception ex)
		{
			Debug.LogError((object)("couldn't write the disconnect report... " + ex.Message));
		}
	}
}
