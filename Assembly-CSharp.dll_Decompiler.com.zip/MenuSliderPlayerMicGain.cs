using Photon.Realtime;
using TMPro;
using UnityEngine;

public class MenuSliderPlayerMicGain : MonoBehaviour
{
	internal MenuSlider menuSlider;

	internal PlayerAvatar playerAvatar;

	internal Player playerPhoton;

	private float currentValue;

	private bool fetched;

	private bool kickButtonFetched;

	private void Start()
	{
		menuSlider = ((Component)this).GetComponent<MenuSlider>();
		SetSlider(0.5f);
	}

	private void Update()
	{
		if (!SemiFunc.IsMultiplayer())
		{
			return;
		}
		if (!Object.op_Implicit((Object)(object)playerAvatar) && playerPhoton != null)
		{
			playerAvatar = SemiFunc.PlayerAvatarGetFromPhotonPlayer(playerPhoton);
		}
		if (!kickButtonFetched && (Object.op_Implicit((Object)(object)playerAvatar) || playerPhoton != null))
		{
			MenuButtonKick componentInChildren = ((Component)this).GetComponentInChildren<MenuButtonKick>();
			if (Object.op_Implicit((Object)(object)componentInChildren))
			{
				componentInChildren.Setup(playerAvatar, playerPhoton);
			}
			kickButtonFetched = true;
		}
		PlayerVoiceChat playerVoiceChat = (Object.op_Implicit((Object)(object)playerAvatar) ? playerAvatar.voiceChat : SemiFunc.PlayerVoiceChatGetFromPhotonPlayer(playerPhoton));
		if (!Object.op_Implicit((Object)(object)playerVoiceChat))
		{
			SetSlider(0.5f);
			return;
		}
		if ((currentValue != (float)menuSlider.currentValue || !fetched) && Object.op_Implicit((Object)(object)playerVoiceChat))
		{
			string text = (Object.op_Implicit((Object)(object)playerAvatar) ? playerAvatar.steamID : playerPhoton.UserId);
			bool flag = !string.IsNullOrEmpty(text);
			if (!fetched & flag)
			{
				playerVoiceChat.voiceGain = GameManager.instance.PlayerMicrophoneSettingGet(text);
				SetSlider(playerVoiceChat.voiceGain);
				fetched = true;
			}
			currentValue = menuSlider.currentValue;
			playerVoiceChat.voiceGain = currentValue / 200f;
			if (flag)
			{
				GameManager.instance.PlayerMicrophoneSettingSet(text, playerVoiceChat.voiceGain);
			}
		}
		menuSlider.ExtraBarSet(playerVoiceChat.clipLoudnessNoTTS * 5f);
	}

	private void SetSlider(float _value)
	{
		menuSlider.settingsValue = _value;
		menuSlider.currentValue = (int)(_value * 200f);
		menuSlider.SetBar(menuSlider.settingsValue);
		menuSlider.SetBarScaleInstant();
		currentValue = menuSlider.currentValue;
	}

	public void SliderNameSet(string name)
	{
		menuSlider = ((Component)this).GetComponent<MenuSlider>();
		menuSlider.elementName = name;
		((TMP_Text)menuSlider.elementNameText).text = name;
	}
}
