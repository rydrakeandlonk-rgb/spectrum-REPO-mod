using TMPro;
using UnityEngine;
using UnityEngine.UI;

public class MenuElementButtonCosmeticCategory : MonoBehaviour
{
	public enum ButtonType
	{
		Category,
		SubCategory,
		Presets
	}

	internal CosmeticCategoryAsset category;

	internal SemiFunc.CosmeticType subCategory;

	public ButtonType buttonType;

	private MenuPageCosmetics menuPageCosmetics;

	private MenuButton menuButton;

	public Image bgMain;

	private MenuElementCosmeticHighlight highlightObj;

	private TextMeshProUGUI text;

	internal CanvasGroup canvasGroup;

	internal SemiUI semiUI;

	private bool wasHovering;

	private Color32 bgColorMain = new Color32((byte)4, (byte)73, (byte)190, byte.MaxValue);

	private Color32 bgColorHover = Color32.op_Implicit(Color.white);

	private Color32 bgColorSelected = Color32.op_Implicit(Color.white);

	private Color32 textColorMain = Color32.op_Implicit(Color.white);

	private Color32 textColorSelected = Color32.op_Implicit(Color.black);

	private void Awake()
	{
		menuButton = ((Component)this).GetComponent<MenuButton>();
		menuPageCosmetics = ((Component)this).GetComponentInParent<MenuPageCosmetics>();
		text = ((Component)this).GetComponentInChildren<TextMeshProUGUI>();
		highlightObj = ((Component)this).GetComponentInChildren<MenuElementCosmeticHighlight>();
		canvasGroup = ((Component)this).GetComponent<CanvasGroup>();
		semiUI = ((Component)this).GetComponentInChildren<SemiUI>();
	}

	private void Start()
	{
		//IL_0053: Unknown result type (might be due to invalid IL or missing references)
		//IL_0058: Unknown result type (might be due to invalid IL or missing references)
		//IL_0021: Unknown result type (might be due to invalid IL or missing references)
		//IL_0026: Unknown result type (might be due to invalid IL or missing references)
		//IL_002b: Unknown result type (might be due to invalid IL or missing references)
		//IL_003e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0043: Unknown result type (might be due to invalid IL or missing references)
		menuButton.ResizeToText();
		menuButton.customColors = true;
		if (buttonType == ButtonType.SubCategory)
		{
			textColorMain = Color32.op_Implicit(Color.black);
			bgColorMain = new Color32(byte.MaxValue, (byte)115, (byte)0, byte.MaxValue);
		}
		menuButton.colorClick = AssetManager.instance.colorYellow;
		UpdateHighlight();
	}

	private void Update()
	{
		//IL_00a1: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a6: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ab: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ad: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b2: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b7: Unknown result type (might be due to invalid IL or missing references)
		//IL_0059: Unknown result type (might be due to invalid IL or missing references)
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0064: Unknown result type (might be due to invalid IL or missing references)
		//IL_007a: Unknown result type (might be due to invalid IL or missing references)
		//IL_007f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0090: Unknown result type (might be due to invalid IL or missing references)
		//IL_0095: Unknown result type (might be due to invalid IL or missing references)
		//IL_009a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0163: Unknown result type (might be due to invalid IL or missing references)
		//IL_0168: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d0: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d5: Unknown result type (might be due to invalid IL or missing references)
		//IL_00da: Unknown result type (might be due to invalid IL or missing references)
		//IL_00dc: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e1: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e6: Unknown result type (might be due to invalid IL or missing references)
		//IL_0182: Unknown result type (might be due to invalid IL or missing references)
		//IL_0183: Unknown result type (might be due to invalid IL or missing references)
		//IL_0176: Unknown result type (might be due to invalid IL or missing references)
		//IL_0117: Unknown result type (might be due to invalid IL or missing references)
		//IL_011c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0121: Unknown result type (might be due to invalid IL or missing references)
		//IL_0123: Unknown result type (might be due to invalid IL or missing references)
		//IL_0128: Unknown result type (might be due to invalid IL or missing references)
		//IL_012d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0152: Unknown result type (might be due to invalid IL or missing references)
		//IL_0157: Unknown result type (might be due to invalid IL or missing references)
		//IL_015c: Unknown result type (might be due to invalid IL or missing references)
		if (wasHovering != menuButton.hovering)
		{
			wasHovering = menuButton.hovering;
			if (wasHovering)
			{
				semiUI.SemiUISpringShakeY(5f, 2f, 0.25f);
			}
		}
		if (menuButton.hovering)
		{
			if (((Graphic)bgMain).color != Color32.op_Implicit(bgColorHover))
			{
				((Graphic)bgMain).color = Color32.op_Implicit(bgColorHover);
				menuButton.colorNormal = Color32.op_Implicit(textColorSelected);
			}
			return;
		}
		Color val = Color32.op_Implicit(bgColorMain);
		Color colorNormal = Color32.op_Implicit(textColorMain);
		if (menuPageCosmetics.selectedTab == MenuPageCosmetics.CosmeticPageTab.Presets && buttonType == ButtonType.Presets)
		{
			val = Color32.op_Implicit(bgColorSelected);
			colorNormal = Color32.op_Implicit(textColorSelected);
		}
		else if (menuPageCosmetics.selectedTab == MenuPageCosmetics.CosmeticPageTab.Cosmetics)
		{
			if (buttonType == ButtonType.Category && (Object)(object)menuPageCosmetics.selectedCategory == (Object)(object)category)
			{
				val = Color32.op_Implicit(bgColorSelected);
				colorNormal = Color32.op_Implicit(textColorSelected);
			}
			else if (buttonType == ButtonType.SubCategory && menuPageCosmetics.stickyHeader.subCategory == subCategory)
			{
				val = Color32.op_Implicit(bgColorSelected);
			}
		}
		if (((Graphic)bgMain).color != val)
		{
			((Graphic)bgMain).color = val;
		}
		menuButton.colorNormal = colorNormal;
	}

	public void ClickCategory()
	{
		//IL_00fe: Unknown result type (might be due to invalid IL or missing references)
		//IL_0104: Expected Obj, but got Unknown
		if (!Object.op_Implicit((Object)(object)menuPageCosmetics) || !menuPageCosmetics.subCategoriesReady)
		{
			return;
		}
		semiUI.SemiUISpringScale(0.1f, 2f, 0.2f);
		if (buttonType == ButtonType.Category)
		{
			if ((Object)(object)menuPageCosmetics.selectedCategory != (Object)(object)category || menuPageCosmetics.selectedTab != MenuPageCosmetics.CosmeticPageTab.Cosmetics)
			{
				menuPageCosmetics.selectedTab = MenuPageCosmetics.CosmeticPageTab.Cosmetics;
				menuPageCosmetics.SetCurrentCategory(category);
			}
		}
		else if (buttonType == ButtonType.SubCategory)
		{
			if (menuPageCosmetics.selectedTab == MenuPageCosmetics.CosmeticPageTab.Cosmetics)
			{
				menuPageCosmetics.SetCurrentSubCategory(subCategory);
			}
		}
		else
		{
			if (buttonType != ButtonType.Presets || menuPageCosmetics.selectedTab == MenuPageCosmetics.CosmeticPageTab.Presets)
			{
				return;
			}
			menuPageCosmetics.selectedTab = MenuPageCosmetics.CosmeticPageTab.Presets;
			menuPageCosmetics.RefreshScrollContent();
			foreach (Transform item in menuPageCosmetics.categoriesTransform)
			{
				Transform val = item;
				MenuElementButtonCosmeticCategory component = ((Component)val).GetComponent<MenuElementButtonCosmeticCategory>();
				if (Object.op_Implicit((Object)(object)component) && component.buttonType == ButtonType.Presets)
				{
					menuPageCosmetics.categoriesHolder.ScrollToShow(((Component)val).GetComponent<RectTransform>());
					break;
				}
			}
		}
	}

	internal void UpdateHighlight()
	{
		if (!Object.op_Implicit((Object)(object)highlightObj))
		{
			return;
		}
		int num = 0;
		if (menuPageCosmetics.selectedTab == MenuPageCosmetics.CosmeticPageTab.Cosmetics && (buttonType == ButtonType.Category || buttonType == ButtonType.SubCategory))
		{
			for (int i = 0; i < MetaManager.instance.cosmeticAssets.Count; i++)
			{
				if (!MetaManager.instance.cosmeticHistory.Contains(i) && MetaManager.instance.cosmeticUnlocks.Contains(i))
				{
					CosmeticAsset cosmeticAsset = MetaManager.instance.cosmeticAssets[i];
					if (Object.op_Implicit((Object)(object)cosmeticAsset) && cosmeticAsset.prefab.IsValid() && (buttonType != ButtonType.Category || category.typeList.Contains(cosmeticAsset.type)) && (buttonType != ButtonType.SubCategory || cosmeticAsset.type == subCategory))
					{
						num++;
					}
				}
			}
		}
		((TMP_Text)highlightObj.text).text = num.ToString();
	}

	public MenuElementButtonCosmeticCategory()
	{
		//IL_000e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0013: Unknown result type (might be due to invalid IL or missing references)
		//IL_0019: Unknown result type (might be due to invalid IL or missing references)
		//IL_001e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0023: Unknown result type (might be due to invalid IL or missing references)
		//IL_0029: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0033: Unknown result type (might be due to invalid IL or missing references)
		//IL_0039: Unknown result type (might be due to invalid IL or missing references)
		//IL_003e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0043: Unknown result type (might be due to invalid IL or missing references)
		//IL_0049: Unknown result type (might be due to invalid IL or missing references)
		//IL_004e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0053: Unknown result type (might be due to invalid IL or missing references)
	}
}
