using System;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class Aim : MonoBehaviour
{
	public enum State
	{
		Default,
		Grabbable,
		Grab,
		Rotate,
		Hidden,
		Climbable,
		Climb,
		Disabled,
		PushPull
	}

	[Serializable]
	public class AimState
	{
		public State State;

		public Sprite Sprite;

		public Color Color;
	}

	public static Aim instance;

	[Space]
	public AnimationCurve curveIntro;

	public AnimationCurve curveOutro;

	private float animLerp;

	[Space]
	public AnimationCurve curvePushPull;

	private float animLerpPushPull;

	public Transform transformPushPull;

	[Space]
	public List<AimState> aimStates;

	private AimState defaultState;

	private Image image;

	private RectTransform rect;

	private RectTransform canvasRect;

	private Vector2 defaultPosition;

	private Vector2 grabCursorCanvasPosition;

	[Space]
	[Min(0.01f)]
	public float grabCursorReturnTime = 0.25f;

	private SpringVector3 grabCursorReturnSpring = new SpringVector3
	{
		damping = 0.75f
	};

	private float grabCursorReturnTimer;

	private float stateTimer;

	private State currentState;

	private State previousState;

	private Sprite currentSprite;

	private Color currentColor;

	[RuntimeInitializeOnLoadMethod(/*Could not decode attribute arguments.*/)]
	private static void RuntimeInitializeOnLoad()
	{
		instance = null;
	}

	private void Awake()
	{
		//IL_0025: Unknown result type (might be due to invalid IL or missing references)
		//IL_002a: Unknown result type (might be due to invalid IL or missing references)
		instance = this;
		image = ((Component)this).GetComponent<Image>();
		rect = ((Component)this).GetComponent<RectTransform>();
		defaultPosition = rect.anchoredPosition;
		Canvas componentInParent = ((Component)this).GetComponentInParent<Canvas>();
		if (Object.op_Implicit((Object)(object)componentInParent))
		{
			Transform transform = ((Component)componentInParent.rootCanvas).transform;
			canvasRect = (RectTransform)(object)((transform is RectTransform) ? transform : null);
		}
		defaultState = aimStates[0];
	}

	private void Update()
	{
		//IL_0059: Unknown result type (might be due to invalid IL or missing references)
		//IL_005e: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e2: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f8: Unknown result type (might be due to invalid IL or missing references)
		//IL_0127: Unknown result type (might be due to invalid IL or missing references)
		//IL_009f: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b5: Unknown result type (might be due to invalid IL or missing references)
		//IL_01a5: Unknown result type (might be due to invalid IL or missing references)
		//IL_0175: Unknown result type (might be due to invalid IL or missing references)
		//IL_017a: Unknown result type (might be due to invalid IL or missing references)
		//IL_017d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0193: Unknown result type (might be due to invalid IL or missing references)
		//IL_023a: Unknown result type (might be due to invalid IL or missing references)
		//IL_01ff: Unknown result type (might be due to invalid IL or missing references)
		//IL_0213: Unknown result type (might be due to invalid IL or missing references)
		//IL_0229: Unknown result type (might be due to invalid IL or missing references)
		if (stateTimer > 0f)
		{
			stateTimer -= 1f * Time.deltaTime;
		}
		else if (currentState != State.Default)
		{
			animLerp = 0f;
			currentState = State.Default;
			currentSprite = defaultState.Sprite;
			currentColor = defaultState.Color;
		}
		if (currentState == previousState)
		{
			if (animLerp < 1f)
			{
				animLerp += 10f * Time.deltaTime;
				((Component)this).transform.localScale = Vector3.one * curveOutro.Evaluate(animLerp);
			}
		}
		else
		{
			animLerp += 15f * Time.deltaTime;
			((Component)this).transform.localScale = Vector3.one * curveIntro.Evaluate(animLerp);
			if (animLerp >= 1f)
			{
				image.sprite = currentSprite;
				((Graphic)image).color = currentColor;
				previousState = currentState;
				animLerp = 0f;
			}
		}
		if (previousState == currentState)
		{
			if (currentState == State.Rotate)
			{
				Transform transform = ((Component)this).transform;
				Quaternion localRotation = ((Component)this).transform.localRotation;
				transform.localRotation = Quaternion.Euler(0f, 0f, localRotation.eulerAngles.z - 100f * Time.deltaTime);
			}
			else
			{
				((Component)this).transform.localRotation = Quaternion.identity;
			}
		}
		if (previousState != currentState)
		{
			return;
		}
		if (currentState == State.PushPull)
		{
			animLerpPushPull += 1.5f * Time.deltaTime;
			if (animLerpPushPull > 1f)
			{
				animLerpPushPull = 0f;
			}
			transformPushPull.localScale = Vector3.Lerp(Vector3.one, new Vector3(0.9f, 1.2f, 1f), curvePushPull.Evaluate(animLerpPushPull));
		}
		else
		{
			transformPushPull.localScale = Vector3.one;
		}
	}

	private void LateUpdate()
	{
		UpdateGrabCursorPosition();
	}

	private void OnDisable()
	{
		ResetGrabCursorPosition();
	}

	private void UpdateGrabCursorPosition()
	{
		//IL_0060: Unknown result type (might be due to invalid IL or missing references)
		//IL_006b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0070: Unknown result type (might be due to invalid IL or missing references)
		//IL_0074: Unknown result type (might be due to invalid IL or missing references)
		//IL_0079: Unknown result type (might be due to invalid IL or missing references)
		//IL_007a: Unknown result type (might be due to invalid IL or missing references)
		//IL_007b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0080: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b0: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b5: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d7: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e2: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e4: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e9: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f6: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f8: Unknown result type (might be due to invalid IL or missing references)
		//IL_00fd: Unknown result type (might be due to invalid IL or missing references)
		//IL_0101: Unknown result type (might be due to invalid IL or missing references)
		//IL_0108: Unknown result type (might be due to invalid IL or missing references)
		//IL_010f: Unknown result type (might be due to invalid IL or missing references)
		//IL_011b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0120: Unknown result type (might be due to invalid IL or missing references)
		//IL_0122: Unknown result type (might be due to invalid IL or missing references)
		//IL_0132: Unknown result type (might be due to invalid IL or missing references)
		//IL_0139: Unknown result type (might be due to invalid IL or missing references)
		//IL_0145: Unknown result type (might be due to invalid IL or missing references)
		//IL_014a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0155: Unknown result type (might be due to invalid IL or missing references)
		//IL_015a: Unknown result type (might be due to invalid IL or missing references)
		if (Object.op_Implicit((Object)(object)rect))
		{
			PhysGrabber physGrabber = PhysGrabber.instance;
			if (!Object.op_Implicit((Object)(object)canvasRect) || !Object.op_Implicit((Object)(object)((Transform)rect).parent) || !Object.op_Implicit((Object)(object)physGrabber) || !((Behaviour)physGrabber).isActiveAndEnabled || !physGrabber.isLocal || !physGrabber.grabbed)
			{
				UpdateGrabCursorReturn();
				return;
			}
			Vector2 offset = physGrabber.gamepadGrabCursor.offset;
			Rect val = canvasRect.rect;
			Vector2 size = val.size;
			Vector2 val2 = Vector2.Scale(offset, size);
			float num = GrabCursorPixelGet(val2.x, grabCursorCanvasPosition.x);
			float num2 = GrabCursorPixelGet(val2.y, grabCursorCanvasPosition.y);
			grabCursorCanvasPosition = new Vector2(num, num2);
			Vector3 val3 = new Vector3(grabCursorCanvasPosition.x, grabCursorCanvasPosition.y, 0f);
			Vector3 val4 = ((Transform)canvasRect).TransformVector(val3);
			Vector3 val5 = ((Transform)rect).parent.InverseTransformVector(val4);
			Vector2 val6 = new Vector2(val5.x, val5.y);
			rect.anchoredPosition = defaultPosition + val6;
			grabCursorReturnSpring.lastPosition = new Vector3(val5.x, val5.y, 0f);
			grabCursorReturnSpring.springVelocity = Vector3.zero;
			grabCursorReturnTimer = Mathf.Max(0.01f, grabCursorReturnTime);
		}
	}

	private static float GrabCursorPixelGet(float position, float previous)
	{
		if (position == 0f)
		{
			return 0f;
		}
		if (Mathf.Abs(position - previous) <= 0.75f)
		{
			return previous;
		}
		return Mathf.Round(position);
	}

	private void UpdateGrabCursorReturn()
	{
		//IL_0066: Unknown result type (might be due to invalid IL or missing references)
		//IL_006c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0071: Unknown result type (might be due to invalid IL or missing references)
		//IL_0074: Unknown result type (might be due to invalid IL or missing references)
		//IL_007a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0080: Unknown result type (might be due to invalid IL or missing references)
		//IL_008c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0091: Unknown result type (might be due to invalid IL or missing references)
		//IL_0092: Unknown result type (might be due to invalid IL or missing references)
		if (grabCursorReturnTimer <= 0f)
		{
			ResetGrabCursorPosition();
			return;
		}
		float num = Mathf.Min(Time.unscaledDeltaTime, grabCursorReturnTimer);
		grabCursorReturnTimer = Mathf.Max(0f, grabCursorReturnTimer - num);
		float num2 = Mathf.Max(0.01f, grabCursorReturnTime);
		grabCursorReturnSpring.speed = 10f / num2;
		Vector3 val = SemiFunc.SpringVector3Get(grabCursorReturnSpring, Vector3.zero, num);
		Vector2 val2 = new Vector2(val.x, val.y);
		rect.anchoredPosition = defaultPosition + val2;
		if (grabCursorReturnTimer <= 0f)
		{
			ResetGrabCursorPosition();
		}
	}

	private void ResetGrabCursorPosition()
	{
		//IL_000c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0011: Unknown result type (might be due to invalid IL or missing references)
		//IL_001c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0021: Unknown result type (might be due to invalid IL or missing references)
		//IL_002c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0031: Unknown result type (might be due to invalid IL or missing references)
		//IL_004a: Unknown result type (might be due to invalid IL or missing references)
		grabCursorReturnTimer = 0f;
		grabCursorCanvasPosition = Vector2.zero;
		grabCursorReturnSpring.lastPosition = Vector3.zero;
		grabCursorReturnSpring.springVelocity = Vector3.zero;
		if (Object.op_Implicit((Object)(object)rect))
		{
			rect.anchoredPosition = defaultPosition;
		}
	}

	public void SetState(State _state)
	{
		//IL_0058: Unknown result type (might be due to invalid IL or missing references)
		//IL_005d: Unknown result type (might be due to invalid IL or missing references)
		if (_state == currentState)
		{
			stateTimer = 0.25f;
		}
		else
		{
			if (currentState == State.Hidden)
			{
				return;
			}
			foreach (AimState aimState in aimStates)
			{
				if (aimState.State == _state)
				{
					currentState = aimState.State;
					currentSprite = aimState.Sprite;
					currentColor = aimState.Color;
					animLerp = 0f;
					stateTimer = 0.2f;
					break;
				}
			}
		}
	}
}
