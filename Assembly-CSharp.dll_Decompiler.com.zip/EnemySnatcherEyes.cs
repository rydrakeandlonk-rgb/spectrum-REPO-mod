using UnityEngine;

public class EnemySnatcherEyes : MonoBehaviour
{
	public EnemySnatcher enemySnatcher;

	public EnemySnatcherVisuals visuals;

	public SemiEyes semiEyes;

	public SnatcherFacePoseSwitcher facePoseSwitcher;

	[Space]
	public float expressionHeadDownForce = 2.4f;

	public float expressionHeadUpForce = 1.25f;

	public float expressionNeckDownForce = 1.35f;

	public float expressionNeckUpForce = 0.75f;

	public float expressionHeadUpDelay = 0.08f;

	private float expressionHeadUpTimer;

	private float expressionCullingTimer;

	private int expressionCameraRevision = -1;

	private bool blinkFaceClosed;

	private float referencesFindTimer;

	private bool referencesResolved;

	private void Awake()
	{
		ReferencesFind(_force: true);
	}

	private void Update()
	{
		//IL_0025: Unknown result type (might be due to invalid IL or missing references)
		ReferencesFindTick();
		ExpressionHeadImpulseTick();
		if (Object.op_Implicit((Object)(object)enemySnatcher))
		{
			if (SemiFunc.InPlayerCameraLocal(((Component)enemySnatcher).transform.position))
			{
				LookAtLogic();
			}
			ExpressionCullingTick();
			ExpressionLogic();
		}
	}

	private void OnDisable()
	{
		FullReset();
	}

	internal void FullReset()
	{
		expressionHeadUpTimer = 0f;
		expressionCullingTimer = 0f;
		expressionCameraRevision = -1;
		blinkFaceClosed = false;
	}

	private void LookAtLogic()
	{
		//IL_0023: Unknown result type (might be due to invalid IL or missing references)
		if (Object.op_Implicit((Object)(object)semiEyes) && enemySnatcher.TryGetVisualLookPoint(out var _point))
		{
			semiEyes.OverrideLookAtSoft(_point, 0.1f, ((Component)enemySnatcher).gameObject);
		}
	}

	private void ExpressionCullingTick()
	{
		//IL_002d: Unknown result type (might be due to invalid IL or missing references)
		if (SemiFunc.IsMasterClientOrSingleplayer() && (SemiFunc.PlayerCameraRevisionChanged(ref expressionCameraRevision) || SemiFunc.PerSecond(5f, (Object)(object)this)) && SemiFunc.InPlayerCameraAny(((Component)enemySnatcher).transform.position))
		{
			expressionCullingTimer = 0.5f;
		}
	}

	private void ExpressionLogic()
	{
		if (!SemiFunc.IsMasterClientOrSingleplayer() || !Object.op_Implicit((Object)(object)facePoseSwitcher) || expressionCullingTimer <= 0f)
		{
			return;
		}
		expressionCullingTimer = Mathf.Max(0f, expressionCullingTimer - Time.deltaTime);
		ExpressionPoseGet(out var _eyesPose, out var _mouthPose);
		if (Object.op_Implicit((Object)(object)semiEyes))
		{
			float num = semiEyes.BlinkAmountGet();
			if (num >= 0.6f)
			{
				blinkFaceClosed = true;
			}
			else if (num <= 0.4f)
			{
				blinkFaceClosed = false;
			}
		}
		if (blinkFaceClosed)
		{
			_eyesPose = "eyesClosed";
		}
		int num2 = facePoseSwitcher.EyesPoseIndex(_eyesPose);
		int num3 = facePoseSwitcher.MouthPoseIndex(_mouthPose);
		if (num2 >= 0 && num3 >= 0)
		{
			enemySnatcher.FaceExpressionSet(num2, num3);
		}
	}

	private void ExpressionPoseGet(out string _eyesPose, out string _mouthPose)
	{
		_eyesPose = "eyesOpenNeutral";
		_mouthPose = "mouthHalfClosed";
		switch (enemySnatcher.currentState)
		{
		case EnemySnatcher.State.Spawn:
			_eyesPose = "eyesClosed";
			_mouthPose = "mouthHalfClosed";
			break;
		case EnemySnatcher.State.Idle:
			_eyesPose = "eyesOpenNeutral";
			_mouthPose = "mouthHalfClosed";
			break;
		case EnemySnatcher.State.IdleBreaker:
			_eyesPose = "eyesAngry";
			_mouthPose = "mouthFrown";
			break;
		case EnemySnatcher.State.Roam:
			_eyesPose = "eyesHappy";
			_mouthPose = "mouthSmile";
			break;
		case EnemySnatcher.State.DiscoverPlayer:
			_eyesPose = "eyesUnamused";
			_mouthPose = "mouthHalfClosed";
			break;
		case EnemySnatcher.State.Notice:
			_eyesPose = "eyesWide";
			_mouthPose = "mouthOpen_O";
			break;
		case EnemySnatcher.State.Chase:
		case EnemySnatcher.State.BackKickApproach:
		case EnemySnatcher.State.BackKickTurn:
			_eyesPose = "eyesAngry";
			_mouthPose = "mouthFrown";
			break;
		case EnemySnatcher.State.RiderPanic:
			_eyesPose = "eyesWide";
			_mouthPose = "mouthOpen_O";
			break;
		case EnemySnatcher.State.Search:
		case EnemySnatcher.State.Investigate:
			_eyesPose = "eyesUnamused";
			_mouthPose = "mouthFrown";
			break;
		case EnemySnatcher.State.LookUnder:
			_eyesPose = "eyesSquint";
			_mouthPose = "mouthHalfClosed";
			break;
		case EnemySnatcher.State.TongueAttackTell:
			_eyesPose = "eyesAngry";
			_mouthPose = "mouthFrown";
			break;
		case EnemySnatcher.State.Grab:
		case EnemySnatcher.State.TonguePullOut:
			_eyesPose = "eyesAngry";
			_mouthPose = "mouthOpen_O";
			break;
		case EnemySnatcher.State.FindNearbyValuable:
			_eyesPose = "eyesHappy";
			_mouthPose = "mouthSmile";
			break;
		case EnemySnatcher.State.SnatchPlayerToPoint:
			_eyesPose = "eyesHappy";
			_mouthPose = "mouthSmile";
			break;
		case EnemySnatcher.State.SnatchFinish:
			_eyesPose = "eyesHappy";
			_mouthPose = "mouthOpen_O";
			break;
		case EnemySnatcher.State.DefensiveGrabShake:
			_eyesPose = "eyesAngry";
			_mouthPose = "mouthFrown";
			break;
		case EnemySnatcher.State.TongueRelease:
			_eyesPose = "eyesUnamused";
			_mouthPose = "mouthHalfClosed";
			break;
		case EnemySnatcher.State.GrabPhysObject:
		case EnemySnatcher.State.DisarmPlayerItem:
			_eyesPose = "eyesAngry";
			_mouthPose = "mouthOpen_O";
			break;
		case EnemySnatcher.State.GrabPhysObjectHold:
		case EnemySnatcher.State.DisarmPlayerItemHold:
			_eyesPose = "eyesAngry";
			_mouthPose = "mouthFrown";
			break;
		case EnemySnatcher.State.GrabPhysObjectRelease:
		case EnemySnatcher.State.DisarmPlayerItemRelease:
			_eyesPose = "eyesAngry";
			_mouthPose = "mouthHalfClosed";
			break;
		case EnemySnatcher.State.ThrowPhysObject:
			_eyesPose = "eyesAngry";
			_mouthPose = "mouthOpen_O";
			break;
		case EnemySnatcher.State.Disappointed:
			_eyesPose = "eyesSad";
			_mouthPose = "mouthHalfSad";
			break;
		case EnemySnatcher.State.Leave:
			_eyesPose = "eyesUnamused";
			_mouthPose = "mouthHalfSad";
			break;
		case EnemySnatcher.State.Stun:
			_eyesPose = "eyesSquint";
			_mouthPose = "mouthFrown";
			break;
		case EnemySnatcher.State.StunEnd:
			_eyesPose = "eyesSquint";
			_mouthPose = "mouthHalfSad";
			break;
		case EnemySnatcher.State.Death:
			_eyesPose = "eyesClosed";
			_mouthPose = "mouthHalfSad";
			break;
		case EnemySnatcher.State.Despawn:
			_eyesPose = "eyesClosed";
			_mouthPose = "mouthHalfClosed";
			break;
		case EnemySnatcher.State.TongueDud:
		case EnemySnatcher.State.JumpCharge:
		case EnemySnatcher.State.Jump:
		case EnemySnatcher.State.JumpLand:
		case EnemySnatcher.State.BackToNavmesh:
		case EnemySnatcher.State.Retarget:
		case EnemySnatcher.State.Frustrated:
		case EnemySnatcher.State.TongueReposition:
		case EnemySnatcher.State.BackKickCharge:
		case EnemySnatcher.State.BackKick:
		case EnemySnatcher.State.BackKickRecover:
		case EnemySnatcher.State.FrontPunchTell:
		case EnemySnatcher.State.FrontPunch:
		case EnemySnatcher.State.FrontPunchRecover:
			break;
		}
	}

	public void FacePoseSet(string eyesPoseName, string mouthPoseName)
	{
		ReferencesFind();
		if (SemiFunc.IsMasterClientOrSingleplayer() && Object.op_Implicit((Object)(object)enemySnatcher) && Object.op_Implicit((Object)(object)facePoseSwitcher))
		{
			int num = facePoseSwitcher.EyesPoseIndex(eyesPoseName);
			int num2 = facePoseSwitcher.MouthPoseIndex(mouthPoseName);
			if (num >= 0 && num2 >= 0)
			{
				enemySnatcher.FaceExpressionSet(num, num2);
			}
		}
	}

	public void EyesPoseSet(string poseName)
	{
		ReferencesFind();
		if (SemiFunc.IsMasterClientOrSingleplayer() && Object.op_Implicit((Object)(object)enemySnatcher) && Object.op_Implicit((Object)(object)facePoseSwitcher))
		{
			int num = facePoseSwitcher.EyesPoseIndex(poseName);
			if (num >= 0)
			{
				enemySnatcher.FaceExpressionSet(num, facePoseSwitcher.mouthPose);
			}
		}
	}

	public void MouthPoseSet(string poseName)
	{
		ReferencesFind();
		if (SemiFunc.IsMasterClientOrSingleplayer() && Object.op_Implicit((Object)(object)enemySnatcher) && Object.op_Implicit((Object)(object)facePoseSwitcher))
		{
			int num = facePoseSwitcher.MouthPoseIndex(poseName);
			if (num >= 0)
			{
				enemySnatcher.FaceExpressionSet(facePoseSwitcher.eyesPose, num);
			}
		}
	}

	internal void FaceExpressionApply(int eyesPose, int mouthPose)
	{
		ReferencesFind();
		if (Object.op_Implicit((Object)(object)facePoseSwitcher) && facePoseSwitcher.FacePoseSet(eyesPose, mouthPose))
		{
			ExpressionHeadImpulse();
		}
	}

	private void ExpressionHeadImpulse()
	{
		//IL_0053: Unknown result type (might be due to invalid IL or missing references)
		//IL_005e: Unknown result type (might be due to invalid IL or missing references)
		//IL_009c: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a7: Unknown result type (might be due to invalid IL or missing references)
		if (Object.op_Implicit((Object)(object)visuals) && Object.op_Implicit((Object)(object)visuals.poseAnimator))
		{
			if (Object.op_Implicit((Object)(object)visuals.neckBone))
			{
				visuals.poseAnimator.SetForceOnBone(visuals.neckBone, visuals.neckBone.right * expressionNeckDownForce);
			}
			if (Object.op_Implicit((Object)(object)visuals.headBone))
			{
				visuals.poseAnimator.SetForceOnBone(visuals.headBone, visuals.headBone.right * expressionHeadDownForce);
			}
			expressionHeadUpTimer = Mathf.Max(0.01f, expressionHeadUpDelay);
		}
	}

	private void ExpressionHeadImpulseTick()
	{
		//IL_008c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0091: Unknown result type (might be due to invalid IL or missing references)
		//IL_009c: Unknown result type (might be due to invalid IL or missing references)
		//IL_00da: Unknown result type (might be due to invalid IL or missing references)
		//IL_00df: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ea: Unknown result type (might be due to invalid IL or missing references)
		if (expressionHeadUpTimer <= 0f)
		{
			return;
		}
		expressionHeadUpTimer -= Time.deltaTime;
		if (expressionHeadUpTimer > 0f)
		{
			return;
		}
		expressionHeadUpTimer = 0f;
		if (Object.op_Implicit((Object)(object)visuals) && Object.op_Implicit((Object)(object)visuals.poseAnimator))
		{
			if (Object.op_Implicit((Object)(object)visuals.neckBone))
			{
				visuals.poseAnimator.SetForceOnBone(visuals.neckBone, -visuals.neckBone.right * expressionNeckUpForce);
			}
			if (Object.op_Implicit((Object)(object)visuals.headBone))
			{
				visuals.poseAnimator.SetForceOnBone(visuals.headBone, -visuals.headBone.right * expressionHeadUpForce);
			}
		}
	}

	private void ReferencesFindTick()
	{
		if (!referencesResolved)
		{
			if (referencesFindTimer <= 0f)
			{
				ReferencesFind();
			}
			if (referencesFindTimer > 0f)
			{
				referencesFindTimer -= Time.deltaTime;
			}
		}
	}

	private void ReferencesFind(bool _force = false)
	{
		if (!referencesResolved && (_force || !(referencesFindTimer > 0f)))
		{
			referencesFindTimer = 1f;
			if (!Object.op_Implicit((Object)(object)semiEyes))
			{
				semiEyes = ((Component)this).GetComponent<SemiEyes>();
			}
			if (!Object.op_Implicit((Object)(object)visuals))
			{
				visuals = ((Component)this).GetComponentInParent<EnemySnatcherVisuals>(true);
			}
			if (!Object.op_Implicit((Object)(object)enemySnatcher) && Object.op_Implicit((Object)(object)visuals))
			{
				enemySnatcher = visuals.enemySnatcher;
			}
			if (!Object.op_Implicit((Object)(object)enemySnatcher) && Object.op_Implicit((Object)(object)visuals) && Object.op_Implicit((Object)(object)visuals.enemy))
			{
				enemySnatcher = ((Component)visuals.enemy).GetComponent<EnemySnatcher>();
			}
			if (!Object.op_Implicit((Object)(object)enemySnatcher))
			{
				enemySnatcher = ((Component)this).GetComponentInParent<EnemySnatcher>(true);
			}
			if (!Object.op_Implicit((Object)(object)facePoseSwitcher) && Object.op_Implicit((Object)(object)((Component)this).transform.parent))
			{
				facePoseSwitcher = ((Component)((Component)this).transform.parent).GetComponentInChildren<SnatcherFacePoseSwitcher>(true);
			}
			if (!Object.op_Implicit((Object)(object)facePoseSwitcher) && Object.op_Implicit((Object)(object)visuals))
			{
				facePoseSwitcher = ((Component)visuals).GetComponentInChildren<SnatcherFacePoseSwitcher>(true);
			}
			if (Object.op_Implicit((Object)(object)facePoseSwitcher) && !Object.op_Implicit((Object)(object)facePoseSwitcher.semiEyes))
			{
				facePoseSwitcher.semiEyes = semiEyes;
			}
			referencesResolved = Object.op_Implicit((Object)(object)semiEyes) && Object.op_Implicit((Object)(object)enemySnatcher) && Object.op_Implicit((Object)(object)visuals) && Object.op_Implicit((Object)(object)facePoseSwitcher);
		}
	}
}
