using UnityEngine;

public class EnemySpinnyAnim : MonoBehaviour
{
	[Header("Scripts")]
	public Enemy enemy;

	public EnemySpinny enemySpinny;

	[Header("Particles")]
	public ParticleSystem spitDroplets;

	public ParticleSystem spitSplash;

	public ParticleSystem spawnParticles;

	public ParticleSystem moneyParticle;

	public ParticleSystem lockInParticles;

	public ParticleSystem RunSpitParticleSystem;

	public EnemySpinnyParticle healParticle;

	public EnemySpinnyParticle hurtParticle;

	public EnemySpinnyParticle deathParticle;

	public EnemySpinnyParticle fullHealParticle;

	public EnemySpinnyParticle moneyPrizeParticle;

	public EnemySpinnyParticle interruptParticle;

	public ParticleSystem lightningParticle;

	public ParticleSystem healingSmokeParticle;

	public ParticleSystem smallhurtParticle;

	public ParticleSystem fullHealSmokeParticle;

	public ParticleSystem[] deathParticles;

	public GameObject interruptParticlePrefab;

	[Header("Enemy components")]
	public Transform tonguePivot;

	public Transform closedHeadPivot;

	public Transform openHeadPivot;

	public Transform playerBall;

	[Space]
	public Light pointLight;

	[Header("Roulette animation curve")]
	public AnimationCurve progressOverTime = AnimationCurve.EaseInOut(0f, 0f, 1f, 1f);

	[Header("Springs")]
	public SpringQuaternion springTopTongue = new SpringQuaternion();

	public SpringQuaternion SpringBaseTongueQuaternion = new SpringQuaternion();

	public SpringQuaternion closedTongueSpring = new SpringQuaternion();

	public SpringQuaternion headSpring = new SpringQuaternion();

	public Transform tongueTopTarget;

	public Transform tongueBaseTarget;

	public Transform tongueBase;

	public Transform tongueTop;

	public Transform closedTongueTarget;

	public Transform closedTongue;

	public Transform headTarget;

	public Transform head1;

	public Transform head2;

	public Transform headANIM;

	[Header("Sounds")]
	public Sound openMouthSound;

	public Sound closeMouthSound;

	public Sound tongueHitSound;

	public Sound noticeSound;

	public Sound jingleGreen;

	public Sound jingleRed;

	public Sound jingleBlackGlobal;

	public Sound jingleBlack;

	public Sound jingleWhite;

	public Sound jingleYellow;

	public Sound idleLoop;

	public Sound runningLoop;

	public Sound tickSound;

	public Sound rouletteLoop;

	public Sound footStep;

	public Sound hurtSound;

	public Sound deathSound;

	public Sound soundMove;

	public Sound soundMoveHead;

	public Sound muffledSongLoop;

	public Sound leaveSongSound;

	public Sound songLoop;

	public Sound interruptionSound;

	public Sound deathJingleSound;

	public Sound jumpSound;

	public Sound landSound;

	[HideInInspector]
	public bool mouthOpened;

	internal Materials.MaterialTrigger material = new Materials.MaterialTrigger();

	[HideInInspector]
	public Animator animator;

	private bool spinning;

	private bool noticed;

	private float startAngleDegrees;

	private float totalDegreesToTravel;

	private float elapsedSeconds;

	private float currentAngleDegrees;

	private float integratedCurveArea;

	private float speedScaleFactor;

	private float moveSoundRigidBodyTimer;

	private float moveSoundHeadTimer;

	private float muffledSongTimer;

	private int lastSliceIndex;

	private Quaternion prevHeadLookRotation;

	private Quaternion prevRigidBodyRotation;

	private int lastBorderAngle = -999;

	private Transform spinnyWheel => enemySpinny.spinnyWheel;

	private Transform headLook => headANIM;

	private Transform[] pieces => enemySpinny.pieces;

	private float spinDurationSeconds => enemySpinny.spinDurationSeconds;

	private Rigidbody rb => enemy.Rigidbody.rb;

	private void Awake()
	{
		animator = ((Component)this).GetComponent<Animator>();
		animator.keepAnimatorStateOnDisable = true;
	}

	private void Update()
	{
		//IL_0311: Unknown result type (might be due to invalid IL or missing references)
		//IL_0316: Unknown result type (might be due to invalid IL or missing references)
		//IL_0326: Unknown result type (might be due to invalid IL or missing references)
		//IL_033c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0341: Unknown result type (might be due to invalid IL or missing references)
		//IL_0351: Unknown result type (might be due to invalid IL or missing references)
		//IL_01be: Unknown result type (might be due to invalid IL or missing references)
		//IL_01c9: Unknown result type (might be due to invalid IL or missing references)
		//IL_01ce: Unknown result type (might be due to invalid IL or missing references)
		//IL_01d3: Unknown result type (might be due to invalid IL or missing references)
		//IL_01d8: Unknown result type (might be due to invalid IL or missing references)
		//IL_01e5: Unknown result type (might be due to invalid IL or missing references)
		//IL_01ea: Unknown result type (might be due to invalid IL or missing references)
		//IL_01ef: Unknown result type (might be due to invalid IL or missing references)
		//IL_01f1: Unknown result type (might be due to invalid IL or missing references)
		//IL_01f6: Unknown result type (might be due to invalid IL or missing references)
		//IL_01fa: Unknown result type (might be due to invalid IL or missing references)
		//IL_01ff: Unknown result type (might be due to invalid IL or missing references)
		//IL_0203: Unknown result type (might be due to invalid IL or missing references)
		//IL_021a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0211: Unknown result type (might be due to invalid IL or missing references)
		//IL_0406: Unknown result type (might be due to invalid IL or missing references)
		//IL_040b: Unknown result type (might be due to invalid IL or missing references)
		//IL_022e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0245: Unknown result type (might be due to invalid IL or missing references)
		//IL_023c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0259: Unknown result type (might be due to invalid IL or missing references)
		//IL_0276: Unknown result type (might be due to invalid IL or missing references)
		//IL_0291: Unknown result type (might be due to invalid IL or missing references)
		//IL_0293: Unknown result type (might be due to invalid IL or missing references)
		//IL_0298: Unknown result type (might be due to invalid IL or missing references)
		//IL_02a5: Unknown result type (might be due to invalid IL or missing references)
		//IL_02aa: Unknown result type (might be due to invalid IL or missing references)
		//IL_02ac: Unknown result type (might be due to invalid IL or missing references)
		//IL_02b1: Unknown result type (might be due to invalid IL or missing references)
		//IL_02bf: Unknown result type (might be due to invalid IL or missing references)
		//IL_02c4: Unknown result type (might be due to invalid IL or missing references)
		//IL_02d1: Unknown result type (might be due to invalid IL or missing references)
		//IL_02e7: Unknown result type (might be due to invalid IL or missing references)
		//IL_02ec: Unknown result type (might be due to invalid IL or missing references)
		//IL_02f9: Unknown result type (might be due to invalid IL or missing references)
		//IL_067f: Unknown result type (might be due to invalid IL or missing references)
		//IL_06a9: Unknown result type (might be due to invalid IL or missing references)
		//IL_06d3: Unknown result type (might be due to invalid IL or missing references)
		//IL_06fd: Unknown result type (might be due to invalid IL or missing references)
		//IL_0727: Unknown result type (might be due to invalid IL or missing references)
		//IL_0751: Unknown result type (might be due to invalid IL or missing references)
		//IL_088f: Unknown result type (might be due to invalid IL or missing references)
		//IL_08a9: Unknown result type (might be due to invalid IL or missing references)
		//IL_08b9: Unknown result type (might be due to invalid IL or missing references)
		//IL_0900: Unknown result type (might be due to invalid IL or missing references)
		//IL_091c: Unknown result type (might be due to invalid IL or missing references)
		TurnSoundLogic();
		AnimateSprings();
		bool playing = enemySpinny.currentState == EnemySpinny.State.Roam || enemySpinny.currentState == EnemySpinny.State.Investigate || enemySpinny.currentState == EnemySpinny.State.WaitForRoulette;
		bool playing2 = enemySpinny.currentState == EnemySpinny.State.GoToPlayer;
		bool playing3 = enemySpinny.currentState == EnemySpinny.State.Roulette && spinDurationSeconds - elapsedSeconds > 3f;
		bool playing4 = enemySpinny.currentState == EnemySpinny.State.GoToPlayer;
		bool playing5 = enemySpinny.currentState == EnemySpinny.State.Leave && muffledSongTimer > 0f;
		bool playing6 = enemySpinny.RouletteGoingOn();
		muffledSongLoop.PlayLoop(playing4, 0.6f, 1f);
		leaveSongSound.PlayLoop(playing5, 1f, 1f);
		songLoop.PlayLoop(playing6, 0.8f, 0.6f);
		idleLoop.PlayLoop(playing, 1f, 0.8f);
		runningLoop.PlayLoop(playing2, 1f, 0.8f);
		rouletteLoop.PlayLoop(playing3, 1f, 0.6f);
		if (Object.op_Implicit((Object)(object)enemySpinny.playerTarget) && (enemySpinny.currentState == EnemySpinny.State.PlayerNotice || enemySpinny.currentState == EnemySpinny.State.GoToPlayer || enemySpinny.RouletteGoingOn()))
		{
			Quaternion val = Quaternion.LookRotation(((Component)enemySpinny.playerTarget).transform.position - closedHeadPivot.position);
			Quaternion val2 = Quaternion.Inverse(closedHeadPivot.parent.rotation) * val;
			Vector3 eulerAngles = val2.eulerAngles;
			eulerAngles.x = ((eulerAngles.x > 180f) ? (eulerAngles.x - 360f) : eulerAngles.x);
			eulerAngles.y = ((eulerAngles.y > 180f) ? (eulerAngles.y - 360f) : eulerAngles.y);
			eulerAngles.x = Mathf.Clamp(eulerAngles.x, -30f, 30f);
			eulerAngles.y = Mathf.Clamp(eulerAngles.y, -45f, 45f);
			Quaternion val3 = Quaternion.Euler(eulerAngles);
			Quaternion val4 = closedHeadPivot.parent.rotation * val3;
			closedHeadPivot.rotation = Quaternion.Slerp(closedHeadPivot.rotation, val4, Time.deltaTime * 5f);
			openHeadPivot.rotation = Quaternion.Slerp(openHeadPivot.rotation, val4, Time.deltaTime * 5f);
		}
		else
		{
			closedHeadPivot.localRotation = Quaternion.Slerp(closedHeadPivot.localRotation, Quaternion.identity, Time.deltaTime * 5f);
			openHeadPivot.localRotation = Quaternion.Slerp(openHeadPivot.localRotation, Quaternion.identity, Time.deltaTime * 5f);
		}
		if (enemy.Rigidbody.velocity.magnitude > 0.3f && !enemySpinny.RouletteGoingOn() && enemySpinny.currentState != EnemySpinny.State.Idle && enemySpinny.currentState != EnemySpinny.State.PlayerNotice && enemySpinny.currentState != EnemySpinny.State.CloseMouth && enemySpinny.currentState != EnemySpinny.State.Roulette && enemySpinny.currentState != EnemySpinny.State.RouletteEnd && enemySpinny.currentState != EnemySpinny.State.RouletteEndPause)
		{
			animator.SetBool("move", true);
		}
		else
		{
			animator.SetBool("move", false);
		}
		AnimatorStateInfo currentAnimatorStateInfo = animator.GetCurrentAnimatorStateInfo(0);
		if (currentAnimatorStateInfo.IsName("Walk cycle"))
		{
			if (enemySpinny.currentState == EnemySpinny.State.Roam)
			{
				animator.speed = 1.35f;
			}
			else if (enemySpinny.currentState == EnemySpinny.State.Investigate)
			{
				animator.speed = 1.3f;
			}
			else if (enemySpinny.currentState == EnemySpinny.State.GoToPlayer)
			{
				animator.speed = 2.5f;
			}
			else if (enemySpinny.currentState == EnemySpinny.State.Leave)
			{
				animator.speed = 3.5f;
			}
			else
			{
				animator.speed = 1f;
			}
		}
		else
		{
			animator.speed = 1f;
		}
		if (!enemy.IsStunned() && (enemy.Jump.jumping || enemy.Jump.jumpingDelay))
		{
			animator.SetBool("jump", true);
		}
		else
		{
			animator.SetBool("jump", false);
		}
		if (enemySpinny.currentState == EnemySpinny.State.PlayerNotice && !noticed)
		{
			animator.SetTrigger("player_notice");
			noticed = true;
		}
		else if (enemySpinny.currentState != EnemySpinny.State.PlayerNotice)
		{
			noticed = false;
		}
		if (enemySpinny.currentState == EnemySpinny.State.GoToPlayer)
		{
			RunSpitParticleSystem.Play();
		}
		else
		{
			RunSpitParticleSystem.Stop();
		}
		if (enemy.IsStunned())
		{
			if (!animator.GetBool("stun"))
			{
				animator.SetTrigger("stun_trigger");
			}
			animator.SetBool("stun", true);
		}
		else
		{
			animator.SetBool("stun", false);
		}
		if (enemy.CurrentState == EnemyState.Despawn)
		{
			if (!animator.GetBool("despawn"))
			{
				spawnParticles.Play();
			}
			animator.SetBool("despawn", true);
		}
		else
		{
			animator.SetBool("despawn", false);
		}
		if (enemySpinny.RouletteGoingOn() && Object.op_Implicit((Object)(object)enemySpinny.playerTarget) && Object.op_Implicit((Object)(object)enemySpinny.playerTarget.tumble))
		{
			playerBall.position = enemySpinny.playerTarget.tumble.rb.position;
			((Component)lightningParticle).transform.position = enemySpinny.playerTarget.tumble.rb.position;
			((Component)lockInParticles).transform.position = enemySpinny.playerTarget.tumble.rb.position;
			((Component)healingSmokeParticle).transform.position = enemySpinny.playerTarget.tumble.rb.position;
			((Component)smallhurtParticle).transform.position = enemySpinny.playerTarget.tumble.rb.position;
			((Component)fullHealSmokeParticle).transform.position = enemySpinny.playerTarget.tumble.rb.position;
			if (enemySpinny.currentState == EnemySpinny.State.WaitForRoulette)
			{
				((Component)playerBall).gameObject.SetActive(true);
				if (!animator.GetBool("open_mouth_bool"))
				{
					TurnOnAllColors();
					if (enemySpinny.playerTarget.isLocal)
					{
						AudioScare.instance.PlaySoft();
					}
				}
				animator.SetBool("close_mouth_bool", false);
				animator.SetBool("open_mouth_bool", true);
			}
			else if (enemySpinny.currentState == EnemySpinny.State.Roulette)
			{
				if (!spinning)
				{
					PlaySpitParticles();
					BeginningOfRoulette();
					if (!enemySpinny.playerTarget.isLocal)
					{
						lockInParticles.Play(true);
					}
					animator.SetBool("open_mouth_bool", false);
					spinning = true;
				}
				StepSpinFrame();
				LightUpWheel();
				if (spinDurationSeconds - elapsedSeconds < 3f)
				{
					StopSpitParticles();
				}
				if (spinDurationSeconds - elapsedSeconds < 0.3f)
				{
					LerpTongueBack();
				}
				else
				{
					AnimateTongue();
				}
			}
			else if (enemySpinny.currentState == EnemySpinny.State.RouletteEndPause)
			{
				spinnyWheel.localRotation = Quaternion.Slerp(spinnyWheel.localRotation, Quaternion.Euler(0f, 0f, enemySpinny.targetAngleDegrees), Time.deltaTime * 5f);
				StopSpitParticles();
				LerpTongueBack();
			}
			else if (enemySpinny.currentState == EnemySpinny.State.RouletteEnd)
			{
				if (spinning)
				{
					spinning = false;
					TurnPiecesColor(enemySpinny.GetCurrentColorColor(enemySpinny.targetAngleDegrees));
					TurnLightColor(enemySpinny.GetCurrentColorColor(enemySpinny.targetAngleDegrees));
				}
				LerpTongueBack();
			}
		}
		else if (enemySpinny.currentState == EnemySpinny.State.Spawn || enemySpinny.currentState == EnemySpinny.State.CloseMouth || enemySpinny.currentState == EnemySpinny.State.Stunned)
		{
			((Component)playerBall).gameObject.SetActive(false);
			lockInParticles.Stop(true);
			((Behaviour)pointLight).enabled = false;
			if (!animator.GetBool("close_mouth_bool") || enemySpinny.currentState == EnemySpinny.State.CloseMouth)
			{
				muffledSongTimer = 5f;
			}
			animator.SetBool("close_mouth_bool", true);
			animator.SetBool("open_mouth_bool", false);
			StopSpitParticles();
			spinning = false;
		}
		else if (enemySpinny.currentState == EnemySpinny.State.Leave)
		{
			muffledSongTimer -= Time.deltaTime;
			if (animator.GetBool("close_mouth_bool"))
			{
				animator.SetBool("close_mouth_bool", false);
			}
		}
	}

	private void LightUpWheel()
	{
		//IL_007b: Unknown result type (might be due to invalid IL or missing references)
		float rotation = enemySpinny.GetRotation360();
		(int, EnemySpinny.Colors) sliceAndColour = enemySpinny.GetSliceAndColour(rotation);
		if (sliceAndColour.Item1 == lastSliceIndex)
		{
			return;
		}
		(lastSliceIndex, _) = sliceAndColour;
		TurnOnAllColors();
		for (int i = 0; i < pieces.Length; i++)
		{
			MeshRenderer component = ((Component)pieces[i]).GetComponent<MeshRenderer>();
			if (i == sliceAndColour.Item1)
			{
				((Renderer)component).material.EnableKeyword("_EMISSION");
				((Renderer)component).material.SetColor("_EmissionColor", enemySpinny.GetCurrentColorColor());
			}
		}
	}

	private void AnimateSprings()
	{
		//IL_0012: Unknown result type (might be due to invalid IL or missing references)
		//IL_001c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0038: Unknown result type (might be due to invalid IL or missing references)
		//IL_0042: Unknown result type (might be due to invalid IL or missing references)
		//IL_005e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_0084: Unknown result type (might be due to invalid IL or missing references)
		//IL_008e: Unknown result type (might be due to invalid IL or missing references)
		//IL_00aa: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b4: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ca: Unknown result type (might be due to invalid IL or missing references)
		tongueBase.rotation = SemiFunc.SpringQuaternionGet(SpringBaseTongueQuaternion, tongueBaseTarget.rotation);
		tongueTop.rotation = SemiFunc.SpringQuaternionGet(springTopTongue, tongueTopTarget.rotation);
		closedTongue.rotation = SemiFunc.SpringQuaternionGet(closedTongueSpring, closedTongueTarget.rotation);
		head1.rotation = SemiFunc.SpringQuaternionGet(headSpring, headTarget.rotation);
		head2.rotation = SemiFunc.SpringQuaternionGet(headSpring, headTarget.rotation);
		headTarget.localRotation = headANIM.localRotation;
	}

	private void AnimateTongue()
	{
		//IL_0055: Unknown result type (might be due to invalid IL or missing references)
		//IL_007b: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a6: Unknown result type (might be due to invalid IL or missing references)
		float rotation = enemySpinny.GetRotation360();
		float[] sliceBorders = enemySpinny.SliceBorders;
		for (int i = 0; i < sliceBorders.Length; i++)
		{
			int num = (int)sliceBorders[i];
			float num2 = Mathf.Abs(rotation - (float)num);
			if (num2 <= 20f && rotation > (float)num)
			{
				tonguePivot.localRotation = Quaternion.Euler(0f, 0f, num2);
				if (num != lastBorderAngle)
				{
					lastBorderAngle = num;
					tongueHitSound.Play(((Component)this).transform.position);
					tickSound.Play(((Component)this).transform.position);
				}
				return;
			}
		}
		LerpTongueBack();
	}

	private void LerpTongueBack()
	{
		//IL_0006: Unknown result type (might be due to invalid IL or missing references)
		tonguePivot.localRotation = Quaternion.identity;
	}

	private void BeginningOfRoulette()
	{
		//IL_0007: Unknown result type (might be due to invalid IL or missing references)
		startAngleDegrees = spinnyWheel.localEulerAngles.z;
		totalDegreesToTravel = (float)enemySpinny.extraSpins * 360f + GetSmallestPositiveDelta(startAngleDegrees, enemySpinny.targetAngleDegrees);
		elapsedSeconds = 0f;
	}

	private void StepSpinFrame()
	{
		//IL_00b5: Unknown result type (might be due to invalid IL or missing references)
		//IL_0043: Unknown result type (might be due to invalid IL or missing references)
		elapsedSeconds += Time.deltaTime;
		float num = elapsedSeconds / spinDurationSeconds;
		if (num >= 1f)
		{
			spinnyWheel.localRotation = Quaternion.Euler(0f, 0f, enemySpinny.targetAngleDegrees);
			return;
		}
		float num2 = progressOverTime.Evaluate(Mathf.Clamp01(num));
		float num3 = progressOverTime.Evaluate(0f);
		float num4 = progressOverTime.Evaluate(1f);
		float num5 = (num2 - num3) / (num4 - num3);
		float num6 = Mathf.Repeat(startAngleDegrees + totalDegreesToTravel * num5, 360f);
		spinnyWheel.localRotation = Quaternion.Euler(0f, 0f, num6);
	}

	public void HurtSound()
	{
		//IL_000c: Unknown result type (might be due to invalid IL or missing references)
		hurtSound.Play(((Component)this).transform.position);
	}

	public void DeathSound()
	{
		//IL_000c: Unknown result type (might be due to invalid IL or missing references)
		deathSound.Play(((Component)this).transform.position);
	}

	public void FootStepSound()
	{
		//IL_000c: Unknown result type (might be due to invalid IL or missing references)
		footStep.Play(((Component)this).transform.position);
		MaterialSoundFootStep();
	}

	public void MaterialSound()
	{
		//IL_0015: Unknown result type (might be due to invalid IL or missing references)
		//IL_001a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_0029: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Unknown result type (might be due to invalid IL or missing references)
		Materials.Instance.Impulse(enemy.Rigidbody.physGrabObject.centerPoint + Vector3.down * 0.5f, Vector3.down, Materials.SoundType.Light, footstep: false, footstepParticles: true, material, Materials.HostType.Enemy);
	}

	public void MaterialSoundFootStep()
	{
		//IL_0015: Unknown result type (might be due to invalid IL or missing references)
		//IL_001a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_0029: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Unknown result type (might be due to invalid IL or missing references)
		Materials.Instance.Impulse(enemy.Rigidbody.physGrabObject.centerPoint + Vector3.down * 0.5f, Vector3.down, Materials.SoundType.Light, footstep: true, footstepParticles: true, material, Materials.HostType.Enemy);
	}

	public void MoveSmall()
	{
		//IL_000c: Unknown result type (might be due to invalid IL or missing references)
		soundMoveHead.Play(((Component)this).transform.position);
	}

	public void MoveBig()
	{
		//IL_000c: Unknown result type (might be due to invalid IL or missing references)
		soundMove.Play(((Component)this).transform.position);
	}

	public void OpenMouthSound()
	{
		//IL_000c: Unknown result type (might be due to invalid IL or missing references)
		openMouthSound.Play(((Component)this).transform.position);
	}

	public void CloseMouthSound()
	{
		//IL_000c: Unknown result type (might be due to invalid IL or missing references)
		closeMouthSound.Play(((Component)this).transform.position);
	}

	public void NoticeSound()
	{
		//IL_0011: Unknown result type (might be due to invalid IL or missing references)
		noticeSound.Play(((Component)enemy).transform.position);
	}

	public void JumpSound()
	{
		//IL_000c: Unknown result type (might be due to invalid IL or missing references)
		jumpSound.Play(((Component)this).transform.position);
	}

	public void LandSound()
	{
		//IL_000c: Unknown result type (might be due to invalid IL or missing references)
		landSound.Play(((Component)this).transform.position);
	}

	private void TurnSoundLogic()
	{
		//IL_0011: Unknown result type (might be due to invalid IL or missing references)
		//IL_001c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0082: Unknown result type (might be due to invalid IL or missing references)
		//IL_008d: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f9: Unknown result type (might be due to invalid IL or missing references)
		//IL_00fe: Unknown result type (might be due to invalid IL or missing references)
		//IL_010a: Unknown result type (might be due to invalid IL or missing references)
		//IL_010f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0046: Unknown result type (might be due to invalid IL or missing references)
		//IL_006c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0071: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c2: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e8: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ed: Unknown result type (might be due to invalid IL or missing references)
		if (SemiFunc.PerSecond(5f, (Object)(object)this))
		{
			if (Quaternion.Angle(prevHeadLookRotation, headLook.rotation) > 30f && moveSoundHeadTimer <= 0f)
			{
				soundMoveHead.Play(headLook.position);
				prevHeadLookRotation = headLook.rotation;
				moveSoundHeadTimer = 0.2f;
			}
			if (Quaternion.Angle(prevRigidBodyRotation, rb.rotation) > 20f && moveSoundRigidBodyTimer <= 0f)
			{
				moveSoundRigidBodyTimer = 0.5f;
				soundMove.Play(((Component)this).transform.position);
				prevRigidBodyRotation = rb.rotation;
			}
			prevHeadLookRotation = headLook.rotation;
			prevRigidBodyRotation = rb.rotation;
		}
		if (moveSoundRigidBodyTimer > 0f)
		{
			moveSoundRigidBodyTimer -= Time.deltaTime;
		}
		if (moveSoundHeadTimer > 0f)
		{
			moveSoundHeadTimer -= Time.deltaTime;
		}
	}

	public void SetDespawn()
	{
		enemy.EnemyParent.Despawn();
	}

	public void SetSpawn()
	{
		animator.Play("Enemy Spinny - Spawn", 0, 0f);
		spawnParticles.Play();
	}

	public void SetMouthOpenedBoolToTrue()
	{
		mouthOpened = true;
	}

	public void SetMouthOpenedBoolToFalse()
	{
		mouthOpened = false;
	}

	private void PlaySpitParticles()
	{
		if (!spitDroplets.isPlaying)
		{
			spitDroplets.Play();
		}
		if (!spitSplash.isPlaying)
		{
			spitSplash.Play();
		}
	}

	private void StopSpitParticles()
	{
		if (spitDroplets.isPlaying)
		{
			spitDroplets.Stop();
		}
		if (spitSplash.isPlaying)
		{
			spitSplash.Stop();
		}
	}

	public void TurnOnAllColorsBright()
	{
		//IL_0061: Unknown result type (might be due to invalid IL or missing references)
		for (int i = 0; i < pieces.Length; i++)
		{
			if (!((Renderer)((Component)pieces[i]).GetComponent<MeshRenderer>()).material.IsKeywordEnabled("_EMISSION"))
			{
				((Renderer)((Component)pieces[i]).GetComponent<MeshRenderer>()).material.EnableKeyword("_EMISSION");
			}
			((Renderer)((Component)pieces[i]).GetComponent<MeshRenderer>()).material.SetColor("_EmissionColor", enemySpinny.colors[i]);
		}
	}

	private void TurnOnAllColors()
	{
		//IL_0061: Unknown result type (might be due to invalid IL or missing references)
		//IL_006b: Unknown result type (might be due to invalid IL or missing references)
		for (int i = 0; i < pieces.Length; i++)
		{
			if (!((Renderer)((Component)pieces[i]).GetComponent<MeshRenderer>()).material.IsKeywordEnabled("_EMISSION"))
			{
				((Renderer)((Component)pieces[i]).GetComponent<MeshRenderer>()).material.EnableKeyword("_EMISSION");
			}
			((Renderer)((Component)pieces[i]).GetComponent<MeshRenderer>()).material.SetColor("_EmissionColor", enemySpinny.colors[i] * 0.2f);
		}
	}

	private void TurnPiecesColor(Color _color)
	{
		//IL_004b: Unknown result type (might be due to invalid IL or missing references)
		Transform[] array = pieces;
		foreach (Transform val in array)
		{
			if (!((Renderer)((Component)val).GetComponent<MeshRenderer>()).material.IsKeywordEnabled("_EMISSION"))
			{
				((Renderer)((Component)val).GetComponent<MeshRenderer>()).material.EnableKeyword("_EMISSION");
			}
			((Renderer)((Component)val).GetComponent<MeshRenderer>()).material.SetColor("_EmissionColor", _color);
		}
	}

	private void TurnLightColor(Color _color)
	{
		//IL_0006: Unknown result type (might be due to invalid IL or missing references)
		pointLight.color = _color;
		((Behaviour)pointLight).enabled = true;
	}

	private float GetSmallestPositiveDelta(float fromAngle, float toAngle)
	{
		float num = Mathf.DeltaAngle(fromAngle, toAngle);
		if (num < 0f)
		{
			num += 360f;
		}
		return num;
	}

	public void PlayDeathParticles()
	{
		ParticleSystem[] array = deathParticles;
		for (int i = 0; i < array.Length; i++)
		{
			((Component)array[i]).gameObject.SetActive(true);
		}
	}
}
