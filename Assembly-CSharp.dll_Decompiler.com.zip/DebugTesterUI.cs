using System.Collections.Generic;
using System.Linq;
using Platforms;
using UnityEngine;

public class DebugTesterUI : MonoBehaviour
{
	public static DebugTesterUI instance;

	private string text;

	private string moduleName;

	internal bool Active;

	[RuntimeInitializeOnLoadMethod(/*Could not decode attribute arguments.*/)]
	private static void RuntimeInitializeOnLoad()
	{
		instance = null;
	}

	private void Awake()
	{
		instance = this;
	}

	private void Start()
	{
		if (!Debug.isDebugBuild && !PlatformManager.instance.developerFlags.debug_console && !PlatformManager.instance.developerFlags.debug_overlay)
		{
			Object.Destroy((Object)(object)((Component)this).gameObject);
		}
	}

	private void OnGUI()
	{
		//IL_022c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0231: Unknown result type (might be due to invalid IL or missing references)
		//IL_0239: Unknown result type (might be due to invalid IL or missing references)
		//IL_0240: Unknown result type (might be due to invalid IL or missing references)
		//IL_0247: Unknown result type (might be due to invalid IL or missing references)
		//IL_024e: Unknown result type (might be due to invalid IL or missing references)
		//IL_024f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0254: Unknown result type (might be due to invalid IL or missing references)
		//IL_0255: Unknown result type (might be due to invalid IL or missing references)
		//IL_0264: Expected Obj, but got Unknown
		//IL_0265: Expected Obj, but got Unknown
		//IL_0266: Unknown result type (might be due to invalid IL or missing references)
		//IL_026b: Unknown result type (might be due to invalid IL or missing references)
		//IL_026c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0271: Unknown result type (might be due to invalid IL or missing references)
		//IL_0272: Unknown result type (might be due to invalid IL or missing references)
		//IL_0281: Expected Obj, but got Unknown
		//IL_0282: Expected Obj, but got Unknown
		//IL_0284: Unknown result type (might be due to invalid IL or missing references)
		//IL_0292: Expected Obj, but got Unknown
		//IL_02a5: Unknown result type (might be due to invalid IL or missing references)
		//IL_02b1: Expected Obj, but got Unknown
		//IL_02ce: Unknown result type (might be due to invalid IL or missing references)
		//IL_02fb: Unknown result type (might be due to invalid IL or missing references)
		//IL_0307: Unknown result type (might be due to invalid IL or missing references)
		Active = !Object.op_Implicit((Object)(object)DebugCommandHandler.instance) || DebugCommandHandler.instance.debugOverlay;
		if (Active && Object.op_Implicit((Object)(object)RecordingDirector.instance) && (PlatformManager.instance.developerFlags.debug_console || PlatformManager.instance.developerFlags.debug_overlay))
		{
			Active = false;
		}
		if (!Active)
		{
			return;
		}
		if (string.IsNullOrEmpty(this.text))
		{
			if (!Object.op_Implicit((Object)(object)BuildManager.instance) || !PlatformManager.instance.IsInitialised())
			{
				return;
			}
			this.text = BuildManager.instance.version.title + "\n" + PlatformManager.instance.GetUsername() + " (" + PlatformManager.instance.GetPlatformUserId() + ")";
		}
		string text = this.text;
		string text2 = SemiFunc.NetworkTrafficStatsTextGet();
		if (!string.IsNullOrEmpty(text2))
		{
			text = text2 + "\n" + text;
		}
		if (!SemiFunc.MenuLevel() && !SemiFunc.RunIsLobby() && !SemiFunc.RunIsTutorial())
		{
			string text3;
			if (SemiFunc.IsMultiplayer())
			{
				text3 = (SemiFunc.IsMasterClient() ? "Multiplayer (MC)" : "Multiplayer (CL)");
			}
			else
			{
				text3 = "Singleplayer";
			}
			text = text3 + "\n" + text;
			List<RoomVolume> currentRooms = PlayerAvatar.instance?.RoomVolumeCheck.CurrentRooms.Where((RoomVolume r) => Object.op_Implicit((Object)(object)r.Module)).ToList();
			List<RoomVolume> list = currentRooms;
			if (list != null && list.Any())
			{
				if (currentRooms.All((RoomVolume r) => (Object)(object)r.MapModule == (Object)(object)currentRooms[0].MapModule))
				{
					moduleName = ((Object)currentRooms[0].Module).name.Replace("(Clone)", "");
				}
				if (moduleName != null)
				{
					text = moduleName + "\n" + text;
				}
			}
			else
			{
				moduleName = null;
			}
		}
		else
		{
			moduleName = null;
		}
		GUIStyle val = new GUIStyle(GUI.skin.label)
		{
			fontSize = 13,
			fontStyle = (FontStyle)1,
			alignment = (TextAnchor)8,
			wordWrap = false,
			normal = new GUIStyleState
			{
				textColor = Color.white
			}
		};
		GUIStyle val2 = new GUIStyle(val)
		{
			normal = new GUIStyleState
			{
				textColor = Color.black
			}
		};
		float num = default;
		float num2 = default;
		val.CalcMinMaxWidth(new GUIContent(text), ref num, ref num2);
		float num3 = (float)Screen.width - num - 4f;
		float num4 = val.CalcHeight(new GUIContent(text), num);
		float num5 = (float)Screen.height - num4 - 20f;
		Rect val3 = new Rect(num3, num5, num, num4);
		GUI.Label(new Rect(val3.x + 1f, val3.y + 1f, val3.width, val3.height), text, val2);
		GUI.Label(val3, text, val);
	}
}
