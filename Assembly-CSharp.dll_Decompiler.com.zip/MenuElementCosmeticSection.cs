using System.Collections.Generic;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

public class MenuElementCosmeticSection : MonoBehaviour
{
	internal MenuPageCosmetics menuPageCosmetics;

	public TextMeshProUGUI headerText;

	internal CanvasGroup headerCanvasGroup;

	private SemiUI headerSemiUI;

	public Transform cosmeticListTransform;

	internal SemiFunc.CosmeticType subCategory;

	public MenuButton colorButton;

	public Image colorButtonIcon;

	private SemiUI colorButtonSemiUI;

	private bool colorButtonHovered;

	public MenuElementCosmeticButton unequipButton;

	internal List<int> cosmeticIndexes = new List<int>();

	internal MenuElementCosmeticHighlight highlightObj;

	private float nextShakeAllowedTime;

	private const float stickyShakeCooldown = 0.25f;

	public bool isStickyHeader;

	public RectTransform viewport;

	public RectTransform stickyRoot;

	internal int stickyCurrentIndex = -1;

	private RectMask2D viewPortRectMask;

	private string cachedHeaderText;

	private void Awake()
	{
		menuPageCosmetics = ((Component)this).GetComponentInParent<MenuPageCosmetics>();
		highlightObj = ((Component)this).GetComponentInChildren<MenuElementCosmeticHighlight>();
		headerCanvasGroup = ((Component)((TMP_Text)headerText).transform.parent).GetComponent<CanvasGroup>();
		headerSemiUI = ((Component)((TMP_Text)headerText).transform.parent.parent).GetComponent<SemiUI>();
		colorButtonSemiUI = ((Component)colorButton).GetComponentInChildren<SemiUI>();
		if (Object.op_Implicit((Object)(object)viewport))
		{
			viewPortRectMask = ((Component)viewport).GetComponent<RectMask2D>();
		}
		if (menuPageCosmetics.selectedTab != MenuPageCosmetics.CosmeticPageTab.Cosmetics)
		{
			((Component)unequipButton).gameObject.SetActive(false);
		}
	}

	private void Start()
	{
		UpdateColorButton(null, _initial: true);
		for (int i = 0; i < MetaManager.instance.cosmeticAssets.Count; i++)
		{
			CosmeticAsset cosmeticAsset = MetaManager.instance.cosmeticAssets[i];
			if (Object.op_Implicit((Object)(object)cosmeticAsset) && cosmeticAsset.type == subCategory && cosmeticAsset.prefab.IsValid())
			{
				cosmeticIndexes.Add(i);
			}
		}
		UpdateHighlight();
	}

	private void Update()
	{
		if (colorButtonHovered != colorButton.hovering)
		{
			colorButtonHovered = colorButton.hovering;
			if (colorButtonHovered)
			{
				colorButtonSemiUI.SemiUISpringShakeY(5f, 2f, 0.25f);
			}
		}
	}

	private void LateUpdate()
	{
		if (isStickyHeader && menuPageCosmetics.subCategoriesReady)
		{
			RefreshImmediate();
		}
	}

	public void UpdateColorButton(CosmeticAsset _cosmeticAsset, bool _initial = false)
	{
		//IL_013b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0134: Unknown result type (might be due to invalid IL or missing references)
		//IL_0140: Unknown result type (might be due to invalid IL or missing references)
		//IL_0147: Unknown result type (might be due to invalid IL or missing references)
		//IL_01c9: Unknown result type (might be due to invalid IL or missing references)
		if (menuPageCosmetics.selectedTab != MenuPageCosmetics.CosmeticPageTab.Cosmetics)
		{
			((Component)colorButton).gameObject.SetActive(false);
			return;
		}
		if (!((Component)colorButton).gameObject.activeSelf)
		{
			((Component)colorButton).gameObject.SetActive(true);
		}
		bool flag = false;
		if (Object.op_Implicit((Object)(object)_cosmeticAsset))
		{
			flag = _cosmeticAsset.tintable;
		}
		else if (Object.op_Implicit((Object)(object)menuPageCosmetics.menuPage) && Object.op_Implicit((Object)(object)menuPageCosmetics.menuPage.playerAvatarMenu))
		{
			foreach (PlayerMaterial playerMaterial in menuPageCosmetics.menuPage.playerAvatarMenu.playerCosmetics.playerMaterials)
			{
				if (Object.op_Implicit((Object)(object)playerMaterial) && playerMaterial.cosmeticType == subCategory && (playerMaterial.tintable || (Object.op_Implicit((Object)(object)playerMaterial.cosmetic) && Object.op_Implicit((Object)(object)playerMaterial.cosmetic.cosmeticAsset) && playerMaterial.cosmetic.cosmeticAsset.tintable)))
				{
					flag = true;
					break;
				}
			}
		}
		Color color = (Color)(flag ? Color.white : new Color(0.2f, 0.2f, 0.2f, 1f));
		((Graphic)colorButtonIcon).color = color;
		if (colorButton.disabled != !flag && !_initial)
		{
			if (flag)
			{
				colorButtonSemiUI.SemiUISpringScale(0.3f, 1f, 0.25f);
			}
			else
			{
				colorButtonSemiUI.SemiUISpringScale(-0.3f, 1f, 0.25f);
			}
		}
		ColorButtonStateSet(colorButton, flag);
		if (menuPageCosmetics.selectedSubCategory == subCategory)
		{
			((Graphic)menuPageCosmetics.stickyHeader.colorButtonIcon).color = color;
			ColorButtonStateSet(menuPageCosmetics.stickyHeader.colorButton, flag);
		}
	}

	private static void ColorButtonStateSet(MenuButton _button, bool _state)
	{
		_button.disabled = !_state;
		if (Object.op_Implicit((Object)(object)_button.menuSelectableElement))
		{
			((Selectable)_button.menuSelectableElement).interactable = _state;
		}
	}

	public void ChangeColorButton()
	{
		colorButtonSemiUI.SemiUISpringScale(-0.3f, 1f, 0.25f);
		((Component)MenuManager.instance.PageOpenOnTop(MenuPageIndex.Color)).GetComponent<MenuPageColor>().colorKey = (int)subCategory;
		menuPageCosmetics.HideAvatarControls(_state: true);
	}

	internal void UpdateHighlight()
	{
		if (!Object.op_Implicit((Object)(object)highlightObj))
		{
			return;
		}
		int num = 0;
		for (int i = 0; i < MetaManager.instance.cosmeticAssets.Count; i++)
		{
			if (!MetaManager.instance.cosmeticHistory.Contains(i) && MetaManager.instance.cosmeticUnlocks.Contains(i))
			{
				CosmeticAsset cosmeticAsset = MetaManager.instance.cosmeticAssets[i];
				if (Object.op_Implicit((Object)(object)cosmeticAsset) && cosmeticAsset.type == subCategory && cosmeticAsset.prefab.IsValid())
				{
					num++;
				}
			}
		}
		((TMP_Text)highlightObj.text).text = num.ToString();
		if (menuPageCosmetics.selectedSubCategory == subCategory)
		{
			((TMP_Text)menuPageCosmetics.stickyHeader.highlightObj.text).text = ((TMP_Text)highlightObj.text).text;
		}
	}

	public void SetSections()
	{
		stickyCurrentIndex = -1;
		RefreshImmediate();
	}

	private void RefreshImmediate()
	{
		//IL_004f: Unknown result type (might be due to invalid IL or missing references)
		//IL_007a: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d9: Unknown result type (might be due to invalid IL or missing references)
		//IL_0175: Unknown result type (might be due to invalid IL or missing references)
		//IL_0104: Unknown result type (might be due to invalid IL or missing references)
		//IL_01a0: Unknown result type (might be due to invalid IL or missing references)
		//IL_025e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0263: Unknown result type (might be due to invalid IL or missing references)
		//IL_0287: Unknown result type (might be due to invalid IL or missing references)
		//IL_028c: Unknown result type (might be due to invalid IL or missing references)
		//IL_03ab: Unknown result type (might be due to invalid IL or missing references)
		//IL_03b0: Unknown result type (might be due to invalid IL or missing references)
		//IL_03c1: Unknown result type (might be due to invalid IL or missing references)
		//IL_03e6: Unknown result type (might be due to invalid IL or missing references)
		//IL_0470: Unknown result type (might be due to invalid IL or missing references)
		//IL_0480: Unknown result type (might be due to invalid IL or missing references)
		//IL_0485: Unknown result type (might be due to invalid IL or missing references)
		//IL_0489: Unknown result type (might be due to invalid IL or missing references)
		//IL_04a5: Unknown result type (might be due to invalid IL or missing references)
		//IL_04af: Unknown result type (might be due to invalid IL or missing references)
		if (!Object.op_Implicit((Object)(object)viewPortRectMask) || !Object.op_Implicit((Object)(object)stickyRoot) || !Object.op_Implicit((Object)(object)headerText) || menuPageCosmetics.sections.Count == 0)
		{
			if (Object.op_Implicit((Object)(object)viewPortRectMask) && viewPortRectMask.padding.w != 0f)
			{
				viewPortRectMask.padding = new Vector4(0f, 0f, 0f, 0f);
			}
			if (Object.op_Implicit((Object)(object)stickyRoot) && ((Component)stickyRoot).gameObject.activeSelf)
			{
				((Component)stickyRoot).gameObject.SetActive(false);
			}
			stickyCurrentIndex = -1;
			menuPageCosmetics.scrollGradientTopHidden = true;
			return;
		}
		int num = FindCurrentSectionIndex();
		if (num < 0)
		{
			if (viewPortRectMask.padding.w != 0f)
			{
				viewPortRectMask.padding = new Vector4(0f, 0f, 0f, 0f);
			}
			if (((Component)stickyRoot).gameObject.activeSelf)
			{
				((Component)stickyRoot).gameObject.SetActive(false);
			}
			stickyCurrentIndex = -1;
			menuPageCosmetics.scrollGradientTopHidden = true;
			return;
		}
		MenuElementCosmeticSection menuElementCosmeticSection = menuPageCosmetics.sections[num];
		if (!Object.op_Implicit((Object)(object)menuElementCosmeticSection) || !Object.op_Implicit((Object)(object)menuElementCosmeticSection.headerText))
		{
			if (viewPortRectMask.padding.w != 0f)
			{
				viewPortRectMask.padding = new Vector4(0f, 0f, 0f, 0f);
			}
			if (((Component)stickyRoot).gameObject.activeSelf)
			{
				((Component)stickyRoot).gameObject.SetActive(false);
			}
			if (menuPageCosmetics.selectedTab == MenuPageCosmetics.CosmeticPageTab.Presets)
			{
				menuPageCosmetics.scrollGradientTopHidden = menuPageCosmetics.menuScrollBox.scrollAmount >= 0.999f;
			}
			else
			{
				menuPageCosmetics.scrollGradientTopHidden = true;
			}
			return;
		}
		int num2 = stickyCurrentIndex;
		if (num != stickyCurrentIndex)
		{
			menuPageCosmetics.SetCurrentSubCategory(menuPageCosmetics.sections[num].subCategory, _scrollPage: false, num2 == -1, num2 != -1);
		}
		else
		{
			menuPageCosmetics.TryShowCurrentSubCategoryButton();
		}
		Rect rect = viewport.rect;
		Vector3[] array = new Vector3[4];
		((TMP_Text)menuElementCosmeticSection.headerText).rectTransform.GetWorldCorners(array);
		if (((Transform)viewport).InverseTransformPoint(array[1]).y <= rect.yMax)
		{
			if (((Component)stickyRoot).gameObject.activeSelf)
			{
				((Component)stickyRoot).gameObject.SetActive(false);
			}
		}
		else if (!((Component)stickyRoot).gameObject.activeSelf)
		{
			((Component)stickyRoot).gameObject.SetActive(true);
		}
		menuPageCosmetics.scrollGradientTopHidden = !((Component)stickyRoot).gameObject.activeSelf;
		foreach (MenuElementCosmeticSection section in menuPageCosmetics.sections)
		{
			if (Object.op_Implicit((Object)(object)section) && Object.op_Implicit((Object)(object)section.headerText))
			{
				section.headerCanvasGroup.alpha = 1f;
			}
		}
		menuElementCosmeticSection.headerCanvasGroup.alpha = (((Component)stickyRoot).gameObject.activeSelf ? 0f : 1f);
		float num3;
		if (!((Component)stickyRoot).gameObject.activeSelf)
		{
			num3 = 0f;
		}
		else
		{
			Rect rect2 = stickyRoot.rect;
			num3 = rect2.height;
		}
		float num4 = num3;
		if (viewPortRectMask.padding.w != num4)
		{
			viewPortRectMask.padding = new Vector4(0f, 0f, 0f, num4);
		}
		if (Object.op_Implicit((Object)(object)menuPageCosmetics.menuScrollBox))
		{
			menuPageCosmetics.menuScrollBox.topInset = num4;
		}
		if (Object.op_Implicit((Object)(object)highlightObj))
		{
			if (((TMP_Text)headerText).text != cachedHeaderText)
			{
				cachedHeaderText = ((TMP_Text)headerText).text;
				((TMP_Text)headerText).ForceMeshUpdate(false, false);
			}
			RectTransform rectTransform = highlightObj.rectTransform;
			float x = ((TMP_Text)headerText).rectTransform.anchoredPosition.x;
			Bounds textBounds = ((TMP_Text)headerText).textBounds;
			rectTransform.anchoredPosition = new Vector2(x + textBounds.max.x + 15f, highlightObj.rectTransform.anchoredPosition.y);
		}
		if (num2 != stickyCurrentIndex && (num2 != -1 || stickyCurrentIndex != 0) && Time.unscaledTime >= nextShakeAllowedTime)
		{
			nextShakeAllowedTime = Time.unscaledTime + 0.25f;
			headerSemiUI.SemiUISpringShakeY(5f, 2f, 0.25f);
			menuElementCosmeticSection.headerSemiUI.SemiUISpringShakeY(5f, 2f, 0.25f);
		}
	}

	private int FindCurrentSectionIndex()
	{
		//IL_0006: Unknown result type (might be due to invalid IL or missing references)
		//IL_000b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0078: Unknown result type (might be due to invalid IL or missing references)
		//IL_007d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0082: Unknown result type (might be due to invalid IL or missing references)
		Rect rect = viewport.rect;
		int num = -1;
		float num2 = float.NegativeInfinity;
		for (int i = 0; i < menuPageCosmetics.sections.Count; i++)
		{
			MenuElementCosmeticSection menuElementCosmeticSection = menuPageCosmetics.sections[i];
			if (!Object.op_Implicit((Object)(object)menuElementCosmeticSection))
			{
				continue;
			}
			Transform transform = ((Component)menuElementCosmeticSection).transform;
			RectTransform val = (RectTransform)(object)((transform is RectTransform) ? transform : null);
			if (Object.op_Implicit((Object)(object)val))
			{
				Vector3[] array = new Vector3[4];
				val.GetWorldCorners(array);
				for (int j = 0; j < 4; j++)
				{
					array[j] = ((Transform)viewport).InverseTransformPoint(array[j]);
				}
				float y = array[0].y;
				float y2 = array[1].y;
				if (y2 >= rect.yMin && y <= rect.yMax && y2 > num2)
				{
					num2 = y2;
					num = i;
				}
			}
		}
		if (num == -1)
		{
			num = 0;
		}
		return num;
	}
}
