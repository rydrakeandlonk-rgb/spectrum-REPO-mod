using UnityEngine;
using UnityEngine.SceneManagement;

public class AudioListenerFollow : MonoBehaviour
{
	public static AudioListenerFollow instance;

	public Transform TargetPositionTransform;

	public Transform TargetRotationTransform;

	internal LowPassTrigger lowPassTrigger;

	[RuntimeInitializeOnLoadMethod(/*Could not decode attribute arguments.*/)]
	private static void RuntimeInitializeOnLoad()
	{
		instance = null;
	}

	private void Awake()
	{
		instance = this;
		ReloadScene.ListenerHandoffIncoming(((Component)this).GetComponent<AudioListener>(), this);
	}

	private void Start()
	{
		TargetCameraTrySet();
	}

	private void TargetCameraTrySet()
	{
		//IL_002f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0034: Unknown result type (might be due to invalid IL or missing references)
		//IL_0037: Unknown result type (might be due to invalid IL or missing references)
		//IL_0042: Unknown result type (might be due to invalid IL or missing references)
		//IL_0047: Unknown result type (might be due to invalid IL or missing references)
		//IL_004a: Unknown result type (might be due to invalid IL or missing references)
		if (Object.op_Implicit((Object)(object)TargetPositionTransform) && Object.op_Implicit((Object)(object)TargetRotationTransform))
		{
			return;
		}
		Camera main = Camera.main;
		if (Object.op_Implicit((Object)(object)main))
		{
			Scene scene = ((Component)main).gameObject.scene;
			SceneHandle handle = scene.handle;
			scene = ((Component)this).gameObject.scene;
			if (handle == scene.handle)
			{
				HandoffPoseSet(main);
			}
		}
	}

	internal void HandoffPoseSet(Camera _camera)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002f: Unknown result type (might be due to invalid IL or missing references)
		//IL_003a: Unknown result type (might be due to invalid IL or missing references)
		//IL_003f: Unknown result type (might be due to invalid IL or missing references)
		//IL_004a: Unknown result type (might be due to invalid IL or missing references)
		TargetPositionTransform = ((Component)_camera).transform;
		TargetRotationTransform = ((Component)_camera).transform;
		((Component)this).transform.SetPositionAndRotation(((Component)_camera).transform.position + ((Component)_camera).transform.forward * _camera.nearClipPlane, ((Component)_camera).transform.rotation);
	}

	private void Update()
	{
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b9: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c4: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ca: Unknown result type (might be due to invalid IL or missing references)
		//IL_00cf: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f3: Unknown result type (might be due to invalid IL or missing references)
		//IL_0117: Unknown result type (might be due to invalid IL or missing references)
		if (!Object.op_Implicit((Object)(object)TargetPositionTransform) || !Object.op_Implicit((Object)(object)TargetRotationTransform))
		{
			if (SemiFunc.PerSecond(10f, (Object)(object)this))
			{
				TargetCameraTrySet();
			}
			if (!Object.op_Implicit((Object)(object)TargetPositionTransform) || !Object.op_Implicit((Object)(object)TargetRotationTransform))
			{
				return;
			}
		}
		if (Object.op_Implicit((Object)(object)SpectateCamera.instance) && SpectateCamera.instance.CheckState(SpectateCamera.State.Death))
		{
			((Component)this).transform.position = TargetPositionTransform.position;
		}
		else
		{
			float num = ((Object.op_Implicit((Object)(object)AssetManager.instance) && Object.op_Implicit((Object)(object)AssetManager.instance.mainCamera)) ? AssetManager.instance.mainCamera.nearClipPlane : 0f);
			((Component)this).transform.position = TargetPositionTransform.position + TargetPositionTransform.forward * num;
		}
		if (!Object.op_Implicit((Object)(object)TargetRotationTransform))
		{
			return;
		}
		((Component)this).transform.rotation = TargetRotationTransform.rotation;
		if (!SemiFunc.PerSecond(15f, (Object)(object)this))
		{
			return;
		}
		lowPassTrigger = null;
		Collider[] array = Physics.OverlapSphere(((Component)this).transform.position, 0.1f, LayerMask.GetMask(new string[1] { "LowPassTrigger" }), (QueryTriggerInteraction)2);
		if (array.Length != 0)
		{
			lowPassTrigger = ((Component)array[0]).GetComponent<LowPassTrigger>();
			if (!Object.op_Implicit((Object)(object)lowPassTrigger))
			{
				lowPassTrigger = ((Component)array[0]).GetComponentInParent<LowPassTrigger>();
			}
		}
	}
}
