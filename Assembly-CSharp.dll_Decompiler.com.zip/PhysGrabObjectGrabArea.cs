using System;
using System.Collections.Generic;
using System.Linq;
using Photon.Pun;
using UnityEngine;
using UnityEngine.Events;

public class PhysGrabObjectGrabArea : MonoBehaviour
{
	[Serializable]
	public class GrabArea
	{
		public Transform grabAreaTransform;

		[Space(20f)]
		public UnityEvent grabAreaEventOnStart = new UnityEvent();

		public UnityEvent grabAreaEventOnRelease = new UnityEvent();

		public UnityEvent grabAreaEventOnHolding = new UnityEvent();

		internal bool grabAreaActive;

		internal List<PhysGrabber> listOfGrabbers = new List<PhysGrabber>();

		internal List<Collider> grabAreaColliders = new List<Collider>();

		public GrabArea()
		{
			//IL_0001: Unknown result type (might be due to invalid IL or missing references)
			//IL_000b: Expected Obj, but got Unknown
			//IL_000c: Unknown result type (might be due to invalid IL or missing references)
			//IL_0016: Expected Obj, but got Unknown
			//IL_0017: Unknown result type (might be due to invalid IL or missing references)
			//IL_0021: Expected Obj, but got Unknown
		}
	}

	private PhysGrabObject physGrabObject;

	private StaticGrabObject staticGrabObject;

	private PhotonView photonView;

	[HideInInspector]
	public List<PhysGrabber> listOfAllGrabbers = new List<PhysGrabber>();

	public List<GrabArea> grabAreas = new List<GrabArea>();

	private void Start()
	{
		physGrabObject = ((Component)this).GetComponentInParent<PhysGrabObject>();
		staticGrabObject = ((Component)this).GetComponentInParent<StaticGrabObject>();
		photonView = ((Component)this).GetComponentInParent<PhotonView>();
		foreach (GrabArea grabArea in grabAreas)
		{
			if (!Object.op_Implicit((Object)(object)grabArea.grabAreaTransform))
			{
				continue;
			}
			if (grabArea.grabAreaTransform.childCount == 0)
			{
				Collider component = ((Component)grabArea.grabAreaTransform).GetComponent<Collider>();
				if ((Object)(object)component != (Object)null)
				{
					grabArea.grabAreaColliders.Add(component);
				}
				else
				{
					Debug.LogWarning((object)("Grab area '" + ((Object)grabArea.grabAreaTransform).name + "' is missing a Collider component."));
				}
			}
			else
			{
				Collider[] componentsInChildren = ((Component)grabArea.grabAreaTransform).GetComponentsInChildren<Collider>();
				if (componentsInChildren.Length != 0)
				{
					grabArea.grabAreaColliders.AddRange(componentsInChildren);
				}
				else
				{
					Debug.LogWarning((object)("Grab area '" + ((Object)grabArea.grabAreaTransform).name + "' has children but no colliders."));
				}
			}
		}
	}

	public PlayerAvatar GetLatestGrabber()
	{
		if (listOfAllGrabbers.Count > 0)
		{
			return listOfAllGrabbers[listOfAllGrabbers.Count - 1].playerAvatar;
		}
		return null;
	}

	private void Update()
	{
		//IL_011f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0124: Unknown result type (might be due to invalid IL or missing references)
		//IL_016b: Unknown result type (might be due to invalid IL or missing references)
		//IL_016d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0172: Unknown result type (might be due to invalid IL or missing references)
		if (!SemiFunc.IsMasterClientOrSingleplayer())
		{
			return;
		}
		foreach (GrabArea grabArea in grabAreas)
		{
			for (int num = grabArea.listOfGrabbers.Count - 1; num >= 0; num--)
			{
				PhysGrabber physGrabber = grabArea.listOfGrabbers[num];
				if (!Object.op_Implicit((Object)(object)physGrabber) || !physGrabber.grabbed || (Object.op_Implicit((Object)(object)physGrabber.grabbedPhysGrabObject) && (Object)(object)physGrabber.grabbedPhysGrabObject != (Object)(object)physGrabObject) || (Object.op_Implicit((Object)(object)physGrabber.grabbedStaticGrabObject) && (Object)(object)physGrabber.grabbedStaticGrabObject != (Object)(object)staticGrabObject))
				{
					UpdateList(add: false, physGrabber);
					listOfAllGrabbers.Remove(physGrabber);
					grabArea.listOfGrabbers.RemoveAt(num);
				}
			}
		}
		foreach (PhysGrabber item in (Object.op_Implicit((Object)(object)physGrabObject) ? physGrabObject.playerGrabbing : staticGrabObject.playerGrabbing).ToList())
		{
			Vector3 position = item.physGrabPoint.position;
			foreach (GrabArea grabArea2 in grabAreas)
			{
				if (grabArea2.grabAreaColliders.Count == 0)
				{
					continue;
				}
				bool flag = false;
				foreach (Collider grabAreaCollider in grabArea2.grabAreaColliders)
				{
					if (grabAreaCollider.ClosestPoint(position) == position)
					{
						flag = true;
						break;
					}
				}
				if (!flag)
				{
					continue;
				}
				if (!grabArea2.listOfGrabbers.Contains(item))
				{
					if (item.initialPressTimer <= 0f)
					{
						continue;
					}
					grabArea2.listOfGrabbers.Add(item);
					if (!listOfAllGrabbers.Contains(item))
					{
						listOfAllGrabbers.Add(item);
						UpdateList(add: true, item);
					}
					UnityEvent grabAreaEventOnStart = grabArea2.grabAreaEventOnStart;
					if (grabAreaEventOnStart != null)
					{
						grabAreaEventOnStart.Invoke();
					}
				}
				else
				{
					UnityEvent grabAreaEventOnHolding = grabArea2.grabAreaEventOnHolding;
					if (grabAreaEventOnHolding != null)
					{
						grabAreaEventOnHolding.Invoke();
					}
				}
				grabArea2.grabAreaActive = true;
				break;
			}
		}
		foreach (GrabArea grabArea3 in grabAreas)
		{
			if (grabArea3.listOfGrabbers.Count == 0 && grabArea3.grabAreaActive)
			{
				UnityEvent grabAreaEventOnRelease = grabArea3.grabAreaEventOnRelease;
				if (grabAreaEventOnRelease != null)
				{
					grabAreaEventOnRelease.Invoke();
				}
				grabArea3.grabAreaActive = false;
			}
		}
	}

	[PunRPC]
	public void AddToGrabbersList(int grabberId, PhotonMessageInfo _info = default(PhotonMessageInfo))
	{
		//IL_0000: Unknown result type (might be due to invalid IL or missing references)
		if (SemiFunc.MasterOnlyRPC(_info))
		{
			PhysGrabber physGrabber = FindGrabberById(grabberId);
			if ((Object)(object)physGrabber != (Object)null && !listOfAllGrabbers.Contains(physGrabber))
			{
				listOfAllGrabbers.Add(physGrabber);
			}
		}
	}

	[PunRPC]
	public void RemoveFromGrabbersList(int grabberId, PhotonMessageInfo _info = default(PhotonMessageInfo))
	{
		//IL_0000: Unknown result type (might be due to invalid IL or missing references)
		if (SemiFunc.MasterOnlyRPC(_info))
		{
			PhysGrabber physGrabber = FindGrabberById(grabberId);
			if ((Object)(object)physGrabber != (Object)null)
			{
				listOfAllGrabbers.Remove(physGrabber);
			}
		}
	}

	private PhysGrabber FindGrabberById(int id)
	{
		foreach (PlayerAvatar item in SemiFunc.PlayerGetList())
		{
			PhysGrabber componentInChildren = ((Component)item).GetComponentInChildren<PhysGrabber>();
			if ((Object)(object)componentInChildren != (Object)null && componentInChildren.photonView.ViewID == id)
			{
				return componentInChildren;
			}
		}
		return null;
	}

	private void UpdateList(bool add, PhysGrabber grabber)
	{
		if (SemiFunc.IsMultiplayer() && !((Object)(object)grabber == (Object)null))
		{
			int viewID = grabber.photonView.ViewID;
			if (add)
			{
				photonView.RPC("AddToGrabbersList", (RpcTarget)1, new object[1] { viewID });
			}
			else
			{
				photonView.RPC("RemoveFromGrabbersList", (RpcTarget)1, new object[1] { viewID });
			}
		}
	}
}
