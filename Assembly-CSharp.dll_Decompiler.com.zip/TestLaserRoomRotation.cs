using UnityEngine;

public class TestLaserRoomRotation : MonoBehaviour
{
	public float rotationDirection = 1f;

	private float rotationSpeed = 15f;

	private void Start()
	{
	}

	private void Update()
	{
		((Component)this).transform.Rotate(0f, rotationSpeed * rotationDirection * Time.deltaTime, 0f);
	}
}
