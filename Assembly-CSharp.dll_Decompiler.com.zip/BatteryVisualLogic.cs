using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class BatteryVisualLogic : MonoBehaviour
{
	public HorizontalLayoutGroup batteryBarContainerGroup;

	public GameObject batteryBarPrefab;

	public int batteryBars = 3;

	public Transform batteryBarContainer;

	public bool inUI;

	public bool cameraTurn = true;

	public Transform batteryBarCharge;

	public Transform batteryBarDrain;

	internal List<GameObject> bars = new List<GameObject>();

	internal float batteryPercent = 100f;

	internal int currentBars = 3;

	public ItemBattery itemBattery;

	private ItemBattery itemBatteryPrev;

	public RawImage batteryBorderShadow;

	public RawImage batteryBorderMain;

	public RawImage batteryBackground;

	public RawImage batteryCharge;

	public RawImage batteryDrain;

	public GameObject batteryOutVisual;

	public GameObject batteryChargeNeededVisual;

	private float batteryDrainFullXScale = 0.93f;

	private float batteryChargeFullXScale = 1f;

	private Color batteryColorMain = new Color(1f, 1f, 0f, 1f);

	private Color batteryColorBackground = new Color(0.1f, 0.1f, 0.1f, 1f);

	private Color batteryColorShadow = new Color(0.1f, 0.1f, 0.1f, 0.5f);

	private Color batteryColorWarning = new Color(1f, 0f, 0f, 1f);

	private Color batteryColorCharge = new Color(0f, 1f, 0f, 1f);

	private Color batteryColorDrain = new Color(1f, 0.2f, 0f, 1f);

	private SpringFloat springScale = new SpringFloat();

	private SpringFloat springRotation = new SpringFloat();

	private SpringVector3 springPosition = new SpringVector3();

	public GameObject barLossEffectPrefab;

	internal float targetScale = 1f;

	private float targetRotation;

	private Vector3 targetPosition = Vector3.zero;

	private float targetScaleOriginal = 1f;

	private float targetRotationOriginal;

	private Vector3 targetPositionOriginal = Vector3.zero;

	private float overrideTimerBatteryOutWarning;

	private bool batteryIsOutWarning;

	private float overrideTimerBatteryDrain;

	private bool batteryIsDraining;

	private float overrideTimerBatteryCharge;

	private bool batteryIsCharging;

	private float overrideTimerChargeNeeded;

	private bool batteryChargeNeeded;

	private bool batteryChargeNeededFlash = true;

	private float smallDeductionFlashTimer;

	private bool smallDeductionFlashing;

	private float chargeAnimationProgress;

	private float drainAnimationProgress;

	private float warningAnimationProgress;

	private float chargeNeededAnimationProgress;

	internal bool doOutro;

	private void Awake()
	{
		//IL_0007: Unknown result type (might be due to invalid IL or missing references)
		//IL_000c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0018: Unknown result type (might be due to invalid IL or missing references)
		//IL_0041: Unknown result type (might be due to invalid IL or missing references)
		//IL_0046: Unknown result type (might be due to invalid IL or missing references)
		targetPosition = ((Component)this).transform.localPosition;
		targetScale = ((Component)this).transform.localScale.x;
		targetScaleOriginal = targetScale;
		targetRotationOriginal = targetRotation;
		targetPositionOriginal = targetPosition;
	}

	public void HideForCameras()
	{
		if (!inUI)
		{
			((Component)this).gameObject.layer = LayerMask.NameToLayer("Ignore Raycast");
			Transform[] componentsInChildren = ((Component)this).GetComponentsInChildren<Transform>(true);
			for (int i = 0; i < componentsInChildren.Length; i++)
			{
				((Component)componentsInChildren[i]).gameObject.layer = LayerMask.NameToLayer("Ignore Raycast");
			}
		}
	}

	private void Start()
	{
		//IL_0088: Unknown result type (might be due to invalid IL or missing references)
		//IL_008d: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c7: Unknown result type (might be due to invalid IL or missing references)
		//IL_00dd: Unknown result type (might be due to invalid IL or missing references)
		springScale = new SpringFloat();
		springScale.damping = 0.4f;
		springScale.speed = 30f;
		springRotation = new SpringFloat();
		springRotation.damping = 0.3f;
		springRotation.speed = 40f;
		springPosition = new SpringVector3();
		springPosition.damping = 0.35f;
		springPosition.speed = 30f;
		springPosition.lastPosition = targetPosition;
		SetSpacing();
		BatteryBarsSet();
		((Component)batteryBarCharge).gameObject.SetActive(false);
		((Component)batteryBarDrain).gameObject.SetActive(false);
		batteryDrainFullXScale = batteryBarDrain.localScale.x;
		batteryChargeFullXScale = batteryBarCharge.localScale.x;
	}

	public void VisibleForCamerasAgain()
	{
		if (!inUI)
		{
			((Component)this).gameObject.layer = LayerMask.NameToLayer("Default");
			Transform[] componentsInChildren = ((Component)this).GetComponentsInChildren<Transform>(true);
			for (int i = 0; i < componentsInChildren.Length; i++)
			{
				((Component)componentsInChildren[i]).gameObject.layer = LayerMask.NameToLayer("Default");
			}
		}
	}

	private void SetAllMainColors()
	{
		//IL_0007: Unknown result type (might be due to invalid IL or missing references)
		//IL_0018: Unknown result type (might be due to invalid IL or missing references)
		//IL_0029: Unknown result type (might be due to invalid IL or missing references)
		//IL_003a: Unknown result type (might be due to invalid IL or missing references)
		//IL_004b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0070: Unknown result type (might be due to invalid IL or missing references)
		((Graphic)batteryBorderMain).color = batteryColorMain;
		((Graphic)batteryBackground).color = batteryColorBackground;
		((Graphic)batteryBorderShadow).color = batteryColorShadow;
		((Graphic)batteryCharge).color = batteryColorCharge;
		((Graphic)batteryDrain).color = batteryColorDrain;
		foreach (GameObject bar in bars)
		{
			((Graphic)bar.GetComponent<RawImage>()).color = batteryColorMain;
		}
	}

	private void BatteryVisualBounce()
	{
		//IL_0016: Unknown result type (might be due to invalid IL or missing references)
		//IL_0026: Unknown result type (might be due to invalid IL or missing references)
		//IL_002b: Unknown result type (might be due to invalid IL or missing references)
		springPosition.springVelocity = new Vector3(0f, 500f * ((Component)this).transform.localScale.x, 0f);
		springRotation.springVelocity = 1000f;
	}

	public void BatteryDenyShake()
	{
		//IL_0011: Unknown result type (might be due to invalid IL or missing references)
		//IL_0026: Unknown result type (might be due to invalid IL or missing references)
		//IL_002b: Unknown result type (might be due to invalid IL or missing references)
		springPosition.springVelocity = new Vector3(500f * ((Component)this).transform.localScale.x, 0f, 0f);
		springRotation.springVelocity = -500f;
	}

	public void OverrideBatteryOutWarning(float _time)
	{
		overrideTimerBatteryOutWarning = _time;
		batteryIsOutWarning = true;
	}

	public void OverrideChargeNeeded(float _time, bool _flash = true)
	{
		overrideTimerChargeNeeded = _time;
		batteryChargeNeeded = true;
		batteryChargeNeededFlash = _flash;
	}

	public void OverrideBatteryDrain(float _time)
	{
		if (!batteryIsDraining)
		{
			drainAnimationProgress = 0f;
			if (!((Component)batteryDrain).gameObject.activeSelf)
			{
				((Component)batteryDrain).gameObject.SetActive(true);
			}
			BatteryVisualBounce();
		}
		overrideTimerBatteryDrain = _time;
		batteryIsDraining = true;
	}

	public void OverrideBatteryCharge(float _time)
	{
		if (!batteryIsCharging)
		{
			chargeAnimationProgress = 0f;
			if (!((Component)batteryCharge).gameObject.activeSelf)
			{
				((Component)batteryCharge).gameObject.SetActive(true);
			}
			BatteryVisualBounce();
		}
		overrideTimerBatteryCharge = _time;
		batteryIsCharging = true;
	}

	private void OverrideBatteryOutWarningTimer()
	{
		if (overrideTimerBatteryOutWarning > 0f)
		{
			overrideTimerBatteryOutWarning -= Time.deltaTime;
			return;
		}
		if (batteryIsOutWarning)
		{
			BatteryColorMainReset();
		}
		if (batteryOutVisual.activeSelf)
		{
			batteryOutVisual.SetActive(false);
		}
		batteryIsOutWarning = false;
	}

	private void OverrideChargeNeededTimer()
	{
		if (overrideTimerChargeNeeded > 0f)
		{
			overrideTimerChargeNeeded -= Time.deltaTime;
			return;
		}
		if (batteryChargeNeededVisual.activeSelf)
		{
			batteryChargeNeededVisual.SetActive(false);
		}
		batteryChargeNeeded = false;
	}

	private void OverrideBatteryDrainTimer()
	{
		if (overrideTimerBatteryDrain > 0f)
		{
			overrideTimerBatteryDrain -= Time.deltaTime;
			return;
		}
		if (((Component)batteryDrain).gameObject.activeSelf)
		{
			((Component)batteryDrain).gameObject.SetActive(false);
		}
		batteryIsDraining = false;
	}

	private void OverrideBatteryChargeTimer()
	{
		if (overrideTimerBatteryCharge > 0f)
		{
			overrideTimerBatteryCharge -= Time.deltaTime;
			return;
		}
		if (((Component)batteryCharge).gameObject.activeSelf)
		{
			((Component)batteryCharge).gameObject.SetActive(false);
		}
		batteryIsCharging = false;
	}

	private void OverrideTimers()
	{
		OverrideBatteryOutWarningTimer();
		OverrideBatteryDrainTimer();
		OverrideBatteryChargeTimer();
		OverrideChargeNeededTimer();
	}

	private void BatteryDrainVisuals()
	{
		//IL_002d: Unknown result type (might be due to invalid IL or missing references)
		//IL_003d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0047: Unknown result type (might be due to invalid IL or missing references)
		//IL_007a: Unknown result type (might be due to invalid IL or missing references)
		//IL_008f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0094: Unknown result type (might be due to invalid IL or missing references)
		if (batteryIsDraining)
		{
			float num = drainAnimationProgress;
			batteryBarDrain.localScale = new Vector3(Mathf.Lerp(batteryDrainFullXScale, 0f, num), batteryBarDrain.localScale.y, batteryBarDrain.localScale.z);
			if (drainAnimationProgress >= 1f)
			{
				drainAnimationProgress = 0f;
				springPosition.springVelocity = new Vector3(-250f * ((Component)this).transform.localScale.x, 0f, 0f);
				springRotation.springVelocity = -50f;
			}
			drainAnimationProgress += Time.deltaTime * 5f;
		}
	}

	private void BatteryChargeVisuals()
	{
		//IL_002d: Unknown result type (might be due to invalid IL or missing references)
		//IL_003d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0047: Unknown result type (might be due to invalid IL or missing references)
		//IL_007a: Unknown result type (might be due to invalid IL or missing references)
		//IL_008f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0094: Unknown result type (might be due to invalid IL or missing references)
		if (batteryIsCharging)
		{
			float num = chargeAnimationProgress;
			batteryBarCharge.localScale = new Vector3(Mathf.Lerp(0f, batteryChargeFullXScale, num), batteryBarCharge.localScale.y, batteryBarCharge.localScale.z);
			if (chargeAnimationProgress >= 1f)
			{
				chargeAnimationProgress = 0f;
				springPosition.springVelocity = new Vector3(250f * ((Component)this).transform.localScale.x, 0f, 0f);
				springRotation.springVelocity = 50f;
			}
			chargeAnimationProgress += Time.deltaTime * 5f;
		}
	}

	private void BatteryOutWarningVisuals()
	{
		//IL_0017: Unknown result type (might be due to invalid IL or missing references)
		//IL_001d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0023: Unknown result type (might be due to invalid IL or missing references)
		if (!batteryIsOutWarning)
		{
			return;
		}
		float num = warningAnimationProgress;
		((Graphic)batteryBorderMain).color = Color.Lerp(batteryColorMain, batteryColorWarning, num);
		if (warningAnimationProgress > 0.5f && batteryOutVisual.activeSelf)
		{
			batteryOutVisual.SetActive(false);
		}
		if (warningAnimationProgress >= 1f)
		{
			if (!batteryOutVisual.activeSelf)
			{
				batteryOutVisual.SetActive(true);
			}
			warningAnimationProgress = 0f;
		}
		warningAnimationProgress += Time.deltaTime * 2f;
	}

	private void BatteryChargeNeededVisuals()
	{
		if (!batteryChargeNeeded)
		{
			return;
		}
		if (!batteryChargeNeededFlash)
		{
			if (!batteryChargeNeededVisual.activeSelf)
			{
				batteryChargeNeededVisual.SetActive(true);
			}
			chargeNeededAnimationProgress = 0f;
			return;
		}
		if (chargeNeededAnimationProgress > 0.5f && batteryChargeNeededVisual.activeSelf)
		{
			batteryChargeNeededVisual.SetActive(false);
		}
		if (chargeNeededAnimationProgress >= 1f)
		{
			if (!batteryChargeNeededVisual.activeSelf)
			{
				batteryChargeNeededVisual.SetActive(true);
			}
			chargeNeededAnimationProgress = 0f;
		}
		chargeNeededAnimationProgress += Time.deltaTime * 0.5f;
	}

	private void SmallDeductionFlashVisuals()
	{
		//IL_003e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0095: Unknown result type (might be due to invalid IL or missing references)
		//IL_008e: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b5: Unknown result type (might be due to invalid IL or missing references)
		if (!smallDeductionFlashing)
		{
			return;
		}
		smallDeductionFlashTimer -= Time.deltaTime;
		int num = -1;
		for (int num2 = bars.Count - 1; num2 >= 0; num2--)
		{
			if (((Graphic)bars[num2].GetComponent<RawImage>()).color.a > 0f)
			{
				num = num2;
				break;
			}
		}
		if (num >= 0)
		{
			RawImage component = bars[num].GetComponent<RawImage>();
			bool flag = Mathf.FloorToInt(smallDeductionFlashTimer * 8f) % 2 == 0;
			((Graphic)component).color = (flag ? Color.red : batteryColorMain);
			if (smallDeductionFlashTimer <= 0f)
			{
				smallDeductionFlashing = false;
				((Graphic)component).color = batteryColorMain;
			}
		}
	}

	public void SmallBatteryDeductionEffect(float _time = 0.4f)
	{
		BatteryVisualBounce();
		smallDeductionFlashTimer = _time;
		smallDeductionFlashing = true;
	}

	private void BatteryVisuals()
	{
		BatteryDrainVisuals();
		BatteryChargeVisuals();
		BatteryOutWarningVisuals();
		BatteryChargeNeededVisuals();
		SmallDeductionFlashVisuals();
	}

	private void Update()
	{
		//IL_0064: Unknown result type (might be due to invalid IL or missing references)
		//IL_006e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0098: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ca: Unknown result type (might be due to invalid IL or missing references)
		if ((Object)(object)itemBatteryPrev != (Object)(object)itemBattery)
		{
			BatteryBarsSet();
			itemBatteryPrev = itemBattery;
		}
		if (Object.op_Implicit((Object)(object)itemBattery) && itemBattery.batteryLifeInt != currentBars)
		{
			BatteryBarsUpdate(itemBattery.batteryLifeInt);
		}
		((Component)this).transform.localPosition = SemiFunc.SpringVector3Get(springPosition, targetPosition);
		float num = SemiFunc.SpringFloatGet(springScale, targetScale);
		((Component)this).transform.localScale = new Vector3(num, num, num);
		float num2 = SemiFunc.SpringFloatGet(springRotation, targetRotation);
		((Component)this).transform.localRotation = Quaternion.Euler(0f, 0f, num2);
		if (doOutro && num <= 0f)
		{
			ResetOutro();
			((Component)this).gameObject.SetActive(false);
		}
		OverrideTimers();
		BatteryVisuals();
	}

	public void ResetOutro()
	{
		targetScale = targetScaleOriginal;
		targetRotation = targetRotationOriginal;
		doOutro = false;
	}

	private void OnEnable()
	{
		//IL_0006: Unknown result type (might be due to invalid IL or missing references)
		//IL_0035: Unknown result type (might be due to invalid IL or missing references)
		//IL_007c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0081: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b3: Unknown result type (might be due to invalid IL or missing references)
		((Component)this).transform.localScale = Vector3.zero;
		springScale.lastPosition = 0f;
		((Component)this).transform.localRotation = Quaternion.Euler(0f, 0f, 45f);
		springRotation.lastPosition = -90f;
		springPosition.lastPosition = new Vector3(targetPosition.x, targetPosition.y - 0.5f, targetPosition.z);
		((Component)this).transform.localPosition = new Vector3(targetPosition.x, targetPosition.y - 0.5f, targetPosition.z);
		SetSpacing();
		SetBatteryColor();
		doOutro = false;
	}

	private void SetBatteryColor()
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		if (Object.op_Implicit((Object)(object)itemBattery))
		{
			if (itemBattery.currentBars > 0)
			{
				BatteryColorMainReset();
			}
			else
			{
				BatteryColorMainSet(Color.red);
			}
		}
	}

	public void BatteryBarsSet()
	{
		//IL_00e0: Unknown result type (might be due to invalid IL or missing references)
		//IL_0173: Unknown result type (might be due to invalid IL or missing references)
		//IL_0154: Unknown result type (might be due to invalid IL or missing references)
		SetAllMainColors();
		int num = batteryBars;
		if (Object.op_Implicit((Object)(object)itemBattery))
		{
			num = itemBattery.batteryBars;
		}
		foreach (GameObject bar in bars)
		{
			Object.Destroy((Object)(object)bar);
		}
		bars.Clear();
		batteryBars = num;
		for (int i = 0; i < num; i++)
		{
			GameObject item = Object.Instantiate<GameObject>(batteryBarPrefab, batteryBarContainer);
			bars.Add(item);
		}
		if (Object.op_Implicit((Object)(object)itemBattery))
		{
			int num2 = itemBattery.currentBars;
			for (int j = 0; j < bars.Count; j++)
			{
				if (j >= num2)
				{
					((Graphic)bars[j].GetComponent<RawImage>()).color = new Color(1f, 1f, 1f, 0f);
				}
			}
			SetBatteryColor();
			currentBars = num2;
		}
		if (Object.op_Implicit((Object)(object)itemBattery))
		{
			for (int k = 0; k < bars.Count; k++)
			{
				if (k >= itemBattery.batteryLifeInt)
				{
					((Graphic)bars[k].GetComponent<RawImage>()).color = new Color(1f, 1f, 1f, 0f);
				}
				else
				{
					((Graphic)bars[k].GetComponent<RawImage>()).color = batteryColorMain;
				}
			}
		}
		SetSpacing();
	}

	private void SetSpacing()
	{
		((HorizontalOrVerticalLayoutGroup)batteryBarContainerGroup).spacing = 12f / (float)batteryBars;
		if (batteryBars <= 8)
		{
			((HorizontalOrVerticalLayoutGroup)batteryBarContainerGroup).spacing = 2f;
		}
		if (batteryBars > 8)
		{
			((HorizontalOrVerticalLayoutGroup)batteryBarContainerGroup).spacing = 1f;
		}
	}

	public void BatteryBarsUpdate(int _setToBars = -1, bool _forceUpdate = false)
	{
		//IL_012d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0097: Unknown result type (might be due to invalid IL or missing references)
		//IL_01a7: Unknown result type (might be due to invalid IL or missing references)
		//IL_0175: Unknown result type (might be due to invalid IL or missing references)
		//IL_018b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0190: Unknown result type (might be due to invalid IL or missing references)
		//IL_010d: Unknown result type (might be due to invalid IL or missing references)
		//IL_00de: Unknown result type (might be due to invalid IL or missing references)
		if (!Object.op_Implicit((Object)(object)itemBattery) && _setToBars == -1)
		{
			return;
		}
		int num = _setToBars;
		if (_setToBars == -1 && Object.op_Implicit((Object)(object)itemBattery))
		{
			num = itemBattery.batteryLifeInt;
		}
		if (!inUI && !_forceUpdate && (Object)(object)BatteryUI.instance.batteryVisualLogic.itemBattery == (Object)(object)itemBattery)
		{
			BatteryUI.instance.batteryVisualLogic.BatteryBarsUpdate(num, _forceUpdate: true);
		}
		SetBatteryColor();
		currentBars = num;
		for (int i = 0; i < bars.Count; i++)
		{
			if (i >= num)
			{
				if (((Graphic)bars[i].GetComponent<RawImage>()).color.a != 0f)
				{
					BatteryVisualBounce();
					Object.Instantiate<GameObject>(barLossEffectPrefab, bars[i].transform).transform.localPosition = new Vector3(0f, 0f, 0f);
				}
				((Graphic)bars[i].GetComponent<RawImage>()).color = new Color(1f, 1f, 1f, 0f);
				continue;
			}
			if (((Graphic)bars[i].GetComponent<RawImage>()).color.a == 0f)
			{
				BatteryVisualBounce();
				GameObject val = Object.Instantiate<GameObject>(barLossEffectPrefab, bars[i].transform);
				val.transform.localPosition = new Vector3(0f, 0f, 0f);
				BatteryBarEffect component = val.GetComponent<BatteryBarEffect>();
				component.barLossEffect = false;
				component.barColor = Color.green;
			}
			((Graphic)bars[i].GetComponent<RawImage>()).color = batteryColorMain;
		}
	}

	public void BatteryColorMainSet(Color _color)
	{
		//IL_0006: Unknown result type (might be due to invalid IL or missing references)
		//IL_0028: Unknown result type (might be due to invalid IL or missing references)
		//IL_003f: Unknown result type (might be due to invalid IL or missing references)
		((Graphic)batteryBorderMain).color = _color;
		foreach (GameObject bar in bars)
		{
			if (((Graphic)bar.GetComponent<RawImage>()).color.a > 0f)
			{
				((Graphic)bar.GetComponent<RawImage>()).color = _color;
			}
		}
	}

	public void BatteryColorMainReset()
	{
		//IL_001a: Unknown result type (might be due to invalid IL or missing references)
		//IL_002b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0030: Unknown result type (might be due to invalid IL or missing references)
		//IL_0051: Unknown result type (might be due to invalid IL or missing references)
		//IL_0069: Unknown result type (might be due to invalid IL or missing references)
		if (!Object.op_Implicit((Object)(object)itemBattery))
		{
			return;
		}
		((Graphic)batteryBorderMain).color = itemBattery.batteryColorMedium;
		batteryColorMain = itemBattery.batteryColor;
		foreach (GameObject bar in bars)
		{
			if (((Graphic)bar.GetComponent<RawImage>()).color.a > 0f)
			{
				((Graphic)bar.GetComponent<RawImage>()).color = batteryColorMain;
			}
		}
	}

	public void HideCurrentBar(bool _hide, Color _blinkColor)
	{
		//IL_005c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0079: Unknown result type (might be due to invalid IL or missing references)
		//IL_007f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0085: Unknown result type (might be due to invalid IL or missing references)
		//IL_0090: Unknown result type (might be due to invalid IL or missing references)
		//IL_0076: Unknown result type (might be due to invalid IL or missing references)
		//IL_0039: Unknown result type (might be due to invalid IL or missing references)
		//IL_003f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0045: Unknown result type (might be due to invalid IL or missing references)
		//IL_0050: Unknown result type (might be due to invalid IL or missing references)
		//IL_0036: Unknown result type (might be due to invalid IL or missing references)
		if (Object.op_Implicit((Object)(object)itemBattery))
		{
			int num = itemBattery.currentBars;
			if (num > 0)
			{
				((Graphic)bars[num - 1].GetComponent<RawImage>()).color = (Color)(_hide ? new Color(_blinkColor.r, _blinkColor.g, _blinkColor.b, 0f) : _blinkColor);
				return;
			}
			_ = batteryColorMain;
			((Graphic)bars[0].GetComponent<RawImage>()).color = (Color)(_hide ? new Color(_blinkColor.r, _blinkColor.g, _blinkColor.b, 0f) : _blinkColor);
		}
	}

	public void BatteryOutro()
	{
		if (!doOutro)
		{
			springScale.springVelocity = 0.1f;
			springRotation.springVelocity = -1000f;
			doOutro = true;
			targetScale = 0f;
		}
	}

	public BatteryVisualLogic()
	{
		//IL_0056: Unknown result type (might be due to invalid IL or missing references)
		//IL_005b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0075: Unknown result type (might be due to invalid IL or missing references)
		//IL_007a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0094: Unknown result type (might be due to invalid IL or missing references)
		//IL_0099: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b8: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d2: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d7: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f1: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f6: Unknown result type (might be due to invalid IL or missing references)
		//IL_0128: Unknown result type (might be due to invalid IL or missing references)
		//IL_012d: Unknown result type (might be due to invalid IL or missing references)
		//IL_013e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0143: Unknown result type (might be due to invalid IL or missing references)
	}
}
