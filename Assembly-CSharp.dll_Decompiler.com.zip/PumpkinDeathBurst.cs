using UnityEngine;

public class PumpkinDeathBurst : MonoBehaviour
{
	private enum State
	{
		Ready,
		Playing
	}

	public LarvaPukeDeathParticles pulp;

	public ParticleSystem bits;

	public ParticleSystem smallBits;

	public Color pulpColorMin = new Color(1f, 0.32f, 0.015f, 1f);

	public Color pulpColorMax = new Color(1f, 0.72f, 0.08f, 1f);

	public Color rindColorMin = new Color(0.75f, 0.12f, 0.005f, 1f);

	public Color rindColorMax = new Color(1f, 0.42f, 0.025f, 1f);

	public int bitCount = 28;

	public int smallBitCount = 18;

	public float referenceDiameter = 0.5f;

	public Sound soundHit = new Sound
	{
		Volume = 0.75f,
		VolumeRandom = 0.05f,
		PitchRandom = 0.04f,
		Doppler = 0f
	};

	public Sound soundSplat = new Sound
	{
		Volume = 0.65f,
		VolumeRandom = 0.05f,
		PitchRandom = 0.04f,
		Doppler = 0f
	};

	private ParticleSystem[] particleSystems;

	private State currentState;

	private float cleanupTimer;

	public void Play(float diameter, Vector3 forward)
	{
		//IL_0033: Unknown result type (might be due to invalid IL or missing references)
		//IL_0034: Unknown result type (might be due to invalid IL or missing references)
		//IL_0039: Unknown result type (might be due to invalid IL or missing references)
		//IL_003e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0059: Unknown result type (might be due to invalid IL or missing references)
		//IL_0060: Unknown result type (might be due to invalid IL or missing references)
		//IL_0065: Unknown result type (might be due to invalid IL or missing references)
		//IL_0075: Unknown result type (might be due to invalid IL or missing references)
		//IL_007b: Unknown result type (might be due to invalid IL or missing references)
		//IL_004d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0052: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a6: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ac: Unknown result type (might be due to invalid IL or missing references)
		if (currentState == State.Playing)
		{
			return;
		}
		currentState = State.Playing;
		float num = Mathf.Clamp(diameter / Mathf.Max(0.01f, referenceDiameter), 0.3f, 3f);
		Vector3 val = Vector3.ProjectOnPlane(forward, Vector3.up);
		if (val.sqrMagnitude < 0.001f)
		{
			val = Vector3.forward;
		}
		((Component)this).transform.rotation = Quaternion.LookRotation(Vector3.up, val.normalized);
		((Component)this).transform.localScale = Vector3.one * num;
		particleSystems = ((Component)this).GetComponentsInChildren<ParticleSystem>(true);
		ParticleSystem[] array = particleSystems;
		foreach (ParticleSystem particles in array)
		{
			PrepareParticles(particles, pulpColorMin, pulpColorMax);
		}
		if (Object.op_Implicit((Object)(object)pulp))
		{
			foreach (LarvaPukeDeathParticles.Emitter emitter in pulp.emitters)
			{
				if (emitter != null && Object.op_Implicit((Object)(object)emitter.particles))
				{
					emitter.particles.Play(false);
					emitter.particles.Emit(emitter.particleCount);
				}
			}
			foreach (ParticleSystem authoredEmitter in pulp.authoredEmitters)
			{
				if (Object.op_Implicit((Object)(object)authoredEmitter))
				{
					authoredEmitter.Play(false);
				}
			}
		}
		EmitBits(bits, bitCount, 0.055f, 0.11f);
		EmitBits(smallBits, smallBitCount, 0.025f, 0.055f);
		PlayLayer(soundHit);
		PlayLayer(soundSplat);
		cleanupTimer = 0.5f;
	}

	private void Update()
	{
		if (currentState != State.Playing)
		{
			return;
		}
		if (cleanupTimer > 0f)
		{
			cleanupTimer -= Time.deltaTime;
			return;
		}
		ParticleSystem[] array = particleSystems;
		foreach (ParticleSystem val in array)
		{
			if (Object.op_Implicit((Object)(object)val) && val.IsAlive(false))
			{
				return;
			}
		}
		Object.Destroy((Object)(object)((Component)this).gameObject);
	}

	private void PrepareParticles(ParticleSystem particles, Color colorMin, Color colorMax)
	{
		//IL_0009: Unknown result type (might be due to invalid IL or missing references)
		//IL_000e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0039: Unknown result type (might be due to invalid IL or missing references)
		//IL_003a: Unknown result type (might be due to invalid IL or missing references)
		//IL_003b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0046: Unknown result type (might be due to invalid IL or missing references)
		//IL_004b: Unknown result type (might be due to invalid IL or missing references)
		//IL_00be: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d1: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d6: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e5: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ea: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f5: Unknown result type (might be due to invalid IL or missing references)
		//IL_00fa: Unknown result type (might be due to invalid IL or missing references)
		//IL_0057: Unknown result type (might be due to invalid IL or missing references)
		//IL_005c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0060: Unknown result type (might be due to invalid IL or missing references)
		//IL_0066: Invalid comparison between Unknown and I4
		//IL_0085: Unknown result type (might be due to invalid IL or missing references)
		//IL_008b: Invalid comparison between Unknown and I4
		//IL_0077: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a9: Unknown result type (might be due to invalid IL or missing references)
		particles.Stop(false, (ParticleSystemStopBehavior)0);
		MainModule main = particles.main;
		main.loop = false;
		main.playOnAwake = false;
		main.stopAction = (ParticleSystemStopAction)0;
		main.cullingMode = (ParticleSystemCullingMode)3;
		main.scalingMode = (ParticleSystemScalingMode)0;
		main.startColor = new MinMaxGradient(colorMin, colorMax);
		ColorOverLifetimeModule colorOverLifetime = particles.colorOverLifetime;
		if (colorOverLifetime.enabled)
		{
			MinMaxGradient color = colorOverLifetime.color;
			if ((int)color.mode == 1)
			{
				colorOverLifetime.color = MinMaxGradient.op_Implicit(WhiteGradient(color.gradient));
			}
			else if ((int)color.mode == 3)
			{
				colorOverLifetime.color = new MinMaxGradient(WhiteGradient(color.gradientMin), WhiteGradient(color.gradientMax));
			}
			else
			{
				colorOverLifetime.enabled = false;
			}
		}
		TrailModule trails = particles.trails;
		trails.inheritParticleColor = true;
		trails.colorOverLifetime = WhiteColors(trails.colorOverLifetime);
		trails.colorOverTrail = WhiteColors(trails.colorOverTrail);
		ColorBySpeedModule colorBySpeed = particles.colorBySpeed;
		colorBySpeed.enabled = false;
	}

	private MinMaxGradient WhiteColors(MinMaxGradient colors)
	{
		//IL_0002: Unknown result type (might be due to invalid IL or missing references)
		//IL_0007: Unknown result type (might be due to invalid IL or missing references)
		//IL_0008: Unknown result type (might be due to invalid IL or missing references)
		//IL_000a: Unknown result type (might be due to invalid IL or missing references)
		//IL_001c: Expected I4, but got Unknown
		//IL_002b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0062: Unknown result type (might be due to invalid IL or missing references)
		//IL_006c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0082: Unknown result type (might be due to invalid IL or missing references)
		//IL_008c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0091: Unknown result type (might be due to invalid IL or missing references)
		//IL_004b: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a8: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b2: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b7: Unknown result type (might be due to invalid IL or missing references)
		ParticleSystemGradientMode mode = colors.mode;
		return (mode - 1) switch
		{
			0 => new MinMaxGradient(WhiteGradient(colors.gradient)), 
			2 => new MinMaxGradient(WhiteGradient(colors.gradientMin), WhiteGradient(colors.gradientMax)), 
			1 => new MinMaxGradient(new Color(1f, 1f, 1f, colors.colorMin.a), new Color(1f, 1f, 1f, colors.colorMax.a)), 
			_ => new MinMaxGradient(new Color(1f, 1f, 1f, colors.color.a)), 
		};
	}

	private Gradient WhiteGradient(Gradient gradient)
	{
		//IL_0000: Unknown result type (might be due to invalid IL or missing references)
		//IL_0006: Expected Obj, but got Unknown
		//IL_000f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0019: Unknown result type (might be due to invalid IL or missing references)
		//IL_001e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0025: Unknown result type (might be due to invalid IL or missing references)
		//IL_002f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0034: Unknown result type (might be due to invalid IL or missing references)
		//IL_0046: Unknown result type (might be due to invalid IL or missing references)
		Gradient val = new Gradient();
		val.SetKeys(new GradientColorKey[2]
		{
			new GradientColorKey(Color.white, 0f),
			new GradientColorKey(Color.white, 1f)
		}, gradient.alphaKeys);
		val.mode = gradient.mode;
		return val;
	}

	private void EmitBits(ParticleSystem particles, int count, float sizeMin, float sizeMax)
	{
		//IL_000a: Unknown result type (might be due to invalid IL or missing references)
		//IL_000f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0013: Unknown result type (might be due to invalid IL or missing references)
		//IL_0019: Unknown result type (might be due to invalid IL or missing references)
		//IL_001e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0035: Unknown result type (might be due to invalid IL or missing references)
		//IL_004b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0061: Unknown result type (might be due to invalid IL or missing references)
		//IL_006c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0071: Unknown result type (might be due to invalid IL or missing references)
		//IL_0088: Unknown result type (might be due to invalid IL or missing references)
		//IL_0093: Unknown result type (might be due to invalid IL or missing references)
		//IL_0098: Unknown result type (might be due to invalid IL or missing references)
		if (Object.op_Implicit((Object)(object)particles))
		{
			MainModule main = particles.main;
			main.startColor = new MinMaxGradient(rindColorMin, rindColorMax);
			main.startSize3D = false;
			main.startSize = new MinMaxCurve(sizeMin, sizeMax);
			main.startSpeed = new MinMaxCurve(1.5f, 4f);
			main.startLifetime = new MinMaxCurve(1.2f, 2.8f);
			ShapeModule shape = particles.shape;
			shape.shapeType = (ParticleSystemShapeType)0;
			shape.radius = 0.12f;
			shape.scale = Vector3.one;
			EmissionModule emission = particles.emission;
			emission.enabled = false;
			particles.Play(false);
			particles.Emit(count);
		}
	}

	private void PlayLayer(Sound sound)
	{
		//IL_003d: Unknown result type (might be due to invalid IL or missing references)
		if (sound == null || sound.Sounds == null || sound.Sounds.Length == 0)
		{
			return;
		}
		AudioClip[] sounds = sound.Sounds;
		sound.Sounds = new AudioClip[1] { sounds[Random.Range(0, sounds.Length)] };
		try
		{
			sound.Play(((Component)this).transform.position);
		}
		finally
		{
			sound.Sounds = sounds;
		}
	}

	public PumpkinDeathBurst()
	{
		//IL_0015: Unknown result type (might be due to invalid IL or missing references)
		//IL_001a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0034: Unknown result type (might be due to invalid IL or missing references)
		//IL_0039: Unknown result type (might be due to invalid IL or missing references)
		//IL_0053: Unknown result type (might be due to invalid IL or missing references)
		//IL_0058: Unknown result type (might be due to invalid IL or missing references)
		//IL_0072: Unknown result type (might be due to invalid IL or missing references)
		//IL_0077: Unknown result type (might be due to invalid IL or missing references)
	}
}
