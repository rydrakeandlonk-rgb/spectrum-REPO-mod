using System.Linq;
using Photon.Realtime;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

public class MenuPlayerListed : MonoBehaviour
{
	internal PlayerAvatar playerAvatar;

	internal Player playerPhoton;

	internal int listSpot;

	public TextMeshProUGUI playerName;

	public MenuPlayerHead playerHead;

	private RectTransform parentTransform;

	private Vector3 midScreenFocus;

	public TextMeshProUGUI pingText;

	private bool localFetch;

	internal bool isLocal;

	public bool isSpectate = true;

	public GameObject leftCrown;

	public GameObject rightCrown;

	public bool forceCrown;

	public bool brightName;

	[Space]
	private MenuPlayerListedSteam steamButton;

	private void Start()
	{
		//IL_0062: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0072: Unknown result type (might be due to invalid IL or missing references)
		//IL_0087: Unknown result type (might be due to invalid IL or missing references)
		//IL_008c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0091: Unknown result type (might be due to invalid IL or missing references)
		parentTransform = ((Component)((Component)this).transform.parent).GetComponent<RectTransform>();
		((Transform)playerHead.focusPoint).SetParent((Transform)(object)parentTransform);
		((Transform)playerHead.myFocusPoint).SetParent((Transform)(object)parentTransform);
		midScreenFocus = new Vector3((float)(MenuManager.instance.screenUIWidth / 2), (float)(MenuManager.instance.screenUIHeight / 2), 0f) - ((Transform)parentTransform).localPosition - ((Transform)((Component)((Transform)parentTransform).parent).GetComponent<RectTransform>()).localPosition;
		if (forceCrown)
		{
			leftCrown.SetActive(true);
			rightCrown.SetActive(true);
			PlayerAvatar playerAvatar = null;
			if (Object.op_Implicit((Object)(object)Arena.instance))
			{
				playerAvatar = Arena.instance.winnerPlayer;
			}
			if (!Object.op_Implicit((Object)(object)playerAvatar) && Object.op_Implicit((Object)(object)ArenaRace.instance))
			{
				playerAvatar = ArenaRace.instance.winnerPlayer;
			}
			if (Object.op_Implicit((Object)(object)playerAvatar))
			{
				ForcePlayer(playerAvatar);
			}
			TextMeshProUGUI componentInChildren = ((Component)this).GetComponentInChildren<TextMeshProUGUI>();
			if (Object.op_Implicit((Object)(object)componentInChildren) && Object.op_Implicit((Object)(object)this.playerAvatar))
			{
				((TMP_Text)componentInChildren).text = this.playerAvatar.playerName;
			}
		}
		steamButton = ((Component)this).GetComponentInChildren<MenuPlayerListedSteam>();
		if (Object.op_Implicit((Object)(object)steamButton) && !SemiFunc.RunIsLobbyMenu())
		{
			((Component)steamButton).gameObject.SetActive(false);
		}
	}

	public void ForcePlayer(PlayerAvatar _playerAvatar)
	{
		playerHead.SetPlayer(_playerAvatar);
		playerAvatar = _playerAvatar;
		localFetch = false;
	}

	private void Update()
	{
		//IL_0164: Unknown result type (might be due to invalid IL or missing references)
		//IL_016a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0182: Unknown result type (might be due to invalid IL or missing references)
		//IL_039a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0374: Unknown result type (might be due to invalid IL or missing references)
		//IL_030e: Unknown result type (might be due to invalid IL or missing references)
		//IL_032e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0333: Unknown result type (might be due to invalid IL or missing references)
		//IL_0340: Unknown result type (might be due to invalid IL or missing references)
		//IL_031b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0320: Unknown result type (might be due to invalid IL or missing references)
		//IL_02bf: Unknown result type (might be due to invalid IL or missing references)
		//IL_025b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0260: Unknown result type (might be due to invalid IL or missing references)
		//IL_026a: Unknown result type (might be due to invalid IL or missing references)
		//IL_026f: Unknown result type (might be due to invalid IL or missing references)
		//IL_027d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0282: Unknown result type (might be due to invalid IL or missing references)
		//IL_028f: Unknown result type (might be due to invalid IL or missing references)
		//IL_02df: Unknown result type (might be due to invalid IL or missing references)
		//IL_02e4: Unknown result type (might be due to invalid IL or missing references)
		//IL_02f1: Unknown result type (might be due to invalid IL or missing references)
		//IL_02cc: Unknown result type (might be due to invalid IL or missing references)
		//IL_02d1: Unknown result type (might be due to invalid IL or missing references)
		if (!Object.op_Implicit((Object)(object)this.playerAvatar) && playerPhoton != null)
		{
			PlayerAvatar playerAvatar = SemiFunc.PlayerAvatarGetFromPhotonPlayer(playerPhoton);
			if (Object.op_Implicit((Object)(object)playerAvatar))
			{
				this.playerAvatar = playerAvatar;
				playerHead.SetPlayer(this.playerAvatar);
			}
		}
		if (SemiFunc.PerSecond(5f, (Object)(object)this) && Object.op_Implicit((Object)(object)this.playerAvatar) && !forceCrown)
		{
			bool flag = SessionManager.instance.crownedPlayerSteamID == this.playerAvatar.steamID;
			if (flag != leftCrown.activeSelf || flag != rightCrown.activeSelf)
			{
				leftCrown.SetActive(flag);
				rightCrown.SetActive(flag);
			}
		}
		if (!localFetch && (Object.op_Implicit((Object)(object)this.playerAvatar) || playerPhoton != null))
		{
			MenuButtonKick componentInChildren = ((Component)this).GetComponentInChildren<MenuButtonKick>();
			if (Object.op_Implicit((Object)(object)componentInChildren))
			{
				componentInChildren.Setup(this.playerAvatar, playerPhoton);
			}
			isLocal = (Object.op_Implicit((Object)(object)this.playerAvatar) ? this.playerAvatar.isLocal : playerPhoton.IsLocal);
			localFetch = true;
			if (isLocal && Object.op_Implicit((Object)(object)steamButton))
			{
				((Component)steamButton).gameObject.SetActive(false);
			}
			SetupRowNavigation();
		}
		if (!forceCrown && ((Transform)playerHead.myFocusPoint).localPosition != midScreenFocus)
		{
			((Transform)playerHead.myFocusPoint).localPosition = midScreenFocus;
		}
		if (Object.op_Implicit((Object)(object)this.playerAvatar) || playerPhoton != null)
		{
			if (isSpectate && Object.op_Implicit((Object)(object)this.playerAvatar) && ((TMP_Text)playerName).text != this.playerAvatar.playerName)
			{
				((TMP_Text)playerName).text = this.playerAvatar.playerName;
			}
			PlayerVoiceChat playerVoiceChat;
			if (Object.op_Implicit((Object)(object)this.playerAvatar) && this.playerAvatar.voiceChatFetched)
			{
				playerVoiceChat = this.playerAvatar.voiceChat;
			}
			else
			{
				playerVoiceChat = ((playerPhoton != null) ? SemiFunc.PlayerVoiceChatGetFromPhotonPlayer(playerPhoton) : null);
			}
			if (Object.op_Implicit((Object)(object)this.playerAvatar) && Object.op_Implicit((Object)(object)this.playerAvatar.playerDeathHead) && this.playerAvatar.playerDeathHead.spectated)
			{
				Color val = Color.Lerp(Color.white, Color.black, 0.9f);
				((Graphic)playerName).color = Color.Lerp(((Graphic)playerName).color, val, Time.deltaTime * 10f);
			}
			else if (Object.op_Implicit((Object)(object)playerVoiceChat) && playerVoiceChat.isTalking)
			{
				Color val2 = new Color(0.6f, 0.6f, 0.4f);
				if (brightName)
				{
					val2 = Color.white;
				}
				((Graphic)playerName).color = Color.Lerp(((Graphic)playerName).color, val2, Time.deltaTime * 10f);
			}
			else
			{
				Color val3 = new Color(0.2f, 0.2f, 0.2f);
				if (brightName)
				{
					val3 = Color.white;
				}
				((Graphic)playerName).color = Color.Lerp(((Graphic)playerName).color, val3, Time.deltaTime * 10f);
			}
		}
		if (!forceCrown)
		{
			if (!SemiFunc.RunIsLobbyMenu())
			{
				((Component)this).transform.localPosition = new Vector3(-23f, (float)(-listSpot * 22), 0f);
			}
			else
			{
				((Component)this).transform.localPosition = new Vector3(0f, (float)(-listSpot * 32), 0f);
			}
		}
	}

	private void SetupRowNavigation()
	{
		//IL_0061: Unknown result type (might be due to invalid IL or missing references)
		//IL_0066: Unknown result type (might be due to invalid IL or missing references)
		//IL_0094: Unknown result type (might be due to invalid IL or missing references)
		MenuSelectableElement[] array = (from el in ((Component)this).GetComponentsInChildren<MenuSelectableElement>()
			where ((Selectable)el).interactable
			select el).OrderBy((MenuSelectableElement el) =>
		{
			//IL_000c: Unknown result type (might be due to invalid IL or missing references)
			//IL_0011: Unknown result type (might be due to invalid IL or missing references)
			//IL_0014: Unknown result type (might be due to invalid IL or missing references)
			//IL_0019: Unknown result type (might be due to invalid IL or missing references)
			//IL_001e: Unknown result type (might be due to invalid IL or missing references)
			RectTransform rectTransform = el.rectTransform;
			Rect rect = el.rectTransform.rect;
			return ((Transform)rectTransform).TransformPoint(Vector2.op_Implicit(rect.center)).x;
		}).ToArray();
		if (array.Length >= 2)
		{
			for (int num = 0; num < array.Length; num++)
			{
				Navigation navigation = ((Selectable)array[num]).navigation;
				navigation.selectOnLeft = (Selectable)(object)((num > 0) ? array[num - 1] : null);
				navigation.selectOnRight = (Selectable)(object)((num < array.Length - 1) ? array[num + 1] : null);
				((Selectable)array[num]).navigation = navigation;
			}
		}
		if (SemiFunc.RunIsLobbyMenu() && Object.op_Implicit((Object)(object)MenuPageLobby.instance))
		{
			MenuPageLobby.instance.KickNavigationUpdate();
		}
	}

	internal MenuSelectableElement KickSelectableGet()
	{
		MenuButtonKick componentInChildren = ((Component)this).GetComponentInChildren<MenuButtonKick>();
		if (!Object.op_Implicit((Object)(object)componentInChildren))
		{
			return null;
		}
		return ((Component)componentInChildren).GetComponentInChildren<MenuSelectableElement>();
	}

	public void MenuPlayerListedOutro()
	{
		Object.Destroy((Object)(object)((Component)this).gameObject);
	}
}
