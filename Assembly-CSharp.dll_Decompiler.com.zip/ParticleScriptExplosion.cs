using UnityEngine;

public class ParticleScriptExplosion : MonoBehaviour
{
	public ExplosionPreset explosionPreset;

	private GameObject explosionPrefab;

	internal PlayerAvatar playerCausingHurtOverride;

	internal bool playerHitFullRuckusOverride;

	private void Start()
	{
		explosionPrefab = Resources.Load<GameObject>("Effects/Part Prefab Explosion");
	}

	public void PlayExplosionSoundSmall(Vector3 _position)
	{
		//IL_000b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0031: Unknown result type (might be due to invalid IL or missing references)
		explosionPreset.explosionSoundSmall.Play(_position);
		explosionPreset.explosionSoundSmallGlobal.Play(_position);
	}

	public void PlayExplosionSoundMedium(Vector3 _position)
	{
		//IL_000b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0031: Unknown result type (might be due to invalid IL or missing references)
		explosionPreset.explosionSoundMedium.Play(_position);
		explosionPreset.explosionSoundMediumGlobal.Play(_position);
	}

	public void PlayExplosionSoundBig(Vector3 _position)
	{
		//IL_000b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0031: Unknown result type (might be due to invalid IL or missing references)
		explosionPreset.explosionSoundBig.Play(_position);
		explosionPreset.explosionSoundBigGlobal.Play(_position);
	}

	public ParticlePrefabExplosion Spawn(Vector3 position, float size, int damage, int enemyDamage, float forceMulti = 1f, bool onlyParticleEffect = false, bool disableSound = false, float shakeMultiplier = 1f, float investigateRadius = 0f)
	{
		//IL_001a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0040: Unknown result type (might be due to invalid IL or missing references)
		//IL_0183: Unknown result type (might be due to invalid IL or missing references)
		//IL_01a9: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d4: Unknown result type (might be due to invalid IL or missing references)
		//IL_00fa: Unknown result type (might be due to invalid IL or missing references)
		//IL_0083: Unknown result type (might be due to invalid IL or missing references)
		//IL_00aa: Unknown result type (might be due to invalid IL or missing references)
		//IL_01e9: Unknown result type (might be due to invalid IL or missing references)
		//IL_0210: Unknown result type (might be due to invalid IL or missing references)
		//IL_013d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0164: Unknown result type (might be due to invalid IL or missing references)
		//IL_023e: Unknown result type (might be due to invalid IL or missing references)
		//IL_023f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0290: Unknown result type (might be due to invalid IL or missing references)
		//IL_0295: Unknown result type (might be due to invalid IL or missing references)
		//IL_02a3: Unknown result type (might be due to invalid IL or missing references)
		//IL_02b3: Unknown result type (might be due to invalid IL or missing references)
		//IL_02b8: Unknown result type (might be due to invalid IL or missing references)
		//IL_02c6: Unknown result type (might be due to invalid IL or missing references)
		//IL_0342: Unknown result type (might be due to invalid IL or missing references)
		if (size < 0.25f)
		{
			if (!disableSound)
			{
				explosionPreset.explosionSoundSmall.Play(position);
				explosionPreset.explosionSoundSmallGlobal.Play(position);
			}
			if (shakeMultiplier != 0f)
			{
				GameDirector.instance.CameraImpact.ShakeDistance(3f * shakeMultiplier, 3f, 6f, position, 0.2f);
				GameDirector.instance.CameraShake.ShakeDistance(3f * shakeMultiplier, 3f, 6f, position, 0.5f);
			}
		}
		else if (size < 0.5f)
		{
			if (!disableSound)
			{
				explosionPreset.explosionSoundMedium.Play(position);
				explosionPreset.explosionSoundMediumGlobal.Play(position);
			}
			if (shakeMultiplier != 0f)
			{
				GameDirector.instance.CameraImpact.ShakeDistance(5f * shakeMultiplier, 4f, 8f, position, 0.2f);
				GameDirector.instance.CameraShake.ShakeDistance(5f * shakeMultiplier, 4f, 8f, position, 0.5f);
			}
		}
		else
		{
			if (!disableSound)
			{
				explosionPreset.explosionSoundBig.Play(position);
				explosionPreset.explosionSoundBigGlobal.Play(position);
			}
			if (shakeMultiplier != 0f)
			{
				GameDirector.instance.CameraImpact.ShakeDistance(10f * shakeMultiplier, 6f, 12f, position, 0.2f);
				GameDirector.instance.CameraShake.ShakeDistance(5f * shakeMultiplier, 6f, 12f, position, 0.5f);
			}
		}
		if (!Object.op_Implicit((Object)(object)explosionPrefab))
		{
			explosionPrefab = Resources.Load<GameObject>("Effects/Part Prefab Explosion");
		}
		ParticlePrefabExplosion component = Object.Instantiate<GameObject>(explosionPrefab, position, Quaternion.identity).GetComponent<ParticlePrefabExplosion>();
		component.forceMultiplier = explosionPreset.explosionForceMultiplier * forceMulti;
		component.explosionSize = size;
		component.explosionDamage = damage;
		component.explosionDamageEnemy = enemyDamage;
		component.lightColorOverTime = explosionPreset.lightColor;
		ColorOverLifetimeModule colorOverLifetime = component.particleFire.colorOverLifetime;
		colorOverLifetime.color = MinMaxGradient.op_Implicit(explosionPreset.explosionColors);
		colorOverLifetime = component.particleSmoke.colorOverLifetime;
		colorOverLifetime.color = MinMaxGradient.op_Implicit(explosionPreset.smokeColors);
		if (Object.op_Implicit((Object)(object)playerCausingHurtOverride))
		{
			component.playerCausingHurt = playerCausingHurtOverride;
		}
		else
		{
			PhysGrabObject component2 = ((Component)this).GetComponent<PhysGrabObject>();
			if (Object.op_Implicit((Object)(object)component2))
			{
				component.playerCausingHurt = component2.lastPlayerGrabbing;
			}
		}
		component.playerHitFullRuckus = playerHitFullRuckusOverride;
		component.particleFire.Play();
		component.particleSmoke.Play();
		((Behaviour)component.light).enabled = true;
		if (investigateRadius > 0f)
		{
			EnemyDirector.instance.SetInvestigate(position, investigateRadius);
		}
		return component;
	}
}
