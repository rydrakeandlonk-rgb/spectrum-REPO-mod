using TMPro;
using UnityEngine;
using UnityEngine.Events;
using UnityEngine.UI;

public class MenuPagePopUpTextInput : MonoBehaviour
{
	public static MenuPagePopUpTextInput instance;

	internal MenuPage menuPage;

	internal UnityEvent<string> confirmEvent;

	internal UnityEvent cancelEvent;

	public TextMeshProUGUI bodyTextMesh;

	public MenuButton confirmButton;

	public MenuButton backButton;

	public MenuTextInput menuTextInput;

	internal bool richText = true;

	internal bool allowEmpty;

	[RuntimeInitializeOnLoadMethod(/*Could not decode attribute arguments.*/)]
	private static void RuntimeInitializeOnLoad()
	{
		instance = null;
	}

	private void Awake()
	{
		instance = this;
		menuPage = ((Component)this).GetComponent<MenuPage>();
	}

	private void Start()
	{
		((TMP_Text)bodyTextMesh).richText = richText;
		SetupButtonNavigation();
	}

	private void SetupButtonNavigation()
	{
		//IL_0073: Unknown result type (might be due to invalid IL or missing references)
		//IL_0083: Unknown result type (might be due to invalid IL or missing references)
		MenuSelectableElement menuSelectableElement = (Object.op_Implicit((Object)(object)menuTextInput) ? menuTextInput.menuSelectableElement : null);
		MenuSelectableElement menuSelectableElement2 = (Object.op_Implicit((Object)(object)backButton) ? backButton.menuSelectableElement : null);
		MenuSelectableElement menuSelectableElement3 = (Object.op_Implicit((Object)(object)confirmButton) ? confirmButton.menuSelectableElement : null);
		if (Object.op_Implicit((Object)(object)menuSelectableElement) && Object.op_Implicit((Object)(object)menuSelectableElement2) && Object.op_Implicit((Object)(object)menuSelectableElement3))
		{
			if (((Transform)menuSelectableElement2.rectTransform).position.x > ((Transform)menuSelectableElement3.rectTransform).position.x)
			{
				MenuSelectableElement menuSelectableElement4 = menuSelectableElement3;
				MenuSelectableElement menuSelectableElement5 = menuSelectableElement2;
				menuSelectableElement2 = menuSelectableElement4;
				menuSelectableElement3 = menuSelectableElement5;
			}
			LinkExplicit((Selectable)(object)menuSelectableElement, null, (Selectable)(object)menuSelectableElement3);
			LinkExplicit((Selectable)(object)menuSelectableElement2, (Selectable)(object)menuSelectableElement, null, null, (Selectable)(object)menuSelectableElement3);
			LinkExplicit((Selectable)(object)menuSelectableElement3, (Selectable)(object)menuSelectableElement, null, (Selectable)(object)menuSelectableElement2);
		}
	}

	private void LinkExplicit(Selectable selectable, Selectable up = null, Selectable down = null, Selectable left = null, Selectable right = null)
	{
		//IL_0001: Unknown result type (might be due to invalid IL or missing references)
		//IL_0006: Unknown result type (might be due to invalid IL or missing references)
		//IL_0054: Unknown result type (might be due to invalid IL or missing references)
		Navigation navigation = selectable.navigation;
		navigation.mode = (Mode)4;
		if (Object.op_Implicit((Object)(object)up))
		{
			navigation.selectOnUp = up;
		}
		if (Object.op_Implicit((Object)(object)down))
		{
			navigation.selectOnDown = down;
		}
		if (Object.op_Implicit((Object)(object)left))
		{
			navigation.selectOnLeft = left;
		}
		if (Object.op_Implicit((Object)(object)right))
		{
			navigation.selectOnRight = right;
		}
		selectable.navigation = navigation;
	}

	private void Update()
	{
		if (SemiFunc.InputDown(InputKey.Back) && menuPage.isInteractable)
		{
			ButtonEventCancel();
		}
		if (menuPage.isInteractable && (Input.GetKeyDown((KeyCode)13) || Input.GetKeyDown((KeyCode)271)) && (!MenuManager.instance.isKeyboardNavigating || MenuManager.instance.currentMenuID == menuTextInput.menuSelectableElement.menuID))
		{
			ButtonEventConfirm();
		}
		if (((TMP_Text)confirmButton.buttonText).text != confirmButton.buttonTextString)
		{
			((TMP_Text)confirmButton.buttonText).text = confirmButton.buttonTextString;
		}
	}

	private void OnDestroy()
	{
	}

	public void ButtonEventConfirm()
	{
		if (!allowEmpty && string.IsNullOrWhiteSpace(menuTextInput.textCurrent))
		{
			confirmButton.OnHovering();
			MenuManager.instance.MenuEffectClick(MenuManager.MenuClickEffectType.Deny, null, 1f, 1f);
			return;
		}
		string textCurrent = menuTextInput.textCurrent;
		MenuManager.instance.MenuEffectClick(MenuManager.MenuClickEffectType.Confirm, null, 1f, 1f);
		MenuManager.instance.PageReactivatePageUnderThisPage(menuPage);
		menuPage.PageStateSet(MenuPage.PageState.Closing);
		if (confirmEvent != null)
		{
			confirmEvent.Invoke(textCurrent);
		}
	}

	public void ButtonEventCancel()
	{
		MenuManager.instance.PageReactivatePageUnderThisPage(menuPage);
		menuPage.PageStateSet(MenuPage.PageState.Closing);
		if (cancelEvent != null)
		{
			cancelEvent.Invoke();
		}
	}
}
