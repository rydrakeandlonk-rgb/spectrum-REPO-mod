using System.Collections.Generic;
using Photon.Pun;
using Photon.Realtime;
using TMPro;
using UnityEngine;

public class MenuPageEsc : MonoBehaviour
{
	public static MenuPageEsc instance;

	internal MenuPage menuPage;

	public GameObject playerMicrophoneVolumeSliderPrefab;

	internal Dictionary<Player, MenuSliderPlayerMicGain> playerMicGainSliders = new Dictionary<Player, MenuSliderPlayerMicGain>();

	public RectTransform mainMenuRectTransform;

	public GameObject moonsObject;

	public MenuButton customizeButton;

	public MenuElementCosmeticHighlight customizeHighlightObj;

	public MenuButton quitButton;

	[RuntimeInitializeOnLoadMethod(/*Could not decode attribute arguments.*/)]
	private static void RuntimeInitializeOnLoad()
	{
		instance = null;
	}

	private void Start()
	{
		//IL_002a: Unknown result type (might be due to invalid IL or missing references)
		instance = this;
		menuPage = ((Component)this).GetComponent<MenuPage>();
		PlayerGainSlidersUpdate();
		UpdateMenuButtonPosition();
		UpdateHighlight();
		SemiFunc.MenuNavigationBlock(quitButton, Vector2.down);
	}

	private void Update()
	{
		if (SemiFunc.MenuLevel())
		{
			menuPage.PageStateSet(MenuPage.PageState.Closing);
		}
		if (SemiFunc.InputDown(InputKey.Back) && menuPage.isInteractable && menuPage.currentPageState != MenuPage.PageState.Closing)
		{
			ButtonEventContinue();
		}
	}

	public void ButtonEventContinue()
	{
		menuPage.PageStateSet(MenuPage.PageState.Closing);
	}

	public void PlayerGainSlidersUpdate()
	{
		//IL_0105: Unknown result type (might be due to invalid IL or missing references)
		//IL_0116: Unknown result type (might be due to invalid IL or missing references)
		//IL_0137: Unknown result type (might be due to invalid IL or missing references)
		//IL_013c: Unknown result type (might be due to invalid IL or missing references)
		List<Player> list = new List<Player>();
		foreach (Player key in playerMicGainSliders.Keys)
		{
			if (key == null || !Object.op_Implicit((Object)(object)playerMicGainSliders[key]))
			{
				list.Add(key);
			}
		}
		foreach (Player item in list)
		{
			playerMicGainSliders.Remove(item);
		}
		Player[] playerList = PhotonNetwork.PlayerList;
		foreach (Player val in playerList)
		{
			if (!playerMicGainSliders.ContainsKey(val) && !val.IsLocal)
			{
				PlayerAvatar playerAvatar = SemiFunc.PlayerAvatarGetFromPhotonPlayer(val);
				float num = 375f;
				if (SemiFunc.IsMasterClient())
				{
					num = 400f;
				}
				GameObject val2 = Object.Instantiate<GameObject>(playerMicrophoneVolumeSliderPrefab, ((Component)this).transform);
				val2.transform.localPosition = new Vector3(num, 21f, 0f);
				Transform transform = val2.transform;
				transform.localPosition += new Vector3(0f, 25f * (float)playerMicGainSliders.Count, 0f);
				MenuSliderPlayerMicGain component = val2.GetComponent<MenuSliderPlayerMicGain>();
				component.playerPhoton = val;
				component.playerAvatar = playerAvatar;
				component.SliderNameSet(Object.op_Implicit((Object)(object)playerAvatar) ? playerAvatar.playerName : val.NickName);
				playerMicGainSliders.Add(val, component);
			}
		}
	}

	public void ButtonEventSelfDestruct()
	{
		if (SemiFunc.IsMultiplayer())
		{
			ChatManager.instance.PossessSelfDestruction();
		}
		else
		{
			PlayerAvatar.instance.playerHealth.Hurt(PlayerAvatar.instance.playerHealth.health, savingGrace: false);
		}
		MenuManager.instance.PageCloseAll();
	}

	public void ButtonEventQuit()
	{
		RunManager.instance.skipLoadingUI = true;
		foreach (PlayerAvatar player in GameDirector.instance.PlayerList)
		{
			player.quitApplication = true;
		}
		GameDirector.instance.OutroStart();
		ResultScreenUI.instance.Disable();
	}

	public void ButtonEventQuitToMenu()
	{
		GameDirector.instance.OutroStart();
		ResultScreenUI.instance.Disable();
		NetworkManager.instance.leavePhotonRoom = true;
	}

	public void ButtonEventChangeColor()
	{
		if (Object.op_Implicit((Object)(object)MetaManager.instance) && MetaManager.instance.saveReady)
		{
			MenuManager.instance.PageSwap(MenuPageIndex.Cosmetics);
		}
	}

	public void ButtonEventSettings()
	{
		MenuManager.instance.PageSwap(MenuPageIndex.Settings);
	}

	public void ButtonEventMoons()
	{
		MenuManager.instance.PageSwap(MenuPageIndex.Moons);
	}

	public void UpdateMenuButtonPosition()
	{
		//IL_0026: Unknown result type (might be due to invalid IL or missing references)
		//IL_0036: Unknown result type (might be due to invalid IL or missing references)
		//IL_0046: Unknown result type (might be due to invalid IL or missing references)
		if (RunManager.instance.moonLevel < 1)
		{
			moonsObject.SetActive(false);
			mainMenuRectTransform.anchoredPosition = new Vector2(mainMenuRectTransform.anchoredPosition.x, mainMenuRectTransform.anchoredPosition.y + 32f);
		}
	}

	public void UpdateHighlight()
	{
		//IL_00b8: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e1: Unknown result type (might be due to invalid IL or missing references)
		//IL_00cb: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e6: Unknown result type (might be due to invalid IL or missing references)
		//IL_010a: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f4: Unknown result type (might be due to invalid IL or missing references)
		//IL_010f: Unknown result type (might be due to invalid IL or missing references)
		if (!Object.op_Implicit((Object)(object)customizeHighlightObj))
		{
			return;
		}
		int num = 0;
		for (int i = 0; i < MetaManager.instance.cosmeticAssets.Count; i++)
		{
			if (!MetaManager.instance.cosmeticHistory.Contains(i) && MetaManager.instance.cosmeticUnlocks.Contains(i))
			{
				CosmeticAsset cosmeticAsset = MetaManager.instance.cosmeticAssets[i];
				if (Object.op_Implicit((Object)(object)cosmeticAsset) && cosmeticAsset.prefab.IsValid())
				{
					num++;
				}
			}
		}
		bool flag = num > 0;
		((TMP_Text)customizeHighlightObj.text).text = num.ToString();
		((TMP_Text)customizeButton.buttonText).margin = new Vector4(10f, 0f, (float)(flag ? 25 : 10), 0f);
		customizeButton.colorNormal = (Color)(flag ? new Color(1f, 0.55f, 0f) : Color.gray);
		customizeButton.colorHover = (Color)(flag ? new Color(1f, 0.9f, 0f) : Color.white);
	}
}
