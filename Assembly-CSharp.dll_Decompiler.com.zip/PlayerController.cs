using System;
using System.Collections;
using System.Collections.Generic;
using Photon.Pun;
using UnityEngine;

public class PlayerController : MonoBehaviour
{
	public static PlayerController instance;

	private bool previousCrouchingState;

	private bool previousCrawlingState;

	private bool previousSprintingState;

	private bool previousSlidingState;

	private bool previousMovingState;

	public GameObject playerAvatar;

	public GameObject playerAvatarPrefab;

	public PlayerCollision PlayerCollision;

	[HideInInspector]
	public GameObject physGrabObject;

	[HideInInspector]
	public bool physGrabActive;

	[HideInInspector]
	public Transform physGrabPoint;

	[Space]
	public PlayerCollisionController CollisionController;

	public PlayerCollisionGrounded CollisionGrounded;

	private bool GroundedPrevious;

	public Materials.MaterialTrigger MaterialTrigger;

	[HideInInspector]
	public Rigidbody rb;

	private bool CanLand;

	private float landCooldown;

	[Space]
	public float MoveSpeed = 0.5f;

	public float MoveFriction = 5f;

	[HideInInspector]
	public Vector3 Velocity;

	[HideInInspector]
	public Vector3 VelocityRelative;

	private Vector3 VelocityRelativeNew;

	private bool VelocityIdle;

	private Vector3 VelocityImpulse = Vector3.zero;

	private Vector3 platformVelocity = Vector3.zero;

	private float platformVelocityTimer;

	[Space]
	public float SprintSpeed = 1f;

	public float SprintSpeedUpgrades;

	private float SprintSpeedCurrent = 1f;

	[HideInInspector]
	public float SprintSpeedLerp;

	public float SprintAcceleration = 1f;

	private float SprintedTimer;

	private float SprintDrainTimer;

	[Space]
	public float CrouchSpeed = 1f;

	public float CrouchTimeMin = 0.2f;

	private float CrouchActiveTimer;

	private float CrouchInactiveTimer;

	[Space]
	public float SlideTime = 1f;

	public float SlideDecay = 0.1f;

	private float SlideTimer;

	private Vector3 SlideDirection;

	private Vector3 SlideDirectionCurrent;

	internal bool CanSlide;

	[HideInInspector]
	public bool Sliding;

	[Space]
	public float JumpForce = 20f;

	internal int JumpExtra;

	private int JumpExtraCurrent;

	private bool JumpFirst;

	public float CustomGravity = 20f;

	internal bool JumpImpulse;

	private float JumpCooldown;

	private float JumpGroundedBuffer;

	internal List<PhysGrabObject> JumpGroundedObjects = new List<PhysGrabObject>();

	private float JumpInputBuffer;

	private float OverrideJumpCooldownAmount;

	private float OverrideJumpCooldownCurrent;

	private float OverrideJumpCooldownTimer;

	public float StepUpForce = 2f;

	public bool DebugNoTumble;

	public bool DebugDisableOvercharge;

	[Space]
	public bool DebugEnergy;

	public float EnergyStart = 100f;

	[HideInInspector]
	public float EnergyCurrent;

	public float EnergySprintDrain = 1f;

	internal float sprintRechargeTimer;

	private float sprintRechargeTime = 1f;

	private float sprintRechargeAmount = 2f;

	[Space(15f)]
	public CameraAim cameraAim;

	public GameObject cameraGameObject;

	public GameObject cameraGameObjectLocal;

	public Transform VisionTarget;

	[HideInInspector]
	public bool CanInteract;

	[HideInInspector]
	public bool moving;

	private float movingResetTimer;

	[HideInInspector]
	public bool sprinting;

	[HideInInspector]
	public bool Crouching;

	[HideInInspector]
	public bool Crawling;

	[HideInInspector]
	public Vector3 InputDirection;

	[HideInInspector]
	public Vector3 InputDirectionRaw;

	[HideInInspector]
	public float InputAnalogAmount = 1f;

	public float analogMovementMinSpeed = 0.1f;

	[HideInInspector]
	public AudioSource AudioSource;

	private float crouchOverrideTimer;

	private Vector3 positionPrevious;

	private Vector3 MoveForceDirection = Vector3.zero;

	private float MoveForceAmount;

	private float MoveForceTimer;

	internal float InputDisableTimer;

	private float MoveMultiplier = 1f;

	private float MoveMultiplierTimer;

	internal string playerName;

	internal string playerSteamID;

	private float overrideSpeedTimer;

	internal float overrideSpeedMultiplier = 1f;

	private float overrideSpeedSprintCap = -1f;

	private float overrideLookSpeedTimer;

	internal float overrideLookSpeedTarget = 1f;

	private float overrideLookSpeedTimeIn = 15f;

	private float overrideLookSpeedTimeOut = 0.3f;

	private float overrideLookSpeedLerp;

	private float overrideLookSpeedProgress;

	private float overrideVoicePitchTimer;

	internal float overrideVoicePitchMultiplier = 1f;

	private float overrideTimeScaleTimer;

	internal float overrideTimeScaleMultiplier = 1f;

	private float overrideDisableTurnTimer;

	private Quaternion overrideResetTurnPosition;

	private bool overrideResetTurn;

	internal float overrideTurnRotationTimer;

	private Quaternion overrideTurnRotation;

	private Vector3 originalVelocity;

	private Vector3 originalAngularVelocity;

	public PlayerAvatar playerAvatarScript;

	[Space]
	public Collider col;

	public PhysicsMaterial PhysicMaterialMove;

	public PhysicsMaterial PhysicMaterialIdle;

	internal float antiGravityTimer;

	internal float featherTimer;

	internal float deathSeenTimer;

	internal float tumbleInputDisableTimer;

	private float kinematicTimer;

	private bool toggleSprint;

	private bool toggleCrouch;

	private float rbOriginalMass;

	private float rbOriginalDrag;

	private float playerOriginalMoveSpeed;

	private float playerOriginalCustomGravity;

	internal float playerOriginalSprintSpeed;

	private float playerOriginalCrouchSpeed;

	internal bool debugSlow;

	[RuntimeInitializeOnLoadMethod(/*Could not decode attribute arguments.*/)]
	private static void RuntimeInitializeOnLoad()
	{
		instance = null;
	}

	private void Awake()
	{
		instance = this;
	}

	public void PlayerSetName(string _playerName, string _steamID)
	{
		playerName = _playerName;
		playerSteamID = _steamID;
	}

	public void MoveForce(Vector3 direction, float amount, float time)
	{
		//IL_0003: Unknown result type (might be due to invalid IL or missing references)
		//IL_0008: Unknown result type (might be due to invalid IL or missing references)
		MoveForceDirection = direction.normalized;
		MoveForceAmount = amount;
		MoveForceTimer = time;
	}

	public void InputDisable(float time)
	{
		InputDisableTimer = time;
	}

	public void MoveMult(float multiplier, float time)
	{
		MoveMultiplier = multiplier;
		MoveMultiplierTimer = time;
	}

	public void CrouchDisable(float time)
	{
		CrouchInactiveTimer = Mathf.Max(time, CrouchInactiveTimer);
	}

	private void OnCollisionEnter(Collision other)
	{
		if (GameManager.instance.gameMode != 0 && !PhotonNetwork.IsMasterClient && other.gameObject.CompareTag("Phys Grab Object"))
		{
			playerAvatarScript.photonView.RPC("ResetPhysPusher", (RpcTarget)2, Array.Empty<object>());
		}
	}

	private void Start()
	{
		//IL_0041: Unknown result type (might be due to invalid IL or missing references)
		//IL_0046: Unknown result type (might be due to invalid IL or missing references)
		//IL_0078: Unknown result type (might be due to invalid IL or missing references)
		//IL_007d: Unknown result type (might be due to invalid IL or missing references)
		rb = ((Component)this).GetComponent<Rigidbody>();
		rbOriginalMass = rb.mass;
		rbOriginalDrag = rb.linearDamping;
		AudioSource = ((Component)this).GetComponent<AudioSource>();
		positionPrevious = ((Component)this).transform.position;
		Inventory component = ((Component)this).GetComponent<Inventory>();
		if (SemiFunc.RunIsArena())
		{
			((Behaviour)component).enabled = false;
		}
		if (GameManager.instance.gameMode == 0)
		{
			Object.Instantiate<GameObject>(playerAvatarPrefab, ((Component)this).transform.position, Quaternion.identity);
		}
		((MonoBehaviour)this).StartCoroutine(LateStart());
		if (Object.op_Implicit((Object)(object)DebugCommandHandler.instance) && DebugCommandHandler.instance.infiniteEnergy)
		{
			if (SemiFunc.IsMainMenu())
			{
				DebugCommandHandler.instance.infiniteEnergy = false;
			}
			else
			{
				DebugEnergy = true;
			}
		}
	}

	private IEnumerator LateStart()
	{
		while (!LevelGenerator.Instance.Generated)
		{
			yield return null;
		}
		yield return (object)new WaitForSeconds(0.2f);
		string key = SemiFunc.PlayerGetSteamID(playerAvatarScript);
		EnergyStart += (float)StatsManager.instance.playerUpgradeStamina.GetValueOrDefault(key, 0) * 10f;
		JumpExtra = StatsManager.instance.playerUpgradeExtraJump.GetValueOrDefault(key, 0);
		int valueOrDefault = StatsManager.instance.playerUpgradeSpeed.GetValueOrDefault(key, 0);
		SprintSpeed += valueOrDefault;
		SprintSpeedUpgrades += valueOrDefault;
		EnergyCurrent = EnergyStart;
		playerOriginalMoveSpeed = MoveSpeed;
		playerOriginalSprintSpeed = SprintSpeed;
		playerOriginalCrouchSpeed = CrouchSpeed;
		playerOriginalCustomGravity = CustomGravity;
		if (SemiFunc.MenuLevel())
		{
			rb.isKinematic = true;
			((Component)this).gameObject.SetActive(false);
		}
	}

	public void ChangeState()
	{
		playerAvatarScript.UpdateState(Crouching, sprinting, Crawling, Sliding, moving);
	}

	public void ForceImpulse(Vector3 force)
	{
		//IL_0002: Unknown result type (might be due to invalid IL or missing references)
		//IL_000d: Unknown result type (might be due to invalid IL or missing references)
		//IL_000e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0013: Unknown result type (might be due to invalid IL or missing references)
		//IL_0018: Unknown result type (might be due to invalid IL or missing references)
		VelocityImpulse += ((Component)this).transform.InverseTransformDirection(force);
	}

	public void OverridePlatformVelocity(Vector3 _velocity)
	{
		//IL_0001: Unknown result type (might be due to invalid IL or missing references)
		//IL_0002: Unknown result type (might be due to invalid IL or missing references)
		platformVelocity = _velocity;
		platformVelocityTimer = 0.1f;
	}

	private Vector3 PlatformVelocityHorizontal()
	{
		//IL_002e: Unknown result type (might be due to invalid IL or missing references)
		//IL_000d: Unknown result type (might be due to invalid IL or missing references)
		if (platformVelocityTimer <= 0f)
		{
			return Vector3.zero;
		}
		return new Vector3(platformVelocity.x, 0f, platformVelocity.z);
	}

	private void PlatformCarryIdle(Vector3 _platformVelocityHorizontal)
	{
		//IL_0016: Unknown result type (might be due to invalid IL or missing references)
		//IL_002b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0035: Unknown result type (might be due to invalid IL or missing references)
		//IL_0040: Unknown result type (might be due to invalid IL or missing references)
		//IL_0041: Unknown result type (might be due to invalid IL or missing references)
		//IL_0042: Unknown result type (might be due to invalid IL or missing references)
		if (!(platformVelocityTimer <= 0f))
		{
			Vector3 val = new Vector3(rb.linearVelocity.x, 0f, rb.linearVelocity.z);
			rb.AddForce(_platformVelocityHorizontal - val, (ForceMode)2);
		}
	}

	public void AntiGravity(float _timer)
	{
		antiGravityTimer = _timer;
	}

	public void Feather(float _timer)
	{
		featherTimer = _timer;
	}

	public void Kinematic(float _timer)
	{
		kinematicTimer = _timer;
		rb.isKinematic = true;
		rb.collisionDetectionMode = (CollisionDetectionMode)0;
	}

	public void SetCrawl()
	{
		Crouching = true;
		Crawling = true;
		CrouchActiveTimer = CrouchTimeMin;
		sprinting = false;
		Sliding = false;
		moving = false;
		if (Object.op_Implicit((Object)(object)PlayerCollisionStand.instance))
		{
			PlayerCollisionStand.instance.SetBlocked();
		}
		if (Object.op_Implicit((Object)(object)CameraCrouchPosition.instance))
		{
			CameraCrouchPosition.instance.Lerp = 1f;
			CameraCrouchPosition.instance.Active = true;
			CameraCrouchPosition.instance.ActivePrev = true;
		}
		ChangeState();
	}

	public void OverrideSpeed(float _speedMulti, float _time = 0.1f, float _sprintCap = -1f)
	{
		overrideSpeedTimer = _time;
		overrideSpeedMultiplier = _speedMulti;
		overrideSpeedSprintCap = _sprintCap;
	}

	private void OverrideSpeedTick()
	{
		if (overrideSpeedTimer > 0f)
		{
			overrideSpeedTimer -= Time.fixedDeltaTime;
			if (overrideSpeedTimer <= 0f)
			{
				overrideSpeedMultiplier = 1f;
				overrideSpeedSprintCap = -1f;
				MoveSpeed = playerOriginalMoveSpeed;
				SprintSpeed = playerOriginalSprintSpeed;
				CrouchSpeed = playerOriginalCrouchSpeed;
			}
		}
	}

	private void OverrideSpeedLogic()
	{
		if (!(overrideSpeedTimer <= 0f))
		{
			MoveSpeed = playerOriginalMoveSpeed * overrideSpeedMultiplier;
			SprintSpeed = playerOriginalSprintSpeed * overrideSpeedMultiplier;
			CrouchSpeed = playerOriginalCrouchSpeed * overrideSpeedMultiplier;
			if (overrideSpeedSprintCap > 0f)
			{
				float num = Mathf.Min(SprintSpeed, overrideSpeedSprintCap);
				SprintSpeed = Mathf.Max(playerOriginalSprintSpeed, num);
			}
		}
	}

	public void OverrideAnimationSpeed(float _animSpeedMulti, float _timeIn, float _timeOut, float _time = 0.1f)
	{
		playerAvatarScript.OverrideAnimationSpeed(_animSpeedMulti, _timeIn, _timeOut, _time);
	}

	public void OverrideTimeScale(float _timeScaleMulti, float _time = 0.1f)
	{
		overrideTimeScaleTimer = _time;
		overrideTimeScaleMultiplier = _timeScaleMulti;
	}

	private void OverrideTimeScaleTick()
	{
		if (overrideTimeScaleTimer > 0f)
		{
			overrideTimeScaleTimer -= Time.fixedDeltaTime;
			if (overrideTimeScaleTimer <= 0f)
			{
				overrideTimeScaleMultiplier = 1f;
				rb.mass = rbOriginalMass;
				rb.linearDamping = rbOriginalDrag;
				CustomGravity = playerOriginalCustomGravity;
				MoveSpeed = playerOriginalMoveSpeed;
				SprintSpeed = playerOriginalSprintSpeed;
				CrouchSpeed = playerOriginalCrouchSpeed;
				rb.useGravity = true;
			}
		}
	}

	private void OverrideTimeScaleLogic()
	{
		//IL_002b: Unknown result type (might be due to invalid IL or missing references)
		//IL_003c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0047: Unknown result type (might be due to invalid IL or missing references)
		//IL_004d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0063: Unknown result type (might be due to invalid IL or missing references)
		//IL_0074: Unknown result type (might be due to invalid IL or missing references)
		//IL_007e: Unknown result type (might be due to invalid IL or missing references)
		//IL_008e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0099: Unknown result type (might be due to invalid IL or missing references)
		//IL_009f: Unknown result type (might be due to invalid IL or missing references)
		if (!(overrideTimeScaleTimer <= 0f))
		{
			float num = overrideSpeedMultiplier;
			if (!rb.isKinematic)
			{
				float y = rb.linearVelocity.y;
				rb.linearVelocity = Vector3.Lerp(Vector3.zero, rb.linearVelocity, num);
				rb.linearVelocity = new Vector3(rb.linearVelocity.x, y, rb.linearVelocity.z);
				rb.angularVelocity = Vector3.Lerp(Vector3.zero, rb.angularVelocity, num);
			}
			rb.mass = Mathf.Lerp(0.01f, rbOriginalMass, num);
			rb.linearDamping = Mathf.Lerp((1f + overrideSpeedMultiplier) * 10f, rbOriginalDrag, num);
			CustomGravity = Mathf.Lerp(0.1f, playerOriginalCustomGravity, num);
			MoveSpeed = Mathf.Lerp(0.1f, playerOriginalMoveSpeed, num);
			SprintSpeed = Mathf.Lerp(0.1f, playerOriginalSprintSpeed, num);
			CrouchSpeed = Mathf.Lerp(0.1f, playerOriginalCrouchSpeed, num);
			rb.useGravity = false;
		}
	}

	public void OverrideLookSpeed(float _lookSpeedTarget, float timeIn, float timeOut, float _time = 0.1f)
	{
		overrideLookSpeedTimer = _time;
		overrideLookSpeedTarget = _lookSpeedTarget;
		overrideLookSpeedTimeIn = timeIn;
		overrideLookSpeedTimeOut = timeOut;
	}

	private void OverrideLookSpeedTick()
	{
		if (overrideLookSpeedTimer > 0f)
		{
			overrideLookSpeedTimer -= Time.fixedDeltaTime;
		}
	}

	private void OverrideLookSpeedLogic()
	{
		if (overrideLookSpeedTimer <= 0f && overrideLookSpeedProgress <= 0f)
		{
			return;
		}
		float smooth;
		if (overrideLookSpeedTimer > 0f)
		{
			overrideLookSpeedProgress += Time.fixedDeltaTime / overrideLookSpeedTimeIn;
			overrideLookSpeedProgress = Mathf.Clamp01(overrideLookSpeedProgress);
			overrideLookSpeedLerp = Mathf.SmoothStep(0f, 1f, overrideLookSpeedProgress);
			smooth = Mathf.Lerp(cameraAim.aimSmoothOriginal, overrideLookSpeedTarget, overrideLookSpeedLerp);
		}
		else
		{
			overrideLookSpeedProgress -= Time.fixedDeltaTime / overrideLookSpeedTimeOut;
			overrideLookSpeedProgress = Mathf.Clamp01(overrideLookSpeedProgress);
			overrideLookSpeedLerp = Mathf.SmoothStep(0f, 1f, overrideLookSpeedProgress);
			smooth = Mathf.Lerp(cameraAim.aimSmoothOriginal, overrideLookSpeedTarget, overrideLookSpeedLerp);
			if (overrideLookSpeedProgress <= 0f)
			{
				smooth = cameraAim.aimSmoothOriginal;
			}
		}
		cameraAim.OverrideAimSmooth(smooth, 0.1f);
	}

	public void OverrideVoicePitch(float _voicePitchMulti, float _timeIn, float _timeOut, float _time = 0.1f)
	{
		if (Object.op_Implicit((Object)(object)playerAvatarScript.voiceChat))
		{
			playerAvatarScript.voiceChat.OverridePitch(_voicePitchMulti, _timeIn, _timeOut, _time);
		}
	}

	private void OverrideVoicePitchTick()
	{
		if (overrideVoicePitchTimer > 0f)
		{
			overrideVoicePitchTimer -= Time.fixedDeltaTime;
			if (overrideVoicePitchTimer <= 0f)
			{
				overrideVoicePitchMultiplier = 1f;
			}
		}
	}

	public void OverrideJumpCooldown(float _cooldown)
	{
		OverrideJumpCooldownAmount = _cooldown;
		OverrideJumpCooldownTimer = 0.1f;
	}

	public void OverrideDisableTurn(float _time = 0.1f, bool _reset = false)
	{
		//IL_0055: Unknown result type (might be due to invalid IL or missing references)
		//IL_005a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0035: Unknown result type (might be due to invalid IL or missing references)
		if (_time <= 0f)
		{
			overrideDisableTurnTimer = _time;
			playerAvatarScript.rotationDisabled = overrideDisableTurnTimer > 0f;
			if (overrideResetTurn)
			{
				CameraAim.Instance.SetPlayerAim(overrideResetTurnPosition, _setRotation: true);
			}
			return;
		}
		if (overrideDisableTurnTimer <= 0f)
		{
			overrideResetTurnPosition = ((Component)this).transform.rotation;
		}
		overrideResetTurn = _reset;
		overrideDisableTurnTimer = _time;
		playerAvatarScript.rotationDisabled = true;
	}

	public void OverrideTurnRotation(Quaternion _rotation, float _time = 0.1f)
	{
		//IL_0001: Unknown result type (might be due to invalid IL or missing references)
		//IL_0002: Unknown result type (might be due to invalid IL or missing references)
		overrideTurnRotation = _rotation;
		overrideTurnRotationTimer = _time;
		playerAvatarScript.rotationOverrideActive = overrideTurnRotationTimer > 0f;
	}

	private void FixedUpdate()
	{
		//IL_0036: Unknown result type (might be due to invalid IL or missing references)
		//IL_003b: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b9: Unknown result type (might be due to invalid IL or missing references)
		//IL_00be: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c8: Unknown result type (might be due to invalid IL or missing references)
		//IL_00cd: Unknown result type (might be due to invalid IL or missing references)
		//IL_0187: Unknown result type (might be due to invalid IL or missing references)
		//IL_018c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0190: Unknown result type (might be due to invalid IL or missing references)
		//IL_019f: Unknown result type (might be due to invalid IL or missing references)
		//IL_01a4: Unknown result type (might be due to invalid IL or missing references)
		//IL_023d: Unknown result type (might be due to invalid IL or missing references)
		//IL_01de: Unknown result type (might be due to invalid IL or missing references)
		//IL_01e3: Unknown result type (might be due to invalid IL or missing references)
		//IL_022a: Unknown result type (might be due to invalid IL or missing references)
		//IL_027c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0281: Unknown result type (might be due to invalid IL or missing references)
		//IL_051e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0523: Unknown result type (might be due to invalid IL or missing references)
		//IL_0533: Unknown result type (might be due to invalid IL or missing references)
		//IL_0538: Unknown result type (might be due to invalid IL or missing references)
		//IL_0556: Unknown result type (might be due to invalid IL or missing references)
		//IL_0561: Unknown result type (might be due to invalid IL or missing references)
		//IL_0868: Unknown result type (might be due to invalid IL or missing references)
		//IL_086d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0590: Unknown result type (might be due to invalid IL or missing references)
		//IL_0595: Unknown result type (might be due to invalid IL or missing references)
		//IL_0599: Unknown result type (might be due to invalid IL or missing references)
		//IL_059e: Unknown result type (might be due to invalid IL or missing references)
		//IL_05a5: Unknown result type (might be due to invalid IL or missing references)
		//IL_05aa: Unknown result type (might be due to invalid IL or missing references)
		//IL_0602: Unknown result type (might be due to invalid IL or missing references)
		//IL_060d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0612: Unknown result type (might be due to invalid IL or missing references)
		//IL_0631: Unknown result type (might be due to invalid IL or missing references)
		//IL_0636: Unknown result type (might be due to invalid IL or missing references)
		//IL_05ca: Unknown result type (might be due to invalid IL or missing references)
		//IL_05cf: Unknown result type (might be due to invalid IL or missing references)
		//IL_092e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0930: Unknown result type (might be due to invalid IL or missing references)
		//IL_0935: Unknown result type (might be due to invalid IL or missing references)
		//IL_093a: Unknown result type (might be due to invalid IL or missing references)
		//IL_093d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0943: Unknown result type (might be due to invalid IL or missing references)
		//IL_0948: Unknown result type (might be due to invalid IL or missing references)
		//IL_094d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0953: Unknown result type (might be due to invalid IL or missing references)
		//IL_0958: Unknown result type (might be due to invalid IL or missing references)
		//IL_0667: Unknown result type (might be due to invalid IL or missing references)
		//IL_0672: Unknown result type (might be due to invalid IL or missing references)
		//IL_0677: Unknown result type (might be due to invalid IL or missing references)
		//IL_0970: Unknown result type (might be due to invalid IL or missing references)
		//IL_0975: Unknown result type (might be due to invalid IL or missing references)
		//IL_0982: Unknown result type (might be due to invalid IL or missing references)
		//IL_0987: Unknown result type (might be due to invalid IL or missing references)
		//IL_0966: Unknown result type (might be due to invalid IL or missing references)
		//IL_0967: Unknown result type (might be due to invalid IL or missing references)
		//IL_06ce: Unknown result type (might be due to invalid IL or missing references)
		//IL_06d0: Unknown result type (might be due to invalid IL or missing references)
		//IL_06db: Unknown result type (might be due to invalid IL or missing references)
		//IL_06e0: Unknown result type (might be due to invalid IL or missing references)
		//IL_06e5: Unknown result type (might be due to invalid IL or missing references)
		//IL_06e8: Unknown result type (might be due to invalid IL or missing references)
		//IL_06f3: Unknown result type (might be due to invalid IL or missing references)
		//IL_06f8: Unknown result type (might be due to invalid IL or missing references)
		//IL_06ff: Unknown result type (might be due to invalid IL or missing references)
		//IL_0704: Unknown result type (might be due to invalid IL or missing references)
		//IL_098d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0992: Unknown result type (might be due to invalid IL or missing references)
		//IL_099f: Unknown result type (might be due to invalid IL or missing references)
		//IL_09a4: Unknown result type (might be due to invalid IL or missing references)
		//IL_09a5: Unknown result type (might be due to invalid IL or missing references)
		//IL_09aa: Unknown result type (might be due to invalid IL or missing references)
		//IL_09af: Unknown result type (might be due to invalid IL or missing references)
		//IL_0a61: Unknown result type (might be due to invalid IL or missing references)
		//IL_0a66: Unknown result type (might be due to invalid IL or missing references)
		//IL_0a72: Unknown result type (might be due to invalid IL or missing references)
		//IL_0a77: Unknown result type (might be due to invalid IL or missing references)
		//IL_0a7d: Unknown result type (might be due to invalid IL or missing references)
		//IL_09df: Unknown result type (might be due to invalid IL or missing references)
		//IL_09e5: Unknown result type (might be due to invalid IL or missing references)
		//IL_09f6: Unknown result type (might be due to invalid IL or missing references)
		//IL_09fb: Unknown result type (might be due to invalid IL or missing references)
		//IL_0a06: Unknown result type (might be due to invalid IL or missing references)
		//IL_0a18: Unknown result type (might be due to invalid IL or missing references)
		//IL_0a1d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0a1e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0a31: Unknown result type (might be due to invalid IL or missing references)
		//IL_0a36: Unknown result type (might be due to invalid IL or missing references)
		//IL_0a37: Unknown result type (might be due to invalid IL or missing references)
		//IL_0a3c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0a41: Unknown result type (might be due to invalid IL or missing references)
		//IL_0846: Unknown result type (might be due to invalid IL or missing references)
		//IL_0848: Unknown result type (might be due to invalid IL or missing references)
		//IL_0853: Unknown result type (might be due to invalid IL or missing references)
		//IL_0858: Unknown result type (might be due to invalid IL or missing references)
		//IL_085d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0832: Unknown result type (might be due to invalid IL or missing references)
		//IL_083c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0841: Unknown result type (might be due to invalid IL or missing references)
		//IL_0791: Unknown result type (might be due to invalid IL or missing references)
		//IL_0793: Unknown result type (might be due to invalid IL or missing references)
		//IL_0798: Unknown result type (might be due to invalid IL or missing references)
		//IL_079d: Unknown result type (might be due to invalid IL or missing references)
		//IL_07a0: Unknown result type (might be due to invalid IL or missing references)
		//IL_07a6: Unknown result type (might be due to invalid IL or missing references)
		//IL_07b1: Unknown result type (might be due to invalid IL or missing references)
		//IL_07bb: Unknown result type (might be due to invalid IL or missing references)
		//IL_07c0: Unknown result type (might be due to invalid IL or missing references)
		//IL_07c5: Unknown result type (might be due to invalid IL or missing references)
		//IL_080e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0810: Unknown result type (might be due to invalid IL or missing references)
		//IL_081b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0820: Unknown result type (might be due to invalid IL or missing references)
		//IL_0825: Unknown result type (might be due to invalid IL or missing references)
		//IL_07fa: Unknown result type (might be due to invalid IL or missing references)
		//IL_0804: Unknown result type (might be due to invalid IL or missing references)
		//IL_0809: Unknown result type (might be due to invalid IL or missing references)
		//IL_0b1e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0aee: Unknown result type (might be due to invalid IL or missing references)
		//IL_0d65: Unknown result type (might be due to invalid IL or missing references)
		//IL_0d6a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0bd8: Unknown result type (might be due to invalid IL or missing references)
		//IL_0be7: Unknown result type (might be due to invalid IL or missing references)
		//IL_0d16: Unknown result type (might be due to invalid IL or missing references)
		//IL_0c0c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0c13: Unknown result type (might be due to invalid IL or missing references)
		//IL_0c18: Unknown result type (might be due to invalid IL or missing references)
		//IL_0c1a: Unknown result type (might be due to invalid IL or missing references)
		if (GameDirector.instance.currentState != GameDirector.gameState.Main)
		{
			return;
		}
		OverrideSpeedTick();
		OverrideTimeScaleTick();
		OverrideLookSpeedTick();
		OverrideVoicePitchTick();
		if (kinematicTimer > 0f)
		{
			VelocityImpulse = Vector3.zero;
			rb.isKinematic = true;
			kinematicTimer -= Time.fixedDeltaTime;
			if (kinematicTimer <= 0f)
			{
				rb.collisionDetectionMode = (CollisionDetectionMode)2;
				rb.isKinematic = false;
			}
			return;
		}
		if (playerAvatarScript.isTumbling && Object.op_Implicit((Object)(object)playerAvatarScript.tumble))
		{
			((Component)this).transform.position = ((Component)playerAvatarScript.tumble).transform.position + Vector3.down * 0.3f;
		}
		if (Crawling != previousCrawlingState)
		{
			ChangeState();
			previousCrawlingState = Crawling;
		}
		if (Crouching != previousCrouchingState)
		{
			ChangeState();
			previousCrouchingState = Crouching;
		}
		if (sprinting != previousSprintingState)
		{
			ChangeState();
			previousSprintingState = sprinting;
		}
		if (Sliding != previousSlidingState)
		{
			ChangeState();
			previousSlidingState = Sliding;
		}
		if (moving != previousMovingState)
		{
			ChangeState();
			previousMovingState = moving;
		}
		Quaternion localRotation = cameraGameObject.transform.localRotation;
		Quaternion rotation = Quaternion.Euler(0f, localRotation.eulerAngles.y, 0f);
		if (overrideTurnRotationTimer > 0f)
		{
			overrideTurnRotationTimer -= Time.fixedDeltaTime;
			if (overrideTurnRotationTimer <= 0f)
			{
				playerAvatarScript.rotationOverrideActive = false;
			}
			rotation = overrideTurnRotation;
		}
		if (overrideDisableTurnTimer > 0f)
		{
			overrideDisableTurnTimer -= Time.fixedDeltaTime;
			if (overrideDisableTurnTimer <= 0f)
			{
				playerAvatarScript.rotationDisabled = false;
				if (overrideResetTurn)
				{
					CameraAim.Instance.SetPlayerAim(overrideResetTurnPosition, _setRotation: true);
				}
			}
		}
		else
		{
			((Component)this).transform.rotation = rotation;
		}
		Vector3 val;
		if ((SemiFunc.InputHold(InputKey.Sprint) || toggleSprint) && !playerAvatarScript.isTumbling && !Crouching && EnergyCurrent > 0f)
		{
			val = rb.linearVelocity;
			if (val.magnitude > 0.01f)
			{
				TutorialDirector.instance.playerSprinted = true;
				sprinting = true;
				SprintedTimer = 0.5f;
				SprintDrainTimer = 0.2f;
			}
		}
		else
		{
			if (SprintedTimer > 0f)
			{
				SprintedTimer -= Time.fixedDeltaTime;
				if (SprintedTimer <= 0f)
				{
					CanSlide = false;
					SprintedTimer = 0f;
				}
			}
			SprintSpeedLerp = 0f;
			sprinting = false;
		}
		if (SprintDrainTimer > 0f && !DebugEnergy)
		{
			float energySprintDrain = EnergySprintDrain;
			energySprintDrain += SprintSpeedUpgrades;
			energySprintDrain *= Mathf.Lerp(0f, 1f, SprintSpeedLerp);
			EnergyCurrent -= energySprintDrain * Time.fixedDeltaTime;
			EnergyCurrent = Mathf.Max(0f, EnergyCurrent);
			if (EnergyCurrent <= 0f)
			{
				toggleSprint = false;
			}
			SprintDrainTimer -= Time.fixedDeltaTime;
		}
		if ((Crouching && Object.op_Implicit((Object)(object)PlayerCollisionStand.instance) && PlayerCollisionStand.instance.CheckBlocked()) || playerAvatarScript.isTumbling)
		{
			TutorialDirector.instance.playerCrawled = true;
			Crawling = true;
		}
		else
		{
			Crawling = false;
		}
		if (playerAvatarScript.isTumbling || (CollisionController.Grounded && (((SemiFunc.InputHold(InputKey.Crouch) || crouchOverrideTimer > 0f) && InputDisableTimer <= 0f) || toggleCrouch)))
		{
			if (CrouchInactiveTimer <= 0f)
			{
				if (!Crouching)
				{
					CrouchActiveTimer = CrouchTimeMin;
				}
				TutorialDirector.instance.playerCrouched = true;
				Crouching = true;
				sprinting = false;
			}
		}
		else if (Crouching && CrouchActiveTimer <= 0f && !Crawling)
		{
			Crawling = false;
			Crouching = false;
			CrouchInactiveTimer = CrouchTimeMin;
		}
		if (CrouchActiveTimer > 0f)
		{
			CrouchActiveTimer -= Time.fixedDeltaTime;
		}
		if (CrouchInactiveTimer > 0f)
		{
			CrouchInactiveTimer -= Time.fixedDeltaTime;
		}
		if (crouchOverrideTimer > 0f)
		{
			crouchOverrideTimer -= Time.fixedDeltaTime;
		}
		if (sprinting || Crouching)
		{
			CanInteract = false;
		}
		else
		{
			CanInteract = true;
		}
		Vector3 val2 = Vector3.zero;
		if (MoveForceTimer > 0f)
		{
			InputDirection = MoveForceDirection;
			MoveForceTimer -= Time.fixedDeltaTime;
			rb.linearVelocity = MoveForceDirection * MoveForceAmount;
		}
		else if (InputDisableTimer <= 0f)
		{
			val = new Vector3(SemiFunc.InputMovementX(), 0f, SemiFunc.InputMovementY());
			InputDirectionRaw = val.normalized;
			InputDirection = InputDirectionRaw;
			InputAnalogAmount = 1f;
			if (SemiFunc.InputMode() == InputModes.Gamepad && !sprinting)
			{
				Vector2 val3 = SemiFunc.InputMovement();
				float num = Mathf.Clamp01(val3.magnitude);
				if (num > 0f)
				{
					InputAnalogAmount = Mathf.Lerp(analogMovementMinSpeed, 1f, num);
				}
			}
			InputDirection *= InputAnalogAmount;
			if (GameDirector.instance.DisableInput || playerAvatarScript.isTumbling)
			{
				InputDirection = Vector3.zero;
			}
			if (InputDirection.magnitude <= 0.1f)
			{
				SprintSpeedLerp = 0f;
			}
			if (MoveMultiplierTimer > 0f)
			{
				InputDirection *= MoveMultiplier;
			}
			if (sprinting)
			{
				SprintSpeedCurrent = Mathf.Lerp(MoveSpeed, SprintSpeed, SprintSpeedLerp);
				SprintSpeedLerp += SprintAcceleration * Time.fixedDeltaTime;
				SprintSpeedLerp = Mathf.Clamp01(SprintSpeedLerp);
				val2 += InputDirection * SprintSpeedCurrent;
				SlideDirection = InputDirection * SprintSpeedCurrent;
				SlideDirectionCurrent = SlideDirection;
				CanSlide = true;
				Sliding = false;
			}
			else if (Crouching)
			{
				if (CanSlide)
				{
					playerAvatarScript.Slide();
					if (!DebugEnergy)
					{
						EnergyCurrent -= 5f;
					}
					EnergyCurrent = Mathf.Max(0f, EnergyCurrent);
					CanSlide = false;
					Sliding = true;
					SlideTimer = SlideTime;
				}
				if (SlideTimer > 0f)
				{
					val2 += SlideDirectionCurrent;
					SlideDirectionCurrent -= SlideDirection * SlideDecay * Time.fixedDeltaTime;
					SlideTimer -= Time.fixedDeltaTime;
					if (SlideTimer <= 0f)
					{
						Sliding = false;
					}
				}
				if (debugSlow)
				{
					InputDirection *= 0.2f;
				}
				val2 += InputDirection * CrouchSpeed;
			}
			else
			{
				if (debugSlow)
				{
					InputDirection *= 0.1f;
				}
				val2 += InputDirection * MoveSpeed;
				Sliding = false;
			}
		}
		else
		{
			InputDirection = Vector3.zero;
			InputAnalogAmount = 1f;
		}
		if (InputDisableTimer > 0f)
		{
			InputDisableTimer -= Time.fixedDeltaTime;
		}
		if (MoveMultiplierTimer > 0f)
		{
			MoveMultiplierTimer -= Time.fixedDeltaTime;
		}
		if (antiGravityTimer > 0f)
		{
			if (rb.useGravity)
			{
				rb.linearDamping = 2f;
				rb.useGravity = false;
			}
			antiGravityTimer -= Time.fixedDeltaTime;
		}
		else if (!rb.useGravity)
		{
			rb.linearDamping = 0f;
			rb.useGravity = true;
		}
		val2 += VelocityImpulse;
		VelocityRelativeNew += VelocityImpulse;
		VelocityImpulse = Vector3.zero;
		if (VelocityIdle)
		{
			VelocityRelativeNew = val2;
		}
		else
		{
			VelocityRelativeNew = Vector3.Lerp(VelocityRelativeNew, val2, MoveFriction * Time.fixedDeltaTime);
		}
		Vector3 val4 = PlatformVelocityHorizontal();
		Vector3 val5 = ((Component)this).transform.InverseTransformDirection(rb.linearVelocity - val4);
		if (VelocityRelativeNew.magnitude > 0.1f)
		{
			VelocityIdle = false;
			col.material = PhysicMaterialMove;
			VelocityRelative = Vector3.Lerp(VelocityRelative, VelocityRelativeNew, MoveFriction * Time.fixedDeltaTime);
			VelocityRelative.y = val5.y;
			rb.AddRelativeForce(VelocityRelative - val5, (ForceMode)1);
			Velocity = ((Component)this).transform.InverseTransformDirection(VelocityRelative - val5);
		}
		else
		{
			VelocityIdle = true;
			col.material = PhysicMaterialIdle;
			VelocityRelative = Vector3.zero;
			Velocity = rb.linearVelocity;
			PlatformCarryIdle(val4);
		}
		if (platformVelocityTimer > 0f)
		{
			platformVelocityTimer -= Time.fixedDeltaTime;
		}
		if (!CollisionController.Grounded && !JumpImpulse && featherTimer <= 0f)
		{
			if (rb.useGravity)
			{
				rb.AddForce(new Vector3(0f, (0f - CustomGravity) * Time.fixedDeltaTime, 0f), (ForceMode)1);
			}
			else
			{
				rb.AddForce(new Vector3(0f, (0f - CustomGravity * 0.1f) * Time.fixedDeltaTime, 0f), (ForceMode)1);
			}
		}
		if (JumpImpulse)
		{
			bool flag = false;
			foreach (PhysGrabObject jumpGroundedObject in JumpGroundedObjects)
			{
				foreach (PhysGrabber item in jumpGroundedObject.playerGrabbing)
				{
					if ((Object)(object)item.playerAvatar == (Object)(object)playerAvatarScript)
					{
						flag = true;
						item.ReleaseObject(jumpGroundedObject.photonView.ViewID, 1f);
						break;
					}
				}
			}
			Vector3 val6 = new Vector3(0f, rb.linearVelocity.y, 0f);
			float num2 = JumpForce;
			if (flag)
			{
				num2 = JumpForce * 0.5f;
			}
			rb.AddForce(Vector3.up * num2 - val6, (ForceMode)1);
			JumpCooldown = 0.1f;
			JumpImpulse = false;
			CollisionGrounded.Grounded = false;
			JumpGroundedBuffer = 0f;
			CollisionController.GroundedDisableTimer = 0.1f;
			CollisionController.fallDistance = 0f;
		}
		if (VelocityRelativeNew.magnitude > 0.1f)
		{
			movingResetTimer = 0.1f;
			moving = true;
		}
		else if (movingResetTimer > 0f)
		{
			movingResetTimer -= Time.fixedDeltaTime;
			if (movingResetTimer <= 0f)
			{
				sprinting = false;
				moving = false;
			}
		}
		if (featherTimer > 0f)
		{
			if (rb.useGravity)
			{
				rb.useGravity = false;
			}
			if (antiGravityTimer <= 0f)
			{
				rb.AddForce(new Vector3(0f, -15f, 0f), (ForceMode)0);
			}
			featherTimer -= Time.fixedDeltaTime;
			if (featherTimer <= 0f)
			{
				rb.useGravity = true;
			}
		}
		OverrideTimeScaleLogic();
		OverrideSpeedLogic();
		OverrideLookSpeedLogic();
		positionPrevious = ((Component)this).transform.position;
	}

	private void Update()
	{
		//IL_0448: Unknown result type (might be due to invalid IL or missing references)
		//IL_0119: Unknown result type (might be due to invalid IL or missing references)
		//IL_011e: Unknown result type (might be due to invalid IL or missing references)
		if (!LevelGenerator.Instance.Generated || SemiFunc.MenuLevel())
		{
			return;
		}
		if (GameDirector.instance.currentState == GameDirector.gameState.Load || GameDirector.instance.currentState == GameDirector.gameState.Start)
		{
			InputDisableTimer = Mathf.Max(InputDisableTimer, 0.1f);
		}
		if (deathSeenTimer > 0f)
		{
			deathSeenTimer -= Time.deltaTime;
		}
		if (CollisionController.Grounded && InputDisableTimer <= 0f)
		{
			if (InputManager.instance.InputToggleGet(InputKey.Crouch))
			{
				if (SemiFunc.InputDown(InputKey.Crouch))
				{
					toggleCrouch = !toggleCrouch;
					if (toggleCrouch)
					{
						toggleSprint = false;
					}
				}
			}
			else
			{
				toggleCrouch = false;
			}
		}
		if (!playerAvatarScript.isTumbling)
		{
			if (InputManager.instance.InputToggleGet(InputKey.Sprint))
			{
				if (SemiFunc.InputDown(InputKey.Sprint) && InputDisableTimer <= 0f)
				{
					toggleSprint = !toggleSprint;
					if (toggleSprint)
					{
						toggleCrouch = false;
					}
				}
				if (toggleSprint && SemiFunc.InputMode() == InputModes.Gamepad)
				{
					Vector2 val = SemiFunc.InputMovement();
					if (val.sqrMagnitude < 0.0001f)
					{
						toggleSprint = false;
					}
				}
			}
			else
			{
				toggleSprint = false;
			}
		}
		if (sprinting)
		{
			sprintRechargeTimer = sprintRechargeTime;
			if (SemiFunc.RunIsArena())
			{
				sprintRechargeTimer *= 0.5f;
			}
		}
		else if (sprintRechargeTimer > 0f)
		{
			sprintRechargeTimer -= Time.deltaTime;
		}
		else if (EnergyCurrent < EnergyStart)
		{
			float num = sprintRechargeAmount;
			if (SemiFunc.RunIsArena() && !playerAvatarScript.isTumbling)
			{
				num *= 5f;
			}
			if (playerAvatarScript.physGrabber.grabState == PhysGrabber.GrabState.Climb)
			{
				num = 0f;
			}
			EnergyCurrent += num * Time.deltaTime;
			if (EnergyCurrent > EnergyStart)
			{
				EnergyCurrent = EnergyStart;
			}
		}
		if (!JumpImpulse)
		{
			if (SemiFunc.InputDown(InputKey.Jump) && !playerAvatarScript.isTumbling && InputDisableTimer <= 0f && OverrideJumpCooldownCurrent <= 0f)
			{
				JumpInputBuffer = 0.25f;
				if (OverrideJumpCooldownTimer > 0f)
				{
					OverrideJumpCooldownCurrent = OverrideJumpCooldownAmount;
				}
			}
			if (OverrideJumpCooldownTimer > 0f)
			{
				OverrideJumpCooldownTimer -= Time.deltaTime;
			}
			if (OverrideJumpCooldownCurrent > 0f)
			{
				OverrideJumpCooldownCurrent -= Time.deltaTime;
			}
			if (CollisionGrounded.Grounded)
			{
				JumpFirst = true;
				JumpExtraCurrent = JumpExtra;
				JumpGroundedBuffer = 0.25f;
			}
			else if (JumpGroundedBuffer > 0f)
			{
				JumpGroundedBuffer -= Time.deltaTime;
				if (JumpGroundedBuffer <= 0f)
				{
					JumpFirst = false;
				}
			}
			if (JumpInputBuffer > 0f)
			{
				JumpInputBuffer -= Time.deltaTime;
			}
			if (JumpCooldown > 0f)
			{
				JumpCooldown -= Time.deltaTime;
			}
			if (JumpInputBuffer > 0f && (JumpGroundedBuffer > 0f || (!JumpFirst && JumpExtraCurrent > 0)) && JumpCooldown <= 0f)
			{
				if (JumpFirst)
				{
					JumpFirst = false;
					playerAvatarScript.Jump(_powerupEffect: false);
				}
				else
				{
					JumpExtraCurrent--;
					playerAvatarScript.Jump(_powerupEffect: true);
				}
				CameraJump.instance.Jump();
				TutorialDirector.instance.playerJumped = true;
				if (!Crawling)
				{
					toggleCrouch = false;
				}
				JumpImpulse = true;
				JumpInputBuffer = 0f;
			}
			if ((JumpGroundedBuffer <= 0f || !CollisionGrounded.onPhysObject) && JumpGroundedObjects.Count > 0)
			{
				JumpGroundedObjects.Clear();
			}
		}
		if (landCooldown > 0f)
		{
			landCooldown -= Time.deltaTime;
		}
		if (rb.linearVelocity.y < -4f || (Object.op_Implicit((Object)(object)playerAvatarScript.tumble) && playerAvatarScript.tumble.physGrabObject.rbVelocity.y < -4f))
		{
			CanLand = true;
		}
		if (GroundedPrevious != CollisionController.Grounded)
		{
			if (CollisionController.Grounded && CanLand)
			{
				if (!SemiFunc.MenuLevel() && landCooldown <= 0f)
				{
					landCooldown = 1f;
					CameraJump.instance.Land();
					playerAvatarScript.Land();
				}
				CanLand = false;
			}
			GroundedPrevious = CollisionController.Grounded;
		}
		if (tumbleInputDisableTimer > 0f)
		{
			tumbleInputDisableTimer -= Time.deltaTime;
		}
		if (playerAvatarScript.isTumbling)
		{
			col.enabled = false;
			rb.isKinematic = true;
			bool flag = false;
			if (Object.op_Implicit((Object)(object)playerAvatarScript.tumble) && playerAvatarScript.tumble.notMovingTimer > 0.5f && (Mathf.Abs(SemiFunc.InputMovementX()) > 0f || Mathf.Abs(SemiFunc.InputMovementY()) > 0f))
			{
				flag = true;
			}
			if (((SemiFunc.InputDown(InputKey.Jump) || SemiFunc.InputDown(InputKey.Tumble)) | flag) && tumbleInputDisableTimer <= 0f && Object.op_Implicit((Object)(object)playerAvatarScript.tumble) && !playerAvatarScript.tumble.tumbleOverride && InputDisableTimer <= 0f)
			{
				playerAvatarScript.tumble.TumbleRequest(_isTumbling: false, _playerInput: true);
			}
		}
		else
		{
			col.enabled = true;
			rb.isKinematic = false;
			if (Object.op_Implicit((Object)(object)playerAvatarScript.tumble) && SemiFunc.InputDown(InputKey.Tumble) && tumbleInputDisableTimer <= 0f && InputDisableTimer <= 0f)
			{
				TutorialDirector.instance.playerTumbled = true;
				playerAvatarScript.tumble.TumbleRequest(_isTumbling: true, _playerInput: true);
			}
		}
	}

	public void Revive(Vector3 _rotation)
	{
		//IL_000b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0016: Unknown result type (might be due to invalid IL or missing references)
		//IL_0060: Unknown result type (might be due to invalid IL or missing references)
		//IL_0065: Unknown result type (might be due to invalid IL or missing references)
		//IL_006b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0070: Unknown result type (might be due to invalid IL or missing references)
		((Component)this).transform.rotation = Quaternion.Euler(0f, _rotation.y, 0f);
		InputDisable(0.5f);
		Kinematic(0.2f);
		SetCrawl();
		CollisionController.ResetFalling();
		VelocityIdle = true;
		col.material = PhysicMaterialIdle;
		VelocityRelative = Vector3.zero;
		Velocity = Vector3.zero;
		EnergyCurrent = EnergyStart;
	}

	public void CrouchOverride(float _time)
	{
		crouchOverrideTimer = _time;
	}

	public PlayerController()
	{
		//IL_0017: Unknown result type (might be due to invalid IL or missing references)
		//IL_001c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0022: Unknown result type (might be due to invalid IL or missing references)
		//IL_0027: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e8: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ed: Unknown result type (might be due to invalid IL or missing references)
	}
}
