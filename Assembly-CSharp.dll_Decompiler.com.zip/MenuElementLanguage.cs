using TMPro;
using UnityEngine;
using UnityEngine.UI;

public class MenuElementLanguage : MonoBehaviour
{
	private MenuElementHover menuElementHover;

	public TextMeshProUGUI textName;

	public RawImage border;

	public RawImage background;

	public MenuPageSettingsLanguage parentPage;

	public LocalizeChangedUI localizeChangedUI;

	private bool active;

	private bool hovering;

	private float clickTimer;

	private float clickCooldown;

	private Vector3 textOriginalPosition;

	private Color inactiveBorderColor;

	private static readonly Color activeBorderColor = new Color(1f, 141f / 255f, 0f);

	private static readonly Color sharedColor = new Color(1f / 51f, 56f / 255f, 123f / 255f);

	private static readonly Color inactiveBackgroundColor = Color.black;

	[Space]
	private float introLerp;

	internal LocaleAsset localeAsset;

	private void Start()
	{
		//IL_0018: Unknown result type (might be due to invalid IL or missing references)
		//IL_001d: Unknown result type (might be due to invalid IL or missing references)
		menuElementHover = ((Component)this).GetComponent<MenuElementHover>();
		textOriginalPosition = ((TMP_Text)textName).transform.localPosition;
	}

	private void Awake()
	{
		//IL_0007: Unknown result type (might be due to invalid IL or missing references)
		//IL_000c: Unknown result type (might be due to invalid IL or missing references)
		inactiveBorderColor = ((Graphic)border).color;
		LocalizationManager.instance.AddLocalizationChangedCallback(LocalizationChanged);
	}

	private void OnDestroy()
	{
		if (Object.op_Implicit((Object)(object)LocalizationManager.instance))
		{
			LocalizationManager.instance.RemoveLocalizationChangedCallback(LocalizationChanged);
		}
	}

	private void LocalizationChanged()
	{
		if ((Object)(object)localeAsset == (Object)(object)LocalizationManager.instance.ActiveLocale)
		{
			localizeChangedUI.LocalizeChangedSpringShakeY();
		}
	}

	private void Update()
	{
		//IL_0057: Unknown result type (might be due to invalid IL or missing references)
		//IL_0067: Unknown result type (might be due to invalid IL or missing references)
		//IL_0034: Unknown result type (might be due to invalid IL or missing references)
		//IL_0044: Unknown result type (might be due to invalid IL or missing references)
		//IL_0131: Unknown result type (might be due to invalid IL or missing references)
		//IL_009c: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a1: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a6: Unknown result type (might be due to invalid IL or missing references)
		//IL_019a: Unknown result type (might be due to invalid IL or missing references)
		//IL_018e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0187: Unknown result type (might be due to invalid IL or missing references)
		bool flag = (Object)(object)localeAsset == (Object)(object)LocalizationManager.instance.ActiveLocale;
		if (active != flag)
		{
			active = flag;
			if (active)
			{
				((Graphic)border).color = activeBorderColor;
				((Graphic)background).color = sharedColor;
			}
			else
			{
				((Graphic)border).color = inactiveBorderColor;
				((Graphic)background).color = inactiveBackgroundColor;
			}
		}
		if (menuElementHover.isHovering)
		{
			if (!hovering)
			{
				hovering = true;
				((TMP_Text)textName).transform.localPosition = textOriginalPosition + Vector3.up;
			}
			if (!menuElementHover.JustBecameCurrentTarget && clickCooldown <= 0f && SemiFunc.InputUIClick())
			{
				MenuPageSettingsLanguage.PickLanguage(localeAsset);
				MenuManager.instance.MenuEffectClick(MenuManager.MenuClickEffectType.Action, menuElementHover.parentPage);
				clickTimer = 0.2f;
				clickCooldown = 0.25f;
			}
		}
		else if (hovering)
		{
			hovering = false;
			((TMP_Text)textName).transform.localPosition = textOriginalPosition;
		}
		if (clickTimer > 0f)
		{
			clickTimer -= Time.deltaTime;
		}
		clickCooldown -= Time.deltaTime;
		((Graphic)textName).color = ((clickTimer > 0f) ? AssetManager.instance.colorYellow : (hovering ? Color.white : Color.gray));
	}

	static MenuElementLanguage()
	{
		//IL_000f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0014: Unknown result type (might be due to invalid IL or missing references)
		//IL_0028: Unknown result type (might be due to invalid IL or missing references)
		//IL_002d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0032: Unknown result type (might be due to invalid IL or missing references)
		//IL_0037: Unknown result type (might be due to invalid IL or missing references)
	}
}
