using System.Collections.Generic;
using UnityEngine;

public class EnemySlowMouthAttaching : MonoBehaviour
{
	internal EnemySlowMouth enemySlowMouth;

	public Transform tentaclesTransform;

	public List<Transform> eyeTransforms = new List<Transform>();

	public Transform topJaw;

	public Transform bottomJaw;

	public Transform particleTransform;

	private List<ParticleSystem> particleSystems = new List<ParticleSystem>();

	private Quaternion startRotationTopJaw;

	private Quaternion startRotationBottomJaw;

	private Transform targetTransform;

	public PlayerAvatar targetPlayerAvatar;

	private SpringQuaternion springQuaternion;

	private bool isActive;

	private Vector3 startPosition;

	private SpringFloat springFloatScale;

	private float targetScale = 1f;

	[Space(20f)]
	public Sound soundAttachVO;

	public Sound soundAttach;

	private void Start()
	{
		//IL_005d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0062: Unknown result type (might be due to invalid IL or missing references)
		//IL_006e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0073: Unknown result type (might be due to invalid IL or missing references)
		//IL_007f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0084: Unknown result type (might be due to invalid IL or missing references)
		springQuaternion = new SpringQuaternion();
		springQuaternion.damping = 0.5f;
		springQuaternion.speed = 20f;
		springFloatScale = new SpringFloat();
		springFloatScale.damping = 0.5f;
		springFloatScale.speed = 20f;
		startRotationTopJaw = topJaw.localRotation;
		startRotationBottomJaw = bottomJaw.localRotation;
		startPosition = ((Component)this).transform.position;
		particleSystems = new List<ParticleSystem>(((Component)particleTransform).GetComponentsInChildren<ParticleSystem>());
		GoTime();
	}

	public void GoTime()
	{
		//IL_0078: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a6: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c1: Unknown result type (might be due to invalid IL or missing references)
		PlayParticles(finalPlay: false);
		if (Object.op_Implicit((Object)(object)targetPlayerAvatar) && targetPlayerAvatar.isLocal)
		{
			CameraGlitch.Instance.PlayLong();
		}
		SetTarget(targetPlayerAvatar);
		springFloatScale.springVelocity = 50f;
		isActive = true;
		targetScale = 1f;
		GameDirector.instance.CameraShake.ShakeDistance(3f, 3f, 8f, ((Component)this).transform.position, 0.1f);
		GameDirector.instance.CameraImpact.ShakeDistance(2f, 3f, 8f, ((Component)this).transform.position, 0.1f);
		soundAttachVO.Play(((Component)this).transform.position);
	}

	private void PlayParticles(bool finalPlay)
	{
		foreach (ParticleSystem particleSystem in particleSystems)
		{
			particleSystem.Play();
			if (finalPlay)
			{
				((Component)particleSystem).transform.parent = null;
				Object.Destroy((Object)(object)((Component)particleSystem).gameObject, 4f);
			}
		}
	}

	private void Update()
	{
		//IL_0086: Unknown result type (might be due to invalid IL or missing references)
		//IL_0091: Unknown result type (might be due to invalid IL or missing references)
		//IL_0096: Unknown result type (might be due to invalid IL or missing references)
		//IL_009b: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a0: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ad: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00da: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e0: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f0: Unknown result type (might be due to invalid IL or missing references)
		//IL_00fb: Unknown result type (might be due to invalid IL or missing references)
		//IL_013b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0146: Unknown result type (might be due to invalid IL or missing references)
		//IL_0153: Unknown result type (might be due to invalid IL or missing references)
		//IL_004b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0050: Unknown result type (might be due to invalid IL or missing references)
		//IL_0061: Unknown result type (might be due to invalid IL or missing references)
		//IL_0066: Unknown result type (might be due to invalid IL or missing references)
		//IL_01fd: Unknown result type (might be due to invalid IL or missing references)
		//IL_0202: Unknown result type (might be due to invalid IL or missing references)
		//IL_0213: Unknown result type (might be due to invalid IL or missing references)
		//IL_0218: Unknown result type (might be due to invalid IL or missing references)
		//IL_02cf: Unknown result type (might be due to invalid IL or missing references)
		//IL_02ff: Unknown result type (might be due to invalid IL or missing references)
		//IL_0310: Unknown result type (might be due to invalid IL or missing references)
		//IL_0335: Unknown result type (might be due to invalid IL or missing references)
		//IL_033a: Unknown result type (might be due to invalid IL or missing references)
		//IL_034b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0370: Unknown result type (might be due to invalid IL or missing references)
		//IL_0375: Unknown result type (might be due to invalid IL or missing references)
		//IL_024a: Unknown result type (might be due to invalid IL or missing references)
		//IL_03d2: Unknown result type (might be due to invalid IL or missing references)
		bool flag = !Object.op_Implicit((Object)(object)targetTransform) || !Object.op_Implicit((Object)(object)targetPlayerAvatar);
		if (!isActive)
		{
			return;
		}
		if (flag)
		{
			if (SemiFunc.IsMasterClientOrSingleplayer() && Object.op_Implicit((Object)(object)enemySlowMouth))
			{
				enemySlowMouth.detachPosition = ((Component)this).transform.position;
				enemySlowMouth.detachRotation = ((Component)this).transform.rotation;
				enemySlowMouth.UpdateState(EnemySlowMouth.State.Detach);
				isActive = false;
			}
			return;
		}
		Quaternion targetRotation = Quaternion.LookRotation(targetTransform.position - ((Component)this).transform.position);
		((Component)this).transform.rotation = SemiFunc.SpringQuaternionGet(springQuaternion, targetRotation);
		float num = SemiFunc.SpringFloatGet(springFloatScale, targetScale);
		((Component)this).transform.localScale = Vector3.one * num;
		float num2 = Vector3.Distance(((Component)this).transform.position, targetTransform.position);
		float num3 = num2 * 2f;
		if (num3 < 4f)
		{
			num3 = 4f;
		}
		if (num3 > 10f)
		{
			num3 = 10f;
		}
		((Component)this).transform.position = Vector3.MoveTowards(((Component)this).transform.position, targetTransform.position, Time.deltaTime * num3);
		if (num2 < 1f)
		{
			targetScale = 2.5f;
		}
		if (targetPlayerAvatar.isLocal)
		{
			GameDirector.instance.CameraShake.Shake(4f, 0.1f);
		}
		if (!SemiFunc.IsMasterClientOrSingleplayer())
		{
			return;
		}
		if (!targetPlayerAvatar.isDisabled && Object.op_Implicit((Object)(object)enemySlowMouth) && !enemySlowMouth.IsPossessed() && enemySlowMouth.currentState != EnemySlowMouth.State.Dead)
		{
			if (!(num2 < 0.1f))
			{
				if (targetPlayerAvatar.isLocal)
				{
					CameraAim.Instance.AimTargetSet(((Component)this).transform.position, 0.2f, 20f, ((Component)this).gameObject, 100);
					CameraZoom.Instance.OverrideZoomSet(30f, 0.1f, 8f, 1f, ((Component)this).gameObject, 50);
				}
				tentaclesTransform.localScale = new Vector3(1f + Mathf.Sin(Time.time * 40f) * 0.2f, 1f + Mathf.Sin(Time.time * 60f) * 0.1f, 1f);
				tentaclesTransform.localRotation = Quaternion.Euler(0f, 0f, Mathf.Sin(Time.time * 20f) * 10f);
				topJaw.localRotation = startRotationTopJaw * Quaternion.Euler(Mathf.Sin(Time.time * 60f) * 3f, 0f, 0f);
				bottomJaw.localRotation = startRotationBottomJaw * Quaternion.Euler(Mathf.Sin(Time.time * 60f) * 10f, 0f, 0f);
				{
					foreach (Transform eyeTransform in eyeTransforms)
					{
						eyeTransform.localScale = new Vector3(1.5f + Mathf.Sin(Time.time * 40f) * 0.5f, 1.5f + Mathf.Sin(Time.time * 60f) * 0.5f, 1.5f);
					}
					return;
				}
			}
			enemySlowMouth.UpdateState(EnemySlowMouth.State.Attached);
			isActive = false;
		}
		else
		{
			enemySlowMouth.detachPosition = ((Component)this).transform.position;
			enemySlowMouth.detachRotation = ((Component)this).transform.rotation;
			enemySlowMouth.UpdateState(EnemySlowMouth.State.Detach);
			isActive = false;
		}
	}

	public void FinishAttack(bool _attached)
	{
		isActive = false;
		if (_attached)
		{
			Despawn();
		}
		else
		{
			Detach();
		}
	}

	private void Detach()
	{
		//IL_000c: Unknown result type (might be due to invalid IL or missing references)
		soundAttach.Play(((Component)this).transform.position);
		PlayParticles(finalPlay: true);
		Object.Destroy((Object)(object)((Component)this).gameObject);
	}

	private void Despawn()
	{
		//IL_000c: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a9: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d7: Unknown result type (might be due to invalid IL or missing references)
		soundAttach.Play(((Component)this).transform.position);
		PlayParticles(finalPlay: true);
		if (Object.op_Implicit((Object)(object)targetPlayerAvatar) && targetPlayerAvatar.isLocal)
		{
			GameDirector.instance.CameraImpact.Shake(8f, 0.1f);
			GameDirector.instance.CameraShake.Shake(5f, 0.1f);
			CameraGlitch.Instance.PlayLong();
		}
		else
		{
			GameDirector.instance.CameraShake.ShakeDistance(3f, 3f, 8f, ((Component)this).transform.position, 0.1f);
			GameDirector.instance.CameraImpact.ShakeDistance(2f, 3f, 8f, ((Component)this).transform.position, 0.1f);
		}
		Object.Destroy((Object)(object)((Component)this).gameObject);
	}

	public void SetTarget(PlayerAvatar _playerAvatar)
	{
		targetTransform = SemiFunc.PlayerGetFaceEyeTransform(_playerAvatar);
		targetPlayerAvatar = _playerAvatar;
	}
}
