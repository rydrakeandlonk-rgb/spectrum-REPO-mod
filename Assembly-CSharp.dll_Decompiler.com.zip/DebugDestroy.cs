using UnityEngine;

public class DebugDestroy : MonoBehaviour
{
	private void Awake()
	{
		Object.Destroy((Object)(object)((Component)this).gameObject);
	}
}
