using System.Collections.Generic;
using Photon.Pun;
using UnityEngine;

public class ShopRadio : MonoBehaviour
{
	public Sound shopMusic;

	public List<AudioClip> shopMusicClips;

	public Sound soundGlitch;

	public Sound glitchLoop;

	public ParticleSystem spark;

	public ParticleSystem smoke;

	public GameObject speaker;

	private float smokeAmount;

	private PhotonView photonView;

	private PhysGrabObject physGrabObject;

	private NotValuableObject notValuableObject;

	private bool isPlaying;

	private int prevIndex;

	private float pitch = 1f;

	private bool hitLow;

	private bool shouldWobble;

	private int syncedHealth;

	public AudioSource musicSource;

	private float musicClipTimer;

	private float musicClipLoudness;

	private int musicClipSampleDataLength = 1024;

	private float[] musicClipSampleData;

	private void Start()
	{
		//IL_007b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0081: Unknown result type (might be due to invalid IL or missing references)
		photonView = ((Component)this).GetComponent<PhotonView>();
		physGrabObject = ((Component)this).GetComponent<PhysGrabObject>();
		notValuableObject = ((Component)this).GetComponent<NotValuableObject>();
		musicClipSampleData = new float[musicClipSampleDataLength];
		int num = Random.Range(0, shopMusicClips.Count);
		if (SemiFunc.IsMasterClientOrSingleplayer())
		{
			if (SemiFunc.IsMultiplayer())
			{
				photonView.RPC("RandomClipOnAwakeRPC", (RpcTarget)0, new object[1] { num });
			}
			else
			{
				RandomClipOnAwakeRPC(num);
			}
		}
		syncedHealth = notValuableObject.healthMax;
	}

	private void Update()
	{
		//IL_0044: Unknown result type (might be due to invalid IL or missing references)
		//IL_00de: Unknown result type (might be due to invalid IL or missing references)
		//IL_0151: Unknown result type (might be due to invalid IL or missing references)
		//IL_0156: Unknown result type (might be due to invalid IL or missing references)
		//IL_015f: Unknown result type (might be due to invalid IL or missing references)
		float num = musicClipLoudness;
		num = Mathf.Log10(num * 1000f + 1f);
		num = Mathf.Lerp(0.8f, 1.2f, Mathf.Clamp01(num / 3f));
		speaker.transform.localScale = new Vector3(num, num, num);
		shopMusic.PlayLoop(playing: true, 10f, 10f, pitch);
		glitchLoop.PlayLoop(smokeAmount > 0f, 10f, 10f, Random.Range(1, 2));
		if (shouldWobble)
		{
			AudioWobble();
		}
		if (smokeAmount > 0f && Random.Range(0, 1000) < 1)
		{
			spark.Play();
			soundGlitch.Play(physGrabObject.centerPoint);
		}
		if (syncedHealth < notValuableObject.healthMax / 2)
		{
			smokeAmount = (float)(notValuableObject.healthMax - syncedHealth) * 0.1f;
		}
		else
		{
			smokeAmount = 0f;
		}
		if (Object.op_Implicit((Object)(object)smoke))
		{
			EmissionModule emission = smoke.emission;
			emission.rateOverTime = MinMaxCurve.op_Implicit(smokeAmount);
		}
		if (musicClipTimer <= 0f)
		{
			musicClipTimer = 0.01f;
			musicClipLoudness = 0f;
			if (Object.op_Implicit((Object)(object)musicSource.clip) && musicSource.isPlaying)
			{
				musicSource.clip.GetData(musicClipSampleData, musicSource.timeSamples);
				float[] array = musicClipSampleData;
				foreach (float num2 in array)
				{
					musicClipLoudness += Mathf.Abs(num2);
				}
				musicClipLoudness /= musicClipSampleDataLength;
			}
		}
		else
		{
			musicClipTimer -= Time.deltaTime;
		}
	}

	public void OnImpact()
	{
		if (SemiFunc.IsMasterClientOrSingleplayer())
		{
			PlayNewClip();
		}
	}

	public void OnDestroyed()
	{
		DeparentAndDestroyParticleSystem(smoke);
	}

	private void PlayNewClip()
	{
		//IL_0079: Unknown result type (might be due to invalid IL or missing references)
		//IL_007f: Unknown result type (might be due to invalid IL or missing references)
		int num;
		for (num = Random.Range(0, shopMusicClips.Count); num == prevIndex; num = Random.Range(0, shopMusicClips.Count))
		{
		}
		if (SemiFunc.IsMultiplayer())
		{
			photonView.RPC("PlayNewClipRPC", (RpcTarget)0, new object[2] { num, notValuableObject.healthCurrent });
		}
		else
		{
			PlayNewClipRPC(num, notValuableObject.healthCurrent);
		}
	}

	private void AudioWobble()
	{
		if (pitch > 0f && !hitLow)
		{
			pitch -= Time.deltaTime * 4f;
		}
		if (pitch <= 0f && !hitLow)
		{
			hitLow = true;
		}
		if (pitch <= 1f && hitLow)
		{
			pitch += Time.deltaTime * 3f;
		}
		if (hitLow && pitch >= 1f)
		{
			pitch = 1f;
			hitLow = false;
			shouldWobble = false;
		}
	}

	private void DeparentAndDestroyParticleSystem(ParticleSystem particleSystem)
	{
		//IL_0023: Unknown result type (might be due to invalid IL or missing references)
		//IL_0028: Unknown result type (might be due to invalid IL or missing references)
		if ((Object)(object)particleSystem != (Object)null && particleSystem.isPlaying)
		{
			((Component)particleSystem).gameObject.transform.parent = null;
			MainModule main = particleSystem.main;
			main.stopAction = (ParticleSystemStopAction)2;
			particleSystem.Stop(false);
		}
	}

	[PunRPC]
	private void PlayNewClipRPC(int index, int health, PhotonMessageInfo _info = default(PhotonMessageInfo))
	{
		//IL_0000: Unknown result type (might be due to invalid IL or missing references)
		//IL_004c: Unknown result type (might be due to invalid IL or missing references)
		if (SemiFunc.MasterOnlyRPC(_info))
		{
			syncedHealth = health;
			AudioClip val = shopMusicClips[index];
			AudioClip[] sounds = new AudioClip[1] { val };
			shopMusic.Sounds = sounds;
			shopMusic.AudioInfoFetched = false;
			soundGlitch.Play(physGrabObject.centerPoint);
			shouldWobble = true;
			spark.Play();
			prevIndex = index;
		}
	}

	[PunRPC]
	private void RandomClipOnAwakeRPC(int index, PhotonMessageInfo _info = default(PhotonMessageInfo))
	{
		//IL_0000: Unknown result type (might be due to invalid IL or missing references)
		if (SemiFunc.MasterOnlyRPC(_info))
		{
			AudioClip val = shopMusicClips[index];
			AudioClip[] sounds = new AudioClip[1] { val };
			shopMusic.Sounds = sounds;
			shopMusic.AudioInfoFetched = false;
		}
	}
}
