using System.Collections.Generic;
using Photon.Pun;
using UnityEngine;

public class SemiAreaOfEffect : MonoBehaviour
{
	public PrefabRef semiAffectPrefab;

	public float affectTimeMin;

	public float affectTimeMax;

	[Space]
	public bool useEnemyDifficulty;

	public float enemyHighestDifficultyTimeMin = 5f;

	public float enemyHighestDifficultyTimeMax = 5.5f;

	public float enemyLowestDifficultyTimeMin = 10f;

	public float enemyLowestDifficultyTimeMax = 12f;

	internal bool staffFeedback;

	private HurtCollider hurtCollider;

	private PhotonView photonView;

	private List<int> processedViewIDs = new List<int>();

	public Vector3 direction;

	public Vector3 position;

	private bool doingAreaOfEffect;

	private bool done;

	private List<PhysGrabObject> targetPhysObjectsForSingleplayer = new List<PhysGrabObject>();

	private List<PlayerAvatar> playerAvatars = new List<PlayerAvatar>();

	private void Awake()
	{
		photonView = ((Component)this).GetComponent<PhotonView>();
		hurtCollider = ((Component)this).GetComponentInChildren<HurtCollider>(true);
	}

	public void DoAreaOfEffect(Vector3 _position, Vector3 _direction)
	{
		//IL_0022: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0035: Unknown result type (might be due to invalid IL or missing references)
		//IL_0036: Unknown result type (might be due to invalid IL or missing references)
		//IL_003c: Unknown result type (might be due to invalid IL or missing references)
		//IL_003d: Unknown result type (might be due to invalid IL or missing references)
		if (!done && SemiFunc.IsMasterClientOrSingleplayer())
		{
			((Component)this).transform.SetParent((Transform)null);
			((Component)this).transform.position = _position;
			((Component)this).transform.forward = _direction;
			position = _position;
			direction = _direction;
			hurtCollider.detectionOnly = true;
			((Component)hurtCollider).gameObject.SetActive(true);
			doingAreaOfEffect = true;
			Object.Destroy((Object)(object)((Component)this).gameObject, 10f);
		}
	}

	private void Update()
	{
		//IL_028b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0291: Unknown result type (might be due to invalid IL or missing references)
		//IL_0298: Unknown result type (might be due to invalid IL or missing references)
		//IL_029e: Unknown result type (might be due to invalid IL or missing references)
		//IL_025a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0268: Unknown result type (might be due to invalid IL or missing references)
		if (!doingAreaOfEffect || done || !SemiFunc.IsMasterClientOrSingleplayer())
		{
			return;
		}
		if (hurtCollider.hits.Count <= 0)
		{
			processedViewIDs.Clear();
			return;
		}
		List<int> list = new List<int>();
		List<float> list2 = new List<float>();
		List<int> list3 = new List<int>();
		List<double> list4 = new List<double>();
		foreach (HurtCollider.Hit hit in hurtCollider.hits)
		{
			if (!Object.op_Implicit((Object)(object)hit.hitObject))
			{
				continue;
			}
			PhotonView val = hit.hitObject.GetComponent<PhotonView>();
			if (!Object.op_Implicit((Object)(object)val))
			{
				val = hit.hitObject.GetComponentInParent<PhotonView>();
			}
			if (!Object.op_Implicit((Object)(object)val))
			{
				continue;
			}
			if (!SemiFunc.IsMultiplayer())
			{
				PhysGrabObject componentInParent = hit.hitObject.GetComponentInParent<PhysGrabObject>();
				if ((Object)(object)componentInParent != (Object)null)
				{
					if (targetPhysObjectsForSingleplayer.Contains(componentInParent))
					{
						continue;
					}
					targetPhysObjectsForSingleplayer.Add(componentInParent);
				}
				PlayerAvatar playerAvatar = hit.hitObject.GetComponentInParent<PlayerAvatar>();
				if (!Object.op_Implicit((Object)(object)playerAvatar))
				{
					PlayerController componentInParent2 = hit.hitObject.GetComponentInParent<PlayerController>();
					if (Object.op_Implicit((Object)(object)componentInParent2))
					{
						playerAvatar = componentInParent2.playerAvatarScript;
					}
				}
				if (Object.op_Implicit((Object)(object)playerAvatar))
				{
					if (playerAvatars.Contains(playerAvatar))
					{
						continue;
					}
					playerAvatars.Add(playerAvatar);
				}
			}
			if (!processedViewIDs.Contains(val.ViewID))
			{
				float affectTime = GetAffectTime(hit.hitObject);
				processedViewIDs.Add(val.ViewID);
				list.Add(val.ViewID);
				list2.Add(affectTime);
				list3.Add((SemiFunc.IsMultiplayer() && Object.op_Implicit((Object)(object)PunManager.instance)) ? PunManager.instance.SemiAffectNetworkIDGet() : 0);
				list4.Add(SemiFunc.IsMultiplayer() ? (PhotonNetwork.Time + (double)affectTime) : 0.0);
			}
		}
		if (list.Count > 0)
		{
			int[] array = list.ToArray();
			float[] array2 = list2.ToArray();
			int[] array3 = list3.ToArray();
			double[] array4 = list4.ToArray();
			if (SemiFunc.IsMultiplayer())
			{
				photonView.RPC("CreateAffectsRPC", (RpcTarget)0, new object[6] { array, array2, array3, array4, position, direction });
				done = true;
			}
			else
			{
				CreateAffectsRPC(array, array2, array3, array4, position, direction);
				done = true;
			}
			doingAreaOfEffect = false;
		}
	}

	private float GetAffectTime(GameObject _target)
	{
		if (useEnemyDifficulty && Object.op_Implicit((Object)(object)_target))
		{
			EnemyParent componentInParent = _target.GetComponentInParent<EnemyParent>();
			if (Object.op_Implicit((Object)(object)componentInParent))
			{
				float num = (float)componentInParent.difficulty / 2f;
				float num2 = Mathf.Lerp(enemyLowestDifficultyTimeMin, enemyHighestDifficultyTimeMin, num);
				float num3 = Mathf.Lerp(enemyLowestDifficultyTimeMax, enemyHighestDifficultyTimeMax, num);
				return Random.Range(num2, num3);
			}
		}
		return Random.Range(affectTimeMin, affectTimeMax);
	}

	[PunRPC]
	private void CreateAffectsRPC(int[] photonViewIDs, float[] affectTimes, int[] _affectIDs, double[] _affectEndTimes, Vector3 _pos, Vector3 _dir, PhotonMessageInfo _info = default(PhotonMessageInfo))
	{
		//IL_0000: Unknown result type (might be due to invalid IL or missing references)
		//IL_000b: Unknown result type (might be due to invalid IL or missing references)
		//IL_000d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0013: Unknown result type (might be due to invalid IL or missing references)
		//IL_0015: Unknown result type (might be due to invalid IL or missing references)
		//IL_019f: Unknown result type (might be due to invalid IL or missing references)
		//IL_01a4: Unknown result type (might be due to invalid IL or missing references)
		//IL_01c1: Unknown result type (might be due to invalid IL or missing references)
		//IL_01c6: Unknown result type (might be due to invalid IL or missing references)
		//IL_01cd: Unknown result type (might be due to invalid IL or missing references)
		//IL_01d2: Unknown result type (might be due to invalid IL or missing references)
		//IL_005b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0060: Unknown result type (might be due to invalid IL or missing references)
		//IL_007d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0082: Unknown result type (might be due to invalid IL or missing references)
		//IL_0089: Unknown result type (might be due to invalid IL or missing references)
		//IL_008e: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ec: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f1: Unknown result type (might be due to invalid IL or missing references)
		//IL_010e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0113: Unknown result type (might be due to invalid IL or missing references)
		//IL_011a: Unknown result type (might be due to invalid IL or missing references)
		//IL_011f: Unknown result type (might be due to invalid IL or missing references)
		if (!SemiFunc.MasterOnlyRPC(_info))
		{
			return;
		}
		position = _pos;
		direction = _dir;
		Object.Destroy((Object)(object)((Component)this).gameObject, 8f);
		if (!SemiFunc.IsMultiplayer())
		{
			foreach (PhysGrabObject item in targetPhysObjectsForSingleplayer)
			{
				SemiAffect component = Object.Instantiate<GameObject>(semiAffectPrefab.Prefab, ((Component)item).transform.position, Quaternion.identity).GetComponent<SemiAffect>();
				component.staffFeedback = staffFeedback;
				component.direction = direction;
				component.positionOfOriginalAreaOfEffect = position;
				component.SetupSingleplayer(((Component)item).transform, item, GetAffectTime(((Component)item).gameObject));
			}
			{
				foreach (PlayerAvatar playerAvatar in playerAvatars)
				{
					SemiAffect component2 = Object.Instantiate<GameObject>(semiAffectPrefab.Prefab, ((Component)playerAvatar).transform.position, Quaternion.identity).GetComponent<SemiAffect>();
					component2.staffFeedback = staffFeedback;
					component2.direction = direction;
					component2.positionOfOriginalAreaOfEffect = position;
					component2.SetupSingleplayer(((Component)playerAvatar).transform, playerAvatar.tumble.physGrabObject, GetAffectTime(((Component)playerAvatar).gameObject), playerAvatar);
				}
				return;
			}
		}
		for (int i = 0; i < photonViewIDs.Length; i++)
		{
			PhotonView val = PhotonView.Find(photonViewIDs[i]);
			if (!((Object)(object)val == (Object)null))
			{
				string resourcePath = semiAffectPrefab.ResourcePath;
				SemiAffect component3 = Object.Instantiate<GameObject>(semiAffectPrefab.Prefab, ((Component)val).transform.position, Quaternion.identity).GetComponent<SemiAffect>();
				component3.staffFeedback = staffFeedback;
				component3.direction = direction;
				component3.positionOfOriginalAreaOfEffect = position;
				component3.Setup(photonViewIDs[i], affectTimes[i], _affectIDs[i], _affectEndTimes[i], resourcePath);
			}
		}
	}
}
