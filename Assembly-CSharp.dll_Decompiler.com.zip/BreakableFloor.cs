using System;
using System.Collections.Generic;
using Photon.Pun;
using UnityEngine;

public class BreakableFloor : MonoBehaviour
{
	private enum State
	{
		Idle,
		Breaking,
		Break,
		Broken
	}

	[Serializable]
	public class ObjectSwitch
	{
		public string name;

		public GameObject idle;

		public GameObject broken;
	}

	private State stateCurrent;

	private bool stateImpulse;

	private float stateTimer;

	private bool quickBreak;

	private bool instantBreak;

	private PhotonView photonView;

	private BreakableFloorTrigger breakableFloorTrigger;

	private List<DirtFinderMapFloor> mapFloors = new List<DirtFinderMapFloor>();

	private BreakableFloorCondition[] breakableFloorConditions;

	public GameObject playerCollision;

	public BoxCollider stunCollider;

	public List<PhysGrabObject> physGrabObjects;

	public List<ObjectSwitch> objectSwitches;

	[Space]
	public GameObject breakingParticlesParent;

	public GameObject breakParticlesParent;

	[Space]
	public Sound soundBreaking;

	public Sound soundBreak;

	[Space]
	public List<DirtFinderMapFloor> mapCustomFloorsIdle;

	public List<DirtFinderMapFloor> mapCustomFloorsBroken;

	private void Awake()
	{
		photonView = ((Component)this).GetComponent<PhotonView>();
		breakableFloorTrigger = ((Component)this).GetComponentInChildren<BreakableFloorTrigger>();
		mapFloors.AddRange(((Component)this).GetComponentsInChildren<DirtFinderMapFloor>());
		breakableFloorConditions = ((Component)this).GetComponentsInChildren<BreakableFloorCondition>();
	}

	private void Start()
	{
		if (mapCustomFloorsBroken.Count <= 0)
		{
			return;
		}
		foreach (DirtFinderMapFloor item in mapCustomFloorsBroken)
		{
			if (Object.op_Implicit((Object)(object)item.MapObject))
			{
				item.MapObject.Hide();
			}
		}
	}

	private void Update()
	{
		if (LevelGenerator.Instance.Generated)
		{
			StateMachine(_fixedUpdate: false);
		}
	}

	private void FixedUpdate()
	{
		if (LevelGenerator.Instance.Generated)
		{
			StateMachine(_fixedUpdate: true);
		}
	}

	private void StateIdle(bool _fixedUpdate)
	{
		if (stateImpulse)
		{
			stateImpulse = false;
			stateTimer = 2f;
		}
		if (!_fixedUpdate)
		{
			PhysObjectLogic();
			stateTimer -= Time.deltaTime;
		}
	}

	private void StateBreaking(bool _fixedUpdate)
	{
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0088: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d9: Unknown result type (might be due to invalid IL or missing references)
		if (stateImpulse)
		{
			stateImpulse = false;
			if (instantBreak)
			{
				stateTimer = 0.1f;
			}
			else if (quickBreak)
			{
				stateTimer = 0.25f;
			}
			else
			{
				stateTimer = 1f;
			}
			if (Object.op_Implicit((Object)(object)breakableFloorTrigger))
			{
				SemiFunc.CameraShakeDistance(((Component)breakableFloorTrigger).transform.position, 1.5f, 0.5f, 5f, 10f);
				SemiFunc.CameraShakeImpactDistance(((Component)breakableFloorTrigger).transform.position, 1.5f, 0.1f, 5f, 10f);
			}
			ParticleSystem[] componentsInChildren = breakingParticlesParent.GetComponentsInChildren<ParticleSystem>();
			for (int i = 0; i < componentsInChildren.Length; i++)
			{
				componentsInChildren[i].Play();
			}
			soundBreaking.Play(breakingParticlesParent.transform.position);
		}
		if (_fixedUpdate)
		{
			return;
		}
		stateTimer -= Time.deltaTime;
		PhysObjectLogic();
		if (!SemiFunc.IsMasterClientOrSingleplayer() || !(stateTimer <= 0f))
		{
			return;
		}
		bool flag = true;
		BreakableFloorCondition[] array = breakableFloorConditions;
		foreach (BreakableFloorCondition breakableFloorCondition in array)
		{
			if (Object.op_Implicit((Object)(object)breakableFloorCondition) && !breakableFloorCondition.ConditionCheck())
			{
				flag = false;
				break;
			}
		}
		if (!flag)
		{
			StateSet(State.Idle);
		}
		else if (instantBreak || Random.Range(0f, 1f) < 0.5f)
		{
			StateSet(State.Break);
		}
		else
		{
			StateSet(State.Idle);
		}
	}

	private void StateBreak(bool _fixedUpdate)
	{
		//IL_0023: Unknown result type (might be due to invalid IL or missing references)
		//IL_004c: Unknown result type (might be due to invalid IL or missing references)
		//IL_02f8: Unknown result type (might be due to invalid IL or missing references)
		//IL_0246: Unknown result type (might be due to invalid IL or missing references)
		//IL_024b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0255: Unknown result type (might be due to invalid IL or missing references)
		//IL_0266: Unknown result type (might be due to invalid IL or missing references)
		//IL_026b: Unknown result type (might be due to invalid IL or missing references)
		//IL_026f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0279: Unknown result type (might be due to invalid IL or missing references)
		//IL_0289: Unknown result type (might be due to invalid IL or missing references)
		//IL_0293: Unknown result type (might be due to invalid IL or missing references)
		if (stateImpulse)
		{
			if (Object.op_Implicit((Object)(object)breakableFloorTrigger))
			{
				SemiFunc.CameraShakeDistance(((Component)breakableFloorTrigger).transform.position, 5f, 0.5f, 5f, 10f);
				SemiFunc.CameraShakeImpactDistance(((Component)breakableFloorTrigger).transform.position, 5f, 0.25f, 5f, 10f);
			}
			if (mapCustomFloorsIdle.Count > 0 && mapCustomFloorsBroken.Count > 0)
			{
				foreach (DirtFinderMapFloor item in mapCustomFloorsIdle)
				{
					if (Object.op_Implicit((Object)(object)item.MapObject))
					{
						item.MapObject.Hide();
					}
				}
				foreach (DirtFinderMapFloor item2 in mapCustomFloorsBroken)
				{
					if (Object.op_Implicit((Object)(object)item2.MapObject))
					{
						item2.MapObject.Show();
					}
				}
			}
			else
			{
				foreach (DirtFinderMapFloor mapFloor in mapFloors)
				{
					if (Object.op_Implicit((Object)(object)mapFloor.MapObject))
					{
						mapFloor.MapObject.Hide();
					}
				}
			}
			if (Object.op_Implicit((Object)(object)playerCollision))
			{
				Object.Destroy((Object)(object)playerCollision);
			}
			if (Object.op_Implicit((Object)(object)breakableFloorTrigger))
			{
				Object.Destroy((Object)(object)((Component)breakableFloorTrigger).gameObject);
			}
			foreach (ObjectSwitch objectSwitch in objectSwitches)
			{
				objectSwitch.idle.SetActive(false);
				objectSwitch.broken.SetActive(true);
			}
			BreakableFloorCondition[] array = breakableFloorConditions;
			foreach (BreakableFloorCondition breakableFloorCondition in array)
			{
				if (Object.op_Implicit((Object)(object)breakableFloorCondition))
				{
					breakableFloorCondition.BreakImpulse();
				}
			}
			if (SemiFunc.IsMasterClientOrSingleplayer())
			{
				foreach (PhysGrabObject physGrabObject in physGrabObjects)
				{
					physGrabObject.OverrideKinematic(0f);
					physGrabObject.PhysRidingDisabledSet(_state: false);
					physGrabObject.rb.AddRelativeTorque(-Vector3.left * 3f, (ForceMode)1);
					Rigidbody rb = physGrabObject.rb;
					Vector3 insideUnitSphere = Random.insideUnitSphere;
					rb.AddTorque(insideUnitSphere.normalized * 0.25f, (ForceMode)1);
					physGrabObject.rb.AddForce(Vector3.down * 5f, (ForceMode)1);
				}
				StunColliderLogic();
			}
			ParticleSystem[] componentsInChildren = breakParticlesParent.GetComponentsInChildren<ParticleSystem>();
			for (int i = 0; i < componentsInChildren.Length; i++)
			{
				componentsInChildren[i].Play();
			}
			soundBreak.Play(breakParticlesParent.transform.position);
			stateImpulse = false;
			stateTimer = 1f;
		}
		if (!_fixedUpdate)
		{
			stateTimer -= Time.deltaTime;
			if (SemiFunc.IsMasterClientOrSingleplayer() && stateTimer <= 0f)
			{
				StateSet(State.Broken);
			}
		}
	}

	private void StateBroken(bool _fixedUpdate)
	{
		if (stateImpulse)
		{
			stateImpulse = false;
		}
	}

	private void StateMachine(bool _fixedUpdate)
	{
		switch (stateCurrent)
		{
		case State.Idle:
			StateIdle(_fixedUpdate);
			break;
		case State.Breaking:
			StateBreaking(_fixedUpdate);
			break;
		case State.Break:
			StateBreak(_fixedUpdate);
			break;
		case State.Broken:
			StateBroken(_fixedUpdate);
			break;
		}
	}

	private void StateSet(State _state)
	{
		//IL_003d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0043: Unknown result type (might be due to invalid IL or missing references)
		if (SemiFunc.IsMasterClientOrSingleplayer() && _state != stateCurrent)
		{
			if (GameManager.Multiplayer())
			{
				photonView.RPC("StateSetRPC", (RpcTarget)0, new object[1] { _state });
			}
			else
			{
				StateSetRPC(_state);
			}
		}
	}

	private void PhysObjectLogic()
	{
		bool flag = SemiFunc.IsMasterClientOrSingleplayer();
		foreach (PhysGrabObject physGrabObject in physGrabObjects)
		{
			if (flag)
			{
				if (!physGrabObject.physRidingDisabled)
				{
					physGrabObject.PhysRidingDisabledSet(_state: true);
				}
				physGrabObject.OverrideKinematic();
				physGrabObject.OverrideIndestructible();
			}
			physGrabObject.OverrideGrabDisable();
			physGrabObject.OverrideDroneTargetDisable();
		}
	}

	public void TriggerImpulse(bool _quickBreak, bool _instantBreak)
	{
		if (stateCurrent == State.Idle && stateTimer <= 0f)
		{
			quickBreak = _quickBreak;
			instantBreak = _instantBreak;
			StateSet(State.Breaking);
		}
	}

	private void StunColliderLogic()
	{
		//IL_000d: Unknown result type (might be due to invalid IL or missing references)
		//IL_001d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0033: Unknown result type (might be due to invalid IL or missing references)
		//IL_0043: Unknown result type (might be due to invalid IL or missing references)
		//IL_0059: Unknown result type (might be due to invalid IL or missing references)
		//IL_0069: Unknown result type (might be due to invalid IL or missing references)
		//IL_0074: Unknown result type (might be due to invalid IL or missing references)
		//IL_008a: Unknown result type (might be due to invalid IL or missing references)
		//IL_008f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0094: Unknown result type (might be due to invalid IL or missing references)
		//IL_009a: Unknown result type (might be due to invalid IL or missing references)
		//IL_00aa: Unknown result type (might be due to invalid IL or missing references)
		//IL_00af: Unknown result type (might be due to invalid IL or missing references)
		//IL_0132: Unknown result type (might be due to invalid IL or missing references)
		//IL_013c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0154: Unknown result type (might be due to invalid IL or missing references)
		//IL_0159: Unknown result type (might be due to invalid IL or missing references)
		//IL_0163: Unknown result type (might be due to invalid IL or missing references)
		//IL_0226: Unknown result type (might be due to invalid IL or missing references)
		//IL_0230: Unknown result type (might be due to invalid IL or missing references)
		Vector3 val = new Vector3(((Component)stunCollider).transform.lossyScale.x * stunCollider.size.x, ((Component)stunCollider).transform.lossyScale.y * stunCollider.size.y, ((Component)stunCollider).transform.lossyScale.z * stunCollider.size.z);
		Collider[] array = Physics.OverlapBox(((Component)stunCollider).transform.TransformPoint(stunCollider.center), val / 2f, ((Component)stunCollider).transform.rotation, LayerMask.op_Implicit(SemiFunc.LayerMaskGetPlayersAndPhysObjects()));
		foreach (Collider val2 in array)
		{
			PlayerController componentInParent = ((Component)val2).GetComponentInParent<PlayerController>();
			PlayerAvatar playerAvatar;
			if (Object.op_Implicit((Object)(object)componentInParent))
			{
				playerAvatar = componentInParent.playerAvatarScript;
			}
			else
			{
				playerAvatar = ((Component)val2).GetComponentInParent<PlayerAvatar>();
				if (!Object.op_Implicit((Object)(object)playerAvatar))
				{
					PlayerTumble componentInParent2 = ((Component)val2).GetComponentInParent<PlayerTumble>();
					if (Object.op_Implicit((Object)(object)componentInParent2))
					{
						playerAvatar = componentInParent2.playerAvatar;
					}
				}
			}
			if (Object.op_Implicit((Object)(object)playerAvatar))
			{
				playerAvatar.tumble.TumbleRequest(_isTumbling: true, _playerInput: false);
				playerAvatar.tumble.TumbleForce(Vector3.down * 10f);
				playerAvatar.tumble.TumbleTorque(-((Component)playerAvatar).transform.right * 45f);
				playerAvatar.tumble.TumbleOverrideTime(1.5f);
				playerAvatar.tumble.ImpactHurtSet(3f, 10);
				playerAvatar.tumble.breakableFloorTimer = 2f;
			}
			EnemyRigidbody componentInParent3 = ((Component)val2).GetComponentInParent<EnemyRigidbody>();
			if (!Object.op_Implicit((Object)(object)componentInParent3))
			{
				continue;
			}
			if (componentInParent3.enemy.HasStateStunned)
			{
				float time = 0f;
				switch (componentInParent3.enemy.EnemyParent.difficulty)
				{
				case EnemyParent.Difficulty.Difficulty1:
					time = 6f;
					break;
				case EnemyParent.Difficulty.Difficulty2:
					time = 5f;
					break;
				case EnemyParent.Difficulty.Difficulty3:
					time = 4f;
					break;
				}
				componentInParent3.enemy.StateStunned.Set(time);
			}
			componentInParent3.rb.AddForce(Vector3.down * 10f, (ForceMode)1);
		}
	}

	[PunRPC]
	private void StateSetRPC(State _state, PhotonMessageInfo _info = default(PhotonMessageInfo))
	{
		//IL_0000: Unknown result type (might be due to invalid IL or missing references)
		if (SemiFunc.MasterOnlyRPC(_info))
		{
			stateCurrent = _state;
			stateImpulse = true;
			stateTimer = 0f;
			if (breakableFloorConditions != null)
			{
				StateMachine(_fixedUpdate: false);
			}
		}
	}
}
