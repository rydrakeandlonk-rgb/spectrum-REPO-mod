using System.Collections;
using System.Collections.Generic;
using Photon.Pun;
using UnityEngine;

[RequireComponent(typeof(PhotonView))]
public class RockSlide : MonoBehaviour
{
	public enum State
	{
		WaitingForPlayer,
		InitialDelay,
		WaitingForPlayerReset,
		Ready,
		Cooldown,
		Done
	}

	public PrefabRef rockPrefab;

	public Vector2Int rockCount = new Vector2Int(4, 8);

	[Tooltip("how many slides fire in a row at this spawn")]
	public Vector2Int slideCount = new Vector2Int(1, 3);

	[Tooltip("gap between back to back slides")]
	public Vector2 slideGap = new Vector2(2f, 4f);

	[Tooltip("quiet beat after the sound before the rocks start falling")]
	public Vector2 spawnDelay = new Vector2(1.5f, 2.5f);

	[Tooltip("rocks fall across this many seconds, bigger = more spread out")]
	public float spawnDuration = 3f;

	public float rockSpawnSpread = 1.5f;

	public float rockSpawnMinDistance = 1f;

	public int spawnPlacementAttempts = 16;

	public float targetSpread = 3f;

	[Range(1f, 90f)]
	public float placementAngle = 35f;

	[Tooltip("target has to sit inside this distance band, down the slide cone, for the slide to trigger")]
	public Vector2 triggerDistanceRange = new Vector2(25f, 60f);

	[Tooltip("auto-capped to the inner trigger distance so the band always has a live zone just outside the suppression sphere")]
	public float playerSeeDistance = 25f;

	public float rockslideRadius = 10f;

	[Tooltip("how many separate rock slide events this spawn can do before it is done")]
	public Vector2Int rockSlideCount = new Vector2Int(1, 3);

	[Range(0f, 100f)]
	[Tooltip("chance that this spawn will activate at all after the first player trigger")]
	public int rockSlideRisk = 100;

	[Tooltip("wait after the first player trigger, 0-300 seconds is the 0-5 min band")]
	public Vector2 triggerDelay = new Vector2(0f, 300f);

	[Tooltip("wait between rock slide events, 120-900 seconds is the 2-15 min band")]
	public Vector2 cooldown = new Vector2(120f, 900f);

	public float shakeStrength = 6f;

	public float shakeTime = 1f;

	public float shakeImpactStrength = 10f;

	public Sound triggerSound;

	public bool debugDetection;

	private PhotonView photonView;

	private State currentState;

	private float stateTimer;

	private int rockSlidesMax;

	private int rockSlidesDone;

	private int visionObstructMask;

	private Vector3 SlideDirection
	{
		get
		{
			//IL_0006: Unknown result type (might be due to invalid IL or missing references)
			//IL_000b: Unknown result type (might be due to invalid IL or missing references)
			return -((Component)this).transform.up;
		}
	}

	private void Awake()
	{
		//IL_000d: Unknown result type (might be due to invalid IL or missing references)
		photonView = ((Component)this).GetComponent<PhotonView>();
		visionObstructMask = LayerMask.op_Implicit(SemiFunc.LayerMaskGetVisionObstruct()) & ~(1 << LayerMask.NameToLayer("Player"));
	}

	private void Update()
	{
		if (SemiFunc.IsMasterClientOrSingleplayer())
		{
			StateMachine();
		}
	}

	private void StateMachine()
	{
		switch (currentState)
		{
		case State.WaitingForPlayer:
			StateWaitingForPlayer();
			break;
		case State.InitialDelay:
			StateInitialDelay();
			break;
		case State.WaitingForPlayerReset:
			StateWaitingForPlayerReset();
			break;
		case State.Ready:
			StateReady();
			break;
		case State.Cooldown:
			StateCooldown();
			break;
		}
	}

	private void StateWaitingForPlayer()
	{
		if (!SemiFunc.PerSecond(2f, (Object)(object)this))
		{
			return;
		}
		PlayerAvatar playerAvatar = FindTarget();
		if (Object.op_Implicit((Object)(object)playerAvatar))
		{
			rockSlidesMax = Random.Range(rockSlideCount.x, rockSlideCount.y + 1);
			if (Random.Range(0, 100) >= rockSlideRisk)
			{
				DebugDetection(playerAvatar.playerName + " triggered the risk roll, this spawn will stay quiet");
				StateSet(State.Done);
			}
			else
			{
				stateTimer = Random.Range(triggerDelay.x, triggerDelay.y);
				DebugDetection(playerAvatar.playerName + " triggered the risk roll, armed for " + stateTimer.ToString("F0") + " seconds");
				StateSet(State.InitialDelay);
			}
		}
	}

	private void StateInitialDelay()
	{
		StateTimerTick();
		if (!(stateTimer > 0f))
		{
			StateSet(State.WaitingForPlayerReset);
		}
	}

	private void StateWaitingForPlayerReset()
	{
		if (SemiFunc.PerSecond(2f, (Object)(object)this) && !Object.op_Implicit((Object)(object)FindTarget()))
		{
			StateSet(State.Ready);
		}
	}

	private void StateReady()
	{
		if (SemiFunc.PerSecond(2f, (Object)(object)this))
		{
			PlayerAvatar playerAvatar = FindTarget();
			if (Object.op_Implicit((Object)(object)playerAvatar))
			{
				TriggerRockSlide(playerAvatar);
			}
		}
	}

	private void StateCooldown()
	{
		StateTimerTick();
		if (!(stateTimer > 0f))
		{
			StateSet(State.WaitingForPlayerReset);
		}
	}

	private void StateSet(State _state)
	{
		if (currentState != _state)
		{
			currentState = _state;
		}
	}

	private PlayerAvatar FindTarget()
	{
		//IL_0032: Unknown result type (might be due to invalid IL or missing references)
		//IL_0042: Unknown result type (might be due to invalid IL or missing references)
		//IL_004c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0057: Unknown result type (might be due to invalid IL or missing references)
		//IL_005c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0061: Unknown result type (might be due to invalid IL or missing references)
		//IL_0079: Unknown result type (might be due to invalid IL or missing references)
		//IL_007e: Unknown result type (might be due to invalid IL or missing references)
		//IL_017c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0181: Unknown result type (might be due to invalid IL or missing references)
		//IL_0185: Unknown result type (might be due to invalid IL or missing references)
		PlayerAvatar playerAvatar = null;
		float num = float.MaxValue;
		foreach (PlayerAvatar item in SemiFunc.PlayerGetList())
		{
			if (!PlayerIsValid(item))
			{
				continue;
			}
			Vector3 val = Vector3.Lerp(((Component)item).transform.position, item.PlayerVisionTarget.VisionTransform.position, 0.5f) - ((Component)this).transform.position;
			float magnitude = val.magnitude;
			if (magnitude < 0.01f)
			{
				continue;
			}
			float num2 = Vector3.Angle(SlideDirection, val);
			bool flag = magnitude <= playerSeeDistance;
			bool flag2 = magnitude >= triggerDistanceRange.x && magnitude <= triggerDistanceRange.y && num2 <= placementAngle;
			if (!flag && !flag2)
			{
				DebugDetection(item.playerName + " out of the green wedge: " + magnitude.ToString("F1") + "m at " + num2.ToString("F0") + "deg (needs " + triggerDistanceRange.x + "-" + triggerDistanceRange.y + "m within " + placementAngle + "deg)");
			}
			else if (Physics.Raycast(((Component)this).transform.position, val / magnitude, magnitude, visionObstructMask, (QueryTriggerInteraction)1))
			{
				DebugDetection(item.playerName + " blocked, no line of sight from the spawner pivot");
			}
			else
			{
				if (flag)
				{
					DebugDetection(item.playerName + " inside the suppression radius, slide held back");
					return null;
				}
				if (flag2 && magnitude < num)
				{
					num = magnitude;
					playerAvatar = item;
				}
			}
		}
		if (Object.op_Implicit((Object)(object)playerAvatar))
		{
			DebugDetection(playerAvatar.playerName + " locked as trigger target");
		}
		return playerAvatar;
	}

	private void DebugDetection(string _message)
	{
		//IL_001a: Unknown result type (might be due to invalid IL or missing references)
		if (debugDetection)
		{
			SemiFunc.Log("rockslide: " + _message, ((Component)this).gameObject, Color.yellow);
		}
	}

	private bool PlayerIsValid(PlayerAvatar _player)
	{
		if (!Object.op_Implicit((Object)(object)_player))
		{
			return false;
		}
		if (_player.deadSet)
		{
			return false;
		}
		if (_player.isDisabled)
		{
			return false;
		}
		if (_player.spectating)
		{
			return false;
		}
		return true;
	}

	private void TriggerRockSlide(PlayerAvatar _target)
	{
		//IL_0055: Unknown result type (might be due to invalid IL or missing references)
		rockSlidesDone++;
		if (rockSlidesDone >= rockSlidesMax)
		{
			StateSet(State.Done);
		}
		else
		{
			stateTimer = Random.Range(cooldown.x, cooldown.y);
			StateSet(State.Cooldown);
		}
		((MonoBehaviour)this).StartCoroutine(RockSlideSequence(((Component)_target).transform.position));
	}

	private IEnumerator RockSlideSequence(Vector3 _targetPosition)
	{
		//IL_000e: Unknown result type (might be due to invalid IL or missing references)
		//IL_000f: Unknown result type (might be due to invalid IL or missing references)
		int _slides = Random.Range(slideCount.x, slideCount.y + 1);
		for (int _i = 0; _i < _slides; _i++)
		{
			FireRockSlide(_targetPosition);
			yield return (object)new WaitForSeconds(Random.Range(slideGap.x, slideGap.y));
		}
	}

	private void FireRockSlide(Vector3 _targetPosition)
	{
		//IL_0029: Unknown result type (might be due to invalid IL or missing references)
		//IL_002c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0032: Unknown result type (might be due to invalid IL or missing references)
		//IL_001b: Unknown result type (might be due to invalid IL or missing references)
		if (SemiFunc.IsMultiplayer())
		{
			photonView.RPC("RockSlideRPC", (RpcTarget)0, new object[1] { _targetPosition });
		}
		else
		{
			RockSlideRPC(_targetPosition);
		}
	}

	[PunRPC]
	private void RockSlideRPC(Vector3 _targetPosition, PhotonMessageInfo _info = default(PhotonMessageInfo))
	{
		//IL_0000: Unknown result type (might be due to invalid IL or missing references)
		//IL_0015: Unknown result type (might be due to invalid IL or missing references)
		//IL_0034: Unknown result type (might be due to invalid IL or missing references)
		//IL_0051: Unknown result type (might be due to invalid IL or missing references)
		//IL_0077: Unknown result type (might be due to invalid IL or missing references)
		if (SemiFunc.MasterOnlyRPC(_info))
		{
			triggerSound.Play(((Component)this).transform.position);
			SemiFunc.CameraShakeDistance(_targetPosition, shakeStrength, shakeTime, 0f, rockslideRadius);
			SemiFunc.CameraShakeImpactDistance(_targetPosition, shakeImpactStrength, shakeTime, 0f, rockslideRadius);
			if (SemiFunc.IsMasterClientOrSingleplayer())
			{
				((MonoBehaviour)this).StartCoroutine(SpawnRocks(_targetPosition));
			}
		}
	}

	private IEnumerator SpawnRocks(Vector3 _targetPosition)
	{
		//IL_000e: Unknown result type (might be due to invalid IL or missing references)
		//IL_000f: Unknown result type (might be due to invalid IL or missing references)
		yield return (object)new WaitForSeconds(Random.Range(spawnDelay.x, spawnDelay.y));
		int _count = Random.Range(rockCount.x, rockCount.y + 1);
		float _delay = spawnDuration / (float)_count;
		List<Vector3> _usedPositions = new List<Vector3>();
		for (int _i = 0; _i < _count; _i++)
		{
			SpawnRock(_targetPosition, _usedPositions);
			yield return (object)new WaitForSeconds(_delay);
		}
	}

	private void SpawnRock(Vector3 _targetPosition, List<Vector3> _usedPositions)
	{
		//IL_001b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0021: Unknown result type (might be due to invalid IL or missing references)
		//IL_002c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0032: Unknown result type (might be due to invalid IL or missing references)
		//IL_0037: Unknown result type (might be due to invalid IL or missing references)
		//IL_003c: Unknown result type (might be due to invalid IL or missing references)
		//IL_003d: Unknown result type (might be due to invalid IL or missing references)
		//IL_003e: Unknown result type (might be due to invalid IL or missing references)
		//IL_003f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0044: Unknown result type (might be due to invalid IL or missing references)
		//IL_0045: Unknown result type (might be due to invalid IL or missing references)
		//IL_004a: Unknown result type (might be due to invalid IL or missing references)
		//IL_004e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0053: Unknown result type (might be due to invalid IL or missing references)
		//IL_0081: Unknown result type (might be due to invalid IL or missing references)
		//IL_0082: Unknown result type (might be due to invalid IL or missing references)
		//IL_0066: Unknown result type (might be due to invalid IL or missing references)
		//IL_0067: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c0: Unknown result type (might be due to invalid IL or missing references)
		if (rockPrefab.IsValid() && TryGetSpawnPosition(_usedPositions, out var _spawnPosition))
		{
			_usedPositions.Add(_spawnPosition);
			Vector3 val = Vector3.ProjectOnPlane(Random.insideUnitSphere * targetSpread, SlideDirection);
			Vector3 val2 = _targetPosition + val - _spawnPosition;
			Vector3 normalized = val2.normalized;
			GameObject val3 = ((!SemiFunc.IsMultiplayer()) ? Object.Instantiate<GameObject>(rockPrefab.Prefab, _spawnPosition, Random.rotation) : PhotonNetwork.Instantiate(rockPrefab.ResourcePath, _spawnPosition, Random.rotation, (byte)0, (object[])null));
			RockSlideRock component = val3.GetComponent<RockSlideRock>();
			if (Object.op_Implicit((Object)(object)component))
			{
				float sizeMultiplier = Random.Range(component.sizeRange.x, component.sizeRange.y);
				component.Launch(normalized, sizeMultiplier);
			}
		}
	}

	private bool TryGetSpawnPosition(List<Vector3> _usedPositions, out Vector3 _spawnPosition)
	{
		//IL_000a: Unknown result type (might be due to invalid IL or missing references)
		//IL_000f: Unknown result type (might be due to invalid IL or missing references)
		//IL_001a: Unknown result type (might be due to invalid IL or missing references)
		//IL_001f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_0026: Unknown result type (might be due to invalid IL or missing references)
		//IL_004f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0054: Unknown result type (might be due to invalid IL or missing references)
		//IL_002f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0039: Unknown result type (might be due to invalid IL or missing references)
		//IL_003a: Unknown result type (might be due to invalid IL or missing references)
		for (int i = 0; i < spawnPlacementAttempts; i++)
		{
			Vector3 val = ((Component)this).transform.position + Random.insideUnitSphere * rockSpawnSpread;
			if (PositionHasClearView(val) && !PositionOverlaps(val, _usedPositions))
			{
				_spawnPosition = val;
				return true;
			}
		}
		_spawnPosition = Vector3.zero;
		return false;
	}

	private bool PositionHasClearView(Vector3 _position)
	{
		//IL_0000: Unknown result type (might be due to invalid IL or missing references)
		//IL_0007: Unknown result type (might be due to invalid IL or missing references)
		//IL_000c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0011: Unknown result type (might be due to invalid IL or missing references)
		//IL_002a: Unknown result type (might be due to invalid IL or missing references)
		//IL_002f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0031: Unknown result type (might be due to invalid IL or missing references)
		Vector3 val = _position - ((Component)this).transform.position;
		float magnitude = val.magnitude;
		if (magnitude < 0.01f)
		{
			return true;
		}
		return !Physics.Raycast(((Component)this).transform.position, val / magnitude, magnitude, visionObstructMask, (QueryTriggerInteraction)1);
	}

	private bool PositionOverlaps(Vector3 _position, List<Vector3> _usedPositions)
	{
		//IL_000b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0010: Unknown result type (might be due to invalid IL or missing references)
		//IL_0011: Unknown result type (might be due to invalid IL or missing references)
		//IL_0012: Unknown result type (might be due to invalid IL or missing references)
		foreach (Vector3 _usedPosition in _usedPositions)
		{
			if (Vector3.Distance(_position, _usedPosition) < rockSpawnMinDistance)
			{
				return true;
			}
		}
		return false;
	}

	private void StateTimerTick()
	{
		if (stateTimer > 0f)
		{
			stateTimer -= Time.deltaTime;
		}
	}

	public RockSlide()
	{
		//IL_0003: Unknown result type (might be due to invalid IL or missing references)
		//IL_0008: Unknown result type (might be due to invalid IL or missing references)
		//IL_0010: Unknown result type (might be due to invalid IL or missing references)
		//IL_0015: Unknown result type (might be due to invalid IL or missing references)
		//IL_0025: Unknown result type (might be due to invalid IL or missing references)
		//IL_002a: Unknown result type (might be due to invalid IL or missing references)
		//IL_003a: Unknown result type (might be due to invalid IL or missing references)
		//IL_003f: Unknown result type (might be due to invalid IL or missing references)
		//IL_008e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0093: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b1: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b6: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ce: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e8: Unknown result type (might be due to invalid IL or missing references)
	}
}
