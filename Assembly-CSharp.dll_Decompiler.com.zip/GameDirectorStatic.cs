using UnityEngine;

public static class GameDirectorStatic
{
	public static bool CatchCutscenePlayed;

	[RuntimeInitializeOnLoadMethod(/*Could not decode attribute arguments.*/)]
	private static void RuntimeInitializeOnLoad()
	{
		CatchCutscenePlayed = false;
	}
}
