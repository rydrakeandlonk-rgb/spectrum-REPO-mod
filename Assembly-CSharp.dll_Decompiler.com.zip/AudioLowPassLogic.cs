using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[RequireComponent(typeof(AudioLowPassFilter))]
public class AudioLowPassLogic : MonoBehaviour
{
	public bool LowPass;

	internal bool IgnoreLowPass;

	[Space]
	public bool ForceStart;

	public bool AlwaysActive;

	[Space]
	public bool HasCustomVolume;

	[Range(0f, 1f)]
	public float CustomVolume = 0.5f;

	private float VolumeMultiplier = 0.5f;

	[Space]
	public bool HasCustomFalloff;

	[Range(0f, 1f)]
	public float CustomFalloff = 0.8f;

	private float FalloffMultiplier = 0.8f;

	internal bool Fetch = true;

	private bool First = true;

	private bool LogicActive;

	internal float Falloff;

	private float LowPassMin = 1000f;

	private float LowPassMax = 22000f;

	private AudioLowPassFilter AudioLowpassFilter;

	private AudioSource AudioSource;

	private LayerMask LayerMask;

	private LayerMask LayerMaskOverlap;

	internal bool volumeFetched;

	internal float Volume;

	internal float SpatialBlend;

	internal List<Collider> LowPassIgnoreColliders = new List<Collider>();

	private Transform audioListener;

	private void Start()
	{
		if (ForceStart)
		{
			Setup();
		}
	}

	public void Setup()
	{
		//IL_00c5: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ca: Unknown result type (might be due to invalid IL or missing references)
		//IL_00fb: Unknown result type (might be due to invalid IL or missing references)
		//IL_0100: Unknown result type (might be due to invalid IL or missing references)
		if (Fetch)
		{
			if (Object.op_Implicit((Object)(object)AudioListenerFollow.instance))
			{
				audioListener = ((Component)AudioListenerFollow.instance).transform;
			}
			AudioLowpassFilter = ((Component)this).GetComponent<AudioLowPassFilter>();
			AudioSource = ((Component)this).GetComponent<AudioSource>();
			if (Object.op_Implicit((Object)(object)AudioManager.instance))
			{
				LowPassMin = AudioManager.instance.lowpassValueMin;
				LowPassMax = AudioManager.instance.lowpassValueMax;
			}
			if (HasCustomFalloff)
			{
				FalloffMultiplier = CustomFalloff;
			}
			Falloff = AudioSource.maxDistance;
			SpatialBlend = AudioSource.spatialBlend;
			LayerMask = LayerMask.op_Implicit(LayerMask.GetMask(new string[3] { "Default", "PhysGrabObject", "PhysGrabObjectHinge" }));
			LayerMaskOverlap = LayerMask.op_Implicit(LayerMask.GetMask(new string[4] { "Default", "PhysGrabObject", "PhysGrabObjectHinge", "LowPassTrigger" }));
			if (!volumeFetched)
			{
				if (HasCustomVolume)
				{
					VolumeMultiplier = CustomVolume;
				}
				volumeFetched = true;
				Volume = AudioSource.volume;
			}
			Fetch = false;
		}
		CheckStart();
	}

	internal void UpdateMe()
	{
		if (LogicActive)
		{
			float num = ((IgnoreLowPass || !LowPass) ? 0f : 1f);
			bool flag = GlobalLowPassOverride(out var _amount);
			if (flag)
			{
				num = Mathf.Max(num, _amount);
			}
			if (IgnoreLowPass | flag)
			{
				LowPassApply(num);
			}
			else
			{
				float num2 = Mathf.Lerp(LowPassMax, LowPassMin, num);
				float num3 = ((num2 < AudioLowpassFilter.cutoffFrequency) ? 10f : 1f);
				AudioLowpassFilter.cutoffFrequency = Mathf.MoveTowards(AudioLowpassFilter.cutoffFrequency, num2, (LowPassMax - LowPassMin) * num3 * Time.deltaTime);
				float amount = Mathf.Clamp01((LowPassMax - AudioLowpassFilter.cutoffFrequency) / Mathf.Max(0.001f, LowPassMax - LowPassMin));
				LowPassValuesApply(amount);
			}
			First = false;
		}
	}

	private bool GlobalLowPassOverride(out float _amount)
	{
		_amount = 0f;
		if (IgnoreLowPass || !Object.op_Implicit((Object)(object)AudioManager.instance) || AudioManager.instance.overrideLowPassActiveTimer <= 0f)
		{
			return false;
		}
		_amount = Mathf.Clamp01(AudioManager.instance.overrideLowPassAmount);
		return true;
	}

	private void LowPassApply(float _amount)
	{
		_amount = Mathf.Clamp01(_amount);
		AudioLowpassFilter.cutoffFrequency = Mathf.Lerp(LowPassMax, LowPassMin, _amount);
		LowPassValuesApply(_amount);
	}

	private void LowPassValuesApply(float _amount)
	{
		AudioSource.maxDistance = Mathf.Lerp(Falloff, Falloff * FalloffMultiplier, _amount);
		AudioSource.volume = Mathf.Lerp(Volume, Volume * VolumeMultiplier, _amount);
		if (AudioSource.spatialBlend != 0f)
		{
			AudioSource.spatialBlend = Mathf.Lerp(SpatialBlend, 1f, _amount);
		}
	}

	internal void IgnoreLowPassSet()
	{
		IgnoreLowPass = true;
		if (Object.op_Implicit((Object)(object)AudioLowpassFilter) && Object.op_Implicit((Object)(object)AudioSource))
		{
			LowPassApply(0f);
		}
	}

	private void OnEnable()
	{
		if (Object.op_Implicit((Object)(object)AudioManager.instance) && !AudioManager.instance.lowPassComponents.Contains(this))
		{
			AudioManager.instance.lowPassComponents.Add(this);
		}
		if (!Fetch)
		{
			CheckStart();
		}
	}

	private void OnDisable()
	{
		if (Object.op_Implicit((Object)(object)AudioManager.instance))
		{
			AudioManager.instance.lowPassComponents.Remove(this);
		}
		LogicActive = false;
		((MonoBehaviour)this).StopAllCoroutines();
	}

	private void CheckStart()
	{
		if (!LogicActive)
		{
			First = true;
			if (((Component)this).gameObject.activeInHierarchy)
			{
				((MonoBehaviour)this).StartCoroutine(Check());
			}
		}
	}

	private IEnumerator Check()
	{
		LogicActive = true;
		while (Object.op_Implicit((Object)(object)AudioSource) && (AlwaysActive || !AudioSource.loop || AudioSource.isPlaying || First) && !Fetch)
		{
			if (!Object.op_Implicit((Object)(object)audioListener))
			{
				if (!Object.op_Implicit((Object)(object)AudioListenerFollow.instance))
				{
					yield return null;
					continue;
				}
				audioListener = ((Component)AudioListenerFollow.instance).transform;
			}
			CheckLogic();
			yield return (object)new WaitForSeconds(0.25f);
		}
		LogicActive = false;
		First = true;
	}

	private void CheckLogic()
	{
		//IL_0060: Unknown result type (might be due to invalid IL or missing references)
		//IL_006b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0070: Unknown result type (might be due to invalid IL or missing references)
		//IL_0075: Unknown result type (might be due to invalid IL or missing references)
		//IL_0096: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a1: Unknown result type (might be due to invalid IL or missing references)
		//IL_0176: Unknown result type (might be due to invalid IL or missing references)
		//IL_017b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0184: Unknown result type (might be due to invalid IL or missing references)
		//IL_01a2: Unknown result type (might be due to invalid IL or missing references)
		//IL_01a7: Unknown result type (might be due to invalid IL or missing references)
		LowPass = true;
		bool flag = Object.op_Implicit((Object)(object)SpectateCamera.instance);
		if (!Object.op_Implicit((Object)(object)audioListener) || !Object.op_Implicit((Object)(object)AudioSource) || AudioSource.spatialBlend <= 0f || (flag && SpectateCamera.instance.CheckState(SpectateCamera.State.Death)))
		{
			LowPass = false;
		}
		else
		{
			Vector3 val = audioListener.position - ((Component)this).transform.position;
			if (val.magnitude < 20f)
			{
				LowPass = false;
				LowPassTrigger lowPassTrigger = null;
				Collider[] array = Physics.OverlapSphere(((Component)this).transform.position, 0.1f, LayerMask.op_Implicit(LayerMaskOverlap), (QueryTriggerInteraction)2);
				List<Collider> list = new List<Collider>();
				Collider[] array2 = array;
				foreach (Collider val2 in array2)
				{
					if (((Component)((Component)val2).transform).CompareTag("LowPassTrigger"))
					{
						lowPassTrigger = ((Component)val2).GetComponent<LowPassTrigger>();
						if (!Object.op_Implicit((Object)(object)lowPassTrigger))
						{
							lowPassTrigger = ((Component)val2).GetComponentInParent<LowPassTrigger>();
						}
						if (Object.op_Implicit((Object)(object)lowPassTrigger))
						{
							break;
						}
					}
					if (((Component)((Component)val2).transform).CompareTag("Wall"))
					{
						list.Add(val2);
					}
				}
				if (Object.op_Implicit((Object)(object)AudioListenerFollow.instance.lowPassTrigger))
				{
					if ((Object)(object)AudioListenerFollow.instance.lowPassTrigger != (Object)(object)lowPassTrigger)
					{
						LowPass = true;
					}
					else
					{
						LowPass = false;
					}
				}
				else if (Object.op_Implicit((Object)(object)lowPassTrigger))
				{
					LowPass = true;
				}
				else
				{
					RaycastHit[] array3 = Physics.RaycastAll(((Component)this).transform.position, val, val.magnitude, LayerMask.op_Implicit(LayerMask), (QueryTriggerInteraction)2);
					for (int i = 0; i < array3.Length; i++)
					{
						RaycastHit val3 = array3[i];
						if (!((Component)((Component)val3.collider).transform).CompareTag("Wall"))
						{
							continue;
						}
						bool flag2 = true;
						foreach (Collider item in list)
						{
							if ((Object)(object)((Component)item).transform == (Object)(object)((Component)val3.collider).transform)
							{
								flag2 = false;
								break;
							}
						}
						if (!flag2)
						{
							continue;
						}
						bool flag3 = false;
						if (LowPassIgnoreColliders.Count > 0)
						{
							foreach (Collider lowPassIgnoreCollider in LowPassIgnoreColliders)
							{
								if (Object.op_Implicit((Object)(object)lowPassIgnoreCollider) && (Object)(object)((Component)lowPassIgnoreCollider).transform == (Object)(object)((Component)val3.collider).transform)
								{
									flag3 = true;
									break;
								}
							}
						}
						if (!flag3)
						{
							LowPass = true;
							break;
						}
					}
				}
			}
		}
		if (!First)
		{
			return;
		}
		if (Object.op_Implicit((Object)(object)AudioSource))
		{
			float num = ((IgnoreLowPass || !LowPass) ? 0f : 1f);
			if (GlobalLowPassOverride(out var _amount))
			{
				num = Mathf.Max(num, _amount);
			}
			LowPassApply(num);
		}
		First = false;
	}
}
