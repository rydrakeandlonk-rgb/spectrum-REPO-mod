using UnityEngine;

public class UraniumScript : MonoBehaviour
{
	public enum UraniumIntensity
	{
		Big,
		Small,
		None
	}

	public bool instant;

	[Space]
	public Sound uraniumSoundLoop;

	public Sound uraniumCloudSound;

	public GameObject geigerLoopObject;

	private PhysGrabObject physGrabObject;

	private ParticleSystem uraniumCloudParticles;

	public HurtCollider hurtCollider;

	public UraniumIntensity uraniumIntensityOption;

	private void Awake()
	{
		physGrabObject = ((Component)this).GetComponent<PhysGrabObject>();
		uraniumCloudParticles = ((Component)this).GetComponentInChildren<ParticleSystem>();
	}

	private void Update()
	{
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c6: Unknown result type (might be due to invalid IL or missing references)
		if (instant)
		{
			Cloud();
			Object.Destroy((Object)(object)((Component)this).gameObject);
			return;
		}
		uraniumSoundLoop.PlayLoop(physGrabObject.grabbed, 5f, 5f);
		if (physGrabObject.grabbedLocal && uraniumIntensityOption == UraniumIntensity.Big)
		{
			PostProcessing.Instance.VignetteOverride(new Color(0f, 0.6f, 0f), 1f, 0.5f, 0.1f, 2f, 0.1f, ((Component)this).gameObject);
		}
		else if (physGrabObject.grabbedLocal && uraniumIntensityOption == UraniumIntensity.Small)
		{
			PostProcessing.Instance.VignetteOverride(new Color(0f, 0.6f, 0f), 0.5f, 0.5f, 0.33f, 2f, 0.1f, ((Component)this).gameObject);
		}
	}

	public void Cloud()
	{
		//IL_000c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0011: Unknown result type (might be due to invalid IL or missing references)
		//IL_005c: Unknown result type (might be due to invalid IL or missing references)
		//IL_002f: Unknown result type (might be due to invalid IL or missing references)
		GameObject val = Object.Instantiate<GameObject>(geigerLoopObject, ((Component)this).transform.position, Quaternion.identity);
		if (instant)
		{
			uraniumCloudSound.Play(((Component)this).transform.position);
		}
		else
		{
			uraniumCloudSound.Play(physGrabObject.centerPoint);
		}
		((Component)uraniumCloudParticles).transform.parent = null;
		((Component)hurtCollider).transform.parent = null;
		uraniumCloudParticles.Play();
		Object.Destroy((Object)(object)((Component)uraniumCloudParticles).gameObject, 10f);
		((Component)hurtCollider).gameObject.SetActive(true);
		Object.Destroy((Object)(object)val, 7f);
	}
}
