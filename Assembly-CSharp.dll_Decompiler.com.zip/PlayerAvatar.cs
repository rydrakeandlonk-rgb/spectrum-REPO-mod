using System;
using System.Collections;
using System.Collections.Generic;
using Photon.Pun;
using Photon.Realtime;
using Platforms;
using TMPro;
using UnityEngine;
using UnityEngine.AI;

public class PlayerAvatar : MonoBehaviour, IPunObservable
{
	public PhotonView photonView;

	public Transform playerTransform;

	public Transform lowPassRaycastPoint;

	public GameObject spectateCamera;

	public Transform spectatePoint;

	public PhysGrabber physGrabber;

	public PlayerPhysPusher playerPhysPusher;

	public PlayerAvatarVisuals playerAvatarVisuals;

	public PlayerExpression playerExpression;

	public PlayerHealth playerHealth;

	public FlashlightController flashlightController;

	public FlashlightLightAim flashlightLightAim;

	public MapToolController mapToolController;

	public PlayerDeathEffects playerDeathEffects;

	public PlayerReviveEffects playerReviveEffects;

	internal PlayerDeathHead playerDeathHead;

	public PlayerHealthGrab healthGrab;

	internal PlayerTumble tumble;

	public PlayerPhysObjectStander physObjectStander;

	public PlayerPhysObjectFinder physObjectFinder;

	public GameObject deathSpot;

	public PlayerCosmetics playerCosmetics;

	private Collider playerCollider;

	internal string playerName;

	internal string steamID;

	[Space]
	public PlayerLocalCamera localCamera;

	[Space]
	public PlayerVisionTarget PlayerVisionTarget;

	public RoomVolumeCheck RoomVolumeCheck;

	public Materials.MaterialTrigger MaterialTrigger;

	[Space]
	internal bool isLocal;

	internal bool isDisabled;

	internal bool outroDone;

	internal bool spawned;

	private bool spawnImpulse = true;

	private int spawnFrames = 3;

	private bool spawnDoneImpulse = true;

	private Vector3 spawnPosition;

	internal Quaternion spawnRotation;

	private bool spawnDebug;

	internal bool finalHeal;

	internal bool isCrouching;

	internal bool isSprinting;

	internal bool isCrawling;

	internal bool isSliding;

	internal bool isMoving;

	internal bool isGrounded;

	internal bool isTumbling;

	internal Vector3 InputDirectionRaw;

	internal float InputAnalogAmount = 1f;

	internal Vector3 LastNavmeshPosition;

	internal float LastNavMeshPositionTimer;

	internal PlayerVoiceChat voiceChat;

	internal bool voiceChatFetched;

	private int voiceChatPhotonViewID = -1;

	private int voiceChatOwnerActorNumber = -1;

	private bool voiceChatLinkRPCSent;

	private Rigidbody rb;

	internal Vector3 rbVelocity;

	internal Vector3 rbVelocityRaw;

	private float rbDiscreteTimer;

	internal Vector3 clientPosition = Vector3.zero;

	internal Vector3 clientPositionCurrent = Vector3.zero;

	internal Quaternion clientRotation = Quaternion.identity;

	internal Quaternion clientRotationCurrent = Quaternion.identity;

	internal Vector3 clientCameraPosition;

	internal Quaternion clientCameraRotation = Quaternion.identity;

	internal Vector3 clientCameraViewPosition;

	internal float clientCameraVisibilityDistance;

	internal float clientCameraStateReceiveTime;

	internal float clientCameraStatePacketAge = float.PositiveInfinity;

	internal float clientCameraStateSpeed = 40f;

	internal ushort clientVoicePing;

	internal bool clientCameraStateValid;

	internal bool rotationDisabled;

	internal bool rotationOverrideActive;

	private readonly SemiNetPackedStream networkPackedStream = new SemiNetPackedStream(80);

	private Vector3 networkFlashlightAimPosition;

	private bool networkFlashlightAimInitialized;

	private int cameraCullingTransitionRevision;

	public Sound jumpSound;

	public Sound extraJumpSound;

	public Sound landSound;

	public Sound slideSound;

	[Space]
	public Sound standToCrouchSound;

	public Sound crouchToStandSound;

	[Space]
	public Sound crouchToCrawlSound;

	public Sound crawlToCrouchSound;

	[Space]
	public Sound deathBuildupSound;

	public Sound deathSound;

	[Space]
	public Sound tumbleStartSound;

	public Sound tumbleStopSound;

	public Sound tumbleBreakFreeSound;

	[Space]
	public Sound truckReturn;

	public Sound truckReturnGlobal;

	internal bool clientPhysRiding;

	internal int clientPhysRidingID;

	internal Vector3 clientPhysRidingPosition;

	internal Transform clientPhysRidingTransform;

	internal PhysGrabObject clientPhysRidingObject;

	public static PlayerAvatar instance;

	internal bool spectating;

	internal bool deadSet;

	private float deadTime = 0.5f;

	private float deadTimer;

	internal float enemyVisionFreezeTimer;

	private Transform deadEnemyLookAtTransform;

	internal int steamIDshort;

	internal PlayerAvatarCollision playerAvatarCollision;

	internal bool fallDamageResetState;

	private bool fallDamageResetStatePrevious;

	private float fallDamageResetTimer;

	private bool falling;

	internal int playerPing;

	private float playerPingTimer;

	internal bool quitApplication;

	private float overrrideAnimationSpeedTimer;

	private float overrrideAnimationSpeedTarget;

	private float overrrideAnimationSpeedIn;

	private float overrrideAnimationSpeedOut;

	private float overrideAnimationSpeedLerp;

	private bool overrideAnimationSpeedActive;

	private float overrideAnimationSpeedTime;

	private SpringFloat overridePupilSizeSpring = new SpringFloat();

	private bool overridePupilSizeActive;

	private float overridePupilSizeTimer;

	private float overridePupilSizeTime;

	private float overridePupilSizeMultiplier = 1f;

	private float overridePupilSizeMultiplierTarget = 1f;

	private float overridePupilSpringSpeedIn = 15f;

	private float overridePupilSpringDampIn = 0.3f;

	private float overridePupilSpringSpeedOut = 15f;

	private float overridePupilSpringDampOut = 0.3f;

	private int overridePupilSizePrio;

	private float overridePupilNetworkMultiplier;

	private int overridePupilNetworkPriority;

	private Vector4 overridePupilNetworkSprings;

	private float overridePupilNetworkTime;

	internal float overrideTTSPositionTimer;

	internal int upgradeMapPlayerCount;

	internal bool levelAnimationCompleted;

	internal float upgradeTumbleClimb;

	internal float upgradeDeathHeadBattery;

	internal float upgradeCrouchRest;

	internal bool upgradeCrouchRestActive;

	internal float upgradeTumbleWings;

	private float upgradeTumbleWingsVisualsTimer;

	private float upgradeTumbleWingsPinkTimer;

	internal WorldSpaceUIPlayerName worldSpaceUIPlayerName;

	internal Dictionary<int, float> playerExpressions = new Dictionary<int, float>();

	public ItemUpgradePlayerTumbleWingsLogic upgradeTumbleWingsLogic;

	[HideInInspector]
	public SemiAffectZeroGravity activeZeroGravityAffect;

	[HideInInspector]
	public SemiAffectTorque activeRollAffect;

	internal bool selfDestructPrevented;

	internal float investigateTimer;

	internal byte CameraCullingTeleportSequence
	{
		get
		{
			if (!Object.op_Implicit((Object)(object)localCamera))
			{
				return 0;
			}
			return localCamera.CameraCullingTeleportSequence;
		}
	}

	internal bool upgradeTumbleWingsVisualsActive { get; private set; }

	internal bool upgradeTumbleWingsVisualsPink { get; private set; }

	[RuntimeInitializeOnLoadMethod(/*Could not decode attribute arguments.*/)]
	private static void RuntimeInitializeOnLoad()
	{
		instance = null;
	}

	private void Awake()
	{
		//IL_0031: Unknown result type (might be due to invalid IL or missing references)
		//IL_0036: Unknown result type (might be due to invalid IL or missing references)
		//IL_0040: Unknown result type (might be due to invalid IL or missing references)
		//IL_0045: Unknown result type (might be due to invalid IL or missing references)
		rb = ((Component)this).GetComponent<Rigidbody>();
		photonView = ((Component)this).GetComponent<PhotonView>();
		playerCollider = ((Component)this).GetComponentInChildren<Collider>();
		isDisabled = false;
		((Component)this).transform.position = Vector3.zero + Vector3.forward * 2f;
		playerAvatarCollision = ((Component)this).GetComponent<PlayerAvatarCollision>();
		foreach (PlayerAvatar player in GameDirector.instance.PlayerList)
		{
			PhotonView component = ((Component)player).GetComponent<PhotonView>();
			if (photonView.Owner == component.Owner)
			{
				Object.Destroy((Object)(object)((Component)this).gameObject);
				return;
			}
		}
		GameDirector.instance.PlayerList.Add(this);
		if (Object.op_Implicit((Object)(object)EnemyDirector.instance))
		{
			foreach (EnemyParent item in EnemyDirector.instance.enemiesSpawned)
			{
				if (Object.op_Implicit((Object)(object)item) && Object.op_Implicit((Object)(object)item.Enemy))
				{
					item.Enemy.PlayerAdded(photonView.ViewID);
				}
			}
		}
		if (!SemiFunc.IsMultiplayer() || photonView.IsMine)
		{
			isLocal = true;
		}
	}

	private void OnDisable()
	{
		upgradeTumbleWingsVisualsTimer = 0f;
		upgradeTumbleWingsPinkTimer = 0f;
		if (Object.op_Implicit((Object)(object)photonView) && SemiFunc.IsMasterClientOrSingleplayer() && (!SemiFunc.IsMultiplayer() || PhotonNetwork.InRoom))
		{
			UpgradeTumbleWingsVisualsUpdate();
		}
		upgradeTumbleWingsVisualsActive = false;
		upgradeTumbleWingsVisualsPink = false;
	}

	private void OnDestroy()
	{
		GameDirector.instance.PlayerList.Remove(this);
		foreach (EnemyParent item in EnemyDirector.instance.enemiesSpawned)
		{
			item?.Enemy.PlayerRemoved(photonView.ViewID);
		}
		if (Object.op_Implicit((Object)(object)MenuPageEsc.instance) && photonView.Owner != null && MenuPageEsc.instance.playerMicGainSliders.TryGetValue(photonView.Owner, out var value))
		{
			Object.Destroy((Object)(object)((Component)value).gameObject);
			MenuPageEsc.instance.playerMicGainSliders.Remove(photonView.Owner);
		}
		Object.Destroy((Object)(object)((Component)((Component)this).transform.parent).gameObject);
	}

	private void Start()
	{
		//IL_005c: Unknown result type (might be due to invalid IL or missing references)
		overridePupilSizeSpring.speed = 15f;
		overridePupilSizeSpring.damping = 0.3f;
		deadTimer = deadTime;
		if (!SemiFunc.IsMultiplayer() || photonView.IsMine)
		{
			playerTransform = ((Component)PlayerController.instance).transform;
			playerTransform.position = ((Component)this).transform.position;
			PlayerController.instance.playerAvatar = ((Component)this).gameObject;
			PlayerController.instance.playerAvatarScript = ((Component)this).gameObject.GetComponent<PlayerAvatar>();
			if (Object.op_Implicit((Object)(object)instance))
			{
				Object.Destroy((Object)(object)((Component)this).gameObject);
				return;
			}
			instance = this;
		}
		SoundsSetup();
		AddToStatsManager();
		if (SemiFunc.IsMasterClient() && LevelGenerator.Instance.Generated)
		{
			LevelGenerator.Instance.PlayerSpawn();
		}
		((MonoBehaviour)this).StartCoroutine(LateStart());
	}

	private IEnumerator LateStart()
	{
		while (!LevelGenerator.Instance.Generated)
		{
			yield return null;
		}
		yield return (object)new WaitForSeconds(0.2f);
		WorldSpaceUIParent.instance.PlayerName(this);
		while (string.IsNullOrEmpty(steamID))
		{
			yield return null;
		}
		if (StatsManager.instance.playerUpgradeMapPlayerCount.TryGetValue(steamID, out var value))
		{
			upgradeMapPlayerCount = value;
		}
		if (StatsManager.instance.playerUpgradeTumbleWings.TryGetValue(steamID, out var value2))
		{
			upgradeTumbleWings = value2;
		}
		if (StatsManager.instance.playerUpgradeCrouchRest.TryGetValue(steamID, out var value3))
		{
			upgradeCrouchRest = value3;
		}
		if (StatsManager.instance.playerUpgradeTumbleClimb.TryGetValue(steamID, out var value4))
		{
			upgradeTumbleClimb = value4;
		}
		if (StatsManager.instance.playerUpgradeDeathHeadBattery.TryGetValue(steamID, out var value5))
		{
			upgradeDeathHeadBattery = value5;
		}
	}

	private void CrouchRestUpgrade()
	{
		upgradeCrouchRestActive = false;
		if ((!isCrouching && !isCrawling) || isSliding)
		{
			return;
		}
		float num = upgradeCrouchRest;
		if (!isLocal)
		{
			return;
		}
		bool flag = true;
		if (isTumbling && (tumble.notMovingTimer < 1f || physGrabber.grabState == PhysGrabber.GrabState.Climb))
		{
			flag = false;
		}
		if (flag)
		{
			float energyStart = PlayerController.instance.EnergyStart;
			num++;
			float num2 = 1f;
			if (isMoving)
			{
				num2 = 0.5f;
			}
			PlayerController.instance.EnergyCurrent = Mathf.Min(PlayerController.instance.EnergyCurrent + num * Time.deltaTime * num2, energyStart);
			upgradeCrouchRestActive = true;
		}
	}

	private void AddToStatsManager()
	{
		//IL_00bd: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c3: Unknown result type (might be due to invalid IL or missing references)
		string text = SemiFunc.PlayerGetName(this);
		string text2 = (PlatformManager.instance.IsInitialised() ? PlatformManager.instance.GetPlatformUserId() : "0");
		if (GameManager.Multiplayer() && GameManager.instance.localTest)
		{
			int num = 0;
			Player[] playerList = PhotonNetwork.PlayerList;
			for (int i = 0; i < playerList.Length; i++)
			{
				if (playerList[i].IsLocal)
				{
					text = text + " " + num;
					text2 += num;
					break;
				}
				num++;
			}
		}
		if (GameManager.Multiplayer())
		{
			if (photonView.IsMine)
			{
				photonView.RPC("AddToStatsManagerRPC", (RpcTarget)3, new object[2] { text, text2 });
			}
		}
		else
		{
			AddToStatsManagerRPC(text, text2);
		}
	}

	private void FinalHealCheck()
	{
		if (isLocal && (SemiFunc.RunIsLevel() || SemiFunc.RunIsTutorial()) && SemiFunc.PerSecond(5f, (Object)(object)this) && RoundDirector.instance.allExtractionPointsCompleted && RoomVolumeCheck.inTruck && !finalHeal && Object.op_Implicit((Object)(object)TruckHealer.instance) && TruckHealer.instance.currentState == TruckHealer.State.Open)
		{
			FinalHeal();
		}
	}

	private void FinalHeal()
	{
		//IL_0021: Unknown result type (might be due to invalid IL or missing references)
		//IL_0027: Unknown result type (might be due to invalid IL or missing references)
		if (SemiFunc.IsMultiplayer())
		{
			photonView.RPC("FinalHealRPC", (RpcTarget)0, Array.Empty<object>());
		}
		else
		{
			FinalHealRPC();
		}
	}

	[PunRPC]
	public void FinalHealRPC(PhotonMessageInfo _info = default(PhotonMessageInfo))
	{
		//IL_0000: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b5: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e5: Unknown result type (might be due to invalid IL or missing references)
		if (SemiFunc.OwnerOnlyRPC(_info, photonView) && !finalHeal)
		{
			int healAmount = 50;
			if (SemiFunc.MoonLevel() == 1)
			{
				healAmount = 35;
			}
			else if (SemiFunc.MoonLevel() >= 2)
			{
				healAmount = 25;
			}
			if (isLocal)
			{
				playerHealth.EyeMaterialOverride(PlayerHealth.EyeOverrideState.Green, 2f, 1);
				playerHealth.Heal(healAmount);
			}
			if (SemiFunc.IsMasterClientOrSingleplayer())
			{
				TruckScreenText.instance.MessageSendCustom("", playerName + " {arrowright}{truck}{check}\n {point}{shades}{pointright}<b><color=#00FF00>+" + healAmount + "</color></b>{heart}", 0);
			}
			if (Object.op_Implicit((Object)(object)TruckHealer.instance))
			{
				TruckHealer.instance.Heal(this);
			}
			truckReturn.Play(PlayerVisionTarget.VisionTransform.position);
			truckReturnGlobal.Play(PlayerVisionTarget.VisionTransform.position);
			((Component)playerAvatarVisuals.effectGetIntoTruck).gameObject.SetActive(true);
			finalHeal = true;
		}
	}

	[PunRPC]
	public void AddToStatsManagerRPC(string _playerName, string _steamID, PhotonMessageInfo _info = default(PhotonMessageInfo))
	{
		//IL_0000: Unknown result type (might be due to invalid IL or missing references)
		if (!SemiFunc.OwnerOnlyRPC(_info, photonView) || !string.IsNullOrEmpty(steamID))
		{
			return;
		}
		if (photonView.Owner != null && !GameManager.instance.localTest)
		{
			if (!string.IsNullOrEmpty(photonView.Owner.NickName))
			{
				_playerName = photonView.Owner.NickName;
			}
			if (!string.IsNullOrEmpty(photonView.Owner.UserId))
			{
				_steamID = photonView.Owner.UserId;
			}
		}
		AddToStatsManagerForced(_playerName, _steamID);
	}

	public void AddToStatsManagerForced(string _playerName, string _steamID)
	{
		playerName = _playerName;
		steamID = _steamID;
		if (Object.op_Implicit((Object)(object)worldSpaceUIPlayerName))
		{
			((TMP_Text)worldSpaceUIPlayerName.text).text = playerName;
		}
		if (!SemiFunc.IsMultiplayer() || photonView.IsMine)
		{
			PlayerController.instance.PlayerSetName(playerName, steamID);
		}
		if (Object.op_Implicit((Object)(object)StatsManager.instance))
		{
			StatsManager.instance.PlayerAdd(steamID, playerName);
		}
	}

	[PunRPC]
	public void UpdateMyPlayerVoiceChat(int photonViewID, PhotonMessageInfo _info = default(PhotonMessageInfo))
	{
		//IL_000c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0027: Unknown result type (might be due to invalid IL or missing references)
		//IL_002f: Unknown result type (might be due to invalid IL or missing references)
		//IL_003f: Unknown result type (might be due to invalid IL or missing references)
		photonView = ((Component)this).GetComponent<PhotonView>();
		if (!SemiFunc.OwnerOnlyRPC(_info, photonView) || photonViewID <= 0)
		{
			return;
		}
		if (SemiFunc.IsMultiplayer())
		{
			if (_info.Sender == null || _info.Sender.ActorNumber <= 0)
			{
				return;
			}
			voiceChatOwnerActorNumber = _info.Sender.ActorNumber;
		}
		voiceChatPhotonViewID = photonViewID;
		VoiceChatFetch();
	}

	private void VoiceChatFetch()
	{
		if (voiceChatFetched || voiceChatPhotonViewID <= 0)
		{
			return;
		}
		if (SemiFunc.IsMultiplayer() && (voiceChatOwnerActorNumber <= 0 || !Object.op_Implicit((Object)(object)photonView) || photonView.Owner == null || photonView.OwnerActorNr != voiceChatOwnerActorNumber))
		{
			voiceChatPhotonViewID = -1;
			voiceChatOwnerActorNumber = -1;
			return;
		}
		PhotonView val = PhotonView.Find(voiceChatPhotonViewID);
		if (!Object.op_Implicit((Object)(object)val))
		{
			return;
		}
		if (SemiFunc.IsMultiplayer() && (val.Owner == null || val.OwnerActorNr != voiceChatOwnerActorNumber))
		{
			voiceChatPhotonViewID = -1;
			voiceChatOwnerActorNumber = -1;
			return;
		}
		PlayerVoiceChat component = ((Component)val).GetComponent<PlayerVoiceChat>();
		if (Object.op_Implicit((Object)(object)component))
		{
			voiceChat = component;
			voiceChat.playerAvatar = this;
			if (voiceChat.TTSinstantiated)
			{
				voiceChat.ttsVoice.PlayerAvatarBind(this);
			}
			if (!SemiFunc.MenuLevel())
			{
				voiceChat.ToggleMixer(_lobby: false);
			}
			voiceChatFetched = true;
		}
	}

	[PunRPC]
	public void ResetPhysPusher(PhotonMessageInfo _info = default(PhotonMessageInfo))
	{
		//IL_0008: Unknown result type (might be due to invalid IL or missing references)
		if (SemiFunc.IsMasterClientOrSingleplayer() && SemiFunc.OwnerOnlyRPC(_info, photonView) && Object.op_Implicit((Object)(object)playerPhysPusher))
		{
			playerPhysPusher.Reset = true;
		}
	}

	public void SetDisabled()
	{
		//IL_0038: Unknown result type (might be due to invalid IL or missing references)
		//IL_003e: Unknown result type (might be due to invalid IL or missing references)
		if (GameManager.Multiplayer())
		{
			if (photonView.IsMine)
			{
				photonView.RPC("SetDisabledRPC", (RpcTarget)0, Array.Empty<object>());
				PlayerVoiceChat.instance.OverridePitchCancel();
			}
		}
		else
		{
			SetDisabledRPC();
		}
	}

	[PunRPC]
	public void SetDisabledRPC(PhotonMessageInfo _info = default(PhotonMessageInfo))
	{
		//IL_0000: Unknown result type (might be due to invalid IL or missing references)
		if (SemiFunc.OwnerOnlyRPC(_info, photonView))
		{
			isDisabled = true;
		}
	}

	public void UpdateState(bool isCrouching, bool isSprinting, bool isCrawling, bool isSliding, bool isMoving)
	{
		SetState(isCrouching, isSprinting, isCrawling, isSliding, isMoving);
	}

	private void FixedUpdate()
	{
		//IL_0072: Unknown result type (might be due to invalid IL or missing references)
		//IL_0077: Unknown result type (might be due to invalid IL or missing references)
		//IL_007e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0083: Unknown result type (might be due to invalid IL or missing references)
		//IL_008a: Unknown result type (might be due to invalid IL or missing references)
		//IL_008f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0096: Unknown result type (might be due to invalid IL or missing references)
		//IL_009b: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a7: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b8: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ce: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e4: Unknown result type (might be due to invalid IL or missing references)
		//IL_0282: Unknown result type (might be due to invalid IL or missing references)
		//IL_0287: Unknown result type (might be due to invalid IL or missing references)
		//IL_0297: Unknown result type (might be due to invalid IL or missing references)
		//IL_029c: Unknown result type (might be due to invalid IL or missing references)
		//IL_02ad: Unknown result type (might be due to invalid IL or missing references)
		//IL_02c3: Unknown result type (might be due to invalid IL or missing references)
		//IL_010b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0120: Unknown result type (might be due to invalid IL or missing references)
		//IL_02d5: Unknown result type (might be due to invalid IL or missing references)
		//IL_02e6: Unknown result type (might be due to invalid IL or missing references)
		//IL_0233: Unknown result type (might be due to invalid IL or missing references)
		//IL_01e6: Unknown result type (might be due to invalid IL or missing references)
		//IL_01eb: Unknown result type (might be due to invalid IL or missing references)
		//IL_01ec: Unknown result type (might be due to invalid IL or missing references)
		//IL_01f3: Unknown result type (might be due to invalid IL or missing references)
		//IL_01f8: Unknown result type (might be due to invalid IL or missing references)
		//IL_01fd: Unknown result type (might be due to invalid IL or missing references)
		//IL_0202: Unknown result type (might be due to invalid IL or missing references)
		//IL_0208: Unknown result type (might be due to invalid IL or missing references)
		//IL_0214: Unknown result type (might be due to invalid IL or missing references)
		OverridePupilSizeTick();
		OverrideTTSPositionTick();
		OverrideAnimationSpeedTick();
		if (SemiFunc.IsMultiplayer() && isLocal)
		{
			playerPingTimer -= Time.deltaTime;
			if (playerPingTimer <= 0f)
			{
				playerPing = PhotonNetwork.GetPing();
				playerPingTimer = 6f;
			}
		}
		if (!LevelGenerator.Instance.Generated)
		{
			if (!spawned)
			{
				return;
			}
			clientPosition = spawnPosition;
			clientPositionCurrent = spawnPosition;
			clientRotation = spawnRotation;
			clientRotationCurrent = spawnRotation;
			((Component)this).transform.position = spawnPosition;
			((Component)this).transform.rotation = spawnRotation;
			rb.MovePosition(((Component)this).transform.position);
			rb.MoveRotation(((Component)this).transform.rotation);
			if ((Object)(object)PlayerController.instance.playerAvatarScript == (Object)(object)this)
			{
				((Component)PlayerController.instance).transform.position = spawnPosition;
				((Component)PlayerController.instance).transform.rotation = spawnRotation;
			}
			if (!spawnImpulse)
			{
				return;
			}
			if (spawnFrames <= 0)
			{
				if (!LevelGenerator.Instance.LocalSetupReady)
				{
					return;
				}
				if (GameManager.Multiplayer())
				{
					if (photonView.IsMine)
					{
						LevelGenerator.Instance.PhotonView.RPC("PlayerSpawnedRPC", (RpcTarget)2, Array.Empty<object>());
					}
				}
				else
				{
					LevelGenerator.Instance.playerSpawned++;
				}
				spawnImpulse = false;
			}
			else
			{
				spawnFrames--;
			}
			return;
		}
		if (spawnDoneImpulse)
		{
			if ((Object)(object)PlayerController.instance.playerAvatarScript == (Object)(object)this)
			{
				if (!spawnDebug && Object.op_Implicit((Object)(object)TruckScreenText.instance) && !SemiFunc.MenuLevel())
				{
					Vector3 position = ((Component)TruckScreenText.instance).transform.position;
					Quaternion rotation = Quaternion.LookRotation(position - ((Component)this).transform.position);
					CameraAim.Instance.SetPlayerAim(rotation, _setRotation: true);
					CameraAim.Instance.AimTargetSet(position, 0.3f, 4f, ((Component)this).gameObject, 0);
				}
				else
				{
					CameraAim.Instance.SetPlayerAim(spawnRotation, _setRotation: true);
				}
				if (SemiFunc.MenuLevel())
				{
					PlayerController.instance.rb.isKinematic = false;
				}
			}
			rb.isKinematic = false;
			spawnDoneImpulse = false;
		}
		if (photonView.IsMine || !SemiFunc.IsMultiplayer())
		{
			rbVelocity = PlayerController.instance.VelocityRelative;
			rbVelocityRaw = PlayerController.instance.rb.linearVelocity;
			rb.MovePosition(((Component)this).transform.position);
			rb.MoveRotation(((Component)this).transform.rotation);
		}
		else
		{
			rb.MovePosition(clientPositionCurrent);
			rb.MoveRotation(clientRotationCurrent);
		}
	}

	private void LateUpdate()
	{
		OverrideTumbleWingsTick();
		OverridePupilSizeNetworkSync();
	}

	private void Update()
	{
		//IL_017f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0184: Unknown result type (might be due to invalid IL or missing references)
		//IL_0159: Unknown result type (might be due to invalid IL or missing references)
		//IL_016f: Unknown result type (might be due to invalid IL or missing references)
		//IL_01bf: Unknown result type (might be due to invalid IL or missing references)
		//IL_01c4: Unknown result type (might be due to invalid IL or missing references)
		//IL_01cb: Unknown result type (might be due to invalid IL or missing references)
		//IL_01d0: Unknown result type (might be due to invalid IL or missing references)
		//IL_01ac: Unknown result type (might be due to invalid IL or missing references)
		//IL_01b1: Unknown result type (might be due to invalid IL or missing references)
		//IL_01b6: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a2: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a7: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b3: Unknown result type (might be due to invalid IL or missing references)
		//IL_0086: Unknown result type (might be due to invalid IL or missing references)
		//IL_008b: Unknown result type (might be due to invalid IL or missing references)
		//IL_01fd: Unknown result type (might be due to invalid IL or missing references)
		//IL_029a: Unknown result type (might be due to invalid IL or missing references)
		//IL_029f: Unknown result type (might be due to invalid IL or missing references)
		//IL_02a9: Unknown result type (might be due to invalid IL or missing references)
		//IL_02ae: Unknown result type (might be due to invalid IL or missing references)
		//IL_02b3: Unknown result type (might be due to invalid IL or missing references)
		//IL_02eb: Unknown result type (might be due to invalid IL or missing references)
		//IL_0302: Unknown result type (might be due to invalid IL or missing references)
		//IL_0307: Unknown result type (might be due to invalid IL or missing references)
		//IL_0341: Unknown result type (might be due to invalid IL or missing references)
		//IL_039f: Unknown result type (might be due to invalid IL or missing references)
		//IL_03a4: Unknown result type (might be due to invalid IL or missing references)
		//IL_03b6: Unknown result type (might be due to invalid IL or missing references)
		//IL_03bb: Unknown result type (might be due to invalid IL or missing references)
		//IL_03bd: Unknown result type (might be due to invalid IL or missing references)
		//IL_03c2: Unknown result type (might be due to invalid IL or missing references)
		//IL_0381: Unknown result type (might be due to invalid IL or missing references)
		//IL_03f3: Unknown result type (might be due to invalid IL or missing references)
		//IL_03ff: Unknown result type (might be due to invalid IL or missing references)
		//IL_0419: Unknown result type (might be due to invalid IL or missing references)
		//IL_0433: Unknown result type (might be due to invalid IL or missing references)
		//IL_03d3: Unknown result type (might be due to invalid IL or missing references)
		if (!LevelGenerator.Instance.Generated)
		{
			return;
		}
		CrouchRestUpgrade();
		FinalHealCheck();
		OverrideAnimationSpeedLogic();
		OverridePupilSizeLogic();
		if (GameManager.Multiplayer())
		{
			VoiceChatFetch();
			if (GameDirector.instance.currentState >= GameDirector.gameState.Main)
			{
				if (voiceChatFetched)
				{
					if (!isDisabled)
					{
						Vector3 val = ((Component)PlayerVisionTarget.VisionTransform).transform.position;
						if (voiceChat.overridePositionTimer > 0f)
						{
							val = voiceChat.overridePosition;
						}
						((Component)voiceChat).transform.position = Vector3.Lerp(((Component)voiceChat).transform.position, val, 30f * Time.deltaTime);
					}
				}
				else if (photonView.IsMine && Object.op_Implicit((Object)(object)PlayerVoiceChat.instance) && !voiceChatLinkRPCSent)
				{
					PhotonView val2 = PlayerVoiceChat.instance.photonView;
					if (Object.op_Implicit((Object)(object)val2) && val2.ViewID != 0)
					{
						photonView.RPC("UpdateMyPlayerVoiceChat", (RpcTarget)3, new object[1] { val2.ViewID });
						voiceChatLinkRPCSent = true;
					}
				}
			}
		}
		if (photonView.IsMine || GameManager.instance.gameMode == 0)
		{
			if (Object.op_Implicit((Object)(object)playerTransform))
			{
				((Component)this).transform.position = playerTransform.position;
				((Component)this).transform.rotation = playerTransform.rotation;
			}
			InputDirectionRaw = PlayerController.instance.InputDirectionRaw;
			InputAnalogAmount = PlayerController.instance.InputAnalogAmount;
			ItemVehicle vehicleForPlayer = ItemVehicle.GetVehicleForPlayer(this);
			if (Object.op_Implicit((Object)(object)vehicleForPlayer))
			{
				InputDirectionRaw = vehicleForPlayer.GamepadInputDirectionGet(this, InputDirectionRaw);
			}
		}
		else
		{
			clientPositionCurrent = clientPosition;
			clientRotationCurrent = clientRotation;
		}
		if (deadSet)
		{
			if (isLocal && Object.op_Implicit((Object)(object)deadEnemyLookAtTransform))
			{
				CameraAim.Instance.AimTargetSet(deadEnemyLookAtTransform.position, 1f, 80f, ((Component)deadEnemyLookAtTransform).gameObject, 0);
			}
			deadTimer -= Time.deltaTime;
			if (deadTimer <= 0f)
			{
				PlayerDeathDone();
			}
		}
		if (Object.op_Implicit((Object)(object)tumble))
		{
			isTumbling = tumble.isTumbling;
		}
		if (isTumbling)
		{
			playerCollider.enabled = false;
		}
		else
		{
			playerCollider.enabled = true;
		}
		LastNavMeshPositionTimer += Time.deltaTime;
		RaycastHit val3 = default;
		NavMeshHit val4 = default;
		if (Physics.Raycast(((Component)this).transform.position + Vector3.up * 0.1f, Vector3.down, ref val3, 2f, LayerMask.GetMask(new string[3] { "Default", "NavmeshOnly", "PlayerOnlyCollision" })) && NavMesh.SamplePosition(val3.point, ref val4, 0.5f, -1))
		{
			LastNavmeshPosition = val4.position;
			LastNavMeshPositionTimer = 0f;
		}
		if (SemiFunc.IsMasterClientOrSingleplayer() && !SemiFunc.RunIsArena() && GameDirector.instance.currentState == GameDirector.gameState.Main)
		{
			if (((Component)this).transform.position.y < -100f && Object.op_Implicit((Object)(object)TruckSafetySpawnPoint.instance))
			{
				if (!tumble.isTumbling || ((Component)tumble.physGrabObject).transform.position.y < -100f)
				{
					Vector3 position = ((Component)TruckSafetySpawnPoint.instance).transform.position;
					Vector3 val5 = ((Component)tumble.physGrabObject).transform.position - position;
					if (val5.sqrMagnitude > 25f)
					{
						OutOfBoundsCameraTransition(position);
					}
					tumble.TumbleSet(_isTumbling: true, _playerInput: false, _reset: true);
					tumble.physGrabObject.Teleport(position, ((Component)TruckSafetySpawnPoint.instance).transform.rotation);
					tumble.physGrabObject.rb.linearVelocity = Vector3.zero;
					tumble.physGrabObject.rb.angularVelocity = Vector3.zero;
				}
				FallDamageResetSet(2f);
			}
			FallDamageResetLogic();
		}
		if (enemyVisionFreezeTimer > 0f)
		{
			enemyVisionFreezeTimer -= Time.deltaTime;
		}
		if (investigateTimer > 0f)
		{
			investigateTimer -= Time.deltaTime;
		}
		if (isLocal)
		{
			bool flag = false;
			if (PlayerController.instance.CollisionController.fallDistance >= 8f)
			{
				float fallDistance = PlayerController.instance.CollisionController.fallDistance;
				float num = 5f;
				float num2 = 4f;
				if (fallDistance > num)
				{
					int damage = 5;
					if (fallDistance > num + num2 * 4f)
					{
						damage = 100;
					}
					else if (fallDistance > num + num2 * 3f)
					{
						damage = 50;
					}
					else if (fallDistance > num + num2 * 2f)
					{
						damage = 25;
					}
					else if (fallDistance > num + num2)
					{
						damage = 15;
					}
					tumble.TumbleRequest(_isTumbling: true, _playerInput: false);
					if (SemiFunc.PerSecond(15f, (Object)(object)this))
					{
						tumble.ImpactHurtSet(0.5f, damage);
					}
					flag = true;
				}
			}
			FallingSet(flag);
		}
		if (SemiFunc.IsMasterClientOrSingleplayer() && falling)
		{
			tumble.TumbleOverrideTime(2f);
		}
	}

	private void OutOfBoundsCameraTransition(Vector3 _position)
	{
		//IL_0029: Unknown result type (might be due to invalid IL or missing references)
		//IL_002c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0032: Unknown result type (might be due to invalid IL or missing references)
		//IL_001b: Unknown result type (might be due to invalid IL or missing references)
		if (SemiFunc.IsMultiplayer())
		{
			photonView.RPC("OutOfBoundsCameraTransitionRPC", (RpcTarget)0, new object[1] { _position });
		}
		else
		{
			OutOfBoundsCameraTransitionRPC(_position);
		}
	}

	[PunRPC]
	private void OutOfBoundsCameraTransitionRPC(Vector3 _position, PhotonMessageInfo _info = default(PhotonMessageInfo))
	{
		//IL_0000: Unknown result type (might be due to invalid IL or missing references)
		//IL_0010: Unknown result type (might be due to invalid IL or missing references)
		if (SemiFunc.MasterOnlyRPC(_info))
		{
			SemiFunc.PlayerCameraAnyTransitionStart(this, (Object)(object)((Component)this).gameObject, _position, 1f);
		}
	}

	public void SetState(bool crouching, bool sprinting, bool crawling, bool sliding, bool moving)
	{
		isCrouching = crouching;
		isSprinting = sprinting;
		isCrawling = crawling;
		isSliding = sliding;
		isMoving = moving;
	}

	private void OverrideAnimationSpeedActivate(bool active, float _speedMulti, float _in, float _out, float _time = 0.1f)
	{
		//IL_0061: Unknown result type (might be due to invalid IL or missing references)
		//IL_0067: Unknown result type (might be due to invalid IL or missing references)
		if (isLocal)
		{
			if (SemiFunc.IsMultiplayer())
			{
				photonView.RPC("OverrideAnimationSpeedActivateRPC", (RpcTarget)0, new object[5] { active, _speedMulti, _in, _out, _time });
			}
			else
			{
				OverrideAnimationSpeedActivateRPC(active, _speedMulti, _in, _out, _time);
			}
		}
	}

	[PunRPC]
	public void OverrideAnimationSpeedActivateRPC(bool active, float _speedMulti, float _in, float _out, float _time = 0.1f, PhotonMessageInfo _info = default(PhotonMessageInfo))
	{
		//IL_0000: Unknown result type (might be due to invalid IL or missing references)
		if (SemiFunc.OwnerOnlyRPC(_info, photonView))
		{
			overrideAnimationSpeedActive = active;
			overrrideAnimationSpeedTimer = _time;
			overrrideAnimationSpeedTarget = _speedMulti;
			overrrideAnimationSpeedIn = _in;
			overrrideAnimationSpeedOut = _out;
			overrideAnimationSpeedTime = _time;
		}
	}

	public void OverrideAnimationSpeed(float _speedMulti, float _in, float _out, float _time = 0.1f)
	{
		float num = overrrideAnimationSpeedTarget;
		overrrideAnimationSpeedTimer = _time;
		overrrideAnimationSpeedTarget = _speedMulti;
		overrrideAnimationSpeedIn = _in;
		overrrideAnimationSpeedOut = _out;
		overrideAnimationSpeedTime = _time;
		if (SemiFunc.IsMultiplayer() && (!overrideAnimationSpeedActive || num != _speedMulti))
		{
			OverrideAnimationSpeedActivate(active: true, _speedMulti, _in, _out, _time);
		}
	}

	private void OverrideAnimationSpeedTick()
	{
		if (overrrideAnimationSpeedTimer > 0f)
		{
			overrrideAnimationSpeedTimer -= Time.fixedDeltaTime;
			if (overrrideAnimationSpeedTimer <= 0f && SemiFunc.IsMultiplayer() && overrideAnimationSpeedActive)
			{
				OverrideAnimationSpeedActivate(active: false, overrrideAnimationSpeedTarget, overrrideAnimationSpeedIn, overrrideAnimationSpeedOut, overrideAnimationSpeedTime);
			}
		}
	}

	private void OverrideAnimationSpeedLogic()
	{
		if (Object.op_Implicit((Object)(object)playerAvatarVisuals) && (!(overrrideAnimationSpeedTimer <= 0f) || playerAvatarVisuals.animationSpeedMultiplier != 1f))
		{
			if (!isLocal && overrideAnimationSpeedActive)
			{
				OverrideAnimationSpeed(overrrideAnimationSpeedTarget, overrrideAnimationSpeedIn, overrrideAnimationSpeedOut, overrideAnimationSpeedTime);
			}
			if (overrrideAnimationSpeedTimer > 0f)
			{
				overrideAnimationSpeedLerp = Mathf.Lerp(overrideAnimationSpeedLerp, 1f, Time.deltaTime * overrrideAnimationSpeedIn);
			}
			else
			{
				overrideAnimationSpeedLerp = Mathf.Lerp(overrideAnimationSpeedLerp, 0f, Time.deltaTime * overrrideAnimationSpeedOut);
			}
			playerAvatarVisuals.animationSpeedMultiplier = Mathf.Lerp(1f, overrrideAnimationSpeedTarget, overrideAnimationSpeedLerp);
			if (Mathf.Abs(playerAvatarVisuals.animationSpeedMultiplier - 1f) < 0.02f)
			{
				playerAvatarVisuals.animationSpeedMultiplier = 1f;
			}
		}
	}

	private void OverridePupilSizeActivate(bool active, float _multiplier, int _prio, float springSpeedIn, float dampIn, float springSpeedOut, float dampOut, float _time = 0.1f)
	{
		//IL_0085: Unknown result type (might be due to invalid IL or missing references)
		//IL_008b: Unknown result type (might be due to invalid IL or missing references)
		if (isLocal)
		{
			if (SemiFunc.IsMultiplayer())
			{
				photonView.RPC("OverridePupilSizeActivateRPC", (RpcTarget)0, new object[8] { active, _multiplier, _prio, springSpeedIn, dampIn, springSpeedOut, dampOut, _time });
			}
			else
			{
				OverridePupilSizeActivateRPC(active, _multiplier, _prio, springSpeedIn, dampIn, springSpeedOut, dampOut, _time);
			}
		}
	}

	[PunRPC]
	public void OverridePupilSizeActivateRPC(bool active, float _multiplier, int _prio, float springSpeedIn, float dampIn, float springSpeedOut, float dampOut, float _time = 0.1f, PhotonMessageInfo _info = default(PhotonMessageInfo))
	{
		//IL_0000: Unknown result type (might be due to invalid IL or missing references)
		if (SemiFunc.MasterAndOwnerOnlyRPC(_info, photonView))
		{
			overridePupilSizeActive = active;
			overridePupilSizeMultiplier = _multiplier;
			overridePupilSizeMultiplierTarget = _multiplier;
			overridePupilSizePrio = _prio;
			overridePupilSpringSpeedIn = springSpeedIn;
			overridePupilSpringDampIn = dampIn;
			overridePupilSpringSpeedOut = springSpeedOut;
			overridePupilSpringDampOut = dampOut;
			overridePupilSizeTime = _time;
		}
	}

	public void OverridePupilSize(float _multiplier, int _prio, float springSpeedIn, float springDampIn, float springSpeedOut, float springDampOut, float _time = 0.1f)
	{
		if (!(overridePupilSizeTimer > 0f) || _prio >= overridePupilSizePrio)
		{
			overridePupilSizeMultiplier = _multiplier;
			overridePupilSizeMultiplierTarget = _multiplier;
			overridePupilSizePrio = _prio;
			overridePupilSpringSpeedIn = springSpeedIn;
			overridePupilSpringDampIn = springDampIn;
			overridePupilSpringSpeedOut = springSpeedOut;
			overridePupilSpringDampOut = springDampOut;
			overridePupilSizeTime = _time;
			overridePupilSizeTimer = _time;
		}
	}

	public void OverrideTTSPosition(float _time = 0.1f)
	{
		overrideTTSPositionTimer = _time;
	}

	private void OverrideTTSPositionTick()
	{
		if (overrideTTSPositionTimer > 0f)
		{
			overrideTTSPositionTimer -= Time.fixedDeltaTime;
		}
	}

	private void OverridePupilSizeTick()
	{
		if (overridePupilSizeTimer > 0f)
		{
			overridePupilSizeTimer -= Time.fixedDeltaTime;
		}
	}

	private void OverridePupilSizeNetworkSync()
	{
		//IL_0038: Unknown result type (might be due to invalid IL or missing references)
		//IL_009b: Unknown result type (might be due to invalid IL or missing references)
		//IL_009c: Unknown result type (might be due to invalid IL or missing references)
		//IL_006b: Unknown result type (might be due to invalid IL or missing references)
		if (isLocal && SemiFunc.IsMultiplayer())
		{
			bool flag = overridePupilSizeTimer > 0f;
			Vector4 val = new Vector4(overridePupilSpringSpeedIn, overridePupilSpringDampIn, overridePupilSpringSpeedOut, overridePupilSpringDampOut);
			if (flag != overridePupilSizeActive || (flag && (overridePupilNetworkMultiplier != overridePupilSizeMultiplierTarget || overridePupilNetworkPriority != overridePupilSizePrio || !overridePupilNetworkSprings.Equals(val) || overridePupilNetworkTime != overridePupilSizeTime)))
			{
				overridePupilNetworkMultiplier = overridePupilSizeMultiplierTarget;
				overridePupilNetworkPriority = overridePupilSizePrio;
				overridePupilNetworkSprings = val;
				overridePupilNetworkTime = overridePupilSizeTime;
				OverridePupilSizeActivate(flag, overridePupilSizeMultiplierTarget, overridePupilSizePrio, overridePupilSpringSpeedIn, overridePupilSpringDampIn, overridePupilSpringSpeedOut, overridePupilSpringDampOut, overridePupilSizeTime);
			}
		}
	}

	private void OverridePupilSizeLogic()
	{
		if (Object.op_Implicit((Object)(object)playerAvatarVisuals))
		{
			if (!isLocal && overridePupilSizeActive)
			{
				OverridePupilSize(overridePupilSizeMultiplierTarget, overridePupilSizePrio, overridePupilSpringSpeedIn, overridePupilSpringDampIn, overridePupilSpringSpeedOut, overridePupilSpringDampOut, overridePupilSizeTime);
			}
			if (overridePupilSizeTimer > 0f)
			{
				overridePupilSizeSpring.speed = overridePupilSpringSpeedIn;
				overridePupilSizeSpring.damping = overridePupilSpringDampIn;
				playerAvatarVisuals.playerEyes.pupilSizeMultiplier = SemiFunc.SpringFloatGet(overridePupilSizeSpring, overridePupilSizeMultiplierTarget);
			}
			else
			{
				overridePupilSizeSpring.speed = overridePupilSpringSpeedOut;
				overridePupilSizeSpring.damping = overridePupilSpringDampOut;
				playerAvatarVisuals.playerEyes.pupilSizeMultiplier = SemiFunc.SpringFloatGet(overridePupilSizeSpring, 1f);
			}
		}
	}

	public void OverrideDisableEnemyInvestigate(float _time = 1f)
	{
		investigateTimer = _time;
	}

	public void SetSpectate()
	{
		Object.Instantiate<GameObject>(spectateCamera).GetComponent<SpectateCamera>().SetDeath(spectatePoint);
		spectating = true;
	}

	public void SoundsSetup()
	{
		SoundSetup(jumpSound);
		SoundSetup(extraJumpSound);
		SoundSetup(landSound);
		SoundSetup(slideSound);
		SoundSetup(standToCrouchSound);
		SoundSetup(crouchToStandSound);
		SoundSetup(crouchToCrawlSound);
		SoundSetup(crawlToCrouchSound);
		SoundSetup(tumbleStartSound);
		SoundSetup(tumbleStopSound);
		SoundSetup(tumbleBreakFreeSound);
	}

	public void SoundSetup(Sound _sound)
	{
		_sound.StoreDefault();
		if ((!SemiFunc.IsMultiplayer() || photonView.IsMine) && playerAvatarVisuals.showSelfOverrideTimer <= 0f)
		{
			_sound.Volume = _sound.VolumeDefault;
			_sound.VolumeRandom = _sound.VolumeRandomDefault;
			_sound.SpatialBlend = 0f;
		}
		else
		{
			_sound.Volume = _sound.VolumeDefault * 0.5f;
			_sound.VolumeRandom = _sound.VolumeRandomDefault * 0.5f;
			_sound.SpatialBlend = 1f;
		}
	}

	public void EnemyVisionFreezeTimerSet(float _time)
	{
		enemyVisionFreezeTimer = _time;
	}

	private void FallingSet(bool _falling)
	{
		//IL_0020: Unknown result type (might be due to invalid IL or missing references)
		//IL_0026: Unknown result type (might be due to invalid IL or missing references)
		if (falling != _falling)
		{
			falling = _falling;
			if (!GameManager.Multiplayer())
			{
				FallingSetRPC(falling);
				return;
			}
			photonView.RPC("FallingSetRPC", (RpcTarget)2, new object[1] { falling });
		}
	}

	[PunRPC]
	private void FallingSetRPC(bool _falling, PhotonMessageInfo _info = default(PhotonMessageInfo))
	{
		//IL_0000: Unknown result type (might be due to invalid IL or missing references)
		if (SemiFunc.OwnerOnlyRPC(_info, photonView))
		{
			falling = _falling;
		}
	}

	public void FlashlightFlicker(float _multiplier)
	{
		//IL_002c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0032: Unknown result type (might be due to invalid IL or missing references)
		if (SemiFunc.IsMultiplayer())
		{
			photonView.RPC("FlashlightFlickerRPC", (RpcTarget)0, new object[1] { _multiplier });
		}
		else
		{
			FlashlightFlickerRPC(_multiplier);
		}
	}

	[PunRPC]
	public void FlashlightFlickerRPC(float _multiplier, PhotonMessageInfo _info = default(PhotonMessageInfo))
	{
		//IL_0000: Unknown result type (might be due to invalid IL or missing references)
		if (SemiFunc.MasterOnlyRPC(_info))
		{
			flashlightController.FlickerSet(_multiplier);
		}
	}

	public void Slide()
	{
		//IL_000c: Unknown result type (might be due to invalid IL or missing references)
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_003d: Unknown result type (might be due to invalid IL or missing references)
		slideSound.Play(((Component)this).transform.position);
		if (!GameManager.Multiplayer())
		{
			Materials.Instance.Slide(((Component)this).transform.position, MaterialTrigger, 0f, isPlayer: true);
			return;
		}
		Materials.Instance.Slide(((Component)this).transform.position, MaterialTrigger, 0f, isPlayer: true);
		photonView.RPC("SlideRPC", (RpcTarget)1, Array.Empty<object>());
	}

	[PunRPC]
	private void SlideRPC(PhotonMessageInfo _info = default(PhotonMessageInfo))
	{
		//IL_0000: Unknown result type (might be due to invalid IL or missing references)
		//IL_001b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0045: Unknown result type (might be due to invalid IL or missing references)
		if (SemiFunc.OwnerOnlyRPC(_info, photonView))
		{
			slideSound.Play(((Component)this).transform.position);
			Materials.Instance.Slide(((Component)this).transform.position, MaterialTrigger, 1f, isPlayer: false);
		}
	}

	public void Jump(bool _powerupEffect)
	{
		//IL_0010: Unknown result type (might be due to invalid IL or missing references)
		//IL_0016: Unknown result type (might be due to invalid IL or missing references)
		if (GameManager.instance.gameMode == 0)
		{
			JumpRPC(_powerupEffect);
			return;
		}
		photonView.RPC("JumpRPC", (RpcTarget)0, new object[1] { _powerupEffect });
	}

	[PunRPC]
	private void JumpRPC(bool _powerupEffect, PhotonMessageInfo _info = default(PhotonMessageInfo))
	{
		//IL_0000: Unknown result type (might be due to invalid IL or missing references)
		//IL_0026: Unknown result type (might be due to invalid IL or missing references)
		//IL_006e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0073: Unknown result type (might be due to invalid IL or missing references)
		//IL_0096: Unknown result type (might be due to invalid IL or missing references)
		if (SemiFunc.OwnerOnlyRPC(_info, photonView))
		{
			playerAvatarVisuals.JumpImpulse();
			jumpSound.Play(((Component)this).transform.position);
			Materials.HostType hostType = Materials.HostType.LocalPlayer;
			if (!isLocal || playerAvatarVisuals.showSelfOverrideTimer > 0f)
			{
				hostType = Materials.HostType.OtherPlayer;
			}
			Materials.Instance.Impulse(((Component)this).transform.position, Vector3.down, Materials.SoundType.Light, footstep: true, footstepParticles: false, MaterialTrigger, hostType);
			if (_powerupEffect)
			{
				extraJumpSound.Play(((Component)this).transform.position);
				playerAvatarVisuals.PowerupJumpEffect();
			}
			playerCosmetics.CosmeticSpringJump();
		}
	}

	public void Land()
	{
		//IL_000f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0015: Unknown result type (might be due to invalid IL or missing references)
		if (GameManager.instance.gameMode == 0)
		{
			LandRPC();
		}
		else
		{
			photonView.RPC("LandRPC", (RpcTarget)0, Array.Empty<object>());
		}
	}

	[PunRPC]
	private void LandRPC(PhotonMessageInfo _info = default(PhotonMessageInfo))
	{
		//IL_0000: Unknown result type (might be due to invalid IL or missing references)
		//IL_0015: Unknown result type (might be due to invalid IL or missing references)
		//IL_001a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_0029: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Unknown result type (might be due to invalid IL or missing references)
		//IL_003a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0080: Unknown result type (might be due to invalid IL or missing references)
		//IL_0085: Unknown result type (might be due to invalid IL or missing references)
		//IL_008f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0094: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ce: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f8: Unknown result type (might be due to invalid IL or missing references)
		//IL_00fd: Unknown result type (might be due to invalid IL or missing references)
		//IL_011c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0121: Unknown result type (might be due to invalid IL or missing references)
		//IL_013b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0135: Unknown result type (might be due to invalid IL or missing references)
		//IL_013a: Unknown result type (might be due to invalid IL or missing references)
		if (!SemiFunc.OwnerOnlyRPC(_info, photonView))
		{
			return;
		}
		RaycastHit val = default;
		if (Physics.Raycast(((Component)this).transform.position + Vector3.up * 0.1f, Vector3.down, ref val, 0.25f, LayerMask.op_Implicit(SemiFunc.LayerMaskGetPhysGrabObject())))
		{
			PhysGrabObject component = ((Component)val.transform).GetComponent<PhysGrabObject>();
			if (Object.op_Implicit((Object)(object)component))
			{
				component.mediumBreakImpulse = true;
				return;
			}
		}
		if (investigateTimer <= 0f)
		{
			EnemyDirector.instance.SetInvestigate(((Component)this).transform.position + Vector3.up * 0.2f, 10f);
		}
		Materials.HostType hostType = Materials.HostType.LocalPlayer;
		if (!isLocal || playerAvatarVisuals.showSelfOverrideTimer > 0f)
		{
			hostType = Materials.HostType.OtherPlayer;
		}
		landSound.Play(((Component)this).transform.position);
		Materials.Instance.Impulse(((Component)this).transform.position, Vector3.down, Materials.SoundType.Heavy, footstep: true, footstepParticles: false, MaterialTrigger, hostType);
		Vector3 position = PlayerVisionTarget.VisionTransform.position;
		if (isLocal)
		{
			position = localCamera.GetOverrideTransform().position;
		}
		SemiFunc.PlayerEyesOverrideSoft(position, 2f, ((Component)this).gameObject, 5f);
		playerCosmetics.CosmeticSpringLand();
	}

	private float GetPitchMulti()
	{
		return Mathf.Clamp(playerAvatarVisuals.animationSpeedMultiplier, 0.5f, 1.5f);
	}

	public void Footstep(Materials.SoundType soundType, Vector3 _position = default(Vector3))
	{
		//IL_000d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0010: Unknown result type (might be due to invalid IL or missing references)
		//IL_0016: Unknown result type (might be due to invalid IL or missing references)
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_0029: Unknown result type (might be due to invalid IL or missing references)
		//IL_004e: Unknown result type (might be due to invalid IL or missing references)
		//IL_004f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0080: Unknown result type (might be due to invalid IL or missing references)
		//IL_0081: Unknown result type (might be due to invalid IL or missing references)
		//IL_008b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0090: Unknown result type (might be due to invalid IL or missing references)
		//IL_00aa: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ab: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b5: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ba: Unknown result type (might be due to invalid IL or missing references)
		if (Object.op_Implicit((Object)(object)RecordingDirector.instance))
		{
			return;
		}
		if (_position == default(Vector3))
		{
			_position = ((Component)this).transform.position;
		}
		Materials.HostType hostType = Materials.HostType.LocalPlayer;
		if (!isLocal || playerAvatarVisuals.showSelfOverrideTimer > 0f)
		{
			hostType = Materials.HostType.OtherPlayer;
		}
		Materials.Instance.Impulse(_position, Vector3.down, soundType, footstep: true, footstepParticles: true, MaterialTrigger, hostType);
		if (SemiFunc.IsMasterClientOrSingleplayer() && investigateTimer <= 0f)
		{
			switch (soundType)
			{
			case Materials.SoundType.Heavy:
				EnemyDirector.instance.SetInvestigate(_position + Vector3.up * 0.2f, 5f);
				break;
			case Materials.SoundType.Medium:
				EnemyDirector.instance.SetInvestigate(_position + Vector3.up * 0.2f, 1f);
				break;
			}
		}
	}

	public void StandToCrouch()
	{
		//IL_0015: Unknown result type (might be due to invalid IL or missing references)
		if (!isSprinting)
		{
			AudioSource val = standToCrouchSound.Play(((Component)this).transform.position);
			val.pitch *= playerAvatarVisuals.animationSpeedMultiplier;
			playerCosmetics.CosmeticSpringStandToCrouch();
		}
	}

	public void CrouchToStand()
	{
		//IL_000c: Unknown result type (might be due to invalid IL or missing references)
		AudioSource val = crouchToStandSound.Play(((Component)this).transform.position);
		float pitchMulti = GetPitchMulti();
		val.pitch *= pitchMulti;
		playerCosmetics.CosmeticSpringCrouchToStand();
	}

	public void CrouchToCrawl()
	{
		//IL_001d: Unknown result type (might be due to invalid IL or missing references)
		if (!isSliding && !isSprinting)
		{
			AudioSource val = crouchToCrawlSound.Play(((Component)this).transform.position);
			float pitchMulti = GetPitchMulti();
			val.pitch *= pitchMulti;
			playerCosmetics.CosmeticSpringCrouchToCrawl();
		}
	}

	public void CrawlToCrouch()
	{
		//IL_001d: Unknown result type (might be due to invalid IL or missing references)
		if (!isSliding && !isSprinting)
		{
			AudioSource val = crawlToCrouchSound.Play(((Component)this).transform.position);
			float pitchMulti = GetPitchMulti();
			val.pitch *= pitchMulti;
			playerCosmetics.CosmeticSpringCrawlToCrouch();
		}
	}

	public void TumbleStart()
	{
		//IL_000c: Unknown result type (might be due to invalid IL or missing references)
		AudioSource val = tumbleStartSound.Play(((Component)this).transform.position);
		float pitchMulti = GetPitchMulti();
		val.pitch *= pitchMulti;
		playerCosmetics.TumbleStart();
	}

	public void TumbleStop()
	{
		//IL_000c: Unknown result type (might be due to invalid IL or missing references)
		AudioSource val = tumbleStopSound.Play(((Component)this).transform.position);
		float pitchMulti = GetPitchMulti();
		val.pitch *= pitchMulti;
		playerCosmetics.TumbleStop();
	}

	public void TumbleBreakFree()
	{
		//IL_000c: Unknown result type (might be due to invalid IL or missing references)
		AudioSource val = tumbleBreakFreeSound.Play(((Component)this).transform.position);
		val.pitch *= GetPitchMulti();
		playerAvatarVisuals.TumbleBreakFreeEffect();
	}

	public void PlayerGlitchShort()
	{
		if (GameManager.instance.gameMode == 0)
		{
			CameraGlitch.Instance.PlayShort();
		}
		else
		{
			photonView.RPC("PlayerGlitchShortRPC", (RpcTarget)0, Array.Empty<object>());
		}
	}

	[PunRPC]
	private void PlayerGlitchShortRPC(PhotonMessageInfo _info = default(PhotonMessageInfo))
	{
		//IL_0000: Unknown result type (might be due to invalid IL or missing references)
		if (SemiFunc.OwnerOnlyRPC(_info, photonView) && photonView.IsMine)
		{
			CameraGlitch.Instance.PlayShort();
		}
	}

	public void Spawn(Vector3 position, Quaternion rotation, bool _debug = false)
	{
		//IL_0033: Unknown result type (might be due to invalid IL or missing references)
		//IL_003c: Unknown result type (might be due to invalid IL or missing references)
		//IL_000d: Unknown result type (might be due to invalid IL or missing references)
		//IL_000e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0012: Unknown result type (might be due to invalid IL or missing references)
		//IL_0018: Unknown result type (might be due to invalid IL or missing references)
		if (GameManager.instance.gameMode == 0)
		{
			SpawnRPC(position, rotation, _debug);
			return;
		}
		photonView.RPC("SpawnRPC", (RpcTarget)0, new object[3] { position, rotation, _debug });
	}

	[PunRPC]
	private void SpawnRPC(Vector3 position, Quaternion rotation, bool _debug, PhotonMessageInfo _info = default(PhotonMessageInfo))
	{
		//IL_0000: Unknown result type (might be due to invalid IL or missing references)
		//IL_005a: Unknown result type (might be due to invalid IL or missing references)
		//IL_006a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0076: Unknown result type (might be due to invalid IL or missing references)
		//IL_0082: Unknown result type (might be due to invalid IL or missing references)
		//IL_008e: Unknown result type (might be due to invalid IL or missing references)
		//IL_009a: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a1: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a2: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a8: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a9: Unknown result type (might be due to invalid IL or missing references)
		//IL_00af: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b0: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b6: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b7: Unknown result type (might be due to invalid IL or missing references)
		//IL_00bd: Unknown result type (might be due to invalid IL or missing references)
		//IL_00be: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c4: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c5: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d7: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d8: Unknown result type (might be due to invalid IL or missing references)
		if (SemiFunc.MasterOnlyRPC(_info))
		{
			if (!Object.op_Implicit((Object)(object)photonView))
			{
				photonView = ((Component)this).GetComponent<PhotonView>();
			}
			if (!Object.op_Implicit((Object)(object)rb))
			{
				rb = ((Component)this).GetComponent<Rigidbody>();
			}
			if (!GameManager.Multiplayer() || photonView.IsMine)
			{
				((Component)PlayerController.instance).transform.position = position;
				((Component)PlayerController.instance).transform.rotation = rotation;
			}
			rb.position = position;
			rb.rotation = rotation;
			((Component)this).transform.position = position;
			((Component)this).transform.rotation = rotation;
			clientPosition = position;
			clientPositionCurrent = position;
			clientRotation = rotation;
			clientRotationCurrent = rotation;
			spawnPosition = position;
			spawnRotation = rotation;
			spawnDebug = _debug;
			playerAvatarVisuals.visualPosition = position;
			spawned = true;
		}
	}

	public void PlayerDeath(int enemyIndex)
	{
		//IL_0019: Unknown result type (might be due to invalid IL or missing references)
		//IL_001f: Unknown result type (might be due to invalid IL or missing references)
		if (!deadSet)
		{
			if (GameManager.instance.gameMode == 0)
			{
				PlayerDeathRPC(enemyIndex);
				return;
			}
			photonView.RPC("PlayerDeathRPC", (RpcTarget)0, new object[1] { enemyIndex });
		}
	}

	[PunRPC]
	public void PlayerDeathRPC(int enemyIndex, PhotonMessageInfo _info = default(PhotonMessageInfo))
	{
		//IL_0000: Unknown result type (might be due to invalid IL or missing references)
		//IL_0085: Unknown result type (might be due to invalid IL or missing references)
		if (!SemiFunc.MasterAndOwnerOnlyRPC(_info, photonView))
		{
			return;
		}
		ProgressionManager.instance.BonusNoDeathsFailed();
		if (isLocal)
		{
			ProgressionManager.instance.penaltyDeath += 0.05f;
			ProgressionManager.instance.penaltyDeath = Mathf.Clamp(ProgressionManager.instance.penaltyDeath, 0f, 0.5f);
		}
		playerHealth.Death();
		deadSet = true;
		PlayerVoiceChat.VoiceTargetPlayersInvalidate();
		if (!isLocal)
		{
			deathBuildupSound.Play(((Component)this).transform.position);
		}
		if (!isLocal)
		{
			return;
		}
		deadEnemyLookAtTransform = null;
		Enemy enemy = SemiFunc.EnemyGetFromIndex(enemyIndex);
		if (Object.op_Implicit((Object)(object)enemy))
		{
			if (Object.op_Implicit((Object)(object)enemy.KillLookAtTransform))
			{
				deadEnemyLookAtTransform = enemy.KillLookAtTransform;
			}
			else
			{
				Debug.LogError((object)("Enemy has no kill look at transform..." + ((Object)enemy).name));
			}
		}
		physGrabber.ReleaseObject(-1);
		if (Object.op_Implicit((Object)(object)playerTransform))
		{
			((Component)playerTransform.parent).gameObject.SetActive(false);
		}
		CameraGlitch.Instance.PlayLongHurt(hurtByHeal: false);
		GameDirector.instance.DeathStart();
	}

	private void PlayerDeathDone()
	{
		//IL_0053: Unknown result type (might be due to invalid IL or missing references)
		//IL_0058: Unknown result type (might be due to invalid IL or missing references)
		//IL_0135: Unknown result type (might be due to invalid IL or missing references)
		if (voiceChatFetched)
		{
			voiceChat.OverrideMute(1f);
			voiceChat.ToggleMixer(_lobby: true);
		}
		if (SemiFunc.RunIsTutorial())
		{
			TutorialDirector.instance.deadPlayer = true;
		}
		if (isDisabled)
		{
			return;
		}
		isDisabled = true;
		Object.Instantiate<GameObject>(deathSpot, ((Component)this).transform.position, Quaternion.identity);
		if (GameManager.Multiplayer())
		{
			if (!isLocal)
			{
				if (Object.op_Implicit((Object)(object)SpectateCamera.instance))
				{
					SpectateCamera.instance.UpdatePlayer(this);
				}
			}
			else
			{
				this.physGrabber.ReleaseObject(-1);
				Inventory inventory = Inventory.instance;
				int? num;
				if (inventory == null)
				{
					num = null;
				}
				else
				{
					PhysGrabber physGrabber = inventory.physGrabber;
					num = ((physGrabber != null) ? new int?(physGrabber.photonView.ViewID) : ((int?)null));
				}
				if (num == this.physGrabber.photonView.ViewID)
				{
					Inventory.instance.ForceUnequip();
				}
			}
		}
		else
		{
			this.physGrabber.ReleaseObject(-1);
			Inventory.instance.ForceUnequip();
		}
		deathSound.Play(((Component)this).transform.position);
		if (Object.op_Implicit((Object)(object)playerDeathHead))
		{
			playerDeathHead.Trigger();
		}
		playerDeathEffects.Trigger();
		((Component)this).gameObject.SetActive(false);
	}

	public void OutroStart()
	{
		//IL_000f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0015: Unknown result type (might be due to invalid IL or missing references)
		if (GameManager.instance.gameMode == 0)
		{
			OutroStartRPC();
		}
		else
		{
			photonView.RPC("OutroStartRPC", (RpcTarget)0, Array.Empty<object>());
		}
	}

	[PunRPC]
	public void OutroStartRPC(PhotonMessageInfo _info = default(PhotonMessageInfo))
	{
		//IL_0000: Unknown result type (might be due to invalid IL or missing references)
		if (SemiFunc.MasterOnlyRPC(_info) && isLocal)
		{
			GameDirector.instance.OutroStart();
		}
	}

	public void OutroDone()
	{
		//IL_0034: Unknown result type (might be due to invalid IL or missing references)
		//IL_003a: Unknown result type (might be due to invalid IL or missing references)
		if (quitApplication)
		{
			Application.Quit();
		}
		else if (NetworkManager.instance.leavePhotonRoom)
		{
			NetworkManager.instance.LeavePhotonRoom();
		}
		else if (GameManager.instance.gameMode == 0)
		{
			OutroDoneRPC();
		}
		else
		{
			photonView.RPC("OutroDoneRPC", (RpcTarget)0, Array.Empty<object>());
		}
	}

	[PunRPC]
	public void OutroDoneRPC(PhotonMessageInfo _info = default(PhotonMessageInfo))
	{
		//IL_0000: Unknown result type (might be due to invalid IL or missing references)
		if (SemiFunc.OwnerOnlyRPC(_info, photonView))
		{
			outroDone = true;
		}
	}

	public void ForceImpulse(Vector3 _force)
	{
		//IL_002c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0008: Unknown result type (might be due to invalid IL or missing references)
		//IL_000b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0011: Unknown result type (might be due to invalid IL or missing references)
		if (!GameManager.Multiplayer())
		{
			ForceImpulseRPC(_force);
			return;
		}
		photonView.RPC("ForceImpulseRPC", (RpcTarget)0, new object[1] { _force });
	}

	[PunRPC]
	private void ForceImpulseRPC(Vector3 _force, PhotonMessageInfo _info = default(PhotonMessageInfo))
	{
		//IL_0000: Unknown result type (might be due to invalid IL or missing references)
		//IL_0028: Unknown result type (might be due to invalid IL or missing references)
		if (SemiFunc.MasterAndOwnerOnlyRPC(_info, photonView) && (!GameManager.Multiplayer() || photonView.IsMine))
		{
			PlayerController.instance.ForceImpulse(_force);
		}
	}

	private void CameraCullingTransitionRevisionAdvance()
	{
		cameraCullingTransitionRevision++;
		if (cameraCullingTransitionRevision == 0)
		{
			cameraCullingTransitionRevision = 1;
		}
	}

	public void Revive(bool _revivedByTruck = false)
	{
		//IL_0010: Unknown result type (might be due to invalid IL or missing references)
		//IL_0016: Unknown result type (might be due to invalid IL or missing references)
		if (GameManager.instance.gameMode == 0)
		{
			ReviveRPC(_revivedByTruck);
			return;
		}
		photonView.RPC("ReviveRPC", (RpcTarget)0, new object[1] { _revivedByTruck });
	}

	[PunRPC]
	public void ReviveRPC(bool _revivedByTruck, PhotonMessageInfo _info = default(PhotonMessageInfo))
	{
		//IL_0000: Unknown result type (might be due to invalid IL or missing references)
		//IL_008f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0094: Unknown result type (might be due to invalid IL or missing references)
		//IL_009e: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a8: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b9: Unknown result type (might be due to invalid IL or missing references)
		//IL_00be: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c6: Unknown result type (might be due to invalid IL or missing references)
		//IL_00cb: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d5: Unknown result type (might be due to invalid IL or missing references)
		//IL_00da: Unknown result type (might be due to invalid IL or missing references)
		//IL_00df: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e9: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ee: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ff: Unknown result type (might be due to invalid IL or missing references)
		//IL_012e: Unknown result type (might be due to invalid IL or missing references)
		//IL_013b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0140: Unknown result type (might be due to invalid IL or missing references)
		//IL_014c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0151: Unknown result type (might be due to invalid IL or missing references)
		//IL_015d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0117: Unknown result type (might be due to invalid IL or missing references)
		//IL_011e: Unknown result type (might be due to invalid IL or missing references)
		//IL_01be: Unknown result type (might be due to invalid IL or missing references)
		//IL_01d4: Unknown result type (might be due to invalid IL or missing references)
		//IL_01d9: Unknown result type (might be due to invalid IL or missing references)
		//IL_029e: Unknown result type (might be due to invalid IL or missing references)
		//IL_02e1: Unknown result type (might be due to invalid IL or missing references)
		//IL_02ec: Unknown result type (might be due to invalid IL or missing references)
		//IL_0301: Unknown result type (might be due to invalid IL or missing references)
		//IL_03af: Unknown result type (might be due to invalid IL or missing references)
		//IL_03ba: Unknown result type (might be due to invalid IL or missing references)
		//IL_033b: Unknown result type (might be due to invalid IL or missing references)
		if (!SemiFunc.MasterOnlyRPC(_info))
		{
			return;
		}
		CameraCullingTransitionRevisionAdvance();
		if (!Object.op_Implicit((Object)(object)playerDeathHead))
		{
			Debug.LogError((object)"Tried to revive without death head...");
			return;
		}
		playerHealth.InvincibleSet(1f);
		OverrideDisableEnemyInvestigate();
		if (Object.op_Implicit((Object)(object)voiceChat))
		{
			voiceChat.OverrideDisableEnemyInvestigate();
		}
		TutorialDirector.instance.playerRevived = true;
		if (_revivedByTruck && Object.op_Implicit((Object)(object)TruckHealer.instance))
		{
			TruckHealer.instance.Heal(this);
		}
		Vector3 position = playerDeathHead.physGrabObject.centerPoint - Vector3.up * 0.25f;
		Vector3 eulerAngles = ((Component)playerDeathHead.physGrabObject).transform.eulerAngles;
		if (SemiFunc.RunIsTutorial())
		{
			position = Vector3.zero + Vector3.up * 2f - Vector3.right * 5f;
			((Component)playerDeathHead).transform.position = position;
		}
		if (SemiFunc.IsMasterClientOrSingleplayer())
		{
			tumble.physGrabObject.Teleport(position, ((Component)this).transform.rotation);
		}
		((Component)this).transform.position = position;
		clientPositionCurrent = ((Component)this).transform.position;
		clientPosition = ((Component)this).transform.position;
		SemiFunc.PlayerCameraAnyTransitionStart(this, (Object)(object)((Component)this).gameObject, position, 3f, Object.op_Implicit((Object)(object)photonView) ? photonView.ViewID : 0, cameraCullingTransitionRevision);
		clientPhysRiding = false;
		((Component)this).gameObject.SetActive(true);
		((Component)playerAvatarVisuals).gameObject.SetActive(true);
		((Component)playerAvatarVisuals).transform.position = ((Component)this).transform.position;
		playerAvatarVisuals.visualPosition = ((Component)this).transform.position;
		playerAvatarVisuals.Revive();
		isDisabled = false;
		playerDeathHead.Reset();
		playerDeathEffects.Reset();
		playerReviveEffects.Trigger();
		deadSet = false;
		deadTimer = deadTime;
		if (Object.op_Implicit((Object)(object)voiceChat))
		{
			voiceChat.ToggleMixer(_lobby: false);
		}
		else if (isLocal && Object.op_Implicit((Object)(object)AudioManager.instance))
		{
			AudioManager.instance.SetSoundSnapshot(AudioManager.SoundSnapshot.On, 0.5f);
		}
		playerAvatarCollision.SetCrouch();
		playerHealth.SetMaterialGreen();
		if (isLocal)
		{
			playerHealth.HealOther(1, effect: true);
			playerTransform.position = ((Component)this).transform.position;
			((Component)playerTransform.parent).gameObject.SetActive(true);
			if (!Object.op_Implicit((Object)(object)SpectateCamera.instance) || !SpectateCamera.instance.CheckState(SpectateCamera.State.Head))
			{
				CameraAim.Instance.SetPlayerAim(Quaternion.Euler(0f, eulerAngles.y, 0f), _setRotation: true);
			}
			((Component)CameraPosition.instance).transform.position = position;
			CameraAim.Instance.OverrideNoSmooth(0.25f);
			GameDirector.instance.Revive();
			if (Object.op_Implicit((Object)(object)SpectateCamera.instance))
			{
				SpectateCamera.instance.StopSpectate();
			}
			PlayerController.instance.Revive(eulerAngles);
			if (Object.op_Implicit((Object)(object)localCamera))
			{
				localCamera.CameraCullingTransitionReady(Object.op_Implicit((Object)(object)photonView) ? photonView.ViewID : 0, cameraCullingTransitionRevision);
			}
			CameraGlitch.Instance.PlayLongHeal();
		}
		else if (!_revivedByTruck && SemiFunc.RunIsLevel())
		{
			PlayerAvatar playerAvatarScript = PlayerController.instance.playerAvatarScript;
			if (!playerAvatarScript.isDisabled && Vector3.Distance(((Component)playerAvatarScript).transform.position, ((Component)this).transform.position) < 10f && playerAvatarScript.playerHealth.health >= 50 && !TutorialDirector.instance.playerHealed && TutorialDirector.instance.TutorialSettingCheck(DataDirector.Setting.TutorialHealing, 1))
			{
				TutorialDirector.instance.ActivateTip("Healing", 0.5f, _interrupt: false);
			}
		}
		RoomVolumeCheck.CheckSet();
	}

	private void FallDamageResetLogic()
	{
		//IL_0059: Unknown result type (might be due to invalid IL or missing references)
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		if (fallDamageResetTimer > 0f)
		{
			fallDamageResetTimer -= Time.deltaTime;
			fallDamageResetState = true;
		}
		else
		{
			fallDamageResetState = false;
		}
		if (fallDamageResetState != fallDamageResetStatePrevious)
		{
			fallDamageResetStatePrevious = fallDamageResetState;
			if (!GameManager.Multiplayer())
			{
				FallDamageResetUpdateRPC(fallDamageResetState);
				return;
			}
			photonView.RPC("FallDamageResetUpdateRPC", (RpcTarget)0, new object[1] { fallDamageResetState });
		}
	}

	public void FallDamageResetSet(float _time)
	{
		if (SemiFunc.IsMasterClientOrSingleplayer())
		{
			fallDamageResetTimer = _time;
		}
	}

	[PunRPC]
	private void FallDamageResetUpdateRPC(bool _state, PhotonMessageInfo _info = default(PhotonMessageInfo))
	{
		//IL_0000: Unknown result type (might be due to invalid IL or missing references)
		if (SemiFunc.MasterOnlyRPC(_info))
		{
			fallDamageResetState = _state;
			if (isLocal && fallDamageResetState && Object.op_Implicit((Object)(object)tumble))
			{
				tumble.impactHurtTimer = 0f;
				tumble.impactHurtDamage = 0;
			}
		}
	}

	private void ChatMessageSpeak(string _message, bool crouching, string _localeCode)
	{
		if (Object.op_Implicit((Object)(object)voiceChat) && Object.op_Implicit((Object)(object)voiceChat.ttsVoice))
		{
			voiceChat.ttsVoice.TTSSpeakNow(_message, crouching, _localeCode);
		}
	}

	public void ChatMessageSend(string _message, string localeCode = null)
	{
		if (string.IsNullOrEmpty(localeCode) && _message.StartsWith('/') && Object.op_Implicit((Object)(object)DebugCommandHandler.instance) && DebugCommandHandler.instance.Execute(_message.TrimStart('/')))
		{
			return;
		}
		bool flag = isCrouching;
		string text = localeCode;
		if (string.IsNullOrEmpty(localeCode))
		{
			string localeCode2 = "en-US";
			if (Object.op_Implicit((Object)(object)LocalizationManager.instance))
			{
				localeCode2 = LocalizationManager.instance.TTSLocaleGetCode();
			}
			text = TTSPronunciation.ResolveLocale(ref _message, localeCode2);
		}
		if (string.IsNullOrWhiteSpace(_message))
		{
			return;
		}
		if (!SemiFunc.IsMultiplayer())
		{
			ChatMessageSpeak(_message, flag, text);
			return;
		}
		if (isDisabled)
		{
			flag = true;
		}
		photonView.RPC("ChatMessageSendRPC", (RpcTarget)0, new object[3] { _message, flag, text });
	}

	[PunRPC]
	public void ChatMessageSendRPC(string _message, bool crouching, string _localeCode, PhotonMessageInfo _info = default(PhotonMessageInfo))
	{
		//IL_0000: Unknown result type (might be due to invalid IL or missing references)
		if (SemiFunc.MasterAndOwnerOnlyRPC(_info, photonView) && GameDirector.instance.currentState == GameDirector.gameState.Main)
		{
			ChatMessageSpeak(_message, crouching, _localeCode);
		}
	}

	public void LoadingLevelAnimationCompleted()
	{
		//IL_0021: Unknown result type (might be due to invalid IL or missing references)
		//IL_0027: Unknown result type (might be due to invalid IL or missing references)
		if (SemiFunc.IsMultiplayer())
		{
			photonView.RPC("LoadingLevelAnimationCompletedRPC", (RpcTarget)0, Array.Empty<object>());
		}
		else
		{
			LoadingLevelAnimationCompletedRPC();
		}
	}

	[PunRPC]
	public void LoadingLevelAnimationCompletedRPC(PhotonMessageInfo _info = default(PhotonMessageInfo))
	{
		//IL_0000: Unknown result type (might be due to invalid IL or missing references)
		if (SemiFunc.OwnerOnlyRPC(_info, photonView))
		{
			levelAnimationCompleted = true;
		}
	}

	public void HealedOther()
	{
		if (SemiFunc.IsMultiplayer())
		{
			photonView.RPC("HealedOtherRPC", (RpcTarget)0, Array.Empty<object>());
		}
	}

	[PunRPC]
	public void HealedOtherRPC()
	{
		if (isLocal)
		{
			TutorialDirector.instance.playerHealed = true;
		}
	}

	public void PlayerExpressionSet(int _expressionIndex, float _percent)
	{
		//IL_000c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0012: Unknown result type (might be due to invalid IL or missing references)
		if (!SemiFunc.IsMultiplayer())
		{
			PlayerExpressionSetRPC(_expressionIndex, _percent);
			return;
		}
		photonView.RPC("PlayerExpressionSetRPC", (RpcTarget)0, new object[2] { _expressionIndex, _percent });
	}

	public void PlayerExpressionReset()
	{
		//IL_000a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0010: Unknown result type (might be due to invalid IL or missing references)
		if (!SemiFunc.IsMultiplayer())
		{
			PlayerExpressionResetRPC();
		}
		else
		{
			photonView.RPC("PlayerExpressionResetRPC", (RpcTarget)0, Array.Empty<object>());
		}
	}

	[PunRPC]
	public void PlayerExpressionSetRPC(int _expressionIndex, float _percent, PhotonMessageInfo _info = default(PhotonMessageInfo))
	{
		//IL_0000: Unknown result type (might be due to invalid IL or missing references)
		if (SemiFunc.OwnerOnlyRPC(_info, photonView))
		{
			playerExpression.expressions[_expressionIndex].stopExpressing = false;
			playerExpressions[_expressionIndex] = _percent;
		}
	}

	[PunRPC]
	public void PlayerExpressionStopRPC(int _expressionIndex, PhotonMessageInfo _info = default(PhotonMessageInfo))
	{
		//IL_0000: Unknown result type (might be due to invalid IL or missing references)
		if (SemiFunc.OwnerOnlyRPC(_info, photonView))
		{
			playerExpressions[_expressionIndex] = 0f;
			playerExpression.expressions[_expressionIndex].stopExpressing = true;
		}
	}

	public void PlayerExpressionStop(int _expressionIndex)
	{
		//IL_000b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0011: Unknown result type (might be due to invalid IL or missing references)
		if (!SemiFunc.IsMultiplayer())
		{
			PlayerExpressionStopRPC(_expressionIndex);
			return;
		}
		photonView.RPC("PlayerExpressionStopRPC", (RpcTarget)0, new object[1] { _expressionIndex });
	}

	public void OverrideTumbleWings(bool pink = false, float time = 0.1f)
	{
		if (SemiFunc.IsMasterClientOrSingleplayer() && ((Behaviour)this).isActiveAndEnabled && !isDisabled && !deadSet && (!Object.op_Implicit((Object)(object)upgradeTumbleWingsLogic) || ((Behaviour)upgradeTumbleWingsLogic).isActiveAndEnabled))
		{
			if (pink)
			{
				upgradeTumbleWingsPinkTimer = Mathf.Max(upgradeTumbleWingsPinkTimer, time);
			}
			else
			{
				upgradeTumbleWingsVisualsTimer = Mathf.Max(upgradeTumbleWingsVisualsTimer, time);
			}
		}
	}

	private void OverrideTumbleWingsTick()
	{
		if (SemiFunc.IsMasterClientOrSingleplayer())
		{
			if (isDisabled || deadSet || (Object.op_Implicit((Object)(object)upgradeTumbleWingsLogic) && !((Behaviour)upgradeTumbleWingsLogic).isActiveAndEnabled))
			{
				upgradeTumbleWingsVisualsTimer = 0f;
				upgradeTumbleWingsPinkTimer = 0f;
			}
			UpgradeTumbleWingsVisualsUpdate();
			upgradeTumbleWingsVisualsTimer = Mathf.Max(0f, upgradeTumbleWingsVisualsTimer - Time.deltaTime);
			upgradeTumbleWingsPinkTimer = Mathf.Max(0f, upgradeTumbleWingsPinkTimer - Time.deltaTime);
		}
	}

	private void UpgradeTumbleWingsVisualsUpdate()
	{
		//IL_0041: Unknown result type (might be due to invalid IL or missing references)
		//IL_0047: Unknown result type (might be due to invalid IL or missing references)
		bool flag = upgradeTumbleWingsPinkTimer > 0f;
		bool flag2 = flag || upgradeTumbleWingsVisualsTimer > 0f;
		if (upgradeTumbleWingsVisualsActive != flag2 || upgradeTumbleWingsVisualsPink != flag)
		{
			if (!SemiFunc.IsMultiplayer())
			{
				UpgradeTumbleWingsVisualsActiveRPC(flag2, flag);
				return;
			}
			photonView.RPC("UpgradeTumbleWingsVisualsActiveRPC", (RpcTarget)0, new object[2] { flag2, flag });
		}
	}

	[PunRPC]
	private void UpgradeTumbleWingsVisualsActiveRPC(bool _visualsActive = true, bool _pink = false, PhotonMessageInfo _info = default(PhotonMessageInfo))
	{
		//IL_0000: Unknown result type (might be due to invalid IL or missing references)
		if (!SemiFunc.MasterOnlyRPC(_info))
		{
			return;
		}
		bool flag = upgradeTumbleWingsVisualsActive;
		upgradeTumbleWingsVisualsActive = _visualsActive;
		upgradeTumbleWingsVisualsPink = _visualsActive & _pink;
		if (!Object.op_Implicit((Object)(object)upgradeTumbleWingsLogic))
		{
			return;
		}
		if (!_pink)
		{
			if (_visualsActive && !flag && !SemiFunc.IsMasterClientOrSingleplayer())
			{
				upgradeTumbleWingsLogic.tumbleWingTimer = 1f;
			}
			upgradeTumbleWingsLogic.WingsSetOriginalColors();
		}
		else if (_visualsActive)
		{
			upgradeTumbleWingsLogic.WingsSetPinkColors();
		}
	}

	[PunRPC]
	public void PlayerExpressionResetRPC(PhotonMessageInfo _info = default(PhotonMessageInfo))
	{
		//IL_0000: Unknown result type (might be due to invalid IL or missing references)
		if (SemiFunc.MasterAndOwnerOnlyRPC(_info, photonView))
		{
			playerExpressions.Clear();
		}
	}

	public void OnPhotonSerializeView(PhotonStream stream, PhotonMessageInfo info)
	{
		//IL_02ad: Unknown result type (might be due to invalid IL or missing references)
		//IL_000b: Unknown result type (might be due to invalid IL or missing references)
		//IL_02c0: Unknown result type (might be due to invalid IL or missing references)
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_0029: Unknown result type (might be due to invalid IL or missing references)
		//IL_003f: Unknown result type (might be due to invalid IL or missing references)
		//IL_004a: Unknown result type (might be due to invalid IL or missing references)
		//IL_006c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0071: Unknown result type (might be due to invalid IL or missing references)
		//IL_0089: Unknown result type (might be due to invalid IL or missing references)
		//IL_008e: Unknown result type (might be due to invalid IL or missing references)
		//IL_033e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0343: Unknown result type (might be due to invalid IL or missing references)
		//IL_035e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0363: Unknown result type (might be due to invalid IL or missing references)
		//IL_036e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0373: Unknown result type (might be due to invalid IL or missing references)
		//IL_037e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0383: Unknown result type (might be due to invalid IL or missing references)
		//IL_0387: Unknown result type (might be due to invalid IL or missing references)
		//IL_038c: Unknown result type (might be due to invalid IL or missing references)
		//IL_03b3: Unknown result type (might be due to invalid IL or missing references)
		//IL_03a2: Unknown result type (might be due to invalid IL or missing references)
		//IL_0104: Unknown result type (might be due to invalid IL or missing references)
		//IL_010c: Unknown result type (might be due to invalid IL or missing references)
		//IL_03b8: Unknown result type (might be due to invalid IL or missing references)
		//IL_03c3: Unknown result type (might be due to invalid IL or missing references)
		//IL_03c8: Unknown result type (might be due to invalid IL or missing references)
		//IL_0119: Unknown result type (might be due to invalid IL or missing references)
		//IL_044d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0454: Unknown result type (might be due to invalid IL or missing references)
		//IL_0459: Unknown result type (might be due to invalid IL or missing references)
		//IL_0467: Unknown result type (might be due to invalid IL or missing references)
		//IL_046e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0473: Unknown result type (might be due to invalid IL or missing references)
		//IL_0479: Unknown result type (might be due to invalid IL or missing references)
		//IL_0480: Unknown result type (might be due to invalid IL or missing references)
		//IL_0485: Unknown result type (might be due to invalid IL or missing references)
		//IL_048b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0492: Unknown result type (might be due to invalid IL or missing references)
		//IL_0497: Unknown result type (might be due to invalid IL or missing references)
		//IL_049d: Unknown result type (might be due to invalid IL or missing references)
		//IL_049f: Unknown result type (might be due to invalid IL or missing references)
		//IL_04b5: Unknown result type (might be due to invalid IL or missing references)
		//IL_04bc: Unknown result type (might be due to invalid IL or missing references)
		//IL_04c1: Unknown result type (might be due to invalid IL or missing references)
		//IL_0129: Unknown result type (might be due to invalid IL or missing references)
		//IL_0518: Unknown result type (might be due to invalid IL or missing references)
		//IL_051f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0524: Unknown result type (might be due to invalid IL or missing references)
		//IL_0162: Unknown result type (might be due to invalid IL or missing references)
		//IL_0167: Unknown result type (might be due to invalid IL or missing references)
		//IL_01b9: Unknown result type (might be due to invalid IL or missing references)
		//IL_01ec: Unknown result type (might be due to invalid IL or missing references)
		//IL_01ff: Unknown result type (might be due to invalid IL or missing references)
		//IL_0211: Unknown result type (might be due to invalid IL or missing references)
		//IL_0228: Unknown result type (might be due to invalid IL or missing references)
		//IL_0176: Unknown result type (might be due to invalid IL or missing references)
		//IL_017b: Unknown result type (might be due to invalid IL or missing references)
		//IL_017d: Unknown result type (might be due to invalid IL or missing references)
		//IL_026a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0254: Unknown result type (might be due to invalid IL or missing references)
		if (stream.IsWriting)
		{
			if (!SemiFunc.MasterAndOwnerOnlyRPC(info, photonView))
			{
				return;
			}
			Vector3 position = ((Component)PlayerController.instance).transform.position;
			bool physRiding = PlayerController.instance.CollisionGrounded.physRiding;
			float num = Vector3.Distance(flashlightLightAim.clientAimPointPrevious, flashlightLightAim.clientAimPoint);
			if (!networkFlashlightAimInitialized || num > 0.2f)
			{
				networkFlashlightAimPosition = flashlightLightAim.clientAimPoint;
				networkFlashlightAimInitialized = true;
				flashlightLightAim.clientAimPointPrevious = flashlightLightAim.clientAimPoint;
			}
			byte b = 0;
			if (isCrouching)
			{
				b |= 1;
			}
			if (isSprinting)
			{
				b |= 2;
			}
			if (isCrawling)
			{
				b |= 4;
			}
			if (isSliding)
			{
				b |= 8;
			}
			if (isMoving)
			{
				b |= 0x10;
			}
			if (isGrounded)
			{
				b |= 0x20;
			}
			if (rotationDisabled)
			{
				b |= 0x40;
			}
			if (rotationOverrideActive)
			{
				b |= 0x80;
			}
			bool flag = SemiNetPackedStream.PositionFullPrecisionRequired(position);
			bool flag2 = SemiNetPackedStream.VelocityFullPrecisionRequired(rbVelocity) || SemiNetPackedStream.VelocityFullPrecisionRequired(rbVelocityRaw);
			bool flag3 = SemiNetPackedStream.PositionFullPrecisionRequired(networkFlashlightAimPosition);
			byte b2 = 0;
			if (physRiding)
			{
				b2 |= 1;
			}
			if (flag)
			{
				b2 |= 2;
			}
			if (flag2)
			{
				b2 |= 4;
			}
			if (flag3)
			{
				b2 |= 8;
			}
			Vector3 val = Vector3.zero;
			if (physRiding)
			{
				val = PlayerController.instance.CollisionGrounded.physRidingPosition;
				if (SemiNetPackedStream.PositionFullPrecisionRequired(val))
				{
					b2 |= 0x10;
				}
			}
			networkPackedStream.Begin();
			networkPackedStream.WriteByte(b);
			networkPackedStream.WriteByte(b2);
			networkPackedStream.WriteInputDirection(InputDirectionRaw);
			networkPackedStream.WriteByte((byte)Mathf.RoundToInt(Mathf.Clamp01(InputAnalogAmount) * 255f));
			networkPackedStream.WriteVelocity(rbVelocity, flag2);
			networkPackedStream.WriteVelocity(rbVelocityRaw, flag2);
			networkPackedStream.WritePosition(position, flag);
			networkPackedStream.WriteRotation(((Component)PlayerController.instance).transform.rotation);
			if (physRiding)
			{
				networkPackedStream.WriteInt32(PlayerController.instance.CollisionGrounded.physRidingID);
				networkPackedStream.WritePosition(val, (b2 & 0x10) != 0);
			}
			networkPackedStream.WritePosition(networkFlashlightAimPosition, flag3);
			networkPackedStream.WriteUInt16((ushort)Mathf.Clamp(playerPing, 0, 65535));
			networkPackedStream.Send(stream);
			return;
		}
		byte[] array = stream.ReceiveNext() as byte[];
		if (!SemiFunc.MasterAndOwnerOnlyRPC(info, photonView))
		{
			return;
		}
		SemiNetPackedReader val2 = new SemiNetPackedReader(array);
		byte b3 = val2.ReadByte();
		byte b4 = val2.ReadByte();
		if ((b4 & -32) != 0 || (b4 & 0x11) == 16)
		{
			return;
		}
		bool flag4 = (b4 & 1) != 0;
		int num2 = 35;
		if ((b4 & 2) != 0)
		{
			num2 += 6;
		}
		if ((b4 & 4) != 0)
		{
			num2 += 12;
		}
		if ((b4 & 8) != 0)
		{
			num2 += 6;
		}
		if (flag4)
		{
			num2 += (((b4 & 0x10) != 0) ? 16 : 10);
		}
		if (!val2.LengthMatches(num2))
		{
			return;
		}
		Vector3 val3 = val2.ReadInputDirection();
		float inputAnalogAmount = (float)(int)val2.ReadByte() / 255f;
		Vector3 val4 = val2.ReadVelocity((b4 & 4) != 0);
		Vector3 val5 = val2.ReadVelocity((b4 & 4) != 0);
		Vector3 val6 = val2.ReadPosition((b4 & 2) != 0);
		Quaternion val7 = val2.ReadRotation();
		int num3 = (flag4 ? val2.ReadInt32() : 0);
		Vector3 val8 = (flag4 ? val2.ReadPosition((b4 & 0x10) != 0) : Vector3.zero);
		Vector3 val9 = val2.ReadPosition((b4 & 8) != 0);
		ushort num4 = val2.ReadUInt16();
		if (!val2.CompleteGet())
		{
			return;
		}
		isCrouching = (b3 & 1) != 0;
		isSprinting = (b3 & 2) != 0;
		isCrawling = (b3 & 4) != 0;
		isSliding = (b3 & 8) != 0;
		isMoving = (b3 & 0x10) != 0;
		isGrounded = (b3 & 0x20) != 0;
		rotationDisabled = (b3 & 0x40) != 0;
		rotationOverrideActive = (b3 & 0x80) != 0;
		InputDirectionRaw = Vector3.ClampMagnitude(val3, 100f);
		InputAnalogAmount = inputAnalogAmount;
		rbVelocity = Vector3.ClampMagnitude(val4, 100f);
		rbVelocityRaw = Vector3.ClampMagnitude(val5, 100f);
		clientPosition = Vector3.ClampMagnitude(val6, 1000f);
		clientRotation = val7;
		clientPhysRiding = flag4;
		clientPhysRidingID = num3;
		clientPhysRidingPosition = Vector3.ClampMagnitude(val8, 1000f);
		if (clientPhysRiding)
		{
			PhotonView val10 = PhotonView.Find(clientPhysRidingID);
			if (Object.op_Implicit((Object)(object)val10))
			{
				clientPhysRidingTransform = ((Component)val10).transform;
				clientPhysRidingObject = ((Component)val10).GetComponent<PhysGrabObject>();
			}
			else
			{
				clientPhysRiding = false;
			}
		}
		playerAvatarVisuals.PhysRidingCheck();
		flashlightLightAim.clientAimPoint = Vector3.ClampMagnitude(val9, 1000f);
		playerPing = num4;
	}

	public PlayerAvatar()
	{
		//IL_002f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0034: Unknown result type (might be due to invalid IL or missing references)
		//IL_003a: Unknown result type (might be due to invalid IL or missing references)
		//IL_003f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0045: Unknown result type (might be due to invalid IL or missing references)
		//IL_004a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0050: Unknown result type (might be due to invalid IL or missing references)
		//IL_0055: Unknown result type (might be due to invalid IL or missing references)
		//IL_005b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0060: Unknown result type (might be due to invalid IL or missing references)
		//IL_007e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0088: Expected Obj, but got Unknown
	}
}
