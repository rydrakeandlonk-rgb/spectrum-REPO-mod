using System;
using System.Collections.Generic;
using UnityEngine;

public class EnemyTricycleVisuals : MonoBehaviour
{
	[Serializable]
	public class TricycleWheel
	{
		public string name;

		public Transform transformShake;

		public Transform transformRotation;

		[HideInInspector]
		public Quaternion originalRotation;

		[HideInInspector]
		public float currentRotation;

		private SpringQuaternion shakeSpring;

		private Quaternion shakeTarget = Quaternion.identity;

		private float shakeIntensity;

		private float shakeFrequency;

		private float shakeTimer;

		private float noiseSeedX;

		private float noiseSeedY;

		private float noiseSeedZ;

		public void Initialize(float springSpeed, float springDamping)
		{
			//IL_0007: Unknown result type (might be due to invalid IL or missing references)
			//IL_000c: Unknown result type (might be due to invalid IL or missing references)
			originalRotation = transformRotation.localRotation;
			shakeSpring = new SpringQuaternion();
			shakeSpring.speed = springSpeed;
			shakeSpring.damping = springDamping;
			shakeSpring.maxAngle = 15f;
			shakeSpring.clamp = false;
			noiseSeedX = Random.value * 10f;
			noiseSeedY = Random.value * 10f;
			noiseSeedZ = Random.value * 10f;
		}

		public void Update(float rotationSpeed, float deltaTime)
		{
			//IL_00d5: Unknown result type (might be due to invalid IL or missing references)
			//IL_00da: Unknown result type (might be due to invalid IL or missing references)
			//IL_00ad: Unknown result type (might be due to invalid IL or missing references)
			//IL_00be: Unknown result type (might be due to invalid IL or missing references)
			//IL_00c3: Unknown result type (might be due to invalid IL or missing references)
			//IL_00c6: Unknown result type (might be due to invalid IL or missing references)
			//IL_00c8: Unknown result type (might be due to invalid IL or missing references)
			//IL_00cd: Unknown result type (might be due to invalid IL or missing references)
			//IL_00ec: Unknown result type (might be due to invalid IL or missing references)
			//IL_00f6: Unknown result type (might be due to invalid IL or missing references)
			//IL_0120: Unknown result type (might be due to invalid IL or missing references)
			//IL_0125: Unknown result type (might be due to invalid IL or missing references)
			//IL_012d: Unknown result type (might be due to invalid IL or missing references)
			//IL_0132: Unknown result type (might be due to invalid IL or missing references)
			//IL_0133: Unknown result type (might be due to invalid IL or missing references)
			shakeIntensity = Mathf.Lerp(shakeIntensity, 0f, deltaTime * 10f);
			shakeFrequency = Mathf.Lerp(shakeFrequency, 0f, deltaTime * 5f);
			if (shakeIntensity > 0.01f)
			{
				float num = Time.time * Mathf.Max(0.01f, shakeFrequency);
				float num2 = Mathf.PerlinNoise(noiseSeedX, num) * 2f - 1f;
				float num3 = Mathf.PerlinNoise(noiseSeedY, num) * 2f - 1f;
				float num4 = Mathf.PerlinNoise(noiseSeedZ, num) * 2f - 1f;
				Vector3 val = new Vector3(num2, num3, num4) * (shakeIntensity * 5f);
				shakeTarget = Quaternion.Euler(val);
			}
			else
			{
				shakeTarget = Quaternion.identity;
			}
			transformShake.localRotation = SemiFunc.SpringQuaternionGet(shakeSpring, shakeTarget);
			currentRotation += rotationSpeed * deltaTime;
			Quaternion val2 = Quaternion.Euler(currentRotation, 0f, 0f);
			transformRotation.localRotation = originalRotation * val2;
		}

		public void ApplyShakeImpulse(float intensity, float frequency = 10f)
		{
			shakeIntensity = Mathf.Max(shakeIntensity, intensity);
			shakeFrequency = Mathf.Max(shakeFrequency, frequency);
			if (shakeTimer <= 0f)
			{
				shakeTimer = 0.01f;
			}
		}

		public TricycleWheel()
		{
			//IL_0001: Unknown result type (might be due to invalid IL or missing references)
			//IL_0006: Unknown result type (might be due to invalid IL or missing references)
		}
	}

	[Serializable]
	public class TricycleHandlebars
	{
		public Transform transform;

		public Transform transformShake;

		public Transform handlebar1GrabPoint;

		public Transform handlebar2GrabPoint;

		public Transform handlebarPointTransform;

		[HideInInspector]
		public Vector3 previousPosition;

		[HideInInspector]
		public Vector3 handlebarPreviousPosition;

		[HideInInspector]
		public Vector3 handlebarVelocity;

		[HideInInspector]
		public float velocity;

		[HideInInspector]
		public Quaternion originalRotation;

		private SpringQuaternion steeringSpring;

		private SpringQuaternion shakeSpring;

		private Quaternion shakeTarget = Quaternion.identity;

		private float shakeIntensity;

		private float shakeFrequency;

		private float shakeTimer;

		private float noiseSeedX;

		private float noiseSeedY;

		private float noiseSeedZ;

		private float currentSteeringAngle;

		private float targetSteeringAngle;

		public void Initialize()
		{
			//IL_0007: Unknown result type (might be due to invalid IL or missing references)
			//IL_000c: Unknown result type (might be due to invalid IL or missing references)
			//IL_0018: Unknown result type (might be due to invalid IL or missing references)
			//IL_001d: Unknown result type (might be due to invalid IL or missing references)
			//IL_0029: Unknown result type (might be due to invalid IL or missing references)
			//IL_002e: Unknown result type (might be due to invalid IL or missing references)
			previousPosition = transform.position;
			originalRotation = transform.localRotation;
			handlebarPreviousPosition = handlebarPointTransform.position;
			steeringSpring = new SpringQuaternion();
			steeringSpring.speed = 10f;
			steeringSpring.damping = 0.6f;
			steeringSpring.maxAngle = 80f;
			steeringSpring.clamp = true;
			shakeSpring = new SpringQuaternion();
			shakeSpring.speed = 20f;
			shakeSpring.damping = 0.5f;
			shakeSpring.maxAngle = 30f;
			shakeSpring.clamp = false;
			noiseSeedX = Random.value * 10f;
			noiseSeedY = Random.value * 10f;
			noiseSeedZ = Random.value * 10f;
		}

		public void Update(float deltaTime, Transform tricycleTransform, Vector3 tricycleVelocity)
		{
			//IL_0007: Unknown result type (might be due to invalid IL or missing references)
			//IL_000d: Unknown result type (might be due to invalid IL or missing references)
			//IL_0025: Unknown result type (might be due to invalid IL or missing references)
			//IL_002a: Unknown result type (might be due to invalid IL or missing references)
			//IL_0036: Unknown result type (might be due to invalid IL or missing references)
			//IL_003c: Unknown result type (might be due to invalid IL or missing references)
			//IL_0041: Unknown result type (might be due to invalid IL or missing references)
			//IL_0047: Unknown result type (might be due to invalid IL or missing references)
			//IL_004c: Unknown result type (might be due to invalid IL or missing references)
			//IL_0058: Unknown result type (might be due to invalid IL or missing references)
			//IL_005d: Unknown result type (might be due to invalid IL or missing references)
			//IL_0075: Unknown result type (might be due to invalid IL or missing references)
			//IL_0080: Unknown result type (might be due to invalid IL or missing references)
			//IL_0085: Unknown result type (might be due to invalid IL or missing references)
			//IL_018c: Unknown result type (might be due to invalid IL or missing references)
			//IL_0191: Unknown result type (might be due to invalid IL or missing references)
			//IL_0164: Unknown result type (might be due to invalid IL or missing references)
			//IL_0175: Unknown result type (might be due to invalid IL or missing references)
			//IL_017a: Unknown result type (might be due to invalid IL or missing references)
			//IL_017d: Unknown result type (might be due to invalid IL or missing references)
			//IL_017f: Unknown result type (might be due to invalid IL or missing references)
			//IL_0184: Unknown result type (might be due to invalid IL or missing references)
			//IL_01a3: Unknown result type (might be due to invalid IL or missing references)
			//IL_01ad: Unknown result type (might be due to invalid IL or missing references)
			//IL_01e5: Unknown result type (might be due to invalid IL or missing references)
			//IL_01ea: Unknown result type (might be due to invalid IL or missing references)
			//IL_01f1: Unknown result type (might be due to invalid IL or missing references)
			//IL_01f7: Unknown result type (might be due to invalid IL or missing references)
			//IL_01fc: Unknown result type (might be due to invalid IL or missing references)
			//IL_0204: Unknown result type (might be due to invalid IL or missing references)
			//IL_0209: Unknown result type (might be due to invalid IL or missing references)
			//IL_020a: Unknown result type (might be due to invalid IL or missing references)
			velocity = Vector3.Distance(transform.position, previousPosition) / deltaTime;
			previousPosition = transform.position;
			handlebarVelocity = (handlebarPointTransform.position - handlebarPreviousPosition) / deltaTime;
			handlebarPreviousPosition = handlebarPointTransform.position;
			if (handlebarVelocity.magnitude > 0.1f)
			{
				float num = Vector3.SignedAngle(tricycleTransform.forward, handlebarVelocity.normalized, Vector3.up);
				targetSteeringAngle = Mathf.Clamp(num, -45f, 45f);
			}
			else
			{
				targetSteeringAngle = 0f;
			}
			shakeIntensity = Mathf.Lerp(shakeIntensity, 0f, deltaTime * 10f);
			shakeFrequency = Mathf.Lerp(shakeFrequency, 0f, deltaTime * 5f);
			if (shakeIntensity > 0.01f)
			{
				float num2 = Time.time * Mathf.Max(0.01f, shakeFrequency);
				float num3 = Mathf.PerlinNoise(noiseSeedX, num2) * 2f - 1f;
				float num4 = Mathf.PerlinNoise(noiseSeedY, num2) * 2f - 1f;
				float num5 = Mathf.PerlinNoise(noiseSeedZ, num2) * 2f - 1f;
				Vector3 val = new Vector3(num3, num4, num5) * (shakeIntensity * 3f);
				shakeTarget = Quaternion.Euler(val);
			}
			else
			{
				shakeTarget = Quaternion.identity;
			}
			transformShake.localRotation = SemiFunc.SpringQuaternionGet(shakeSpring, shakeTarget);
			currentSteeringAngle = Mathf.Lerp(currentSteeringAngle, targetSteeringAngle, deltaTime * 8f);
			Quaternion targetRotation = Quaternion.Euler(0f, currentSteeringAngle, 0f);
			Quaternion val2 = SemiFunc.SpringQuaternionGet(steeringSpring, targetRotation);
			transform.localRotation = originalRotation * val2;
		}

		public void ApplyShakeImpulse(float intensity, float frequency = 10f)
		{
			shakeIntensity = Mathf.Max(shakeIntensity, intensity);
			shakeFrequency = Mathf.Max(shakeFrequency, frequency);
			if (shakeTimer <= 0f)
			{
				shakeTimer = 0.01f;
			}
		}

		public TricycleHandlebars()
		{
			//IL_0001: Unknown result type (might be due to invalid IL or missing references)
			//IL_0006: Unknown result type (might be due to invalid IL or missing references)
		}
	}

	[Header("Components")]
	public List<TricycleWheel> wheels = new List<TricycleWheel>();

	public TricycleHandlebars handlebars;

	public Transform bodyTransform;

	public Transform bellTransform;

	public Transform pedalCrankTransform;

	public Transform pedal1Transform;

	public Transform pedal2Transform;

	[Header("Limb Targets")]
	public Transform hand1Transform;

	public Transform hand2Transform;

	public Transform foot1Transform;

	public Transform foot2Transform;

	public BotSystemSpringPoseAnimator botSystemSpringPoseAnimator;

	[Header("Wheel Settings")]
	public float wheelShakeSpringSpeed = 20f;

	public float wheelShakeSpringDamping = 0.5f;

	[Header("Body Shake")]
	private SpringQuaternion bodyShakeSpring;

	private Quaternion bodyShakeTarget = Quaternion.identity;

	private float bodyShakeIntensity;

	private float bodyShakeFrequency;

	private float bodyShakeTimer;

	private float bodyNoiseSeedX;

	private float bodyNoiseSeedY;

	private float bodyNoiseSeedZ;

	[Header("Bell")]
	private SpringFloat bellSpring = new SpringFloat();

	private float bellTarget;

	private float wheelRotationSpeed;

	private float wheelRotationSpeedTarget;

	private SpringFloat wheelRotationSpeedSpring = new SpringFloat();

	private Vector3 _prevTrikePosForHB;

	private float pedal1OriginalXRotation;

	private float pedal2OriginalXRotation;

	private float limbStretchingOverrideTimer;

	private float handsLetGoTimer;

	private float feetLetGoTimer;

	private void Start()
	{
		//IL_0025: Unknown result type (might be due to invalid IL or missing references)
		//IL_002a: Unknown result type (might be due to invalid IL or missing references)
		InitializeWheels();
		InitializeHandlebars();
		InitializeBodyShake();
		InitializeBell();
		InitializePedals();
		_prevTrikePosForHB = ((Component)this).transform.position;
	}

	private void Update()
	{
		UpdateWheelRotationSpeed();
		UpdateWheels();
		UpdateHandlebars();
		UpdateBodyShake();
		UpdateBell();
		UpdatePedals();
		if (limbStretchingOverrideTimer <= 0f)
		{
			UpdateLimbStretching();
		}
		if (limbStretchingOverrideTimer > 0f)
		{
			limbStretchingOverrideTimer -= Time.deltaTime;
		}
		if (handsLetGoTimer > 0f)
		{
			handsLetGoTimer -= Time.deltaTime;
		}
		if (feetLetGoTimer > 0f)
		{
			feetLetGoTimer -= Time.deltaTime;
		}
	}

	private void InitializeWheels()
	{
		foreach (TricycleWheel wheel in wheels)
		{
			wheel.Initialize(wheelShakeSpringSpeed, wheelShakeSpringDamping);
		}
	}

	private void InitializeHandlebars()
	{
		handlebars.Initialize();
	}

	private void InitializeBodyShake()
	{
		bodyShakeSpring = new SpringQuaternion();
		bodyShakeSpring.speed = 15f;
		bodyShakeSpring.damping = 0.6f;
		bodyShakeSpring.maxAngle = 20f;
		bodyShakeSpring.clamp = false;
		bodyNoiseSeedX = Random.value * 10f;
		bodyNoiseSeedY = Random.value * 10f;
		bodyNoiseSeedZ = Random.value * 10f;
	}

	private void InitializeBell()
	{
		bellSpring.speed = 55f;
		bellSpring.damping = 0.1f;
	}

	private void InitializePedals()
	{
		//IL_0007: Unknown result type (might be due to invalid IL or missing references)
		//IL_001d: Unknown result type (might be due to invalid IL or missing references)
		pedal1OriginalXRotation = pedal1Transform.localEulerAngles.x;
		pedal2OriginalXRotation = pedal2Transform.localEulerAngles.x;
	}

	private void UpdateWheelRotationSpeed()
	{
		wheelRotationSpeed = SemiFunc.SpringFloatGet(wheelRotationSpeedSpring, wheelRotationSpeedTarget);
		wheelRotationSpeedTarget = Mathf.Lerp(wheelRotationSpeedTarget, 0f, Time.deltaTime * 5f);
	}

	private void UpdateWheels()
	{
		foreach (TricycleWheel wheel in wheels)
		{
			wheel.Update(wheelRotationSpeed, Time.deltaTime);
		}
	}

	private void UpdateHandlebars()
	{
		//IL_0006: Unknown result type (might be due to invalid IL or missing references)
		//IL_000c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0011: Unknown result type (might be due to invalid IL or missing references)
		//IL_0025: Unknown result type (might be due to invalid IL or missing references)
		//IL_002a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0032: Unknown result type (might be due to invalid IL or missing references)
		//IL_0037: Unknown result type (might be due to invalid IL or missing references)
		//IL_004d: Unknown result type (might be due to invalid IL or missing references)
		Vector3 tricycleVelocity = (((Component)this).transform.position - _prevTrikePosForHB) / Mathf.Max(1E-06f, Time.deltaTime);
		_prevTrikePosForHB = ((Component)this).transform.position;
		handlebars.Update(Time.deltaTime, ((Component)this).transform, tricycleVelocity);
	}

	private void UpdateBodyShake()
	{
		//IL_00d5: Unknown result type (might be due to invalid IL or missing references)
		//IL_00da: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b5: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c0: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c5: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c7: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c8: Unknown result type (might be due to invalid IL or missing references)
		//IL_00cd: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ec: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f6: Unknown result type (might be due to invalid IL or missing references)
		bodyShakeIntensity = Mathf.Lerp(bodyShakeIntensity, 0f, Time.deltaTime * 8f);
		bodyShakeFrequency = Mathf.Lerp(bodyShakeFrequency, 0f, Time.deltaTime * 5f);
		if (bodyShakeIntensity > 0.01f)
		{
			float num = Time.time * Mathf.Max(0.01f, bodyShakeFrequency);
			float num2 = Mathf.PerlinNoise(bodyNoiseSeedX, num) * 2f - 1f;
			float num3 = Mathf.PerlinNoise(bodyNoiseSeedY, num) * 2f - 1f;
			float num4 = Mathf.PerlinNoise(bodyNoiseSeedZ, num) * 2f - 1f;
			Vector3 val = new Vector3(num2, num3, num4) * bodyShakeIntensity;
			bodyShakeTarget = Quaternion.Euler(val);
		}
		else
		{
			bodyShakeTarget = Quaternion.identity;
		}
		bodyTransform.localRotation = SemiFunc.SpringQuaternionGet(bodyShakeSpring, bodyShakeTarget);
	}

	private void UpdateBell()
	{
		//IL_0028: Unknown result type (might be due to invalid IL or missing references)
		float num = SemiFunc.SpringFloatGet(bellSpring, bellTarget);
		bellTransform.localRotation = Quaternion.Euler(0f, 0f, num);
	}

	private void UpdatePedals()
	{
		//IL_0017: Unknown result type (might be due to invalid IL or missing references)
		//IL_005a: Unknown result type (might be due to invalid IL or missing references)
		//IL_006f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0074: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b7: Unknown result type (might be due to invalid IL or missing references)
		//IL_00cc: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d1: Unknown result type (might be due to invalid IL or missing references)
		pedalCrankTransform.localRotation = wheels[0].transformRotation.localRotation;
		float num = ((wheels.Count > 0) ? wheels[0].currentRotation : 0f);
		pedal1Transform.localRotation = Quaternion.Euler(0f - num, 0f, 0f) * Quaternion.Euler(pedal1OriginalXRotation, 0f, 0f);
		num = ((wheels.Count > 0) ? wheels[0].currentRotation : 0f);
		pedal2Transform.localRotation = Quaternion.Euler(0f - num, 0f, 0f) * Quaternion.Euler(pedal2OriginalXRotation, 0f, 0f);
	}

	private void UpdateLimbStretching()
	{
		//IL_001e: Unknown result type (might be due to invalid IL or missing references)
		//IL_003a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0063: Unknown result type (might be due to invalid IL or missing references)
		//IL_007f: Unknown result type (might be due to invalid IL or missing references)
		if (handsLetGoTimer <= 0f)
		{
			botSystemSpringPoseAnimator.StretchLimbToPoint("leftarm", hand1Transform.position, _instantEndpoint: true);
			botSystemSpringPoseAnimator.StretchLimbToPoint("rightarm", hand2Transform.position, _instantEndpoint: true);
		}
		if (feetLetGoTimer <= 0f)
		{
			botSystemSpringPoseAnimator.StretchLimbToPoint("rightleg", foot1Transform.position);
			botSystemSpringPoseAnimator.StretchLimbToPoint("leftleg", foot2Transform.position);
		}
	}

	public void ImpulseWheelRotation(float speed)
	{
		wheelRotationSpeedTarget = Mathf.Max(wheelRotationSpeedTarget, speed);
	}

	public void ImpulseWheelShake(float intensity, float frequency = 10f)
	{
		foreach (TricycleWheel wheel in wheels)
		{
			wheel.ApplyShakeImpulse(intensity, frequency);
		}
	}

	public void ImpulseHandlebarShake(float intensity, float frequency = 10f)
	{
		handlebars.ApplyShakeImpulse(intensity, frequency);
	}

	public void ImpulseBodyShake(float intensity, float frequency = 10f)
	{
		bodyShakeIntensity = Mathf.Max(bodyShakeIntensity, intensity);
		bodyShakeFrequency = Mathf.Max(bodyShakeFrequency, frequency);
		if (bodyShakeTimer <= 0f)
		{
			bodyShakeTimer = 0.01f;
		}
	}

	public void ImpulseWheelShakeSingle(int wheelIndex, float intensity, float frequency = 10f)
	{
		if (wheelIndex >= 0 && wheelIndex < wheels.Count)
		{
			wheels[wheelIndex].ApplyShakeImpulse(intensity, frequency);
		}
	}

	public void ImpulseBellRing()
	{
		bellSpring.springVelocity += 2000f;
	}

	public void ImpulseImpact(float intensity = 10f)
	{
		bodyShakeIntensity = intensity;
		bodyShakeFrequency = 25f;
		if (bodyShakeTimer <= 0f)
		{
			bodyShakeTimer = 0.01f;
		}
		foreach (TricycleWheel wheel in wheels)
		{
			wheel.ApplyShakeImpulse(intensity * 0.8f, 30f);
		}
		handlebars.ApplyShakeImpulse(intensity * 1.2f, 28f);
	}

	public void ImpulseAttackImpact()
	{
		ImpulseImpact(8f);
	}

	public void DeactivateLimbStretching(float duration)
	{
		limbStretchingOverrideTimer = duration;
	}

	public void HandsLetGo(float duration)
	{
		handsLetGoTimer = duration;
	}

	public void FeetLetGo(float duration)
	{
		feetLetGoTimer = duration;
	}

	public EnemyTricycleVisuals()
	{
		//IL_0022: Unknown result type (might be due to invalid IL or missing references)
		//IL_0027: Unknown result type (might be due to invalid IL or missing references)
	}
}
