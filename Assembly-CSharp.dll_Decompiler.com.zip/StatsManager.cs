using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using Photon.Realtime;
using UnityEngine;

public class StatsManager : MonoBehaviour
{
	public class UpgradeInfo
	{
		public string displayName;

		public LocalizedAsset displayNameLocalized;
	}

	[Serializable]
	public class SerializableDictionary
	{
		public List<string> keys = new List<string>();

		public List<SerializableInnerDictionary> values = new List<SerializableInnerDictionary>();
	}

	[Serializable]
	public class SerializableInnerDictionary
	{
		public List<string> keys = new List<string>();

		public List<int> values = new List<int>();
	}

	public class SaveFolder
	{
		public string name;

		public bool isValid;

		public List<string> backups = new List<string>();
	}

	public static StatsManager instance;

	public string folderPath = "ScriptableObjects";

	public List<GameManager.LobbyTypes> savedLobbyTypes = new List<GameManager.LobbyTypes> { GameManager.LobbyTypes.Private };

	public int latestSaveVersion = 1;

	internal string totallyNormalString = "Why would you want to cheat?... :o It's no fun. :') :'D";

	public Dictionary<string, UpgradeInfo> upgradesInfo = new Dictionary<string, UpgradeInfo>();

	public LocalizedAsset localizedUpgradeCrouchRest;

	public LocalizedAsset localizedUpgradeDeathHeadBattery;

	public LocalizedAsset localizedUpgradeExtraJump;

	public LocalizedAsset localizedUpgradeHealth;

	public LocalizedAsset localizedUpgradeLaunch;

	public LocalizedAsset localizedUpgradeMapPlayerCount;

	public LocalizedAsset localizedUpgradeRange;

	public LocalizedAsset localizedUpgradeSpeed;

	public LocalizedAsset localizedUpgradeStamina;

	public LocalizedAsset localizedUpgradeStrength;

	public LocalizedAsset localizedUpgradeTumbleClimb;

	public LocalizedAsset localizedUpgradeTumbleWings;

	public Dictionary<string, Item> itemDictionary = new Dictionary<string, Item>();

	public string dateAndTime;

	public Dictionary<string, string> playerNames = new Dictionary<string, string>();

	public string teamName = "R.E.P.O.";

	public bool teamNameChanged;

	public float timePlayed;

	public int saveVersion;

	internal SortedDictionary<string, Dictionary<string, int>> dictionaryOfDictionaries = new SortedDictionary<string, Dictionary<string, int>>();

	internal readonly Dictionary<string, Dictionary<string, int>> networkSyncShadow = new Dictionary<string, Dictionary<string, int>>(StringComparer.Ordinal);

	internal string[] networkSyncPlayerSteamIDs = Array.Empty<string>();

	private Room networkSyncRoom;

	public Dictionary<string, int> itemBatteryUpgrades = new Dictionary<string, int>();

	public Dictionary<string, int> itemsPurchased = new Dictionary<string, int>();

	public Dictionary<string, int> itemsPurchasedTotal = new Dictionary<string, int>();

	public Dictionary<string, int> itemStatBattery = new Dictionary<string, int>();

	public Dictionary<string, int> itemsUpgradesPurchased = new Dictionary<string, int>();

	public Dictionary<string, int> playerHasCrown = new Dictionary<string, int>();

	public Dictionary<string, int> playerHealth = new Dictionary<string, int>();

	public Dictionary<string, int> playerInventorySpot1 = new Dictionary<string, int>();

	public Dictionary<string, int> playerInventorySpot2 = new Dictionary<string, int>();

	public Dictionary<string, int> playerInventorySpot3 = new Dictionary<string, int>();

	public Dictionary<string, int> playerUpgradeCrouchRest = new Dictionary<string, int>();

	public Dictionary<string, int> playerUpgradeDeathHeadBattery = new Dictionary<string, int>();

	public Dictionary<string, int> playerUpgradeExtraJump = new Dictionary<string, int>();

	public Dictionary<string, int> playerUpgradeHealth = new Dictionary<string, int>();

	public Dictionary<string, int> playerUpgradeLaunch = new Dictionary<string, int>();

	public Dictionary<string, int> playerUpgradeMapPlayerCount = new Dictionary<string, int>();

	public Dictionary<string, int> playerUpgradeRange = new Dictionary<string, int>();

	public Dictionary<string, int> playerUpgradeSpeed = new Dictionary<string, int>();

	public Dictionary<string, int> playerUpgradeStamina = new Dictionary<string, int>();

	public Dictionary<string, int> playerUpgradeStrength = new Dictionary<string, int>();

	public Dictionary<string, int> playerUpgradeThrow = new Dictionary<string, int>();

	public Dictionary<string, int> playerUpgradeTumbleClimb = new Dictionary<string, int>();

	public Dictionary<string, int> playerUpgradeTumbleWings = new Dictionary<string, int>();

	public Dictionary<string, int> runStats = new Dictionary<string, int>();

	public Dictionary<string, int> item = new Dictionary<string, int>();

	public Dictionary<string, int> playerInventorySpot1Taken = new Dictionary<string, int>();

	public Dictionary<string, int> playerInventorySpot2Taken = new Dictionary<string, int>();

	public Dictionary<string, int> playerInventorySpot3Taken = new Dictionary<string, int>();

	[HideInInspector]
	public bool statsSynced;

	internal List<string> takenItemNames = new List<string>();

	internal int backupIndex;

	internal string saveFileCurrent;

	internal bool saveFileReady;

	internal List<string> doNotSaveTheseDictionaries = new List<string>();

	internal Dictionary<string, int> stripTheseDictionaries = new Dictionary<string, int>();

	[RuntimeInitializeOnLoadMethod(/*Could not decode attribute arguments.*/)]
	private static void RuntimeInitializeOnLoad()
	{
		instance = null;
	}

	private void Awake()
	{
		if (!Object.op_Implicit((Object)(object)instance))
		{
			instance = this;
			Object.DontDestroyOnLoad((Object)(object)((Component)this).gameObject);
		}
		else
		{
			Object.Destroy((Object)(object)((Component)this).gameObject);
		}
	}

	public int TimePlayedGetHours(float _timePlayed)
	{
		return (int)(_timePlayed / 3600f);
	}

	public int TimePlayedGetMinutes(float _timePlayed)
	{
		return (int)(_timePlayed % 3600f / 60f);
	}

	public int TimePlayedGetSeconds(float _timePlayed)
	{
		return (int)(_timePlayed % 60f);
	}

	private void Update()
	{
		if (!SemiFunc.RunIsLobbyMenu() && !SemiFunc.IsMainMenu())
		{
			timePlayed += Time.deltaTime;
		}
	}

	private void Start()
	{
		dictionaryOfDictionaries.Add("runStats", runStats);
		dictionaryOfDictionaries.Add("itemsPurchased", itemsPurchased);
		dictionaryOfDictionaries.Add("itemsPurchasedTotal", itemsPurchasedTotal);
		dictionaryOfDictionaries.Add("itemsUpgradesPurchased", itemsUpgradesPurchased);
		dictionaryOfDictionaries.Add("itemBatteryUpgrades", itemBatteryUpgrades);
		dictionaryOfDictionaries.Add("playerHealth", playerHealth);
		dictionaryOfDictionaries.Add("playerUpgradeHealth", playerUpgradeHealth);
		upgradesInfo.Add("playerUpgradeHealth", new UpgradeInfo
		{
			displayName = "Health",
			displayNameLocalized = localizedUpgradeHealth
		});
		dictionaryOfDictionaries.Add("playerUpgradeStamina", playerUpgradeStamina);
		upgradesInfo.Add("playerUpgradeStamina", new UpgradeInfo
		{
			displayName = "Stamina",
			displayNameLocalized = localizedUpgradeStamina
		});
		dictionaryOfDictionaries.Add("playerUpgradeExtraJump", playerUpgradeExtraJump);
		upgradesInfo.Add("playerUpgradeExtraJump", new UpgradeInfo
		{
			displayName = "Extra Jump",
			displayNameLocalized = localizedUpgradeExtraJump
		});
		dictionaryOfDictionaries.Add("playerUpgradeLaunch", playerUpgradeLaunch);
		upgradesInfo.Add("playerUpgradeLaunch", new UpgradeInfo
		{
			displayName = "Tumble Launch",
			displayNameLocalized = localizedUpgradeLaunch
		});
		dictionaryOfDictionaries.Add("playerUpgradeTumbleClimb", playerUpgradeTumbleClimb);
		upgradesInfo.Add("playerUpgradeTumbleClimb", new UpgradeInfo
		{
			displayName = "Tumble Climb",
			displayNameLocalized = localizedUpgradeTumbleClimb
		});
		dictionaryOfDictionaries.Add("playerUpgradeDeathHeadBattery", playerUpgradeDeathHeadBattery);
		upgradesInfo.Add("playerUpgradeDeathHeadBattery", new UpgradeInfo
		{
			displayName = "Death Head Battery",
			displayNameLocalized = localizedUpgradeDeathHeadBattery
		});
		dictionaryOfDictionaries.Add("playerUpgradeMapPlayerCount", playerUpgradeMapPlayerCount);
		upgradesInfo.Add("playerUpgradeMapPlayerCount", new UpgradeInfo
		{
			displayName = "Map Player Count",
			displayNameLocalized = localizedUpgradeMapPlayerCount
		});
		dictionaryOfDictionaries.Add("playerUpgradeSpeed", playerUpgradeSpeed);
		upgradesInfo.Add("playerUpgradeSpeed", new UpgradeInfo
		{
			displayName = "Speed",
			displayNameLocalized = localizedUpgradeSpeed
		});
		dictionaryOfDictionaries.Add("playerUpgradeStrength", playerUpgradeStrength);
		upgradesInfo.Add("playerUpgradeStrength", new UpgradeInfo
		{
			displayName = "Strength",
			displayNameLocalized = localizedUpgradeStrength
		});
		dictionaryOfDictionaries.Add("playerUpgradeRange", playerUpgradeRange);
		upgradesInfo.Add("playerUpgradeRange", new UpgradeInfo
		{
			displayName = "Range",
			displayNameLocalized = localizedUpgradeRange
		});
		dictionaryOfDictionaries.Add("playerUpgradeThrow", playerUpgradeThrow);
		upgradesInfo.Add("playerUpgradeThrow", new UpgradeInfo
		{
			displayName = "Throw",
			displayNameLocalized = null
		});
		dictionaryOfDictionaries.Add("playerUpgradeCrouchRest", playerUpgradeCrouchRest);
		upgradesInfo.Add("playerUpgradeCrouchRest", new UpgradeInfo
		{
			displayName = "Crouch Rest",
			displayNameLocalized = localizedUpgradeCrouchRest
		});
		dictionaryOfDictionaries.Add("playerUpgradeTumbleWings", playerUpgradeTumbleWings);
		upgradesInfo.Add("playerUpgradeTumbleWings", new UpgradeInfo
		{
			displayName = "Tumble Wings",
			displayNameLocalized = localizedUpgradeTumbleWings
		});
		dictionaryOfDictionaries.Add("playerInventorySpot1", playerInventorySpot1);
		dictionaryOfDictionaries.Add("playerInventorySpot2", playerInventorySpot2);
		dictionaryOfDictionaries.Add("playerInventorySpot3", playerInventorySpot3);
		dictionaryOfDictionaries.Add("playerHasCrown", playerHasCrown);
		dictionaryOfDictionaries.Add("item", item);
		dictionaryOfDictionaries.Add("itemStatBattery", itemStatBattery);
		doNotSaveTheseDictionaries.Add("playerInventorySpot1");
		doNotSaveTheseDictionaries.Add("playerInventorySpot2");
		doNotSaveTheseDictionaries.Add("playerInventorySpot3");
		stripTheseDictionaries.Add("itemsPurchased", 0);
		stripTheseDictionaries.Add("itemsPurchasedTotal", 0);
		stripTheseDictionaries.Add("itemsUpgradesPurchased", 0);
		stripTheseDictionaries.Add("itemBatteryUpgrades", 0);
		stripTheseDictionaries.Add("itemStatBattery", 100);
		stripTheseDictionaries.Add("playerHealth", 100);
		foreach (KeyValuePair<string, Dictionary<string, int>> dictionaryOfDictionary in dictionaryOfDictionaries)
		{
			if (dictionaryOfDictionary.Key.StartsWith("playerInventorySpot"))
			{
				stripTheseDictionaries.TryAdd(dictionaryOfDictionary.Key, -1);
			}
			else if (dictionaryOfDictionary.Key.StartsWith("player"))
			{
				stripTheseDictionaries.TryAdd(dictionaryOfDictionary.Key, 0);
			}
		}
		try
		{
			string text = Application.persistentDataPath + "/saves/.es3";
			if (ES3.FileExists(text))
			{
				ES3.DeleteFile(text);
				Debug.Log((object)("Deleted leftover save file: " + text));
			}
		}
		catch
		{
		}
	}

	internal void NetworkSyncSessionEnsure(Room _room)
	{
		if (networkSyncRoom != _room)
		{
			networkSyncRoom = _room;
			NetworkSyncShadowReset();
		}
	}

	internal void NetworkSyncShadowReset()
	{
		networkSyncShadow.Clear();
		networkSyncPlayerSteamIDs = Array.Empty<string>();
	}

	public void PlayerAdd(string _steamID, string _playerName)
	{
		PlayerAddName(_steamID, _playerName);
	}

	public List<string> SaveFileGetPlayerNames(string folderName, string fileName)
	{
		//IL_0050: Unknown result type (might be due to invalid IL or missing references)
		//IL_0056: Expected Obj, but got Unknown
		if (string.IsNullOrWhiteSpace(fileName))
		{
			fileName = folderName;
		}
		string text = Application.persistentDataPath + "/saves/" + folderName + "/" + fileName + ".es3";
		if (File.Exists(text))
		{
			ES3Settings val = new ES3Settings(text, (EncryptionType)1, totallyNormalString, (ES3Settings)null);
			if (ES3.KeyExists("playerNames", val))
			{
				Dictionary<string, string> dictionary = ES3.Load<Dictionary<string, string>>("playerNames", val);
				List<string> list = new List<string>();
				{
					foreach (KeyValuePair<string, string> item in dictionary)
					{
						list.Add(item.Value);
					}
					return list;
				}
			}
			Debug.LogWarning((object)("Key 'playerNames' not found in save file '" + fileName + "'."));
		}
		else
		{
			Debug.LogWarning((object)("Save file not found in " + text));
		}
		return null;
	}

	public float SaveFileGetTimePlayed(string _folderName, string _fileName = null)
	{
		//IL_0050: Unknown result type (might be due to invalid IL or missing references)
		//IL_0056: Expected Obj, but got Unknown
		if (string.IsNullOrWhiteSpace(_fileName))
		{
			_fileName = _folderName;
		}
		string text = Application.persistentDataPath + "/saves/" + _folderName + "/" + _fileName + ".es3";
		if (File.Exists(text))
		{
			ES3Settings val = new ES3Settings(text, (EncryptionType)1, totallyNormalString, (ES3Settings)null);
			if (ES3.KeyExists("timePlayed", val))
			{
				return ES3.Load<float>("timePlayed", val);
			}
			Debug.LogWarning((object)("Key 'timePlayed' not found in save file '" + _fileName + "'."));
		}
		else
		{
			Debug.LogWarning((object)("Save file not found in " + text));
		}
		return 0f;
	}

	public List<string> SaveFileGetBackups(string folderName, string rootPath)
	{
		List<string> result = new List<string>();
		string path = rootPath + "/" + folderName;
		if (Directory.Exists(path))
		{
			result = (from backup in (from backup in Directory.GetFiles(path)
					where Path.GetExtension(backup) == ".es3"
					select backup).Select(Path.GetFileNameWithoutExtension)
				where backup.StartsWith(folderName + "_BACKUP")
				select backup).OrderByDescending(SemiFunc.GetBackupNumber).ToList();
		}
		return result;
	}

	public void SaveFileCreate(string saveFileName = "", bool saveIsDebug = false)
	{
		if (string.IsNullOrEmpty(saveFileName) && !saveIsDebug)
		{
			saveFileName = "REPO_SAVE_" + DateTime.Now.ToString("yyyy_MM_dd_HH_mm_ss", CultureInfo.InvariantCulture);
		}
		saveFileCurrent = saveFileName;
		if (saveIsDebug)
		{
			teamName = "R.E.P.O. DEV";
			teamNameChanged = true;
		}
		else
		{
			teamName = "R.E.P.O.";
			teamNameChanged = false;
		}
		saveVersion = latestSaveVersion;
		PlayersAddAll();
		backupIndex = 0;
		saveFileReady = true;
	}

	public void SaveFileSave()
	{
		if (savedLobbyTypes.Contains(GameManager.instance.lobbyType))
		{
			SaveGame(saveFileCurrent);
		}
		PlayersAddAll();
		saveFileReady = true;
	}

	public string SaveFileGetTeamName(string folderName, string fileName = null)
	{
		//IL_0050: Unknown result type (might be due to invalid IL or missing references)
		//IL_0056: Expected Obj, but got Unknown
		if (string.IsNullOrWhiteSpace(fileName))
		{
			fileName = folderName;
		}
		string text = Application.persistentDataPath + "/saves/" + folderName + "/" + fileName + ".es3";
		if (File.Exists(text))
		{
			ES3Settings val = new ES3Settings(text, (EncryptionType)1, totallyNormalString, (ES3Settings)null);
			if (ES3.KeyExists("teamName", val))
			{
				return ES3.Load<string>("teamName", val);
			}
			Debug.LogWarning((object)("Key 'teamName' not found in save file '" + fileName + "'."));
		}
		else
		{
			Debug.LogWarning((object)("Save file not found in " + text));
		}
		return null;
	}

	public bool SaveFileGetRenamed(string folderName, string fileName = null)
	{
		//IL_0050: Unknown result type (might be due to invalid IL or missing references)
		//IL_0056: Expected Obj, but got Unknown
		if (string.IsNullOrWhiteSpace(fileName))
		{
			fileName = folderName;
		}
		string text = Application.persistentDataPath + "/saves/" + folderName + "/" + fileName + ".es3";
		if (File.Exists(text))
		{
			ES3Settings val = new ES3Settings(text, (EncryptionType)1, totallyNormalString, (ES3Settings)null);
			if (ES3.KeyExists("teamNameChanged", val))
			{
				return ES3.Load<bool>("teamNameChanged", val);
			}
			return ES3.Load<string>("teamName", (string)null, "R.E.P.O.", val) != "R.E.P.O.";
		}
		Debug.LogWarning((object)("Save file not found in " + text));
		return false;
	}

	public string SaveFileGetDateAndTime(string folderName, string fileName = null)
	{
		//IL_0050: Unknown result type (might be due to invalid IL or missing references)
		//IL_0056: Expected Obj, but got Unknown
		if (string.IsNullOrWhiteSpace(fileName))
		{
			fileName = folderName;
		}
		string text = Application.persistentDataPath + "/saves/" + folderName + "/" + fileName + ".es3";
		if (File.Exists(text))
		{
			ES3Settings val = new ES3Settings(text, (EncryptionType)1, totallyNormalString, (ES3Settings)null);
			if (ES3.KeyExists("dateAndTime", val))
			{
				return ES3.Load<string>("dateAndTime", val);
			}
			Debug.LogWarning((object)("Key 'dateAndTime' not found in save file '" + fileName + "'."));
		}
		else
		{
			Debug.LogWarning((object)("Save file not found in " + text));
		}
		return null;
	}

	private string SaveFileGetRunStat(string folderName, string fileName, string _runStat)
	{
		//IL_0053: Unknown result type (might be due to invalid IL or missing references)
		//IL_0059: Expected Obj, but got Unknown
		if (string.IsNullOrWhiteSpace(fileName))
		{
			fileName = folderName;
		}
		string text = Application.persistentDataPath + "/saves/" + folderName + "/" + fileName + ".es3";
		if (File.Exists(text))
		{
			ES3Settings val = new ES3Settings(text, (EncryptionType)1, totallyNormalString, (ES3Settings)null);
			try
			{
				if (!ES3.KeyExists("dictionaryOfDictionaries", val))
				{
					Debug.LogWarning((object)("Key 'dictionaryOfDictionaries' not found in save file '" + fileName + "'."));
					return null;
				}
			}
			catch (Exception ex)
			{
				Debug.LogWarning((object)("Key 'dictionaryOfDictionaries' not found in save file '" + fileName + "': " + ex.Message));
				return null;
			}
			Dictionary<string, Dictionary<string, int>> dictionary = ES3.Load<Dictionary<string, Dictionary<string, int>>>("dictionaryOfDictionaries", (string)null, new Dictionary<string, Dictionary<string, int>>(), val);
			if (dictionary.ContainsKey("runStats"))
			{
				Dictionary<string, int> dictionary2 = dictionary["runStats"];
				if (dictionary2 != null && dictionary2.ContainsKey(_runStat))
				{
					return dictionary2[_runStat].ToString();
				}
				Debug.LogWarning((object)("Key '" + _runStat + "' not found in 'runStats' in save file '" + fileName + "'."));
			}
			else
			{
				Debug.LogWarning((object)("Key 'runStats' not found in save file '" + fileName + "'."));
			}
		}
		else
		{
			Debug.LogWarning((object)("Save file not found in " + text));
		}
		return null;
	}

	public string SaveFileGetRunLevel(string folderName, string fileName = null)
	{
		return SaveFileGetRunStat(folderName, fileName, "level");
	}

	public string SaveFileGetRunCurrency(string folderName, string fileName = null)
	{
		return SaveFileGetRunStat(folderName, fileName, "currency");
	}

	public string SaveFileGetTotalHaul(string folderName, string fileName = null)
	{
		return SaveFileGetRunStat(folderName, fileName, "totalHaul");
	}

	private void RunStartStats()
	{
		runStats.Clear();
		runStats.Add("level", 0);
		runStats.Add("currency", 0);
		runStats.Add("lives", 3);
		runStats.Add("chargingStationCharge", 1);
		runStats.Add("chargingStationChargeTotal", 100);
		runStats.Add("totalHaul", 0);
		item.Clear();
		itemStatBattery.Clear();
		statsSynced = true;
		LoadItemsFromFolder();
		itemsPurchased["Item Power Crystal"] = 1;
		itemsPurchasedTotal["Item Power Crystal"] = 1;
		itemsPurchased["Item Cart Medium"] = 1;
		itemsPurchasedTotal["Item Cart Medium"] = 1;
	}

	private void PlayerAddName(string _steamID, string _playerName)
	{
		if (!string.IsNullOrEmpty(_steamID))
		{
			playerNames[_steamID] = _playerName;
		}
	}

	public Dictionary<string, int> FetchPlayerUpgrades(string _steamID)
	{
		Dictionary<string, int> dictionary = new Dictionary<string, int>();
		foreach (var (text2, dictionary3) in dictionaryOfDictionaries)
		{
			if (text2.StartsWith("playerUpgrade") && dictionary3.ContainsKey(_steamID))
			{
				int value = dictionary3[_steamID];
				dictionary.Add(text2, value);
			}
		}
		return dictionary;
	}

	public void DictionaryUpdateValue(string dictionaryName, string key, int value)
	{
		if (dictionaryOfDictionaries.ContainsKey(dictionaryName))
		{
			if (!stripTheseDictionaries.ContainsKey(dictionaryName) || stripTheseDictionaries[dictionaryName] != value)
			{
				dictionaryOfDictionaries[dictionaryName][key] = value;
			}
			else
			{
				dictionaryOfDictionaries[dictionaryName].Remove(key);
			}
		}
	}

	public void ItemUpdateStatBattery(string itemName, int value, bool sync = true)
	{
		if (SemiFunc.IsMasterClientOrSingleplayer() && !SemiFunc.RunIsShop() && item.ContainsKey(itemName))
		{
			if (sync)
			{
				PunManager.instance.UpdateStat("itemStatBattery", itemName, value);
			}
			else
			{
				DictionaryUpdateValue("itemStatBattery", itemName, value);
			}
		}
	}

	public void PlayerInventoryUpdate(string _steamID, string itemName, int spot, bool sync = true)
	{
		if (!SemiFunc.IsMasterClientOrSingleplayer())
		{
			return;
		}
		int num = itemName.GetHashCode();
		if (itemName == "")
		{
			num = -1;
		}
		if (spot == 0)
		{
			if (num != -1)
			{
				playerInventorySpot1[_steamID] = num;
			}
			else
			{
				playerInventorySpot1.Remove(_steamID);
			}
			if (playerInventorySpot1.GetValueOrDefault(_steamID, -1) != -1)
			{
				playerInventorySpot1Taken[_steamID] = 1;
			}
			else
			{
				playerInventorySpot1Taken.Remove(_steamID);
			}
			if (sync)
			{
				PunManager.instance.UpdateStat("playerInventorySpot1", _steamID, num);
			}
		}
		if (spot == 1)
		{
			if (num != -1)
			{
				playerInventorySpot2[_steamID] = num;
			}
			else
			{
				playerInventorySpot2.Remove(_steamID);
			}
			if (playerInventorySpot2.GetValueOrDefault(_steamID, -1) != -1)
			{
				playerInventorySpot2Taken[_steamID] = 1;
			}
			else
			{
				playerInventorySpot2Taken.Remove(_steamID);
			}
			if (sync)
			{
				PunManager.instance.UpdateStat("playerInventorySpot2", _steamID, num);
			}
		}
		if (spot == 2)
		{
			if (num != -1)
			{
				playerInventorySpot3[_steamID] = num;
			}
			else
			{
				playerInventorySpot3.Remove(_steamID);
			}
			if (playerInventorySpot3.GetValueOrDefault(_steamID, -1) != -1)
			{
				playerInventorySpot3Taken[_steamID] = 1;
			}
			else
			{
				playerInventorySpot3Taken.Remove(_steamID);
			}
			if (sync)
			{
				PunManager.instance.UpdateStat("playerInventorySpot3", _steamID, num);
			}
		}
	}

	public void ItemFetchName(string itemName, ItemAttributes itemAttributes, int photonViewID)
	{
		string name = itemName;
		bool flag = false;
		if (!SemiFunc.RunIsShop() && !SemiFunc.RunIsArena())
		{
			foreach (string key in item.Keys)
			{
				if (key.Contains('/') && key.Split('/')[0] == itemName && !takenItemNames.Contains(key))
				{
					name = key;
					takenItemNames.Add(key);
					flag = true;
					break;
				}
			}
		}
		if (!flag)
		{
			ItemAdd(itemName, itemAttributes, photonViewID);
		}
		else
		{
			PunManager.instance.SetItemName(name, itemAttributes, photonViewID);
		}
	}

	public void StuffNeedingResetAtTheEndOfAScene()
	{
		takenItemNames.Clear();
		playerInventorySpot1Taken.Clear();
		playerInventorySpot2Taken.Clear();
		playerInventorySpot3Taken.Clear();
	}

	public int GetIndexThatHoldsThisItemFromItemDictionary(string itemName)
	{
		int num = 0;
		foreach (string key in itemDictionary.Keys)
		{
			if (key == itemName)
			{
				return num;
			}
			num++;
		}
		return -1;
	}

	public string GetItemNameFromIndexInItemDictionary(int index)
	{
		if (index >= 0 && index < itemDictionary.Count)
		{
			return itemDictionary.Keys.ElementAt(index);
		}
		return null;
	}

	public void ItemAdd(string itemName, ItemAttributes itemAttributes = null, int photonViewID = -1)
	{
		int num = 1;
		foreach (string key in item.Keys)
		{
			if (!key.Contains('/'))
			{
				continue;
			}
			string[] array = key.Split('/');
			if (array[0] == itemName)
			{
				int num2 = int.Parse(array[1]);
				if (num2 >= num)
				{
					num = num2 + 1;
				}
			}
		}
		int indexThatHoldsThisItemFromItemDictionary = GetIndexThatHoldsThisItemFromItemDictionary(itemName);
		itemName = itemName + "/" + num;
		AddingItem(itemName, indexThatHoldsThisItemFromItemDictionary, photonViewID, itemAttributes);
	}

	private void AddingItem(string itemName, int index, int photonViewID, ItemAttributes itemAttributes)
	{
		PunManager.instance.AddingItem(itemName, index, photonViewID, itemAttributes);
	}

	public void ItemRemove(string instanceName)
	{
		if (SemiFunc.RunIsArena() || string.IsNullOrEmpty(instanceName))
		{
			return;
		}
		if (item.ContainsKey(instanceName))
		{
			string key = instanceName.Split('/')[0];
			if (itemsPurchased.TryGetValue(key, out var value))
			{
				value--;
				if (value > 0)
				{
					itemsPurchased[key] = value;
				}
				else
				{
					itemsPurchased.Remove(key);
				}
			}
		}
		else
		{
			Debug.LogError((object)("Item " + instanceName + " not found in item dictionary"));
		}
		item.Remove(instanceName);
		itemStatBattery.Remove(instanceName);
	}

	public void ItemPurchase(string itemName)
	{
		itemsPurchased[itemName] = itemsPurchased.GetValueOrDefault(itemName, 0) + 1;
		itemsPurchasedTotal[itemName] = itemsPurchasedTotal.GetValueOrDefault(itemName, 0) + 1;
		if (itemDictionary.TryGetValue(itemName, out var value) && value.physicalItem)
		{
			ItemAdd(itemName);
		}
	}

	private List<Dictionary<string, int>> AllDictionariesWithPrefix(string prefix)
	{
		List<Dictionary<string, int>> list = new List<Dictionary<string, int>>();
		foreach (KeyValuePair<string, Dictionary<string, int>> dictionaryOfDictionary in dictionaryOfDictionaries)
		{
			if (dictionaryOfDictionary.Key.StartsWith(prefix))
			{
				list.Add(dictionaryOfDictionary.Value);
			}
		}
		return list;
	}

	public int GetBatteryLevel(string itemName)
	{
		return itemStatBattery.GetValueOrDefault(itemName, 100);
	}

	public void SetBatteryLevel(string itemName, int value)
	{
		itemStatBattery[itemName] = value;
	}

	public int GetItemPurchased(Item _item)
	{
		return itemsPurchased.GetValueOrDefault(((Object)_item).name, 0);
	}

	public void SetItemPurchase(Item _item, int value)
	{
		itemsPurchased[((Object)_item).name] = value;
	}

	public int GetItemsUpgradesPurchased(string itemName)
	{
		return itemsUpgradesPurchased.GetValueOrDefault(itemName, 0);
	}

	public int GetItemsUpgradesPurchasedTotal(string itemName)
	{
		return itemsPurchasedTotal.GetValueOrDefault(itemName, 0);
	}

	public void SetItemsUpgradesPurchased(string itemName, int value)
	{
		itemsUpgradesPurchased[itemName] = value;
	}

	public void AddItemsUpgradesPurchased(string itemName)
	{
		itemsUpgradesPurchased[itemName] = itemsUpgradesPurchased.GetValueOrDefault(itemName) + 1;
	}

	public void SetPlayerHealth(string _steamID, int health, bool setInShop)
	{
		if ((!SemiFunc.RunIsShop() && !RunManager.instance.levelIsShop) || setInShop)
		{
			playerHealth[_steamID] = health;
		}
	}

	public int GetPlayerHealth(string _steamID)
	{
		return playerHealth.GetValueOrDefault(_steamID, 100);
	}

	public int GetPlayerMaxHealth(string _steamID)
	{
		playerUpgradeHealth.TryGetValue(_steamID, out var value);
		return value * 20;
	}

	public int GetRunStatCurrency()
	{
		return runStats.GetValueOrDefault("currency", 0);
	}

	public int GetRunStatLives()
	{
		return runStats.GetValueOrDefault("lives", 0);
	}

	public int GetRunStatLevel()
	{
		return runStats.GetValueOrDefault("level", 0);
	}

	public int GetRunStatSaveLevel()
	{
		return runStats.GetValueOrDefault("save level", 0);
	}

	public int GetRunStatTotalHaul()
	{
		return runStats.GetValueOrDefault("totalHaul", 0);
	}

	public void ResetAllStats()
	{
		saveFileReady = false;
		NetworkSyncShadowReset();
		ItemManager.instance.ResetAllItems();
		foreach (KeyValuePair<string, Dictionary<string, int>> dictionaryOfDictionary in dictionaryOfDictionaries)
		{
			if (!SemiFunc.RunIsArena() || !(dictionaryOfDictionary.Key == "playerHasCrown"))
			{
				dictionaryOfDictionary.Value.Clear();
			}
		}
		takenItemNames.Clear();
		playerNames.Clear();
		timePlayed = 0f;
		RunStartStats();
	}

	internal void LoadItemsFromFolder()
	{
		itemDictionary.Clear();
		Item[] array = Resources.LoadAll<Item>(folderPath);
		Item[] array2 = array;
		foreach (Item item in array2)
		{
			if (!string.IsNullOrEmpty(((Object)item).name))
			{
				itemDictionary.TryAdd(((Object)item).name, item);
			}
			else
			{
				Debug.LogWarning((object)"Item with empty or null itemName found and will be skipped.");
			}
		}
		string path = (Application.isEditor ? Path.Combine("Cache", "Editor") : "Cache");
		string path2 = Path.Combine(Application.persistentDataPath, path, "Icons", "Items");
		if (!Directory.Exists(path2))
		{
			return;
		}
		List<string> _itemNames = new List<string>(array.Select((Item x) => ((Object)x).name.ToLowerInvariant()));
		Directory.GetFiles(path2).ToList().ForEach((string f) =>
		{
			try
			{
				if (!_itemNames.Contains(Path.GetFileNameWithoutExtension(f).ToLowerInvariant()))
				{
					File.Delete(f);
				}
			}
			catch (Exception ex)
			{
				Debug.LogError((object)ex);
			}
		});
	}

	public void EmptyAllBatteries()
	{
		foreach (string item in new List<string>(itemStatBattery.Keys))
		{
			itemStatBattery[item] = 0;
		}
	}

	public void BuyAllItems()
	{
		if (!SemiFunc.IsMasterClientOrSingleplayer())
		{
			return;
		}
		foreach (string item in new List<string>(itemDictionary.Keys))
		{
			ItemPurchase(item);
		}
	}

	private void ManualEntry()
	{
		List<KeyValuePair<string, Item>> list = new List<KeyValuePair<string, Item>>();
		foreach (KeyValuePair<string, Item> item in itemDictionary)
		{
			string name = ((Object)item.Value).name;
			if (!string.IsNullOrEmpty(name))
			{
				list.Add(new KeyValuePair<string, Item>(name, item.Value));
			}
			else
			{
				Debug.LogWarning((object)"Item with empty or null name found and will be skipped.");
			}
		}
		itemDictionary.Clear();
		foreach (KeyValuePair<string, Item> item2 in list)
		{
			if (!itemDictionary.ContainsKey(item2.Key))
			{
				itemDictionary.Add(item2.Key, item2.Value);
			}
			else
			{
				Debug.LogWarning((object)("Duplicate key found: " + item2.Key + ". This entry will be skipped."));
			}
		}
	}

	public async Task<List<SaveFolder>> SaveFileGetAllAsync()
	{
		string savesPath = Application.persistentDataPath + "/saves";
		return await Task.Run(() =>
		{
			List<SaveFolder> list = new List<SaveFolder>();
			if (Directory.Exists(savesPath))
			{
				foreach (string item in Directory.GetDirectories(savesPath).OrderByDescending(Directory.GetCreationTime).Select(Path.GetFileName)
					.ToList())
				{
					SaveFolder saveFolder = new SaveFolder
					{
						name = item,
						isValid = File.Exists(savesPath + "/" + item + "/" + item + ".es3")
					};
					try
					{
						saveFolder.backups = SaveFileGetBackups(item, savesPath);
					}
					catch (Exception ex)
					{
						Debug.LogWarning((object)("Skipping unreadable save folder " + item + ": " + ex.Message));
						continue;
					}
					if (saveFolder.isValid || saveFolder.backups.Count != 0)
					{
						list.Add(saveFolder);
					}
				}
			}
			else
			{
				Debug.LogWarning((object)("Saves directory not found at " + savesPath));
			}
			return list;
		});
	}

	public void SaveFileDelete(string saveFileName)
	{
		string text = Application.persistentDataPath + "/saves/" + saveFileName;
		if (Directory.Exists(text))
		{
			List<int> list = SemiFunc.DeleteDirectoriesRecursive(text);
			Debug.Log((object)$"Deleted {list[0]}/{list[1]} files and directories for '{saveFileName}'");
		}
		else if (!string.IsNullOrEmpty(saveFileName))
		{
			Debug.LogWarning((object)("Save folder not found: " + text));
		}
	}

	public void SaveGame(string fileName)
	{
		//IL_0135: Unknown result type (might be due to invalid IL or missing references)
		//IL_013b: Expected Obj, but got Unknown
		//IL_013d: Unknown result type (might be due to invalid IL or missing references)
		if (string.IsNullOrEmpty(fileName) || !SemiFunc.IsMasterClientOrSingleplayer())
		{
			return;
		}
		dateAndTime = DateTime.Now.ToString("yyyy-MM-dd", CultureInfo.InvariantCulture);
		string text = Application.persistentDataPath + "/saves";
		if (!Directory.Exists(text))
		{
			Directory.CreateDirectory(text);
		}
		string text2 = text + "/" + fileName;
		if (!Directory.Exists(text2))
		{
			Directory.CreateDirectory(text2);
		}
		string text3 = text2 + "/" + fileName + ".es3";
		if (File.Exists(text3))
		{
			backupIndex++;
			string destFileName = text2 + "/" + fileName + "_BACKUP" + backupIndex + ".es3";
			File.Move(text3, destFileName);
			foreach (string item in SaveFileGetBackups(fileName, text).Skip(3))
			{
				SemiFunc.DeleteFileSafe(text2 + "/" + item + ".es3");
			}
		}
		ES3Settings val = new ES3Settings(new Enum[1] { (Enum)(object)(Location)4 });
		val.encryptionType = (EncryptionType)1;
		val.encryptionPassword = totallyNormalString;
		val.path = text3;
		ES3.Save<string>("teamName", teamName, val);
		ES3.Save<bool>("teamNameChanged", teamNameChanged, val);
		ES3.Save<string>("dateAndTime", dateAndTime, val);
		ES3.Save<float>("timePlayed", timePlayed, val);
		ES3.Save<Dictionary<string, string>>("playerNames", playerNames, val);
		Dictionary<string, Dictionary<string, int>> dictionary = new Dictionary<string, Dictionary<string, int>>();
		foreach (KeyValuePair<string, Dictionary<string, int>> dictionaryOfDictionary in dictionaryOfDictionaries)
		{
			if (doNotSaveTheseDictionaries.Contains(dictionaryOfDictionary.Key))
			{
				continue;
			}
			if (stripTheseDictionaries.TryGetValue(dictionaryOfDictionary.Key, out var value))
			{
				Dictionary<string, int> dictionary2 = new Dictionary<string, int>();
				foreach (KeyValuePair<string, int> item2 in dictionaryOfDictionary.Value)
				{
					if (value != item2.Value)
					{
						dictionary2[item2.Key] = item2.Value;
					}
					else
					{
						dictionary2.Remove(item2.Key);
					}
				}
				dictionary[dictionaryOfDictionary.Key] = dictionary2;
			}
			else
			{
				dictionary[dictionaryOfDictionary.Key] = dictionaryOfDictionary.Value;
			}
		}
		ES3.Save<Dictionary<string, Dictionary<string, int>>>("dictionaryOfDictionaries", dictionary, val);
		ES3.Save<int>("saveVersion", saveVersion, val);
		try
		{
			ES3.StoreCachedFile(val);
		}
		catch (Exception ex)
		{
			Debug.LogError((object)ex);
		}
	}

	internal void PlayersAddAll()
	{
		if (!SemiFunc.IsMasterClientOrSingleplayer())
		{
			return;
		}
		foreach (PlayerAvatar player in GameDirector.instance.PlayerList)
		{
			if (!string.IsNullOrEmpty(player.steamID))
			{
				PlayerAdd(player.steamID, player.playerName);
			}
		}
	}

	public void LoadGame(string fileName, List<string> backupList)
	{
		//IL_005d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0063: Expected Obj, but got Unknown
		if (!SemiFunc.IsMasterClientOrSingleplayer())
		{
			return;
		}
		NetworkSyncShadowReset();
		string text = Application.persistentDataPath + "/saves/" + fileName + "/" + fileName + ".es3";
		if (File.Exists(text))
		{
			saveFileCurrent = fileName;
			ES3Settings val = new ES3Settings(text, (EncryptionType)1, totallyNormalString, (ES3Settings)null);
			teamName = ES3.Load<string>("teamName", (string)null, "R.E.P.O.", val);
			teamNameChanged = ES3.Load<bool>("teamNameChanged", (string)null, teamName != "R.E.P.O.", val);
			dateAndTime = ES3.Load<string>("dateAndTime", (string)null, DateTime.Now.ToString("yyyy-MM-dd", CultureInfo.InvariantCulture), val);
			timePlayed = ES3.Load<float>("timePlayed", (string)null, 0f, val);
			playerNames = ES3.Load<Dictionary<string, string>>("playerNames", (string)null, new Dictionary<string, string>(), val);
			saveVersion = ES3.Load<int>("saveVersion", (string)null, 0, val);
			foreach (KeyValuePair<string, Dictionary<string, int>> item in ES3.Load<Dictionary<string, Dictionary<string, int>>>("dictionaryOfDictionaries", (string)null, new Dictionary<string, Dictionary<string, int>>(), val))
			{
				if (doNotSaveTheseDictionaries.Contains(item.Key))
				{
					continue;
				}
				if (dictionaryOfDictionaries.TryGetValue(item.Key, out var value))
				{
					foreach (KeyValuePair<string, int> item2 in item.Value)
					{
						if (!stripTheseDictionaries.ContainsKey(item.Key) || stripTheseDictionaries[item.Key] != item2.Value)
						{
							value[item2.Key] = item2.Value;
						}
						else
						{
							value.Remove(item2.Key);
						}
					}
				}
				else
				{
					Debug.LogWarning((object)("dictionaryOfDictionaries does not contain key '" + item.Key + "'."));
					dictionaryOfDictionaries.Add(item.Key, new Dictionary<string, int>(item.Value));
				}
			}
			if (saveVersion < 1)
			{
				foreach (string item3 in itemStatBattery.Keys.Where((string key) => !key.Contains("/")).ToList())
				{
					itemStatBattery.Remove(item3);
				}
				foreach (string item4 in this.item.Keys.Where((string key) => !itemStatBattery.ContainsKey(key)).ToList())
				{
					this.item.Remove(item4);
				}
			}
		}
		else
		{
			teamName = "R.E.P.O.";
			teamNameChanged = false;
			Debug.LogWarning((object)("Save file not found in " + text));
		}
		saveVersion = latestSaveVersion;
		RunManager.instance.levelsCompleted = GetRunStatLevel();
		RunManager.instance.runLives = GetRunStatLives();
		RunManager.instance.loadLevel = GetRunStatSaveLevel();
		PlayersAddAll();
		if (backupList == null)
		{
			backupList = SaveFileGetBackups(fileName, Application.persistentDataPath + "/saves");
		}
		if (backupList.Count > 0)
		{
			backupIndex = SemiFunc.GetBackupNumber(backupList[0]);
		}
		else
		{
			backupIndex = 0;
		}
		saveFileReady = true;
	}

	public void UpdateCrown(string steamID)
	{
		playerHasCrown.Clear();
		playerHasCrown[steamID] = 1;
	}
}
