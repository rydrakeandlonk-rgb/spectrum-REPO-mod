using Photon.Pun;
using UnityEngine;

public class PlayerVisionTarget : MonoBehaviourPunCallbacks, IPunObservable
{
	private PhotonView PhotonView;

	private PlayerAvatar PlayerAvatar;

	private PlayerController PlayerController;

	public Transform VisionTransform;

	private Camera MainCamera;

	[Space]
	public float StandPosition;

	public float CrouchPosition;

	public float CrawlPosition;

	[Space]
	public float HeadStandPosition;

	public float HeadCrouchPosition;

	public float HeadCrawlPosition;

	private float TargetPosition;

	private const float networkStandPosition = 1.5f;

	private const float networkCrouchPosition = 0.35f;

	private Quaternion TargetRotation;

	internal float CurrentPosition;

	internal Quaternion CurrentRotation;

	public float LerpSpeed;

	[Space]
	public bool DebugMeshActive = true;

	public Mesh DebugMesh;

	private void Awake()
	{
		PhotonView = ((Component)this).GetComponent<PhotonView>();
	}

	private void Start()
	{
		PlayerAvatar = ((Component)this).GetComponent<PlayerAvatar>();
		CurrentPosition = StandPosition;
		PlayerController = PlayerController.instance;
		MainCamera = Camera.main;
	}

	private void Update()
	{
		//IL_00c2: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c8: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d8: Unknown result type (might be due to invalid IL or missing references)
		//IL_00dd: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f8: Unknown result type (might be due to invalid IL or missing references)
		//IL_0109: Unknown result type (might be due to invalid IL or missing references)
		//IL_0093: Unknown result type (might be due to invalid IL or missing references)
		//IL_0098: Unknown result type (might be due to invalid IL or missing references)
		//IL_007b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0080: Unknown result type (might be due to invalid IL or missing references)
		if (PlayerAvatar.isLocal)
		{
			if (PlayerController.Crouching)
			{
				if (PlayerController.Crawling)
				{
					TargetPosition = CrawlPosition;
				}
				else
				{
					TargetPosition = CrouchPosition;
				}
			}
			else
			{
				TargetPosition = StandPosition;
			}
			if (!PlayerAvatar.rotationDisabled)
			{
				if (PlayerController.instance.overrideTurnRotationTimer > 0f)
				{
					TargetRotation = ((Component)PlayerController.instance).transform.rotation;
				}
				else
				{
					TargetRotation = ((Component)MainCamera).transform.rotation;
				}
			}
		}
		CurrentPosition = Mathf.Lerp(CurrentPosition, TargetPosition, Time.deltaTime * LerpSpeed);
		CurrentRotation = Quaternion.Slerp(CurrentRotation, TargetRotation, Time.deltaTime * 20f);
		VisionTransform.localPosition = new Vector3(0f, CurrentPosition, 0f);
		VisionTransform.rotation = CurrentRotation;
	}

	private void OnDrawGizmos()
	{
		//IL_001c: Unknown result type (might be due to invalid IL or missing references)
		//IL_002c: Unknown result type (might be due to invalid IL or missing references)
		//IL_003d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0042: Unknown result type (might be due to invalid IL or missing references)
		//IL_0047: Unknown result type (might be due to invalid IL or missing references)
		//IL_0051: Unknown result type (might be due to invalid IL or missing references)
		if (DebugMeshActive)
		{
			Gizmos.color = new Color(0f, 1f, 0.13f, 0.75f);
			Gizmos.matrix = VisionTransform.localToWorldMatrix;
			Gizmos.DrawMesh(DebugMesh, 0, Vector3.zero, Quaternion.identity, Vector3.one * 0.15f);
		}
	}

	public void OnPhotonSerializeView(PhotonStream stream, PhotonMessageInfo info)
	{
		//IL_0000: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c8: Unknown result type (might be due to invalid IL or missing references)
		//IL_005e: Unknown result type (might be due to invalid IL or missing references)
		if (!SemiFunc.MasterAndOwnerOnlyRPC(info, ((MonoBehaviourPun)this).photonView))
		{
			return;
		}
		if (stream.IsWriting)
		{
			byte b = 0;
			if (TargetPosition == 1.5f)
			{
				b = 1;
			}
			else if (TargetPosition == 0.35f)
			{
				b = 2;
			}
			stream.SendNext((object)b);
			stream.SendNext((b == 0) ? ((object)TargetPosition) : null);
			stream.SendNext((object)TargetRotation);
			return;
		}
		byte b2 = (byte)stream.ReceiveNext();
		object obj = stream.ReceiveNext();
		switch (b2)
		{
		case 1:
			TargetPosition = 1.5f;
			break;
		case 2:
			TargetPosition = 0.35f;
			break;
		case 0:
			if (obj is float targetPosition)
			{
				TargetPosition = targetPosition;
			}
			break;
		}
		TargetRotation = (Quaternion)stream.ReceiveNext();
	}
}
