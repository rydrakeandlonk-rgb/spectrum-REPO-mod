using System.Collections;
using System.Collections.Generic;
using Photon.Pun;
using Photon.Realtime;
using Steamworks;
using UnityEngine;
using UnityEngine.SceneManagement;

public class RunManager : MonoBehaviour
{
	public enum ChangeLevelType
	{
		Normal,
		RunLevel,
		Tutorial,
		LobbyMenu,
		MainMenu,
		Shop,
		Recording
	}

	public enum SaveLevel
	{
		RunLevel,
		Shop,
		Lobby
	}

	private enum SceneHandoffState
	{
		Idle,
		FirstLeg,
		Waiting,
		Cancelling
	}

	private enum SessionLeaveState
	{
		Idle,
		Waiting,
		Loading
	}

	[Tooltip("Increment this if the splash screen has changed and should be forced to show again")]
	[Space]
	public int splashScreenLatestVersion;

	public static RunManager instance;

	internal int saveLevel;

	internal int loadLevel;

	internal Level debugLevel;

	internal bool localSingleplayerTest;

	internal bool localMultiplayerTest;

	internal bool runStarted;

	internal RunManagerPUN runManagerPUN;

	[Space]
	public Level levelCurrent;

	public int levelsCompleted;

	internal Level levelPrevious;

	private Level previousRunLevel;

	private Level previousShopLevel;

	internal bool restarting;

	internal bool restartingDone;

	internal int levelsMax = 10;

	[Space]
	public Level levelLobby;

	public Level levelLobbyMenu;

	public Level levelMainMenu;

	public Level levelRecording;

	public Level levelSplashScreen;

	public Level levelTutorial;

	[Space]
	public List<Level> levelShop;

	[Space]
	public List<Level> levelArena;

	[Space]
	public List<Level> levels;

	internal int runLives = 3;

	internal bool levelFailed;

	internal bool waitToChangeScene;

	internal bool lobbyJoin;

	internal bool masterSwitched;

	internal bool gameOver;

	internal bool allPlayersDead;

	internal bool allPlayersDeadCheckDisabled;

	[Space]
	public List<Moon> moons = new List<Moon>();

	private int moonLevelPrev;

	internal int moonLevel;

	internal bool moonLevelChanged;

	[Space]
	public List<EnemySetup> enemiesSpawned;

	private List<EnemySetup> enemiesSpawnedToDelete = new List<EnemySetup>();

	internal bool skipLoadingUI = true;

	internal Color loadingFadeColor = Color.black;

	internal float loadingAnimationTime;

	internal List<PlayerVoiceChat> voiceChats = new List<PlayerVoiceChat>();

	internal bool levelIsShop;

	private SceneHandoffState sceneHandoffState;

	private SessionLeaveState sessionLeaveState;

	private int sceneHandoffToken;

	private int sceneHandoffReloadHandle;

	private Room sceneHandoffRoom;

	private int sceneHandoffMaster;

	private bool sceneHandoffNativePending;

	private float sceneHandoffNativeTimer;

	private bool sceneHandoffMultiplayer;

	private bool sceneSwitchCompleted;

	private bool sceneSwitchTutorial;

	private LocalizedAsset sceneHandoffHeader;

	private LocalizedAsset sceneHandoffCause;

	private LocalizedAsset sceneHandoffStuck;

	private LocalizedAsset sceneHandoffHost;

	private LocalizedAsset sceneHandoffButton;

	internal Dictionary<string, Object> singleplayerPool = new Dictionary<string, Object>();

	internal MultiplayerPool multiplayerPool = new MultiplayerPool();

	internal float cosmeticWorldObjectCooldown;

	internal int cosmeticWorldObjectBadLuckCount;

	internal int megaModuleBadLuckCount;

	internal int megaModuleCooldownCount;

	public bool SceneHandoffCancelling => sceneHandoffState == SceneHandoffState.Cancelling;

	internal bool SceneHandoffActive => sceneHandoffState != SceneHandoffState.Idle;

	public bool SceneHandoffFirstLegPending => sceneHandoffState == SceneHandoffState.FirstLeg;

	public bool SceneHandoffFirstLegAvailable
	{
		get
		{
			//IL_0116: Unknown result type (might be due to invalid IL or missing references)
			//IL_011b: Unknown result type (might be due to invalid IL or missing references)
			if (!SceneHandoffActive && sessionLeaveState == SessionLeaveState.Idle && sceneSwitchCompleted && Object.op_Implicit((Object)(object)LevelGenerator.Instance) && LevelGenerator.Instance.Generated && Object.op_Implicit((Object)(object)levelCurrent) && (Object)(object)levelCurrent != (Object)(object)levelMainMenu && (Object)(object)levelCurrent != (Object)(object)levelSplashScreen && (Object)(object)levelCurrent != (Object)(object)levelTutorial && (Object)(object)levelCurrent != (Object)(object)levelRecording && ((Object)(object)LevelGenerator.Instance.Level != (Object)(object)levelMainMenu || (Object)(object)levelCurrent != (Object)(object)levelLobbyMenu) && (Object)(object)LevelGenerator.Instance.Level != (Object)(object)levelSplashScreen && (Object)(object)LevelGenerator.Instance.Level != (Object)(object)levelTutorial && (Object)(object)LevelGenerator.Instance.Level != (Object)(object)levelRecording)
			{
				Scene activeScene = SceneManager.GetActiveScene();
				return activeScene.name == "Main";
			}
			return false;
		}
	}

	[RuntimeInitializeOnLoadMethod(/*Could not decode attribute arguments.*/)]
	private static void RuntimeInitializeOnLoad()
	{
		instance = null;
	}

	private void Awake()
	{
		if (!Object.op_Implicit((Object)(object)instance))
		{
			instance = this;
			Object.DontDestroyOnLoad((Object)(object)((Component)this).gameObject);
		}
		else
		{
			Object.Destroy((Object)(object)((Component)this).gameObject);
		}
		levelPrevious = levelCurrent;
	}

	private void Update()
	{
		SceneHandoffTick();
		SceneHandoffNativeStuckTick();
		if (SceneHandoffActive || sessionLeaveState != SessionLeaveState.Idle)
		{
			return;
		}
		if (LevelGenerator.Instance.Generated && (!SteamClient.IsValid || !Object.op_Implicit((Object)(object)SteamLobbyManager.instance) || !((Behaviour)SteamLobbyManager.instance).enabled))
		{
			Debug.LogError((object)"Steam not initialized. Quitting game.");
			Application.Quit();
		}
		if (SemiFunc.IsMasterClientOrSingleplayer())
		{
			if (Application.isEditor)
			{
				if (Input.GetKeyDown((KeyCode)284))
				{
					if (SemiFunc.RunIsArena())
					{
						ChangeLevel(_completedLevel: true, _levelFailed: true);
					}
					else
					{
						ChangeLevel(_completedLevel: true, _levelFailed: false);
					}
				}
				if (!restarting && SemiFunc.NoTextInputsActive() && Input.GetKeyDown((KeyCode)8))
				{
					ResetProgress();
					RestartScene();
					if ((Object)(object)levelCurrent != (Object)(object)levelTutorial)
					{
						SemiFunc.OnSceneSwitch(gameOver, _leaveGame: false);
					}
				}
			}
			if (restarting)
			{
				RestartScene();
			}
			if (!restarting && !allPlayersDeadCheckDisabled && runStarted && GameDirector.instance.PlayerList.Count > 0 && !SemiFunc.RunIsArena() && GameDirector.instance.currentState == GameDirector.gameState.Main)
			{
				bool flag = true;
				foreach (PlayerAvatar player in GameDirector.instance.PlayerList)
				{
					if (!player.isDisabled)
					{
						flag = false;
						break;
					}
				}
				if (flag)
				{
					AllPlayersDeadSet(_set: true);
					ExtractionPoint extractionPoint = (Object.op_Implicit((Object)(object)RoundDirector.instance) ? RoundDirector.instance.extractionPointCurrent : null);
					if (Object.op_Implicit((Object)(object)SpectateCamera.instance) && !SpectateCamera.instance.CheckState(SpectateCamera.State.Death) && (!Object.op_Implicit((Object)(object)extractionPoint) || !extractionPoint.ShopExtractionInProgress()) && (!Object.op_Implicit((Object)(object)DebugComputerCheck.instance) || DebugComputerCheck.instance.DebugDisable || !DebugComputerCheck.instance.LevelDebug || DebugComputerCheck.instance.DeathLevelChange))
					{
						ChangeLevel(_completedLevel: false, _levelFailed: true);
					}
				}
				else
				{
					AllPlayersDeadSet(_set: false);
				}
			}
		}
		if (cosmeticWorldObjectCooldown > 0f)
		{
			cosmeticWorldObjectCooldown -= Time.deltaTime;
		}
	}

	private void OnApplicationQuit()
	{
		DataDirector.instance.SaveDeleteCheck(_leaveGame: true);
	}

	public void ChangeLevel(bool _completedLevel, bool _levelFailed, ChangeLevelType _changeLevelType = ChangeLevelType.Normal)
	{
		if ((!SemiFunc.MenuLevel() && !SemiFunc.IsMasterClientOrSingleplayer()) || restarting)
		{
			return;
		}
		gameOver = false;
		if (_levelFailed && (Object)(object)levelCurrent != (Object)(object)levelLobby && !SemiFunc.IsLevelShop(levelCurrent))
		{
			if (SemiFunc.IsLevelArena(levelCurrent))
			{
				ResetProgress();
				if (SemiFunc.IsMultiplayer())
				{
					levelCurrent = levelLobbyMenu;
				}
				else
				{
					SetRunLevel();
				}
				gameOver = true;
			}
			else
			{
				SetArenaLevel();
			}
		}
		if (!gameOver && !SemiFunc.IsLevelArena(levelCurrent))
		{
			switch (_changeLevelType)
			{
			case ChangeLevelType.RunLevel:
				SetRunLevel();
				break;
			case ChangeLevelType.LobbyMenu:
				levelCurrent = levelLobbyMenu;
				break;
			case ChangeLevelType.MainMenu:
				levelCurrent = levelMainMenu;
				break;
			case ChangeLevelType.Tutorial:
				levelCurrent = levelTutorial;
				break;
			case ChangeLevelType.Recording:
				levelCurrent = levelRecording;
				break;
			case ChangeLevelType.Shop:
				SetShopLevel();
				break;
			default:
				if ((Object)(object)levelCurrent == (Object)(object)levelMainMenu || (Object)(object)levelCurrent == (Object)(object)levelLobbyMenu)
				{
					levelCurrent = levelLobby;
				}
				else if (_completedLevel && (Object)(object)levelCurrent != (Object)(object)levelLobby && !SemiFunc.IsLevelShop(levelCurrent))
				{
					previousRunLevel = levelCurrent;
					levelsCompleted++;
					if (SemiFunc.RunIsLevel() && ValuableDirector.instance.cosmeticWorldObjectTargetAmount <= 0)
					{
						cosmeticWorldObjectBadLuckCount++;
					}
					SemiFunc.StatSetRunLevel(levelsCompleted);
					SemiFunc.LevelSuccessful();
					SetShopLevel();
				}
				else if ((Object)(object)levelCurrent == (Object)(object)levelLobby)
				{
					SetRunLevel();
				}
				else if (SemiFunc.IsLevelShop(levelCurrent))
				{
					levelCurrent = levelLobby;
				}
				break;
			}
		}
		if ((Object)(object)levelCurrent != (Object)(object)levelSplashScreen && (Object)(object)levelCurrent != (Object)(object)levelMainMenu && (Object)(object)levelCurrent != (Object)(object)levelTutorial && (Object)(object)levelCurrent != (Object)(object)levelLobbyMenu)
		{
			if (Object.op_Implicit((Object)(object)debugLevel))
			{
				levelCurrent = debugLevel;
			}
			else if (Object.op_Implicit((Object)(object)DebugComputerCheck.instance) && !DebugComputerCheck.instance.DebugDisable && DebugComputerCheck.instance.LevelDebug)
			{
				Level moduleLevelFromName = SemiFunc.GetModuleLevelFromName(DebugComputerCheck.instance.ModuleOverride?.PrefabName);
				if (DebugComputerCheck.instance.ModuleOverrideActive && DebugComputerCheck.instance.ModuleOverrideLevel && Object.op_Implicit((Object)(object)moduleLevelFromName))
				{
					levelCurrent = moduleLevelFromName;
				}
				else if (Object.op_Implicit((Object)(object)DebugComputerCheck.instance.LevelOverride))
				{
					levelCurrent = DebugComputerCheck.instance.LevelOverride;
				}
			}
		}
		allPlayersDeadCheckDisabled = true;
		AllPlayersDeadSet(_levelFailed);
		if (GameManager.Multiplayer())
		{
			runManagerPUN.photonView.RPC("UpdateLevelRPC", (RpcTarget)4, new object[3]
			{
				((Object)levelCurrent).name,
				levelsCompleted,
				gameOver
			});
		}
		if (SemiFunc.IsLevelShop(levelCurrent))
		{
			saveLevel = 1;
		}
		else if (SemiFunc.RunIsLobby())
		{
			saveLevel = 2;
		}
		else
		{
			saveLevel = 0;
		}
		SemiFunc.StatSetSaveLevel(saveLevel);
		RestartScene();
		if (_changeLevelType != ChangeLevelType.Tutorial)
		{
			SemiFunc.OnSceneSwitch(gameOver, _leaveGame: false);
		}
	}

	public void RestartScene()
	{
		if (!restarting)
		{
			restarting = true;
			if (!Object.op_Implicit((Object)(object)GameDirector.instance))
			{
				return;
			}
			{
				foreach (PlayerAvatar player in GameDirector.instance.PlayerList)
				{
					player.OutroStart();
				}
				return;
			}
		}
		if (restartingDone)
		{
			return;
		}
		bool flag = true;
		if (!Object.op_Implicit((Object)(object)GameDirector.instance))
		{
			flag = false;
		}
		else
		{
			foreach (PlayerAvatar player2 in GameDirector.instance.PlayerList)
			{
				if (!player2.outroDone)
				{
					flag = false;
					break;
				}
			}
		}
		if (!flag)
		{
			return;
		}
		bool flag2 = false;
		if (gameOver)
		{
			NetworkManager.instance.DestroyRunObjects();
			gameOver = false;
			flag2 = true;
		}
		if (lobbyJoin)
		{
			lobbyJoin = false;
			restartingDone = true;
			PhotonNetwork.SceneLoadScopeCancelPending();
			SceneManager.LoadSceneAsync("LobbyJoin");
		}
		else
		{
			if (waitToChangeScene)
			{
				return;
			}
			restartingDone = true;
			if (!flag2 && SemiFunc.RunIsLobbyMenu())
			{
				NetworkManager.instance.DestroyRunObjects();
			}
			if (!GameManager.Multiplayer())
			{
				if (!SceneHandoffFirstLegAvailable || !PhotonNetwork.LoadLevelScopedLocal("Reload"))
				{
					SceneManager.LoadSceneAsync("Main");
				}
			}
			else if (PhotonNetwork.IsMasterClient)
			{
				PhotonNetwork.AutomaticallySyncScene = true;
				PhotonNetwork.LoadLevel("Reload");
			}
		}
	}

	public void UpdateLevel(string _levelName, int _levelsCompleted, bool _gameOver)
	{
		if (Object.op_Implicit((Object)(object)LobbyMenuOpen.instance))
		{
			DataDirector.instance.RunsPlayedAdd();
		}
		levelsCompleted = _levelsCompleted;
		SemiFunc.StatSetRunLevel(levelsCompleted);
		bool flag = false;
		foreach (Level item in levelShop)
		{
			if (_levelName == ((Object)item).name)
			{
				flag = true;
				levelCurrent = item;
				break;
			}
		}
		if (!flag)
		{
			bool flag2 = false;
			foreach (Level item2 in levelArena)
			{
				if (_levelName == ((Object)item2).name)
				{
					flag2 = true;
					levelCurrent = item2;
					break;
				}
			}
			if (!flag2)
			{
				if (_levelName == ((Object)levelLobbyMenu).name)
				{
					levelCurrent = levelLobbyMenu;
				}
				else if (_levelName == ((Object)levelLobby).name)
				{
					levelCurrent = levelLobby;
				}
				else if (_levelName == ((Object)levelRecording).name)
				{
					levelCurrent = levelRecording;
				}
				else
				{
					foreach (Level level in levels)
					{
						if (((Object)level).name == _levelName)
						{
							levelCurrent = level;
							break;
						}
					}
				}
			}
		}
		SemiFunc.OnSceneSwitch(_gameOver, _leaveGame: false);
	}

	public void ResetProgress()
	{
		if (Object.op_Implicit((Object)(object)StatsManager.instance))
		{
			StatsManager.instance.ResetAllStats();
		}
		levelsCompleted = 0;
		loadLevel = 0;
		UpdateMoonLevel();
	}

	public void EnemiesSpawnedRemoveStart()
	{
		enemiesSpawnedToDelete.Clear();
		foreach (EnemySetup item in enemiesSpawned)
		{
			bool flag = false;
			foreach (EnemySetup item2 in enemiesSpawnedToDelete)
			{
				if ((Object)(object)item == (Object)(object)item2)
				{
					flag = true;
					break;
				}
			}
			if (!flag)
			{
				enemiesSpawnedToDelete.Add(item);
			}
		}
	}

	public void EnemiesSpawnedRemoveEnd()
	{
		foreach (EnemySetup item in enemiesSpawnedToDelete)
		{
			enemiesSpawned.Remove(item);
		}
	}

	public void SetArenaLevel()
	{
		if (levelArena == null || levelArena.Count == 0)
		{
			return;
		}
		if (SemiFunc.PlayerGetAll().Count <= 1)
		{
			if (Object.op_Implicit((Object)(object)levelArena[0]))
			{
				levelCurrent = levelArena[0];
			}
			return;
		}
		List<Level> list = levelArena.FindAll((Level _level) => Object.op_Implicit((Object)(object)_level));
		if (Object.op_Implicit((Object)(object)GameManager.instance) && GameManager.instance.IsWIPActive(DebugCommandHandler.WIPTypes.Level))
		{
			List<Level> list2 = list.FindAll((Level _level) => _level.status != Level.Status.Finalized);
			if (list2.Count > 0)
			{
				list = list2;
			}
		}
		if (list.Count > 0)
		{
			levelCurrent = list[Random.Range(0, list.Count)];
		}
	}

	public void SetRunLevel()
	{
		if (levels == null || levels.Count == 0)
		{
			levelCurrent = previousRunLevel;
			return;
		}
		List<Level> list = levels.FindAll((Level _level) => Object.op_Implicit((Object)(object)_level));
		if (Object.op_Implicit((Object)(object)GameManager.instance) && GameManager.instance.IsWIPActive(DebugCommandHandler.WIPTypes.Level))
		{
			List<Level> list2 = list.FindAll((Level _level) => _level.status != Level.Status.Finalized);
			if (list2.Count > 0)
			{
				list = list2;
			}
		}
		List<Level> list3 = list.FindAll((Level _level) => (Object)(object)_level != (Object)(object)previousRunLevel);
		levelCurrent = ((list3.Count > 0) ? list3[Random.Range(0, list3.Count)] : previousRunLevel);
	}

	public void SetShopLevel()
	{
		if (levelShop == null || levelShop.Count == 0)
		{
			levelCurrent = previousShopLevel;
			return;
		}
		List<Level> list = levelShop.FindAll((Level _level) => Object.op_Implicit((Object)(object)_level));
		if (Object.op_Implicit((Object)(object)GameManager.instance) && GameManager.instance.IsWIPActive(DebugCommandHandler.WIPTypes.Level))
		{
			List<Level> list2 = list.FindAll((Level _level) => _level.status != Level.Status.Finalized);
			if (list2.Count > 0)
			{
				list = list2;
			}
		}
		List<Level> list3 = list.FindAll((Level _level) => (Object)(object)_level != (Object)(object)previousShopLevel);
		levelCurrent = ((list3.Count > 0) ? list3[Random.Range(0, list3.Count)] : previousShopLevel);
		previousShopLevel = levelCurrent;
	}

	internal void SceneSwitchCompleted()
	{
		//IL_001a: Unknown result type (might be due to invalid IL or missing references)
		sceneSwitchCompleted = true;
		sceneSwitchTutorial = SemiFunc.RunIsTutorial();
		if (SceneHandoffFirstLegAvailable)
		{
			ReloadScene.FirstLegConfigure(SceneManager.GetActiveScene());
		}
	}

	internal void SceneHandoffMessagesSet(NetworkManager _network)
	{
		sceneHandoffHeader = _network.disconnectedHeaderLocalized;
		sceneHandoffCause = _network.disconnectedCausePrefixLocalized;
		sceneHandoffStuck = _network.reasonStuckInLoadingLocalized;
		sceneHandoffHost = _network.reasonHostDisconnectedLocalized;
		sceneHandoffButton = _network.disconnectedButtonLocalized;
	}

	public int SceneHandoffFirstLegBegin(int _mainHandle)
	{
		//IL_0008: Unknown result type (might be due to invalid IL or missing references)
		//IL_000d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0010: Unknown result type (might be due to invalid IL or missing references)
		//IL_0016: Unknown result type (might be due to invalid IL or missing references)
		if (SceneHandoffFirstLegAvailable)
		{
			Scene activeScene = SceneManager.GetActiveScene();
			if (!(activeScene.handle != SceneHandle.op_Implicit(_mainHandle)))
			{
				return SceneHandoffStart(_mainHandle, SceneHandoffState.FirstLeg);
			}
		}
		return 0;
	}

	public void SceneHandoffAdvance(int _token, int _reloadHandle)
	{
		if (SceneHandoffValid(_token) && SceneHandoffFirstLegPending && !sceneHandoffNativePending)
		{
			sceneHandoffReloadHandle = _reloadHandle;
			sceneHandoffState = SceneHandoffState.Waiting;
		}
	}

	public int SceneHandoffBegin(int _reloadHandle)
	{
		if (SceneHandoffActive)
		{
			if (sceneHandoffReloadHandle == _reloadHandle && SceneHandoffValid(sceneHandoffToken))
			{
				return sceneHandoffToken;
			}
			SceneHandoffCancel();
			return 0;
		}
		if (sessionLeaveState != SessionLeaveState.Idle || !SemiFunc.IsMultiplayer())
		{
			return 0;
		}
		return SceneHandoffStart(_reloadHandle, SceneHandoffState.Waiting);
	}

	private int SceneHandoffStart(int _sourceHandle, SceneHandoffState _state)
	{
		//IL_008e: Unknown result type (might be due to invalid IL or missing references)
		sceneHandoffToken++;
		if (sceneHandoffToken == 0)
		{
			sceneHandoffToken++;
		}
		sceneHandoffReloadHandle = _sourceHandle;
		sceneHandoffMultiplayer = SemiFunc.IsMultiplayer();
		sceneHandoffRoom = (sceneHandoffMultiplayer ? PhotonNetwork.CurrentRoom : null);
		Room val = sceneHandoffRoom;
		sceneHandoffMaster = ((val != null) ? val.MasterClientId : 0);
		sceneHandoffNativePending = false;
		sceneHandoffState = _state;
		if (sceneHandoffMultiplayer && (!PhotonNetwork.InRoom || !PhotonNetwork.IsConnectedAndReady))
		{
			SceneHandoffCancel(PhotonNetwork.NetworkingClient.DisconnectedCause);
			return 0;
		}
		return sceneHandoffToken;
	}

	public bool SceneHandoffValid(int _token)
	{
		if (_token == 0 || _token != sceneHandoffToken || (sceneHandoffState != SceneHandoffState.FirstLeg && sceneHandoffState != SceneHandoffState.Waiting) || sceneHandoffMultiplayer != SemiFunc.IsMultiplayer())
		{
			return false;
		}
		if (!sceneHandoffMultiplayer)
		{
			return true;
		}
		if (PhotonNetwork.IsConnectedAndReady && PhotonNetwork.InRoom && sceneHandoffRoom != null && PhotonNetwork.CurrentRoom == sceneHandoffRoom)
		{
			return sceneHandoffRoom.MasterClientId == sceneHandoffMaster;
		}
		return false;
	}

	public void SceneHandoffNativePendingSet(int _token, bool _pending)
	{
		if (_token == sceneHandoffToken && SceneHandoffActive && (!_pending || !SceneHandoffCancelling))
		{
			if (sceneHandoffNativePending != _pending)
			{
				sceneHandoffNativeTimer = 0f;
			}
			sceneHandoffNativePending = _pending;
		}
	}

	public void SceneHandoffComplete(int _token)
	{
		if (SceneHandoffValid(_token) && sceneHandoffState == SceneHandoffState.Waiting && !sceneHandoffNativePending)
		{
			sceneHandoffState = SceneHandoffState.Idle;
			sceneHandoffRoom = null;
			sceneSwitchCompleted = false;
			sceneSwitchTutorial = false;
		}
	}

	private void SceneHandoffNativeStuckTick()
	{
		if (!SceneHandoffActive || SceneHandoffCancelling || !sceneHandoffNativePending)
		{
			sceneHandoffNativeTimer = 0f;
			return;
		}
		sceneHandoffNativeTimer += Time.unscaledDeltaTime;
		if (!(sceneHandoffNativeTimer < 60f))
		{
			Debug.LogError((object)"this machine spent 60 seconds loading or unloading a scene during the level change... something hung on this side... leaving to the menu");
			SceneHandoffCancel();
		}
	}

	private void SceneHandoffTick()
	{
		//IL_007f: Unknown result type (might be due to invalid IL or missing references)
		if (SceneHandoffActive && !SceneHandoffCancelling && !SceneHandoffValid(sceneHandoffToken))
		{
			if (sceneHandoffMultiplayer && sceneHandoffRoom != null && PhotonNetwork.InRoom && PhotonNetwork.CurrentRoom == sceneHandoffRoom && sceneHandoffRoom.MasterClientId != sceneHandoffMaster)
			{
				SceneHandoffCancel(sceneHandoffHost?.GetLocalizedString() ?? "Host disconnected");
			}
			else
			{
				SceneHandoffCancel(PhotonNetwork.NetworkingClient.DisconnectedCause);
			}
		}
	}

	public void SceneHandoffCancel()
	{
		SceneHandoffCancel(sceneHandoffStuck?.GetLocalizedString() ?? "Stuck in loading");
	}

	internal void SceneHandoffCancel(DisconnectCause _cause)
	{
		//IL_0002: Unknown result type (might be due to invalid IL or missing references)
		//IL_0005: Invalid comparison between Unknown and I4
		//IL_0007: Unknown result type (might be due to invalid IL or missing references)
		//IL_000a: Invalid comparison between Unknown and I4
		string reason = null;
		if ((int)_cause != 17 && (int)_cause != 9)
		{
			reason = ((object)_cause/*cast due to constrained. prefix*/).ToString();
		}
		SceneHandoffCancel(reason);
	}

	internal void SceneHandoffCancel(string _reason)
	{
		//IL_00a2: Unknown result type (might be due to invalid IL or missing references)
		if (!SceneHandoffActive || SceneHandoffCancelling)
		{
			return;
		}
		sceneHandoffState = SceneHandoffState.Cancelling;
		if (sceneHandoffMultiplayer)
		{
			PhotonNetwork.AutomaticallySyncScene = false;
		}
		try
		{
			if (Object.op_Implicit((Object)(object)LevelGenerator.Instance))
			{
				LevelGenerator.Instance.GenerateCancel();
			}
			if (!string.IsNullOrEmpty(_reason))
			{
				string headerText = sceneHandoffHeader?.GetLocalizedString() ?? "Disconnected";
				string text = sceneHandoffCause?.GetLocalizedString() ?? "Cause:";
				string buttonText = sceneHandoffButton?.GetLocalizedString() ?? "Ok Dang";
				MenuManager.instance.PagePopUpScheduled(headerText, Color.red, "<b>" + text + "</b>\n" + _reason, buttonText, richText: true);
			}
		}
		finally
		{
			if (sceneHandoffMultiplayer)
			{
				LeavePhotonRoom();
			}
			else
			{
				GameManager.instance.SetGameMode(0);
				((MonoBehaviour)this).StartCoroutine(LeaveToMainMenu());
			}
		}
	}

	public void LeavePhotonRoom()
	{
		if (sessionLeaveState != SessionLeaveState.Idle)
		{
			return;
		}
		if (SceneHandoffActive && !SceneHandoffCancelling)
		{
			SceneHandoffCancel((string)null);
			return;
		}
		Debug.Log((object)"leaving photon");
		PhotonNetwork.Disconnect();
		SteamLobbyManager.instance?.LeaveLobby();
		GameManager.instance.SetGameMode(0);
		if ((SemiFunc.RunIsTutorial() || (SceneHandoffCancelling && sceneSwitchTutorial)) && Object.op_Implicit((Object)(object)TutorialDirector.instance))
		{
			TutorialDirector.instance.EndTutorial();
		}
		((MonoBehaviour)this).StartCoroutine(LeaveToMainMenu());
	}

	public IEnumerator LeaveToMainMenu()
	{
		if (sessionLeaveState == SessionLeaveState.Idle)
		{
			bool _loadMainDirectly = (Object)(object)levelCurrent == (Object)(object)levelSplashScreen && !SceneHandoffActive && !SemiFunc.IsMultiplayer();
			PhotonNetwork.SceneLoadScopeCancelPending();
			sessionLeaveState = SessionLeaveState.Waiting;
			while ((!SceneHandoffCancelling || sceneHandoffMultiplayer) && (int)PhotonNetwork.NetworkingClient.State != 14 && (int)PhotonNetwork.NetworkingClient.State != 0)
			{
				yield return null;
			}
			while (sceneHandoffNativePending)
			{
				yield return null;
			}
			Debug.Log((object)"Leave to Main Menu");
			if (SceneHandoffCancelling)
			{
				SemiFunc.OnSessionLeave();
			}
			else
			{
				SemiFunc.OnSceneSwitch(_gameOver: false, _leaveGame: true);
			}
			if (SceneHandoffCancelling && sceneHandoffMultiplayer)
			{
				PhotonNetwork.IsMessageQueueRunning = true;
			}
			sceneHandoffState = SceneHandoffState.Idle;
			sceneHandoffRoom = null;
			sessionLeaveState = SessionLeaveState.Loading;
			levelCurrent = levelMainMenu;
			SceneManager.LoadSceneAsync(_loadMainDirectly ? "Main" : "Reload");
			yield return null;
		}
	}

	public string MoonGetName(int _moonIndex)
	{
		if (_moonIndex - 1 >= 0 && moons.Count > _moonIndex - 1)
		{
			Moon moon = moons[_moonIndex - 1];
			return moon.localizedMoonName?.GetLocalizedString() ?? moon.moonName;
		}
		return "";
	}

	public List<Moon.MoonAttribute> MoonGetAttributes(int _moonIndex)
	{
		if (_moonIndex - 1 >= 0 && moons.Count > _moonIndex - 1)
		{
			return moons[_moonIndex - 1].moonAttributes;
		}
		return new List<Moon.MoonAttribute>();
	}

	public Texture MoonGetIcon(int _moonIndex)
	{
		if (_moonIndex - 1 >= 0 && moons.Count > _moonIndex - 1)
		{
			return moons[_moonIndex - 1].moonIcon;
		}
		return null;
	}

	public void UpdateMoonLevel()
	{
		moonLevelPrev = moonLevel;
		moonLevel = CalculateMoonLevel(levelsCompleted);
		if (moonLevel != moonLevelPrev && moons.Count >= moonLevel)
		{
			moonLevelChanged = true;
		}
	}

	public int CalculateMoonLevel(int _levelsCompleted)
	{
		return (_levelsCompleted + 1) / 5;
	}

	public void UpdateSteamRichPresence()
	{
		int num = DataDirector.instance.SettingValueFetch(DataDirector.Setting.RichPresence);
		int num2 = ((num == 2 && Debug.isDebugBuild) ? 1 : num);
		string text = "In Menu";
		string text2 = null;
		if ((Object)(object)levelCurrent == (Object)(object)levelMainMenu || (Object)(object)levelCurrent == (Object)(object)levelSplashScreen || SemiFunc.RunIsTutorial() || SemiFunc.RunIsLobbyMenu())
		{
			if (num == 2)
			{
				text2 = levelCurrent.NarrativeName;
			}
			if (SteamClient.IsValid)
			{
				string text3 = num2 switch
				{
					2 => levelCurrent.NarrativeName, 
					1 => text, 
					_ => null, 
				};
				SteamFriends.SetRichPresence("levelname", text3);
				SteamFriends.SetRichPresence("levelnum", (string)null);
				SteamFriends.SetRichPresence("steam_display", string.IsNullOrEmpty(text3) ? null : "#Status_LevelName");
			}
		}
		else
		{
			string text4 = (levelsCompleted + 1).ToString();
			if (num == 1)
			{
				text = "In Game";
			}
			else if (SemiFunc.RunIsArena())
			{
				text = "In Arena";
			}
			else if (SemiFunc.RunIsLobby())
			{
				text = "In Truck";
			}
			else
			{
				text = (SemiFunc.RunIsShop() ? "In Shop" : "In Game");
			}
			if (num == 2)
			{
				text2 = "Level " + text4;
				if (!Debug.isDebugBuild)
				{
					text2 = text2 + " - " + levelCurrent.NarrativeName;
				}
			}
			if (SteamClient.IsValid)
			{
				string text5 = num2 switch
				{
					2 => levelCurrent.NarrativeName, 
					1 => text, 
					_ => null, 
				};
				SteamFriends.SetRichPresence("levelname", text5);
				SteamFriends.SetRichPresence("levelnum", (num == 2) ? text4 : null);
				string text6;
				if (string.IsNullOrEmpty(text5))
				{
					text6 = null;
				}
				else
				{
					text6 = ((num == 2) ? "#Status_LevelNameNum" : "#Status_LevelName");
				}
				SteamFriends.SetRichPresence("steam_display", text6);
			}
		}
		DiscordManager.instance?.UpdateDiscordRichPresence(text, text2);
	}

	public void AllPlayersDeadSet(bool _set)
	{
		if (SemiFunc.IsMasterClientOrSingleplayer() && allPlayersDead != _set)
		{
			allPlayersDead = _set;
			if (GameManager.Multiplayer())
			{
				runManagerPUN.photonView.RPC("AllPlayersDeadRPC", (RpcTarget)4, new object[1] { allPlayersDead });
			}
		}
	}

	public void GameDirectorStart()
	{
		if (!SceneHandoffCancelling)
		{
			if (!SceneHandoffActive)
			{
				sessionLeaveState = SessionLeaveState.Idle;
				sceneSwitchCompleted = false;
				sceneSwitchTutorial = false;
			}
			runStarted = true;
			allPlayersDeadCheckDisabled = false;
			AllPlayersDeadSet(_set: false);
			cosmeticWorldObjectCooldown = Mathf.Max(60f, 60f * (float)ValuableDirector.instance.CosmeticWorldObjectLevelLoopsClampedGet());
		}
	}

	public RunManager()
	{
		//IL_002d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0032: Unknown result type (might be due to invalid IL or missing references)
	}
}
