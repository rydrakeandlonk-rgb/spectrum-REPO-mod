using System.Collections.Generic;
using System.Linq;
using Photon.Pun;
using UnityEngine;
using UnityEngine.Events;

public class PhysGrabObjectImpactDetector : MonoBehaviour, IPunObservable
{
	public enum ImpactState
	{
		None,
		Light,
		Medium,
		Heavy
	}

	public bool particleDisable;

	public bool particleBreakSmokeDisable;

	public bool hasFreezeFrameOnBreakParticles = true;

	[Range(0f, 4f)]
	public float particleMultiplier = 1f;

	[Space]
	public bool playerHurtDisable;

	public bool slidingDisable;

	internal bool impactDisable;

	public bool destroyInvestigate = true;

	public bool destroyDisable;

	internal int destroyDisableLaunches;

	internal float destroyDisableLaunchesTimer;

	internal bool destroyDisableTeleport = true;

	public bool indestructibleBreakEffects = true;

	public bool canHurtLogic = true;

	[HideInInspector]
	public PhysObjectParticles particles;

	private List<Transform> colliderTransforms = new List<Transform>();

	internal EnemyRigidbody enemyRigidbody;

	[HideInInspector]
	public bool isEnemy;

	internal float enemyInteractionTimer;

	private Rigidbody rb;

	private Materials.MaterialTrigger materialTrigger = new Materials.MaterialTrigger();

	[HideInInspector]
	public float fragility = 50f;

	[HideInInspector]
	public float durability = 100f;

	private float impactLevel1 = 300f;

	private float impactLevel2 = 400f;

	private float impactLevel3 = 500f;

	private float breakLevel1Cooldown;

	private float breakLevel2Cooldown;

	private float breakLevel3Cooldown;

	private float impactLightCooldown;

	private float impactMediumCooldown;

	private float impactHeavyCooldown;

	private Vector3 previousPosition;

	private Vector3 previousRotation;

	private Camera mainCamera;

	private float impactCooldown;

	internal bool isIndestructible;

	internal float impulseTimerDeactivateImpacts = 5f;

	internal float highestVelocity;

	internal float impactForce;

	internal float resetPrevPositionTimer;

	private PhysGrabObject physGrabObject;

	private MineCart mineCart;

	private float enemyInvestigateDisableTimer;

	private PhotonView photonView;

	internal bool isHinge;

	internal bool isBrokenHinge;

	private ValuableObject valuableObject;

	private NotValuableObject notValuableObject;

	private bool isNotValuable;

	private bool breakLogic;

	[HideInInspector]
	public bool isValuable;

	private bool collisionsActive;

	private float collisionsActiveTimer;

	private float collisionActivatedBuffer;

	[HideInInspector]
	public bool isSliding;

	private float slidingTimer;

	private float slidingGain;

	private float slidingSpeedThreshold = 0.1f;

	private float slidingAudioSpeed;

	private Vector3 previousSlidingPosition;

	internal Vector3 previousVelocity;

	internal Vector3 previousAngularVelocity;

	internal Vector3 previousVelocityRaw;

	internal Vector3 previousPreviousVelocityRaw;

	private bool impactHappened;

	internal float impactDisabledTimer;

	private Vector3 contactPoint;

	internal PhysAudio impactAudio;

	private float impactAudioPitch = 1f;

	internal float impactAudioPitchMultiplier = 1f;

	private float impactAudioPitchOverride = 1f;

	private float impactAudioPitchOverrideTimer;

	private bool audioActive;

	private float impactAudioOverrideDisableTimer;

	private float colliderVolume;

	private float timerInCart;

	private float timerInSafeArea;

	internal int breakLevelHeavy;

	internal int breakLevelMedium = 1;

	internal int breakLevelLight = 2;

	private Vector3 prevPos;

	private Quaternion prevRot;

	private bool isMoving;

	private float breakForce;

	private Vector3 originalPosition;

	private Quaternion originalRotation;

	public UnityEvent onAllImpacts;

	public UnityEvent onImpactLight;

	public UnityEvent onImpactMedium;

	public UnityEvent onImpactHeavy;

	[Space(15f)]
	public UnityEvent onAllBreaks;

	public UnityEvent onBreakLight;

	public UnityEvent onBreakMedium;

	public UnityEvent onBreakHeavy;

	[Space(15f)]
	public UnityEvent onDestroy;

	public UnityEvent onHurtColliderHit;

	internal Vector3 onHurtColliderHitForce;

	internal Vector3 onHurtColliderHitTorque;

	[HideInInspector]
	public bool inCart;

	private bool inCartPrevious;

	[HideInInspector]
	public bool isCart;

	internal PhysGrabCart cart;

	private float inCartVolumeMultiplier;

	private float impactCheckTimer;

	internal PhysGrabCart currentCart;

	internal PhysGrabCart currentCartPrev;

	internal float indestructibleSpawnTimer = 5f;

	internal bool isColliding;

	internal float isCollidingTimer;

	[HideInInspector]
	public float fragilityMultiplier = 1f;

	[HideInInspector]
	public float impactFragilityMultiplier = 1f;

	private float playerHurtMultiplier = 1f;

	private float playerHurtMultiplierTimer;

	[Space(15f)]
	public bool centerPointNeedsToBeInsideCart;

	internal Vector3 centerPoint = Vector3.zero;

	private bool playerHitDisable;

	private float playerHitDisableTimer;

	private float ImpactAudioPitch => impactAudioPitch * impactAudioPitchMultiplier * ((impactAudioPitchOverrideTimer > 0f) ? impactAudioPitchOverride : 1f);

	private void Awake()
	{
		photonView = ((Component)this).GetComponent<PhotonView>();
		physGrabObject = ((Component)this).GetComponent<PhysGrabObject>();
		mineCart = ((Component)this).GetComponent<MineCart>();
		rb = ((Component)this).GetComponent<Rigidbody>();
	}

	private void Start()
	{
		//IL_0066: Unknown result type (might be due to invalid IL or missing references)
		//IL_006b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0097: Unknown result type (might be due to invalid IL or missing references)
		//IL_009c: Unknown result type (might be due to invalid IL or missing references)
		//IL_01f5: Unknown result type (might be due to invalid IL or missing references)
		//IL_01fa: Unknown result type (might be due to invalid IL or missing references)
		//IL_022b: Unknown result type (might be due to invalid IL or missing references)
		//IL_02aa: Unknown result type (might be due to invalid IL or missing references)
		//IL_02af: Unknown result type (might be due to invalid IL or missing references)
		//IL_02bb: Unknown result type (might be due to invalid IL or missing references)
		//IL_02c0: Unknown result type (might be due to invalid IL or missing references)
		//IL_02f2: Unknown result type (might be due to invalid IL or missing references)
		//IL_02f7: Unknown result type (might be due to invalid IL or missing references)
		inCartVolumeMultiplier = 0.6f;
		if (Object.op_Implicit((Object)(object)((Component)this).GetComponent<PhysGrabHinge>()))
		{
			isHinge = true;
		}
		cart = ((Component)this).GetComponent<PhysGrabCart>();
		if (Object.op_Implicit((Object)(object)cart))
		{
			isCart = true;
		}
		enemyRigidbody = ((Component)this).GetComponent<EnemyRigidbody>();
		if (Object.op_Implicit((Object)(object)enemyRigidbody))
		{
			isEnemy = true;
		}
		previousSlidingPosition = ((Component)this).transform.position;
		valuableObject = ((Component)this).GetComponent<ValuableObject>();
		Transform val = ((Component)this).transform.Find("ForceCenterPoint");
		if (Object.op_Implicit((Object)(object)val))
		{
			centerPoint = val.position;
		}
		if (Object.op_Implicit((Object)(object)valuableObject))
		{
			isValuable = true;
			breakLogic = true;
			fragility = valuableObject.durabilityPreset.fragility;
			durability = valuableObject.durabilityPreset.durability;
			impactAudio = valuableObject.audioPreset;
			impactAudioPitch = valuableObject.audioPresetPitch;
		}
		else
		{
			notValuableObject = ((Component)this).GetComponent<NotValuableObject>();
			isNotValuable = true;
			if (Object.op_Implicit((Object)(object)notValuableObject))
			{
				if (Object.op_Implicit((Object)(object)notValuableObject.durabilityPreset))
				{
					breakLogic = true;
					fragility = notValuableObject.durabilityPreset.fragility;
					durability = notValuableObject.durabilityPreset.durability;
				}
				impactAudio = notValuableObject.audioPreset;
				impactAudioPitch = notValuableObject.audioPresetPitch;
			}
		}
		if (Object.op_Implicit((Object)(object)impactAudio))
		{
			audioActive = true;
		}
		else
		{
			audioActive = false;
		}
		mainCamera = Camera.main;
		ColliderGet(((Component)this).transform);
		colliderVolume /= 200000f;
		GameObject val2 = Object.Instantiate<GameObject>(Resources.Load<GameObject>("Phys Object Particles"), new Vector3(0f, 0f, 0f), Quaternion.identity);
		val2.transform.parent = ((Component)this).transform;
		val2.transform.localPosition = new Vector3(0f, 0f, 0f);
		particles = val2.GetComponent<PhysObjectParticles>();
		particles.multiplier = 1f;
		if (isValuable)
		{
			particles.gradient = valuableObject.particleColors;
		}
		if (Object.op_Implicit((Object)(object)notValuableObject))
		{
			particles.gradient = notValuableObject.particleColors;
		}
		particles.colliderTransforms = colliderTransforms;
		originalPosition = rb.position;
		originalRotation = rb.rotation;
		materialTrigger.OverrideLayerMask = true;
		materialTrigger.LayerMask = LayerMask.op_Implicit(LayerMask.GetMask(new string[2] { "Default", "PlayerOnlyCollision" }));
	}

	private void ColliderGet(Transform transform)
	{
		//IL_0034: Unknown result type (might be due to invalid IL or missing references)
		//IL_0039: Unknown result type (might be due to invalid IL or missing references)
		//IL_003c: Unknown result type (might be due to invalid IL or missing references)
		//IL_004e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0061: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a5: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ab: Expected Obj, but got Unknown
		if (((Component)transform).CompareTag("Phys Grab Object") && Object.op_Implicit((Object)(object)((Component)transform).GetComponent<Collider>()))
		{
			colliderTransforms.Add(transform);
			Bounds bounds = ((Component)((Component)transform).transform).GetComponent<Collider>().bounds;
			float num = bounds.size.x * 100f * (bounds.size.y * 100f) * (bounds.size.z * 100f);
			if (Object.op_Implicit((Object)(object)((Component)transform).GetComponent<SphereCollider>()))
			{
				num *= 0.55f;
			}
			colliderVolume += num;
		}
		foreach (Transform item in transform)
		{
			Transform transform2 = item;
			ColliderGet(transform2);
		}
	}

	[PunRPC]
	private void InCartRPC(bool inCartState, PhotonMessageInfo _info = default(PhotonMessageInfo))
	{
		//IL_0000: Unknown result type (might be due to invalid IL or missing references)
		if (SemiFunc.MasterOnlyRPC(_info))
		{
			inCart = inCartState;
		}
	}

	private void IndestructibleSpawnTimer()
	{
		if (indestructibleSpawnTimer > 0f)
		{
			physGrabObject.OverrideIndestructible();
			if (LevelGenerator.Instance.Generated)
			{
				indestructibleSpawnTimer -= Time.deltaTime;
			}
		}
	}

	private void OnDisable()
	{
		enemyInvestigateDisableTimer = 0f;
	}

	private void Update()
	{
		//IL_020a: Unknown result type (might be due to invalid IL or missing references)
		//IL_020f: Unknown result type (might be due to invalid IL or missing references)
		//IL_012b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0130: Unknown result type (might be due to invalid IL or missing references)
		//IL_0143: Unknown result type (might be due to invalid IL or missing references)
		//IL_0148: Unknown result type (might be due to invalid IL or missing references)
		//IL_0155: Unknown result type (might be due to invalid IL or missing references)
		//IL_0156: Unknown result type (might be due to invalid IL or missing references)
		//IL_0157: Unknown result type (might be due to invalid IL or missing references)
		//IL_015c: Unknown result type (might be due to invalid IL or missing references)
		//IL_01a9: Unknown result type (might be due to invalid IL or missing references)
		//IL_0269: Unknown result type (might be due to invalid IL or missing references)
		//IL_026e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0284: Unknown result type (might be due to invalid IL or missing references)
		//IL_0289: Unknown result type (might be due to invalid IL or missing references)
		//IL_0459: Unknown result type (might be due to invalid IL or missing references)
		//IL_045e: Unknown result type (might be due to invalid IL or missing references)
		OverrideEnemyInvestigateDisableTick();
		IndestructibleSpawnTimer();
		if (GameManager.instance.gameMode == 1 && !PhotonNetwork.IsMasterClient)
		{
			return;
		}
		if (inCartPrevious != inCart)
		{
			inCartPrevious = inCart;
			if (GameManager.instance.gameMode == 1)
			{
				photonView.RPC("InCartRPC", (RpcTarget)1, new object[1] { inCart });
			}
		}
		bool flag = false;
		if (timerInCart > 0f)
		{
			flag = true;
			timerInCart -= Time.deltaTime;
		}
		else if (Object.op_Implicit((Object)(object)currentCart))
		{
			currentCartPrev = currentCart;
			currentCart = null;
		}
		if (timerInSafeArea > 0f)
		{
			flag = true;
			timerInSafeArea -= Time.deltaTime;
		}
		inCart = flag;
		if (isValuable && !valuableObject.dollarValueSet)
		{
			return;
		}
		if (isCollidingTimer > 0f)
		{
			isColliding = true;
			isCollidingTimer -= Time.deltaTime;
		}
		else
		{
			isColliding = false;
		}
		Vector3 val2;
		if (isSliding)
		{
			Vector3 val = previousSlidingPosition;
			val.y = 0f;
			Vector3 position = ((Component)this).transform.position;
			position.y = 0f;
			val2 = position - val;
			float num = val2.magnitude / Time.deltaTime;
			if (num >= slidingSpeedThreshold)
			{
				slidingAudioSpeed = Mathf.Lerp(slidingAudioSpeed, 1f + num * 0.01f, 10f * Time.deltaTime);
				Materials.Instance.SlideLoop(rb.worldCenterOfMass, materialTrigger, 1f, 1f + slidingAudioSpeed);
			}
			if (GameManager.instance.gameMode == 0 || PhotonNetwork.IsMasterClient)
			{
				slidingTimer -= Time.deltaTime;
				if (slidingTimer < 0f)
				{
					isSliding = false;
				}
			}
		}
		previousSlidingPosition = ((Component)this).transform.position;
		if (playerHurtMultiplierTimer > 0f)
		{
			playerHurtMultiplierTimer -= Time.deltaTime;
			if (playerHurtMultiplierTimer <= 0f)
			{
				playerHurtMultiplier = 1f;
			}
		}
		if (physGrabObject.grabbed)
		{
			collisionsActiveTimer = 0.5f;
		}
		val2 = rb.linearVelocity;
		if (!(val2.magnitude > 0.01f))
		{
			val2 = rb.angularVelocity;
			if (!(val2.magnitude > 0.1f))
			{
				goto IL_02a4;
			}
		}
		collisionsActiveTimer = 0.5f;
		goto IL_02a4;
		IL_02a4:
		if (collisionsActiveTimer > 0f)
		{
			if (!collisionsActive)
			{
				collisionActivatedBuffer = 0.1f;
			}
			collisionsActive = true;
			collisionsActiveTimer -= Time.deltaTime;
		}
		else
		{
			collisionsActive = false;
		}
		if (collisionActivatedBuffer > 0f)
		{
			collisionActivatedBuffer -= Time.deltaTime;
		}
		if (playerHitDisableTimer > 0f)
		{
			playerHitDisableTimer -= Time.deltaTime;
		}
		else if (playerHitDisable)
		{
			playerHitDisable = false;
			physGrabObject.PhysRidingDisabledSet(_state: false);
		}
		if (breakLevel1Cooldown > 0f)
		{
			breakLevel1Cooldown -= Time.deltaTime;
		}
		if (breakLevel2Cooldown > 0f)
		{
			breakLevel2Cooldown -= Time.deltaTime;
		}
		if (breakLevel3Cooldown > 0f)
		{
			breakLevel3Cooldown -= Time.deltaTime;
		}
		if (impactLightCooldown > 0f)
		{
			impactLightCooldown -= Time.deltaTime;
		}
		if (impactMediumCooldown > 0f)
		{
			impactMediumCooldown -= Time.deltaTime;
		}
		if (impactHeavyCooldown > 0f)
		{
			impactHeavyCooldown -= Time.deltaTime;
		}
		if (impactCooldown > 0f)
		{
			impactCooldown -= Time.deltaTime;
		}
		if (impulseTimerDeactivateImpacts > 0f)
		{
			impulseTimerDeactivateImpacts -= Time.deltaTime;
		}
		if (resetPrevPositionTimer > 0f)
		{
			resetPrevPositionTimer -= Time.deltaTime;
			previousPosition = Vector3.zero;
		}
		if (enemyInteractionTimer > 0f)
		{
			enemyInteractionTimer -= Time.deltaTime;
		}
		if (destroyDisableLaunchesTimer > 0f)
		{
			destroyDisableLaunchesTimer -= Time.deltaTime;
			if (destroyDisableLaunchesTimer <= 0f)
			{
				destroyDisableLaunches = 0;
			}
		}
	}

	private void FixedUpdate()
	{
		//IL_01a0: Unknown result type (might be due to invalid IL or missing references)
		//IL_01aa: Unknown result type (might be due to invalid IL or missing references)
		//IL_01af: Unknown result type (might be due to invalid IL or missing references)
		//IL_01b6: Unknown result type (might be due to invalid IL or missing references)
		//IL_01c0: Unknown result type (might be due to invalid IL or missing references)
		//IL_01c5: Unknown result type (might be due to invalid IL or missing references)
		//IL_0204: Unknown result type (might be due to invalid IL or missing references)
		//IL_020f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0214: Unknown result type (might be due to invalid IL or missing references)
		//IL_0216: Unknown result type (might be due to invalid IL or missing references)
		//IL_0221: Unknown result type (might be due to invalid IL or missing references)
		//IL_022c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0231: Unknown result type (might be due to invalid IL or missing references)
		//IL_0233: Unknown result type (might be due to invalid IL or missing references)
		//IL_039c: Unknown result type (might be due to invalid IL or missing references)
		//IL_03a1: Unknown result type (might be due to invalid IL or missing references)
		//IL_03ad: Unknown result type (might be due to invalid IL or missing references)
		//IL_03b2: Unknown result type (might be due to invalid IL or missing references)
		//IL_03be: Unknown result type (might be due to invalid IL or missing references)
		//IL_03c8: Unknown result type (might be due to invalid IL or missing references)
		//IL_03cd: Unknown result type (might be due to invalid IL or missing references)
		//IL_03d9: Unknown result type (might be due to invalid IL or missing references)
		//IL_03e3: Unknown result type (might be due to invalid IL or missing references)
		//IL_03e8: Unknown result type (might be due to invalid IL or missing references)
		//IL_03ee: Unknown result type (might be due to invalid IL or missing references)
		//IL_03f9: Unknown result type (might be due to invalid IL or missing references)
		//IL_040b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0416: Unknown result type (might be due to invalid IL or missing references)
		//IL_0435: Unknown result type (might be due to invalid IL or missing references)
		//IL_043a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0446: Unknown result type (might be due to invalid IL or missing references)
		//IL_044b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0097: Unknown result type (might be due to invalid IL or missing references)
		//IL_009c: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a9: Unknown result type (might be due to invalid IL or missing references)
		//IL_00af: Unknown result type (might be due to invalid IL or missing references)
		//IL_00bf: Unknown result type (might be due to invalid IL or missing references)
		//IL_00cf: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d9: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ed: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f7: Unknown result type (might be due to invalid IL or missing references)
		//IL_0103: Unknown result type (might be due to invalid IL or missing references)
		//IL_010d: Unknown result type (might be due to invalid IL or missing references)
		if (GameManager.instance.gameMode == 1 && !PhotonNetwork.IsMasterClient)
		{
			return;
		}
		if (inCart && !isEnemy && physGrabObject.playerGrabbing.Count == 0 && Object.op_Implicit((Object)(object)currentCart) && !rb.isKinematic && !Object.op_Implicit((Object)(object)((Component)this).GetComponent<PlayerTumble>()))
		{
			PhysGrabCart component = ((Component)currentCart).GetComponent<PhysGrabCart>();
			if (component.actualVelocity.magnitude > 1f)
			{
				Vector3 linearVelocity = rb.linearVelocity;
				rb.linearVelocity = Vector3.Lerp(rb.linearVelocity, component.actualVelocity, 30f * Time.fixedDeltaTime);
				if (rb.linearVelocity.y > linearVelocity.y)
				{
					rb.linearVelocity = new Vector3(rb.linearVelocity.x, linearVelocity.y, rb.linearVelocity.z);
				}
			}
		}
		impactHappened = false;
		breakForce = 0f;
		impactForce = 0f;
		if (impactAudioOverrideDisableTimer > 0f)
		{
			impactAudioOverrideDisableTimer -= Time.fixedDeltaTime;
		}
		if (impactAudioPitchOverrideTimer > 0f)
		{
			impactAudioPitchOverrideTimer -= Time.fixedDeltaTime;
		}
		if (impactDisable)
		{
			impactDisabledTimer = 0f;
		}
		else if (impactDisabledTimer <= 0f)
		{
			Vector3 val = rb.linearVelocity / Time.fixedDeltaTime;
			Vector3 val2 = rb.angularVelocity / Time.fixedDeltaTime;
			float magnitude = previousVelocity.magnitude;
			float num = Mathf.Abs(magnitude - val.magnitude);
			float magnitude2 = previousAngularVelocity.magnitude;
			float num2 = Mathf.Abs(magnitude2 - val2.magnitude);
			Vector3 normalized = val.normalized;
			Vector3 normalized2 = previousVelocity.normalized;
			float num3 = Vector3.Angle(normalized, normalized2);
			Vector3 normalized3 = val2.normalized;
			Vector3 normalized4 = previousAngularVelocity.normalized;
			float num4 = Vector3.Angle(normalized3, normalized4);
			num *= 1f;
			num2 *= 0.4f * rb.mass;
			num3 *= 0.2f;
			num4 *= 0.02f * rb.mass;
			if ((num > 1f && magnitude > 1f) || (num2 > 1f && magnitude2 > 1f) || (num3 > 1f && magnitude > 1f) || (num4 > 1f && magnitude2 > 1f))
			{
				impactHappened = true;
				float num5 = num * 2f;
				float num6 = Mathf.Max(rb.mass, 1f);
				breakForce += num5 * num6;
			}
			breakForce *= 8f;
			impactForce = breakForce / 8f * impactFragilityMultiplier;
			breakForce = breakForce * (fragility / 100f) * fragilityMultiplier;
			if (impactHappened)
			{
				if (inCart)
				{
					breakForce = 0f;
				}
				if (inCart || isCart)
				{
					impactForce *= 0.3f;
				}
			}
		}
		else
		{
			impactDisabledTimer -= Time.fixedDeltaTime;
		}
		previousPreviousVelocityRaw = previousVelocityRaw;
		previousVelocityRaw = rb.linearVelocity;
		previousVelocity = rb.linearVelocity / Time.fixedDeltaTime;
		previousAngularVelocity = rb.angularVelocity / Time.fixedDeltaTime;
		if (Vector3.Distance(prevPos, ((Component)this).transform.position) > 0.01f || Quaternion.Angle(prevRot, ((Component)this).transform.rotation) > 0.1f)
		{
			isMoving = true;
		}
		prevPos = ((Component)this).transform.position;
		prevRot = ((Component)this).transform.rotation;
	}

	public void ImpactDisable(float time)
	{
		impactDisabledTimer = time;
	}

	public void OverrideImpactAudioDisable(float time)
	{
		impactAudioOverrideDisableTimer = time;
	}

	public void OverrideImpactAudioPitch(float pitch, float time = 0.1f)
	{
		impactAudioPitchOverride = pitch;
		impactAudioPitchOverrideTimer = time;
	}

	private bool ImpactAudioActive()
	{
		if (audioActive)
		{
			return impactAudioOverrideDisableTimer <= 0f;
		}
		return false;
	}

	public void OverrideEnemyInvestigateDisable(float time = 0.1f)
	{
		enemyInvestigateDisableTimer = Mathf.Max(enemyInvestigateDisableTimer, time);
	}

	private void OverrideEnemyInvestigateDisableTick()
	{
		if (Object.op_Implicit((Object)(object)physGrabObject) && physGrabObject.playerGrabbing.Count > 0)
		{
			enemyInvestigateDisableTimer = 0f;
		}
		if (enemyInvestigateDisableTimer > 0f)
		{
			enemyInvestigateDisableTimer = Mathf.Max(0f, enemyInvestigateDisableTimer - Time.deltaTime);
		}
	}

	private float EnemyInvestigateDisableTimeGet()
	{
		if (Object.op_Implicit((Object)(object)mineCart) && mineCart.EnemyInvestigateBlocked())
		{
			return 2f;
		}
		if (Object.op_Implicit((Object)(object)physGrabObject) && physGrabObject.playerGrabbing.Count > 0)
		{
			return 0f;
		}
		return enemyInvestigateDisableTimer;
	}

	public void EnemyInvestigate(float radius)
	{
		//IL_0008: Unknown result type (might be due to invalid IL or missing references)
		EnemyInvestigate(radius, ((Component)this).transform.position);
	}

	internal void EnemyInvestigate(float radius, Vector3 position)
	{
		//IL_0051: Unknown result type (might be due to invalid IL or missing references)
		//IL_0044: Unknown result type (might be due to invalid IL or missing references)
		if (!(physGrabObject.enemyInteractTimer > 0f) && !inCart && !isCart && !(EnemyInvestigateDisableTimeGet() > 0f))
		{
			if (Object.op_Implicit((Object)(object)mineCart))
			{
				mineCart.EnemyInvestigate(position, radius);
			}
			else
			{
				EnemyDirector.instance.SetInvestigate(position, radius);
			}
		}
	}

	public void DestroyObject(bool effects = true, bool forced = false)
	{
		//IL_0046: Unknown result type (might be due to invalid IL or missing references)
		//IL_008f: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a4: Unknown result type (might be due to invalid IL or missing references)
		//IL_00aa: Unknown result type (might be due to invalid IL or missing references)
		if ((destroyDisable && !forced) || !SemiFunc.IsMasterClientOrSingleplayer())
		{
			return;
		}
		EnemyRigidbody component = ((Component)this).GetComponent<EnemyRigidbody>();
		if (Object.op_Implicit((Object)(object)component))
		{
			if (component.enemy.HasHealth)
			{
				component.enemy.Health.Hurt(999999, physGrabObject.centerPoint);
			}
			else
			{
				component.enemy.EnemyParent.Despawn();
			}
		}
		else if (!physGrabObject.dead)
		{
			physGrabObject.dead = true;
			if (destroyInvestigate)
			{
				EnemyInvestigate(15f, physGrabObject.centerPoint);
			}
			if (!SemiFunc.IsMultiplayer())
			{
				DestroyObjectRPC(effects);
			}
			else if (SemiFunc.IsMasterClient())
			{
				photonView.RPC("DestroyObjectRPC", (RpcTarget)0, new object[1] { effects });
			}
		}
	}

	[PunRPC]
	public void DestroyObjectRPC(bool effects, PhotonMessageInfo _info = default(PhotonMessageInfo))
	{
		//IL_0000: Unknown result type (might be due to invalid IL or missing references)
		//IL_0037: Unknown result type (might be due to invalid IL or missing references)
		//IL_006a: Unknown result type (might be due to invalid IL or missing references)
		//IL_006f: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d4: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a2: Unknown result type (might be due to invalid IL or missing references)
		//IL_0095: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a7: Unknown result type (might be due to invalid IL or missing references)
		if (!SemiFunc.MasterOnlyRPC(_info))
		{
			return;
		}
		physGrabObject.dead = true;
		if (effects)
		{
			GameDirector.instance.CameraImpact.ShakeDistance(10f, 1f, 6f, ((Component)this).transform.position, 0.1f);
		}
		if (Object.op_Implicit((Object)(object)particles))
		{
			particles.particleSystemSmokeDisable = particleBreakSmokeDisable;
			Vector3 localScale = ((Component)this).transform.localScale;
			((Component)particles).transform.parent = null;
			particles.DestroyParticles(Object.op_Implicit((Object)(object)rb) ? rb.linearVelocity : previousVelocityRaw, localScale, hasFreezeFrameOnBreakParticles);
		}
		if (ImpactAudioActive() & effects)
		{
			AudioSource val = impactAudio.destroy.Play(((Component)this).transform, physGrabObject.centerPoint);
			if (Object.op_Implicit((Object)(object)val))
			{
				val.pitch *= ImpactAudioPitch;
			}
		}
		onDestroy.Invoke();
	}

	public void BreakHeavy(Vector3 contactPoint, bool _forceBreak = false, float minimumValue = 0f)
	{
		//IL_009d: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d8: Unknown result type (might be due to invalid IL or missing references)
		float num = 0.1f * (1f + 9f * (100f - durability) / 100f);
		bool flag = false;
		if (isValuable || breakLogic)
		{
			float valueLost = 0f;
			if (isValuable)
			{
				valueLost = Mathf.Round(valuableObject.dollarValueOriginal * num);
				valueLost += Mathf.Round(Random.Range((0f - valueLost) * 0.1f, valueLost * 0.1f));
				if (minimumValue != 0f)
				{
					valueLost = Mathf.Max(valueLost, minimumValue);
				}
				valueLost = Mathf.Clamp(valueLost, 1f, valuableObject.dollarValueCurrent);
			}
			Break(valueLost, contactPoint, breakLevelHeavy, _forceBreak);
			flag = true;
		}
		if (isNotValuable && notValuableObject.hasHealth)
		{
			notValuableObject.Impact(ImpactState.Heavy);
			flag = true;
		}
		if (flag)
		{
			EnemyInvestigate(10f, contactPoint);
		}
		breakLevel3Cooldown = 0.6f;
		breakLevel2Cooldown = 0.4f;
		breakLevel1Cooldown = 0.3f;
	}

	public void BreakMedium(Vector3 contactPoint, bool _forceBreak = false)
	{
		//IL_008d: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c8: Unknown result type (might be due to invalid IL or missing references)
		float num = 0.05f * (1f + 9f * (100f - durability) / 100f);
		bool flag = false;
		if (isValuable || breakLogic)
		{
			float valueLost = 0f;
			if (isValuable)
			{
				valueLost = Mathf.Round(valuableObject.dollarValueOriginal * num);
				valueLost += Mathf.Round(Random.Range((0f - valueLost) * 0.1f, valueLost * 0.1f));
				valueLost = Mathf.Clamp(valueLost, 0f, valuableObject.dollarValueCurrent);
			}
			Break(valueLost, contactPoint, breakLevelMedium, _forceBreak);
			flag = true;
		}
		if (isNotValuable && notValuableObject.hasHealth)
		{
			notValuableObject.Impact(ImpactState.Medium);
			flag = true;
		}
		if (flag)
		{
			EnemyInvestigate(5f, contactPoint);
		}
		breakLevel2Cooldown = 0.4f;
		breakLevel1Cooldown = 0.3f;
	}

	public void BreakLight(Vector3 contactPoint, bool _forceBreak = false)
	{
		//IL_008d: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c8: Unknown result type (might be due to invalid IL or missing references)
		float num = 0.01f * (1f + 9f * (100f - durability) / 100f);
		bool flag = false;
		if (isValuable || breakLogic)
		{
			float valueLost = 0f;
			if (isValuable)
			{
				valueLost = Mathf.Round(valuableObject.dollarValueOriginal * num);
				valueLost += Mathf.Round(Random.Range((0f - valueLost) * 0.1f, valueLost * 0.1f));
				valueLost = Mathf.Clamp(valueLost, 0f, valuableObject.dollarValueCurrent);
			}
			Break(valueLost, contactPoint, breakLevelLight, _forceBreak);
			flag = true;
		}
		if (isNotValuable && notValuableObject.hasHealth)
		{
			notValuableObject.Impact(ImpactState.Light);
			flag = true;
		}
		if (flag)
		{
			EnemyInvestigate(3f, contactPoint);
		}
		breakLevel1Cooldown = 0.3f;
	}

	internal void Break(float valueLost, Vector3 _contactPoint, int breakLevel, bool _forceBreak = false)
	{
		//IL_005d: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0033: Unknown result type (might be due to invalid IL or missing references)
		//IL_0039: Unknown result type (might be due to invalid IL or missing references)
		bool flag = false;
		if (isValuable && (_forceBreak || (!isIndestructible && !destroyDisable)))
		{
			flag = true;
		}
		if (GameManager.instance.gameMode == 0)
		{
			BreakRPC(valueLost, _contactPoint, breakLevel, flag);
			return;
		}
		photonView.RPC("BreakRPC", (RpcTarget)0, new object[4] { valueLost, _contactPoint, breakLevel, flag });
	}

	private void HealLogic(float healAmount, Vector3 healingPoint)
	{
		valuableObject.dollarValueCurrent += Mathf.Floor(healAmount);
		valuableObject.dollarValueCurrent = Mathf.Clamp(valuableObject.dollarValueCurrent, 0f, valuableObject.dollarValueOriginal);
	}

	public float Heal(float healPercent, Vector3 healingPoint)
	{
		//IL_00c3: Unknown result type (might be due to invalid IL or missing references)
		//IL_0078: Unknown result type (might be due to invalid IL or missing references)
		float result = 0f;
		if (isValuable)
		{
			if (GameManager.Multiplayer())
			{
				if (PhotonNetwork.IsMasterClient)
				{
					float num = valuableObject.dollarValueOriginal * healPercent;
					num = Mathf.Clamp(num, 0f, valuableObject.dollarValueOriginal - valuableObject.dollarValueCurrent);
					if (num > 0f)
					{
						photonView.RPC("HealRPC", (RpcTarget)0, new object[2] { num, healingPoint });
					}
					result = num;
				}
			}
			else
			{
				float num2 = valuableObject.dollarValueOriginal * healPercent;
				num2 = Mathf.Clamp(num2, 0f, valuableObject.dollarValueOriginal - valuableObject.dollarValueCurrent);
				if (num2 > 0f)
				{
					HealLogic(num2, healingPoint);
				}
				result = num2;
			}
		}
		return result;
	}

	public void PlayerHitDisableSet()
	{
		if (!playerHitDisable)
		{
			physGrabObject.PhysRidingDisabledSet(_state: true);
			playerHitDisable = true;
		}
		playerHitDisableTimer = 0.5f;
	}

	[PunRPC]
	private void HealRPC(float healAmount, Vector3 healingPoint, PhotonMessageInfo _info = default(PhotonMessageInfo))
	{
		//IL_0000: Unknown result type (might be due to invalid IL or missing references)
		//IL_000b: Unknown result type (might be due to invalid IL or missing references)
		if (SemiFunc.MasterOnlyRPC(_info))
		{
			HealLogic(healAmount, healingPoint);
		}
	}

	private void ResetObject()
	{
		//IL_0095: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a5: Unknown result type (might be due to invalid IL or missing references)
		//IL_00cc: Unknown result type (might be due to invalid IL or missing references)
		//IL_00dd: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ee: Unknown result type (might be due to invalid IL or missing references)
		//IL_0103: Unknown result type (might be due to invalid IL or missing references)
		//IL_012a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0145: Unknown result type (might be due to invalid IL or missing references)
		//IL_014a: Unknown result type (might be due to invalid IL or missing references)
		//IL_014f: Unknown result type (might be due to invalid IL or missing references)
		//IL_015a: Unknown result type (might be due to invalid IL or missing references)
		//IL_015b: Unknown result type (might be due to invalid IL or missing references)
		//IL_016a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0174: Unknown result type (might be due to invalid IL or missing references)
		foreach (PhysGrabber item in physGrabObject.playerGrabbing.ToList())
		{
			if (!SemiFunc.IsMultiplayer())
			{
				item.ReleaseObject(photonView.ViewID);
			}
			else if (SemiFunc.IsMasterClient() && Object.op_Implicit((Object)(object)item.photonView) && item.photonView.Owner != null)
			{
				item.OverrideGrabRelease(photonView.ViewID, 0.1f);
			}
		}
		rb.linearVelocity = Vector3.zero;
		rb.angularVelocity = Vector3.zero;
		valuableObject.dollarValueCurrent = valuableObject.dollarValueOriginal;
		rb.position = originalPosition;
		rb.rotation = originalRotation;
		((Component)this).transform.position = originalPosition;
		AssetManager.instance.soundUnequip.Play(originalPosition);
		BreakEffect(breakLevelLight, originalPosition);
		Vector3 val = ((Component)physGrabObject).transform.TransformPoint(physGrabObject.midPointOffset);
		Object.Instantiate<GameObject>(AssetManager.instance.prefabTeleportEffect, val, Quaternion.identity).transform.localScale = Vector3.one * 2f;
	}

	[PunRPC]
	private void BreakRPC(float valueLost, Vector3 _contactPoint, int breakLevel, bool _loseValue, PhotonMessageInfo _info = default(PhotonMessageInfo))
	{
		//IL_0000: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d9: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c6: Unknown result type (might be due to invalid IL or missing references)
		//IL_01b9: Unknown result type (might be due to invalid IL or missing references)
		//IL_009f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0092: Unknown result type (might be due to invalid IL or missing references)
		//IL_00aa: Unknown result type (might be due to invalid IL or missing references)
		if (!SemiFunc.MasterOnlyRPC(_info))
		{
			return;
		}
		if (_loseValue)
		{
			if (Object.op_Implicit((Object)(object)valuableObject))
			{
				float dollarValueCurrent = valuableObject.dollarValueCurrent;
				valuableObject.dollarValueCurrent -= valueLost;
				bool flag = false;
				if (valuableObject.dollarValueCurrent < valuableObject.dollarValueOriginal * 0.15f)
				{
					if (!SemiFunc.RunIsTutorial())
					{
						DestroyObject();
					}
					else
					{
						if (Object.op_Implicit((Object)(object)particles))
						{
							particles.DestroyParticles(Object.op_Implicit((Object)(object)rb) ? rb.linearVelocity : previousVelocityRaw, ((Component)this).transform.localScale, hasFreezeFrameOnBreakParticles);
						}
						ResetObject();
						ImpactHeavy(1000f, _contactPoint);
					}
					flag = true;
				}
				if (flag)
				{
					valueLost = dollarValueCurrent;
				}
			}
			WorldSpaceUIParent.instance.ValueLostCreate(_contactPoint, (int)valueLost);
		}
		if (_loseValue || !Object.op_Implicit((Object)(object)valuableObject))
		{
			onAllBreaks.Invoke();
		}
		if (breakLevel == breakLevelHeavy)
		{
			if (_loseValue || !Object.op_Implicit((Object)(object)valuableObject))
			{
				onBreakHeavy.Invoke();
			}
			if (Object.op_Implicit((Object)(object)physGrabObject))
			{
				physGrabObject.heavyBreakImpulse = false;
			}
		}
		if (breakLevel == breakLevelMedium)
		{
			if (_loseValue || !Object.op_Implicit((Object)(object)valuableObject))
			{
				onBreakMedium.Invoke();
			}
			if (Object.op_Implicit((Object)(object)physGrabObject))
			{
				physGrabObject.mediumBreakImpulse = false;
			}
		}
		if (breakLevel == breakLevelLight)
		{
			if (_loseValue || !Object.op_Implicit((Object)(object)valuableObject))
			{
				onBreakLight.Invoke();
			}
			if (Object.op_Implicit((Object)(object)physGrabObject))
			{
				physGrabObject.lightBreakImpulse = false;
			}
		}
		BreakEffect(breakLevel, _contactPoint);
	}

	public void BreakEffect(int breakLevel, Vector3 contactPoint)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_00de: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ea: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ab: Unknown result type (might be due to invalid IL or missing references)
		//IL_0062: Unknown result type (might be due to invalid IL or missing references)
		//IL_019f: Unknown result type (might be due to invalid IL or missing references)
		//IL_01ab: Unknown result type (might be due to invalid IL or missing references)
		//IL_016c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0123: Unknown result type (might be due to invalid IL or missing references)
		//IL_0260: Unknown result type (might be due to invalid IL or missing references)
		//IL_026c: Unknown result type (might be due to invalid IL or missing references)
		//IL_022d: Unknown result type (might be due to invalid IL or missing references)
		//IL_01e4: Unknown result type (might be due to invalid IL or missing references)
		if (!particleDisable && Object.op_Implicit((Object)(object)particles) && !particleBreakSmokeDisable)
		{
			particles.ImpactSmoke(5, contactPoint, colliderVolume);
		}
		if (breakLevel == breakLevelHeavy)
		{
			if (ImpactAudioActive() && Object.op_Implicit((Object)(object)impactAudio))
			{
				AudioSource val = impactAudio.breakHeavy.Play(((Component)this).transform, contactPoint);
				if (Object.op_Implicit((Object)(object)val))
				{
					val.pitch *= ImpactAudioPitch;
				}
			}
			if (Object.op_Implicit((Object)(object)physGrabObject))
			{
				SemiFunc.PlayerEyesOverrideSoft(physGrabObject.centerPoint, 1f, ((Component)this).gameObject, 10f);
			}
			GameDirector.instance.CameraImpact.ShakeDistance(5f, 1f, 6f, contactPoint, 0.1f);
			MaterialImpact(contactPoint, Materials.SoundType.Heavy);
		}
		if (breakLevel == breakLevelMedium)
		{
			if (ImpactAudioActive() && Object.op_Implicit((Object)(object)impactAudio))
			{
				AudioSource val2 = impactAudio.breakMedium.Play(((Component)this).transform, contactPoint);
				if (Object.op_Implicit((Object)(object)val2))
				{
					val2.pitch *= ImpactAudioPitch;
				}
			}
			if (Object.op_Implicit((Object)(object)physGrabObject))
			{
				SemiFunc.PlayerEyesOverrideSoft(physGrabObject.centerPoint, 1f, ((Component)this).gameObject, 5f);
			}
			GameDirector.instance.CameraImpact.ShakeDistance(3f, 1f, 6f, contactPoint, 0.1f);
			MaterialImpact(contactPoint, Materials.SoundType.Medium);
		}
		if (breakLevel != breakLevelLight)
		{
			return;
		}
		if (ImpactAudioActive() && Object.op_Implicit((Object)(object)impactAudio))
		{
			AudioSource val3 = impactAudio.breakLight.Play(((Component)this).transform, contactPoint);
			if (Object.op_Implicit((Object)(object)val3))
			{
				val3.pitch *= ImpactAudioPitch;
			}
		}
		if (Object.op_Implicit((Object)(object)physGrabObject))
		{
			SemiFunc.PlayerEyesOverrideSoft(physGrabObject.centerPoint, 1f, ((Component)this).gameObject, 3f);
		}
		GameDirector.instance.CameraImpact.ShakeDistance(1f, 1f, 6f, contactPoint, 0.1f);
		MaterialImpact(contactPoint, Materials.SoundType.Light);
	}

	public void ImpactHeavy(float force, Vector3 contactPoint)
	{
		//IL_003c: Unknown result type (might be due to invalid IL or missing references)
		//IL_000e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0011: Unknown result type (might be due to invalid IL or missing references)
		//IL_0017: Unknown result type (might be due to invalid IL or missing references)
		if (GameManager.instance.gameMode == 0)
		{
			ImpactHeavyRPC(force, contactPoint);
		}
		else
		{
			photonView.RPC("ImpactHeavyRPC", (RpcTarget)0, new object[2] { force, contactPoint });
		}
		physGrabObject.impactHappenedTimer = 0.1f;
		physGrabObject.impactHeavyTimer = 0.1f;
	}

	[PunRPC]
	private void ImpactHeavyRPC(float force, Vector3 contactPoint, PhotonMessageInfo _info = default(PhotonMessageInfo))
	{
		//IL_0000: Unknown result type (might be due to invalid IL or missing references)
		//IL_001d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0103: Unknown result type (might be due to invalid IL or missing references)
		//IL_007d: Unknown result type (might be due to invalid IL or missing references)
		//IL_00db: Unknown result type (might be due to invalid IL or missing references)
		if (!SemiFunc.MasterOnlyRPC(_info) || !Object.op_Implicit((Object)(object)physGrabObject))
		{
			return;
		}
		SemiFunc.PlayerEyesOverrideSoft(physGrabObject.centerPoint, 1f, ((Component)this).gameObject, 8f);
		if (ImpactAudioActive() && !isHinge && Object.op_Implicit((Object)(object)impactAudio))
		{
			float volumeMultiplier = ImpactSoundGetVolume(force, impactAudio.impactHeavy.Volume);
			AudioSource val = impactAudio.impactHeavy.Play(((Component)this).transform, contactPoint, volumeMultiplier);
			if (Object.op_Implicit((Object)(object)val))
			{
				val.pitch *= ImpactAudioPitch;
			}
		}
		if (!particleDisable && !inCart && Object.op_Implicit((Object)(object)particles) && !particleBreakSmokeDisable)
		{
			particles.ImpactSmoke(5, contactPoint, colliderVolume);
		}
		onAllImpacts.Invoke();
		onImpactHeavy.Invoke();
		EnemyInvestigate(1f, contactPoint);
		physGrabObject.impactHappenedTimer = 0.1f;
		physGrabObject.impactHeavyTimer = 0.1f;
	}

	public void ImpactMedium(float force, Vector3 contactPoint)
	{
		//IL_003c: Unknown result type (might be due to invalid IL or missing references)
		//IL_000e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0011: Unknown result type (might be due to invalid IL or missing references)
		//IL_0017: Unknown result type (might be due to invalid IL or missing references)
		if (GameManager.instance.gameMode == 0)
		{
			ImpactMediumRPC(force, contactPoint);
		}
		else
		{
			photonView.RPC("ImpactMediumRPC", (RpcTarget)0, new object[2] { force, contactPoint });
		}
		physGrabObject.impactHappenedTimer = 0.1f;
		physGrabObject.impactMediumTimer = 0.1f;
	}

	[PunRPC]
	private void ImpactMediumRPC(float force, Vector3 contactPoint, PhotonMessageInfo _info = default(PhotonMessageInfo))
	{
		//IL_0000: Unknown result type (might be due to invalid IL or missing references)
		//IL_001d: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d9: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e3: Unknown result type (might be due to invalid IL or missing references)
		//IL_007d: Unknown result type (might be due to invalid IL or missing references)
		if (!SemiFunc.MasterOnlyRPC(_info) || !Object.op_Implicit((Object)(object)physGrabObject))
		{
			return;
		}
		SemiFunc.PlayerEyesOverrideSoft(physGrabObject.centerPoint, 1f, ((Component)this).gameObject, 5f);
		if (ImpactAudioActive() && !isHinge && Object.op_Implicit((Object)(object)impactAudio))
		{
			float volumeMultiplier = ImpactSoundGetVolume(force, impactAudio.impactMedium.Volume);
			AudioSource val = impactAudio.impactMedium.Play(((Component)this).transform, contactPoint, volumeMultiplier);
			if (Object.op_Implicit((Object)(object)val))
			{
				val.pitch *= ImpactAudioPitch;
			}
		}
		onImpactMedium.Invoke();
		onAllImpacts.Invoke();
		if (!rb.isKinematic)
		{
			Rigidbody val2 = rb;
			val2.angularVelocity *= 0.55f;
		}
		EnemyInvestigate(0.5f, contactPoint);
		physGrabObject.impactHappenedTimer = 0.1f;
		physGrabObject.impactMediumTimer = 0.1f;
	}

	private float ImpactSoundGetVolume(float force, float volume)
	{
		float num = Mathf.Clamp01(force * 0.01f);
		if (inCart)
		{
			num *= inCartVolumeMultiplier;
		}
		return Mathf.Clamp(num, 0.1f, 1f);
	}

	public void ImpactLight(float force, Vector3 contactPoint)
	{
		//IL_000e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0011: Unknown result type (might be due to invalid IL or missing references)
		//IL_0017: Unknown result type (might be due to invalid IL or missing references)
		//IL_004a: Unknown result type (might be due to invalid IL or missing references)
		//IL_005c: Unknown result type (might be due to invalid IL or missing references)
		if (GameManager.instance.gameMode == 0)
		{
			ImpactLightRPC(force, contactPoint);
		}
		else
		{
			if (photonView.ViewID == 0)
			{
				return;
			}
			photonView.RPC("ImpactLightRPC", (RpcTarget)0, new object[2] { force, contactPoint });
		}
		EnemyInvestigate(0.2f, contactPoint);
		physGrabObject.impactHappenedTimer = 0.1f;
		physGrabObject.impactLightTimer = 0.1f;
	}

	private void MaterialImpact(Vector3 _position, Materials.SoundType _type)
	{
		//IL_0005: Unknown result type (might be due to invalid IL or missing references)
		//IL_0006: Unknown result type (might be due to invalid IL or missing references)
		//IL_0010: Unknown result type (might be due to invalid IL or missing references)
		//IL_0015: Unknown result type (might be due to invalid IL or missing references)
		//IL_001a: Unknown result type (might be due to invalid IL or missing references)
		Materials.Instance.Impulse(_position + Vector3.up * 0.1f, Vector3.down, _type, footstep: false, footstepParticles: false, materialTrigger, Materials.HostType.Enemy);
	}

	[PunRPC]
	private void ImpactLightRPC(float force, Vector3 contactPoint, PhotonMessageInfo _info = default(PhotonMessageInfo))
	{
		//IL_0000: Unknown result type (might be due to invalid IL or missing references)
		//IL_001d: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d7: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e1: Unknown result type (might be due to invalid IL or missing references)
		//IL_0091: Unknown result type (might be due to invalid IL or missing references)
		if (!SemiFunc.MasterOnlyRPC(_info) || !Object.op_Implicit((Object)(object)physGrabObject))
		{
			return;
		}
		SemiFunc.PlayerEyesOverrideSoft(physGrabObject.centerPoint, 1f, ((Component)this).gameObject, 3f);
		if (ImpactAudioActive() && !isHinge && Object.op_Implicit((Object)(object)impactAudio))
		{
			float num = ImpactSoundGetVolume(force, impactAudio.impactLight.Volume);
			if (inCart)
			{
				num *= inCartVolumeMultiplier;
			}
			AudioSource val = impactAudio.impactLight.Play(((Component)this).transform, contactPoint, num);
			if (Object.op_Implicit((Object)(object)val))
			{
				val.pitch *= ImpactAudioPitch;
			}
		}
		if (!rb.isKinematic)
		{
			Rigidbody val2 = rb;
			val2.angularVelocity *= 0.6f;
		}
		onAllImpacts.Invoke();
		onImpactLight.Invoke();
		physGrabObject.impactHappenedTimer = 0.1f;
		physGrabObject.impactLightTimer = 0.1f;
	}

	private void OnTriggerStay(Collider other)
	{
		//IL_0037: Unknown result type (might be due to invalid IL or missing references)
		//IL_003c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0041: Unknown result type (might be due to invalid IL or missing references)
		//IL_0052: Unknown result type (might be due to invalid IL or missing references)
		//IL_0057: Unknown result type (might be due to invalid IL or missing references)
		//IL_005a: Unknown result type (might be due to invalid IL or missing references)
		if ((GameManager.instance.gameMode != 0 && !PhotonNetwork.IsMasterClient) || !((Component)other).CompareTag("Cart"))
		{
			return;
		}
		bool flag = true;
		if (centerPointNeedsToBeInsideCart)
		{
			Vector3 val = ((Component)this).transform.TransformPoint(centerPoint);
			Collider component = ((Component)other).GetComponent<Collider>();
			if (Object.op_Implicit((Object)(object)component))
			{
				Bounds bounds = component.bounds;
				if (!bounds.Contains(val))
				{
					flag = false;
				}
			}
		}
		if (flag)
		{
			PhysGrabCart componentInParent = ((Component)other).GetComponentInParent<PhysGrabCart>();
			if (Object.op_Implicit((Object)(object)componentInParent))
			{
				currentCartPrev = currentCart;
				currentCart = componentInParent;
				currentCart.physGrabInCart.Add(physGrabObject);
				timerInCart = 0.1f;
			}
			else
			{
				timerInSafeArea = 0.1f;
			}
		}
	}

	private void OnCollisionStay(Collision collision)
	{
		//IL_016e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0173: Unknown result type (might be due to invalid IL or missing references)
		//IL_0185: Unknown result type (might be due to invalid IL or missing references)
		//IL_018a: Unknown result type (might be due to invalid IL or missing references)
		//IL_018c: Unknown result type (might be due to invalid IL or missing references)
		//IL_018f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0194: Unknown result type (might be due to invalid IL or missing references)
		//IL_0199: Unknown result type (might be due to invalid IL or missing references)
		//IL_01c9: Unknown result type (might be due to invalid IL or missing references)
		//IL_01ce: Unknown result type (might be due to invalid IL or missing references)
		//IL_01b2: Unknown result type (might be due to invalid IL or missing references)
		//IL_01bc: Unknown result type (might be due to invalid IL or missing references)
		//IL_01c1: Unknown result type (might be due to invalid IL or missing references)
		//IL_023a: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a0: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a5: Unknown result type (might be due to invalid IL or missing references)
		//IL_00bc: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d1: Unknown result type (might be due to invalid IL or missing references)
		//IL_013d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0142: Unknown result type (might be due to invalid IL or missing references)
		//IL_0151: Unknown result type (might be due to invalid IL or missing references)
		//IL_0156: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e8: Unknown result type (might be due to invalid IL or missing references)
		//IL_00fd: Unknown result type (might be due to invalid IL or missing references)
		//IL_02ad: Unknown result type (might be due to invalid IL or missing references)
		//IL_02fd: Unknown result type (might be due to invalid IL or missing references)
		//IL_0342: Unknown result type (might be due to invalid IL or missing references)
		//IL_0fcb: Unknown result type (might be due to invalid IL or missing references)
		//IL_0fa0: Unknown result type (might be due to invalid IL or missing references)
		//IL_0fa7: Unknown result type (might be due to invalid IL or missing references)
		//IL_0fad: Unknown result type (might be due to invalid IL or missing references)
		//IL_0536: Unknown result type (might be due to invalid IL or missing references)
		//IL_053b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0546: Unknown result type (might be due to invalid IL or missing references)
		//IL_1094: Unknown result type (might be due to invalid IL or missing references)
		//IL_10a6: Unknown result type (might be due to invalid IL or missing references)
		//IL_1054: Unknown result type (might be due to invalid IL or missing references)
		//IL_10b8: Unknown result type (might be due to invalid IL or missing references)
		//IL_106b: Unknown result type (might be due to invalid IL or missing references)
		//IL_1082: Unknown result type (might be due to invalid IL or missing references)
		//IL_0b42: Unknown result type (might be due to invalid IL or missing references)
		//IL_0b48: Unknown result type (might be due to invalid IL or missing references)
		//IL_0b4d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0b52: Unknown result type (might be due to invalid IL or missing references)
		//IL_0b65: Unknown result type (might be due to invalid IL or missing references)
		//IL_0b6c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0b76: Unknown result type (might be due to invalid IL or missing references)
		//IL_0b7b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0b90: Unknown result type (might be due to invalid IL or missing references)
		//IL_0665: Unknown result type (might be due to invalid IL or missing references)
		//IL_066b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0670: Unknown result type (might be due to invalid IL or missing references)
		//IL_0675: Unknown result type (might be due to invalid IL or missing references)
		//IL_068a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0691: Unknown result type (might be due to invalid IL or missing references)
		//IL_069b: Unknown result type (might be due to invalid IL or missing references)
		//IL_06a0: Unknown result type (might be due to invalid IL or missing references)
		//IL_06b7: Unknown result type (might be due to invalid IL or missing references)
		//IL_0ba8: Unknown result type (might be due to invalid IL or missing references)
		//IL_0bad: Unknown result type (might be due to invalid IL or missing references)
		//IL_0bd5: Unknown result type (might be due to invalid IL or missing references)
		//IL_0bdf: Unknown result type (might be due to invalid IL or missing references)
		//IL_06cf: Unknown result type (might be due to invalid IL or missing references)
		//IL_06d4: Unknown result type (might be due to invalid IL or missing references)
		//IL_0c6b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0c70: Unknown result type (might be due to invalid IL or missing references)
		//IL_070c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0dce: Unknown result type (might be due to invalid IL or missing references)
		//IL_0ddc: Unknown result type (might be due to invalid IL or missing references)
		//IL_0de1: Unknown result type (might be due to invalid IL or missing references)
		//IL_0dea: Unknown result type (might be due to invalid IL or missing references)
		//IL_0df4: Unknown result type (might be due to invalid IL or missing references)
		//IL_0e05: Unknown result type (might be due to invalid IL or missing references)
		//IL_0e0a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0e0f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0e11: Unknown result type (might be due to invalid IL or missing references)
		//IL_0e13: Unknown result type (might be due to invalid IL or missing references)
		//IL_0e21: Unknown result type (might be due to invalid IL or missing references)
		//IL_0e26: Unknown result type (might be due to invalid IL or missing references)
		//IL_0e2f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0d11: Unknown result type (might be due to invalid IL or missing references)
		//IL_08ad: Unknown result type (might be due to invalid IL or missing references)
		//IL_0987: Unknown result type (might be due to invalid IL or missing references)
		//IL_0991: Unknown result type (might be due to invalid IL or missing references)
		//IL_0999: Unknown result type (might be due to invalid IL or missing references)
		//IL_099e: Unknown result type (might be due to invalid IL or missing references)
		//IL_09ac: Unknown result type (might be due to invalid IL or missing references)
		//IL_09b2: Unknown result type (might be due to invalid IL or missing references)
		//IL_09b7: Unknown result type (might be due to invalid IL or missing references)
		//IL_09bc: Unknown result type (might be due to invalid IL or missing references)
		//IL_09c0: Unknown result type (might be due to invalid IL or missing references)
		//IL_09cc: Unknown result type (might be due to invalid IL or missing references)
		//IL_09d1: Unknown result type (might be due to invalid IL or missing references)
		//IL_09db: Unknown result type (might be due to invalid IL or missing references)
		//IL_09e7: Unknown result type (might be due to invalid IL or missing references)
		//IL_09ec: Unknown result type (might be due to invalid IL or missing references)
		//IL_09f7: Unknown result type (might be due to invalid IL or missing references)
		//IL_09f9: Unknown result type (might be due to invalid IL or missing references)
		//IL_0a16: Unknown result type (might be due to invalid IL or missing references)
		//IL_0a1b: Unknown result type (might be due to invalid IL or missing references)
		if ((GameManager.instance.gameMode == 1 && !PhotonNetwork.IsMasterClient) || !collisionsActive || !isMoving)
		{
			return;
		}
		isCollidingTimer = 0.1f;
		Vector3 val;
		if (!isHinge && !slidingDisable && !isCart && !inCart && !isCart && isValuable && valuableObject.volumeType >= ValuableVolume.Type.Medium && Object.op_Implicit((Object)(object)collision.gameObject.GetComponent<MaterialSurface>()))
		{
			val = rb.linearVelocity;
			if (val.magnitude > slidingSpeedThreshold && (Mathf.Abs(rb.linearVelocity.x) > Mathf.Abs(rb.linearVelocity.y) || Mathf.Abs(rb.linearVelocity.z) > Mathf.Abs(rb.linearVelocity.y)))
			{
				isSliding = true;
				slidingTimer = 0.1f;
			}
			PhysGrabObject component = collision.gameObject.GetComponent<PhysGrabObject>();
			if (Object.op_Implicit((Object)(object)component))
			{
				val = component.rb.linearVelocity;
				float magnitude = val.magnitude;
				val = rb.linearVelocity;
				if (magnitude > val.magnitude * 0.8f)
				{
					isSliding = false;
				}
			}
		}
		Vector3 val2 = Vector3.zero;
		ContactPoint[] contacts = collision.contacts;
		for (int i = 0; i < contacts.Length; i++)
		{
			ContactPoint val3 = contacts[i];
			val2 += val3.point;
		}
		if (collision.contacts.Length != 0)
		{
			contactPoint = val2 / (float)collision.contacts.Length;
		}
		else
		{
			contactPoint = Vector3.zero;
		}
		PhysGrabObjectImpactDetector component2 = collision.gameObject.GetComponent<PhysGrabObjectImpactDetector>();
		PhysGrabObjectImpactDetector physGrabObjectImpactDetector = component2;
		if (!Object.op_Implicit((Object)(object)physGrabObjectImpactDetector) && Object.op_Implicit((Object)(object)collision.rigidbody))
		{
			physGrabObjectImpactDetector = ((Component)collision.rigidbody).GetComponent<PhysGrabObjectImpactDetector>();
		}
		if (Object.op_Implicit((Object)(object)physGrabObjectImpactDetector))
		{
			OverrideEnemyInvestigateDisable(physGrabObjectImpactDetector.EnemyInvestigateDisableTimeGet());
		}
		bool flag = false;
		bool flag2 = false;
		int num = 0;
		bool flag3 = false;
		flag3 = isCart && contactPoint.y < ((Component)this).transform.position.y;
		if (impactHappened && (!isCart || !Object.op_Implicit((Object)(object)component2) || !component2.inCart) && !flag3)
		{
			if (impulseTimerDeactivateImpacts <= 0f)
			{
				if (impactForce > 150f && impactHeavyCooldown <= 0f)
				{
					flag2 = true;
					ImpactHeavy(impactForce, contactPoint);
					impactHeavyCooldown = 0.5f;
					impactMediumCooldown = 0.5f;
					impactLightCooldown = 0.5f;
				}
				if (impactForce > 80f && impactMediumCooldown <= 0f)
				{
					flag2 = true;
					ImpactMedium(impactForce, contactPoint);
					impactMediumCooldown = 0.5f;
					impactLightCooldown = 0.5f;
				}
				if (impactForce > 20f && impactLightCooldown <= 0f)
				{
					flag2 = true;
					ImpactLight(impactForce, contactPoint);
					impactLightCooldown = 0.5f;
				}
			}
			if (indestructibleSpawnTimer <= 0f)
			{
				float num2 = Mathf.Max(rb.mass, 1f);
				if (breakForce > impactLevel3 * num2 && breakLevel3Cooldown <= 0f && !inCart)
				{
					flag = true;
					num = 3;
				}
				if (breakForce > impactLevel2 * num2 && breakLevel2Cooldown <= 0f && !flag && !inCart)
				{
					flag = true;
					num = 2;
				}
				if (breakForce > impactLevel1 * num2 && breakLevel1Cooldown <= 0f && !flag && !inCart)
				{
					flag = true;
					num = 1;
				}
			}
		}
		bool flag4 = false;
		bool flag5 = false;
		if (flag && (!isEnemy || this.enemyRigidbody.enemy.IsStunned()))
		{
			flag4 = true;
		}
		if (flag2 && (!isEnemy || this.enemyRigidbody.enemy.IsStunned()))
		{
			flag4 = true;
		}
		if (flag && isBrokenHinge)
		{
			flag5 = true;
		}
		if (!canHurtLogic)
		{
			flag4 = false;
		}
		bool flag6 = false;
		if (playerHitDisable && (((Component)collision.transform).CompareTag("Player") || Object.op_Implicit((Object)(object)((Component)collision.transform).GetComponent<PlayerTumble>())))
		{
			playerHitDisableTimer = 0.5f;
		}
		if (!playerHitDisable && flag4 && (flag || (flag2 && isCart)))
		{
			bool flag7 = false;
			PlayerTumble playerTumble = null;
			if (((Component)collision.transform).CompareTag("Player"))
			{
				flag7 = true;
			}
			else
			{
				playerTumble = ((Component)collision.transform).GetComponent<PlayerTumble>();
				if (Object.op_Implicit((Object)(object)playerTumble))
				{
					flag7 = true;
				}
			}
			if (flag7 && isCart)
			{
				if (physGrabObject.playerGrabbing.Count <= 0)
				{
					flag7 = false;
				}
				else if (Vector3.Distance(((Collider)((Component)cart.inCart).GetComponent<BoxCollider>()).ClosestPoint(collision.transform.position), collision.transform.position) < 0.01f)
				{
					flag7 = false;
				}
			}
			if (flag7)
			{
				PlayerController componentInParent = ((Component)collision.transform).GetComponentInParent<PlayerController>();
				PlayerAvatar playerAvatar;
				if (Object.op_Implicit((Object)(object)playerTumble))
				{
					playerAvatar = playerTumble.playerAvatar;
				}
				else if (Object.op_Implicit((Object)(object)componentInParent))
				{
					playerAvatar = componentInParent.playerAvatarScript;
				}
				else
				{
					playerAvatar = ((Component)collision.transform).GetComponentInParent<PlayerAvatar>();
					if (!Object.op_Implicit((Object)(object)playerAvatar))
					{
						playerAvatar = ((Component)collision.transform).GetComponent<PlayerAvatar>();
					}
					if (!Object.op_Implicit((Object)(object)playerAvatar))
					{
						playerAvatar = ((Component)collision.transform).GetComponentInChildren<PlayerAvatar>();
					}
					if (!Object.op_Implicit((Object)(object)playerAvatar))
					{
						PlayerPhysPusher component3 = ((Component)collision.transform).GetComponent<PlayerPhysPusher>();
						if (Object.op_Implicit((Object)(object)component3))
						{
							playerAvatar = component3.Player;
						}
					}
				}
				bool flag8 = false;
				foreach (PhysGrabber item in physGrabObject.playerGrabbing)
				{
					if ((Object)(object)item.playerAvatar == (Object)(object)playerAvatar)
					{
						flag8 = true;
						break;
					}
				}
				if (Object.op_Implicit((Object)(object)playerAvatar) && !flag8)
				{
					Vector3 val4 = ((Component)playerAvatar.PlayerVisionTarget.VisionTransform).transform.position - contactPoint;
					float magnitude2 = previousPreviousVelocityRaw.magnitude;
					Vector3 val5 = Vector3.Lerp(previousPreviousVelocityRaw.normalized, val4.normalized, 0f);
					if (magnitude2 >= 3f)
					{
						PlayerAvatar playerAvatar2 = null;
						RaycastHit[] array = rb.SweepTestAll(val5, 1f, (QueryTriggerInteraction)2);
						for (int i = 0; i < array.Length; i++)
						{
							RaycastHit val6 = array[i];
							playerAvatar2 = ImpactGetPlayer(val6.collider, componentInParent, playerTumble);
							if ((Object)(object)playerAvatar2 == (Object)(object)playerAvatar)
							{
								break;
							}
						}
						if (!Object.op_Implicit((Object)(object)playerAvatar2))
						{
							Collider[] array2 = Physics.OverlapSphere(contactPoint, 0.2f, LayerMask.GetMask(new string[1] { "Player" }));
							foreach (Collider hit in array2)
							{
								playerAvatar2 = ImpactGetPlayer(hit, componentInParent, playerTumble);
								if ((Object)(object)playerAvatar2 == (Object)(object)playerAvatar)
								{
									break;
								}
							}
						}
						if ((Object)(object)playerAvatar2 == (Object)(object)playerAvatar)
						{
							bool flag9 = false;
							if (!playerAvatar.isTumbling)
							{
								foreach (PhysGrabObject physGrabObject in playerAvatar.physObjectFinder.physGrabObjects)
								{
									if ((Object)(object)physGrabObject == (Object)(object)this.physGrabObject && !Object.op_Implicit((Object)(object)physGrabObject.impactDetector.cart))
									{
										flag9 = true;
										break;
									}
								}
							}
							if (!flag9)
							{
								bool flag10 = false;
								float time = 0.1f;
								bool flag11 = isValuable;
								if (!flag11)
								{
									flag11 = this.physGrabObject.isNonValuable && this.physGrabObject.notValuableObject.hasHealth;
								}
								if (((!playerHurtDisable && !isIndestructible && !destroyDisable) & flag11) && (!isValuable || !playerAvatar.tumble.CocoonHeld()))
								{
									time = 0.15f;
									int num3 = Mathf.RoundToInt((float)(5 * num) * (rb.mass * 0.5f) * playerHurtMultiplier);
									int health = playerAvatar.playerHealth.health;
									bool num4 = health > 0 && !playerAvatar.deadSet;
									playerAvatar.playerHealth.HurtOther(num3, contactPoint, savingGrace: true);
									PlayerAvatar playerAvatar3 = ItemVehicle.GetSeatedDriverForPhysObject(this.physGrabObject);
									if (!Object.op_Implicit((Object)(object)playerAvatar3))
									{
										playerAvatar3 = this.physGrabObject.lastPlayerGrabbing;
									}
									if (num4 && Object.op_Implicit((Object)(object)playerAvatar3) && (Object)(object)playerAvatar3 != (Object)(object)playerAvatar)
									{
										int damage = Mathf.Min(num3, health);
										bool killed = num3 >= health;
										SemiFunc.PlayerShopKeeperPhysObjectHitPlayerHost(playerAvatar3, playerAvatar, damage, killed);
									}
									flag10 = true;
								}
								bool flag12 = false;
								if (isHinge)
								{
									if (magnitude2 >= 3f)
									{
										flag12 = true;
									}
								}
								else if (isCart)
								{
									if (magnitude2 >= 3f)
									{
										flag12 = true;
									}
								}
								else if (magnitude2 >= 6f)
								{
									flag12 = true;
								}
								if (flag10 | flag12)
								{
									if (!Object.op_Implicit((Object)(object)playerTumble))
									{
										playerTumble = playerAvatar.tumble;
									}
									playerTumble.TumbleRequest(_isTumbling: true, _playerInput: false);
									playerTumble.TumbleOverrideTime(2f);
									Vector3 force = val4.normalized * 4f * (float)num;
									val = playerAvatar.localCamera.GetOverrideTransform().position - contactPoint;
									Vector3 torque = Vector3.Cross(val.normalized, ((Component)playerAvatar).transform.forward) * 5f * force.magnitude;
									playerTumble.physGrabObject.FreezeForces(time, force, torque);
									playerAvatar.playerHealth.HurtFreezeOverride(time);
									this.physGrabObject.FreezeForces(time, Vector3.zero, Vector3.zero);
									flag6 = true;
									PlayerAvatar playerAvatar4 = ItemVehicle.GetSeatedDriverForPhysObject(this.physGrabObject);
									if (!Object.op_Implicit((Object)(object)playerAvatar4))
									{
										playerAvatar4 = this.physGrabObject.lastPlayerGrabbing;
									}
									if (!flag10 && Object.op_Implicit((Object)(object)playerAvatar4) && (Object)(object)playerAvatar4 != (Object)(object)playerAvatar && !playerAvatar.deadSet)
									{
										SemiFunc.PlayerShopKeeperPhysObjectHitPlayerHost(playerAvatar4, playerAvatar, 0, _killed: false);
									}
								}
							}
						}
					}
				}
			}
		}
		if ((flag4 | flag5) && !playerHurtDisable && enemyInteractionTimer <= 0f && !isIndestructible && !destroyDisable && ((isValuable || isEnemy) | flag5) && ((Component)collision.transform).CompareTag("Enemy"))
		{
			EnemyRigidbody component4 = ((Component)collision.transform).GetComponent<EnemyRigidbody>();
			if (Object.op_Implicit((Object)(object)component4) && component4.enemy.HasHealth && component4.enemy.Health.objectHurt && component4.enemy.Health.objectHurtDisableTimer <= 0f)
			{
				Vector3 val7 = component4.physGrabObject.centerPoint - contactPoint;
				float magnitude3 = previousPreviousVelocityRaw.magnitude;
				Vector3 val8 = Vector3.Lerp(previousPreviousVelocityRaw.normalized, val7.normalized, 0.5f);
				if (magnitude3 > 2f)
				{
					EnemyRigidbody enemyRigidbody = null;
					RaycastHit[] array = rb.SweepTestAll(val8, 1f, (QueryTriggerInteraction)2);
					for (int i = 0; i < array.Length; i++)
					{
						RaycastHit val9 = array[i];
						enemyRigidbody = ((Component)val9.transform).GetComponent<EnemyRigidbody>();
					}
					if (!Object.op_Implicit((Object)(object)enemyRigidbody))
					{
						Collider[] array2 = Physics.OverlapSphere(contactPoint, 0.2f, LayerMask.op_Implicit(SemiFunc.LayerMaskGetPhysGrabObject()));
						for (int i = 0; i < array2.Length; i++)
						{
							enemyRigidbody = ((Component)array2[i]).GetComponentInParent<EnemyRigidbody>();
						}
					}
					if ((Object)(object)enemyRigidbody == (Object)(object)component4)
					{
						flag6 = true;
						int num5 = Mathf.RoundToInt((float)(10 * num) * (rb.mass * 0.5f));
						num5 = Mathf.RoundToInt((float)num5 * component4.enemy.Health.objectHurtMultiplier);
						component4.enemy.Health.Hurt(num5, -val7.normalized);
						if (isValuable)
						{
							float num6 = 0f;
							switch (valuableObject.volumeType)
							{
							case ValuableVolume.Type.Tiny:
								num6 = 0.2f;
								break;
							case ValuableVolume.Type.Small:
								num6 = 0.2f;
								break;
							case ValuableVolume.Type.Medium:
								num6 = 1f / 7f;
								break;
							case ValuableVolume.Type.Big:
								num6 = 0.1f;
								break;
							case ValuableVolume.Type.Wide:
								num6 = 0.1f;
								break;
							case ValuableVolume.Type.Tall:
								num6 = 0.1f;
								break;
							case ValuableVolume.Type.VeryTall:
								num6 = 0.1f;
								break;
							}
							num6 += Random.Range(-0.05f, 0.05f);
							BreakHeavy(contactPoint, _forceBreak: false, Mathf.CeilToInt(valuableObject.dollarValueOriginal * num6));
						}
						flag2 = false;
						flag = false;
						if (component4.enemy.Health.onObjectHurt != null)
						{
							if (this.physGrabObject.grabbedTimer > 0f)
							{
								component4.enemy.Health.onObjectHurtPhysObject = this.physGrabObject;
								component4.enemy.Health.onObjectHurtPlayer = this.physGrabObject.lastPlayerGrabbing;
							}
							else
							{
								component4.enemy.Health.onObjectHurtPhysObject = null;
								component4.enemy.Health.onObjectHurtPlayer = null;
							}
							component4.enemy.Health.onObjectHurt.Invoke();
						}
						Vector3 val10 = val7.normalized * (2f * (float)num);
						component4.rb.AddForce(val10, (ForceMode)1);
						Vector3 normalized = val7.normalized;
						Vector3 val11 = -((Component)component4.rb).transform.up;
						Vector3 val12 = Vector3.Cross(normalized, val11) * (2f * (float)num);
						component4.rb.AddTorque(val12, (ForceMode)1);
						EnemyType type = component4.enemy.Type;
						if (isValuable)
						{
							if (component4.enemy.HasStateStunned && component4.enemy.Health.objectHurtStun)
							{
								float num7 = (Object.op_Implicit((Object)(object)valuableObject.physAttributePreset) ? valuableObject.physAttributePreset.mass : 0f);
								float num8 = -1.5f;
								if (SemiFunc.MoonLevel() >= 1)
								{
									num8 = 0f;
								}
								bool flag13 = false;
								switch (type)
								{
								case EnemyType.VeryLight:
									if (num7 >= 0.5f + num8)
									{
										flag13 = true;
									}
									break;
								case EnemyType.Light:
									if (num7 >= 1f + num8)
									{
										flag13 = true;
									}
									break;
								case EnemyType.Medium:
									if (num7 >= 2f + num8)
									{
										flag13 = true;
									}
									break;
								case EnemyType.Heavy:
									if (num7 >= 3.5f + num8)
									{
										flag13 = true;
									}
									break;
								case EnemyType.VeryHeavy:
									if (num7 >= 5f + num8)
									{
										flag13 = true;
									}
									break;
								}
								if (flag13)
								{
									component4.enemy.StateStunned.Set(2f);
								}
							}
						}
						else if (isBrokenHinge)
						{
							if (type <= EnemyType.Medium && component4.enemy.HasStateStunned && component4.enemy.Health.objectHurtStun)
							{
								component4.enemy.StateStunned.Set(2f);
							}
							DestroyObject();
						}
					}
				}
			}
		}
		if (flag6)
		{
			if (!SemiFunc.IsMultiplayer())
			{
				ImpactEffectRPC(contactPoint);
			}
			else
			{
				photonView.RPC("ImpactEffectRPC", (RpcTarget)0, new object[1] { contactPoint });
			}
		}
		if (!flag || !(this.physGrabObject.overrideDisableBreakEffectsTimer <= 0f))
		{
			return;
		}
		bool flag14 = isValuable;
		if (!flag14 && this.physGrabObject.isNonValuable && this.physGrabObject.notValuableObject.hasHealth)
		{
			flag14 = true;
		}
		if ((destroyDisable || isIndestructible || !flag14) && !indestructibleBreakEffects)
		{
			if (!flag2)
			{
				if (num == 1)
				{
					ImpactLight(impactForce, contactPoint);
				}
				if (num == 2)
				{
					ImpactMedium(impactForce, contactPoint);
				}
				if (num == 3)
				{
					ImpactHeavy(impactForce, contactPoint);
				}
			}
		}
		else
		{
			if (num == 1)
			{
				BreakLight(contactPoint);
			}
			if (num == 2)
			{
				BreakMedium(contactPoint);
			}
			if (num == 3)
			{
				BreakHeavy(contactPoint);
			}
		}
	}

	[PunRPC]
	private void ImpactEffectRPC(Vector3 _position, PhotonMessageInfo _info = default(PhotonMessageInfo))
	{
		//IL_0000: Unknown result type (might be due to invalid IL or missing references)
		//IL_000e: Unknown result type (might be due to invalid IL or missing references)
		if (SemiFunc.MasterOnlyRPC(_info))
		{
			AssetManager.instance.PhysImpactEffect(_position);
		}
	}

	private PlayerAvatar ImpactGetPlayer(Collider _hit, PlayerController _playerController, PlayerTumble _playerTumble)
	{
		PlayerAvatar playerAvatar = null;
		if (Object.op_Implicit((Object)(object)_playerTumble))
		{
			PlayerTumble playerTumble = ((Component)((Component)_hit).transform).GetComponent<PlayerTumble>();
			if (!Object.op_Implicit((Object)(object)playerTumble))
			{
				playerTumble = ((Component)((Component)_hit).transform).GetComponentInParent<PlayerTumble>();
			}
			if (Object.op_Implicit((Object)(object)playerTumble))
			{
				return playerTumble.playerAvatar;
			}
		}
		playerAvatar = ((Component)((Component)_hit).transform).GetComponentInParent<PlayerAvatar>();
		if (!Object.op_Implicit((Object)(object)playerAvatar))
		{
			playerAvatar = ((Component)((Component)_hit).transform).GetComponent<PlayerAvatar>();
		}
		if (!Object.op_Implicit((Object)(object)playerAvatar))
		{
			playerAvatar = ((Component)((Component)_hit).transform).GetComponentInChildren<PlayerAvatar>();
		}
		if (!Object.op_Implicit((Object)(object)playerAvatar))
		{
			PlayerPhysPusher component = ((Component)((Component)_hit).transform).GetComponent<PlayerPhysPusher>();
			if (Object.op_Implicit((Object)(object)component))
			{
				playerAvatar = component.Player;
			}
		}
		if (!Object.op_Implicit((Object)(object)playerAvatar) && Object.op_Implicit((Object)(object)_playerController))
		{
			PlayerController playerController = ((Component)((Component)_hit).transform).GetComponentInParent<PlayerController>();
			if (!Object.op_Implicit((Object)(object)playerController) && Object.op_Implicit((Object)(object)((Component)((Component)_hit).transform).GetComponentInParent<PlayerCollisionController>()))
			{
				playerController = PlayerController.instance;
			}
			if (Object.op_Implicit((Object)(object)playerController))
			{
				playerAvatar = playerController.playerAvatarScript;
			}
		}
		return playerAvatar;
	}

	public void PlayerHurtMultiplier(float _multiplier, float _time)
	{
		playerHurtMultiplier = _multiplier;
		playerHurtMultiplierTimer = _time;
	}

	public void OnPhotonSerializeView(PhotonStream stream, PhotonMessageInfo info)
	{
	}

	public void ChangePhysAudio(PhysAudio _physAudio)
	{
		impactAudio = _physAudio;
	}

	public PhysGrabObjectImpactDetector()
	{
		//IL_00ed: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f2: Unknown result type (might be due to invalid IL or missing references)
	}
}
