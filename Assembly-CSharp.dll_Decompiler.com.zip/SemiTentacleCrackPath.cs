using System;
using UnityEngine;

internal static class SemiTentacleCrackPath
{
	internal static Vector3 TipPosition(Vector3 _start, Vector3 _control, Vector3 _end, float _progress)
	{
		//IL_0008: Unknown result type (might be due to invalid IL or missing references)
		//IL_0009: Unknown result type (might be due to invalid IL or missing references)
		//IL_000a: Unknown result type (might be due to invalid IL or missing references)
		//IL_000b: Unknown result type (might be due to invalid IL or missing references)
		float num = Mathf.Clamp01(_progress);
		return SemiFunc.CalculateBezierPoint(num * num, _start, _control, _end);
	}

	internal static float LoopRadius(float _distance, float _progress)
	{
		if (_progress <= 0f || _progress >= 1f)
		{
			return 0f;
		}
		float num = Mathf.Clamp(_distance * 0.11f, 0.15f, 0.75f);
		float num2 = Mathf.Sin(_progress * MathF.PI);
		float num3 = num * num2;
		float num4 = 1f - _progress * 0.35f;
		return num3 * num4;
	}

	internal static Vector3 LoopOffset(Vector3 _forward, Vector3 _axis, float _distance, float _progress, float _along)
	{
		//IL_0012: Unknown result type (might be due to invalid IL or missing references)
		//IL_0053: Unknown result type (might be due to invalid IL or missing references)
		//IL_007e: Unknown result type (might be due to invalid IL or missing references)
		//IL_008b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0090: Unknown result type (might be due to invalid IL or missing references)
		//IL_0097: Unknown result type (might be due to invalid IL or missing references)
		//IL_009c: Unknown result type (might be due to invalid IL or missing references)
		//IL_009e: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a0: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a7: Unknown result type (might be due to invalid IL or missing references)
		if (_along <= 0f || _along >= 1f)
		{
			return Vector3.zero;
		}
		float num = Mathf.Lerp(0.18f, 1.15f, _progress * _progress);
		float num2 = Mathf.Lerp(0.45f, 0.16f, _progress);
		float num3 = (_along - num) / num2;
		if (num3 <= -1f || num3 >= 1f)
		{
			return Vector3.zero;
		}
		float num4 = (num3 + 1f) * MathF.PI;
		float num5 = LoopRadius(_distance, _progress) * Mathf.Sin(_along * MathF.PI);
		Vector3 val = _axis * (1f - Mathf.Cos(num4));
		Vector3 val2 = _forward * Mathf.Sin(num4);
		return (val - val2) * num5;
	}
}
