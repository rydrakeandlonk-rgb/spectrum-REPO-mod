using System;
using System.Collections;
using System.Collections.Generic;
using Photon.Pun;
using UnityEngine;
using UnityEngine.AI;

public class EnemyShadow : MonoBehaviour
{
	[Serializable]
	public class FingerSpring
	{
		public Transform bone;

		[HideInInspector]
		public SpringQuaternion spring;

		[HideInInspector]
		public Quaternion bindLocalRotation;

		[HideInInspector]
		public bool bindCaptured;
	}

	public enum State
	{
		Spawn,
		ChooseTarget,
		Despawn,
		Follow,
		Stun,
		Slap,
		CoolDown,
		StuckAttack,
		Leave
	}

	[Header("OTHER SCRIPTS")]
	public EnemyShadowAnim anim;

	public BotSystemSpringPoseAnimator springPoseAnimator;

	public Transform torsoBend;

	public Transform headBend;

	public Transform rightArmBend;

	public Transform leftArmBend;

	public Transform leftEyePivot;

	public Transform rightEyePivot;

	public Transform rightWristPivot;

	public Transform leftWristPivot;

	public Transform leftArmPoint;

	public Transform rightArmPoint;

	public Transform neckBend;

	public Transform leftHandDownPos;

	public Transform rightHandDownPos;

	public Transform visionTransform;

	[Min(0f)]
	public float headTurnSpeed = 2f;

	[Min(0f)]
	public float eyeTurnSpeed = 12f;

	[Space]
	public AnimationCurve slapAnimationCurve = new AnimationCurve();

	public AnimationCurve slapScaleCurve = AnimationCurve.EaseInOut(0f, 0f, 1f, 1f);

	public AnimationCurve reachOutSlapCurve = AnimationCurve.EaseInOut(0f, 0f, 1f, 1f);

	public AnimationCurve reachOutSlapScaleCurve = AnimationCurve.EaseInOut(0f, 0f, 1f, 1f);

	public AnimationCurve reachOutStuckCurve = AnimationCurve.EaseInOut(0f, 0f, 1f, 1f);

	public AnimationCurve reachOutStuckScaleCurve = AnimationCurve.EaseInOut(0f, 0f, 1f, 1f);

	public AnimationCurve returnHandsCurve = AnimationCurve.EaseInOut(0f, 0f, 1f, 1f);

	public AnimationCurve returnHandsScaleCurve = AnimationCurve.EaseInOut(0f, 0f, 1f, 1f);

	public AnimationCurve cooldownScaleCurve = AnimationCurve.EaseInOut(0f, 0f, 1f, 1f);

	public AnimationCurve handGrowCurve = AnimationCurve.EaseInOut(0f, 0f, 1f, 1f);

	public AnimationCurve reachRotCurve = AnimationCurve.EaseInOut(0f, 0f, 1f, 1f);

	public AnimationCurve returnRotCurve = AnimationCurve.EaseInOut(0f, 0f, 1f, 1f);

	public AnimationCurve handBendCurve = AnimationCurve.EaseInOut(0f, 0f, 1f, 1f);

	public AnimationCurve bodyAvoidCurve = AnimationCurve.EaseInOut(0f, 0f, 1f, 1f);

	public AnimationCurve wristReachZCurve = new AnimationCurve(new Keyframe[4]
	{
		new Keyframe(0f, 0f),
		new Keyframe(0.25f, -1f),
		new Keyframe(0.6f, 0.75f),
		new Keyframe(1f, 0f)
	});

	public AnimationCurve wristReturnZCurve = new AnimationCurve(new Keyframe[4]
	{
		new Keyframe(0f, 0f),
		new Keyframe(0.25f, 0.75f),
		new Keyframe(0.65f, -0.5f),
		new Keyframe(1f, 0f)
	});

	public float wristZAmount = 60f;

	public AnimationCurve slapYCurve = new AnimationCurve(new Keyframe[4]
	{
		new Keyframe(0f, 0f),
		new Keyframe(0.4f, 1f),
		new Keyframe(0.92f, 0f),
		new Keyframe(1f, -0.25f)
	});

	public float slapYAmount = 70f;

	public float handsLockDuration = 0.3f;

	private float handsLockTimer;

	private Vector3 handsLockPosLocal;

	public AnimationCurve reachArcCurve = new AnimationCurve(new Keyframe[3]
	{
		new Keyframe(0f, 0f),
		new Keyframe(0.45f, 1f),
		new Keyframe(1f, 0f)
	});

	public Vector3 reachArcAmount = new Vector3(0f, 0.4f, -0.15f);

	public float elbowOutwardAmount = 0.5f;

	public float elbowOutwardSpeed = 1.5f;

	public AnimationCurve idleHandsLoopCurve = new AnimationCurve(new Keyframe[5]
	{
		new Keyframe(0f, 0f),
		new Keyframe(0.25f, 1f),
		new Keyframe(0.5f, 0f),
		new Keyframe(0.75f, -1f),
		new Keyframe(1f, 0f)
	});

	public float idleHandsLoopDuration = 3f;

	public float idleHandsYAmount = 0.04f;

	public Vector3 idleHandsRotAmount = new Vector3(4f, 0f, 3f);

	private const float reachOutSlapDuration = 0.36f;

	private const float reachOutStuckDuration = 0.36f;

	private const float returnHandsDuration = 1.5f;

	private const float cooldownScaleDuration = 30f;

	private const float handGrowDuration = 0.33f;

	private const float reachRotDuration = 0.3f;

	private const float returnRotDuration = 1.5f;

	private const float handBendDuration = 1.5f;

	private const float bodyAvoidDuration = 0.3f;

	[Header("Hand animators")]
	public Animator leftHandAnimator;

	public Animator rightHandAnimator;

	public List<FingerSpring> rightFingers = new List<FingerSpring>();

	public List<FingerSpring> leftFingers = new List<FingerSpring>();

	[Min(0.01f)]
	public float fingerSpringSpeed = 15f;

	[Range(0f, 2f)]
	public float fingerSpringDamping = 0.5f;

	public float fingerShakeForce = 50f;

	public float fingerIdleJiggleAmount = 2f;

	public float fingerIdleJiggleSpeed = 1.5f;

	public float fingerReachSpeedMultiplier = 4.8f;

	public float fingerReachAmountMultiplier = 1.2f;

	[Range(0f, 1f)]
	public float fingerSlapDampening = 0.15f;

	public AnimationCurve moveBackSpikeCurve = new AnimationCurve(new Keyframe[3]
	{
		new Keyframe(0f, 0f),
		new Keyframe(0.5f, 1f),
		new Keyframe(1f, 0f)
	});

	public float moveBackSpikeSpeed = 22f;

	public float fingerClapForce = 200f;

	public float fingerPostSlapJiggleSpeed = 45f;

	public float fingerPostSlapJiggleAmount = 22f;

	public float postSlapVibrationDuration = 1f;

	[Space]
	[Header("COLLIDERS")]
	public Collider topCollider;

	public List<Collider> crouchColliders = new List<Collider>();

	public List<Transform> shootingColliders = new List<Transform>();

	[Header("Collision Checkers (From Top to Bottom)")]
	public List<Transform> collisionCheckers = new List<Transform>();

	[Header("Hurt Collider")]
	public GameObject hurtCollider;

	public GameObject hurtColliderWave;

	[Space]
	[Header("Hand movement range")]
	public Transform handArea;

	public Transform handAreaUnder;

	public Transform handAreaUnderSlapReady;

	[Space]
	private Quaternion horizontalRotationTarget = Quaternion.identity;

	public SpringQuaternion horizontalRotationSpring;

	[Header("Hair Springs")]
	public SpringQuaternion hairSpring1 = new SpringQuaternion();

	public Transform hairPivot1;

	public Transform hairTarget1;

	public SpringQuaternion hairSpring2 = new SpringQuaternion();

	public Transform hairPivot2;

	public Transform hairTarget2;

	public SpringQuaternion hairSpring3 = new SpringQuaternion();

	public Transform hairPivot3;

	public Transform hairTarget3;

	public SpringQuaternion hairSpring4 = new SpringQuaternion();

	public Transform hairPivot4;

	public Transform hairTarget4;

	[HideInInspector]
	public State currentState;

	[Space]
	public GameObject screenVeinEffect;

	private HurtCollider hurtColliderScript;

	private HurtCollider hurtColliderWaveScript;

	private State previousState;

	private PlayerAvatar actualPlayerTarget;

	private PlayerAvatar playerTarget;

	private PlayerAvatar playerTargetPrevious;

	private Enemy enemy;

	private PhotonView photonView;

	private GameObject activeCollider;

	private EnemyShadowScreenVeinEffect activeVeinEffect;

	private List<float> torsoBends = new List<float> { 57f, 88f, 130f };

	private List<float> headBends = new List<float> { -79f, -100f, -108f };

	private List<float> neckBends = new List<float> { 21f, 18f, -20f };

	private int bendState;

	private bool stateImpulse = true;

	private bool closeEnoughToLook;

	private bool seesTarget = true;

	private bool closeEnoughToReachOut;

	private bool closeEnoughToSlap;

	private bool bendStateChangedCollider;

	private bool stateChangedClient;

	private bool reachDownToPlayer;

	private bool isStuckAttacking;

	private bool annoyed;

	private bool skipTargetTell;

	private bool seesTargetPrevious = true;

	private bool slapNetValid;

	private bool firstTimeColliderCheck;

	private bool reachingActive;

	private float handGrowEntry;

	private float reachAnimTimer;

	private float returnAnimTimer;

	private float handGrowAnimTimer;

	private State previousReachState;

	private float reachPosCurveTPrev;

	private float reachScaleCurveTPrev;

	private float slapScaleCurveTPrev;

	private float returnPosCurveTPrev;

	private float returnScaleCurveTPrev;

	private float reachRotCurveTPrev;

	private float returnRotCurveTPrev;

	private int previousBendStateForHands = -1;

	private float reachInitialDistance;

	private float postSlapVibrationTimer;

	private float rightWristLastZOffset;

	private float leftWristLastZOffset;

	private float rightWristLastYOffset;

	private float leftWristLastYOffset;

	private float bodyAvoidRightTimer;

	private float bodyAvoidLeftTimer;

	private float bodyAvoidRightCurveTPrev;

	private float bodyAvoidLeftCurveTPrev;

	private Vector3 originalRightWristPosition;

	private Vector3 originalRightWristRotation;

	private Vector3 originalLeftWristPosition;

	private Vector3 originalLeftWristRotation;

	private Vector3 rightHandSlapLocation;

	private Vector3 leftHandSlapLocation;

	private Vector3 rightWristSlapRotation = new Vector3(6.04f, -12f, 354f);

	private Vector3 leftWristSlapRotation = new Vector3(6.45f, 12f, 9f);

	private Vector3 agentDestination;

	private Vector3 stuckAttackTarget;

	private List<Vector3> rightBendHandPoses = new List<Vector3>
	{
		new Vector3(0.17f, 2.05f, 0.3f),
		new Vector3(0.185f, 1.9f, 0.5f),
		new Vector3(0.25f, 1.6f, 0.7f)
	};

	private List<Vector3> leftBendHandPoses = new List<Vector3>
	{
		new Vector3(-0.17f, 2.05f, 0.3f),
		new Vector3(-0.185f, 1.9f, 0.5f),
		new Vector3(-0.25f, 1.6f, 0.7f)
	};

	private float stateTimer;

	private float stateTimerClient;

	private float defaultBodyAvoidRadius;

	private float handMoveDistance = 3f;

	private float slapDistance = 1.5f;

	private float slapDuration = 0.3f;

	private float torsoBendingSpeed = 1.7f;

	private float maxHandSize = 3f;

	private float distanceFromPlayer;

	private float postStunTimer;

	private float noSeeTimer;

	private float annoyedTimer;

	private float annoyedFollowTimer;

	private float waveColliderActiveTime;

	private int stuckAttackAttempts;

	private double slapStartTimeNetwork;

	private bool visionBlocked;

	private float visionBlockedCheckTime;

	private void Awake()
	{
		//IL_0041: Unknown result type (might be due to invalid IL or missing references)
		//IL_0046: Unknown result type (might be due to invalid IL or missing references)
		//IL_0052: Unknown result type (might be due to invalid IL or missing references)
		//IL_0057: Unknown result type (might be due to invalid IL or missing references)
		//IL_0063: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_0074: Unknown result type (might be due to invalid IL or missing references)
		//IL_0079: Unknown result type (might be due to invalid IL or missing references)
		enemy = ((Component)this).GetComponent<Enemy>();
		photonView = ((Component)this).GetComponent<PhotonView>();
		hurtColliderScript = hurtCollider.GetComponent<HurtCollider>();
		hurtColliderWaveScript = hurtColliderWave.GetComponent<HurtCollider>();
		originalRightWristPosition = rightWristPivot.localPosition;
		originalRightWristRotation = rightWristPivot.localEulerAngles;
		originalLeftWristPosition = leftWristPivot.localPosition;
		originalLeftWristRotation = leftWristPivot.localEulerAngles;
		activeCollider = ((Component)topCollider).gameObject;
		previousState = currentState;
		if (springPoseAnimator.bodyAvoidRadius <= 0f)
		{
			springPoseAnimator.bodyAvoidRadius = 1f;
		}
		if (!Object.op_Implicit((Object)(object)springPoseAnimator.bodyAvoidCenter))
		{
			springPoseAnimator.bodyAvoidCenter = ((Component)this).transform;
		}
		defaultBodyAvoidRadius = springPoseAnimator.bodyAvoidRadius;
	}

	private void Start()
	{
		//IL_0007: Unknown result type (might be due to invalid IL or missing references)
		//IL_0018: Unknown result type (might be due to invalid IL or missing references)
		//IL_0029: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Unknown result type (might be due to invalid IL or missing references)
		//IL_003f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0044: Unknown result type (might be due to invalid IL or missing references)
		//IL_0054: Unknown result type (might be due to invalid IL or missing references)
		//IL_0064: Unknown result type (might be due to invalid IL or missing references)
		rightWristPivot.localPosition = originalRightWristPosition;
		leftWristPivot.localPosition = originalLeftWristPosition;
		rightWristPivot.localRotation = Quaternion.Euler(originalRightWristRotation);
		leftWristPivot.localRotation = Quaternion.Euler(originalLeftWristRotation);
		rightWristPivot.localScale = Vector3.one;
		leftWristPivot.localScale = Vector3.one;
		rightHandAnimator.Play("SlapHand", 0, 0f);
		rightHandAnimator.speed = 0f;
		leftHandAnimator.Play("SlapHand", 0, 0f);
		leftHandAnimator.speed = 0f;
		StretchLimbs();
	}

	private void Update()
	{
		//IL_0047: Unknown result type (might be due to invalid IL or missing references)
		//IL_0057: Unknown result type (might be due to invalid IL or missing references)
		distanceFromPlayer = DistanceFromPlayer();
		closeEnoughToReachOut = distanceFromPlayer < handMoveDistance;
		closeEnoughToLook = distanceFromPlayer < 7f;
		reachDownToPlayer = closeEnoughToReachOut && ((Component)playerTarget).transform.position.y - ((Component)this).transform.position.y < 0.2f;
		stateChangedClient = false;
		if (previousState != currentState)
		{
			stateChangedClient = true;
			previousState = currentState;
			stateTimerClient = 0f;
		}
		if (postStunTimer > 0f)
		{
			postStunTimer -= Time.deltaTime;
		}
		stateTimerClient += Time.deltaTime;
		if ((Object)(object)playerTarget != (Object)(object)playerTargetPrevious)
		{
			if (!skipTargetTell)
			{
				if (Object.op_Implicit((Object)(object)playerTargetPrevious) && playerTargetPrevious.isLocal && (!Object.op_Implicit((Object)(object)playerTarget) || !playerTarget.isLocal))
				{
					PlayerTargetStopTell();
				}
				else if (Object.op_Implicit((Object)(object)playerTarget) && playerTarget.isLocal)
				{
					PlayerTargetTell();
				}
			}
			playerTargetPrevious = playerTarget;
			skipTargetTell = false;
		}
		BendLogic();
		GeneralRotationLogic();
		SpringLogic();
		HandLogic();
		anim.TurnSoundLogic(headBend, enemy.Rigidbody.rb, torsoBend);
		if (currentState == State.Slap)
		{
			if (stateChangedClient)
			{
				anim.ToggleWooshLines(_state: true);
			}
			Slap();
		}
		else
		{
			if (hurtCollider.activeSelf)
			{
				hurtCollider.SetActive(false);
			}
			if (hurtColliderWave.activeSelf && waveColliderActiveTime > 0f)
			{
				waveColliderActiveTime -= Time.deltaTime;
				if (waveColliderActiveTime <= 0f)
				{
					hurtColliderWave.SetActive(false);
					hurtColliderWaveScript.playerLogic = true;
				}
			}
			anim.ToggleWooshLines(_state: false);
		}
		if (!SemiFunc.IsMasterClientOrSingleplayer())
		{
			return;
		}
		if (closeEnoughToReachOut)
		{
			if (!VisionBlocked())
			{
				noSeeTimer = 0f;
			}
			else
			{
				noSeeTimer += Time.deltaTime;
			}
			seesTarget = noSeeTimer < 1f;
		}
		else
		{
			seesTarget = false;
			noSeeTimer = 1f;
		}
		if (seesTarget != seesTargetPrevious && closeEnoughToReachOut)
		{
			seesTargetPrevious = seesTarget;
			if (SemiFunc.IsMultiplayer())
			{
				photonView.RPC("UpdateSeesTargetRPC", (RpcTarget)1, new object[1] { seesTarget });
			}
		}
		if (annoyedTimer > 0f)
		{
			annoyedTimer -= Time.deltaTime;
		}
		if (enemy.CurrentState == EnemyState.Despawn)
		{
			UpdateState(State.Despawn);
		}
		else if (enemy.IsStunned())
		{
			UpdateState(State.Stun);
		}
		else if (currentState == State.Follow && (!Object.op_Implicit((Object)(object)playerTarget) || playerTarget.isDisabled))
		{
			UpdateState(State.ChooseTarget);
		}
		switch (currentState)
		{
		case State.Spawn:
			StateSpawn();
			break;
		case State.Despawn:
			StateDespawn();
			break;
		case State.Follow:
			StateFollow();
			break;
		case State.Stun:
			StateStun();
			break;
		case State.ChooseTarget:
			StateChooseTarget();
			break;
		case State.Slap:
			StateSlap();
			break;
		case State.CoolDown:
			StateCoolDown();
			break;
		case State.StuckAttack:
			StateStuckAttack();
			break;
		case State.Leave:
			StateLeave();
			break;
		}
	}

	private void UpdateState(State _nextState)
	{
		//IL_0078: Unknown result type (might be due to invalid IL or missing references)
		//IL_007d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0084: Unknown result type (might be due to invalid IL or missing references)
		//IL_0089: Unknown result type (might be due to invalid IL or missing references)
		//IL_009c: Unknown result type (might be due to invalid IL or missing references)
		//IL_009d: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c7: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d0: Unknown result type (might be due to invalid IL or missing references)
		if (!SemiFunc.IsMasterClientOrSingleplayer() || _nextState == currentState)
		{
			return;
		}
		SemiLogger.LogMonika("Change state to : " + _nextState);
		stateImpulse = true;
		currentState = _nextState;
		if (GameManager.Multiplayer())
		{
			photonView.RPC("UpdateStateRPC", (RpcTarget)1, new object[1] { _nextState });
		}
		if (_nextState == State.Slap)
		{
			Vector3 localPosition = rightWristPivot.localPosition;
			Vector3 localPosition2 = leftWristPivot.localPosition;
			double num = PhotonNetwork.Time + 0.06;
			ApplySlapStart(num, localPosition, localPosition2);
			if (GameManager.Multiplayer())
			{
				photonView.RPC("StartSlapRPC", (RpcTarget)1, new object[3] { num, localPosition, localPosition2 });
			}
		}
	}

	[PunRPC]
	private void UpdateStateRPC(State _nextState, PhotonMessageInfo _info = default(PhotonMessageInfo))
	{
		//IL_0000: Unknown result type (might be due to invalid IL or missing references)
		if (SemiFunc.MasterOnlyRPC(_info))
		{
			currentState = _nextState;
		}
	}

	private void UpdatePlayerTarget(PlayerAvatar _player)
	{
		if (!SemiFunc.IsMasterClientOrSingleplayer())
		{
			return;
		}
		if (SemiFunc.IsMultiplayer() && (Object)(object)_player != (Object)(object)playerTarget)
		{
			int num = -1;
			if (Object.op_Implicit((Object)(object)_player))
			{
				num = _player.photonView.ViewID;
			}
			photonView.RPC("UpdatePlayerTargetRPC", (RpcTarget)1, new object[2] { num, skipTargetTell });
		}
		playerTarget = _player;
	}

	[PunRPC]
	private void UpdatePlayerTargetRPC(int photonViewID, bool _skipTell, PhotonMessageInfo _info = default(PhotonMessageInfo))
	{
		//IL_0000: Unknown result type (might be due to invalid IL or missing references)
		if (SemiFunc.MasterOnlyRPC(_info))
		{
			skipTargetTell = _skipTell;
			playerTarget = SemiFunc.PlayerAvatarGetFromPhotonID(photonViewID);
		}
	}

	private void UpdateBendState(int _bendState)
	{
		//IL_003e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0044: Unknown result type (might be due to invalid IL or missing references)
		if (SemiFunc.IsMasterClientOrSingleplayer() && _bendState != bendState)
		{
			if (SemiFunc.IsMultiplayer())
			{
				photonView.RPC("UpdateBendStateRPC", (RpcTarget)0, new object[1] { _bendState });
			}
			else
			{
				UpdateBendStateRPC(_bendState);
			}
			bendStateChangedCollider = true;
			firstTimeColliderCheck = true;
		}
	}

	[PunRPC]
	private void UpdateBendStateRPC(int _bendState, PhotonMessageInfo _info = default(PhotonMessageInfo))
	{
		//IL_0000: Unknown result type (might be due to invalid IL or missing references)
		if (!SemiFunc.MasterOnlyRPC(_info))
		{
			return;
		}
		bendState = _bendState;
		if (activeCollider.activeSelf)
		{
			activeCollider.SetActive(false);
		}
		foreach (Transform shootingCollider in shootingColliders)
		{
			if (((Component)shootingCollider).gameObject.activeSelf)
			{
				((Component)shootingCollider).gameObject.SetActive(false);
			}
		}
		if (bendState != -1)
		{
			((Component)shootingColliders[bendState]).gameObject.SetActive(true);
		}
	}

	private void EnableHurtCollider(Vector3 _pos)
	{
		//IL_0031: Unknown result type (might be due to invalid IL or missing references)
		//IL_0023: Unknown result type (might be due to invalid IL or missing references)
		if (SemiFunc.IsMasterClientOrSingleplayer())
		{
			if (SemiFunc.IsMultiplayer())
			{
				photonView.RPC("EnableHurtColliderRPC", (RpcTarget)0, new object[1] { _pos });
			}
			else
			{
				HurtColliderLogic(_pos);
			}
		}
	}

	private IEnumerator EnableWaveColliderDelayed(Vector3 _pos)
	{
		//IL_000e: Unknown result type (might be due to invalid IL or missing references)
		//IL_000f: Unknown result type (might be due to invalid IL or missing references)
		yield return (object)new WaitForSeconds(0.06f);
		hurtColliderWave.transform.position = _pos + ((Component)this).transform.forward * 1f;
		hurtColliderWave.SetActive(true);
		waveColliderActiveTime = 0.2f;
	}

	[PunRPC]
	private void EnableHurtColliderRPC(Vector3 _pos, PhotonMessageInfo _info = default(PhotonMessageInfo))
	{
		//IL_0000: Unknown result type (might be due to invalid IL or missing references)
		//IL_000a: Unknown result type (might be due to invalid IL or missing references)
		if (SemiFunc.MasterOnlyRPC(_info))
		{
			HurtColliderLogic(_pos);
		}
	}

	private void HurtColliderLogic(Vector3 _pos)
	{
		//IL_000b: Unknown result type (might be due to invalid IL or missing references)
		//IL_001f: Unknown result type (might be due to invalid IL or missing references)
		//IL_003c: Unknown result type (might be due to invalid IL or missing references)
		//IL_006b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0076: Unknown result type (might be due to invalid IL or missing references)
		//IL_007b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0085: Unknown result type (might be due to invalid IL or missing references)
		//IL_008a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0092: Unknown result type (might be due to invalid IL or missing references)
		//IL_0093: Unknown result type (might be due to invalid IL or missing references)
		//IL_0098: Unknown result type (might be due to invalid IL or missing references)
		hurtCollider.transform.position = _pos;
		hurtCollider.SetActive(true);
		((MonoBehaviour)this).StartCoroutine(EnableWaveColliderDelayed(_pos));
		anim.PlayClapSound();
		anim.PlaySlapParticles(_pos);
		anim.ClapCameraShake();
		ShakeFingers(fingerClapForce);
		postSlapVibrationTimer = postSlapVibrationDuration;
		Vector3 val = (rightWristPivot.position + leftWristPivot.position) * 0.5f;
		handsLockPosLocal = ((Component)this).transform.InverseTransformPoint(val);
		handsLockTimer = handsLockDuration;
	}

	[PunRPC]
	private void ToggleTopColliderRPC(bool _active, int _bendState, PhotonMessageInfo _info = default(PhotonMessageInfo))
	{
		//IL_0000: Unknown result type (might be due to invalid IL or missing references)
		if (SemiFunc.MasterOnlyRPC(_info))
		{
			Collider val = ((_bendState != -1) ? crouchColliders[_bendState] : topCollider);
			((Component)val).gameObject.SetActive(_active);
			activeCollider = ((Component)val).gameObject;
		}
	}

	private void ApplySlapStart(double _slapStartTimeNetwork, Vector3 _rightStartLocal, Vector3 _leftStartLocal)
	{
		//IL_001d: Unknown result type (might be due to invalid IL or missing references)
		//IL_001e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_0025: Unknown result type (might be due to invalid IL or missing references)
		//IL_004c: Unknown result type (might be due to invalid IL or missing references)
		slapStartTimeNetwork = _slapStartTimeNetwork;
		slapNetValid = PhotonNetwork.IsConnected && PhotonNetwork.InRoom;
		rightHandSlapLocation = _rightStartLocal;
		leftHandSlapLocation = _leftStartLocal;
		anim.ToggleWooshLines(_state: true);
		anim.clapTell.Play(enemy.CenterTransform.position);
	}

	[PunRPC]
	private void StartSlapRPC(double t0, Vector3 rightStartLocal, Vector3 leftStartLocal, PhotonMessageInfo info)
	{
		//IL_0000: Unknown result type (might be due to invalid IL or missing references)
		//IL_000c: Unknown result type (might be due to invalid IL or missing references)
		//IL_000d: Unknown result type (might be due to invalid IL or missing references)
		if (SemiFunc.MasterOnlyRPC(info))
		{
			ApplySlapStart(t0, rightStartLocal, leftStartLocal);
		}
	}

	[PunRPC]
	private void UpdateSeesTargetRPC(bool _seesTarget, PhotonMessageInfo _info = default(PhotonMessageInfo))
	{
		//IL_0000: Unknown result type (might be due to invalid IL or missing references)
		if (SemiFunc.MasterOnlyRPC(_info))
		{
			seesTarget = _seesTarget;
		}
	}

	private void StateSpawn()
	{
		if (stateImpulse)
		{
			stateImpulse = false;
			stateTimer = 2f;
			springPoseAnimator.CullingVisualOverride(2f);
			skipTargetTell = false;
			annoyed = false;
			annoyedFollowTimer = 0f;
			actualPlayerTarget = null;
			playerTargetPrevious = null;
			UpdatePlayerTarget(null);
		}
		stateTimer -= Time.deltaTime;
		if (stateTimer <= 0f && !SemiFunc.EnemySpawnIdlePause())
		{
			if (!Object.op_Implicit((Object)(object)playerTarget))
			{
				UpdateState(State.ChooseTarget);
			}
			else
			{
				UpdateState(State.Follow);
			}
		}
	}

	private void StateDespawn()
	{
		if (stateImpulse)
		{
			stateImpulse = false;
			ResetNavMesh();
		}
	}

	private void StateStun()
	{
		if (stateImpulse)
		{
			stateImpulse = false;
			ResetNavMesh();
			UpdatePlayerTarget(null);
		}
		if (!enemy.IsStunned())
		{
			postStunTimer = 2f;
			UpdateState(State.ChooseTarget);
		}
	}

	private void StateFollow()
	{
		//IL_019f: Unknown result type (might be due to invalid IL or missing references)
		//IL_020d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0212: Unknown result type (might be due to invalid IL or missing references)
		//IL_0218: Unknown result type (might be due to invalid IL or missing references)
		//IL_021d: Unknown result type (might be due to invalid IL or missing references)
		//IL_01e6: Unknown result type (might be due to invalid IL or missing references)
		//IL_01eb: Unknown result type (might be due to invalid IL or missing references)
		//IL_0120: Unknown result type (might be due to invalid IL or missing references)
		//IL_012b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0130: Unknown result type (might be due to invalid IL or missing references)
		//IL_0135: Unknown result type (might be due to invalid IL or missing references)
		//IL_0138: Unknown result type (might be due to invalid IL or missing references)
		//IL_013d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0145: Unknown result type (might be due to invalid IL or missing references)
		//IL_014a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0150: Unknown result type (might be due to invalid IL or missing references)
		//IL_0155: Unknown result type (might be due to invalid IL or missing references)
		//IL_015a: Unknown result type (might be due to invalid IL or missing references)
		//IL_016b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0247: Unknown result type (might be due to invalid IL or missing references)
		//IL_024c: Unknown result type (might be due to invalid IL or missing references)
		//IL_022f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0235: Unknown result type (might be due to invalid IL or missing references)
		if (stateImpulse)
		{
			if (!isStuckAttacking)
			{
				enemy.Rigidbody.notMovingTimer = 0f;
			}
			else
			{
				enemy.Rigidbody.notMovingTimer = 1f;
			}
			stateImpulse = false;
			stateTimer = 5f;
		}
		if (annoyed && annoyedFollowTimer > 0f)
		{
			if (currentState == State.Leave)
			{
				annoyedFollowTimer = 0f;
				annoyed = false;
			}
			else
			{
				annoyedFollowTimer -= Time.deltaTime;
				if (annoyedFollowTimer <= 0f)
				{
					UpdateState(State.ChooseTarget);
					return;
				}
			}
		}
		if (!enemy.OnScreen.OnScreenAny && enemy.PlayerDistance.PlayerDistanceClosest >= 5f && SemiFunc.EnemyForceLeave(enemy))
		{
			UpdateState(State.Leave);
			return;
		}
		if (Object.op_Implicit((Object)(object)playerTarget))
		{
			if (reachDownToPlayer && distanceFromPlayer < 1f)
			{
				if (!HandsInPositionToSlap())
				{
					Vector3 val = ((Component)playerTarget).transform.position - ((Component)this).transform.position;
					Vector3 normalized = val.normalized;
					agentDestination = ((Component)this).transform.position - normalized * 3f;
					enemy.NavMeshAgent.SetDestination(agentDestination);
				}
				else
				{
					enemy.NavMeshAgent.ResetPath();
				}
			}
			else
			{
				enemy.NavMeshAgent.SetDestination(((Component)playerTarget).transform.position);
			}
		}
		if (enemy.Rigidbody.notMovingTimer > 3f)
		{
			if (!isStuckAttacking)
			{
				AttackNearestPhysObjectOrFollow();
				return;
			}
			stuckAttackAttempts++;
			if (stuckAttackAttempts >= 5)
			{
				stuckAttackTarget = Vector3.zero;
				stuckAttackAttempts = 0;
				isStuckAttacking = false;
				UpdateState(State.Leave);
				return;
			}
			stuckAttackTarget = SemiFunc.EnemyGetNearestPhysObject(enemy);
			if (!(stuckAttackTarget == Vector3.zero) && !(Vector3.Distance(((Component)this).transform.position, stuckAttackTarget) > 5f))
			{
				UpdateState(State.StuckAttack);
				return;
			}
			stuckAttackTarget = Vector3.zero;
			stuckAttackAttempts = 0;
			isStuckAttacking = false;
		}
		if (enemy.Rigidbody.notMovingTimer > 2f)
		{
			stateTimer -= Time.deltaTime;
			if (stateTimer < 0f)
			{
				UpdateState(State.Leave);
				return;
			}
		}
		if (HandsInPositionToSlap() || (HandsInDownPositionToSlap() && postStunTimer <= 0f))
		{
			isStuckAttacking = false;
			UpdateState(State.Slap);
		}
	}

	private void StateSlap()
	{
		if (stateImpulse)
		{
			ResetNavMesh();
			stateTimer = 0f;
			stateImpulse = false;
		}
		if (slapNetValid)
		{
			if (NetNow() >= slapStartTimeNetwork + (double)slapDuration)
			{
				UpdateState(State.CoolDown);
			}
			return;
		}
		stateTimer += Time.deltaTime;
		if (stateTimer >= slapDuration)
		{
			UpdateState(State.CoolDown);
		}
	}

	private void StateChooseTarget()
	{
		if (stateImpulse)
		{
			stateImpulse = false;
			stateTimer = 1f;
			if (annoyed && Object.op_Implicit((Object)(object)actualPlayerTarget) && !actualPlayerTarget.isDisabled)
			{
				skipTargetTell = true;
				UpdatePlayerTarget(actualPlayerTarget);
				annoyed = false;
				actualPlayerTarget = null;
			}
			else
			{
				List<PlayerAvatar> list = SemiFunc.PlayerGetList();
				int count = list.Count;
				int index = Random.Range(0, count);
				UpdatePlayerTarget(list[index]);
			}
			ResetNavMesh();
		}
		if (!Object.op_Implicit((Object)(object)playerTarget) || playerTarget.isDisabled)
		{
			stateImpulse = true;
		}
		stateTimer -= Time.deltaTime;
		if (stateTimer <= 0f)
		{
			UpdateState(State.Follow);
		}
	}

	private void StateCoolDown()
	{
		if (stateImpulse)
		{
			stateImpulse = false;
			if (isStuckAttacking)
			{
				stateTimer = 0f;
			}
			else
			{
				stateTimer = 2f;
			}
		}
		stateTimer -= Time.deltaTime;
		if (stateTimer <= 0f)
		{
			if (isStuckAttacking)
			{
				UpdateState(State.Follow);
			}
			else
			{
				UpdateState(State.ChooseTarget);
			}
		}
	}

	private void StateStuckAttack()
	{
		//IL_0033: Unknown result type (might be due to invalid IL or missing references)
		if (stateImpulse)
		{
			enemy.NavMeshAgent.ResetPath();
			enemy.NavMeshAgent.Warp(((Component)enemy.Rigidbody).transform.position);
			isStuckAttacking = true;
			stateTimer = 1.5f;
			stateImpulse = false;
		}
		enemy.NavMeshAgent.Stop(0.2f);
		stateTimer -= Time.deltaTime;
		if (stateTimer <= 0f)
		{
			UpdateState(State.Slap);
		}
	}

	private void StateLeave()
	{
		//IL_0106: Unknown result type (might be due to invalid IL or missing references)
		//IL_0116: Unknown result type (might be due to invalid IL or missing references)
		//IL_011c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0025: Unknown result type (might be due to invalid IL or missing references)
		//IL_0043: Unknown result type (might be due to invalid IL or missing references)
		//IL_0048: Unknown result type (might be due to invalid IL or missing references)
		//IL_0052: Unknown result type (might be due to invalid IL or missing references)
		//IL_0057: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0072: Unknown result type (might be due to invalid IL or missing references)
		//IL_0099: Unknown result type (might be due to invalid IL or missing references)
		//IL_009e: Unknown result type (might be due to invalid IL or missing references)
		if (stateImpulse)
		{
			stateImpulse = false;
			stateTimer = 30f;
			bool flag = false;
			LevelPoint levelPoint = SemiFunc.LevelPointGetFurthestFromPlayer(((Component)this).transform.position, 5f);
			NavMeshHit val = default;
			if (Object.op_Implicit((Object)(object)levelPoint) && NavMesh.SamplePosition(((Component)levelPoint).transform.position + Random.insideUnitSphere * 3f, ref val, 5f, -1) && Physics.Raycast(val.position, Vector3.down, 5f, LayerMask.GetMask(new string[1] { "Default" })))
			{
				agentDestination = val.position;
				flag = true;
			}
			if (!flag)
			{
				return;
			}
			SemiFunc.EnemyLeaveStart(enemy);
			enemy.Rigidbody.notMovingTimer = 0f;
			annoyedTimer = 5f;
			UpdatePlayerTarget(null);
		}
		enemy.NavMeshAgent.OverrideAgent(2.5f, 30f, 0.1f);
		enemy.NavMeshAgent.SetDestination(agentDestination);
		if (Vector3.Distance(((Component)this).transform.position, agentDestination) <= 1f)
		{
			if (stateTimer > 0f)
			{
				stateTimer -= Time.deltaTime;
				if (enemy.PlayerDistance.PlayerDistanceClosest <= 15f)
				{
					stateTimer = 0f;
				}
			}
			else if (Object.op_Implicit((Object)(object)playerTarget))
			{
				UpdateState(State.Follow);
			}
			else
			{
				UpdateState(State.ChooseTarget);
			}
		}
		else if (enemy.Rigidbody.notMovingTimer >= 3f)
		{
			AttackNearestPhysObjectOrFollow();
			if (enemy.Rigidbody.notMovingTimer >= 10f)
			{
				enemy.EnemyParent.SpawnedTimerSet(0f);
				UpdateState(State.Despawn);
			}
		}
	}

	public void OnSpawn()
	{
		if (SemiFunc.IsMasterClientOrSingleplayer() && SemiFunc.EnemySpawn(enemy))
		{
			UpdateState(State.Spawn);
		}
		anim.spawnTriggerImpulse = true;
	}

	public void OnTouchPlayer()
	{
		if (!((Object)(object)playerTarget == (Object)(object)enemy.Rigidbody.onTouchPlayerAvatar) || currentState == State.Leave)
		{
			GetAnnoyed(enemy.Rigidbody.onTouchPlayerAvatar);
		}
	}

	public void OnTouchPlayerGrabbedObject()
	{
		if (!((Object)(object)playerTarget == (Object)(object)enemy.Rigidbody.onTouchPlayerGrabbedObjectAvatar) || currentState == State.Leave)
		{
			GetAnnoyed(enemy.Rigidbody.onTouchPlayerGrabbedObjectAvatar);
		}
	}

	public void OnGrabbed()
	{
		if (!((Object)(object)playerTarget == (Object)(object)enemy.Rigidbody.onGrabbedPlayerAvatar) || currentState == State.Leave)
		{
			GetAnnoyed(enemy.Rigidbody.onGrabbedPlayerAvatar);
		}
	}

	public void OnHurt()
	{
		anim.PlayHurtSound();
		if (SemiFunc.IsMasterClientOrSingleplayer() && currentState == State.Leave)
		{
			if (Object.op_Implicit((Object)(object)playerTarget))
			{
				UpdateState(State.Follow);
			}
			else
			{
				UpdateState(State.ChooseTarget);
			}
		}
	}

	public void OnDeath()
	{
		//IL_001f: Unknown result type (might be due to invalid IL or missing references)
		//IL_004d: Unknown result type (might be due to invalid IL or missing references)
		GameDirector.instance.CameraShake.ShakeDistance(5f, 3f, 8f, ((Component)this).transform.position, 0.5f);
		GameDirector.instance.CameraImpact.ShakeDistance(5f, 3f, 8f, ((Component)this).transform.position, 0.1f);
		anim.PlayDeathParticles();
		anim.PlayDeathSound();
		if (SemiFunc.IsMasterClientOrSingleplayer())
		{
			UpdateState(State.Despawn);
			enemy.EnemyParent.SpawnedTimerSet(0f);
			enemy.EnemyParent.Despawn();
		}
	}

	private void BendLogic()
	{
		if (SemiFunc.PerSecond(5f, (Object)(object)this) && SemiFunc.IsMasterClientOrSingleplayer())
		{
			CheckBendState();
		}
		BendingColliderLogic();
		TorsoRotationLogic();
		NeckRotationLogic();
		ArmRotationLogic();
		HeadRotationLogic();
		EyeRotationLogic();
		FaceHairDown();
	}

	private void CheckBendState()
	{
		if (SemiFunc.IsMasterClientOrSingleplayer() && currentState != State.CoolDown)
		{
			int num = GetBendState();
			if (num != bendState)
			{
				UpdateBendState(num);
			}
		}
	}

	private int GetBendState()
	{
		//IL_003c: Unknown result type (might be due to invalid IL or missing references)
		if (reachDownToPlayer || currentState == State.Leave)
		{
			return 2;
		}
		for (int num = collisionCheckers.Count - 1; num >= 0; num--)
		{
			if (IsColliding(collisionCheckers[num], collisionCheckers[num].position))
			{
				return num;
			}
		}
		return -1;
	}

	private void BendingColliderLogic()
	{
		//IL_0053: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a6: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ac: Unknown result type (might be due to invalid IL or missing references)
		if (!bendStateChangedCollider || (!SemiFunc.PerSecond(1f, (Object)(object)this) && !firstTimeColliderCheck))
		{
			return;
		}
		firstTimeColliderCheck = false;
		Collider val = ((bendState != -1) ? crouchColliders[bendState] : topCollider);
		if (!IsCollidingCapsule(((Component)val).transform.position, ((Component)val).GetComponent<CapsuleCollider>()))
		{
			if (SemiFunc.IsMultiplayer())
			{
				photonView.RPC("ToggleTopColliderRPC", (RpcTarget)0, new object[2] { true, bendState });
			}
			else
			{
				ToggleTopColliderRPC(_active: true, bendState);
			}
			bendStateChangedCollider = false;
		}
	}

	private void TorsoRotationLogic()
	{
		//IL_003a: Unknown result type (might be due to invalid IL or missing references)
		//IL_004a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0050: Unknown result type (might be due to invalid IL or missing references)
		float num = 0f;
		float num2 = Time.deltaTime * torsoBendingSpeed;
		if (bendState != -1)
		{
			num = torsoBends[bendState];
		}
		torsoBend.localRotation = Quaternion.Slerp(torsoBend.localRotation, Quaternion.Euler(num, 0f, 0f), num2);
	}

	private void NeckRotationLogic()
	{
		//IL_002d: Unknown result type (might be due to invalid IL or missing references)
		//IL_003d: Unknown result type (might be due to invalid IL or missing references)
		//IL_004e: Unknown result type (might be due to invalid IL or missing references)
		float num = 0f;
		if (bendState != -1)
		{
			num = neckBends[bendState];
		}
		neckBend.localRotation = Quaternion.Slerp(neckBend.localRotation, Quaternion.Euler(num, 0f, 0f), Time.deltaTime * torsoBendingSpeed);
	}

	private void HeadRotationLogic()
	{
		//IL_0036: Unknown result type (might be due to invalid IL or missing references)
		//IL_003b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0009: Unknown result type (might be due to invalid IL or missing references)
		//IL_0029: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0033: Unknown result type (might be due to invalid IL or missing references)
		//IL_0083: Unknown result type (might be due to invalid IL or missing references)
		//IL_0088: Unknown result type (might be due to invalid IL or missing references)
		//IL_0095: Unknown result type (might be due to invalid IL or missing references)
		//IL_004e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0053: Unknown result type (might be due to invalid IL or missing references)
		//IL_0061: Unknown result type (might be due to invalid IL or missing references)
		//IL_0071: Unknown result type (might be due to invalid IL or missing references)
		//IL_0076: Unknown result type (might be due to invalid IL or missing references)
		Quaternion val = ((bendState == -1) ? Quaternion.identity : (Quaternion.identity * Quaternion.Euler(headBends[bendState], 0f, 0f)));
		if (closeEnoughToLook && currentState != State.Leave)
		{
			Vector3 lookTargetWorld = GetLookTargetWorld();
			val = BuildClampedLocalRotation(headBend, torsoBend, lookTargetWorld, 80f, 50f, 50f);
		}
		headBend.localRotation = Quaternion.Slerp(headBend.localRotation, val, Time.deltaTime * headTurnSpeed);
	}

	private void EyeRotationLogic()
	{
		//IL_0062: Unknown result type (might be due to invalid IL or missing references)
		//IL_0067: Unknown result type (might be due to invalid IL or missing references)
		//IL_0075: Unknown result type (might be due to invalid IL or missing references)
		//IL_0085: Unknown result type (might be due to invalid IL or missing references)
		//IL_008a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0097: Unknown result type (might be due to invalid IL or missing references)
		//IL_009c: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a9: Unknown result type (might be due to invalid IL or missing references)
		//IL_00bf: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c4: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d1: Unknown result type (might be due to invalid IL or missing references)
		//IL_0014: Unknown result type (might be due to invalid IL or missing references)
		//IL_0019: Unknown result type (might be due to invalid IL or missing references)
		//IL_002a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0040: Unknown result type (might be due to invalid IL or missing references)
		//IL_0045: Unknown result type (might be due to invalid IL or missing references)
		//IL_0056: Unknown result type (might be due to invalid IL or missing references)
		if (!closeEnoughToLook)
		{
			leftEyePivot.localRotation = Quaternion.Slerp(leftEyePivot.localRotation, Quaternion.identity, Time.deltaTime * eyeTurnSpeed);
			rightEyePivot.localRotation = Quaternion.Slerp(rightEyePivot.localRotation, Quaternion.identity, Time.deltaTime * eyeTurnSpeed);
			return;
		}
		Vector3 lookTargetWorld = GetLookTargetWorld();
		Quaternion val = BuildClampedLocalRotation(leftEyePivot, headBend, lookTargetWorld, 25f, 20f, 25f);
		leftEyePivot.localRotation = Quaternion.Slerp(leftEyePivot.localRotation, val, Time.deltaTime * eyeTurnSpeed);
		rightEyePivot.localRotation = Quaternion.Slerp(rightEyePivot.localRotation, val, Time.deltaTime * eyeTurnSpeed);
	}

	private void GeneralRotationLogic()
	{
		//IL_0175: Unknown result type (might be due to invalid IL or missing references)
		//IL_017f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0019: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0044: Unknown result type (might be due to invalid IL or missing references)
		//IL_0059: Unknown result type (might be due to invalid IL or missing references)
		//IL_005e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0063: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_007e: Unknown result type (might be due to invalid IL or missing references)
		//IL_008d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0126: Unknown result type (might be due to invalid IL or missing references)
		//IL_0131: Unknown result type (might be due to invalid IL or missing references)
		//IL_0136: Unknown result type (might be due to invalid IL or missing references)
		//IL_013b: Unknown result type (might be due to invalid IL or missing references)
		//IL_00da: Unknown result type (might be due to invalid IL or missing references)
		//IL_00df: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e4: Unknown result type (might be due to invalid IL or missing references)
		//IL_00fa: Unknown result type (might be due to invalid IL or missing references)
		//IL_0109: Unknown result type (might be due to invalid IL or missing references)
		//IL_0159: Unknown result type (might be due to invalid IL or missing references)
		//IL_015e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0163: Unknown result type (might be due to invalid IL or missing references)
		if (currentState != State.CoolDown)
		{
			if (currentState == State.StuckAttack)
			{
				if (Vector3.Distance(stuckAttackTarget, ((Component)enemy.Rigidbody).transform.position) > 0.1f)
				{
					horizontalRotationTarget = Quaternion.LookRotation(stuckAttackTarget - ((Component)enemy.Rigidbody).transform.position);
					horizontalRotationTarget.eulerAngles = new Vector3(0f, horizontalRotationTarget.eulerAngles.y, 0f);
				}
			}
			else if (enemy.NavMeshAgent.AgentVelocity.sqrMagnitude > 0.01f && (!closeEnoughToReachOut || currentState == State.Leave))
			{
				horizontalRotationTarget = Quaternion.LookRotation(enemy.NavMeshAgent.AgentVelocity.normalized);
				horizontalRotationTarget.eulerAngles = new Vector3(0f, horizontalRotationTarget.eulerAngles.y, 0f);
			}
			else if (closeEnoughToLook || closeEnoughToReachOut)
			{
				Vector3 val = GetLookTargetWorld() - ((Component)this).transform.position;
				val.y = 0f;
				if (val.sqrMagnitude > 0.0001f)
				{
					horizontalRotationTarget = Quaternion.LookRotation(val.normalized);
				}
			}
		}
		((Component)this).transform.rotation = SemiFunc.SpringQuaternionGet(horizontalRotationSpring, horizontalRotationTarget);
	}

	private void ArmRotationLogic()
	{
		//IL_000c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0022: Unknown result type (might be due to invalid IL or missing references)
		rightArmBend.position = rightArmPoint.position;
		leftArmBend.position = leftArmPoint.position;
	}

	private void FaceHairDown()
	{
		//IL_0006: Unknown result type (might be due to invalid IL or missing references)
		//IL_000b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0032: Unknown result type (might be due to invalid IL or missing references)
		//IL_0033: Unknown result type (might be due to invalid IL or missing references)
		//IL_0038: Unknown result type (might be due to invalid IL or missing references)
		//IL_0055: Unknown result type (might be due to invalid IL or missing references)
		//IL_0056: Unknown result type (might be due to invalid IL or missing references)
		//IL_005b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0078: Unknown result type (might be due to invalid IL or missing references)
		//IL_0079: Unknown result type (might be due to invalid IL or missing references)
		//IL_007e: Unknown result type (might be due to invalid IL or missing references)
		//IL_009b: Unknown result type (might be due to invalid IL or missing references)
		//IL_009c: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a1: Unknown result type (might be due to invalid IL or missing references)
		Vector3 forward = headBend.forward;
		forward.y = 0f;
		forward.Normalize();
		if (Object.op_Implicit((Object)(object)hairTarget1))
		{
			hairTarget1.rotation = Quaternion.LookRotation(forward, Vector3.up);
		}
		if (Object.op_Implicit((Object)(object)hairTarget2))
		{
			hairTarget2.rotation = Quaternion.LookRotation(forward, Vector3.up);
		}
		if (Object.op_Implicit((Object)(object)hairTarget3))
		{
			hairTarget3.rotation = Quaternion.LookRotation(forward, Vector3.up);
		}
		if (Object.op_Implicit((Object)(object)hairTarget4))
		{
			hairTarget4.rotation = Quaternion.LookRotation(forward, Vector3.up);
		}
	}

	private void HandLogic()
	{
		//IL_046e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0475: Unknown result type (might be due to invalid IL or missing references)
		//IL_047a: Unknown result type (might be due to invalid IL or missing references)
		//IL_047f: Unknown result type (might be due to invalid IL or missing references)
		//IL_04ad: Unknown result type (might be due to invalid IL or missing references)
		//IL_04b2: Unknown result type (might be due to invalid IL or missing references)
		//IL_04ba: Unknown result type (might be due to invalid IL or missing references)
		//IL_04d0: Unknown result type (might be due to invalid IL or missing references)
		//IL_04d5: Unknown result type (might be due to invalid IL or missing references)
		//IL_04da: Unknown result type (might be due to invalid IL or missing references)
		//IL_04e0: Unknown result type (might be due to invalid IL or missing references)
		//IL_04e5: Unknown result type (might be due to invalid IL or missing references)
		//IL_04ea: Unknown result type (might be due to invalid IL or missing references)
		//IL_04ec: Unknown result type (might be due to invalid IL or missing references)
		//IL_04f3: Unknown result type (might be due to invalid IL or missing references)
		//IL_04f8: Unknown result type (might be due to invalid IL or missing references)
		//IL_0500: Unknown result type (might be due to invalid IL or missing references)
		//IL_050e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0513: Unknown result type (might be due to invalid IL or missing references)
		//IL_0536: Unknown result type (might be due to invalid IL or missing references)
		//IL_054c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0551: Unknown result type (might be due to invalid IL or missing references)
		//IL_0556: Unknown result type (might be due to invalid IL or missing references)
		//IL_055c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0561: Unknown result type (might be due to invalid IL or missing references)
		//IL_0566: Unknown result type (might be due to invalid IL or missing references)
		//IL_0568: Unknown result type (might be due to invalid IL or missing references)
		//IL_056f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0574: Unknown result type (might be due to invalid IL or missing references)
		//IL_057c: Unknown result type (might be due to invalid IL or missing references)
		//IL_058b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0590: Unknown result type (might be due to invalid IL or missing references)
		//IL_05d7: Unknown result type (might be due to invalid IL or missing references)
		//IL_05e2: Unknown result type (might be due to invalid IL or missing references)
		//IL_05e7: Unknown result type (might be due to invalid IL or missing references)
		//IL_05f5: Unknown result type (might be due to invalid IL or missing references)
		//IL_05fa: Unknown result type (might be due to invalid IL or missing references)
		//IL_05fe: Unknown result type (might be due to invalid IL or missing references)
		//IL_0614: Unknown result type (might be due to invalid IL or missing references)
		//IL_0619: Unknown result type (might be due to invalid IL or missing references)
		//IL_061d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0336: Unknown result type (might be due to invalid IL or missing references)
		//IL_034c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0351: Unknown result type (might be due to invalid IL or missing references)
		//IL_0356: Unknown result type (might be due to invalid IL or missing references)
		//IL_035c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0361: Unknown result type (might be due to invalid IL or missing references)
		//IL_0368: Unknown result type (might be due to invalid IL or missing references)
		//IL_036d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0375: Unknown result type (might be due to invalid IL or missing references)
		//IL_0380: Unknown result type (might be due to invalid IL or missing references)
		//IL_0385: Unknown result type (might be due to invalid IL or missing references)
		//IL_03a5: Unknown result type (might be due to invalid IL or missing references)
		//IL_03bb: Unknown result type (might be due to invalid IL or missing references)
		//IL_03c0: Unknown result type (might be due to invalid IL or missing references)
		//IL_03c5: Unknown result type (might be due to invalid IL or missing references)
		//IL_03cb: Unknown result type (might be due to invalid IL or missing references)
		//IL_03d0: Unknown result type (might be due to invalid IL or missing references)
		//IL_03d7: Unknown result type (might be due to invalid IL or missing references)
		//IL_03dc: Unknown result type (might be due to invalid IL or missing references)
		//IL_03e4: Unknown result type (might be due to invalid IL or missing references)
		//IL_03f1: Unknown result type (might be due to invalid IL or missing references)
		//IL_03f6: Unknown result type (might be due to invalid IL or missing references)
		bool flag = currentState == State.Slap || currentState == State.StuckAttack || currentState == State.CoolDown || (currentState == State.Follow && closeEnoughToReachOut && postStunTimer <= 0f && seesTarget);
		bool flag2 = !flag || currentState == State.CoolDown;
		bool flag3 = currentState != previousReachState;
		bool num = flag && !reachingActive;
		bool flag4 = !flag && reachingActive;
		bool flag5 = (flag && reachingActive) & flag3;
		bool flag6 = flag2 & flag3;
		reachingActive = flag;
		if (num)
		{
			reachAnimTimer = 0f;
			handGrowAnimTimer = 0f;
			reachPosCurveTPrev = 0f;
			reachScaleCurveTPrev = 0f;
			reachRotCurveTPrev = 0f;
			rightWristLastZOffset = 0f;
			leftWristLastZOffset = 0f;
			rightWristLastYOffset = 0f;
			leftWristLastYOffset = 0f;
			CaptureReachInitialDistance();
		}
		else if (flag5)
		{
			reachAnimTimer = 0f;
			reachPosCurveTPrev = 0f;
			reachScaleCurveTPrev = 0f;
			if (currentState == State.Slap)
			{
				slapScaleCurveTPrev = 0f;
			}
			CaptureReachInitialDistance();
		}
		if (flag4)
		{
			returnAnimTimer = 0f;
			returnPosCurveTPrev = 0f;
			returnRotCurveTPrev = 0f;
			rightWristLastZOffset = 0f;
			leftWristLastZOffset = 0f;
			rightWristLastYOffset = 0f;
			leftWristLastYOffset = 0f;
		}
		if (bendState != previousBendStateForHands && !flag)
		{
			returnAnimTimer = 0f;
			returnPosCurveTPrev = 0f;
		}
		previousBendStateForHands = bendState;
		if (flag6)
		{
			returnScaleCurveTPrev = 0f;
			if (currentState == State.CoolDown)
			{
				returnAnimTimer = 0f;
				returnPosCurveTPrev = 0f;
			}
		}
		previousReachState = currentState;
		if (flag)
		{
			reachAnimTimer += Time.deltaTime;
			handGrowAnimTimer += Time.deltaTime;
			float num2 = Mathf.Clamp01(handGrowAnimTimer / 0.33f);
			handGrowEntry = handGrowCurve.Evaluate(num2);
		}
		else
		{
			handGrowEntry = 0f;
		}
		if (flag2)
		{
			returnAnimTimer += Time.deltaTime;
		}
		if (flag && currentState != State.CoolDown)
		{
			float num3 = IncrementalCurveFactor(reachRotCurve, handGrowAnimTimer, 0.3f, ref reachRotCurveTPrev);
			float num4 = Mathf.Clamp01(handGrowAnimTimer / 0.3f);
			float num5 = wristReachZCurve.Evaluate(num4) * wristZAmount;
			float num6 = 0f;
			if (currentState == State.Slap)
			{
				float num7 = (slapNetValid ? Mathf.Clamp01((float)((PhotonNetwork.Time - slapStartTimeNetwork) / (double)slapDuration)) : Mathf.Clamp01(stateTimerClient / slapDuration));
				num6 = slapYCurve.Evaluate(num7) * slapYAmount;
			}
			Quaternion val = Quaternion.Slerp(rightWristPivot.localRotation * Quaternion.Inverse(Quaternion.Euler(0f, rightWristLastYOffset, rightWristLastZOffset)), Quaternion.Euler(rightWristSlapRotation), num3);
			rightWristPivot.localRotation = val * Quaternion.Euler(0f, num6, num5);
			rightWristLastYOffset = num6;
			rightWristLastZOffset = num5;
			Quaternion val2 = Quaternion.Slerp(leftWristPivot.localRotation * Quaternion.Inverse(Quaternion.Euler(0f, leftWristLastYOffset, leftWristLastZOffset)), Quaternion.Euler(leftWristSlapRotation), num3);
			leftWristPivot.localRotation = val2 * Quaternion.Euler(0f, 0f - num6, 0f - num5);
			leftWristLastYOffset = 0f - num6;
			leftWristLastZOffset = 0f - num5;
		}
		else if (!flag)
		{
			float num8 = IncrementalCurveFactor(returnRotCurve, returnAnimTimer, 1.5f, ref returnRotCurveTPrev);
			float num9 = Mathf.Clamp01(returnAnimTimer / 1.5f);
			float num10 = wristReturnZCurve.Evaluate(num9) * wristZAmount;
			float num11 = IdleLoopValue();
			Quaternion val3 = Quaternion.Euler(idleHandsRotAmount * num11);
			Quaternion val4 = Quaternion.Euler(idleHandsRotAmount.x * num11, (0f - idleHandsRotAmount.y) * num11, (0f - idleHandsRotAmount.z) * num11);
			Quaternion val5 = Quaternion.Slerp(rightWristPivot.localRotation * Quaternion.Inverse(Quaternion.Euler(0f, rightWristLastYOffset, rightWristLastZOffset)), Quaternion.Euler(originalRightWristRotation) * val3, num8);
			rightWristPivot.localRotation = val5 * Quaternion.Euler(0f, 0f, num10);
			rightWristLastYOffset = 0f;
			rightWristLastZOffset = num10;
			Quaternion val6 = Quaternion.Slerp(leftWristPivot.localRotation * Quaternion.Inverse(Quaternion.Euler(0f, leftWristLastYOffset, leftWristLastZOffset)), Quaternion.Euler(originalLeftWristRotation) * val4, num8);
			leftWristPivot.localRotation = val6 * Quaternion.Euler(0f, 0f, 0f - num10);
			leftWristLastYOffset = 0f;
			leftWristLastZOffset = 0f - num10;
		}
		if (currentState == State.Slap)
		{
			float num12 = IncrementalCurveFactor(slapScaleCurve, reachAnimTimer, slapDuration, ref slapScaleCurveTPrev);
			Vector3 val7 = Vector3.one * maxHandSize;
			rightWristPivot.localScale = Vector3.Lerp(rightWristPivot.localScale, val7, num12);
			leftWristPivot.localScale = Vector3.Lerp(leftWristPivot.localScale, val7, num12);
		}
		else if (currentState == State.Follow && closeEnoughToReachOut && postStunTimer <= 0f && seesTarget)
		{
			ReachOutHandsToSlap();
		}
		else if (currentState == State.StuckAttack)
		{
			ReachOutHandsToStuckTarget();
		}
		else if (currentState == State.CoolDown)
		{
			ReturnHandsToDefaultPosition();
			ShakeHands();
		}
		else
		{
			ReturnHandsToDefaultPosition();
		}
		StretchLimbs();
	}

	private void StretchLimbs()
	{
		//IL_0011: Unknown result type (might be due to invalid IL or missing references)
		//IL_002d: Unknown result type (might be due to invalid IL or missing references)
		springPoseAnimator.StretchLimbToPoint("Left Arm", leftWristPivot.position, _instantEndpoint: true);
		springPoseAnimator.StretchLimbToPoint("Right Arm", rightWristPivot.position, _instantEndpoint: true);
	}

	private void ReachOutHandsToSlap()
	{
		//IL_0002: Unknown result type (might be due to invalid IL or missing references)
		//IL_0009: Unknown result type (might be due to invalid IL or missing references)
		//IL_000e: Unknown result type (might be due to invalid IL or missing references)
		//IL_005c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0061: Unknown result type (might be due to invalid IL or missing references)
		//IL_0063: Unknown result type (might be due to invalid IL or missing references)
		//IL_0065: Unknown result type (might be due to invalid IL or missing references)
		//IL_006a: Unknown result type (might be due to invalid IL or missing references)
		//IL_006c: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_006f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0074: Unknown result type (might be due to invalid IL or missing references)
		//IL_0088: Unknown result type (might be due to invalid IL or missing references)
		//IL_0098: Unknown result type (might be due to invalid IL or missing references)
		//IL_0127: Unknown result type (might be due to invalid IL or missing references)
		//IL_012e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0133: Unknown result type (might be due to invalid IL or missing references)
		//IL_0141: Unknown result type (might be due to invalid IL or missing references)
		//IL_0146: Unknown result type (might be due to invalid IL or missing references)
		//IL_0149: Unknown result type (might be due to invalid IL or missing references)
		//IL_015f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0164: Unknown result type (might be due to invalid IL or missing references)
		//IL_0167: Unknown result type (might be due to invalid IL or missing references)
		Vector3 handTarget = GetHandTarget(_rightHand: true);
		Vector3 handTarget2 = GetHandTarget(_rightHand: false);
		float duration = Mathf.Max(0.36f, reachInitialDistance / 3.5f);
		float factor = IncrementalCurveFactor(reachOutSlapCurve, reachAnimTimer, duration, ref reachPosCurveTPrev);
		float num = IncrementalCurveFactor(reachOutSlapScaleCurve, reachAnimTimer, duration, ref reachScaleCurveTPrev);
		Vector3 val = ComputeReachArcOffset(duration);
		Vector3 _rightTarget = handTarget + val;
		Vector3 _leftTarget = handTarget2 + val;
		ApplyLinkedWallClamp(ref _rightTarget, ref _leftTarget);
		UpdateHandPositionTo(rightWristPivot, _rightHand: true, _rightTarget, factor);
		UpdateHandPositionTo(leftWristPivot, _rightHand: false, _leftTarget, factor);
		float num2 = ((distanceFromPlayer - slapDistance <= 0f) ? 1f : (1f - Mathf.Clamp01((distanceFromPlayer - slapDistance) / (handMoveDistance - slapDistance)))) * handGrowEntry;
		float num3 = 1f + (maxHandSize - 1f) * num2;
		leftHandAnimator.Play("SlapHand", 0, num2);
		rightHandAnimator.Play("SlapHand", 0, num2);
		Vector3 val2 = Vector3.one * num3;
		rightWristPivot.localScale = Vector3.Lerp(rightWristPivot.localScale, val2, num);
		leftWristPivot.localScale = Vector3.Lerp(leftWristPivot.localScale, val2, num);
	}

	private void ReachOutHandsToStuckTarget()
	{
		//IL_0001: Unknown result type (might be due to invalid IL or missing references)
		//IL_0006: Unknown result type (might be due to invalid IL or missing references)
		//IL_0019: Unknown result type (might be due to invalid IL or missing references)
		//IL_001f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0031: Unknown result type (might be due to invalid IL or missing references)
		//IL_003c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0042: Unknown result type (might be due to invalid IL or missing references)
		//IL_0047: Unknown result type (might be due to invalid IL or missing references)
		//IL_0052: Unknown result type (might be due to invalid IL or missing references)
		//IL_005c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0061: Unknown result type (might be due to invalid IL or missing references)
		//IL_0066: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_0073: Unknown result type (might be due to invalid IL or missing references)
		//IL_0079: Unknown result type (might be due to invalid IL or missing references)
		//IL_007e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0089: Unknown result type (might be due to invalid IL or missing references)
		//IL_0093: Unknown result type (might be due to invalid IL or missing references)
		//IL_0098: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ec: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f1: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f4: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f6: Unknown result type (might be due to invalid IL or missing references)
		//IL_00fb: Unknown result type (might be due to invalid IL or missing references)
		//IL_00fd: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ff: Unknown result type (might be due to invalid IL or missing references)
		//IL_0104: Unknown result type (might be due to invalid IL or missing references)
		//IL_0118: Unknown result type (might be due to invalid IL or missing references)
		//IL_0129: Unknown result type (might be due to invalid IL or missing references)
		//IL_01af: Unknown result type (might be due to invalid IL or missing references)
		//IL_01b6: Unknown result type (might be due to invalid IL or missing references)
		//IL_01bb: Unknown result type (might be due to invalid IL or missing references)
		//IL_01c9: Unknown result type (might be due to invalid IL or missing references)
		//IL_01ce: Unknown result type (might be due to invalid IL or missing references)
		//IL_01d2: Unknown result type (might be due to invalid IL or missing references)
		//IL_01e8: Unknown result type (might be due to invalid IL or missing references)
		//IL_01ed: Unknown result type (might be due to invalid IL or missing references)
		//IL_01f1: Unknown result type (might be due to invalid IL or missing references)
		if (!(stuckAttackTarget == Vector3.zero))
		{
			float num = Vector3.Distance(((Component)this).transform.position, stuckAttackTarget);
			float num2 = 0.3f;
			Vector3 val = stuckAttackTarget + ((Component)this).transform.right * num2 - ((Component)this).transform.forward * 0.6f;
			Vector3 val2 = stuckAttackTarget - ((Component)this).transform.right * num2 - ((Component)this).transform.forward * 0.6f;
			float duration = Mathf.Max(0.36f, reachInitialDistance / 3.5f);
			float factor = IncrementalCurveFactor(reachOutStuckCurve, reachAnimTimer, duration, ref reachPosCurveTPrev);
			float num3 = IncrementalCurveFactor(reachOutStuckScaleCurve, reachAnimTimer, duration, ref reachScaleCurveTPrev);
			Vector3 val3 = ComputeReachArcOffset(duration);
			Vector3 _rightTarget = val + val3;
			Vector3 _leftTarget = val2 + val3;
			ApplyLinkedWallClamp(ref _rightTarget, ref _leftTarget);
			UpdateHandPositionTo(rightWristPivot, _rightHand: true, _rightTarget, factor);
			UpdateHandPositionTo(leftWristPivot, _rightHand: false, _leftTarget, factor);
			float num4 = ((num - slapDistance <= 0f) ? 1f : (1f - Mathf.Clamp01((num - slapDistance) / (handMoveDistance - slapDistance)))) * handGrowEntry;
			float num5 = 1f + (maxHandSize - 1f) * num4;
			leftHandAnimator.Play("SlapHand", 0, num4);
			rightHandAnimator.Play("SlapHand", 0, num4);
			Vector3 val4 = Vector3.one * num5;
			rightWristPivot.localScale = Vector3.Lerp(rightWristPivot.localScale, val4, num3);
			leftWristPivot.localScale = Vector3.Lerp(leftWristPivot.localScale, val4, num3);
		}
	}

	private Vector3 ComputeReachArcOffset(float _duration)
	{
		//IL_0030: Unknown result type (might be due to invalid IL or missing references)
		//IL_0035: Unknown result type (might be due to invalid IL or missing references)
		//IL_003b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0008: Unknown result type (might be due to invalid IL or missing references)
		if (_duration <= 0.0001f)
		{
			return Vector3.zero;
		}
		float num = Mathf.Clamp01(reachAnimTimer / _duration);
		float num2 = reachArcCurve.Evaluate(num);
		return ((Component)this).transform.TransformDirection(reachArcAmount) * num2;
	}

	private float IdleLoopValue()
	{
		if (idleHandsLoopDuration <= 0.0001f)
		{
			return 0f;
		}
		float num = Mathf.Repeat(Time.time / idleHandsLoopDuration, 1f);
		return idleHandsLoopCurve.Evaluate(num);
	}

	private float ComputeWallSafeReach(Transform _armPoint, Vector3 _targetWorld)
	{
		//IL_000f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0014: Unknown result type (might be due to invalid IL or missing references)
		//IL_0015: Unknown result type (might be due to invalid IL or missing references)
		//IL_0016: Unknown result type (might be due to invalid IL or missing references)
		//IL_0017: Unknown result type (might be due to invalid IL or missing references)
		//IL_001c: Unknown result type (might be due to invalid IL or missing references)
		//IL_002f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0031: Unknown result type (might be due to invalid IL or missing references)
		//IL_0036: Unknown result type (might be due to invalid IL or missing references)
		//IL_0037: Unknown result type (might be due to invalid IL or missing references)
		//IL_0038: Unknown result type (might be due to invalid IL or missing references)
		//IL_003a: Unknown result type (might be due to invalid IL or missing references)
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0064: Unknown result type (might be due to invalid IL or missing references)
		if (!Object.op_Implicit((Object)(object)_armPoint))
		{
			return -1f;
		}
		Vector3 position = _armPoint.position;
		Vector3 val = _targetWorld - position;
		float magnitude = val.magnitude;
		if (magnitude <= 0.01f)
		{
			return magnitude;
		}
		Vector3 val2 = val / magnitude;
		RaycastHit[] array = Physics.RaycastAll(position, val2, magnitude, LayerMask.op_Implicit(SemiFunc.LayerMaskGetVisionObstruct()), (QueryTriggerInteraction)1);
		float num = -1f;
		for (int i = 0; i < array.Length; i++)
		{
			RaycastHit val3 = array[i];
			if (((Component)val3.collider).CompareTag("Wall") && !val3.transform.IsChildOf(((Component)enemy.EnemyParent).transform) && (!Object.op_Implicit((Object)(object)playerTarget) || !((Object)(object)((Component)val3.collider).GetComponentInParent<PlayerAvatar>() == (Object)(object)playerTarget)) && (num < 0f || val3.distance < num))
			{
				num = val3.distance;
			}
		}
		if (!(num >= 0f))
		{
			return magnitude;
		}
		return Mathf.Max(0f, num - 0.05f);
	}

	private void ApplyLinkedWallClamp(ref Vector3 _rightTarget, ref Vector3 _leftTarget)
	{
		//IL_0021: Unknown result type (might be due to invalid IL or missing references)
		//IL_0027: Unknown result type (might be due to invalid IL or missing references)
		//IL_0038: Unknown result type (might be due to invalid IL or missing references)
		//IL_003e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0051: Unknown result type (might be due to invalid IL or missing references)
		//IL_0064: Unknown result type (might be due to invalid IL or missing references)
		//IL_0096: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a1: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a6: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ab: Unknown result type (might be due to invalid IL or missing references)
		//IL_00af: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b4: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b7: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c2: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c7: Unknown result type (might be due to invalid IL or missing references)
		//IL_00cc: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d0: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d5: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ec: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f1: Unknown result type (might be due to invalid IL or missing references)
		//IL_00fb: Unknown result type (might be due to invalid IL or missing references)
		//IL_0100: Unknown result type (might be due to invalid IL or missing references)
		//IL_0105: Unknown result type (might be due to invalid IL or missing references)
		//IL_011f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0124: Unknown result type (might be due to invalid IL or missing references)
		//IL_012e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0133: Unknown result type (might be due to invalid IL or missing references)
		//IL_0138: Unknown result type (might be due to invalid IL or missing references)
		if (!Object.op_Implicit((Object)(object)rightArmPoint) || !Object.op_Implicit((Object)(object)leftArmPoint))
		{
			return;
		}
		float num = Vector3.Distance(rightArmPoint.position, _rightTarget);
		float num2 = Vector3.Distance(leftArmPoint.position, _leftTarget);
		float num3 = ComputeWallSafeReach(rightArmPoint, _rightTarget);
		float num4 = ComputeWallSafeReach(leftArmPoint, _leftTarget);
		bool flag = num3 < num - 0.001f;
		bool flag2 = num4 < num2 - 0.001f;
		if (flag || flag2)
		{
			float num5 = Mathf.Min(num3, num4);
			Vector3 val = _rightTarget - rightArmPoint.position;
			Vector3 normalized = val.normalized;
			val = _leftTarget - leftArmPoint.position;
			Vector3 normalized2 = val.normalized;
			if (normalized.sqrMagnitude > 0.0001f)
			{
				_rightTarget = rightArmPoint.position + normalized * Mathf.Min(num, num5);
			}
			if (normalized2.sqrMagnitude > 0.0001f)
			{
				_leftTarget = leftArmPoint.position + normalized2 * Mathf.Min(num2, num5);
			}
		}
	}

	private float IncrementalCurveFactor(AnimationCurve _curve, float _timer, float _duration, ref float _prev)
	{
		if (_curve == null || _duration <= 0f)
		{
			return 1f;
		}
		if (_timer >= _duration)
		{
			_prev = 1f;
			return Mathf.Clamp01(Time.deltaTime * 8f);
		}
		float num = Mathf.Clamp01(_timer / _duration);
		float num2 = _curve.Evaluate(num);
		float num3;
		if (num2 >= 0.9999f || _prev >= 0.9999f)
		{
			num3 = 1f;
		}
		else
		{
			float num4 = 1f - _prev;
			num3 = ((num4 > 0.0001f) ? ((num2 - _prev) / num4) : 1f);
		}
		num3 = Mathf.Clamp01(num3);
		_prev = num2;
		return num3;
	}

	private void UpdateHandPositionTo(Transform _wrist, bool _rightHand, Vector3 _handTarget, float _factor)
	{
		//IL_0027: Unknown result type (might be due to invalid IL or missing references)
		//IL_0037: Unknown result type (might be due to invalid IL or missing references)
		//IL_0004: Unknown result type (might be due to invalid IL or missing references)
		//IL_0014: Unknown result type (might be due to invalid IL or missing references)
		//IL_0063: Unknown result type (might be due to invalid IL or missing references)
		//IL_0078: Unknown result type (might be due to invalid IL or missing references)
		//IL_00fb: Unknown result type (might be due to invalid IL or missing references)
		//IL_0100: Unknown result type (might be due to invalid IL or missing references)
		//IL_0103: Unknown result type (might be due to invalid IL or missing references)
		//IL_0108: Unknown result type (might be due to invalid IL or missing references)
		//IL_010f: Unknown result type (might be due to invalid IL or missing references)
		//IL_011a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0124: Unknown result type (might be due to invalid IL or missing references)
		//IL_0129: Unknown result type (might be due to invalid IL or missing references)
		//IL_012e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0135: Unknown result type (might be due to invalid IL or missing references)
		//IL_0140: Unknown result type (might be due to invalid IL or missing references)
		//IL_014a: Unknown result type (might be due to invalid IL or missing references)
		//IL_014f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0154: Unknown result type (might be due to invalid IL or missing references)
		//IL_01bb: Unknown result type (might be due to invalid IL or missing references)
		//IL_01c1: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00dd: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e9: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a6: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b0: Unknown result type (might be due to invalid IL or missing references)
		//IL_00bc: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c6: Unknown result type (might be due to invalid IL or missing references)
		//IL_01d8: Unknown result type (might be due to invalid IL or missing references)
		//IL_01de: Unknown result type (might be due to invalid IL or missing references)
		//IL_01cb: Unknown result type (might be due to invalid IL or missing references)
		//IL_0175: Unknown result type (might be due to invalid IL or missing references)
		//IL_0180: Unknown result type (might be due to invalid IL or missing references)
		//IL_018a: Unknown result type (might be due to invalid IL or missing references)
		//IL_018f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0194: Unknown result type (might be due to invalid IL or missing references)
		//IL_019b: Unknown result type (might be due to invalid IL or missing references)
		//IL_01a6: Unknown result type (might be due to invalid IL or missing references)
		//IL_01b0: Unknown result type (might be due to invalid IL or missing references)
		//IL_01b5: Unknown result type (might be due to invalid IL or missing references)
		//IL_01ba: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f8: Unknown result type (might be due to invalid IL or missing references)
		//IL_01f3: Unknown result type (might be due to invalid IL or missing references)
		//IL_01f9: Unknown result type (might be due to invalid IL or missing references)
		//IL_01e8: Unknown result type (might be due to invalid IL or missing references)
		//IL_0210: Unknown result type (might be due to invalid IL or missing references)
		//IL_0216: Unknown result type (might be due to invalid IL or missing references)
		//IL_0203: Unknown result type (might be due to invalid IL or missing references)
		//IL_022b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0231: Unknown result type (might be due to invalid IL or missing references)
		//IL_0220: Unknown result type (might be due to invalid IL or missing references)
		//IL_0248: Unknown result type (might be due to invalid IL or missing references)
		//IL_024e: Unknown result type (might be due to invalid IL or missing references)
		//IL_023b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0269: Unknown result type (might be due to invalid IL or missing references)
		//IL_026a: Unknown result type (might be due to invalid IL or missing references)
		//IL_026f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0271: Unknown result type (might be due to invalid IL or missing references)
		//IL_0258: Unknown result type (might be due to invalid IL or missing references)
		//IL_029f: Unknown result type (might be due to invalid IL or missing references)
		//IL_02a4: Unknown result type (might be due to invalid IL or missing references)
		//IL_02a6: Unknown result type (might be due to invalid IL or missing references)
		//IL_02a7: Unknown result type (might be due to invalid IL or missing references)
		//IL_02a9: Unknown result type (might be due to invalid IL or missing references)
		//IL_02ae: Unknown result type (might be due to invalid IL or missing references)
		//IL_02b0: Unknown result type (might be due to invalid IL or missing references)
		//IL_0291: Unknown result type (might be due to invalid IL or missing references)
		//IL_0293: Unknown result type (might be due to invalid IL or missing references)
		//IL_0298: Unknown result type (might be due to invalid IL or missing references)
		//IL_0328: Unknown result type (might be due to invalid IL or missing references)
		//IL_0315: Unknown result type (might be due to invalid IL or missing references)
		//IL_0319: Unknown result type (might be due to invalid IL or missing references)
		//IL_031e: Unknown result type (might be due to invalid IL or missing references)
		//IL_046e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0349: Unknown result type (might be due to invalid IL or missing references)
		//IL_034e: Unknown result type (might be due to invalid IL or missing references)
		//IL_033c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0341: Unknown result type (might be due to invalid IL or missing references)
		//IL_0371: Unknown result type (might be due to invalid IL or missing references)
		//IL_0373: Unknown result type (might be due to invalid IL or missing references)
		//IL_03d3: Unknown result type (might be due to invalid IL or missing references)
		//IL_03da: Unknown result type (might be due to invalid IL or missing references)
		//IL_03e8: Unknown result type (might be due to invalid IL or missing references)
		//IL_03f2: Unknown result type (might be due to invalid IL or missing references)
		//IL_03f9: Unknown result type (might be due to invalid IL or missing references)
		//IL_0407: Unknown result type (might be due to invalid IL or missing references)
		//IL_042d: Unknown result type (might be due to invalid IL or missing references)
		//IL_042e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0432: Unknown result type (might be due to invalid IL or missing references)
		//IL_0437: Unknown result type (might be due to invalid IL or missing references)
		//IL_0385: Unknown result type (might be due to invalid IL or missing references)
		//IL_0387: Unknown result type (might be due to invalid IL or missing references)
		//IL_038b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0390: Unknown result type (might be due to invalid IL or missing references)
		//IL_0395: Unknown result type (might be due to invalid IL or missing references)
		//IL_03b6: Unknown result type (might be due to invalid IL or missing references)
		//IL_03a7: Unknown result type (might be due to invalid IL or missing references)
		//IL_03ac: Unknown result type (might be due to invalid IL or missing references)
		//IL_03ca: Unknown result type (might be due to invalid IL or missing references)
		//IL_03cf: Unknown result type (might be due to invalid IL or missing references)
		float num = (_rightHand ? Mathf.Abs(_wrist.localPosition.x - rightHandDownPos.localPosition.x) : Mathf.Abs(_wrist.localPosition.x - leftHandDownPos.localPosition.x));
		if (Object.op_Implicit((Object)(object)playerTarget) && playerTarget.isCrouching && _wrist.position.y - (((Component)playerTarget).transform.position.y + 0.2f) > 0.2f && num > 0.25f)
		{
			_handTarget = (_rightHand ? new Vector3(rightHandDownPos.position.x, _handTarget.y, rightHandDownPos.position.z) : new Vector3(leftHandDownPos.position.x, _handTarget.y, leftHandDownPos.position.z));
		}
		Vector3 val = Vector3.Lerp(_wrist.position, _handTarget, _factor);
		Vector3 val2 = handArea.position - handArea.localScale / 2f;
		Vector3 val3 = handArea.position + handArea.localScale / 2f;
		if (Object.op_Implicit((Object)(object)playerTarget) && playerTarget.isCrouching)
		{
			val2 = handAreaUnder.position - handAreaUnder.localScale / 2f;
			val3 = handAreaUnder.position + handAreaUnder.localScale / 2f;
		}
		if (val.x < val2.x)
		{
			val.x = val2.x;
		}
		else if (val.x > val3.x)
		{
			val.x = val3.x;
		}
		if (val.y < val2.y)
		{
			val.y = val2.y;
		}
		else if (val.y > val3.y)
		{
			val.y = val3.y;
		}
		if (val.z < val2.z)
		{
			val.z = val2.z;
		}
		else if (val.z > val3.z)
		{
			val.z = val3.z;
		}
		Vector3 val4 = ((Component)this).transform.InverseTransformPoint(val);
		if (val4.z < 0f)
		{
			val4.z = 0f;
			val = ((Component)this).transform.TransformPoint(val4);
		}
		Vector3 position = ((Component)this).transform.position;
		Vector3 val5 = val - position;
		float y = val5.y;
		val5.y = 0f;
		float magnitude = val5.magnitude;
		float num2 = (_rightHand ? bodyAvoidRightTimer : bodyAvoidLeftTimer);
		float _prev = (_rightHand ? bodyAvoidRightCurveTPrev : bodyAvoidLeftCurveTPrev);
		if (bendState == -1 && magnitude < 1f)
		{
			Vector3 val6 = ((!(magnitude > 0.0001f)) ? (((Component)this).transform.right * (_rightHand ? 1f : (-1f))) : (val5 / magnitude));
			Vector3 forward = ((Component)this).transform.forward;
			forward.y = 0f;
			if (forward.sqrMagnitude > 0.0001f)
			{
				forward.Normalize();
			}
			float num3 = Vector3.Dot(val6, forward);
			if (num3 < 0f)
			{
				val6 -= forward * num3;
				val6 = ((!(val6.sqrMagnitude > 0.0001f)) ? (((Component)this).transform.right * (_rightHand ? 1f : (-1f))) : val6.normalized);
			}
			Vector3 val7 = new Vector3(position.x + val6.x * 1f, position.y + y, position.z + val6.z * 1f);
			num2 += Time.deltaTime;
			float num4 = IncrementalCurveFactor(bodyAvoidCurve, num2, 0.3f, ref _prev);
			val = Vector3.Lerp(val, val7, num4);
		}
		else
		{
			num2 = 0f;
			_prev = 0f;
		}
		if (_rightHand)
		{
			bodyAvoidRightTimer = num2;
			bodyAvoidRightCurveTPrev = _prev;
		}
		else
		{
			bodyAvoidLeftTimer = num2;
			bodyAvoidLeftCurveTPrev = _prev;
		}
		_wrist.position = val;
	}

	private void ReturnHandsToDefaultPosition(bool _pos = true, bool _scale = true, bool _anim = true)
	{
		//IL_000d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0012: Unknown result type (might be due to invalid IL or missing references)
		//IL_001a: Unknown result type (might be due to invalid IL or missing references)
		//IL_001f: Unknown result type (might be due to invalid IL or missing references)
		//IL_01fd: Unknown result type (might be due to invalid IL or missing references)
		//IL_0202: Unknown result type (might be due to invalid IL or missing references)
		//IL_0209: Unknown result type (might be due to invalid IL or missing references)
		//IL_021f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0224: Unknown result type (might be due to invalid IL or missing references)
		//IL_022b: Unknown result type (might be due to invalid IL or missing references)
		//IL_010f: Unknown result type (might be due to invalid IL or missing references)
		//IL_00fc: Unknown result type (might be due to invalid IL or missing references)
		//IL_0114: Unknown result type (might be due to invalid IL or missing references)
		//IL_012c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0119: Unknown result type (might be due to invalid IL or missing references)
		//IL_0131: Unknown result type (might be due to invalid IL or missing references)
		//IL_013b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0149: Unknown result type (might be due to invalid IL or missing references)
		//IL_014e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0150: Unknown result type (might be due to invalid IL or missing references)
		//IL_0152: Unknown result type (might be due to invalid IL or missing references)
		//IL_0154: Unknown result type (might be due to invalid IL or missing references)
		//IL_0159: Unknown result type (might be due to invalid IL or missing references)
		//IL_015b: Unknown result type (might be due to invalid IL or missing references)
		//IL_015d: Unknown result type (might be due to invalid IL or missing references)
		//IL_015f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0164: Unknown result type (might be due to invalid IL or missing references)
		//IL_0172: Unknown result type (might be due to invalid IL or missing references)
		//IL_0177: Unknown result type (might be due to invalid IL or missing references)
		//IL_017b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0191: Unknown result type (might be due to invalid IL or missing references)
		//IL_0196: Unknown result type (might be due to invalid IL or missing references)
		//IL_019a: Unknown result type (might be due to invalid IL or missing references)
		if (_anim)
		{
			AnimatorStateInfo currentAnimatorStateInfo = leftHandAnimator.GetCurrentAnimatorStateInfo(0);
			AnimatorStateInfo currentAnimatorStateInfo2 = rightHandAnimator.GetCurrentAnimatorStateInfo(0);
			float num = Mathf.Lerp(currentAnimatorStateInfo.normalizedTime % 1f, 0f, Time.deltaTime * 6f);
			float num2 = Mathf.Lerp(currentAnimatorStateInfo2.normalizedTime % 1f, 0f, Time.deltaTime * 6f);
			leftHandAnimator.Play("SlapHand", 0, num);
			leftHandAnimator.speed = 0f;
			rightHandAnimator.Play("SlapHand", 0, num2);
			rightHandAnimator.speed = 0f;
		}
		if (_pos)
		{
			bool flag = bendState != -1;
			AnimationCurve curve = (flag ? handBendCurve : returnHandsCurve);
			float duration = (flag ? 1.5f : 1.5f);
			float num3 = IncrementalCurveFactor(curve, returnAnimTimer, duration, ref returnPosCurveTPrev);
			Vector3 val = (flag ? rightBendHandPoses[bendState] : originalRightWristPosition);
			Vector3 val2 = (flag ? leftBendHandPoses[bendState] : originalLeftWristPosition);
			float num4 = IdleLoopValue();
			Vector3 val3 = Vector3.up * (num4 * idleHandsYAmount);
			val += val3;
			val2 += val3;
			rightWristPivot.localPosition = Vector3.Lerp(rightWristPivot.localPosition, val, num3);
			leftWristPivot.localPosition = Vector3.Lerp(leftWristPivot.localPosition, val2, num3);
		}
		if (_scale)
		{
			bool flag2 = bendState != -1;
			AnimationCurve curve2 = (flag2 ? handBendCurve : returnHandsCurve);
			float duration2 = (flag2 ? 1.5f : 1.5f);
			float num5 = IncrementalCurveFactor(curve2, returnAnimTimer, duration2, ref returnScaleCurveTPrev);
			rightWristPivot.localScale = Vector3.Lerp(rightWristPivot.localScale, Vector3.one, num5);
			leftWristPivot.localScale = Vector3.Lerp(leftWristPivot.localScale, Vector3.one, num5);
		}
	}

	private Vector3 GetHandTarget(bool _rightHand)
	{
		//IL_0120: Unknown result type (might be due to invalid IL or missing references)
		//IL_0125: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ce: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d9: Unknown result type (might be due to invalid IL or missing references)
		//IL_00de: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e9: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f8: Unknown result type (might be due to invalid IL or missing references)
		//IL_0103: Unknown result type (might be due to invalid IL or missing references)
		//IL_010d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0112: Unknown result type (might be due to invalid IL or missing references)
		//IL_0117: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ae: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b3: Unknown result type (might be due to invalid IL or missing references)
		//IL_005c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0061: Unknown result type (might be due to invalid IL or missing references)
		//IL_0067: Unknown result type (might be due to invalid IL or missing references)
		//IL_006c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0077: Unknown result type (might be due to invalid IL or missing references)
		//IL_0081: Unknown result type (might be due to invalid IL or missing references)
		//IL_0086: Unknown result type (might be due to invalid IL or missing references)
		//IL_0091: Unknown result type (might be due to invalid IL or missing references)
		//IL_009b: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a0: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a5: Unknown result type (might be due to invalid IL or missing references)
		//IL_0126: Unknown result type (might be due to invalid IL or missing references)
		float num = ((Object.op_Implicit((Object)(object)playerTarget) && (playerTarget.isCrouching || playerTarget.isCrawling || playerTarget.isTumbling)) ? 0.2f : 1.2f);
		if (_rightHand)
		{
			if (Object.op_Implicit((Object)(object)playerTarget))
			{
				return ((Component)playerTarget).transform.position + Vector3.up * num - ((Component)this).transform.forward * 0.6f + ((Component)this).transform.right * 0.3f;
			}
			return rightWristPivot.position;
		}
		if (Object.op_Implicit((Object)(object)playerTarget))
		{
			return ((Component)playerTarget).transform.position + Vector3.up * num - ((Component)this).transform.forward * 0.6f - ((Component)this).transform.right * 0.3f;
		}
		return leftWristPivot.position;
	}

	public void GetAnnoyed(PlayerAvatar _nearbyPlayer)
	{
		if (SemiFunc.EnemySpawnIdlePause() || !SemiFunc.IsMasterClientOrSingleplayer() || annoyedTimer > 0f)
		{
			return;
		}
		if (!SemiFunc.IsMultiplayer())
		{
			if (currentState == State.Leave)
			{
				UpdateState(State.Follow);
			}
		}
		else
		{
			if (!Object.op_Implicit((Object)(object)_nearbyPlayer))
			{
				_nearbyPlayer = GetNearestPlayer();
			}
			if ((Object)(object)playerTarget != (Object)(object)_nearbyPlayer)
			{
				skipTargetTell = true;
				actualPlayerTarget = playerTarget;
				annoyedFollowTimer = 5f;
				annoyed = true;
				UpdatePlayerTarget(_nearbyPlayer);
				UpdateState(State.Follow);
			}
			else if (currentState == State.Leave)
			{
				UpdateState(State.Follow);
			}
		}
		annoyedTimer = 10f;
	}

	public void SkipShockwave()
	{
		if (hurtColliderScript.onImpactPlayerAvatar.isLocal)
		{
			hurtColliderWaveScript.playerLogic = false;
		}
	}

	private void Slap()
	{
		//IL_00a1: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a6: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ac: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b1: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c2: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c7: Unknown result type (might be due to invalid IL or missing references)
		//IL_00cd: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d2: Unknown result type (might be due to invalid IL or missing references)
		//IL_004c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0057: Unknown result type (might be due to invalid IL or missing references)
		//IL_005c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0066: Unknown result type (might be due to invalid IL or missing references)
		//IL_0071: Unknown result type (might be due to invalid IL or missing references)
		//IL_007b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0080: Unknown result type (might be due to invalid IL or missing references)
		//IL_0085: Unknown result type (might be due to invalid IL or missing references)
		//IL_0087: Unknown result type (might be due to invalid IL or missing references)
		float num = (slapNetValid ? Mathf.Clamp01((float)((PhotonNetwork.Time - slapStartTimeNetwork) / (double)slapDuration)) : Mathf.Clamp01(stateTimerClient / slapDuration));
		if (num >= 0.92f && SemiFunc.IsMasterClientOrSingleplayer())
		{
			Vector3 pos = (rightWristPivot.position + leftWristPivot.position) * 0.5f + ((Component)this).transform.forward * 0.2f;
			EnableHurtCollider(pos);
		}
		float num2 = slapAnimationCurve.Evaluate(num);
		rightWristPivot.localPosition = rightHandSlapLocation + Vector3.right * num2;
		leftWristPivot.localPosition = leftHandSlapLocation - Vector3.right * num2;
	}

	private void SpringLogic()
	{
		//IL_0012: Unknown result type (might be due to invalid IL or missing references)
		//IL_001c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0038: Unknown result type (might be due to invalid IL or missing references)
		//IL_0042: Unknown result type (might be due to invalid IL or missing references)
		//IL_005e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_007e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0083: Unknown result type (might be due to invalid IL or missing references)
		//IL_0086: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a0: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a5: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a8: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b8: Unknown result type (might be due to invalid IL or missing references)
		//IL_00bd: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c0: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ca: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e6: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f0: Unknown result type (might be due to invalid IL or missing references)
		hairPivot1.localRotation = SemiFunc.SpringQuaternionGet(hairSpring1, hairTarget1.localRotation);
		hairPivot2.localRotation = SemiFunc.SpringQuaternionGet(hairSpring2, hairTarget2.localRotation);
		hairPivot3.localRotation = SemiFunc.SpringQuaternionGet(hairSpring3, hairTarget3.localRotation);
		Transform val = hairPivot3;
		Quaternion localRotation = hairPivot3.localRotation;
		float num = Mathf.Min(localRotation.eulerAngles.x, 0f);
		localRotation = hairPivot3.localRotation;
		float y = localRotation.eulerAngles.y;
		localRotation = hairPivot3.localRotation;
		val.localRotation = Quaternion.Euler(num, y, localRotation.eulerAngles.z);
		hairPivot4.localRotation = SemiFunc.SpringQuaternionGet(hairSpring4, hairTarget4.localRotation);
	}

	private void ResetNavMesh()
	{
		//IL_002b: Unknown result type (might be due to invalid IL or missing references)
		enemy.NavMeshAgent.ResetPath();
		enemy.NavMeshAgent.Warp(((Component)enemy.Rigidbody).transform.position);
	}

	private void ShakeHands()
	{
		//IL_0006: Unknown result type (might be due to invalid IL or missing references)
		//IL_000b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0015: Unknown result type (might be due to invalid IL or missing references)
		//IL_001a: Unknown result type (might be due to invalid IL or missing references)
		//IL_001f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0020: Unknown result type (might be due to invalid IL or missing references)
		//IL_002c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0078: Unknown result type (might be due to invalid IL or missing references)
		//IL_007d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0087: Unknown result type (might be due to invalid IL or missing references)
		//IL_008c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0091: Unknown result type (might be due to invalid IL or missing references)
		//IL_0092: Unknown result type (might be due to invalid IL or missing references)
		//IL_009e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0038: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ea: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f6: Unknown result type (might be due to invalid IL or missing references)
		//IL_00aa: Unknown result type (might be due to invalid IL or missing references)
		//IL_0053: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c5: Unknown result type (might be due to invalid IL or missing references)
		Vector3 val = rightWristPivot.localPosition + Random.insideUnitSphere * 0.01f;
		if (val.x < rightWristPivot.localPosition.x && val.x < rightHandSlapLocation.x)
		{
			val.x = rightWristPivot.localPosition.x + Random.Range(0.005f, 0.01f);
		}
		Vector3 val2 = leftWristPivot.localPosition + Random.insideUnitSphere * 0.01f;
		if (val2.x > leftWristPivot.localPosition.x && val2.x > leftHandSlapLocation.x)
		{
			val2.x = leftWristPivot.localPosition.x - Random.Range(0.005f, 0.01f);
		}
		rightWristPivot.localPosition = val;
		leftWristPivot.localPosition = val2;
	}

	private void LateUpdate()
	{
		if (postSlapVibrationTimer > 0f)
		{
			postSlapVibrationTimer -= Time.deltaTime;
		}
		UpdateElbowOutwardMotion();
		ApplyHandsLock();
		UpdateFingerSprings(rightFingers);
		UpdateFingerSprings(leftFingers);
	}

	private void ApplyHandsLock()
	{
		//IL_0027: Unknown result type (might be due to invalid IL or missing references)
		//IL_002c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0031: Unknown result type (might be due to invalid IL or missing references)
		//IL_0038: Unknown result type (might be due to invalid IL or missing references)
		//IL_0044: Unknown result type (might be due to invalid IL or missing references)
		//IL_0051: Unknown result type (might be due to invalid IL or missing references)
		//IL_0056: Unknown result type (might be due to invalid IL or missing references)
		//IL_0067: Unknown result type (might be due to invalid IL or missing references)
		//IL_006c: Unknown result type (might be due to invalid IL or missing references)
		if (!(handsLockTimer <= 0f))
		{
			handsLockTimer -= Time.deltaTime;
			Vector3 position = ((Component)this).transform.TransformPoint(handsLockPosLocal);
			rightWristPivot.position = position;
			leftWristPivot.position = position;
			rightWristPivot.localRotation = Quaternion.Euler(rightWristSlapRotation);
			leftWristPivot.localRotation = Quaternion.Euler(leftWristSlapRotation);
			rightWristLastYOffset = 0f;
			rightWristLastZOffset = 0f;
			leftWristLastYOffset = 0f;
			leftWristLastZOffset = 0f;
		}
	}

	private void UpdateElbowOutwardMotion()
	{
		if (currentState != State.Slap && currentState != State.StuckAttack && (currentState != State.Follow || !closeEnoughToReachOut || !seesTarget))
		{
			springPoseAnimator.bodyAvoidRadius = 0f;
			return;
		}
		float num = Mathf.PerlinNoise(Time.time * elbowOutwardSpeed, 0.31f);
		float num2 = Mathf.PerlinNoise(Time.time * elbowOutwardSpeed * 0.73f, 7.4f);
		float num3 = Mathf.Clamp01((num + num2 * 0.5f) / 1.5f) * elbowOutwardAmount;
		springPoseAnimator.bodyAvoidRadius = defaultBodyAvoidRadius + num3;
	}

	private void CaptureReachInitialDistance()
	{
		//IL_000a: Unknown result type (might be due to invalid IL or missing references)
		//IL_000f: Unknown result type (might be due to invalid IL or missing references)
		//IL_004c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0053: Unknown result type (might be due to invalid IL or missing references)
		//IL_0022: Unknown result type (might be due to invalid IL or missing references)
		//IL_0028: Unknown result type (might be due to invalid IL or missing references)
		if (currentState == State.StuckAttack && stuckAttackTarget != Vector3.zero)
		{
			reachInitialDistance = Vector3.Distance(rightWristPivot.position, stuckAttackTarget);
		}
		else if (Object.op_Implicit((Object)(object)playerTarget))
		{
			reachInitialDistance = Vector3.Distance(rightWristPivot.position, GetHandTarget(_rightHand: true));
		}
		else
		{
			reachInitialDistance = 0f;
		}
	}

	private void UpdateFingerSprings(List<FingerSpring> _fingers)
	{
		//IL_0006: Unknown result type (might be due to invalid IL or missing references)
		//IL_000c: Unknown result type (might be due to invalid IL or missing references)
		//IL_001c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0022: Unknown result type (might be due to invalid IL or missing references)
		//IL_01ee: Unknown result type (might be due to invalid IL or missing references)
		//IL_01f3: Unknown result type (might be due to invalid IL or missing references)
		//IL_01bc: Unknown result type (might be due to invalid IL or missing references)
		//IL_01c1: Unknown result type (might be due to invalid IL or missing references)
		//IL_0274: Unknown result type (might be due to invalid IL or missing references)
		//IL_0279: Unknown result type (might be due to invalid IL or missing references)
		//IL_0282: Unknown result type (might be due to invalid IL or missing references)
		//IL_0289: Unknown result type (might be due to invalid IL or missing references)
		//IL_028e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0297: Unknown result type (might be due to invalid IL or missing references)
		//IL_0299: Unknown result type (might be due to invalid IL or missing references)
		//IL_029b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0254: Unknown result type (might be due to invalid IL or missing references)
		//IL_0261: Unknown result type (might be due to invalid IL or missing references)
		//IL_0266: Unknown result type (might be due to invalid IL or missing references)
		//IL_026b: Unknown result type (might be due to invalid IL or missing references)
		//IL_02bb: Unknown result type (might be due to invalid IL or missing references)
		//IL_02db: Unknown result type (might be due to invalid IL or missing references)
		//IL_02e0: Unknown result type (might be due to invalid IL or missing references)
		//IL_02e9: Unknown result type (might be due to invalid IL or missing references)
		//IL_02ee: Unknown result type (might be due to invalid IL or missing references)
		//IL_02f2: Unknown result type (might be due to invalid IL or missing references)
		//IL_0305: Unknown result type (might be due to invalid IL or missing references)
		float num = Vector3.Distance(rightWristPivot.localPosition, originalRightWristPosition);
		float num2 = Vector3.Distance(leftWristPivot.localPosition, originalLeftWristPosition);
		float num3 = Mathf.Clamp01((num + num2) * 0.5f / slapDistance);
		float num5;
		if (postSlapVibrationDuration > 0.0001f)
		{
			float num4 = Mathf.Clamp01(postSlapVibrationTimer / postSlapVibrationDuration);
			num5 = num4 * num4;
		}
		else
		{
			num5 = 0f;
		}
		float num6 = fingerIdleJiggleSpeed;
		float num7 = fingerIdleJiggleAmount;
		float num8 = fingerSpringSpeed;
		float num9;
		float num10;
		float num11;
		if (num5 > 0f || currentState == State.CoolDown)
		{
			num9 = Mathf.Lerp(num6, fingerPostSlapJiggleSpeed, num5);
			num10 = Mathf.Lerp(num7, fingerPostSlapJiggleAmount, num5);
			num11 = Mathf.Lerp(num8, fingerPostSlapJiggleSpeed, num5);
		}
		else
		{
			float num12 = Mathf.Lerp(1f, fingerReachSpeedMultiplier, num3);
			float num13 = Mathf.Lerp(1f, fingerReachAmountMultiplier, num3);
			num9 = num6 * num12;
			num10 = num7 * num13;
			num11 = num8 * num12;
		}
		if (currentState == State.Slap)
		{
			num10 *= fingerSlapDampening;
		}
		if (!reachingActive)
		{
			float num14 = Mathf.Clamp01(returnAnimTimer / 1.5f);
			float num15 = moveBackSpikeCurve.Evaluate(num14);
			if (num15 > 0f)
			{
				num9 = Mathf.Lerp(num9, moveBackSpikeSpeed, num15);
				num11 = Mathf.Lerp(num11, moveBackSpikeSpeed, num15);
			}
		}
		float num16 = Time.time * num9;
		for (int i = 0; i < _fingers.Count; i++)
		{
			FingerSpring fingerSpring = _fingers[i];
			if (Object.op_Implicit((Object)(object)fingerSpring.bone))
			{
				if (fingerSpring.spring == null)
				{
					fingerSpring.spring = new SpringQuaternion();
				}
				if (!fingerSpring.bindCaptured)
				{
					fingerSpring.bindLocalRotation = fingerSpring.bone.localRotation;
					fingerSpring.bindCaptured = true;
				}
				fingerSpring.spring.speed = num11;
				fingerSpring.spring.damping = fingerSpringDamping;
				Quaternion targetRotation = Quaternion.identity;
				if (num10 > 0f)
				{
					float num17 = (float)i * 7.13f;
					targetRotation = Quaternion.Euler(new Vector3(Mathf.PerlinNoise(num16 + num17, 0.5f) - 0.5f, Mathf.PerlinNoise(num16 + num17 + 100f, 0.5f) - 0.5f, Mathf.PerlinNoise(num16 + num17 + 200f, 0.5f) - 0.5f) * (2f * num10));
				}
				Quaternion rotation = fingerSpring.bone.rotation;
				Quaternion val = SemiFunc.SpringQuaternionGet(fingerSpring.spring, targetRotation);
				fingerSpring.bone.rotation = rotation * val;
				if (handsLockTimer > 0f)
				{
					fingerSpring.bone.localRotation = fingerSpring.bindLocalRotation;
				}
				else if (postSlapVibrationTimer > 0f)
				{
					Vector3 localEulerAngles = fingerSpring.bone.localEulerAngles;
					Vector3 eulerAngles = fingerSpring.bindLocalRotation.eulerAngles;
					localEulerAngles.y = eulerAngles.y;
					fingerSpring.bone.localEulerAngles = localEulerAngles;
				}
			}
		}
	}

	public void ShakeFingers()
	{
		ShakeFingers(fingerShakeForce);
	}

	public void ShakeFingers(float _force)
	{
		KickFingerSprings(rightFingers, _force);
		KickFingerSprings(leftFingers, _force);
	}

	private void KickFingerSprings(List<FingerSpring> _fingers, float _force)
	{
		//IL_0025: Unknown result type (might be due to invalid IL or missing references)
		//IL_002b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0030: Unknown result type (might be due to invalid IL or missing references)
		for (int i = 0; i < _fingers.Count; i++)
		{
			FingerSpring fingerSpring = _fingers[i];
			if (fingerSpring.spring == null)
			{
				fingerSpring.spring = new SpringQuaternion();
			}
			fingerSpring.spring.springVelocity = Random.onUnitSphere * _force;
		}
	}

	private void AttackNearestPhysObjectOrFollow()
	{
		//IL_0001: Unknown result type (might be due to invalid IL or missing references)
		//IL_0006: Unknown result type (might be due to invalid IL or missing references)
		//IL_0034: Unknown result type (might be due to invalid IL or missing references)
		//IL_0039: Unknown result type (might be due to invalid IL or missing references)
		//IL_0029: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Unknown result type (might be due to invalid IL or missing references)
		//IL_004b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0051: Unknown result type (might be due to invalid IL or missing references)
		stuckAttackTarget = Vector3.zero;
		if (enemy.Rigidbody.notMovingTimer > 3f)
		{
			stuckAttackTarget = SemiFunc.EnemyGetNearestPhysObject(enemy);
		}
		if (stuckAttackTarget == Vector3.zero || Vector3.Distance(((Component)this).transform.position, stuckAttackTarget) > 5f)
		{
			UpdateState(State.Leave);
			return;
		}
		stuckAttackAttempts = 0;
		UpdateState(State.StuckAttack);
	}

	private void PlayerTargetTell()
	{
		//IL_0041: Unknown result type (might be due to invalid IL or missing references)
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0142: Unknown result type (might be due to invalid IL or missing references)
		//IL_0152: Unknown result type (might be due to invalid IL or missing references)
		if (Object.op_Implicit((Object)(object)playerTarget) && playerTarget.isLocal && !playerTarget.isDisabled)
		{
			anim.playTargetedSound(((Component)playerTarget).transform.position);
			PostProcessing.Instance.VignetteOverride(new Color(0.5f, 0f, 0f), 0.3f, 1f, 3f, 1f, 0.5f, ((Component)this).gameObject);
			PostProcessing.Instance.SaturationOverride(-20f, 3f, 1f, 0.5f, ((Component)this).gameObject);
			PostProcessing.Instance.ContrastOverride(5f, 3f, 1f, 0.5f, ((Component)this).gameObject);
			GameDirector.instance.CameraImpact.Shake(1f, 0.1f);
			GameDirector.instance.CameraShake.Shake(1f, 0.25f);
			if (!Object.op_Implicit((Object)(object)activeVeinEffect))
			{
				Transform overrideTransform = playerTarget.localCamera.GetOverrideTransform();
				GameObject val = Object.Instantiate<GameObject>(screenVeinEffect, overrideTransform);
				val.transform.localPosition = Vector3.zero;
				val.transform.localRotation = Quaternion.identity;
				activeVeinEffect = val.GetComponent<EnemyShadowScreenVeinEffect>();
			}
			if (Object.op_Implicit((Object)(object)activeVeinEffect))
			{
				activeVeinEffect.Active();
			}
		}
	}

	private void PlayerTargetStopTell()
	{
		//IL_0041: Unknown result type (might be due to invalid IL or missing references)
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		if (Object.op_Implicit((Object)(object)playerTargetPrevious) && playerTargetPrevious.isLocal && !playerTargetPrevious.isDisabled)
		{
			anim.PlayUntargetedSound(((Component)playerTargetPrevious).transform.position);
			PostProcessing.Instance.VignetteOverride(new Color(0.3f, 0.6f, 0.5f), 0.15f, 1f, 2f, 1f, 0.3f, ((Component)this).gameObject);
			PostProcessing.Instance.SaturationOverride(10f, 2f, 1f, 0.3f, ((Component)this).gameObject);
			PostProcessing.Instance.ContrastOverride(-3f, 2f, 1f, 0.3f, ((Component)this).gameObject);
			GameDirector.instance.CameraImpact.Shake(0.5f, 0.05f);
			GameDirector.instance.CameraShake.Shake(1.5f, 0.1f);
		}
	}

	private Vector3 GetLookTargetWorld()
	{
		//IL_002a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0013: Unknown result type (might be due to invalid IL or missing references)
		//IL_001e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0023: Unknown result type (might be due to invalid IL or missing references)
		if (!Object.op_Implicit((Object)(object)playerTarget))
		{
			return ((Component)this).transform.position + ((Component)this).transform.forward;
		}
		return PlayerTargetEyePos();
	}

	private Vector3 PlayerTargetEyePos()
	{
		//IL_003c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0041: Unknown result type (might be due to invalid IL or missing references)
		//IL_0052: Unknown result type (might be due to invalid IL or missing references)
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_0029: Unknown result type (might be due to invalid IL or missing references)
		Vector3 position;
		if (SemiFunc.IsMultiplayer() && !playerTarget.isLocal)
		{
			position = playerTarget.playerAvatarVisuals.headLookAtTransform.position;
		}
		else
		{
			position = playerTarget.localCamera.GetOverrideTransform().position;
			position.y -= 0.3f;
		}
		return position;
	}

	private Quaternion BuildClampedLocalRotation(Transform _pivot, Transform _parent, Vector3 _targetWorld, float _yawLimit, float _pitchUpLimit, float _pitchDownLimit)
	{
		//IL_0000: Unknown result type (might be due to invalid IL or missing references)
		//IL_0002: Unknown result type (might be due to invalid IL or missing references)
		//IL_0007: Unknown result type (might be due to invalid IL or missing references)
		//IL_000c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0023: Unknown result type (might be due to invalid IL or missing references)
		//IL_001b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0038: Unknown result type (might be due to invalid IL or missing references)
		//IL_0030: Unknown result type (might be due to invalid IL or missing references)
		//IL_003d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0042: Unknown result type (might be due to invalid IL or missing references)
		//IL_0044: Unknown result type (might be due to invalid IL or missing references)
		//IL_0049: Unknown result type (might be due to invalid IL or missing references)
		//IL_004e: Unknown result type (might be due to invalid IL or missing references)
		//IL_004f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0054: Unknown result type (might be due to invalid IL or missing references)
		//IL_0055: Unknown result type (might be due to invalid IL or missing references)
		//IL_005a: Unknown result type (might be due to invalid IL or missing references)
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0060: Unknown result type (might be due to invalid IL or missing references)
		//IL_0065: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0070: Unknown result type (might be due to invalid IL or missing references)
		//IL_007d: Unknown result type (might be due to invalid IL or missing references)
		//IL_00aa: Unknown result type (might be due to invalid IL or missing references)
		//IL_00af: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b1: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b6: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b8: Unknown result type (might be due to invalid IL or missing references)
		Vector3 val = _targetWorld - _pivot.position;
		if (val.sqrMagnitude <= 0.0001f)
		{
			return Quaternion.identity;
		}
		Quaternion val2 = Quaternion.LookRotation(val.normalized, Object.op_Implicit((Object)(object)_parent) ? _parent.up : Vector3.up);
		Quaternion val3 = Quaternion.Inverse(_parent.rotation) * val2;
		Quaternion val4 = Quaternion.Inverse(Quaternion.identity) * val3;
		Vector3 eulerAngles = val4.eulerAngles;
		float num = Normalize180(eulerAngles.x);
		float num2 = Normalize180(eulerAngles.y);
		num2 = Mathf.Clamp(num2, 0f - _yawLimit, _yawLimit);
		Quaternion val5 = Quaternion.Euler(Mathf.Clamp(num, 0f - _pitchUpLimit, _pitchDownLimit), num2, 0f);
		return Quaternion.identity * val5;
	}

	private float Normalize180(float angle)
	{
		angle %= 360f;
		if (angle > 180f)
		{
			angle -= 360f;
		}
		if (angle < -180f)
		{
			angle += 360f;
		}
		return angle;
	}

	private float DistanceFromPlayer()
	{
		//IL_001e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0023: Unknown result type (might be due to invalid IL or missing references)
		//IL_002a: Unknown result type (might be due to invalid IL or missing references)
		//IL_002f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0048: Unknown result type (might be due to invalid IL or missing references)
		//IL_0049: Unknown result type (might be due to invalid IL or missing references)
		if (!Object.op_Implicit((Object)(object)playerTarget))
		{
			return float.PositiveInfinity;
		}
		Vector3 position = ((Component)playerTarget).transform.position;
		Vector3 position2 = ((Component)this).transform.position;
		position.y = 0f;
		position2.y = 0f;
		return Vector3.Distance(position, position2);
	}

	private Collider[] GetCollidingColliders(Transform _collisionChecker, Vector3 _pos)
	{
		//IL_0000: Unknown result type (might be due to invalid IL or missing references)
		//IL_0002: Unknown result type (might be due to invalid IL or missing references)
		//IL_000c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0012: Unknown result type (might be due to invalid IL or missing references)
		//IL_0017: Unknown result type (might be due to invalid IL or missing references)
		return Physics.OverlapBox(_pos, _collisionChecker.lossyScale / 2f, _collisionChecker.rotation, LayerMask.op_Implicit(SemiFunc.LayerMaskGetVisionObstruct()));
	}

	private Collider[] GetCollidingCollidersCapsule(Vector3 _pos, CapsuleCollider _capsuleReference)
	{
		//IL_0008: Unknown result type (might be due to invalid IL or missing references)
		//IL_000d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0032: Unknown result type (might be due to invalid IL or missing references)
		//IL_0038: Unknown result type (might be due to invalid IL or missing references)
		//IL_004b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0055: Unknown result type (might be due to invalid IL or missing references)
		//IL_005a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0067: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0080: Unknown result type (might be due to invalid IL or missing references)
		//IL_008a: Unknown result type (might be due to invalid IL or missing references)
		//IL_008f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0099: Unknown result type (might be due to invalid IL or missing references)
		//IL_009f: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b2: Unknown result type (might be due to invalid IL or missing references)
		//IL_00bc: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c1: Unknown result type (might be due to invalid IL or missing references)
		//IL_010b: Unknown result type (might be due to invalid IL or missing references)
		//IL_010c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0110: Unknown result type (might be due to invalid IL or missing references)
		//IL_0115: Unknown result type (might be due to invalid IL or missing references)
		//IL_011a: Unknown result type (might be due to invalid IL or missing references)
		//IL_011b: Unknown result type (might be due to invalid IL or missing references)
		//IL_011f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0124: Unknown result type (might be due to invalid IL or missing references)
		//IL_0129: Unknown result type (might be due to invalid IL or missing references)
		//IL_012b: Unknown result type (might be due to invalid IL or missing references)
		//IL_012e: Unknown result type (might be due to invalid IL or missing references)
		//IL_00cb: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d1: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e4: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ee: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f3: Unknown result type (might be due to invalid IL or missing references)
		Transform transform = ((Component)_capsuleReference).transform;
		Vector3 lossyScale = transform.lossyScale;
		float num;
		float num2;
		Vector3 val;
		switch (_capsuleReference.direction)
		{
		case 0:
			num = _capsuleReference.radius * Mathf.Max(lossyScale.y, lossyScale.z);
			num2 = _capsuleReference.height * lossyScale.x;
			val = transform.right;
			break;
		case 1:
			num = _capsuleReference.radius * Mathf.Max(lossyScale.x, lossyScale.z);
			num2 = _capsuleReference.height * lossyScale.y;
			val = transform.up;
			break;
		case 2:
			num = _capsuleReference.radius * Mathf.Max(lossyScale.x, lossyScale.y);
			num2 = _capsuleReference.height * lossyScale.z;
			val = transform.forward;
			break;
		default:
			num = _capsuleReference.radius * Mathf.Max(lossyScale.x, lossyScale.z);
			num2 = _capsuleReference.height * lossyScale.y;
			val = transform.up;
			break;
		}
		float num3 = Mathf.Max(0f, num2 / 2f - num);
		Vector3 val2 = _pos + val * num3;
		Vector3 val3 = _pos - val * num3;
		return Physics.OverlapCapsule(val2, val3, num, LayerMask.op_Implicit(SemiFunc.LayerMaskGetVisionObstruct()));
	}

	private PlayerAvatar GetNearestPlayer()
	{
		//IL_0023: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Unknown result type (might be due to invalid IL or missing references)
		PlayerAvatar result = null;
		List<PlayerAvatar> list = SemiFunc.PlayerGetList();
		float num = float.PositiveInfinity;
		foreach (PlayerAvatar item in list)
		{
			float num2 = Vector3.Distance(((Component)item).transform.position, ((Component)this).transform.position);
			if (num2 < num)
			{
				num = num2;
				result = item;
			}
		}
		return result;
	}

	private bool IsColliding(Transform _collisionChecker, Vector3 _pos)
	{
		//IL_0002: Unknown result type (might be due to invalid IL or missing references)
		Collider[] collidingColliders = GetCollidingColliders(_collisionChecker, _pos);
		for (int i = 0; i < collidingColliders.Length; i++)
		{
			if (!((Component)collidingColliders[i]).transform.IsChildOf(((Component)enemy.EnemyParent).transform))
			{
				return true;
			}
		}
		return false;
	}

	private bool IsCollidingCapsule(Vector3 _pos, CapsuleCollider _capsuleReference)
	{
		//IL_0001: Unknown result type (might be due to invalid IL or missing references)
		Collider[] collidingCollidersCapsule = GetCollidingCollidersCapsule(_pos, _capsuleReference);
		for (int i = 0; i < collidingCollidersCapsule.Length; i++)
		{
			if (!((Component)collidingCollidersCapsule[i]).transform.IsChildOf(((Component)enemy.EnemyParent).transform))
			{
				return true;
			}
		}
		return false;
	}

	private bool HandsInPositionToSlap()
	{
		//IL_0006: Unknown result type (might be due to invalid IL or missing references)
		//IL_000d: Unknown result type (might be due to invalid IL or missing references)
		//IL_001d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		float num = Vector3.Distance(rightWristPivot.position, GetHandTarget(_rightHand: true));
		float num2 = Vector3.Distance(leftWristPivot.position, GetHandTarget(_rightHand: false));
		if (num < 0.15f)
		{
			return num2 < 0.15f;
		}
		return false;
	}

	private bool HandsInDownPositionToSlap()
	{
		//IL_0006: Unknown result type (might be due to invalid IL or missing references)
		//IL_0011: Unknown result type (might be due to invalid IL or missing references)
		//IL_001b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0020: Unknown result type (might be due to invalid IL or missing references)
		//IL_0025: Unknown result type (might be due to invalid IL or missing references)
		//IL_002c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0037: Unknown result type (might be due to invalid IL or missing references)
		//IL_0041: Unknown result type (might be due to invalid IL or missing references)
		//IL_0046: Unknown result type (might be due to invalid IL or missing references)
		//IL_004b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0052: Unknown result type (might be due to invalid IL or missing references)
		//IL_005c: Unknown result type (might be due to invalid IL or missing references)
		//IL_006a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0074: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e8: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f2: Unknown result type (might be due to invalid IL or missing references)
		//IL_0082: Unknown result type (might be due to invalid IL or missing references)
		//IL_008c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0100: Unknown result type (might be due to invalid IL or missing references)
		//IL_010a: Unknown result type (might be due to invalid IL or missing references)
		//IL_009a: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a4: Unknown result type (might be due to invalid IL or missing references)
		//IL_0118: Unknown result type (might be due to invalid IL or missing references)
		//IL_0122: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b2: Unknown result type (might be due to invalid IL or missing references)
		//IL_00bc: Unknown result type (might be due to invalid IL or missing references)
		//IL_0130: Unknown result type (might be due to invalid IL or missing references)
		//IL_013a: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ca: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d4: Unknown result type (might be due to invalid IL or missing references)
		//IL_0148: Unknown result type (might be due to invalid IL or missing references)
		//IL_0152: Unknown result type (might be due to invalid IL or missing references)
		//IL_0160: Unknown result type (might be due to invalid IL or missing references)
		//IL_016a: Unknown result type (might be due to invalid IL or missing references)
		Vector3 val = handAreaUnderSlapReady.position - handAreaUnderSlapReady.localScale / 2f;
		Vector3 val2 = handAreaUnderSlapReady.position + handAreaUnderSlapReady.localScale / 2f;
		bool num = rightWristPivot.position.x >= val.x && rightWristPivot.position.x <= val2.x && rightWristPivot.position.y >= val.y && rightWristPivot.position.y <= val2.y && rightWristPivot.position.z >= val.z && rightWristPivot.position.z <= val2.z;
		bool flag = leftWristPivot.position.x >= val.x && leftWristPivot.position.x <= val2.x && leftWristPivot.position.y >= val.y && leftWristPivot.position.y <= val2.y && leftWristPivot.position.z >= val.z && leftWristPivot.position.z <= val2.z;
		return num & flag;
	}

	private bool VisionBlocked()
	{
		//IL_0033: Unknown result type (might be due to invalid IL or missing references)
		//IL_0049: Unknown result type (might be due to invalid IL or missing references)
		//IL_004e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0053: Unknown result type (might be due to invalid IL or missing references)
		//IL_005b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0060: Unknown result type (might be due to invalid IL or missing references)
		if (Time.time - visionBlockedCheckTime > 0.2f && Object.op_Implicit((Object)(object)playerTarget))
		{
			Vector3 position = playerTarget.PlayerVisionTarget.VisionTransform.position;
			visionBlockedCheckTime = Time.time;
			Vector3 val = position - visionTransform.position;
			visionBlocked = Physics.Raycast(visionTransform.position, val, val.magnitude, LayerMask.GetMask(new string[1] { "Default" }) + LayerMask.GetMask(new string[1] { "PhysGrabObjectHinge" }), (QueryTriggerInteraction)1);
		}
		return visionBlocked;
	}

	private static double NetNow()
	{
		if (!SemiFunc.IsMultiplayer())
		{
			return Time.time;
		}
		return PhotonNetwork.Time;
	}

	public EnemyShadow()
	{
		//IL_0017: Unknown result type (might be due to invalid IL or missing references)
		//IL_0021: Expected Obj, but got Unknown
		//IL_01c7: Unknown result type (might be due to invalid IL or missing references)
		//IL_01cc: Unknown result type (might be due to invalid IL or missing references)
		//IL_01dd: Unknown result type (might be due to invalid IL or missing references)
		//IL_01e2: Unknown result type (might be due to invalid IL or missing references)
		//IL_01f3: Unknown result type (might be due to invalid IL or missing references)
		//IL_01f8: Unknown result type (might be due to invalid IL or missing references)
		//IL_0209: Unknown result type (might be due to invalid IL or missing references)
		//IL_020e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0213: Unknown result type (might be due to invalid IL or missing references)
		//IL_021d: Expected Obj, but got Unknown
		//IL_0230: Unknown result type (might be due to invalid IL or missing references)
		//IL_0235: Unknown result type (might be due to invalid IL or missing references)
		//IL_0246: Unknown result type (might be due to invalid IL or missing references)
		//IL_024b: Unknown result type (might be due to invalid IL or missing references)
		//IL_025c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0261: Unknown result type (might be due to invalid IL or missing references)
		//IL_0272: Unknown result type (might be due to invalid IL or missing references)
		//IL_0277: Unknown result type (might be due to invalid IL or missing references)
		//IL_027c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0286: Expected Obj, but got Unknown
		//IL_02a4: Unknown result type (might be due to invalid IL or missing references)
		//IL_02a9: Unknown result type (might be due to invalid IL or missing references)
		//IL_02ba: Unknown result type (might be due to invalid IL or missing references)
		//IL_02bf: Unknown result type (might be due to invalid IL or missing references)
		//IL_02d0: Unknown result type (might be due to invalid IL or missing references)
		//IL_02d5: Unknown result type (might be due to invalid IL or missing references)
		//IL_02e6: Unknown result type (might be due to invalid IL or missing references)
		//IL_02eb: Unknown result type (might be due to invalid IL or missing references)
		//IL_02f0: Unknown result type (might be due to invalid IL or missing references)
		//IL_02fa: Expected Obj, but got Unknown
		//IL_0323: Unknown result type (might be due to invalid IL or missing references)
		//IL_0328: Unknown result type (might be due to invalid IL or missing references)
		//IL_0339: Unknown result type (might be due to invalid IL or missing references)
		//IL_033e: Unknown result type (might be due to invalid IL or missing references)
		//IL_034f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0354: Unknown result type (might be due to invalid IL or missing references)
		//IL_0359: Unknown result type (might be due to invalid IL or missing references)
		//IL_0363: Expected Obj, but got Unknown
		//IL_0373: Unknown result type (might be due to invalid IL or missing references)
		//IL_0378: Unknown result type (might be due to invalid IL or missing references)
		//IL_03a6: Unknown result type (might be due to invalid IL or missing references)
		//IL_03ab: Unknown result type (might be due to invalid IL or missing references)
		//IL_03bc: Unknown result type (might be due to invalid IL or missing references)
		//IL_03c1: Unknown result type (might be due to invalid IL or missing references)
		//IL_03d2: Unknown result type (might be due to invalid IL or missing references)
		//IL_03d7: Unknown result type (might be due to invalid IL or missing references)
		//IL_03e8: Unknown result type (might be due to invalid IL or missing references)
		//IL_03ed: Unknown result type (might be due to invalid IL or missing references)
		//IL_03fe: Unknown result type (might be due to invalid IL or missing references)
		//IL_0403: Unknown result type (might be due to invalid IL or missing references)
		//IL_0408: Unknown result type (might be due to invalid IL or missing references)
		//IL_0412: Expected Obj, but got Unknown
		//IL_0438: Unknown result type (might be due to invalid IL or missing references)
		//IL_043d: Unknown result type (might be due to invalid IL or missing references)
		//IL_04c3: Unknown result type (might be due to invalid IL or missing references)
		//IL_04c8: Unknown result type (might be due to invalid IL or missing references)
		//IL_04d9: Unknown result type (might be due to invalid IL or missing references)
		//IL_04de: Unknown result type (might be due to invalid IL or missing references)
		//IL_04ef: Unknown result type (might be due to invalid IL or missing references)
		//IL_04f4: Unknown result type (might be due to invalid IL or missing references)
		//IL_04f9: Unknown result type (might be due to invalid IL or missing references)
		//IL_0503: Expected Obj, but got Unknown
		//IL_055c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0561: Unknown result type (might be due to invalid IL or missing references)
		//IL_0642: Unknown result type (might be due to invalid IL or missing references)
		//IL_0647: Unknown result type (might be due to invalid IL or missing references)
		//IL_065c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0661: Unknown result type (might be due to invalid IL or missing references)
		//IL_067c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0696: Unknown result type (might be due to invalid IL or missing references)
		//IL_06b0: Unknown result type (might be due to invalid IL or missing references)
		//IL_06d5: Unknown result type (might be due to invalid IL or missing references)
		//IL_06ef: Unknown result type (might be due to invalid IL or missing references)
		//IL_0709: Unknown result type (might be due to invalid IL or missing references)
	}
}
