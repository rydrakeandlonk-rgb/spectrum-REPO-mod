using UnityEngine;
using UnityEngine.UI;

public class MenuElementHover : MonoBehaviour
{
	private RectTransform rectTransform;

	private float buttonPitch;

	public bool hasHoverEffect = true;

	internal string menuID = "-1";

	private float disableTimer;

	private MenuScrollBox menuScrollBox;

	private ScrollRect scrollRect;

	internal bool isHovering { get; private set; }

	public MenuSelectableElement menuSelectableElement { get; private set; }

	public MenuPage parentPage { get; private set; }

	internal bool JustBecameCurrentTarget
	{
		get
		{
			if ((Object)(object)MenuManager.instance != (Object)null)
			{
				return MenuManager.instance.currentTargetChangedThisFrame;
			}
			return false;
		}
	}

	private void Awake()
	{
		rectTransform = ((Component)this).GetComponent<RectTransform>();
		menuSelectableElement = ((Component)this).GetComponent<MenuSelectableElement>();
		parentPage = ((Component)this).GetComponentInParent<MenuPage>();
		menuScrollBox = ((Component)this).GetComponentInParent<MenuScrollBox>();
		scrollRect = ((Component)this).GetComponentInParent<ScrollRect>();
	}

	private void Start()
	{
		buttonPitch = SemiFunc.MenuGetPitchFromYPos(rectTransform);
		if (Object.op_Implicit((Object)(object)menuSelectableElement))
		{
			menuID = menuSelectableElement.menuID;
		}
	}

	private void OnEnable()
	{
		MenuManager.instance?.RegisterHoverElement(this);
	}

	private void OnDisable()
	{
		MenuManager.instance?.UnregisterHoverElement(this);
	}

	private void Update()
	{
		//IL_00fa: Unknown result type (might be due to invalid IL or missing references)
		//IL_0100: Unknown result type (might be due to invalid IL or missing references)
		//IL_0103: Unknown result type (might be due to invalid IL or missing references)
		//IL_0109: Unknown result type (might be due to invalid IL or missing references)
		if (disableTimer > 0f)
		{
			disableTimer -= Time.deltaTime;
			isHovering = false;
		}
		else if (SemiFunc.InputMode() == InputModes.MouseAndKeyboard && Object.op_Implicit((Object)(object)MenuManager.instance) && !MenuManager.instance.isKeyboardNavigating && SemiFunc.UIMouseHover(parentPage, rectTransform, menuID, 0f, 0f, menuScrollBox, scrollRect))
		{
			OnHoverStart();
		}
		else if (Object.op_Implicit((Object)(object)menuSelectableElement) && Object.op_Implicit((Object)(object)MenuManager.instance) && (SemiFunc.InputMode() == InputModes.Gamepad || MenuManager.instance.isKeyboardNavigating) && menuID == MenuManager.instance.currentMenuID)
		{
			OnHoverStart();
		}
		else if (isHovering)
		{
			isHovering = false;
		}
		if (hasHoverEffect && isHovering)
		{
			SemiFunc.MenuSelectionBoxTargetSet(parentPage, rectTransform);
		}
	}

	public void OnHoverStart()
	{
		if (!isHovering && hasHoverEffect)
		{
			MenuManager.instance.MenuEffectHover(buttonPitch);
		}
		isHovering = true;
	}

	public void Disable()
	{
		disableTimer = 0.1f;
	}
}
