using TMPro;
using UnityEngine;

public class ChatUI : SemiUI
{
	public static ChatUI instance;

	public RectTransform chatBackgroundRect;

	public TextMeshProUGUI chatPrefixText;

	public TextMeshProUGUI chatText;

	public int chatPrefixTextOffset = 5;

	public int chatTextOffset = 8;

	[RuntimeInitializeOnLoadMethod(/*Could not decode attribute arguments.*/)]
	private static void RuntimeInitializeOnLoad()
	{
		instance = null;
	}

	protected override void Start()
	{
		base.Start();
		instance = this;
	}

	protected override void Update()
	{
		base.Update();
	}

	public void SetChatTextOffset()
	{
		//IL_0006: Unknown result type (might be due to invalid IL or missing references)
		//IL_000b: Unknown result type (might be due to invalid IL or missing references)
		//IL_015a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0180: Unknown result type (might be due to invalid IL or missing references)
		//IL_019a: Unknown result type (might be due to invalid IL or missing references)
		//IL_01a4: Unknown result type (might be due to invalid IL or missing references)
		//IL_01d5: Unknown result type (might be due to invalid IL or missing references)
		//IL_01ef: Unknown result type (might be due to invalid IL or missing references)
		//IL_01f9: Unknown result type (might be due to invalid IL or missing references)
		//IL_004a: Unknown result type (might be due to invalid IL or missing references)
		//IL_004f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0067: Unknown result type (might be due to invalid IL or missing references)
		//IL_0081: Unknown result type (might be due to invalid IL or missing references)
		//IL_0086: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a7: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c1: Unknown result type (might be due to invalid IL or missing references)
		//IL_00cb: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ec: Unknown result type (might be due to invalid IL or missing references)
		//IL_010b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0125: Unknown result type (might be due to invalid IL or missing references)
		//IL_012f: Unknown result type (might be due to invalid IL or missing references)
		Vector2 preferredValues = ((TMP_Text)chatPrefixText).GetPreferredValues();
		if (Object.op_Implicit((Object)(object)LocalizationManager.instance.ActiveLocale) && LocalizationManager.instance.ActiveLocale.RightToLeft)
		{
			((TMP_Text)chatText).alignment = (TextAlignmentOptions)1028;
			Rect rect = chatBackgroundRect.rect;
			Transform transform = ((Component)chatText).gameObject.transform;
			float num = rect.width - preferredValues.x - (float)chatPrefixTextOffset;
			Rect rect2 = ((TMP_Text)chatText).rectTransform.rect;
			transform.localPosition = new Vector3(num - rect2.width - (float)chatTextOffset, ((Component)chatText).gameObject.transform.localPosition.y, ((Component)chatText).gameObject.transform.localPosition.z);
			((Component)chatPrefixText).gameObject.transform.localPosition = new Vector3(rect.width - preferredValues.x - (float)chatPrefixTextOffset, ((Component)chatPrefixText).gameObject.transform.localPosition.y, ((Component)chatPrefixText).gameObject.transform.localPosition.z);
		}
		else
		{
			((TMP_Text)chatText).alignment = (TextAlignmentOptions)1025;
			((Component)chatText).gameObject.transform.localPosition = new Vector3(preferredValues.x + (float)chatPrefixTextOffset + (float)chatTextOffset, ((Component)chatText).gameObject.transform.localPosition.y, ((Component)chatText).gameObject.transform.localPosition.z);
			((Component)chatPrefixText).gameObject.transform.localPosition = new Vector3((float)chatPrefixTextOffset, ((Component)chatPrefixText).gameObject.transform.localPosition.y, ((Component)chatPrefixText).gameObject.transform.localPosition.z);
		}
	}
}
