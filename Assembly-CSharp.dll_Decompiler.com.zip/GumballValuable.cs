using System.Collections.Generic;
using Photon.Pun;
using UnityEngine;

public class GumballValuable : Trap
{
	[Header("Transforms")]
	public Transform closedLidsMesh;

	public Transform openLidsMesh;

	public Transform eyeBallMesh;

	public Transform bodyTransform;

	public Transform eyeLockTransform;

	public Transform globe;

	public Transform HypnosisLinesParenTransform;

	public Transform eyeLineParent;

	[Header("Line of sight transforms")]
	public Transform top;

	public Transform bottom;

	public Transform front;

	public Transform back;

	[Header("Lights")]
	public Light pointLight;

	public AnimationCurve lightIntensityCurve;

	[Header("Hypnosis Line GameObject")]
	public GameObject hypnosisLine;

	[Header("Particles")]
	public List<ParticleSystem> particles = new List<ParticleSystem>();

	[Header("Camera Shake")]
	public float cameraShakeTime = 0.2f;

	public float cameraShakeStrength = 3f;

	public Vector2 cameraShakeBounds = new Vector2(1.5f, 5f);

	[Header("Vignette")]
	public float vignetteIntensity = 0.5f;

	[Header("Camera Zoom")]
	public float cameraZoomSpeedIn = 0.5f;

	public float cameraZoomSpeedOut = 0.5f;

	public float cameraZoomAmount = 20f;

	[Header("EyeLock")]
	public float noAimStrength = 1.5f;

	[Header("Spiral on screen")]
	public GameObject screenSpiralEffect;

	[Header("Sounds")]
	public Sound eyesOpenSound;

	public Sound eyesCloseSound;

	public Sound hypnosisSoundLoop;

	private float lightIntensityOriginal;

	private float lightRangeOriginal;

	private float animationCurveEval;

	private int playerCount;

	private List<PlayerAvatar> allPlayers;

	private List<bool> playerInSight = new List<bool>();

	private List<GameObject> hypnosisLines = new List<GameObject>();

	private SpiralOnScreen spiralScreenEffect;

	private EyeLines eyeLines;

	private bool isActive;

	private int oldPlayerCount;

	private List<bool> previouslySeenList = new List<bool>();

	protected override void Start()
	{
		base.Start();
		CloseEyes();
		GetValues();
		InstantiateHypnosisLines();
	}

	private void InstantiateHypnosisLines()
	{
		for (int i = 0; i < playerCount; i++)
		{
			hypnosisLines.Add(HypnosisLineCreate(allPlayers[i]));
		}
	}

	private GameObject HypnosisLineCreate(PlayerAvatar _player)
	{
		//IL_000c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0011: Unknown result type (might be due to invalid IL or missing references)
		//IL_0037: Unknown result type (might be due to invalid IL or missing references)
		//IL_0047: Unknown result type (might be due to invalid IL or missing references)
		GameObject val = Object.Instantiate<GameObject>(hypnosisLine, ((Component)this).transform.position, Quaternion.identity);
		val.transform.SetParent(_player.localCamera.GetOverrideTransform());
		val.transform.localPosition = Vector3.zero;
		val.transform.localRotation = Quaternion.identity;
		val.GetComponent<EyeLines>().InitializeLine(_player);
		val.transform.SetParent(HypnosisLinesParenTransform);
		val.SetActive(false);
		return val;
	}

	private void GetValues()
	{
		allPlayers = SemiFunc.PlayerGetList();
		playerCount = allPlayers.Count;
		for (int i = 0; i < playerCount; i++)
		{
			playerInSight.Add(item: false);
			previouslySeenList.Add(item: false);
		}
		lightIntensityOriginal = pointLight.intensity;
		lightRangeOriginal = pointLight.range;
	}

	protected override void Update()
	{
		base.Update();
		if (physGrabObject.grabbed && !isActive)
		{
			OpenEyes();
		}
		else if (!physGrabObject.grabbed && isActive)
		{
			CloseEyes();
		}
		CheckForLeftPlayers();
		ClientEffectsLoop();
		if (SemiFunc.IsMasterClientOrSingleplayer() && isActive)
		{
			CheckForListChange();
		}
	}

	public void ClientEffectsLoop()
	{
		hypnosisSoundLoop.PlayLoop(isActive, 1f, 1f);
		for (int i = 0; i < playerCount; i++)
		{
			if (playerCount == 0)
			{
				break;
			}
			EyeLines component = hypnosisLines[i].GetComponent<EyeLines>();
			if (playerInSight[i])
			{
				hypnosisLines[i].SetActive(true);
				component.SetIsActive(_isActive: true);
				if (allPlayers[i].isLocal)
				{
					VignetteOverride();
					ScreenSpiralOn();
					CameraAimAndZoom(allPlayers[i]);
					PlayerAvatarOverride(allPlayers[i]);
					PostProcessing.Instance.SaturationOverride(-50f, 0.8f, 5f, 0.1f, ((Component)this).gameObject);
				}
			}
			else
			{
				component.SetIsActive(_isActive: false);
			}
			if (!allPlayers[i].isLocal)
			{
				DrawHypnosisLines(allPlayers[i], hypnosisLines[i]);
			}
		}
		if (((Behaviour)pointLight).enabled && !isActive)
		{
			LerpLightOff(pointLight);
		}
		else if (isActive)
		{
			LerpLightOn(pointLight);
		}
	}

	private void CheckForListChange()
	{
		if (SemiFunc.PerSecond(5f, (Object)(object)this))
		{
			GetAffectedPlayers();
		}
	}

	private void CheckForLeftPlayers()
	{
		if (playerCount != SemiFunc.PlayerGetList().Count)
		{
			RedoPlayersInSightList();
			UpdateHypnosisLinesList();
			playerCount = SemiFunc.PlayerGetList().Count;
			allPlayers = SemiFunc.PlayerGetList();
		}
	}

	private void TurnOffHypnosisLines()
	{
		for (int i = 0; i < playerCount; i++)
		{
			hypnosisLines[i].SetActive(false);
		}
	}

	private void OpenEyes()
	{
		//IL_0032: Unknown result type (might be due to invalid IL or missing references)
		isActive = true;
		GetAffectedPlayers();
		UpdateMeshes();
		ToggleParticles(_state: true);
		ScreenSpiralOn();
		CameraShake();
		eyesOpenSound.Play(globe.position);
		if (!((Behaviour)pointLight).enabled)
		{
			SetLightEnableState(_state: true);
		}
	}

	private void CloseEyes()
	{
		//IL_0026: Unknown result type (might be due to invalid IL or missing references)
		isActive = false;
		UpdateMeshes();
		ToggleParticles(_state: false);
		CameraShake();
		eyesCloseSound.Play(globe.position);
		EmptyPlayersInSightList();
	}

	private void CameraAimAndZoom(PlayerAvatar _player)
	{
		//IL_0023: Unknown result type (might be due to invalid IL or missing references)
		if (!physGrabObject.playerGrabbing.Contains(_player.physGrabber))
		{
			CameraAim.Instance.AimTargetSoftSet(eyeLockTransform.position, 0.1f, 2f, noAimStrength, ((Component)this).gameObject, 100);
		}
		CameraZoom.Instance.OverrideZoomSet(cameraZoomAmount, 0.1f, 2f, 2f, ((Component)this).gameObject, 100);
	}

	private void PlayerAvatarOverride(PlayerAvatar _player)
	{
		//IL_003e: Unknown result type (might be due to invalid IL or missing references)
		_player.playerHealth.EyeMaterialOverride(PlayerHealth.EyeOverrideState.Inverted, 0.25f, 0);
		_player.OverridePupilSize(3f, 4, 3f, 1f, 15f, 0.3f);
		SemiFunc.PlayerEyesOverride(_player, eyeBallMesh.position, 0.1f, ((Component)this).gameObject);
	}

	private void DrawHypnosisLines(PlayerAvatar _player, GameObject _hypnosisLine)
	{
		EyeLines component = _hypnosisLine.GetComponent<EyeLines>();
		if (_hypnosisLine.activeSelf)
		{
			component.DrawLines();
		}
	}

	private void UpdateMeshes()
	{
		((Component)closedLidsMesh).gameObject.SetActive(!isActive);
		((Component)openLidsMesh).gameObject.SetActive(isActive);
		((Component)eyeBallMesh).gameObject.SetActive(isActive);
	}

	private void CameraShake()
	{
		//IL_0020: Unknown result type (might be due to invalid IL or missing references)
		//IL_005c: Unknown result type (might be due to invalid IL or missing references)
		GameDirector.instance.CameraShake.ShakeDistance(cameraShakeStrength, 3f, 8f, ((Component)this).transform.position, cameraShakeTime);
		GameDirector.instance.CameraImpact.ShakeDistance(cameraShakeStrength, cameraShakeBounds.x, cameraShakeBounds.y, ((Component)this).transform.position, cameraShakeTime);
	}

	private void ToggleParticles(bool _state)
	{
		if (_state)
		{
			foreach (ParticleSystem particle in particles)
			{
				particle.Play();
			}
			return;
		}
		foreach (ParticleSystem particle2 in particles)
		{
			particle2.Stop();
		}
	}

	private void VignetteOverride()
	{
		//IL_0014: Unknown result type (might be due to invalid IL or missing references)
		PostProcessing.Instance.VignetteOverride(new Color(0f, 0f, 0f), vignetteIntensity, 0.5f, 0.1f, 2f, 0.1f, ((Component)this).gameObject);
	}

	private void ScreenSpiralOn()
	{
		//IL_008e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0093: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a5: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b5: Unknown result type (might be due to invalid IL or missing references)
		if (!Object.op_Implicit((Object)(object)spiralScreenEffect) && Object.op_Implicit((Object)(object)PlayerAvatar.instance))
		{
			spiralScreenEffect = ((Component)PlayerAvatar.instance.localCamera.GetOverrideTransform()).GetComponentInChildren<SpiralOnScreen>();
		}
		if (!Object.op_Implicit((Object)(object)spiralScreenEffect))
		{
			for (int i = 0; i < playerCount; i++)
			{
				if (allPlayers[i].isLocal && playerInSight[i])
				{
					Transform overrideTransform = allPlayers[i].localCamera.GetOverrideTransform();
					GameObject val = Object.Instantiate<GameObject>(screenSpiralEffect, ((Component)this).transform.position, Quaternion.identity, overrideTransform);
					val.transform.localPosition = Vector3.zero;
					val.transform.localRotation = Quaternion.identity;
					spiralScreenEffect = val.GetComponent<SpiralOnScreen>();
					break;
				}
			}
		}
		if (Object.op_Implicit((Object)(object)spiralScreenEffect) && !SemiFunc.Photosensitivity() && !PlayerAvatar.instance.localCamera.GetOverrideActive())
		{
			spiralScreenEffect.Active();
		}
	}

	private void SetLightEnableState(bool _state)
	{
		pointLight.intensity = 0f;
		pointLight.range = 0f;
		animationCurveEval = 0f;
		((Behaviour)pointLight).enabled = _state;
	}

	private void LerpLightOn(Light _light)
	{
		if (_light.intensity < lightIntensityOriginal - 0.01f)
		{
			animationCurveEval += Time.deltaTime * 0.2f;
			float num = lightIntensityCurve.Evaluate(animationCurveEval);
			_light.intensity = Mathf.Lerp(_light.intensity, lightIntensityOriginal, num);
			_light.range = Mathf.Lerp(_light.range, lightRangeOriginal, num);
		}
	}

	private void LerpLightOff(Light _light)
	{
		animationCurveEval += Time.deltaTime * 1f;
		float num = lightIntensityCurve.Evaluate(animationCurveEval);
		_light.intensity = Mathf.Lerp(_light.intensity, 0f, num);
		_light.range = Mathf.Lerp(_light.range, 0f, num);
		if (pointLight.intensity < 0.01f)
		{
			SetLightEnableState(_state: false);
		}
	}

	private void EmptyPlayersInSightList()
	{
		if (!SemiFunc.IsMasterClientOrSingleplayer())
		{
			return;
		}
		for (int i = 0; i < playerCount; i++)
		{
			if (playerInSight[i])
			{
				PlayerStateChanged(_state: false, allPlayers[i].photonView.ViewID);
			}
		}
	}

	private void GetAffectedPlayers()
	{
		if (!SemiFunc.IsMasterClientOrSingleplayer())
		{
			return;
		}
		for (int i = 0; i < playerCount; i++)
		{
			if (!allPlayers[i].isDisabled)
			{
				if (InLineOfSight(allPlayers[i], i) && !playerInSight[i])
				{
					PlayerStateChanged(_state: true, allPlayers[i].photonView.ViewID);
				}
				else if (!InLineOfSight(allPlayers[i], i) && playerInSight[i])
				{
					PlayerStateChanged(_state: false, allPlayers[i].photonView.ViewID);
				}
			}
		}
	}

	public void PlayerStateChanged(bool _state, int _playerID)
	{
		//IL_003e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0044: Unknown result type (might be due to invalid IL or missing references)
		if (SemiFunc.IsMasterClientOrSingleplayer())
		{
			if (SemiFunc.IsMultiplayer())
			{
				photonView.RPC("PlayerStateChangedRPC", (RpcTarget)0, new object[2] { _state, _playerID });
			}
			else
			{
				PlayerStateChangedRPC(_state, _playerID);
			}
		}
	}

	[PunRPC]
	public void PlayerStateChangedRPC(bool _state, int _playerID, PhotonMessageInfo _info = default(PhotonMessageInfo))
	{
		//IL_0000: Unknown result type (might be due to invalid IL or missing references)
		if (!SemiFunc.MasterOnlyRPC(_info))
		{
			return;
		}
		for (int i = 0; i < playerCount; i++)
		{
			if (allPlayers[i].photonView.ViewID == _playerID)
			{
				playerInSight[i] = _state;
				break;
			}
		}
	}

	private bool InLineOfSight(PlayerAvatar _player, int i)
	{
		//IL_0006: Unknown result type (might be due to invalid IL or missing references)
		//IL_002a: Unknown result type (might be due to invalid IL or missing references)
		//IL_004e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0072: Unknown result type (might be due to invalid IL or missing references)
		if (SemiFunc.PlayerVisionCheck(top.position, 10f, _player, previouslySeenList[i]) || SemiFunc.PlayerVisionCheck(bottom.position, 10f, _player, previouslySeenList[i]) || SemiFunc.PlayerVisionCheck(front.position, 10f, _player, previouslySeenList[i]) || SemiFunc.PlayerVisionCheck(back.position, 10f, _player, previouslySeenList[i]))
		{
			previouslySeenList[i] = true;
		}
		else
		{
			previouslySeenList[i] = false;
		}
		return previouslySeenList[i];
	}

	private void RedoPlayersInSightList()
	{
		for (int i = 0; i < playerCount; i++)
		{
			playerInSight[i] = false;
			previouslySeenList[i] = false;
		}
	}

	private void UpdateHypnosisLinesList()
	{
		TurnOffHypnosisLines();
		List<PlayerAvatar> list = SemiFunc.PlayerGetList();
		for (int i = 0; i < list.Count; i++)
		{
			if (i >= hypnosisLines.Count)
			{
				hypnosisLines.Add(HypnosisLineCreate(list[i]));
				continue;
			}
			hypnosisLines[i].GetComponent<EyeLines>().InitializeLine(list[i]);
			hypnosisLines[i].SetActive(false);
		}
		while (playerInSight.Count < list.Count)
		{
			playerInSight.Add(item: false);
		}
		while (previouslySeenList.Count < list.Count)
		{
			previouslySeenList.Add(item: false);
		}
	}

	private void OnDestroy()
	{
		TurnOffHypnosisLines();
	}

	public GumballValuable()
	{
		//IL_002c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0031: Unknown result type (might be due to invalid IL or missing references)
	}
}
