using UnityEngine;

public class DebugMeshReference : MonoBehaviour
{
	public bool debugEnabled = true;

	[Space]
	public Mesh debugMesh;

	public Color debugColor = new Color(0f, 0.46f, 1f);

	private void Start()
	{
		((Behaviour)this).enabled = false;
	}

	private void OnDrawGizmos()
	{
		//IL_0025: Unknown result type (might be due to invalid IL or missing references)
		//IL_0030: Unknown result type (might be due to invalid IL or missing references)
		//IL_0040: Unknown result type (might be due to invalid IL or missing references)
		//IL_0045: Unknown result type (might be due to invalid IL or missing references)
		//IL_004a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0086: Unknown result type (might be due to invalid IL or missing references)
		//IL_0096: Unknown result type (might be due to invalid IL or missing references)
		//IL_009b: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a0: Unknown result type (might be due to invalid IL or missing references)
		if (((Behaviour)this).enabled && debugEnabled && !((Object)(object)debugMesh == (Object)null))
		{
			Gizmos.matrix = ((Component)this).transform.localToWorldMatrix;
			Gizmos.color = debugColor;
			Gizmos.DrawWireMesh(debugMesh, Vector3.zero, Quaternion.identity, Vector3.one);
			Gizmos.color = new Color(debugColor.r, debugColor.g, debugColor.b, debugColor.a * 0.7f);
			Gizmos.DrawMesh(debugMesh, Vector3.zero, Quaternion.identity, Vector3.one);
		}
	}

	public DebugMeshReference()
	{
		//IL_0017: Unknown result type (might be due to invalid IL or missing references)
		//IL_001c: Unknown result type (might be due to invalid IL or missing references)
	}
}
