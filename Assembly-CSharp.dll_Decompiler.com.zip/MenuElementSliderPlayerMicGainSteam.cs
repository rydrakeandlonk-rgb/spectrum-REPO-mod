using Platforms;
using UnityEngine;
using UnityEngine.UI;

public class MenuElementSliderPlayerMicGainSteam : MonoBehaviour
{
	private MenuElementHover menuElementHover;

	private MenuSliderPlayerMicGain menuSliderPlayerMicGain;

	public RawImage icon;

	public RectTransform iconTransform;

	[Space]
	public AnimationCurve hoverIntroCurve;

	public AnimationCurve hoverOutroCurve;

	private float hoverLerp;

	private bool hovering;

	private Vector3 previousScale;

	private bool colorFetched;

	private void Start()
	{
		if (SemiFunc.RunIsLobbyMenu())
		{
			((Component)this).gameObject.SetActive(false);
		}
		menuElementHover = ((Component)this).GetComponent<MenuElementHover>();
		menuSliderPlayerMicGain = ((Component)this).GetComponentInParent<MenuSliderPlayerMicGain>();
	}

	private void Update()
	{
		//IL_0026: Unknown result type (might be due to invalid IL or missing references)
		//IL_002b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0160: Unknown result type (might be due to invalid IL or missing references)
		//IL_0166: Unknown result type (might be due to invalid IL or missing references)
		//IL_017c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0133: Unknown result type (might be due to invalid IL or missing references)
		//IL_0138: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e0: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e5: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ef: Unknown result type (might be due to invalid IL or missing references)
		//IL_0105: Unknown result type (might be due to invalid IL or missing references)
		if (menuElementHover.isHovering)
		{
			if (!hovering)
			{
				hovering = true;
				previousScale = ((Transform)iconTransform).localScale;
			}
			if (!menuElementHover.JustBecameCurrentTarget && SemiFunc.InputUIClick())
			{
				MenuManager.instance.MenuEffectClick(MenuManager.MenuClickEffectType.Confirm);
				if (Object.op_Implicit((Object)(object)menuSliderPlayerMicGain.playerAvatar))
				{
					PlatformManager.instance.OpenPlayerProfile(menuSliderPlayerMicGain.playerAvatar);
				}
				else if (menuSliderPlayerMicGain.playerPhoton != null)
				{
					PlatformManager.instance.OpenPlayerProfile(menuSliderPlayerMicGain.playerPhoton.UserId);
				}
			}
			if (hoverLerp < 1f)
			{
				hoverLerp = Mathf.Clamp01(hoverLerp + 3f * Time.deltaTime);
				((Transform)iconTransform).localScale = Vector3.LerpUnclamped(previousScale, Vector3.one * 1.2f, hoverIntroCurve.Evaluate(hoverLerp));
			}
		}
		else if (hoverLerp > 0f)
		{
			if (hovering)
			{
				hovering = false;
				previousScale = ((Transform)iconTransform).localScale;
			}
			hoverLerp = Mathf.Clamp01(hoverLerp - 5f * Time.deltaTime);
			((Transform)iconTransform).localScale = Vector3.LerpUnclamped(Vector3.one, previousScale, hoverOutroCurve.Evaluate(hoverLerp));
		}
	}
}
