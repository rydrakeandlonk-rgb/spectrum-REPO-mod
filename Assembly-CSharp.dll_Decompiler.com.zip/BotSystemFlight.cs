using System;
using System.Collections.Generic;
using UnityEngine;

public class BotSystemFlight : MonoBehaviour
{
	[Header("Flight Configuration")]
	public FlightSettings flightSettings = new FlightSettings();

	[Header("Physics References")]
	public Rigidbody targetRigidbody;

	public BotPhysicsController physicsController;

	public Transform flightTransform;

	private SpringVector3 positionSpring = new SpringVector3();

	private SpringQuaternion rotationSpring = new SpringQuaternion();

	private SpringFloat stabilizationSpring = new SpringFloat();

	private Vector3 currentTarget = Vector3.zero;

	private Vector3 currentLookDirection = Vector3.forward;

	private bool isInitialized;

	private Vector3 spawnPoint;

	private float currentStabilizationForce;

	private float stuckTimer;

	private Vector3 prevStuckPosition;

	private Vector3 currentStuckPosition;

	public EnemyRigidbody enemyRigidbody;

	private void Start()
	{
		Initialize();
	}

	public void Initialize()
	{
		//IL_0074: Unknown result type (might be due to invalid IL or missing references)
		//IL_0079: Unknown result type (might be due to invalid IL or missing references)
		if (!isInitialized)
		{
			if (!Object.op_Implicit((Object)(object)targetRigidbody))
			{
				targetRigidbody = ((Component)this).GetComponent<Rigidbody>();
			}
			if (!Object.op_Implicit((Object)(object)physicsController))
			{
				physicsController = ((Component)this).GetComponent<BotPhysicsController>();
			}
			if (!Object.op_Implicit((Object)(object)flightTransform))
			{
				flightTransform = ((Component)this).transform;
			}
			if (!Object.op_Implicit((Object)(object)enemyRigidbody))
			{
				enemyRigidbody = ((Component)this).GetComponent<EnemyRigidbody>();
			}
			spawnPoint = flightTransform.position;
			SetupSprings();
			InitializeStuckDetection();
			isInitialized = true;
		}
	}

	private void SetupSprings()
	{
		positionSpring.damping = flightSettings.positionDamping;
		positionSpring.speed = flightSettings.positionSpeed;
		rotationSpring.damping = flightSettings.rotationDamping;
		rotationSpring.speed = flightSettings.rotationSpeed;
		stabilizationSpring.damping = 0.8f;
		stabilizationSpring.speed = 10f;
	}

	public void FlyToPosition(Vector3 targetPosition, float customForce = -1f)
	{
		//IL_000f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0010: Unknown result type (might be due to invalid IL or missing references)
		//IL_003f: Unknown result type (might be due to invalid IL or missing references)
		if (!isInitialized)
		{
			Initialize();
		}
		currentTarget = targetPosition;
		float spring = ((customForce > 0f) ? customForce : flightSettings.moveForce);
		if (Object.op_Implicit((Object)(object)physicsController))
		{
			SemiFunc.PhysFollowPoint(targetRigidbody, targetPosition, spring, flightSettings.turnSmoothness);
		}
	}

	public void FlyInDirection(Vector3 direction, float force, float drag = 0.2f)
	{
		//IL_001e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0023: Unknown result type (might be due to invalid IL or missing references)
		//IL_002a: Unknown result type (might be due to invalid IL or missing references)
		if (!isInitialized)
		{
			Initialize();
		}
		if (Object.op_Implicit((Object)(object)physicsController))
		{
			Vector3 normalized = direction.normalized;
			physicsController.PhysMoveTowards(normalized, force, drag);
		}
	}

	public void RotateTowards(Vector3 direction, float turnSpeed = -1f, float verticalTurnSpeed = -1f, float drag = 1f)
	{
		//IL_0040: Unknown result type (might be due to invalid IL or missing references)
		//IL_0045: Unknown result type (might be due to invalid IL or missing references)
		//IL_004c: Unknown result type (might be due to invalid IL or missing references)
		if (!isInitialized)
		{
			Initialize();
		}
		if (Object.op_Implicit((Object)(object)physicsController))
		{
			float spring = ((turnSpeed > 0f) ? turnSpeed : 100f);
			float damping = ((verticalTurnSpeed > 0f) ? verticalTurnSpeed : 10f);
			Vector3 normalized = direction.normalized;
			physicsController.PhysRotateTowards(normalized, spring, damping, drag);
		}
	}

	public void LookAtTarget(Vector3 targetPosition, float smoothness = -1f)
	{
		//IL_000e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0015: Unknown result type (might be due to invalid IL or missing references)
		//IL_001a: Unknown result type (might be due to invalid IL or missing references)
		//IL_001f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0022: Unknown result type (might be due to invalid IL or missing references)
		//IL_0027: Unknown result type (might be due to invalid IL or missing references)
		//IL_0029: Unknown result type (might be due to invalid IL or missing references)
		//IL_002a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0066: Unknown result type (might be due to invalid IL or missing references)
		//IL_0067: Unknown result type (might be due to invalid IL or missing references)
		//IL_0037: Unknown result type (might be due to invalid IL or missing references)
		//IL_0038: Unknown result type (might be due to invalid IL or missing references)
		//IL_003d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0042: Unknown result type (might be due to invalid IL or missing references)
		//IL_004f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0055: Unknown result type (might be due to invalid IL or missing references)
		if (!isInitialized)
		{
			Initialize();
		}
		Vector3 val = targetPosition - flightTransform.position;
		Vector3 val2 = (currentLookDirection = val.normalized);
		if (smoothness > 0f)
		{
			Quaternion targetRotation = Quaternion.LookRotation(val2, Vector3.up);
			flightTransform.rotation = SemiFunc.SpringQuaternionGet(rotationSpring, targetRotation);
		}
		else
		{
			flightTransform.LookAt(targetPosition, Vector3.up);
		}
	}

	public void Stabilize()
	{
		if (!isInitialized)
		{
			Initialize();
		}
		if (Object.op_Implicit((Object)(object)physicsController))
		{
			ApplyGroundAvoidance();
			ApplyOrientationStabilization();
		}
	}

	public void Hover(float intensity = 1f, float speed = 2f)
	{
		//IL_000e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0027: Unknown result type (might be due to invalid IL or missing references)
		//IL_002c: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0033: Unknown result type (might be due to invalid IL or missing references)
		//IL_0043: Unknown result type (might be due to invalid IL or missing references)
		//IL_0048: Unknown result type (might be due to invalid IL or missing references)
		//IL_004d: Unknown result type (might be due to invalid IL or missing references)
		//IL_004e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0053: Unknown result type (might be due to invalid IL or missing references)
		//IL_0055: Unknown result type (might be due to invalid IL or missing references)
		if (!isInitialized)
		{
			Initialize();
		}
		Vector3 val = Vector3.up * (Mathf.Sin(Time.time * speed) * 0.5f * intensity);
		Vector3 targetPosition = spawnPoint + Vector3.up * flightSettings.preferredHeight + val;
		FlyToPosition(targetPosition);
	}

	public void CircleAround(Vector3 centerPoint, float radius, float speed = 1f, float height = -1f)
	{
		//IL_0040: Unknown result type (might be due to invalid IL or missing references)
		//IL_0046: Unknown result type (might be due to invalid IL or missing references)
		//IL_004b: Unknown result type (might be due to invalid IL or missing references)
		//IL_004c: Unknown result type (might be due to invalid IL or missing references)
		//IL_004d: Unknown result type (might be due to invalid IL or missing references)
		//IL_004e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0053: Unknown result type (might be due to invalid IL or missing references)
		//IL_0059: Unknown result type (might be due to invalid IL or missing references)
		//IL_005e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0063: Unknown result type (might be due to invalid IL or missing references)
		//IL_0065: Unknown result type (might be due to invalid IL or missing references)
		//IL_0084: Unknown result type (might be due to invalid IL or missing references)
		//IL_008a: Unknown result type (might be due to invalid IL or missing references)
		if (!isInitialized)
		{
			Initialize();
		}
		float num = ((height > 0f) ? height : flightSettings.preferredHeight);
		float num2 = Time.time * speed;
		Vector3 val = new Vector3(Mathf.Cos(num2), 0f, Mathf.Sin(num2)) * radius;
		Vector3 targetPosition = centerPoint + val + Vector3.up * num;
		FlyToPosition(targetPosition);
		Vector3 direction = new Vector3(0f - Mathf.Sin(num2), 0f, Mathf.Cos(num2));
		RotateTowards(direction);
	}

	public void PatrolBetweenPoints(List<Vector3> patrolPoints, ref int currentPatrolIndex, float arrivalDistance = 3f)
	{
		//IL_002a: Unknown result type (might be due to invalid IL or missing references)
		//IL_002f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0031: Unknown result type (might be due to invalid IL or missing references)
		//IL_0042: Unknown result type (might be due to invalid IL or missing references)
		//IL_0047: Unknown result type (might be due to invalid IL or missing references)
		if (!isInitialized)
		{
			Initialize();
		}
		if (patrolPoints != null && patrolPoints.Count != 0)
		{
			if (currentPatrolIndex >= patrolPoints.Count)
			{
				currentPatrolIndex = 0;
			}
			Vector3 val = patrolPoints[currentPatrolIndex];
			FlyToPosition(val);
			if (Vector3.Distance(flightTransform.position, val) < arrivalDistance)
			{
				currentPatrolIndex = (currentPatrolIndex + 1) % patrolPoints.Count;
			}
		}
	}

	public void ChaseTarget(Vector3 targetPosition, float chaseForce, float predictionAmount = 0f)
	{
		//IL_000e: Unknown result type (might be due to invalid IL or missing references)
		//IL_000f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0040: Unknown result type (might be due to invalid IL or missing references)
		//IL_0048: Unknown result type (might be due to invalid IL or missing references)
		//IL_002b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0030: Unknown result type (might be due to invalid IL or missing references)
		//IL_0031: Unknown result type (might be due to invalid IL or missing references)
		//IL_0032: Unknown result type (might be due to invalid IL or missing references)
		//IL_0034: Unknown result type (might be due to invalid IL or missing references)
		//IL_0039: Unknown result type (might be due to invalid IL or missing references)
		//IL_003e: Unknown result type (might be due to invalid IL or missing references)
		if (!isInitialized)
		{
			Initialize();
		}
		Vector3 val = targetPosition;
		if (predictionAmount > 0f && Object.op_Implicit((Object)(object)targetRigidbody))
		{
			Vector3 linearVelocity = targetRigidbody.linearVelocity;
			val += linearVelocity * predictionAmount;
		}
		FlyToPosition(val, chaseForce);
		LookAtTarget(val);
	}

	public void FleeFrom(Vector3 dangerPosition, float fleeForce, float fleeDistance = 20f)
	{
		//IL_0014: Unknown result type (might be due to invalid IL or missing references)
		//IL_0019: Unknown result type (might be due to invalid IL or missing references)
		//IL_001a: Unknown result type (might be due to invalid IL or missing references)
		//IL_001f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0022: Unknown result type (might be due to invalid IL or missing references)
		//IL_0027: Unknown result type (might be due to invalid IL or missing references)
		//IL_0028: Unknown result type (might be due to invalid IL or missing references)
		//IL_0029: Unknown result type (might be due to invalid IL or missing references)
		//IL_002b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0030: Unknown result type (might be due to invalid IL or missing references)
		//IL_0035: Unknown result type (might be due to invalid IL or missing references)
		//IL_0038: Unknown result type (might be due to invalid IL or missing references)
		//IL_0054: Unknown result type (might be due to invalid IL or missing references)
		if (!isInitialized)
		{
			Initialize();
		}
		Vector3 val = flightTransform.position - dangerPosition;
		Vector3 normalized = val.normalized;
		Vector3 val2 = dangerPosition + normalized * fleeDistance;
		val2.y = Mathf.Max(val2.y, flightSettings.preferredHeight);
		FlyToPosition(val2, fleeForce);
	}

	public void RandomRoam(float roamRadius, ref Vector3 currentRoamTarget, ref bool roamTargetReached, float arrivalDistance = 6f)
	{
		//IL_000f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0014: Unknown result type (might be due to invalid IL or missing references)
		//IL_0035: Unknown result type (might be due to invalid IL or missing references)
		//IL_004a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0050: Unknown result type (might be due to invalid IL or missing references)
		//IL_0026: Unknown result type (might be due to invalid IL or missing references)
		//IL_002b: Unknown result type (might be due to invalid IL or missing references)
		if (!isInitialized)
		{
			Initialize();
		}
		if ((currentRoamTarget == Vector3.zero) | roamTargetReached)
		{
			currentRoamTarget = GenerateRandomRoamTarget(roamRadius);
			roamTargetReached = false;
		}
		FlyToPosition(currentRoamTarget);
		if (Vector3.Distance(flightTransform.position, currentRoamTarget) < arrivalDistance)
		{
			roamTargetReached = true;
		}
	}

	public void PerformLoop(Vector3 centerPoint, float loopRadius, float loopSpeed, ref float loopProgress)
	{
		//IL_005a: Unknown result type (might be due to invalid IL or missing references)
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0060: Unknown result type (might be due to invalid IL or missing references)
		//IL_0061: Unknown result type (might be due to invalid IL or missing references)
		//IL_0066: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_0094: Unknown result type (might be due to invalid IL or missing references)
		//IL_009a: Unknown result type (might be due to invalid IL or missing references)
		if (!isInitialized)
		{
			Initialize();
		}
		loopProgress += Time.deltaTime * loopSpeed;
		if (loopProgress >= MathF.PI * 2f)
		{
			loopProgress = 0f;
		}
		Vector3 val = new Vector3(Mathf.Cos(loopProgress) * loopRadius, Mathf.Sin(loopProgress * 2f) * loopRadius * 0.5f, Mathf.Sin(loopProgress) * loopRadius);
		Vector3 targetPosition = centerPoint + val;
		FlyToPosition(targetPosition);
		Vector3 direction = new Vector3(0f - Mathf.Sin(loopProgress), Mathf.Cos(loopProgress * 2f), Mathf.Cos(loopProgress));
		RotateTowards(direction);
	}

	public Vector3 GenerateRandomRoamTarget(float radius)
	{
		//IL_004f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0055: Unknown result type (might be due to invalid IL or missing references)
		//IL_005a: Unknown result type (might be due to invalid IL or missing references)
		//IL_005d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0062: Unknown result type (might be due to invalid IL or missing references)
		//IL_006b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0072: Unknown result type (might be due to invalid IL or missing references)
		//IL_0077: Unknown result type (might be due to invalid IL or missing references)
		//IL_007c: Unknown result type (might be due to invalid IL or missing references)
		//IL_007f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0097: Unknown result type (might be due to invalid IL or missing references)
		//IL_009c: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ac: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b1: Unknown result type (might be due to invalid IL or missing references)
		//IL_0088: Unknown result type (might be due to invalid IL or missing references)
		int num = 10;
		for (int i = 0; i < num; i++)
		{
			float num2 = Random.Range(0f, MathF.PI * 2f);
			float num3 = Random.Range(5f, radius);
			float num4 = Random.Range(flightSettings.minFlightHeight, flightSettings.maxFlightHeight);
			Vector2 val = new Vector2(Mathf.Cos(num2), Mathf.Sin(num2)) * num3;
			Vector3 val2 = spawnPoint + new Vector3(val.x, num4, val.y);
			if (IsPositionSafe(val2))
			{
				return val2;
			}
		}
		return spawnPoint + Vector3.up * flightSettings.preferredHeight;
	}

	public bool IsPositionSafe(Vector3 position)
	{
		//IL_0000: Unknown result type (might be due to invalid IL or missing references)
		//IL_0007: Unknown result type (might be due to invalid IL or missing references)
		//IL_000c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0011: Unknown result type (might be due to invalid IL or missing references)
		//IL_0015: Unknown result type (might be due to invalid IL or missing references)
		//IL_001a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0021: Unknown result type (might be due to invalid IL or missing references)
		//IL_0026: Unknown result type (might be due to invalid IL or missing references)
		//IL_002d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0032: Unknown result type (might be due to invalid IL or missing references)
		//IL_0039: Unknown result type (might be due to invalid IL or missing references)
		//IL_003e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0040: Unknown result type (might be due to invalid IL or missing references)
		//IL_0063: Unknown result type (might be due to invalid IL or missing references)
		//IL_0064: Unknown result type (might be due to invalid IL or missing references)
		//IL_006e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0073: Unknown result type (might be due to invalid IL or missing references)
		//IL_0078: Unknown result type (might be due to invalid IL or missing references)
		//IL_008c: Unknown result type (might be due to invalid IL or missing references)
		//IL_008f: Unknown result type (might be due to invalid IL or missing references)
		Vector3 val = position - flightTransform.position;
		Vector3 normalized = val.normalized;
		float num = Vector3.Distance(flightTransform.position, position);
		LayerMask val2 = SemiFunc.LayerMaskGetVisionObstruct();
		if (Physics.Raycast(flightTransform.position, normalized, num, LayerMask.op_Implicit(val2)))
		{
			return false;
		}
		int mask = LayerMask.GetMask(new string[1] { "Default" });
		RaycastHit val3 = default;
		if (Physics.Raycast(position + Vector3.up * 10f, Vector3.down, ref val3, 50f, mask))
		{
			float num2 = Vector3.Distance(position, val3.point);
			if (num2 >= 4f)
			{
				return num2 <= 30f;
			}
			return false;
		}
		return false;
	}

	public float GetDistanceToGround()
	{
		//IL_001a: Unknown result type (might be due to invalid IL or missing references)
		//IL_001f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_0029: Unknown result type (might be due to invalid IL or missing references)
		//IL_0043: Unknown result type (might be due to invalid IL or missing references)
		//IL_004a: Unknown result type (might be due to invalid IL or missing references)
		int mask = LayerMask.GetMask(new string[1] { "Default" });
		RaycastHit val = default;
		if (Physics.Raycast(flightTransform.position + Vector3.up, Vector3.down, ref val, 100f, mask))
		{
			return Vector3.Distance(flightTransform.position, val.point);
		}
		return float.MaxValue;
	}

	public void SetSpawnPoint(Vector3 newSpawnPoint)
	{
		//IL_0001: Unknown result type (might be due to invalid IL or missing references)
		//IL_0002: Unknown result type (might be due to invalid IL or missing references)
		spawnPoint = newSpawnPoint;
	}

	public Vector3 GetSpawnPoint()
	{
		//IL_0001: Unknown result type (might be due to invalid IL or missing references)
		return spawnPoint;
	}

	public void SetFlightSettings(FlightSettings newSettings)
	{
		flightSettings = newSettings;
		if (isInitialized)
		{
			SetupSprings();
		}
	}

	public void InitializeStuckDetection()
	{
		//IL_0007: Unknown result type (might be due to invalid IL or missing references)
		//IL_000c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0018: Unknown result type (might be due to invalid IL or missing references)
		//IL_001d: Unknown result type (might be due to invalid IL or missing references)
		prevStuckPosition = flightTransform.position;
		currentStuckPosition = flightTransform.position;
		stuckTimer = 0f;
	}

	public void UpdateStuckDetection()
	{
		//IL_0015: Unknown result type (might be due to invalid IL or missing references)
		//IL_001a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0020: Unknown result type (might be due to invalid IL or missing references)
		//IL_0026: Unknown result type (might be due to invalid IL or missing references)
		//IL_0039: Unknown result type (might be due to invalid IL or missing references)
		//IL_003e: Unknown result type (might be due to invalid IL or missing references)
		if (!isInitialized)
		{
			Initialize();
		}
		currentStuckPosition = flightTransform.position;
		if (Vector3.Distance(prevStuckPosition, currentStuckPosition) > 2f)
		{
			prevStuckPosition = currentStuckPosition;
			stuckTimer = 0f;
		}
		else
		{
			stuckTimer += Time.deltaTime;
		}
	}

	public bool IsStuck(float stuckTimeThreshold = 1.5f)
	{
		return stuckTimer > stuckTimeThreshold;
	}

	public float GetStuckTimer()
	{
		return stuckTimer;
	}

	public void EscapeUpwards(float upwardForce = 800f, float speedMultiplier = 1f)
	{
		//IL_003f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0044: Unknown result type (might be due to invalid IL or missing references)
		//IL_0049: Unknown result type (might be due to invalid IL or missing references)
		//IL_004e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0055: Unknown result type (might be due to invalid IL or missing references)
		//IL_005a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0060: Unknown result type (might be due to invalid IL or missing references)
		//IL_0065: Unknown result type (might be due to invalid IL or missing references)
		//IL_006a: Unknown result type (might be due to invalid IL or missing references)
		//IL_008f: Unknown result type (might be due to invalid IL or missing references)
		//IL_00aa: Unknown result type (might be due to invalid IL or missing references)
		if (!isInitialized)
		{
			Initialize();
		}
		if (Object.op_Implicit((Object)(object)physicsController))
		{
			Vector3 val = Quaternion.Euler(Random.Range(-25f, 25f), Random.Range(0f, 360f), 0f) * Vector3.up;
			Vector3 val2 = flightTransform.position + val * 10f;
			val2.y = spawnPoint.y + flightSettings.maxFlightHeight;
			physicsController.PhysRotateTowards(val, 100f, 10f, 1f);
			physicsController.PhysMoveTowards(val, upwardForce * speedMultiplier, 0.5f);
		}
	}

	private void ApplyGroundAvoidance()
	{
		//IL_002e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0033: Unknown result type (might be due to invalid IL or missing references)
		//IL_0038: Unknown result type (might be due to invalid IL or missing references)
		//IL_003d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0057: Unknown result type (might be due to invalid IL or missing references)
		//IL_005e: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f0: Unknown result type (might be due to invalid IL or missing references)
		if (!Object.op_Implicit((Object)(object)physicsController))
		{
			return;
		}
		float targetFloat = 0f;
		int mask = LayerMask.GetMask(new string[1] { "Default" });
		RaycastHit val = default;
		if (Physics.Raycast(flightTransform.position + Vector3.up, Vector3.down, ref val, 100f, mask))
		{
			float num = Vector3.Distance(flightTransform.position, val.point);
			if (num < flightSettings.groundAvoidanceDistance)
			{
				float num2 = Mathf.Clamp01(num / flightSettings.stabilizationRange);
				float num3 = 1f - Mathf.Clamp01((num - flightSettings.stabilizationRange) / 2f);
				targetFloat = Mathf.Lerp(100f, flightSettings.stabilizationForce, num2) * num3;
			}
		}
		currentStabilizationForce = SemiFunc.SpringFloatGet(stabilizationSpring, targetFloat);
		if (currentStabilizationForce > 0.1f)
		{
			physicsController.PhysMoveTowards(Vector3.up, currentStabilizationForce, 0.8f);
		}
	}

	private void ApplyOrientationStabilization()
	{
		//IL_0014: Unknown result type (might be due to invalid IL or missing references)
		//IL_0019: Unknown result type (might be due to invalid IL or missing references)
		//IL_001e: Unknown result type (might be due to invalid IL or missing references)
		//IL_001f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0032: Unknown result type (might be due to invalid IL or missing references)
		//IL_0037: Unknown result type (might be due to invalid IL or missing references)
		//IL_003c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0041: Unknown result type (might be due to invalid IL or missing references)
		//IL_0048: Unknown result type (might be due to invalid IL or missing references)
		//IL_0049: Unknown result type (might be due to invalid IL or missing references)
		//IL_004e: Unknown result type (might be due to invalid IL or missing references)
		if (Object.op_Implicit((Object)(object)physicsController))
		{
			Vector3 up = flightTransform.up;
			Vector3 up2 = Vector3.up;
			if (Vector3.Dot(up, up2) < 0.7f)
			{
				Quaternion val = Quaternion.LookRotation(flightTransform.forward, Vector3.up);
				physicsController.PhysRotateTowards(val * Vector3.forward, 30f, 15f, 0.8f);
			}
		}
	}

	public BotSystemFlight()
	{
		//IL_002d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0032: Unknown result type (might be due to invalid IL or missing references)
		//IL_0038: Unknown result type (might be due to invalid IL or missing references)
		//IL_003d: Unknown result type (might be due to invalid IL or missing references)
	}
}
