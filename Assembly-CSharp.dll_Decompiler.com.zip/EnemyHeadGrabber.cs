using System;
using Photon.Pun;
using UnityEngine;
using UnityEngine.AI;

public class EnemyHeadGrabber : MonoBehaviour
{
	public enum State
	{
		Spawn,
		Idle,
		IdleBreaker,
		Roam,
		RoamFast,
		Investigate,
		InvestigateFast,
		Notice,
		Attack,
		CantReach,
		GotoPlayer,
		GotoPlayerOver,
		GotoHead,
		GotoHeadOver,
		BackToNavmesh,
		GrabHead,
		ReleaseHead,
		Leave,
		Stun,
		Despawn
	}

	public State currentState;

	public float stateTimer;

	private bool stateImpulse;

	internal State previousState;

	internal Enemy enemy;

	internal PhotonView photonView;

	public EnemyHeadGrabberAnim anim;

	public SphereCollider topCollider;

	private bool topColliderActive;

	public SpringQuaternion horizontalRotationSpring;

	private Quaternion horizontalRotationTarget = Quaternion.identity;

	internal PlayerAvatar playerTarget;

	internal PlayerDeathHead headTarget;

	internal bool headTargetActive;

	internal bool headTargetRelease;

	internal float headTargetTime;

	private bool headTargetActivePrevious;

	internal bool headTargetActiveLocal;

	private float headTargetCooldown;

	private bool nearbyHeadLogic;

	[Space]
	public Transform headTargetPositionTransform;

	public Transform headTargetPositionFollowTransform;

	public Transform headTargetPositionReleaseTransform;

	public AnimationCurve headTargetPositionCurve;

	[Space]
	public GameObject localCameraPrefab;

	private float headTargetPositionLerp;

	private Vector3 headTargetOriginalPosition;

	private Quaternion headTargetOriginalRotation;

	private Vector3 agentDestination;

	private Vector3 backToNavmeshPosition;

	private bool visionPrevious;

	private float visionPreviousTime;

	private int idleBreakerIndex;

	private int idleBreakerIndexPrevious;

	private int attackIndex;

	private int attackIndexPrevious;

	private float attackCooldown;

	private int attacksInRow;

	internal float rotationStopTimer;

	private float dropkickHitTimeLast;

	private bool localMeshHidden;

	private EnemyHeadGrabberLocalCamera localCameraObject;

	private void Awake()
	{
		enemy = ((Component)this).GetComponent<Enemy>();
		photonView = ((Component)this).GetComponent<PhotonView>();
	}

	private void Update()
	{
		DeathHeadLogicShared();
		LocalMeshLogicShared();
		if ((!GameManager.Multiplayer() || PhotonNetwork.IsMasterClient) && LevelGenerator.Instance.Generated)
		{
			if (enemy.IsStunned())
			{
				UpdateState(State.Stun);
			}
			else if (enemy.CurrentState == EnemyState.Despawn)
			{
				UpdateState(State.Despawn);
			}
			switch (currentState)
			{
			case State.Spawn:
				StateSpawn();
				break;
			case State.Idle:
				StateIdle();
				break;
			case State.IdleBreaker:
				StateIdleBreaker();
				break;
			case State.Roam:
				StateRoam();
				break;
			case State.RoamFast:
				StateRoamFast();
				break;
			case State.Investigate:
				StateInvestigate();
				break;
			case State.InvestigateFast:
				StateInvestigateFast();
				break;
			case State.Notice:
				StateNotice();
				break;
			case State.CantReach:
				StateCantReach();
				break;
			case State.GotoPlayer:
				StateGotoPlayer();
				break;
			case State.GotoPlayerOver:
				StateGotoPlayerOver();
				break;
			case State.GotoHead:
				StateGotoHead();
				break;
			case State.GotoHeadOver:
				StateGotoHeadOver();
				break;
			case State.BackToNavmesh:
				StateBackToNavmesh();
				break;
			case State.GrabHead:
				StateGrabHead();
				break;
			case State.ReleaseHead:
				StateReleaseHead();
				break;
			case State.Attack:
				StateAttack();
				break;
			case State.Leave:
				StateLeave();
				break;
			case State.Stun:
				StateStun();
				break;
			case State.Despawn:
				StateDespawn();
				break;
			}
			RotationLogic();
			BackToNavmeshPosition();
			DeathHeadLogic();
			TimerLogic();
		}
	}

	private void StateSpawn()
	{
		if (stateImpulse)
		{
			ResetAgent();
			stateImpulse = false;
			stateTimer = 2f;
		}
		stateTimer -= Time.deltaTime;
		if (stateTimer <= 0f)
		{
			UpdateState(State.Idle);
		}
	}

	private void StateIdle()
	{
		//IL_00eb: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f1: Unknown result type (might be due to invalid IL or missing references)
		if (stateImpulse)
		{
			ResetAgent();
			stateImpulse = false;
			stateTimer = Random.Range(2f, 8f);
		}
		if (SemiFunc.EnemySpawnIdlePause() || NearbyHeadLogic())
		{
			return;
		}
		stateTimer -= Time.deltaTime;
		if (stateTimer <= 0f)
		{
			if (headTargetTime >= 60f)
			{
				UpdateState(State.ReleaseHead);
			}
			else if (Random.Range(0, 3) == 0)
			{
				for (idleBreakerIndex = idleBreakerIndexPrevious; idleBreakerIndex == idleBreakerIndexPrevious; idleBreakerIndex = Random.Range(0, 3))
				{
				}
				idleBreakerIndexPrevious = idleBreakerIndex;
				if (GameManager.Multiplayer())
				{
					photonView.RPC("IdleBreakerSetRPC", (RpcTarget)0, new object[1] { idleBreakerIndex });
				}
				else
				{
					IdleBreakerSetRPC(idleBreakerIndex);
				}
				UpdateState(State.IdleBreaker);
			}
			else if (Random.Range(0, 5) == 0)
			{
				UpdateState(State.RoamFast);
			}
			else
			{
				UpdateState(State.Roam);
			}
		}
		else if (SemiFunc.EnemyForceLeave(enemy))
		{
			UpdateState(State.Leave);
		}
	}

	private void StateIdleBreaker()
	{
		if (stateImpulse)
		{
			stateImpulse = false;
			stateTimer = 1.5f;
			ResetAgent();
			RigidbodyReset();
			stateImpulse = false;
		}
		stateTimer -= Time.deltaTime;
		if (stateTimer <= 0f)
		{
			UpdateState(State.Idle);
		}
	}

	private void StateRoam()
	{
		//IL_0040: Unknown result type (might be due to invalid IL or missing references)
		if (stateImpulse)
		{
			stateTimer = 5f;
			if (!SemiFunc.EnemyRoamPoint(enemy, out agentDestination))
			{
				return;
			}
			RigidbodyReset();
			stateImpulse = false;
		}
		enemy.NavMeshAgent.SetDestination(agentDestination);
		if (!NearbyHeadLogic())
		{
			RigidbodyNotMovingTickTimer();
			if (!GoToIdleOnDestinationReached() && SemiFunc.EnemyForceLeave(enemy))
			{
				UpdateState(State.Leave);
			}
		}
	}

	private void StateRoamFast()
	{
		//IL_0047: Unknown result type (might be due to invalid IL or missing references)
		if (stateImpulse)
		{
			stateImpulse = false;
			stateTimer = 5f;
			if (!SemiFunc.EnemyRoamPoint(enemy, out agentDestination))
			{
				return;
			}
			RigidbodyReset();
			stateImpulse = false;
		}
		enemy.NavMeshAgent.SetDestination(agentDestination);
		AgentMoveFast();
		RigidbodyNotMovingTickTimer();
		if (!NearbyHeadLogic() && !GoToIdleOnDestinationReached() && SemiFunc.EnemyForceLeave(enemy))
		{
			UpdateState(State.Leave);
		}
	}

	private void StateInvestigate()
	{
		//IL_002e: Unknown result type (might be due to invalid IL or missing references)
		if (stateImpulse)
		{
			stateImpulse = false;
			stateTimer = 5f;
			RigidbodyReset();
		}
		else
		{
			enemy.NavMeshAgent.SetDestination(agentDestination);
			RigidbodyNotMovingTickTimer();
			if (GoToIdleOnDestinationReached())
			{
				return;
			}
		}
		if (!NearbyHeadLogic() && SemiFunc.EnemyForceLeave(enemy))
		{
			UpdateState(State.Leave);
		}
	}

	private void StateInvestigateFast()
	{
		//IL_002e: Unknown result type (might be due to invalid IL or missing references)
		if (stateImpulse)
		{
			stateImpulse = false;
			stateTimer = 5f;
			RigidbodyReset();
		}
		else
		{
			enemy.NavMeshAgent.SetDestination(agentDestination);
			AgentMoveFast();
			RigidbodyNotMovingTickTimer();
			if (GoToIdleOnDestinationReached())
			{
				return;
			}
		}
		if (!NearbyHeadLogic() && SemiFunc.EnemyForceLeave(enemy))
		{
			UpdateState(State.Leave);
		}
	}

	private void StateNotice()
	{
		if (stateImpulse)
		{
			stateImpulse = false;
			stateTimer = 2f;
			attacksInRow = 0;
			ResetAgent();
			RigidbodyReset();
			stateImpulse = false;
		}
		stateTimer -= Time.deltaTime;
		if (stateTimer <= 0f)
		{
			PlayerDeathHead closestDeathHead = GetClosestDeathHead(30f);
			if (Object.op_Implicit((Object)(object)closestDeathHead))
			{
				UpdateHeadTarget(closestDeathHead);
				UpdateState(State.GotoHead);
			}
			else
			{
				UpdateState(State.GotoPlayer);
			}
		}
	}

	private void StateCantReach()
	{
		if (stateImpulse)
		{
			stateImpulse = false;
			stateTimer = 2.5f;
			ResetAgent();
			RigidbodyReset();
			stateImpulse = false;
		}
		stateTimer -= Time.deltaTime;
		if (stateTimer <= 0f)
		{
			if (previousState == State.GotoHead)
			{
				UpdateState(State.GotoPlayer);
			}
			else
			{
				UpdateState(State.Leave);
			}
		}
	}

	private void StateGotoPlayer()
	{
		GotoLogic();
	}

	private void StateGotoPlayerOver()
	{
		GotoOverLogic();
	}

	private void StateGotoHead()
	{
		GotoLogic();
	}

	private void StateGotoHeadOver()
	{
		GotoOverLogic();
	}

	private void StateBackToNavmesh()
	{
		//IL_0036: Unknown result type (might be due to invalid IL or missing references)
		//IL_0073: Unknown result type (might be due to invalid IL or missing references)
		//IL_0079: Unknown result type (might be due to invalid IL or missing references)
		//IL_0089: Unknown result type (might be due to invalid IL or missing references)
		//IL_018f: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b9: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ce: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ff: Unknown result type (might be due to invalid IL or missing references)
		//IL_0105: Unknown result type (might be due to invalid IL or missing references)
		//IL_010a: Unknown result type (might be due to invalid IL or missing references)
		//IL_010f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0112: Unknown result type (might be due to invalid IL or missing references)
		//IL_0117: Unknown result type (might be due to invalid IL or missing references)
		//IL_0129: Unknown result type (might be due to invalid IL or missing references)
		//IL_012f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0134: Unknown result type (might be due to invalid IL or missing references)
		//IL_0154: Unknown result type (might be due to invalid IL or missing references)
		//IL_0165: Unknown result type (might be due to invalid IL or missing references)
		//IL_016a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0170: Unknown result type (might be due to invalid IL or missing references)
		//IL_0175: Unknown result type (might be due to invalid IL or missing references)
		//IL_01e2: Unknown result type (might be due to invalid IL or missing references)
		//IL_01ea: Unknown result type (might be due to invalid IL or missing references)
		//IL_01f0: Unknown result type (might be due to invalid IL or missing references)
		if (stateImpulse)
		{
			stateImpulse = false;
			stateTimer = 15f;
			RigidbodyReset();
			((Component)this).transform.position = ((Component)enemy.Rigidbody).transform.position;
		}
		enemy.NavMeshAgent.Disable(0.1f);
		if (!enemy.Jump.jumping)
		{
			((Component)this).transform.position = Vector3.MoveTowards(((Component)this).transform.position, backToNavmeshPosition, 6f * Time.deltaTime);
		}
		SemiFunc.EnemyCartJump(enemy);
		if (!enemy.Jump.jumping && (Vector3.Distance(((Component)this).transform.position, ((Component)enemy.Rigidbody).transform.position) > 2f || enemy.Rigidbody.notMovingTimer > 2f))
		{
			Vector3 val = ((Component)this).transform.position - backToNavmeshPosition;
			Vector3 normalized = val.normalized;
			enemy.Jump.StuckTrigger(((Component)this).transform.position - backToNavmeshPosition);
			((Component)this).transform.position = ((Component)enemy.Rigidbody).transform.position;
			Transform transform = ((Component)this).transform;
			transform.position += normalized * 2f;
		}
		NavMeshHit val2 = default;
		if (NavMesh.SamplePosition(((Component)enemy.Rigidbody).transform.position, ref val2, 0.5f, -1))
		{
			if (!headTargetActive && attacksInRow > 3)
			{
				UpdateState(State.Leave);
				return;
			}
			if (previousState == State.Stun)
			{
				UpdateState(State.Idle);
				return;
			}
			if (nearbyHeadLogic)
			{
				PlayerAvatar playerAvatar = SemiFunc.PlayerGetNearestPlayerAvatarWithinRange(999f, ((Component)this).transform.position);
				if (Object.op_Implicit((Object)(object)playerAvatar))
				{
					UpdatePlayerTarget(playerAvatar);
				}
			}
			UpdateState(State.GotoPlayer);
		}
		else
		{
			RigidbodyNotMovingTickTimer();
			if (stateTimer <= 0f)
			{
				enemy.EnemyParent.SpawnedTimerSet(0f);
			}
		}
	}

	private void StateGrabHead()
	{
		//IL_00f5: Unknown result type (might be due to invalid IL or missing references)
		//IL_0042: Unknown result type (might be due to invalid IL or missing references)
		//IL_0057: Unknown result type (might be due to invalid IL or missing references)
		//IL_005c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0061: Unknown result type (might be due to invalid IL or missing references)
		//IL_0064: Unknown result type (might be due to invalid IL or missing references)
		//IL_0069: Unknown result type (might be due to invalid IL or missing references)
		//IL_0086: Unknown result type (might be due to invalid IL or missing references)
		//IL_008c: Unknown result type (might be due to invalid IL or missing references)
		if (stateImpulse)
		{
			stateImpulse = false;
			stateTimer = 1.5f;
			attacksInRow = 0;
			ResetAgent();
			RigidbodyReset();
			stateImpulse = false;
			Vector3 val = headTarget.physGrabObject.centerPoint - ((Component)enemy.Rigidbody).transform.position;
			Vector3 normalized = val.normalized;
			normalized.y = 0f;
			enemy.Rigidbody.rb.AddForce(normalized * 15f, (ForceMode)1);
			enemy.Rigidbody.DisableFollowPosition(1.5f, 5f);
			headTargetActive = true;
		}
		stateTimer -= Time.deltaTime;
		enemy.NavMeshAgent.Disable(0.1f);
		((Component)this).transform.position = ((Component)enemy.Rigidbody).transform.position;
		if (stateTimer <= 0f)
		{
			UpdateState(State.BackToNavmesh);
		}
	}

	private void StateReleaseHead()
	{
		//IL_006a: Unknown result type (might be due to invalid IL or missing references)
		if (stateImpulse)
		{
			stateImpulse = false;
			stateTimer = 2f;
			ResetAgent();
			RigidbodyReset();
			stateImpulse = false;
		}
		stateTimer -= Time.deltaTime;
		enemy.NavMeshAgent.Disable(0.1f);
		((Component)this).transform.position = ((Component)enemy.Rigidbody).transform.position;
		if (stateTimer <= 0f)
		{
			UpdateState(State.Idle);
		}
	}

	private void StateAttack()
	{
		//IL_008e: Unknown result type (might be due to invalid IL or missing references)
		if (stateImpulse)
		{
			stateImpulse = false;
			attacksInRow++;
			if (attackIndex == 2)
			{
				stateTimer = 2f;
			}
			else
			{
				stateTimer = 0.5f;
			}
			ResetAgent();
			RigidbodyReset();
			stateImpulse = false;
		}
		stateTimer -= Time.deltaTime;
		enemy.NavMeshAgent.Disable(0.1f);
		((Component)this).transform.position = ((Component)enemy.Rigidbody).transform.position;
		if (stateTimer <= 0f)
		{
			if (!headTargetActive && attacksInRow > 3)
			{
				UpdateState(State.BackToNavmesh);
			}
			else
			{
				UpdateState(previousState);
			}
		}
	}

	private void StateLeave()
	{
		//IL_0057: Unknown result type (might be due to invalid IL or missing references)
		if (stateImpulse)
		{
			stateTimer = 5f;
			if (!SemiFunc.EnemyLeavePoint(enemy, out agentDestination))
			{
				return;
			}
			SemiFunc.EnemyLeaveStart(enemy);
			RigidbodyReset();
			stateImpulse = false;
		}
		RigidbodyNotMovingTickTimer();
		AgentMoveFast();
		enemy.NavMeshAgent.SetDestination(agentDestination);
		GoToIdleOnDestinationReached();
	}

	private void StateStun()
	{
		if (stateImpulse)
		{
			stateImpulse = false;
			ResetAgent();
		}
		enemy.Vision.DisableVision(1f);
		if (!enemy.IsStunned())
		{
			UpdateState(State.BackToNavmesh);
		}
	}

	private void StateDespawn()
	{
		if (stateImpulse)
		{
			ResetAgent();
			stateImpulse = false;
		}
	}

	private void UpdateState(State _state)
	{
		//IL_006c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0072: Unknown result type (might be due to invalid IL or missing references)
		if (SemiFunc.IsMasterClientOrSingleplayer() && _state != currentState)
		{
			previousState = currentState;
			currentState = _state;
			stateImpulse = true;
			stateTimer = 0f;
			if (GameManager.Multiplayer())
			{
				photonView.RPC("UpdateStateRPC", (RpcTarget)0, new object[1] { currentState });
			}
			else
			{
				UpdateStateRPC(currentState);
			}
		}
	}

	private void RotationLogic()
	{
		//IL_04c2: Unknown result type (might be due to invalid IL or missing references)
		//IL_04cc: Unknown result type (might be due to invalid IL or missing references)
		//IL_0039: Unknown result type (might be due to invalid IL or missing references)
		//IL_003e: Unknown result type (might be due to invalid IL or missing references)
		//IL_003f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0046: Unknown result type (might be due to invalid IL or missing references)
		//IL_0050: Unknown result type (might be due to invalid IL or missing references)
		//IL_0055: Unknown result type (might be due to invalid IL or missing references)
		//IL_005a: Unknown result type (might be due to invalid IL or missing references)
		//IL_005c: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0072: Unknown result type (might be due to invalid IL or missing references)
		//IL_0077: Unknown result type (might be due to invalid IL or missing references)
		//IL_007c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0092: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a1: Unknown result type (might be due to invalid IL or missing references)
		//IL_01ca: Unknown result type (might be due to invalid IL or missing references)
		//IL_01df: Unknown result type (might be due to invalid IL or missing references)
		//IL_0104: Unknown result type (might be due to invalid IL or missing references)
		//IL_0119: Unknown result type (might be due to invalid IL or missing references)
		//IL_03eb: Unknown result type (might be due to invalid IL or missing references)
		//IL_03f0: Unknown result type (might be due to invalid IL or missing references)
		//IL_03f5: Unknown result type (might be due to invalid IL or missing references)
		//IL_040b: Unknown result type (might be due to invalid IL or missing references)
		//IL_041a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0336: Unknown result type (might be due to invalid IL or missing references)
		//IL_034b: Unknown result type (might be due to invalid IL or missing references)
		//IL_028e: Unknown result type (might be due to invalid IL or missing references)
		//IL_02a3: Unknown result type (might be due to invalid IL or missing references)
		//IL_01ff: Unknown result type (might be due to invalid IL or missing references)
		//IL_0214: Unknown result type (might be due to invalid IL or missing references)
		//IL_0219: Unknown result type (might be due to invalid IL or missing references)
		//IL_021e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0223: Unknown result type (might be due to invalid IL or missing references)
		//IL_0239: Unknown result type (might be due to invalid IL or missing references)
		//IL_0248: Unknown result type (might be due to invalid IL or missing references)
		//IL_0139: Unknown result type (might be due to invalid IL or missing references)
		//IL_014e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0153: Unknown result type (might be due to invalid IL or missing references)
		//IL_0158: Unknown result type (might be due to invalid IL or missing references)
		//IL_015d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0173: Unknown result type (might be due to invalid IL or missing references)
		//IL_0182: Unknown result type (might be due to invalid IL or missing references)
		//IL_0368: Unknown result type (might be due to invalid IL or missing references)
		//IL_037d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0382: Unknown result type (might be due to invalid IL or missing references)
		//IL_0387: Unknown result type (might be due to invalid IL or missing references)
		//IL_038c: Unknown result type (might be due to invalid IL or missing references)
		//IL_03a2: Unknown result type (might be due to invalid IL or missing references)
		//IL_03b1: Unknown result type (might be due to invalid IL or missing references)
		//IL_02c3: Unknown result type (might be due to invalid IL or missing references)
		//IL_02d8: Unknown result type (might be due to invalid IL or missing references)
		//IL_02dd: Unknown result type (might be due to invalid IL or missing references)
		//IL_02e2: Unknown result type (might be due to invalid IL or missing references)
		//IL_02e7: Unknown result type (might be due to invalid IL or missing references)
		//IL_02fd: Unknown result type (might be due to invalid IL or missing references)
		//IL_030c: Unknown result type (might be due to invalid IL or missing references)
		bool flag = true;
		if (rotationStopTimer <= 0f)
		{
			if (Object.op_Implicit((Object)(object)playerTarget) && currentState == State.Attack)
			{
				Vector3 position = ((Component)playerTarget).transform.position;
				position += playerTarget.rbVelocityRaw * 0.5f;
				horizontalRotationTarget = Quaternion.LookRotation(position - ((Component)enemy.Rigidbody).transform.position);
				horizontalRotationTarget.eulerAngles = new Vector3(0f, horizontalRotationTarget.eulerAngles.y, 0f);
			}
			else if (Object.op_Implicit((Object)(object)playerTarget) && (currentState == State.GotoPlayer || currentState == State.GotoPlayerOver))
			{
				if (!enemy.Jump.jumping && !VisionBlocked())
				{
					flag = false;
					if (Vector3.Distance(((Component)playerTarget).transform.position, ((Component)enemy.Rigidbody).transform.position) > 0.1f)
					{
						horizontalRotationTarget = Quaternion.LookRotation(((Component)playerTarget).transform.position - ((Component)enemy.Rigidbody).transform.position);
						horizontalRotationTarget.eulerAngles = new Vector3(0f, horizontalRotationTarget.eulerAngles.y, 0f);
					}
				}
			}
			else if (Object.op_Implicit((Object)(object)playerTarget) && currentState == State.Notice)
			{
				flag = false;
				if (stateTimer >= 1f && Vector3.Distance(((Component)playerTarget).transform.position, ((Component)enemy.Rigidbody).transform.position) > 0.1f)
				{
					horizontalRotationTarget = Quaternion.LookRotation(((Component)playerTarget).transform.position - ((Component)enemy.Rigidbody).transform.position);
					horizontalRotationTarget.eulerAngles = new Vector3(0f, horizontalRotationTarget.eulerAngles.y, 0f);
				}
			}
			else if (currentState == State.CantReach)
			{
				flag = false;
				if (previousState == State.GotoHead)
				{
					if (Object.op_Implicit((Object)(object)headTarget) && Vector3.Distance(((Component)headTarget).transform.position, ((Component)enemy.Rigidbody).transform.position) > 0.1f)
					{
						horizontalRotationTarget = Quaternion.LookRotation(((Component)headTarget).transform.position - ((Component)enemy.Rigidbody).transform.position);
						horizontalRotationTarget.eulerAngles = new Vector3(0f, horizontalRotationTarget.eulerAngles.y, 0f);
					}
				}
				else if (Object.op_Implicit((Object)(object)playerTarget) && Vector3.Distance(((Component)playerTarget).transform.position, ((Component)enemy.Rigidbody).transform.position) > 0.1f)
				{
					horizontalRotationTarget = Quaternion.LookRotation(((Component)playerTarget).transform.position - ((Component)enemy.Rigidbody).transform.position);
					horizontalRotationTarget.eulerAngles = new Vector3(0f, horizontalRotationTarget.eulerAngles.y, 0f);
				}
			}
			if (flag && enemy.Rigidbody.velocity.magnitude > 0.5f)
			{
				horizontalRotationTarget = Quaternion.LookRotation(enemy.Rigidbody.velocity.normalized);
				horizontalRotationTarget.eulerAngles = new Vector3(0f, horizontalRotationTarget.eulerAngles.y, 0f);
			}
			if (currentState == State.Attack)
			{
				horizontalRotationSpring.speed = 20f;
				horizontalRotationSpring.damping = 0.8f;
			}
			else if (currentState == State.Idle || currentState == State.IdleBreaker || currentState == State.Roam || currentState == State.Investigate)
			{
				horizontalRotationSpring.speed = 5f;
				horizontalRotationSpring.damping = 0.7f;
			}
			else
			{
				horizontalRotationSpring.speed = 10f;
				horizontalRotationSpring.damping = 0.7f;
			}
		}
		((Component)this).transform.rotation = SemiFunc.SpringQuaternionGet(horizontalRotationSpring, horizontalRotationTarget);
	}

	private void ResetAgent()
	{
		//IL_001b: Unknown result type (might be due to invalid IL or missing references)
		enemy.NavMeshAgent.Warp(((Component)enemy.Rigidbody).transform.position);
		enemy.NavMeshAgent.ResetPath();
	}

	private void AgentMoveFast()
	{
		enemy.NavMeshAgent.OverrideAgent(6f, 15f, 0.1f);
		enemy.Rigidbody.OverrideFollowPosition(0.1f, 10f, 30f);
	}

	private void RigidbodyReset()
	{
		enemy.Rigidbody.StuckReset();
		enemy.Jump.StuckReset();
		SemiFunc.EnemyCartJumpReset(enemy);
	}

	private void RigidbodyNotMovingTickTimer()
	{
		if (enemy.Rigidbody.notMovingTimer > 2f)
		{
			stateTimer -= Time.deltaTime;
		}
	}

	private bool GoToIdleOnDestinationReached()
	{
		//IL_002f: Unknown result type (might be due to invalid IL or missing references)
		//IL_003f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0060: Unknown result type (might be due to invalid IL or missing references)
		//IL_0066: Unknown result type (might be due to invalid IL or missing references)
		if (!enemy.Jump.jumping && (stateTimer <= 0f || Vector3.Distance(((Component)enemy.Rigidbody).transform.position, enemy.NavMeshAgent.GetPoint()) <= 1f || Vector3.Distance(((Component)enemy.Rigidbody).transform.position, agentDestination) <= 1f))
		{
			UpdateState(State.Idle);
			return true;
		}
		return false;
	}

	private bool VisionBlocked()
	{
		//IL_0036: Unknown result type (might be due to invalid IL or missing references)
		//IL_003b: Unknown result type (might be due to invalid IL or missing references)
		//IL_005b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0060: Unknown result type (might be due to invalid IL or missing references)
		//IL_006c: Unknown result type (might be due to invalid IL or missing references)
		//IL_007d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0082: Unknown result type (might be due to invalid IL or missing references)
		//IL_0087: Unknown result type (might be due to invalid IL or missing references)
		//IL_0099: Unknown result type (might be due to invalid IL or missing references)
		//IL_009e: Unknown result type (might be due to invalid IL or missing references)
		if (Time.time - visionPreviousTime > 0.2f && Object.op_Implicit((Object)(object)playerTarget))
		{
			Vector3 val = playerTarget.PlayerVisionTarget.VisionTransform.position;
			if (currentState == State.GotoHead || currentState == State.GotoHeadOver)
			{
				val = headTarget.physGrabObject.centerPoint;
			}
			visionPreviousTime = Time.time;
			Vector3 val2 = val - enemy.Vision.VisionTransform.position;
			visionPrevious = Physics.Raycast(enemy.Vision.VisionTransform.position, val2, val2.magnitude, LayerMask.GetMask(new string[1] { "Default" }), (QueryTriggerInteraction)1);
		}
		return visionPrevious;
	}

	private void BackToNavmeshPosition()
	{
		//IL_0028: Unknown result type (might be due to invalid IL or missing references)
		//IL_004b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0050: Unknown result type (might be due to invalid IL or missing references)
		if (SemiFunc.PerSecond(15f, (Object)(object)this) && enemy.NavMeshAgent.OnNavmesh(((Component)enemy.Rigidbody).transform.position, 0.5f, _checkPit: true))
		{
			backToNavmeshPosition = ((Component)enemy.Rigidbody).transform.position;
		}
	}

	private void UpdatePlayerTarget(PlayerAvatar _player)
	{
		playerTarget = _player;
		int num = -1;
		if (Object.op_Implicit((Object)(object)playerTarget))
		{
			num = playerTarget.photonView.ViewID;
		}
		if (GameManager.Multiplayer())
		{
			photonView.RPC("UpdatePlayerTargetRPC", (RpcTarget)1, new object[1] { num });
		}
	}

	private void UpdateHeadTarget(PlayerDeathHead _head)
	{
		if (!headTargetActive)
		{
			headTarget = _head;
			headTargetCooldown = 120f;
			if (GameManager.Multiplayer())
			{
				photonView.RPC("UpdateHeadTargetRPC", (RpcTarget)1, new object[1] { headTarget.photonView.ViewID });
			}
		}
	}

	private void GotoLogic()
	{
		//IL_0000: Unknown result type (might be due to invalid IL or missing references)
		//IL_0005: Unknown result type (might be due to invalid IL or missing references)
		//IL_002a: Unknown result type (might be due to invalid IL or missing references)
		//IL_002f: Unknown result type (might be due to invalid IL or missing references)
		//IL_007f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0084: Unknown result type (might be due to invalid IL or missing references)
		//IL_0134: Unknown result type (might be due to invalid IL or missing references)
		//IL_015a: Unknown result type (might be due to invalid IL or missing references)
		//IL_015f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0180: Unknown result type (might be due to invalid IL or missing references)
		//IL_01e1: Unknown result type (might be due to invalid IL or missing references)
		//IL_01ae: Unknown result type (might be due to invalid IL or missing references)
		//IL_01b3: Unknown result type (might be due to invalid IL or missing references)
		//IL_01fe: Unknown result type (might be due to invalid IL or missing references)
		//IL_020e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0260: Unknown result type (might be due to invalid IL or missing references)
		//IL_0287: Unknown result type (might be due to invalid IL or missing references)
		//IL_029d: Unknown result type (might be due to invalid IL or missing references)
		Vector3 val = Vector3.zero;
		bool flag = false;
		if (currentState == State.GotoHead)
		{
			if (Object.op_Implicit((Object)(object)headTarget))
			{
				val = ((Component)headTarget).transform.position;
			}
			flag = Object.op_Implicit((Object)(object)headTarget);
			if (Object.op_Implicit((Object)(object)headTarget) && headTarget.overrideSpectated)
			{
				flag = false;
			}
		}
		else if (Object.op_Implicit((Object)(object)playerTarget) && !playerTarget.isDisabled)
		{
			val = ((Component)playerTarget).transform.position;
			flag = true;
		}
		else if (!headTargetActive && Object.op_Implicit((Object)(object)playerTarget) && playerTarget.isDisabled)
		{
			UpdateHeadTarget(playerTarget.playerDeathHead);
			UpdateState(State.GotoHead);
			return;
		}
		if (stateImpulse)
		{
			stateImpulse = false;
			stateTimer = 5f;
			RigidbodyReset();
		}
		if (currentState == State.GotoHead)
		{
			RigidbodyNotMovingTickTimer();
		}
		else if (!nearbyHeadLogic)
		{
			stateTimer -= Time.deltaTime;
		}
		if (!flag || stateTimer <= 0f)
		{
			UpdateState(State.Idle);
			return;
		}
		enemy.NavMeshAgent.SetDestination(val);
		AgentMoveFast();
		if (currentState == State.GotoHead && Vector3.Distance(((Component)enemy.Rigidbody).transform.position, val) < 1.5f)
		{
			UpdateState(State.GrabHead);
		}
		else
		{
			if (currentState == State.GotoPlayer && AttackSet(val))
			{
				return;
			}
			SemiFunc.EnemyCartJump(enemy);
			if (currentState == State.GotoPlayer && Vector3.Distance(((Component)enemy.Rigidbody).transform.position, val) < 1f)
			{
				enemy.NavMeshAgent.Stop(0.1f);
			}
			else
			{
				NavMeshHit val2 = default;
				if (((enemy.NavMeshAgent.CanReach(val, 1f) || !(Vector3.Distance(((Component)enemy.Rigidbody).transform.position, enemy.NavMeshAgent.GetPoint()) < 2f)) && !(enemy.Rigidbody.notMovingTimer > 2f)) || enemy.Jump.jumping || (currentState != State.GotoHead && VisionBlocked()) || NavMesh.SamplePosition(val, ref val2, 1f, -1) || (currentState != State.GotoHead && !playerTarget.isGrounded))
				{
					return;
				}
				if (val.y > ((Component)enemy.Rigidbody).transform.position.y + 0.5f)
				{
					if (currentState == State.GotoHead)
					{
						UpdateState(State.GotoHeadOver);
					}
					else
					{
						UpdateState(State.GotoPlayerOver);
					}
				}
				else
				{
					UpdateState(State.CantReach);
				}
			}
		}
	}

	private void GotoOverLogic()
	{
		//IL_0006: Unknown result type (might be due to invalid IL or missing references)
		//IL_000b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0030: Unknown result type (might be due to invalid IL or missing references)
		//IL_0035: Unknown result type (might be due to invalid IL or missing references)
		//IL_0085: Unknown result type (might be due to invalid IL or missing references)
		//IL_008a: Unknown result type (might be due to invalid IL or missing references)
		//IL_011c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0121: Unknown result type (might be due to invalid IL or missing references)
		//IL_0188: Unknown result type (might be due to invalid IL or missing references)
		//IL_0159: Unknown result type (might be due to invalid IL or missing references)
		//IL_015e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0166: Unknown result type (might be due to invalid IL or missing references)
		//IL_01de: Unknown result type (might be due to invalid IL or missing references)
		//IL_01f4: Unknown result type (might be due to invalid IL or missing references)
		//IL_01ca: Unknown result type (might be due to invalid IL or missing references)
		//IL_0337: Unknown result type (might be due to invalid IL or missing references)
		//IL_025d: Unknown result type (might be due to invalid IL or missing references)
		//IL_026e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0273: Unknown result type (might be due to invalid IL or missing references)
		//IL_0278: Unknown result type (might be due to invalid IL or missing references)
		//IL_027c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0281: Unknown result type (might be due to invalid IL or missing references)
		//IL_028d: Unknown result type (might be due to invalid IL or missing references)
		//IL_02be: Unknown result type (might be due to invalid IL or missing references)
		//IL_02d4: Unknown result type (might be due to invalid IL or missing references)
		//IL_02d9: Unknown result type (might be due to invalid IL or missing references)
		//IL_02df: Unknown result type (might be due to invalid IL or missing references)
		Vector3 position = ((Component)this).transform.position;
		bool flag = false;
		if (currentState == State.GotoHeadOver)
		{
			if (Object.op_Implicit((Object)(object)headTarget))
			{
				position = ((Component)headTarget).transform.position;
			}
			flag = Object.op_Implicit((Object)(object)headTarget);
			if (Object.op_Implicit((Object)(object)headTarget) && headTarget.overrideSpectated)
			{
				flag = false;
			}
		}
		else if (Object.op_Implicit((Object)(object)playerTarget) && !playerTarget.isDisabled)
		{
			position = ((Component)playerTarget).transform.position;
			flag = true;
		}
		else if (!headTargetActive && Object.op_Implicit((Object)(object)playerTarget) && playerTarget.isDisabled)
		{
			UpdateHeadTarget(playerTarget.playerDeathHead);
			UpdateState(State.GotoHeadOver);
			return;
		}
		if (stateImpulse)
		{
			stateImpulse = false;
			stateTimer = 5f;
			RigidbodyReset();
		}
		if (!flag)
		{
			UpdateState(State.BackToNavmesh);
			return;
		}
		enemy.NavMeshAgent.Disable(0.1f);
		if (Vector3.Distance(((Component)enemy.Rigidbody).transform.position, position) > 1.5f)
		{
			float num = enemy.NavMeshAgent.DefaultSpeed;
			if (headTargetActive)
			{
				num = 6f;
			}
			((Component)this).transform.position = Vector3.MoveTowards(((Component)this).transform.position, position, num * Time.deltaTime);
		}
		else
		{
			((Component)this).transform.position = ((Component)enemy.Rigidbody).transform.position;
			enemy.Rigidbody.DisableFollowPosition(0.1f, 5f);
			if (currentState == State.GotoHeadOver)
			{
				UpdateState(State.GrabHead);
				return;
			}
		}
		if (currentState == State.GotoPlayerOver && AttackSet(position))
		{
			return;
		}
		SemiFunc.EnemyCartJump(enemy);
		if (position.y > ((Component)enemy.Rigidbody).transform.position.y + 0.3f && !enemy.Jump.jumping && !enemy.Jump.jumpingDelay && !enemy.Jump.landDelay && !enemy.Jump.stuckJumpImpulse)
		{
			Vector3 val = position - ((Component)enemy.Rigidbody).transform.position;
			Vector3 normalized = val.normalized;
			enemy.Jump.StuckTrigger(normalized);
			enemy.Rigidbody.WarpDisable(0.25f);
			((Component)this).transform.position = ((Component)enemy.Rigidbody).transform.position;
			((Component)this).transform.position = Vector3.MoveTowards(((Component)this).transform.position, position, 2f);
			stateTimer -= 0.5f;
		}
		if (enemy.Jump.jumping || enemy.Jump.jumpingDelay || enemy.Jump.landDelay)
		{
			return;
		}
		NavMeshHit val2 = default;
		if (NavMesh.SamplePosition(position, ref val2, 0.5f, -1))
		{
			UpdateState(State.BackToNavmesh);
		}
		else if (currentState == State.GotoPlayerOver || VisionBlocked() || enemy.Rigidbody.notMovingTimer > 2f)
		{
			stateTimer -= Time.deltaTime;
			if (stateTimer <= 0f)
			{
				UpdateState(State.BackToNavmesh);
			}
		}
		else
		{
			stateTimer = 2f;
		}
	}

	private void DeathHeadLogic()
	{
		//IL_0194: Unknown result type (might be due to invalid IL or missing references)
		//IL_019a: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c2: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d2: Unknown result type (might be due to invalid IL or missing references)
		if (headTargetActive)
		{
			headTargetTime += Time.deltaTime;
			enemy.EnemyParent.SpawnedTimerPause(0.5f);
			if (!Object.op_Implicit((Object)(object)headTarget) || headTargetRelease || !Object.op_Implicit((Object)(object)headTarget.playerAvatar) || !headTarget.playerAvatar.isDisabled || currentState == State.Stun || currentState == State.Despawn)
			{
				DeathHeadRelease();
			}
			else
			{
				headTarget.OverrideSpectated(0.5f);
				if (!topColliderActive && SemiFunc.PerSecond(5f, (Object)(object)this))
				{
					bool flag = false;
					Collider[] array = Physics.OverlapSphere(((Component)topCollider).transform.position, topCollider.radius, LayerMask.op_Implicit(SemiFunc.LayerMaskGetVisionObstruct()));
					foreach (Collider val in array)
					{
						if (!((Component)val).gameObject.CompareTag("Phys Grab Object") || !((Object)(object)((Component)val).GetComponentInParent<PhysGrabObject>() == (Object)(object)enemy.Rigidbody.physGrabObject))
						{
							flag = true;
						}
					}
					if (!flag)
					{
						ToggleTopCollider(_active: true);
					}
				}
			}
		}
		else
		{
			headTargetTime = 0f;
			headTargetRelease = false;
		}
		if (headTargetActivePrevious != headTargetActive)
		{
			headTargetActivePrevious = headTargetActive;
			if (GameManager.Multiplayer())
			{
				photonView.RPC("UpdateHeadTargetActiveRPC", (RpcTarget)0, new object[1] { headTargetActive });
			}
			else
			{
				UpdateHeadTargetActiveRPC(headTargetActive);
			}
		}
		if (nearbyHeadLogic && currentState != State.GotoHead && currentState != State.GotoHeadOver && currentState != State.GrabHead && currentState != State.GotoPlayer && currentState != State.BackToNavmesh)
		{
			nearbyHeadLogic = false;
		}
	}

	private void DeathHeadLogicShared()
	{
		//IL_00d4: Unknown result type (might be due to invalid IL or missing references)
		//IL_00df: Unknown result type (might be due to invalid IL or missing references)
		//IL_0060: Unknown result type (might be due to invalid IL or missing references)
		//IL_006b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0081: Unknown result type (might be due to invalid IL or missing references)
		//IL_0086: Unknown result type (might be due to invalid IL or missing references)
		//IL_0088: Unknown result type (might be due to invalid IL or missing references)
		//IL_0093: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a9: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ae: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b5: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c1: Unknown result type (might be due to invalid IL or missing references)
		if (headTargetActive && Object.op_Implicit((Object)(object)headTarget))
		{
			headTargetPositionLerp += 2f * Time.deltaTime;
			headTargetPositionLerp = Mathf.Clamp01(headTargetPositionLerp);
			Transform followTransform = headTargetPositionTransform;
			if (headTargetPositionLerp < 1f)
			{
				followTransform = headTargetPositionFollowTransform;
				Vector3 position = Vector3.LerpUnclamped(headTargetOriginalPosition, headTargetPositionTransform.position, headTargetPositionCurve.Evaluate(headTargetPositionLerp));
				Quaternion rotation = Quaternion.SlerpUnclamped(headTargetOriginalRotation, headTargetPositionTransform.rotation, headTargetPositionCurve.Evaluate(headTargetPositionLerp));
				headTargetPositionFollowTransform.position = position;
				headTargetPositionFollowTransform.rotation = rotation;
			}
			headTarget.OverridePositionRotation(followTransform, headTargetPositionReleaseTransform.position, headTargetPositionReleaseTransform.rotation, 0.1f);
		}
		else
		{
			headTargetPositionLerp = 0f;
		}
	}

	public void DeathHeadRelease()
	{
		if (headTargetActive)
		{
			headTargetActive = false;
			headTargetCooldown = 120f;
			if (Object.op_Implicit((Object)(object)headTarget))
			{
				headTarget.OverridePositionRotationReset();
				headTarget.OverrideSpectatedReset();
			}
			ToggleTopCollider(_active: false);
			if (SemiFunc.IsMultiplayer())
			{
				photonView.RPC("DeathHeadReleaseRPC", (RpcTarget)1, Array.Empty<object>());
			}
			headTarget = null;
		}
	}

	private bool AttackSet(Vector3 _targetPosition)
	{
		//IL_0055: Unknown result type (might be due to invalid IL or missing references)
		//IL_005a: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f6: Unknown result type (might be due to invalid IL or missing references)
		//IL_00fc: Unknown result type (might be due to invalid IL or missing references)
		if (attackCooldown > 0f || enemy.Jump.jumping || enemy.Jump.jumpingDelay || enemy.Jump.landDelay)
		{
			return false;
		}
		if (Vector3.Distance(((Component)enemy.Rigidbody).transform.position, _targetPosition) > 2f)
		{
			return false;
		}
		for (attackIndex = attackIndexPrevious; attackIndex == attackIndexPrevious; attackIndex = Random.Range(0, 3))
		{
		}
		attackIndexPrevious = attackIndex;
		if (attackIndex == 2)
		{
			attackCooldown = 2f;
		}
		else
		{
			attackCooldown = 1f;
		}
		if (GameManager.Multiplayer())
		{
			photonView.RPC("AttackSetRPC", (RpcTarget)0, new object[1] { attackIndex });
		}
		else
		{
			AttackSetRPC(attackIndex);
		}
		UpdateState(State.Attack);
		return true;
	}

	private void TimerLogic()
	{
		if (attackCooldown > 0f)
		{
			attackCooldown -= Time.deltaTime;
		}
		if (headTargetCooldown > 0f)
		{
			headTargetCooldown -= Time.deltaTime;
		}
		if (rotationStopTimer > 0f)
		{
			rotationStopTimer -= Time.deltaTime;
		}
	}

	private PlayerDeathHead GetClosestDeathHead(float _distanceMax)
	{
		//IL_005b: Unknown result type (might be due to invalid IL or missing references)
		//IL_006b: Unknown result type (might be due to invalid IL or missing references)
		PlayerDeathHead result = null;
		float num = _distanceMax;
		if (headTargetCooldown <= 0f)
		{
			foreach (PlayerAvatar item in SemiFunc.PlayerGetList())
			{
				if (item.isDisabled && Object.op_Implicit((Object)(object)item.playerDeathHead) && !item.playerDeathHead.overrideSpectated)
				{
					float num2 = Vector3.Distance(((Component)enemy.Rigidbody).transform.position, ((Component)item.playerDeathHead).transform.position);
					if (num2 < num)
					{
						num = num2;
						result = item.playerDeathHead;
					}
				}
			}
		}
		return result;
	}

	private bool NearbyHeadLogic()
	{
		if (SemiFunc.PerSecond(1f, (Object)(object)this) && !headTargetActive)
		{
			PlayerDeathHead closestDeathHead = GetClosestDeathHead(10f);
			if (Object.op_Implicit((Object)(object)closestDeathHead))
			{
				UpdatePlayerTarget(null);
				UpdateHeadTarget(closestDeathHead);
				nearbyHeadLogic = true;
				UpdateState(State.GotoHead);
				return true;
			}
		}
		return false;
	}

	private void LocalMeshLogicShared()
	{
		if (headTargetActive && headTargetActiveLocal && Object.op_Implicit((Object)(object)SpectateCamera.instance) && SpectateCamera.instance.CheckState(SpectateCamera.State.Head))
		{
			if (!localMeshHidden)
			{
				foreach (MeshRenderer renderer in enemy.Health.renderers)
				{
					((Component)renderer).gameObject.layer = LayerMask.NameToLayer("HideTriggers");
				}
				localMeshHidden = true;
			}
			if (!Object.op_Implicit((Object)(object)localCameraObject))
			{
				if (Object.op_Implicit((Object)(object)Camera.main))
				{
					GameObject val = Object.Instantiate<GameObject>(localCameraPrefab, ((Component)Camera.main).transform);
					localCameraObject = val.GetComponent<EnemyHeadGrabberLocalCamera>();
				}
			}
			else
			{
				localCameraObject.Active();
			}
		}
		else
		{
			if (!localMeshHidden)
			{
				return;
			}
			if (Object.op_Implicit((Object)(object)localCameraObject))
			{
				localCameraObject.ActiveReset();
			}
			foreach (MeshRenderer renderer2 in enemy.Health.renderers)
			{
				((Component)renderer2).gameObject.layer = LayerMask.NameToLayer("Default");
			}
			localMeshHidden = false;
		}
	}

	[PunRPC]
	private void UpdateStateRPC(State _state, PhotonMessageInfo _info = default(PhotonMessageInfo))
	{
		//IL_0000: Unknown result type (might be due to invalid IL or missing references)
		if (SemiFunc.MasterOnlyRPC(_info))
		{
			currentState = _state;
		}
	}

	[PunRPC]
	private void UpdatePlayerTargetRPC(int _photonViewID, PhotonMessageInfo _info = default(PhotonMessageInfo))
	{
		//IL_0000: Unknown result type (might be due to invalid IL or missing references)
		if (!SemiFunc.MasterOnlyRPC(_info))
		{
			return;
		}
		foreach (PlayerAvatar item in SemiFunc.PlayerGetList())
		{
			if (item.photonView.ViewID == _photonViewID)
			{
				playerTarget = item;
				break;
			}
		}
	}

	[PunRPC]
	private void UpdateHeadTargetRPC(int _photonViewID, PhotonMessageInfo _info = default(PhotonMessageInfo))
	{
		//IL_0000: Unknown result type (might be due to invalid IL or missing references)
		if (!SemiFunc.MasterOnlyRPC(_info))
		{
			return;
		}
		foreach (PlayerAvatar item in SemiFunc.PlayerGetList())
		{
			if (item.playerDeathHead.photonView.ViewID == _photonViewID)
			{
				headTarget = item.playerDeathHead;
				break;
			}
		}
	}

	[PunRPC]
	private void UpdateHeadTargetActiveRPC(bool _active, PhotonMessageInfo _info = default(PhotonMessageInfo))
	{
		//IL_0000: Unknown result type (might be due to invalid IL or missing references)
		//IL_0058: Unknown result type (might be due to invalid IL or missing references)
		//IL_005d: Unknown result type (might be due to invalid IL or missing references)
		//IL_006e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0073: Unknown result type (might be due to invalid IL or missing references)
		if (!SemiFunc.MasterOnlyRPC(_info))
		{
			return;
		}
		headTargetActive = _active;
		if (headTargetActive)
		{
			if (Object.op_Implicit((Object)(object)headTarget.playerAvatar) && headTarget.playerAvatar.isLocal)
			{
				headTargetActiveLocal = true;
			}
			else
			{
				headTargetActiveLocal = false;
			}
			headTargetOriginalPosition = ((Component)headTarget).transform.position;
			headTargetOriginalRotation = ((Component)headTarget).transform.rotation;
			headTargetPositionLerp = 0f;
		}
		LocalMeshLogicShared();
	}

	private void ToggleTopCollider(bool _active)
	{
		//IL_0035: Unknown result type (might be due to invalid IL or missing references)
		//IL_003b: Unknown result type (might be due to invalid IL or missing references)
		if (topColliderActive != _active)
		{
			if (GameManager.Multiplayer())
			{
				photonView.RPC("ToggleTopColliderRPC", (RpcTarget)0, new object[1] { _active });
			}
			else
			{
				ToggleTopColliderRPC(_active);
			}
		}
	}

	[PunRPC]
	private void ToggleTopColliderRPC(bool _active, PhotonMessageInfo _info = default(PhotonMessageInfo))
	{
		//IL_0000: Unknown result type (might be due to invalid IL or missing references)
		if (SemiFunc.MasterOnlyRPC(_info))
		{
			topColliderActive = _active;
			((Collider)topCollider).enabled = _active;
		}
	}

	[PunRPC]
	private void DeathHeadReleaseRPC(PhotonMessageInfo _info = default(PhotonMessageInfo))
	{
		//IL_0000: Unknown result type (might be due to invalid IL or missing references)
		if (SemiFunc.MasterOnlyRPC(_info) && Object.op_Implicit((Object)(object)headTarget))
		{
			headTarget.OverridePositionRotationReset();
		}
	}

	[PunRPC]
	private void AttackSetRPC(int _index, PhotonMessageInfo _info = default(PhotonMessageInfo))
	{
		//IL_0000: Unknown result type (might be due to invalid IL or missing references)
		if (SemiFunc.MasterOnlyRPC(_info))
		{
			attackIndex = _index;
			anim.AttackSet(attackIndex);
		}
	}

	[PunRPC]
	private void IdleBreakerSetRPC(int _index, PhotonMessageInfo _info = default(PhotonMessageInfo))
	{
		//IL_0000: Unknown result type (might be due to invalid IL or missing references)
		if (SemiFunc.MasterOnlyRPC(_info))
		{
			idleBreakerIndex = _index;
			anim.IdleBreakerSet(idleBreakerIndex);
		}
	}

	[PunRPC]
	private void OnDropKickHitRPC(PhotonMessageInfo _info = default(PhotonMessageInfo))
	{
		if (!(Time.time - dropkickHitTimeLast < 0.5f))
		{
			dropkickHitTimeLast = Time.time;
			anim.EventDropkickHit();
		}
	}

	public void OnSpawn()
	{
		if (SemiFunc.IsMasterClientOrSingleplayer() && SemiFunc.EnemySpawn(enemy))
		{
			UpdateState(State.Spawn);
		}
	}

	public void OnVision()
	{
		if (enemy.Jump.jumpingDelay || enemy.Jump.jumping)
		{
			return;
		}
		if (currentState == State.Idle || currentState == State.IdleBreaker || currentState == State.Roam || currentState == State.RoamFast || currentState == State.Investigate || currentState == State.InvestigateFast || currentState == State.Leave)
		{
			UpdatePlayerTarget(enemy.Vision.onVisionTriggeredPlayer);
			if (Object.op_Implicit((Object)(object)playerTarget))
			{
				UpdateState(State.Notice);
			}
		}
		else
		{
			if (currentState != State.GotoPlayer && currentState != State.GotoPlayerOver)
			{
				return;
			}
			if ((Object)(object)playerTarget == (Object)(object)enemy.Vision.onVisionTriggeredPlayer)
			{
				stateTimer = Mathf.Max(2f, stateTimer);
			}
			else if (nearbyHeadLogic)
			{
				UpdatePlayerTarget(enemy.Vision.onVisionTriggeredPlayer);
				if (Object.op_Implicit((Object)(object)playerTarget))
				{
					UpdateState(State.Notice);
				}
			}
			nearbyHeadLogic = false;
		}
	}

	public void OnInvestigate()
	{
		//IL_0043: Unknown result type (might be due to invalid IL or missing references)
		//IL_0048: Unknown result type (might be due to invalid IL or missing references)
		//IL_0053: Unknown result type (might be due to invalid IL or missing references)
		//IL_0059: Unknown result type (might be due to invalid IL or missing references)
		//IL_0078: Unknown result type (might be due to invalid IL or missing references)
		//IL_007e: Unknown result type (might be due to invalid IL or missing references)
		if (SemiFunc.IsMasterClientOrSingleplayer() && (currentState == State.Idle || currentState == State.Roam || currentState == State.RoamFast || currentState == State.Investigate || currentState == State.InvestigateFast))
		{
			agentDestination = enemy.StateInvestigate.onInvestigateTriggeredPosition;
			if (Vector3.Distance(((Component)this).transform.position, agentDestination) > 10f)
			{
				UpdateState(State.InvestigateFast);
			}
			else if (Vector3.Distance(((Component)this).transform.position, agentDestination) > 2f)
			{
				UpdateState(State.Investigate);
			}
		}
	}

	public void OnHurt()
	{
		//IL_0016: Unknown result type (might be due to invalid IL or missing references)
		anim.soundHurt.Play(enemy.CenterTransform.position);
		anim.soundLoopPauseTimer = 0.5f;
		if (SemiFunc.IsMasterClientOrSingleplayer() && currentState == State.Leave)
		{
			UpdateState(State.Idle);
		}
	}

	public void OnDeath()
	{
		anim.EventDeath();
		if (SemiFunc.IsMasterClientOrSingleplayer())
		{
			DeathHeadRelease();
			enemy.EnemyParent.Despawn();
		}
	}

	public void OnDropkickHit()
	{
		//IL_0021: Unknown result type (might be due to invalid IL or missing references)
		//IL_0027: Unknown result type (might be due to invalid IL or missing references)
		if (SemiFunc.IsMultiplayer())
		{
			photonView.RPC("OnDropKickHitRPC", (RpcTarget)0, Array.Empty<object>());
		}
		else
		{
			OnDropKickHitRPC();
		}
	}

	public EnemyHeadGrabber()
	{
		//IL_0001: Unknown result type (might be due to invalid IL or missing references)
		//IL_0006: Unknown result type (might be due to invalid IL or missing references)
	}
}
