using System;
using System.Collections;
using Photon.Pun;
using UnityEngine;

public class EnemyTickHealAura : MonoBehaviour
{
	private PhotonView photonView;

	public int healthPool;

	private LayerMask LayerMask;

	private Collider Collider;

	private SphereCollider SphereCollider;

	private float timeUntilDestroy = 4f;

	private float healDelayTimer;

	private float healDelay = 0.4f;

	private float totalDuration = 3f;

	private bool durationBonusApplied;

	private bool disperse;

	private bool disperseImpulse = true;

	public ParticleSystem[] particles;

	public ParticleSystem healImpactParticle;

	public ParticleSystem healImpactSmokeParticles;

	public Sound auraLoop;

	private void Update()
	{
		//IL_00d3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d9: Unknown result type (might be due to invalid IL or missing references)
		auraLoop.PlayLoop(!disperse, 5f, 0.5f);
		if (disperse)
		{
			Disperse();
		}
		else
		{
			if (!SemiFunc.IsMasterClientOrSingleplayer())
			{
				return;
			}
			if (!durationBonusApplied && healthPool > 100)
			{
				totalDuration += (healthPool - 100) / 20;
				durationBonusApplied = true;
			}
			if (healthPool <= 0)
			{
				totalDuration = 0f;
			}
			if (healDelayTimer > 0f)
			{
				healDelayTimer -= Time.deltaTime;
			}
			if (totalDuration <= 0f)
			{
				if (GameManager.Multiplayer())
				{
					photonView.RPC("DisperseRPC", (RpcTarget)0, Array.Empty<object>());
				}
				else
				{
					DisperseRPC();
				}
			}
			else
			{
				totalDuration -= Time.deltaTime;
			}
		}
	}

	private void Awake()
	{
		//IL_0025: Unknown result type (might be due to invalid IL or missing references)
		//IL_0043: Unknown result type (might be due to invalid IL or missing references)
		//IL_0048: Unknown result type (might be due to invalid IL or missing references)
		photonView = ((Component)this).GetComponent<PhotonView>();
		SphereCollider = ((Component)this).GetComponent<SphereCollider>();
		Collider = (Collider)(object)SphereCollider;
		LayerMask = LayerMask.op_Implicit(LayerMask.op_Implicit(SemiFunc.LayerMaskGetPhysGrabObject()) + LayerMask.GetMask(new string[1] { "Player" }));
		if (particles.Length != 0)
		{
			ParticleSystem[] array = particles;
			foreach (ParticleSystem val in array)
			{
				if (!val.isPlaying)
				{
					val.Play();
				}
			}
		}
		if (SemiFunc.IsMasterClientOrSingleplayer())
		{
			((MonoBehaviour)this).StartCoroutine(ColliderCheck());
		}
	}

	private IEnumerator ColliderCheck()
	{
		yield return null;
		while (!Object.op_Implicit((Object)(object)LevelGenerator.Instance) || !LevelGenerator.Instance.Generated)
		{
			yield return (object)new WaitForSeconds(0.1f);
		}
		while (true)
		{
			Bounds bounds = Collider.bounds;
			Vector3 center = bounds.center;
			float num = ((Component)this).transform.lossyScale.x * SphereCollider.radius;
			Collider[] array = Physics.OverlapSphere(center, num, LayerMask.op_Implicit(LayerMask), (QueryTriggerInteraction)2);
			if (array.Length != 0)
			{
				Collider[] array2 = array;
				foreach (Collider val in array2)
				{
					if (((Component)val).gameObject.CompareTag("Player"))
					{
						PlayerAvatar playerAvatar = ((Component)val).gameObject.GetComponentInParent<PlayerAvatar>();
						if (!Object.op_Implicit((Object)(object)playerAvatar))
						{
							PlayerController componentInParent = ((Component)val).gameObject.GetComponentInParent<PlayerController>();
							if (Object.op_Implicit((Object)(object)componentInParent))
							{
								playerAvatar = componentInParent.playerAvatarScript;
							}
						}
						if (Object.op_Implicit((Object)(object)playerAvatar))
						{
							PlayerHeal(playerAvatar);
						}
					}
					if (((Component)val).gameObject.CompareTag("Phys Grab Object") && Object.op_Implicit((Object)(object)((Component)val).gameObject.GetComponentInParent<PhysGrabObject>()))
					{
						bool flag = false;
						PlayerTumble componentInParent2 = ((Component)val).gameObject.GetComponentInParent<PlayerTumble>();
						if (Object.op_Implicit((Object)(object)componentInParent2))
						{
							flag = true;
						}
						if (flag)
						{
							PlayerHeal(componentInParent2.playerAvatar);
						}
					}
				}
			}
			yield return (object)new WaitForSeconds(0.05f);
		}
	}

	private void PlayerHeal(PlayerAvatar _player)
	{
		int num = _player.playerHealth.maxHealth - _player.playerHealth.health;
		if (healDelayTimer <= 0f && healthPool > 0 && num > 0)
		{
			if (num < 10)
			{
				_player.playerHealth.HealOther(num, effect: true);
				HealthEffects();
				healthPool -= num;
				healDelayTimer = healDelay;
			}
			else if (healthPool > 10)
			{
				_player.playerHealth.HealOther(10, effect: true);
				HealthEffects();
				healthPool -= 10;
				healDelayTimer = healDelay;
			}
			else
			{
				_player.playerHealth.HealOther(healthPool, effect: true);
				HealthEffects();
				healthPool = 0;
				healDelayTimer = healDelay;
			}
		}
	}

	private void Disperse()
	{
		if (disperseImpulse)
		{
			if (particles.Length != 0)
			{
				ParticleSystem[] array = particles;
				foreach (ParticleSystem val in array)
				{
					if (Object.op_Implicit((Object)(object)val))
					{
						if (val.isPlaying)
						{
							val.Stop();
						}
						((Component)val).gameObject.transform.parent = null;
					}
				}
			}
			if (Object.op_Implicit((Object)(object)healImpactParticle))
			{
				((Component)healImpactParticle).gameObject.transform.parent = null;
			}
			if (Object.op_Implicit((Object)(object)healImpactSmokeParticles))
			{
				((Component)healImpactSmokeParticles).gameObject.transform.parent = null;
			}
			disperseImpulse = false;
			((MonoBehaviour)this).StopAllCoroutines();
		}
		if (!SemiFunc.IsMasterClientOrSingleplayer())
		{
			return;
		}
		timeUntilDestroy -= Time.deltaTime;
		if (timeUntilDestroy <= 0f)
		{
			if (!SemiFunc.IsMultiplayer())
			{
				Object.Destroy((Object)(object)((Component)this).gameObject);
			}
			else
			{
				PhotonNetwork.Destroy(((Component)this).gameObject);
			}
		}
	}

	private void HealthEffects()
	{
		//IL_0021: Unknown result type (might be due to invalid IL or missing references)
		//IL_0027: Unknown result type (might be due to invalid IL or missing references)
		if (GameManager.Multiplayer())
		{
			photonView.RPC("HealEffectsRPC", (RpcTarget)0, Array.Empty<object>());
		}
		else
		{
			HealEffectsRPC();
		}
	}

	[PunRPC]
	private void DisperseRPC(PhotonMessageInfo _info = default(PhotonMessageInfo))
	{
		//IL_0000: Unknown result type (might be due to invalid IL or missing references)
		if (SemiFunc.MasterOnlyRPC(_info))
		{
			disperse = true;
		}
	}

	[PunRPC]
	private void HealEffectsRPC(PhotonMessageInfo _info = default(PhotonMessageInfo))
	{
		//IL_0000: Unknown result type (might be due to invalid IL or missing references)
		if (SemiFunc.MasterOnlyRPC(_info))
		{
			if (Object.op_Implicit((Object)(object)healImpactParticle))
			{
				healImpactParticle.Play();
			}
			if (Object.op_Implicit((Object)(object)healImpactSmokeParticles))
			{
				healImpactSmokeParticles.Play();
			}
		}
	}
}
