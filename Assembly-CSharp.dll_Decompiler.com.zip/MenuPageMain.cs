using System.IO;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

public class MenuPageMain : MonoBehaviour
{
	public static MenuPageMain instance;

	public RectTransform rectTransformLeft;

	public RectTransform rectTransformRight;

	private float waitTimer;

	private bool animateIn;

	internal MenuPage menuPage;

	private bool introDone;

	private float joinLobbyTimer = 0.1f;

	private float popUpTimer = 1.5f;

	private bool doIntroAnimation = true;

	private const float introStartX = 600f;

	private CanvasGroup introGroupLeft;

	private CanvasGroup introGroupRight;

	[Space]
	public MenuButton tutorialButton;

	private bool tutorialButtonBlinkActive;

	private bool tutorialButtonBlink;

	private float tutorialButtonTimer;

	[Space]
	public MenuButton customizeButton;

	public MenuElementCosmeticHighlight customizeHighlightObj;

	public MenuButton youtubeButton;

	public SemiUI youtubeButtonSemiUI;

	private bool youtubeButtonClicked;

	private bool youtubeButtonHovered;

	public MenuButton discordButton;

	public SemiUI discordButtonSemiUI;

	private bool discordButtonClicked;

	private bool discordButtonHovered;

	public MenuButton marketingButton;

	public SemiUI marketingButtonSemiUI;

	private bool marketingButtonClicked;

	private bool marketingButtonHovered;

	[Space]
	public MenuPlayerHead marketingPlayerHead;

	public TextMeshProUGUI marketingTitleText;

	public TextMeshProUGUI marketingMessageText;

	[Space]
	public AnimationCurve marketingPopupScaleCurve;

	private float marketingPopupScaleLerp;

	public AnimationCurve marketingPopupRotationCurve;

	private float marketingPopupRotationLerp;

	public AnimationCurve marketingPopupMouthCurve;

	private float marketingPopupMouthLerp;

	public Sound marketingPopupSound;

	public MenuButton marketingPopupButton;

	public SemiUI marketingPopupSemiUI;

	private bool marketingPopupButtonClicked;

	private bool marketingPopupButtonHovered;

	[RuntimeInitializeOnLoadMethod(/*Could not decode attribute arguments.*/)]
	private static void RuntimeInitializeOnLoad()
	{
		instance = null;
	}

	private void Awake()
	{
		//IL_0011: Unknown result type (might be due to invalid IL or missing references)
		instance = this;
		((Component)marketingPopupSemiUI).transform.localScale = Vector3.zero;
		UpdateMarketingMessage();
	}

	private void Start()
	{
		//IL_00c3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c8: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d8: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f2: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f7: Unknown result type (might be due to invalid IL or missing references)
		menuPage = ((Component)this).GetComponent<MenuPage>();
		if (Object.op_Implicit((Object)(object)MainMenuOpen.instance) && MainMenuOpen.instance.firstOpen)
		{
			MainMenuOpen.instance.firstOpen = false;
			menuPage.disableOutroAnimation = false;
			menuPage.interactionBlocked = true;
			introGroupLeft = IntroGroupAdd(rectTransformLeft);
			introGroupRight = IntroGroupAdd(rectTransformRight);
		}
		else
		{
			menuPage.disableIntroAnimation = false;
			menuPage.disableOutroAnimation = false;
			doIntroAnimation = false;
		}
		if (DataDirector.instance.SettingValueFetch(DataDirector.Setting.TutorialPlayed) <= 0)
		{
			tutorialButtonBlinkActive = true;
			tutorialButton.customColors = true;
			tutorialButton.colorNormal = new Color(1f, 0.55f, 0f);
			tutorialButton.colorHover = Color.white;
			tutorialButton.colorClick = new Color(1f, 0.55f, 0f);
		}
		if (Object.op_Implicit((Object)(object)SteamLobbyManager.instance) && SteamLobbyManager.instance.lobbyIdToAutoJoin != 0L)
		{
			SteamLobbyManager.instance.StartAutoJoiningLobby();
		}
		UpdateHighlight();
		if (Object.op_Implicit((Object)(object)marketingPopupButton.menuSelectableElement))
		{
			((Selectable)marketingPopupButton.menuSelectableElement).interactable = false;
		}
	}

	private void Update()
	{
		//IL_005e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0063: Unknown result type (might be due to invalid IL or missing references)
		//IL_003d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0042: Unknown result type (might be due to invalid IL or missing references)
		//IL_0241: Unknown result type (might be due to invalid IL or missing references)
		//IL_0260: Unknown result type (might be due to invalid IL or missing references)
		//IL_0281: Unknown result type (might be due to invalid IL or missing references)
		//IL_02aa: Unknown result type (might be due to invalid IL or missing references)
		//IL_02c0: Unknown result type (might be due to invalid IL or missing references)
		//IL_02e9: Unknown result type (might be due to invalid IL or missing references)
		//IL_031d: Unknown result type (might be due to invalid IL or missing references)
		if (tutorialButtonBlinkActive)
		{
			if (tutorialButtonTimer <= 0f)
			{
				tutorialButtonTimer = 0.5f;
				tutorialButtonBlink = !tutorialButtonBlink;
				if (tutorialButtonBlink)
				{
					tutorialButton.colorNormal = Color.white;
				}
				else
				{
					tutorialButton.colorNormal = new Color(1f, 0.55f, 0f);
				}
			}
			else
			{
				tutorialButtonTimer -= Time.deltaTime;
			}
		}
		if (menuPage.currentPageState == MenuPage.PageState.Closing)
		{
			return;
		}
		if (RunManager.instance.localSingleplayerTest)
		{
			RunManager.instance.localSingleplayerTest = false;
			if (!MenuManager.instance.pagePopUpScheduled)
			{
				RunManager.instance.ResetProgress();
				GameManager.instance.SetConnectRandom(_connectRandom: false);
				GameManager.instance.SetLobbyType(GameManager.LobbyTypes.Private);
				InitDebugSaveFile();
				DataDirector.instance.RunsPlayedAdd();
				if (RunManager.instance.loadLevel == 1)
				{
					RunManager.instance.ChangeLevel(_completedLevel: true, _levelFailed: false, RunManager.ChangeLevelType.Shop);
				}
				else if (RunManager.instance.loadLevel == 2)
				{
					RunManager.instance.ChangeLevel(_completedLevel: true, _levelFailed: false);
				}
				else
				{
					RunManager.instance.ChangeLevel(_completedLevel: true, _levelFailed: false, RunManager.ChangeLevelType.RunLevel);
				}
			}
		}
		else if (RunManager.instance.localMultiplayerTest)
		{
			RunManager.instance.localMultiplayerTest = false;
			if (!MenuManager.instance.pagePopUpScheduled)
			{
				GameManager.instance.localTest = true;
				SteamLobbyManager.instance.joinLobby = false;
				RunManager.instance.ResetProgress();
				GameManager.instance.SetConnectRandom(_connectRandom: false);
				GameManager.instance.SetLobbyType(GameManager.LobbyTypes.Private);
				InitDebugSaveFile();
				RunManager.instance.waitToChangeScene = true;
				RunManager.instance.ChangeLevel(_completedLevel: true, _levelFailed: false, RunManager.ChangeLevelType.LobbyMenu);
				RunManager.instance.lobbyJoin = true;
			}
		}
		if (!LevelGenerator.Instance.Generated)
		{
			return;
		}
		if (popUpTimer > 0f)
		{
			popUpTimer -= Time.deltaTime;
			if (popUpTimer <= 0f)
			{
				MenuManager.instance.PagePopUpScheduledShow();
			}
		}
		if (doIntroAnimation)
		{
			waitTimer += Time.deltaTime;
			if (waitTimer > 3f)
			{
				animateIn = true;
			}
			else
			{
				((Transform)rectTransformLeft).localPosition = new Vector3(-600f, 0f, 0f);
				((Transform)rectTransformRight).localPosition = new Vector3(600f, 0f, 0f);
			}
			if (animateIn)
			{
				((Transform)rectTransformLeft).localPosition = new Vector3(Mathf.Lerp(((Transform)rectTransformLeft).localPosition.x, 0f, Time.deltaTime * 2f), 0f, 0f);
				((Transform)rectTransformRight).localPosition = new Vector3(Mathf.Lerp(((Transform)rectTransformRight).localPosition.x, 0f, Time.deltaTime * 2f), 0f, 0f);
				IntroGroupUpdate(introGroupLeft, rectTransformLeft);
				IntroGroupUpdate(introGroupRight, rectTransformRight);
				if (Mathf.Abs(((Transform)rectTransformLeft).localPosition.x) < 50f && !introDone)
				{
					menuPage.PageStateSet(MenuPage.PageState.Active);
					introDone = true;
				}
			}
			if (waitTimer > 5.5f)
			{
				RunMarketingPopupCurves();
			}
		}
		else
		{
			if (!introDone)
			{
				menuPage.PageStateSet(MenuPage.PageState.Active);
				introDone = true;
			}
			RunMarketingPopupCurves();
		}
		if (Object.op_Implicit((Object)(object)SteamLobbyManager.instance) && SteamLobbyManager.instance.joinLobby)
		{
			if (joinLobbyTimer > 0f)
			{
				joinLobbyTimer -= Time.deltaTime;
			}
			else
			{
				GameManager.instance.localTest = false;
				RunManager.instance.ResetProgress();
				RunManager.instance.waitToChangeScene = true;
				RunManager.instance.lobbyJoin = true;
				RunManager.instance.ChangeLevel(_completedLevel: true, _levelFailed: false, RunManager.ChangeLevelType.LobbyMenu);
				SteamLobbyManager.instance.joinLobby = false;
			}
		}
		if (youtubeButton.clicked != youtubeButtonClicked)
		{
			youtubeButtonClicked = youtubeButton.clicked;
			if (youtubeButtonClicked)
			{
				youtubeButtonSemiUI.SemiUISpringScale(-0.3f, 2f, 0.3f);
			}
		}
		if (youtubeButton.hovering != youtubeButtonHovered)
		{
			youtubeButtonHovered = youtubeButton.hovering;
			if (youtubeButtonHovered)
			{
				youtubeButtonSemiUI.SemiUISpringShakeY(5f, 2f, 0.3f);
			}
		}
		if (discordButton.clicked != discordButtonClicked)
		{
			discordButtonClicked = discordButton.clicked;
			if (discordButtonClicked)
			{
				discordButtonSemiUI.SemiUISpringScale(-0.3f, 2f, 0.3f);
			}
		}
		if (discordButton.hovering != discordButtonHovered)
		{
			discordButtonHovered = discordButton.hovering;
			if (discordButtonHovered)
			{
				discordButtonSemiUI.SemiUISpringShakeY(5f, 2f, 0.3f);
			}
		}
		if (marketingButton.clicked != marketingButtonClicked)
		{
			marketingButtonClicked = marketingButton.clicked;
			if (marketingButtonClicked)
			{
				marketingButtonSemiUI.SemiUISpringScale(-0.3f, 2f, 0.3f);
			}
		}
		if (marketingButton.hovering != marketingButtonHovered)
		{
			marketingButtonHovered = marketingButton.hovering;
			if (marketingButtonHovered)
			{
				marketingButtonSemiUI.SemiUISpringShakeY(5f, 2f, 0.3f);
			}
		}
		if (marketingPopupButton.clicked != marketingPopupButtonClicked)
		{
			marketingPopupButtonClicked = marketingPopupButton.clicked;
			if (marketingPopupButtonClicked)
			{
				marketingPopupSemiUI.SemiUISpringScale(-0.3f, 2f, 0.3f);
			}
		}
		if (marketingPopupButton.hovering != marketingPopupButtonHovered)
		{
			marketingPopupButtonHovered = marketingPopupButton.hovering;
			if (marketingPopupButtonHovered)
			{
				marketingPopupSemiUI.SemiUISpringShakeY(5f, 2f, 0.3f);
			}
		}
	}

	private void RunMarketingPopupCurves()
	{
		//IL_0077: Unknown result type (might be due to invalid IL or missing references)
		//IL_007c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0081: Unknown result type (might be due to invalid IL or missing references)
		//IL_0097: Unknown result type (might be due to invalid IL or missing references)
		//IL_010b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0110: Unknown result type (might be due to invalid IL or missing references)
		//IL_0126: Unknown result type (might be due to invalid IL or missing references)
		//IL_012b: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c9: Unknown result type (might be due to invalid IL or missing references)
		if (!Object.op_Implicit((Object)(object)marketingPopupSemiUI))
		{
			return;
		}
		if (marketingPopupRotationLerp < 1f)
		{
			if (marketingPopupRotationLerp == 0f)
			{
				marketingButtonSemiUI.SemiUISpringShakeY(5f, 2f, 0.3f);
			}
			marketingPopupRotationLerp += Time.deltaTime * 1.5f;
			((Component)marketingPopupSemiUI).transform.localRotation = Quaternion.SlerpUnclamped(Quaternion.Euler(new Vector3(0f, 0f, -15f)), Quaternion.identity, marketingPopupRotationCurve.Evaluate(marketingPopupRotationLerp));
		}
		if (marketingPopupScaleLerp < 1f)
		{
			if (marketingPopupScaleLerp == 0f)
			{
				marketingPopupSound.Play(MenuManager.instance.soundPosition);
			}
			marketingPopupScaleLerp += Time.deltaTime * 3f;
			((Component)marketingPopupSemiUI).transform.localScale = Vector2.op_Implicit(Vector2.LerpUnclamped(Vector2.zero, Vector2.one, marketingPopupScaleCurve.Evaluate(marketingPopupScaleLerp)));
		}
		else
		{
			if (!((Behaviour)marketingPopupSemiUI).enabled)
			{
				((Behaviour)marketingPopupSemiUI).enabled = true;
			}
			MenuSelectableElement menuSelectableElement = marketingPopupButton.menuSelectableElement;
			if (Object.op_Implicit((Object)(object)menuSelectableElement) && !((Selectable)menuSelectableElement).interactable)
			{
				((Selectable)menuSelectableElement).interactable = true;
			}
		}
		if (marketingPopupMouthLerp < 1f)
		{
			marketingPopupMouthLerp += Time.deltaTime * 1.25f;
			marketingPlayerHead.mouthOpenAmount = Mathf.LerpUnclamped(0f, 0.1f, marketingPopupMouthCurve.Evaluate(marketingPopupMouthLerp));
		}
	}

	private CanvasGroup IntroGroupAdd(RectTransform side)
	{
		CanvasGroup val = ((Component)side).gameObject.AddComponent<CanvasGroup>();
		val.interactable = false;
		val.blocksRaycasts = false;
		return val;
	}

	private void IntroGroupUpdate(CanvasGroup group, RectTransform side)
	{
		//IL_0009: Unknown result type (might be due to invalid IL or missing references)
		if (Object.op_Implicit((Object)(object)group) && !(Mathf.Abs(((Transform)side).localPosition.x) > 300f))
		{
			Object.Destroy((Object)(object)group);
			menuPage.interactionBlocked = false;
		}
	}

	public void ButtonEventSinglePlayer()
	{
		SemiFunc.MainMenuSetSingleplayer();
		MenuManager.instance.PageCloseAll();
		MenuManager.instance.PageOpen(MenuPageIndex.Saves);
	}

	public void ButtonEventTutorial()
	{
		DataDirector.instance.TutorialPlayed();
		TutorialDirector.instance.Reset();
		RunManager.instance.ResetProgress();
		RunManager.instance.ChangeLevel(_completedLevel: true, _levelFailed: false, RunManager.ChangeLevelType.Tutorial);
	}

	public void ButtonEventHostGame()
	{
		MenuManager.instance.PageCloseAll();
		((Component)MenuManager.instance.PageOpen(MenuPageIndex.Regions)).GetComponent<MenuPageRegions>().type = MenuPageRegions.Type.HostGame;
	}

	public void ButtonEventJoinGame()
	{
		SteamLobbyManager.instance.OpenSteamOverlayToJoin();
	}

	public void ButtonEventPlayRandom()
	{
		MenuManager.instance.PageCloseAll();
		((Component)MenuManager.instance.PageOpen(MenuPageIndex.Regions)).GetComponent<MenuPageRegions>().type = MenuPageRegions.Type.PlayRandom;
	}

	public void ButtonEventQuit()
	{
		RunManager.instance.skipLoadingUI = true;
		foreach (PlayerAvatar player in GameDirector.instance.PlayerList)
		{
			player.quitApplication = true;
		}
		GameDirector.instance.OutroStart();
		ResultScreenUI.instance.Disable();
	}

	public void ButtonEventSettings()
	{
		MenuManager.instance.PageOpenOnTop(MenuPageIndex.Settings);
	}

	public void ButtonEventChangeColor()
	{
		if (Object.op_Implicit((Object)(object)MetaManager.instance) && MetaManager.instance.saveReady)
		{
			MenuManager.instance.PageOpenOnTop(MenuPageIndex.Cosmetics);
		}
	}

	public void ButtonSocialDiscord()
	{
		Application.OpenURL("https://discord.gg/repo");
	}

	public void ButtonSocialYouTube()
	{
		Application.OpenURL("https://www.youtube.com/@semiwork");
	}

	public void ButtonSocialMarketing()
	{
		if (!((Object)(object)MenuManager.instance.marketingMessage == (Object)null) && !string.IsNullOrWhiteSpace(MenuManager.instance.marketingMessage.link))
		{
			Application.OpenURL(MenuManager.instance.marketingMessage.link);
		}
	}

	public void UpdateMarketingMessage()
	{
		if (!string.IsNullOrWhiteSpace(MenuManager.instance.marketingMessage.title) || !string.IsNullOrWhiteSpace(MenuManager.instance.marketingMessage.message))
		{
			((TMP_Text)marketingTitleText).text = MenuManager.instance.marketingMessage.title ?? "";
			((TMP_Text)marketingMessageText).text = MenuManager.instance.marketingMessage.message ?? "";
		}
	}

	private void InitDebugSaveFile()
	{
		string text = ((Object.op_Implicit((Object)(object)DebugComputerCheck.instance) && !DebugComputerCheck.instance.DebugDisable) ? DebugComputerCheck.instance.SaveFile : "");
		string path = Application.persistentDataPath + "/saves/" + text + "/" + text + ".es3";
		if (!string.IsNullOrEmpty(text) && File.Exists(path))
		{
			StatsManager.instance.LoadGame(text, null);
		}
		else
		{
			StatsManager.instance.SaveFileCreate(text, saveIsDebug: true);
		}
	}

	public void UpdateHighlight()
	{
		//IL_00b3: Unknown result type (might be due to invalid IL or missing references)
		//IL_009d: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b8: Unknown result type (might be due to invalid IL or missing references)
		//IL_00dc: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c6: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e1: Unknown result type (might be due to invalid IL or missing references)
		if (!Object.op_Implicit((Object)(object)customizeHighlightObj))
		{
			return;
		}
		int num = 0;
		for (int i = 0; i < MetaManager.instance.cosmeticAssets.Count; i++)
		{
			if (!MetaManager.instance.cosmeticHistory.Contains(i) && MetaManager.instance.cosmeticUnlocks.Contains(i))
			{
				CosmeticAsset cosmeticAsset = MetaManager.instance.cosmeticAssets[i];
				if (Object.op_Implicit((Object)(object)cosmeticAsset) && cosmeticAsset.prefab.IsValid())
				{
					num++;
				}
			}
		}
		bool flag = num > 0;
		((TMP_Text)customizeHighlightObj.text).text = num.ToString();
		customizeButton.colorNormal = (Color)(flag ? new Color(1f, 0.55f, 0f) : Color.gray);
		customizeButton.colorHover = (Color)(flag ? new Color(1f, 0.9f, 0f) : Color.white);
	}
}
