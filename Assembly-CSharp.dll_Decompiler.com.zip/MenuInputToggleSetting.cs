using UnityEngine;

public class MenuInputToggleSetting : MonoBehaviour
{
	public InputPercentSetting setting;

	public void FetchSetting()
	{
		((Component)this).GetComponent<MenuTwoOptions>().startSettingFetch = InputManager.instance.inputPercentSettings[setting] == 1;
	}

	public void SetOn()
	{
		InputManager.instance.inputPercentSettings[setting] = 1;
	}

	public void SetOff()
	{
		InputManager.instance.inputPercentSettings[setting] = 0;
	}
}
