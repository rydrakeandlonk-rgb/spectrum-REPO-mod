using System;
using System.Collections.Generic;
using Photon.Pun;
using UnityEngine;

public class AnimatronicScare : MonoBehaviour
{
	public bool active = true;

	public bool debug;

	private bool animating;

	private float cooldown;

	private PhotonView photonView;

	private AnimatronicScareTrigger trigger;

	[Space]
	public Sound sound;

	[Space]
	public GameObject particles;

	[Space]
	public Transform headTransform;

	private Light headLight;

	private Material headMaterial;

	public AnimationCurve headMaterialCurve;

	private float headMaterialLerp;

	private static readonly int headMaterialEmission = Shader.PropertyToID("_EmissionColor");

	[Space]
	public List<Transform> partRotationTransforms = new List<Transform>();

	private List<Vector3> partRotations = new List<Vector3>();

	private List<ShakeAnimation> partRotationAnimationsX = new List<ShakeAnimation>();

	private List<ShakeAnimation> partRotationAnimationsY = new List<ShakeAnimation>();

	private List<ShakeAnimation> partRotationAnimationsZ = new List<ShakeAnimation>();

	private List<Transform> partTransforms = new List<Transform>();

	private List<Vector3> partPositions = new List<Vector3>();

	private List<ShakeAnimation> partAnimationsX = new List<ShakeAnimation>();

	private List<ShakeAnimation> partAnimationsY = new List<ShakeAnimation>();

	private List<ShakeAnimation> partAnimationsZ = new List<ShakeAnimation>();

	private void Awake()
	{
		//IL_00a3: Unknown result type (might be due to invalid IL or missing references)
		//IL_0144: Unknown result type (might be due to invalid IL or missing references)
		if (!Application.isEditor)
		{
			debug = false;
		}
		if (Application.isEditor && SemiFunc.Ruben())
		{
			active = false;
			((Behaviour)this).enabled = false;
		}
		photonView = ((Component)this).GetComponent<PhotonView>();
		if (Object.op_Implicit((Object)(object)headTransform))
		{
			headMaterial = ((Renderer)((Component)headTransform).GetComponent<MeshRenderer>()).material;
		}
		headLight = ((Component)this).GetComponentInChildren<Light>(true);
		trigger = ((Component)this).GetComponentInChildren<AnimatronicScareTrigger>(true);
		MeshRenderer[] componentsInChildren = ((Component)this).GetComponentsInChildren<MeshRenderer>(false);
		foreach (MeshRenderer val in componentsInChildren)
		{
			partTransforms.Add(((Component)val).transform);
			partPositions.Add(((Component)val).transform.localPosition);
			partAnimationsX.Add(new ShakeAnimation
			{
				updateFrequency = 0.01f
			});
			partAnimationsY.Add(new ShakeAnimation
			{
				updateFrequency = 0.01f
			});
			partAnimationsZ.Add(new ShakeAnimation
			{
				updateFrequency = 0.01f
			});
		}
		List<Transform> list = new List<Transform>();
		foreach (Transform partRotationTransform in partRotationTransforms)
		{
			if (!Object.op_Implicit((Object)(object)partRotationTransform))
			{
				list.Add(partRotationTransform);
				continue;
			}
			partRotations.Add(partRotationTransform.localEulerAngles);
			partRotationAnimationsX.Add(new ShakeAnimation
			{
				updateFrequency = 0.01f
			});
			partRotationAnimationsY.Add(new ShakeAnimation
			{
				updateFrequency = 0.01f
			});
			partRotationAnimationsZ.Add(new ShakeAnimation
			{
				updateFrequency = 0.01f
			});
		}
		foreach (Transform item in list)
		{
			partRotationTransforms.Remove(item);
		}
	}

	private void Update()
	{
		if (SemiFunc.DebugKeyDown(SemiFunc.User.Axel, (KeyCode)107))
		{
			TriggerSet();
		}
		if (cooldown > 0f)
		{
			cooldown -= Time.deltaTime;
		}
		Animate();
	}

	public void TriggerSet()
	{
		//IL_004a: Unknown result type (might be due to invalid IL or missing references)
		//IL_007b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0081: Unknown result type (might be due to invalid IL or missing references)
		if (!debug)
		{
			if (LevelMusic.instance.timeSinceInterrupted < 30f || Random.Range(0, 100) > 1 || cooldown > 0f)
			{
				return;
			}
			cooldown = 300f;
		}
		EnemyDirector.instance.SetInvestigate(((Component)this).transform.position, 20f);
		if (SemiFunc.IsMultiplayer())
		{
			photonView.RPC("TriggerSetRPC", (RpcTarget)0, Array.Empty<object>());
		}
		else
		{
			TriggerSetRPC();
		}
	}

	[PunRPC]
	private void TriggerSetRPC(PhotonMessageInfo _info = default(PhotonMessageInfo))
	{
		//IL_0000: Unknown result type (might be due to invalid IL or missing references)
		//IL_005a: Unknown result type (might be due to invalid IL or missing references)
		//IL_00cd: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f1: Unknown result type (might be due to invalid IL or missing references)
		//IL_009c: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ac: Unknown result type (might be due to invalid IL or missing references)
		//IL_02a7: Unknown result type (might be due to invalid IL or missing references)
		//IL_02ad: Unknown result type (might be due to invalid IL or missing references)
		if (!SemiFunc.MasterOnlyRPC(_info))
		{
			return;
		}
		animating = true;
		if (Object.op_Implicit((Object)(object)headTransform))
		{
			headMaterialLerp = 0f;
		}
		if (Object.op_Implicit((Object)(object)headLight))
		{
			((Behaviour)headLight).enabled = true;
		}
		if (Object.op_Implicit((Object)(object)headTransform))
		{
			sound.Play(headTransform.position);
		}
		if (Object.op_Implicit((Object)(object)PlayerController.instance) && Object.op_Implicit((Object)(object)trigger) && Vector3.Distance(((Component)PlayerController.instance).transform.position, ((Component)trigger).transform.position) < 5f)
		{
			AudioScare.instance.PlaySoft();
		}
		SemiFunc.CameraShakeDistance(((Component)this).transform.position, 2f, 1f, 5f, 10f);
		SemiFunc.CameraShakeImpactDistance(((Component)this).transform.position, 1f, 0.5f, 5f, 10f);
		foreach (ShakeAnimation item in partAnimationsX)
		{
			item.Set(0.0125f, 0.00025f);
		}
		foreach (ShakeAnimation item2 in partAnimationsY)
		{
			item2.Set(0.0125f, 0.00025f);
		}
		foreach (ShakeAnimation item3 in partAnimationsZ)
		{
			item3.Set(0.0125f, 0.00025f);
		}
		foreach (ShakeAnimation item4 in partRotationAnimationsX)
		{
			item4.Set(5f, 0.5f);
		}
		foreach (ShakeAnimation item5 in partRotationAnimationsY)
		{
			item5.Set(5f, 0.5f);
		}
		foreach (ShakeAnimation item6 in partRotationAnimationsZ)
		{
			item6.Set(5f, 0.5f);
		}
		List<Transform> list = new List<Transform>(partRotationTransforms);
		list.Shuffle();
		int num = 0;
		foreach (Transform item7 in list)
		{
			Object.Destroy((Object)(object)Object.Instantiate<GameObject>(particles, item7.position, item7.rotation, item7), 5f);
			num++;
			if (num >= 3)
			{
				break;
			}
		}
	}

	private void Animate()
	{
		//IL_009d: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c0: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ff: Unknown result type (might be due to invalid IL or missing references)
		//IL_01bb: Unknown result type (might be due to invalid IL or missing references)
		//IL_01de: Unknown result type (might be due to invalid IL or missing references)
		//IL_0201: Unknown result type (might be due to invalid IL or missing references)
		//IL_021d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0289: Unknown result type (might be due to invalid IL or missing references)
		//IL_028e: Unknown result type (might be due to invalid IL or missing references)
		//IL_02a4: Unknown result type (might be due to invalid IL or missing references)
		if (!animating)
		{
			return;
		}
		bool flag = false;
		int num = 0;
		foreach (Transform partTransform in partTransforms)
		{
			partAnimationsX[num].UpdateShake();
			partAnimationsY[num].UpdateShake();
			partAnimationsZ[num].UpdateShake();
			if (!flag && (partAnimationsX[num].IsActive() || partAnimationsY[num].IsActive() || partAnimationsZ[num].IsActive()))
			{
				flag = true;
			}
			partTransform.localPosition = new Vector3(partPositions[num].x + partAnimationsX[num].Get(), partPositions[num].y + partAnimationsY[num].Get(), partPositions[num].z + partAnimationsZ[num].Get());
			num++;
		}
		num = 0;
		foreach (Transform partRotationTransform in partRotationTransforms)
		{
			partRotationAnimationsX[num].UpdateShake();
			partRotationAnimationsY[num].UpdateShake();
			partRotationAnimationsZ[num].UpdateShake();
			if (!flag && (partRotationAnimationsX[num].IsActive() || partRotationAnimationsY[num].IsActive() || partRotationAnimationsZ[num].IsActive()))
			{
				flag = true;
			}
			partRotationTransform.localEulerAngles = new Vector3(partRotations[num].x + partRotationAnimationsX[num].Get(), partRotations[num].y + partRotationAnimationsY[num].Get(), partRotations[num].z + partRotationAnimationsZ[num].Get());
			num++;
		}
		if (headMaterialLerp < 1f)
		{
			flag = true;
			headMaterialLerp += Time.deltaTime * 0.5f;
			if (Object.op_Implicit((Object)(object)headTransform))
			{
				headMaterial.SetColor(headMaterialEmission, Color.Lerp(Color.black, Color.white, headMaterialCurve.Evaluate(headMaterialLerp)));
			}
			if (Object.op_Implicit((Object)(object)headLight))
			{
				headLight.intensity = Mathf.Lerp(0f, 2f, headMaterialCurve.Evaluate(headMaterialLerp));
				if (headMaterialLerp > 1f)
				{
					((Behaviour)headLight).enabled = false;
				}
			}
		}
		if (!flag)
		{
			animating = false;
		}
	}
}
