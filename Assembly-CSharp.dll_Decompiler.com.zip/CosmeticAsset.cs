using System.Collections.Generic;
using System.Threading.Tasks;
using UnityEngine;
using UnityEngine.AddressableAssets;

[CreateAssetMenu(fileName = "Cosmetic - _____", menuName = "Cosmetics/Cosmetic Asset", order = 0)]
public class CosmeticAsset : ScriptableObject
{
	public enum Status
	{
		WIP,
		FirstIteration,
		NeedRevision,
		Finalized
	}

	public Status status;

	public string assetName = "";

	public SemiFunc.CosmeticType type;

	public SemiFunc.Rarity rarity;

	[Space]
	public PrefabRef prefab;

	public List<CosmeticCustomCondition.Type> customTypeList;

	[Space]
	public bool tintable;

	public SemiColor defaultColor;

	internal Sprite icon;

	public AssetReferenceSprite iconRef;

	public const string IconOutputFolder = "Assets/Icons/Cosmetics";

	internal string assetId = "";

	public Sprite GenerateIcon()
	{
		//IL_000b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0010: Unknown result type (might be due to invalid IL or missing references)
		//IL_0037: Unknown result type (might be due to invalid IL or missing references)
		GameObject val = Object.Instantiate<GameObject>(prefab.Prefab, Vector3.zero, Quaternion.identity);
		try
		{
			PrepareIcon(val);
			val.transform.position = new Vector3(-1000f, -1000f, -1000f);
			SemiIconMaker componentInChildren = val.GetComponentInChildren<SemiIconMaker>(true);
			if (Object.op_Implicit((Object)(object)componentInChildren))
			{
				icon = componentInChildren.CreateIconFromRenderTexture(null);
			}
			return icon;
		}
		finally
		{
			DestroyIconObject(val);
		}
	}

	internal async Task<Sprite> GenerateIconAsync(Object _owner)
	{
		if (!Object.op_Implicit(_owner) || prefab == null || !prefab.IsValid())
		{
			return null;
		}
		GameObject _spawnedCosmetic = Object.Instantiate<GameObject>(prefab.Prefab, Vector3.zero, Quaternion.identity);
		Sprite val = null;
		try
		{
			PrepareIcon(_spawnedCosmetic);
			_spawnedCosmetic.transform.position = new Vector3(-1000f, -1000f, -1000f);
			SemiIconMaker componentInChildren = _spawnedCosmetic.GetComponentInChildren<SemiIconMaker>(true);
			if (Object.op_Implicit((Object)(object)componentInChildren))
			{
				val = await componentInChildren.CreateIconAsync(null, () => Object.op_Implicit(_owner) && Object.op_Implicit((Object)(object)_spawnedCosmetic));
			}
			if (!Object.op_Implicit(_owner) && Object.op_Implicit((Object)(object)val))
			{
				Object.Destroy((Object)(object)val.texture);
				Object.Destroy((Object)(object)val);
				return null;
			}
			return val;
		}
		finally
		{
			DestroyIconObject(_spawnedCosmetic);
		}
	}

	public void PrepareIcon(GameObject _spawnedCosmetic)
	{
		MetaManager instance = MetaManager.instance;
		Cosmetic component = _spawnedCosmetic.GetComponent<Cosmetic>();
		if (!Object.op_Implicit((Object)(object)component))
		{
			return;
		}
		component.iconCreation = true;
		component.cosmeticAsset = this;
		component.cosmeticTypeAsset = instance.cosmeticTypeAssets[(int)type];
		component.type = type;
		component.rarity = rarity;
		if (!Object.op_Implicit((Object)(object)defaultColor))
		{
			return;
		}
		int albedoColor = Shader.PropertyToID("_AlbedoColor");
		int emissionColor = Shader.PropertyToID("_EmissionColor");
		int fresnelColor = Shader.PropertyToID("_FresnelColor");
		int num = instance.colors.IndexOf(defaultColor);
		if (num != -1)
		{
			PlayerMaterial[] componentsInChildren = ((Component)component).GetComponentsInChildren<PlayerMaterial>(true);
			foreach (PlayerMaterial obj in componentsInChildren)
			{
				obj.Setup();
				obj.ColorSet(albedoColor, emissionColor, fresnelColor, num);
			}
		}
	}

	public static void DestroyIconObject(GameObject _spawnedCosmetic)
	{
		if (Object.op_Implicit((Object)(object)_spawnedCosmetic))
		{
			PlayerMaterial[] componentsInChildren = _spawnedCosmetic.GetComponentsInChildren<PlayerMaterial>(true);
			for (int i = 0; i < componentsInChildren.Length; i++)
			{
				componentsInChildren[i].DestroyMaterialInstance();
			}
			_spawnedCosmetic.SetActive(false);
			Object.Destroy((Object)(object)_spawnedCosmetic);
		}
	}

	internal Color GetRarityColor()
	{
		//IL_002b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0030: Unknown result type (might be due to invalid IL or missing references)
		//IL_0046: Unknown result type (might be due to invalid IL or missing references)
		//IL_004b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0062: Unknown result type (might be due to invalid IL or missing references)
		//IL_0067: Unknown result type (might be due to invalid IL or missing references)
		//IL_007d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0082: Unknown result type (might be due to invalid IL or missing references)
		//IL_0088: Unknown result type (might be due to invalid IL or missing references)
		return rarity switch
		{
			SemiFunc.Rarity.Common => Color32.op_Implicit(new Color32((byte)0, byte.MaxValue, (byte)2, byte.MaxValue)), 
			SemiFunc.Rarity.Uncommon => Color32.op_Implicit(new Color32((byte)0, (byte)195, byte.MaxValue, byte.MaxValue)), 
			SemiFunc.Rarity.Rare => Color32.op_Implicit(new Color32(byte.MaxValue, (byte)110, (byte)244, byte.MaxValue)), 
			SemiFunc.Rarity.UltraRare => Color32.op_Implicit(new Color32(byte.MaxValue, (byte)199, (byte)0, byte.MaxValue)), 
			_ => Color.white, 
		};
	}

	internal Color GetDefaultColor()
	{
		//IL_0019: Unknown result type (might be due to invalid IL or missing references)
		//IL_000d: Unknown result type (might be due to invalid IL or missing references)
		if (!Object.op_Implicit((Object)(object)defaultColor))
		{
			return Color.white;
		}
		return defaultColor.color;
	}

	internal Color GetStatusColor()
	{
		//IL_002c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0031: Unknown result type (might be due to invalid IL or missing references)
		//IL_0047: Unknown result type (might be due to invalid IL or missing references)
		//IL_004c: Unknown result type (might be due to invalid IL or missing references)
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0064: Unknown result type (might be due to invalid IL or missing references)
		//IL_0076: Unknown result type (might be due to invalid IL or missing references)
		//IL_007b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0081: Unknown result type (might be due to invalid IL or missing references)
		return status switch
		{
			Status.WIP => Color32.op_Implicit(new Color32(byte.MaxValue, (byte)16, (byte)0, byte.MaxValue)), 
			Status.FirstIteration => Color32.op_Implicit(new Color32(byte.MaxValue, (byte)233, (byte)0, byte.MaxValue)), 
			Status.NeedRevision => Color32.op_Implicit(new Color32(byte.MaxValue, (byte)84, (byte)0, byte.MaxValue)), 
			Status.Finalized => Color32.op_Implicit(new Color32((byte)0, byte.MaxValue, (byte)2, byte.MaxValue)), 
			_ => Color.white, 
		};
	}

	private IEnumerable<CosmeticCustomCondition.Type> GetCosmeticCustomConditionTypes()
	{
		return CosmeticCustomCondition.GetTypes();
	}

	private IEnumerable<SemiFunc.CosmeticType> GetCosmeticTypes()
	{
		return SemiFunc.CosmeticGetTypes();
	}
}
