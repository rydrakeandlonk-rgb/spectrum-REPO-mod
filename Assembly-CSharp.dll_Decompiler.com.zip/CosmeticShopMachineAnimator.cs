using System.Collections.Generic;
using UnityEngine;

public class CosmeticShopMachineAnimator : MonoBehaviour
{
	public CosmeticShopMachine controller;

	private Animator animator;

	private float shakeLayerStrength = 0.3f;

	private float shakeLayerImpulseTimer;

	private int animArrowsActive = Animator.StringToHash("ArrowsActive");

	private int animTokenActive = Animator.StringToHash("TokenActive");

	private int animConfettiCannonActive = Animator.StringToHash("ConfettiCannonActive");

	private int animPlateOn = Animator.StringToHash("PlateOn");

	private int animPlateOnImpulse = Animator.StringToHash("PlateOnImpulse");

	public List<GameObject> tokenObjects;

	public List<GameObject> tokenObjectsInserted;

	private bool tokenActive = true;

	internal bool tokenIntroDone;

	internal bool tokenImpactDone;

	[Space]
	public Transform tokenMeshFollowTransform;

	public Transform tokenMeshFollowTransformParent;

	public Transform tokenMeshTargetTransform;

	[Space]
	public AnimationCurve tokenMeshFollowCurve;

	private float tokenMeshFollowLerp;

	[Space]
	public Light tokenLight;

	public List<Color> tokenLightColors;

	public List<MeshRenderer> arrowRenderers;

	public AnimationCurve arrowEmissionCurve;

	private float arrowEmissionLerp;

	private Material arrowMaterial;

	private int shaderAlbedoColor = Shader.PropertyToID("_Color");

	private int shaderEmissionColor = Shader.PropertyToID("_EmissionColor");

	private Color arrowEmissionDefault;

	public List<MeshRenderer> plateEmissionRenderers;

	public AnimationCurve plateEmissionCurveIntro;

	public AnimationCurve plateEmissionCurveOutro;

	public List<Light> plateLights;

	private List<float> plateLightsIntensityDefault = new List<float>();

	private float plateEmissionLerp = 0.1f;

	private float plateLightLerp = 0.1f;

	private Material plateEmissionMaterial;

	private Color plateEmissionDefault;

	private float plateOnTimer;

	private bool platePlayerTarget;

	private bool platePlayerTargetPrevious;

	private PlayerAvatar platePlayerTargetAvatar;

	public List<LineRenderer> grabBeamRenderers;

	public Transform grabBeamOrigin;

	private bool grabBeamActive = true;

	private Vector3 grabBeamTargetPosition;

	private int grabBeamCount = 20;

	private List<Material> grabBeamMaterials = new List<Material>();

	public Transform grabBeamMidTransform;

	public SpringVector3 grabBeamMidSpring;

	[Space]
	public AnimationCurve grabBeamScaleIntro;

	public AnimationCurve grabBeamScaleOutro;

	private float grabBeamScaleLerp = 0.1f;

	private float grabBeamScaleTarget = 1f;

	[Space]
	public List<Transform> grabOrbTransforms;

	private List<Material> grabOrbMaterials = new List<Material>();

	private List<Transform> grabOrbChildren = new List<Transform>();

	private List<Vector3> grabOrbChildrenScale = new List<Vector3>();

	private List<Material> grabBeamAllMaterials = new List<Material>();

	private List<Color> grabBeamAllMaterialsDefaultAlbedo = new List<Color>();

	private List<Color> grabBeamAllMaterialsDefaultEmission = new List<Color>();

	[Space]
	public List<ParticleSystem> grabOrbParticles;

	public ParticleSystem tokenParticleSparkles;

	public List<Gradient> tokenParticleSparklesColors;

	[Space]
	public List<CosmeticShopMachineConfetti> confettis;

	public SpringQuaternionSystem springAntenna01;

	public SpringQuaternionSystem springAntenna02;

	public Sound soundBaseIdleLoop;

	public Sound soundBaseShakeLoop;

	[Space]
	public Transform soundBaseArrowsPosition;

	public Sound soundBaseArrowsBlinkStart;

	public Sound soundBaseArrowsBlinkStop;

	[Space]
	public Transform soundScreenPosition;

	public Sound soundScreensSpeedUp;

	public Sound soundScreensStop;

	[Space]
	public Transform soundTokenPosition;

	public Sound soundTokenSpawn;

	public Sound soundTokenTwirl;

	public Sound soundTokenFly;

	public Sound soundTokenImpact;

	public Sound soundTokenInsert;

	[Space]
	public Transform soundPlatePosition;

	public Sound soundPlateOn;

	public Sound soundPlateOff;

	[Space]
	public Sound soundScreenIconSwitchIntro;

	public Sound soundScreenIconSwitchOutro;

	[Space]
	public Sound soundScreenCurrencyReward;

	[Space]
	public Sound soundScreenCosmeticIntro;

	public Sound soundScreenCosmeticOutro;

	[Space]
	public Sound soundScreenCosmeticFrameIntro;

	public Sound soundScreenCosmeticFrameOutro;

	[Space]
	public Sound soundScreenCosmeticRewardCommon;

	public Sound soundScreenCosmeticRewardUncommon;

	public Sound soundScreenCosmeticRewardRare;

	public Sound soundScreenCosmeticRewardUltraRare;

	[Space]
	public Sound soundCannonsShoot;

	public Sound soundCannonsIntro;

	public Sound soundCannonsOutro;

	private void Awake()
	{
		//IL_007c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0081: Unknown result type (might be due to invalid IL or missing references)
		//IL_00bf: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c4: Unknown result type (might be due to invalid IL or missing references)
		//IL_01fc: Unknown result type (might be due to invalid IL or missing references)
		//IL_026f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0287: Unknown result type (might be due to invalid IL or missing references)
		animator = ((Component)this).GetComponent<Animator>();
		animator.keepAnimatorStateOnDisable = true;
		foreach (MeshRenderer arrowRenderer in arrowRenderers)
		{
			if ((Object)(object)arrowMaterial == (Object)null)
			{
				arrowMaterial = ((Renderer)arrowRenderer).material;
			}
			else
			{
				((Renderer)arrowRenderer).material = arrowMaterial;
			}
		}
		arrowEmissionDefault = arrowMaterial.GetColor(shaderEmissionColor);
		arrowEmissionDefault.a = 1f;
		tokenMeshFollowTransform.parent = tokenMeshFollowTransformParent;
		plateEmissionDefault = ((Renderer)plateEmissionRenderers[0]).material.GetColor(shaderEmissionColor);
		plateEmissionDefault.a = 1f;
		foreach (Light plateLight in plateLights)
		{
			plateLightsIntensityDefault.Add(plateLight.intensity);
			plateLight.intensity = 0f;
		}
		foreach (LineRenderer grabBeamRenderer in grabBeamRenderers)
		{
			grabBeamRenderer.positionCount = grabBeamCount;
			grabBeamMaterials.Add(((Renderer)grabBeamRenderer).material);
			grabBeamAllMaterials.Add(((Renderer)grabBeamRenderer).material);
		}
		int num = 0;
		foreach (Transform grabOrbTransform in grabOrbTransforms)
		{
			Renderer[] componentsInChildren = ((Component)grabOrbTransform).GetComponentsInChildren<Renderer>();
			foreach (Renderer val in componentsInChildren)
			{
				if (!grabOrbParticles.Contains(((Component)val).GetComponent<ParticleSystem>()))
				{
					grabOrbMaterials.Add(val.material);
					grabOrbChildren.Add(((Component)val).transform);
					grabOrbChildrenScale.Add(((Component)val).transform.localScale);
					if (num != 0)
					{
						grabBeamAllMaterials.Add(val.material);
					}
				}
			}
			num++;
		}
		foreach (Material grabBeamAllMaterial in grabBeamAllMaterials)
		{
			grabBeamAllMaterialsDefaultAlbedo.Add(grabBeamAllMaterial.GetColor(shaderAlbedoColor));
			grabBeamAllMaterialsDefaultEmission.Add(grabBeamAllMaterial.GetColor(shaderEmissionColor));
		}
	}

	private void Update()
	{
		ShakeLogic();
		ArrowLogic();
		SpringLogic();
		TokenLogic();
		ConfettiCannonLogic();
		GrabBeamLogic();
		PlayerEyesLogic();
		PlateLogic();
		AudioLogic();
	}

	private void ShakeLogic()
	{
		if (shakeLayerImpulseTimer > 0f)
		{
			shakeLayerStrength = Mathf.Lerp(shakeLayerStrength, 5f, 20f * Time.deltaTime);
			shakeLayerImpulseTimer -= Time.deltaTime;
		}
		else if (controller.screenSpinningFast)
		{
			shakeLayerStrength = Mathf.Lerp(shakeLayerStrength, 3f, 5f * Time.deltaTime);
		}
		else
		{
			shakeLayerStrength = Mathf.Lerp(shakeLayerStrength, 0.5f, 2f * Time.deltaTime);
		}
		animator.SetLayerWeight(1, shakeLayerStrength);
	}

	private void ArrowLogic()
	{
		//IL_0064: Unknown result type (might be due to invalid IL or missing references)
		//IL_006a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0074: Unknown result type (might be due to invalid IL or missing references)
		//IL_007a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0090: Unknown result type (might be due to invalid IL or missing references)
		if (controller.stateCurrent == CosmeticShopMachine.State.Idle)
		{
			animator.SetBool(animArrowsActive, true);
		}
		else
		{
			animator.SetBool(animArrowsActive, false);
		}
		if (arrowEmissionLerp < 1f)
		{
			arrowEmissionLerp += 1f * Time.deltaTime;
			arrowMaterial.SetColor(shaderEmissionColor, Color.Lerp(Color.Lerp(Color.black, arrowEmissionDefault, 0.5f), arrowEmissionDefault, arrowEmissionCurve.Evaluate(arrowEmissionLerp)));
		}
	}

	private void SpringLogic()
	{
		springAntenna01.UpdateWorldSpace();
		springAntenna02.UpdateWorldSpace();
	}

	private void TokenLogic()
	{
		//IL_0095: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e1: Unknown result type (might be due to invalid IL or missing references)
		//IL_010a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0254: Unknown result type (might be due to invalid IL or missing references)
		//IL_025f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0275: Unknown result type (might be due to invalid IL or missing references)
		//IL_0286: Unknown result type (might be due to invalid IL or missing references)
		//IL_0291: Unknown result type (might be due to invalid IL or missing references)
		//IL_02a7: Unknown result type (might be due to invalid IL or missing references)
		//IL_02c2: Unknown result type (might be due to invalid IL or missing references)
		if (controller.stateCurrent == CosmeticShopMachine.State.Interact || controller.stateCurrent == CosmeticShopMachine.State.FetchReward || controller.stateCurrent == CosmeticShopMachine.State.FetchRewardDone || controller.stateCurrent == CosmeticShopMachine.State.TokenOutro)
		{
			if (!tokenActive)
			{
				tokenObjects[(int)controller.interactingRarity].SetActive(true);
				tokenObjectsInserted[(int)controller.interactingRarity].SetActive(true);
				tokenLight.color = tokenLightColors[(int)controller.interactingRarity];
				if (Object.op_Implicit((Object)(object)controller.interactingPlayer))
				{
					Transform headLookAtTransform = controller.interactingPlayer.playerAvatarVisuals.headLookAtTransform;
					GameDirector.instance.CameraShake.ShakeDistance(5f, 3f, 5f, headLookAtTransform.position, 0.1f);
					GameDirector.instance.CameraImpact.ShakeDistance(2f, 3f, 5f, headLookAtTransform.position, 0.05f);
				}
				tokenActive = true;
			}
		}
		else if (tokenActive)
		{
			foreach (GameObject tokenObject in tokenObjects)
			{
				tokenObject.SetActive(false);
			}
			foreach (GameObject item in tokenObjectsInserted)
			{
				item.SetActive(false);
			}
			tokenActive = false;
			tokenIntroDone = false;
			tokenImpactDone = false;
		}
		if (controller.stateCurrent == CosmeticShopMachine.State.Interact || controller.stateCurrent == CosmeticShopMachine.State.FetchReward || controller.stateCurrent == CosmeticShopMachine.State.FetchRewardDone)
		{
			animator.SetBool(animTokenActive, true);
		}
		else
		{
			animator.SetBool(animTokenActive, false);
		}
		if (tokenActive)
		{
			tokenMeshFollowLerp += 1f * Time.deltaTime;
			Transform val = (Object.op_Implicit((Object)(object)controller.interactingPlayer) ? controller.interactingPlayer.playerAvatarVisuals.headLookAtTransform : tokenMeshTargetTransform);
			tokenMeshFollowTransform.position = Vector3.LerpUnclamped(val.position, tokenMeshTargetTransform.position, tokenMeshFollowCurve.Evaluate(tokenMeshFollowLerp));
			tokenMeshFollowTransform.rotation = Quaternion.LerpUnclamped(val.rotation, tokenMeshTargetTransform.rotation, tokenMeshFollowCurve.Evaluate(tokenMeshFollowLerp));
			tokenMeshFollowTransform.localScale = tokenMeshTargetTransform.parent.localScale;
		}
		else
		{
			tokenMeshFollowLerp = 0f;
		}
	}

	private void ConfettiCannonLogic()
	{
		if (controller.stateCurrent == CosmeticShopMachine.State.RewardCosmeticIntro)
		{
			animator.SetBool(animConfettiCannonActive, true);
		}
		else
		{
			animator.SetBool(animConfettiCannonActive, false);
		}
	}

	private void PlateLogic()
	{
		//IL_015e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0164: Unknown result type (might be due to invalid IL or missing references)
		//IL_017a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0088: Unknown result type (might be due to invalid IL or missing references)
		//IL_008e: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a4: Unknown result type (might be due to invalid IL or missing references)
		bool flag = false;
		if (plateOnTimer > 0f)
		{
			if (platePlayerTarget)
			{
				flag = true;
			}
			plateOnTimer -= Time.deltaTime;
			animator.SetBool(animPlateOn, true);
			if (plateEmissionLerp < 1f)
			{
				plateEmissionLerp += 2f * Time.deltaTime;
				foreach (MeshRenderer plateEmissionRenderer in plateEmissionRenderers)
				{
					((Renderer)plateEmissionRenderer).material.SetColor(shaderEmissionColor, Color.Lerp(Color.black, plateEmissionDefault, plateEmissionCurveIntro.Evaluate(plateEmissionLerp)));
				}
				plateLights[0].intensity = Mathf.LerpUnclamped(0f, plateLightsIntensityDefault[0], plateEmissionCurveIntro.Evaluate(plateEmissionLerp));
			}
		}
		else
		{
			animator.SetBool(animPlateOn, false);
			if (plateEmissionLerp > 0f)
			{
				plateEmissionLerp -= 2f * Time.deltaTime;
				foreach (MeshRenderer plateEmissionRenderer2 in plateEmissionRenderers)
				{
					((Renderer)plateEmissionRenderer2).material.SetColor(shaderEmissionColor, Color.Lerp(Color.black, plateEmissionDefault, plateEmissionCurveOutro.Evaluate(plateEmissionLerp)));
				}
				plateLights[0].intensity = Mathf.LerpUnclamped(0f, plateLightsIntensityDefault[0], plateEmissionCurveOutro.Evaluate(plateEmissionLerp));
			}
		}
		if (flag)
		{
			if (plateLightLerp < 1f)
			{
				plateLightLerp += 2f * Time.deltaTime;
				plateLights[1].intensity = Mathf.LerpUnclamped(0f, plateLightsIntensityDefault[1], plateEmissionCurveIntro.Evaluate(plateLightLerp));
			}
		}
		else if (plateLightLerp > 0f)
		{
			plateLightLerp -= 2f * Time.deltaTime;
			plateLights[1].intensity = Mathf.LerpUnclamped(0f, plateLightsIntensityDefault[1], plateEmissionCurveOutro.Evaluate(plateLightLerp));
		}
	}

	public void PlateSet(PlayerAvatar _playerTarget)
	{
		plateOnTimer = 0.1f;
		if (Object.op_Implicit((Object)(object)_playerTarget))
		{
			platePlayerTargetAvatar = _playerTarget;
			platePlayerTarget = true;
		}
		else
		{
			platePlayerTarget = false;
		}
	}

	private void GrabBeamLogic()
	{
		//IL_0582: Unknown result type (might be due to invalid IL or missing references)
		//IL_0587: Unknown result type (might be due to invalid IL or missing references)
		//IL_056f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0574: Unknown result type (might be due to invalid IL or missing references)
		//IL_05b7: Unknown result type (might be due to invalid IL or missing references)
		//IL_05c2: Unknown result type (might be due to invalid IL or missing references)
		//IL_05c8: Unknown result type (might be due to invalid IL or missing references)
		//IL_05cd: Unknown result type (might be due to invalid IL or missing references)
		//IL_05d2: Unknown result type (might be due to invalid IL or missing references)
		//IL_0422: Unknown result type (might be due to invalid IL or missing references)
		//IL_0429: Unknown result type (might be due to invalid IL or missing references)
		//IL_042e: Unknown result type (might be due to invalid IL or missing references)
		//IL_044a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0338: Unknown result type (might be due to invalid IL or missing references)
		//IL_033d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0344: Unknown result type (might be due to invalid IL or missing references)
		//IL_035a: Unknown result type (might be due to invalid IL or missing references)
		//IL_01ff: Unknown result type (might be due to invalid IL or missing references)
		//IL_0210: Unknown result type (might be due to invalid IL or missing references)
		//IL_0221: Unknown result type (might be due to invalid IL or missing references)
		//IL_0232: Unknown result type (might be due to invalid IL or missing references)
		//IL_0242: Unknown result type (might be due to invalid IL or missing references)
		//IL_024e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0253: Unknown result type (might be due to invalid IL or missing references)
		//IL_025d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0262: Unknown result type (might be due to invalid IL or missing references)
		//IL_026b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0278: Unknown result type (might be due to invalid IL or missing references)
		//IL_0190: Unknown result type (might be due to invalid IL or missing references)
		//IL_01a7: Unknown result type (might be due to invalid IL or missing references)
		//IL_0641: Unknown result type (might be due to invalid IL or missing references)
		//IL_0689: Unknown result type (might be due to invalid IL or missing references)
		//IL_06b2: Unknown result type (might be due to invalid IL or missing references)
		//IL_06b8: Unknown result type (might be due to invalid IL or missing references)
		//IL_06c2: Unknown result type (might be due to invalid IL or missing references)
		//IL_06c7: Unknown result type (might be due to invalid IL or missing references)
		//IL_06c9: Unknown result type (might be due to invalid IL or missing references)
		//IL_06cb: Unknown result type (might be due to invalid IL or missing references)
		//IL_06e0: Unknown result type (might be due to invalid IL or missing references)
		//IL_06ea: Unknown result type (might be due to invalid IL or missing references)
		//IL_06ef: Unknown result type (might be due to invalid IL or missing references)
		//IL_06f4: Unknown result type (might be due to invalid IL or missing references)
		//IL_06f6: Unknown result type (might be due to invalid IL or missing references)
		//IL_06f8: Unknown result type (might be due to invalid IL or missing references)
		//IL_070d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0717: Unknown result type (might be due to invalid IL or missing references)
		//IL_071c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0721: Unknown result type (might be due to invalid IL or missing references)
		//IL_072f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0736: Unknown result type (might be due to invalid IL or missing references)
		//IL_0752: Unknown result type (might be due to invalid IL or missing references)
		//IL_0769: Unknown result type (might be due to invalid IL or missing references)
		//IL_0797: Unknown result type (might be due to invalid IL or missing references)
		//IL_079c: Unknown result type (might be due to invalid IL or missing references)
		//IL_079e: Unknown result type (might be due to invalid IL or missing references)
		//IL_07c6: Unknown result type (might be due to invalid IL or missing references)
		//IL_07ee: Unknown result type (might be due to invalid IL or missing references)
		//IL_0816: Unknown result type (might be due to invalid IL or missing references)
		if (platePlayerTarget != platePlayerTargetPrevious)
		{
			grabBeamActive = false;
			platePlayerTargetPrevious = platePlayerTarget;
		}
		if (plateOnTimer > 0f && (platePlayerTarget || !tokenImpactDone))
		{
			if (!grabBeamActive)
			{
				grabBeamActive = true;
				animator.SetTrigger(animPlateOnImpulse);
				foreach (LineRenderer grabBeamRenderer in grabBeamRenderers)
				{
					((Renderer)grabBeamRenderer).enabled = true;
				}
				((Component)grabOrbTransforms[0]).gameObject.SetActive(true);
				grabOrbParticles[0].Play();
				if (platePlayerTarget && Object.op_Implicit((Object)(object)controller.interactingPlayer) && (!controller.interactingPlayer.isLocal || controller.interactingPlayer.playerAvatarVisuals.ShowSelfCheck()))
				{
					((Component)grabOrbTransforms[1]).gameObject.SetActive(true);
					grabOrbParticles[1].Play();
				}
				else
				{
					((Component)grabOrbTransforms[1]).gameObject.SetActive(false);
					grabOrbParticles[1].Stop();
				}
				if (platePlayerTarget)
				{
					grabBeamScaleTarget = 1f;
					int num = 0;
					foreach (Material grabBeamAllMaterial in grabBeamAllMaterials)
					{
						grabBeamAllMaterial.SetColor(shaderAlbedoColor, grabBeamAllMaterialsDefaultAlbedo[num]);
						grabBeamAllMaterial.SetColor(shaderEmissionColor, grabBeamAllMaterialsDefaultEmission[num]);
						num++;
					}
				}
				else
				{
					grabBeamScaleTarget = 0.5f;
					int num2 = 0;
					foreach (Material grabBeamAllMaterial2 in grabBeamAllMaterials)
					{
						Color val = new Color(grabBeamAllMaterialsDefaultAlbedo[num2].r, grabBeamAllMaterialsDefaultAlbedo[num2].g, grabBeamAllMaterialsDefaultAlbedo[num2].b, grabBeamAllMaterialsDefaultAlbedo[num2].a * 0.5f);
						Color val2 = Color.Lerp(grabBeamAllMaterialsDefaultEmission[num2], Color.black, 0.5f);
						grabBeamAllMaterial2.SetColor(shaderAlbedoColor, val);
						grabBeamAllMaterial2.SetColor(shaderEmissionColor, val2);
						num2++;
					}
				}
			}
			if (grabBeamScaleLerp < 1f)
			{
				grabBeamScaleLerp += 2f * Time.deltaTime;
				foreach (LineRenderer grabBeamRenderer2 in grabBeamRenderers)
				{
					grabBeamRenderer2.widthMultiplier = Mathf.LerpUnclamped(0f, grabBeamScaleTarget, grabBeamScaleIntro.Evaluate(grabBeamScaleLerp));
				}
				float num3 = 1f;
				foreach (Transform grabOrbTransform in grabOrbTransforms)
				{
					grabOrbTransform.localScale = Vector3.LerpUnclamped(Vector3.zero, Vector3.one * num3, grabBeamScaleIntro.Evaluate(grabBeamScaleLerp));
					num3 = grabBeamScaleTarget;
				}
			}
		}
		else if (grabBeamActive)
		{
			grabBeamScaleLerp -= 2f * Time.deltaTime;
			foreach (LineRenderer grabBeamRenderer3 in grabBeamRenderers)
			{
				grabBeamRenderer3.widthMultiplier = Mathf.LerpUnclamped(grabBeamScaleTarget, 0f, grabBeamScaleOutro.Evaluate(1f - grabBeamScaleLerp));
			}
			float num4 = 1f;
			foreach (Transform grabOrbTransform2 in grabOrbTransforms)
			{
				grabOrbTransform2.localScale = Vector3.LerpUnclamped(Vector3.one * num4, Vector3.zero, grabBeamScaleOutro.Evaluate(1f - grabBeamScaleLerp));
				num4 = grabBeamScaleTarget;
			}
			if (grabBeamScaleLerp <= 0f)
			{
				grabBeamScaleLerp = 0f;
				grabBeamActive = false;
				foreach (LineRenderer grabBeamRenderer4 in grabBeamRenderers)
				{
					((Renderer)grabBeamRenderer4).enabled = false;
				}
				foreach (Transform grabOrbTransform3 in grabOrbTransforms)
				{
					((Component)grabOrbTransform3).gameObject.SetActive(false);
				}
				foreach (ParticleSystem grabOrbParticle in grabOrbParticles)
				{
					grabOrbParticle.Stop();
				}
			}
		}
		if (!(grabBeamScaleLerp > 0f))
		{
			return;
		}
		if (platePlayerTarget)
		{
			if (Object.op_Implicit((Object)(object)platePlayerTargetAvatar))
			{
				grabBeamTargetPosition = platePlayerTargetAvatar.tumble.physGrabObject.centerPoint;
			}
		}
		else
		{
			grabBeamTargetPosition = tokenMeshFollowTransform.position;
		}
		Vector3[] array = new Vector3[grabBeamCount];
		for (int i = 0; i < grabBeamCount; i++)
		{
			float t = (float)i / (float)grabBeamCount;
			array[i] = SemiFunc.CalculateBezierPoint(t, grabBeamOrigin.position, grabBeamMidTransform.position, grabBeamTargetPosition);
		}
		foreach (LineRenderer grabBeamRenderer5 in grabBeamRenderers)
		{
			grabBeamRenderer5.SetPositions(array);
		}
		foreach (Material grabBeamMaterial in grabBeamMaterials)
		{
			grabBeamMaterial.mainTextureOffset = new Vector2(Time.time * -2f, 0f);
		}
		foreach (Material grabOrbMaterial in grabOrbMaterials)
		{
			grabOrbMaterial.mainTextureOffset = new Vector2(Time.time * -2f, 0f);
		}
		Vector3 val3 = Vector3.Lerp(grabBeamOrigin.position, grabBeamTargetPosition, 0.5f);
		val3 += Vector3.forward * Mathf.Sin(Time.time * 10f) * 0.05f;
		val3 += Vector3.right * Mathf.Sin(Time.time * 5f) * 0.05f;
		grabBeamMidTransform.position = SemiFunc.SpringVector3Get(grabBeamMidSpring, val3);
		grabOrbTransforms[0].position = grabBeamOrigin.position;
		grabOrbTransforms[1].position = grabBeamTargetPosition;
		int num5 = 0;
		foreach (Transform grabOrbChild in grabOrbChildren)
		{
			Vector3 val4 = grabOrbChildrenScale[num5];
			grabOrbChild.localScale = new Vector3(val4.x + Mathf.Sin(Time.time * 10f + (float)num5 * 5f) * 0.03f, val4.y + Mathf.Sin(Time.time * 5f + (float)num5 * 15f) * 0.03f, val4.z + Mathf.Sin(Time.time * 15f + (float)num5 * 20f) * 0.03f);
			num5++;
		}
	}

	private void PlayerEyesLogic()
	{
		//IL_0000: Unknown result type (might be due to invalid IL or missing references)
		//IL_0005: Unknown result type (might be due to invalid IL or missing references)
		//IL_0036: Unknown result type (might be due to invalid IL or missing references)
		//IL_003b: Unknown result type (might be due to invalid IL or missing references)
		//IL_005c: Unknown result type (might be due to invalid IL or missing references)
		//IL_005d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0056: Unknown result type (might be due to invalid IL or missing references)
		//IL_005b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0084: Unknown result type (might be due to invalid IL or missing references)
		//IL_008f: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a1: Unknown result type (might be due to invalid IL or missing references)
		Vector3 val = Vector3.zero;
		if (controller.stateCurrent == CosmeticShopMachine.State.Interact || controller.stateCurrent == CosmeticShopMachine.State.FetchReward || controller.stateCurrent == CosmeticShopMachine.State.FetchRewardDone)
		{
			val = tokenMeshFollowTransform.position;
		}
		else if (controller.stateCurrent != CosmeticShopMachine.State.Idle)
		{
			val = controller.screenSpinTransform.position;
		}
		if (!(val != Vector3.zero))
		{
			return;
		}
		foreach (PlayerAvatar item in SemiFunc.PlayerGetList())
		{
			if (Vector3.Distance(((Component)item).transform.position, ((Component)this).transform.position) < 5f)
			{
				SemiFunc.PlayerEyesOverride(item, val, 0.5f, ((Component)this).gameObject);
			}
		}
	}

	private void AudioLogic()
	{
		soundBaseIdleLoop.PlayLoop(playing: true, 1f, 1f);
		float num = shakeLayerStrength / 5f;
		soundBaseShakeLoop.PlayLoop(num > 0.25f, 5f, 0.5f, 1f, Mathf.Min(1f, num));
	}

	public void EventArrowLightStart()
	{
		//IL_0017: Unknown result type (might be due to invalid IL or missing references)
		arrowEmissionLerp = 0f;
		soundBaseArrowsBlinkStart.Play(soundBaseArrowsPosition.position);
	}

	public void EventArrowLightStop()
	{
		//IL_000c: Unknown result type (might be due to invalid IL or missing references)
		soundBaseArrowsBlinkStop.Play(soundBaseArrowsPosition.position);
	}

	public void TokenParticlesStart()
	{
		//IL_000c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0040: Unknown result type (might be due to invalid IL or missing references)
		//IL_0045: Unknown result type (might be due to invalid IL or missing references)
		//IL_005e: Unknown result type (might be due to invalid IL or missing references)
		((Component)soundTokenSpawn.Play(soundTokenPosition.position)).transform.SetParent(soundTokenPosition);
		ColorOverLifetimeModule colorOverLifetime = tokenParticleSparkles.colorOverLifetime;
		colorOverLifetime.color = MinMaxGradient.op_Implicit(tokenParticleSparklesColors[(int)controller.interactingRarity]);
		tokenParticleSparkles.Play();
	}

	public void EventTokenTwirl()
	{
		//IL_000c: Unknown result type (might be due to invalid IL or missing references)
		((Component)soundTokenTwirl.Play(soundTokenPosition.position)).transform.SetParent(soundTokenPosition);
	}

	public void EventTokenFly()
	{
		//IL_000c: Unknown result type (might be due to invalid IL or missing references)
		((Component)soundTokenFly.Play(soundTokenPosition.position)).transform.SetParent(soundTokenPosition);
	}

	public void TokenParticlesEnd()
	{
		//IL_000c: Unknown result type (might be due to invalid IL or missing references)
		soundTokenInsert.Play(soundBaseArrowsPosition.position);
		tokenParticleSparkles.Stop();
	}

	public void EventTokenSlotImpulse()
	{
		//IL_001f: Unknown result type (might be due to invalid IL or missing references)
		//IL_004d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		GameDirector.instance.CameraShake.ShakeDistance(2f, 3f, 5f, tokenMeshTargetTransform.position, 0.1f);
		GameDirector.instance.CameraImpact.ShakeDistance(2f, 3f, 5f, tokenMeshTargetTransform.position, 0.05f);
		soundTokenImpact.Play(soundBaseArrowsPosition.position);
		shakeLayerImpulseTimer = 0.5f;
		tokenImpactDone = true;
	}

	public void EventTokenIntroDone()
	{
		tokenIntroDone = true;
	}

	public void EventTokenOutroDone()
	{
		//IL_001f: Unknown result type (might be due to invalid IL or missing references)
		//IL_004d: Unknown result type (might be due to invalid IL or missing references)
		GameDirector.instance.CameraShake.ShakeDistance(2f, 3f, 5f, tokenMeshTargetTransform.position, 0.1f);
		GameDirector.instance.CameraImpact.ShakeDistance(2f, 3f, 5f, tokenMeshTargetTransform.position, 0.05f);
		shakeLayerImpulseTimer = 0.5f;
	}

	public void EventConfettiCannonImpulse()
	{
		//IL_001f: Unknown result type (might be due to invalid IL or missing references)
		//IL_004d: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b1: Unknown result type (might be due to invalid IL or missing references)
		GameDirector.instance.CameraShake.ShakeDistance(2f, 3f, 5f, tokenMeshTargetTransform.position, 0.1f);
		GameDirector.instance.CameraImpact.ShakeDistance(2f, 3f, 5f, tokenMeshTargetTransform.position, 0.05f);
		shakeLayerImpulseTimer = 0.5f;
		foreach (CosmeticShopMachineConfetti confetti in confettis)
		{
			confetti.Set(controller.interactingRarity);
		}
		soundCannonsShoot.Play(soundBaseArrowsPosition.position);
	}

	public void EventScreensSpeedUp()
	{
		//IL_000c: Unknown result type (might be due to invalid IL or missing references)
		soundScreensSpeedUp.Play(soundScreenPosition.position);
	}

	public void EventScreensStop()
	{
		//IL_000c: Unknown result type (might be due to invalid IL or missing references)
		soundScreensStop.Play(soundScreenPosition.position);
	}

	public void EventPlateOn()
	{
		//IL_000c: Unknown result type (might be due to invalid IL or missing references)
		soundPlateOn.Play(soundPlatePosition.position);
	}

	public void EventPlateOff()
	{
		//IL_000c: Unknown result type (might be due to invalid IL or missing references)
		soundPlateOff.Play(soundPlatePosition.position);
	}

	public void EventScreenIconSwitchIntro()
	{
		//IL_000c: Unknown result type (might be due to invalid IL or missing references)
		soundScreenIconSwitchIntro.Play(soundScreenPosition.position);
	}

	public void EventScreenIconSwitchOutro()
	{
		//IL_000c: Unknown result type (might be due to invalid IL or missing references)
		soundScreenIconSwitchOutro.Play(soundScreenPosition.position);
	}

	public void EventScreenCurrencyReward()
	{
		//IL_000c: Unknown result type (might be due to invalid IL or missing references)
		soundScreenCurrencyReward.Play(soundScreenPosition.position);
	}

	public void EventScreenCosmeticIntro()
	{
		//IL_000c: Unknown result type (might be due to invalid IL or missing references)
		soundScreenCosmeticIntro.Play(soundScreenPosition.position);
	}

	public void EventScreenCosmeticOutro()
	{
		//IL_000c: Unknown result type (might be due to invalid IL or missing references)
		soundScreenCosmeticOutro.Play(soundScreenPosition.position);
	}

	public void EventScreenCosmeticFrameIntro()
	{
		//IL_000c: Unknown result type (might be due to invalid IL or missing references)
		soundScreenCosmeticFrameIntro.Play(soundScreenPosition.position);
	}

	public void EventScreenCosmeticFrameOutro()
	{
		//IL_000c: Unknown result type (might be due to invalid IL or missing references)
		soundScreenCosmeticFrameOutro.Play(soundScreenPosition.position);
	}

	public void EventScreenCosmeticReward()
	{
		//IL_002f: Unknown result type (might be due to invalid IL or missing references)
		//IL_005b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0087: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b3: Unknown result type (might be due to invalid IL or missing references)
		switch (controller.interactingRarity)
		{
		case SemiFunc.Rarity.Common:
			soundScreenCosmeticRewardCommon.Play(soundScreenPosition.position);
			break;
		case SemiFunc.Rarity.Uncommon:
			soundScreenCosmeticRewardUncommon.Play(soundScreenPosition.position);
			break;
		case SemiFunc.Rarity.Rare:
			soundScreenCosmeticRewardRare.Play(soundScreenPosition.position);
			break;
		case SemiFunc.Rarity.UltraRare:
			soundScreenCosmeticRewardUltraRare.Play(soundScreenPosition.position);
			break;
		}
	}

	public void EventCannonsIntro()
	{
		//IL_000c: Unknown result type (might be due to invalid IL or missing references)
		soundCannonsIntro.Play(soundBaseArrowsPosition.position);
	}

	public void EventCannonsOutro()
	{
		//IL_000c: Unknown result type (might be due to invalid IL or missing references)
		soundCannonsOutro.Play(soundBaseArrowsPosition.position);
	}
}
