using System;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Localization;
using UnityEngine.Localization.Settings;

[CreateAssetMenu(fileName = "Scripted TTS", menuName = "Localization/Scripted TTS")]
public class ScriptedTTS : ScriptableObject
{
	public enum Group
	{
		Ouch,
		BetrayalFarewell,
		SelfDestruct,
		TruckWarning,
		SelfDestructCancel,
		MuseumGreen,
		MuseumRed,
		MuseumCountdown,
		LeftBehind
	}

	public List<LocalizedAsset> ouch = new List<LocalizedAsset>();

	public List<LocalizedAsset> betrayalFarewell = new List<LocalizedAsset>();

	public List<LocalizedAsset> selfDestruct = new List<LocalizedAsset>();

	public List<LocalizedAsset> truckWarning = new List<LocalizedAsset>();

	public List<LocalizedAsset> selfDestructCancel = new List<LocalizedAsset>();

	public List<LocalizedAsset> museumGreen = new List<LocalizedAsset>();

	public List<LocalizedAsset> museumRed = new List<LocalizedAsset>();

	public List<LocalizedAsset> museumCountdown = new List<LocalizedAsset>();

	public List<LocalizedAsset> leftBehind = new List<LocalizedAsset>();

	public static string GetLine(Group group, int index, string english, out string localeCode)
	{
		//IL_0057: Unknown result type (might be due to invalid IL or missing references)
		//IL_005c: Unknown result type (might be due to invalid IL or missing references)
		//IL_007d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0082: Unknown result type (might be due to invalid IL or missing references)
		localeCode = "en-US";
		ScriptedTTS scriptedTTS = Resources.Load<ScriptedTTS>("Scripted TTS");
		if (!Object.op_Implicit((Object)(object)scriptedTTS))
		{
			return english;
		}
		List<LocalizedAsset> list = scriptedTTS.LinesGet(group);
		if (list == null || index < 0 || index >= list.Count)
		{
			return english;
		}
		LocalizedAsset localizedAsset = list[index];
		if (!Object.op_Implicit((Object)(object)localizedAsset) || !localizedAsset.IsValid())
		{
			return english;
		}
		Locale val = LocalizationSettings.SelectedLocale;
		LocaleIdentifier identifier = val.Identifier;
		if (!TTSPronunciation.LocaleSupported(identifier.Code) || !localizedAsset.ExistsForLocale(val))
		{
			val = LocalizationSettings.ProjectLocale;
		}
		identifier = val.Identifier;
		localeCode = identifier.Code;
		return localizedAsset.GetLocalizedString(val) ?? english;
	}

	public static string GetLeftBehind(string english, out string localeCode)
	{
		//IL_0016: Unknown result type (might be due to invalid IL or missing references)
		//IL_001b: Unknown result type (might be due to invalid IL or missing references)
		//IL_002b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0030: Unknown result type (might be due to invalid IL or missing references)
		//IL_0046: Unknown result type (might be due to invalid IL or missing references)
		//IL_004b: Unknown result type (might be due to invalid IL or missing references)
		localeCode = "en-US";
		Locale selectedLocale = LocalizationSettings.SelectedLocale;
		if (Object.op_Implicit((Object)(object)selectedLocale))
		{
			LocaleIdentifier identifier = selectedLocale.Identifier;
			if (TTSPronunciation.LocaleSupported(identifier.Code))
			{
				identifier = selectedLocale.Identifier;
				if (!identifier.Code.Equals("en", StringComparison.OrdinalIgnoreCase))
				{
					identifier = selectedLocale.Identifier;
					if (!identifier.Code.StartsWith("en-", StringComparison.OrdinalIgnoreCase))
					{
						ScriptedTTS scriptedTTS = Resources.Load<ScriptedTTS>("Scripted TTS");
						if (!Object.op_Implicit((Object)(object)scriptedTTS) || scriptedTTS.leftBehind == null || scriptedTTS.leftBehind.Count == 0)
						{
							return english;
						}
						return GetLine(Group.LeftBehind, Random.Range(0, scriptedTTS.leftBehind.Count), english, out localeCode);
					}
				}
			}
		}
		return english;
	}

	private List<LocalizedAsset> LinesGet(Group group)
	{
		return group switch
		{
			Group.Ouch => ouch, 
			Group.BetrayalFarewell => betrayalFarewell, 
			Group.SelfDestruct => selfDestruct, 
			Group.TruckWarning => truckWarning, 
			Group.SelfDestructCancel => selfDestructCancel, 
			Group.MuseumGreen => museumGreen, 
			Group.MuseumRed => museumRed, 
			Group.MuseumCountdown => museumCountdown, 
			Group.LeftBehind => leftBehind, 
			_ => null, 
		};
	}
}
