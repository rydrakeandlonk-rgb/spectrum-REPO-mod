using System.Collections.Generic;
using UnityEngine;

public class EnemySnatcherSuspension : MonoBehaviour
{
	private struct SuspensionGroundCache
	{
		public Transform root;

		public Rigidbody attachedRigidbody;

		public bool valid;
	}

	private enum BodyPitchSupport
	{
		Hind,
		Front
	}

	[Tooltip("leg attachment points the body raycasts down from. rest height comes from each point's local y, so place them where the straightened leg meets the body.")]
	public List<Transform> suspensionPoints = new List<Transform>();

	[Tooltip("how far below the straightened-leg height the ground can be before that corner stops pushing")]
	public float extraDropDistance = 0.6f;

	[Tooltip("upward acceleration per meter of leg compression, per point")]
	public float springStrength = 80f;

	[Tooltip("damping on the vertical velocity at each point, kills bounce")]
	public float springDamping = 6f;

	[Tooltip("max upward acceleration one point is allowed to add")]
	public float springMaxAcceleration = 40f;

	[Tooltip("fraction of the max used to pull a corner back down when it sits above rest height, keeps it from floating over ledges")]
	public float pullDownFraction = 0.35f;

	[Tooltip("horizontal velocity damping while any leg finds ground. stands in for the foot friction the raised colliders no longer give, otherwise the body sways forever on the follow spring")]
	public float groundGrip = 8f;

	[Tooltip("angular velocity damping on all axes while grounded. planted feet resist twisting AND rocking, and this is what stops the follow torque and the upright torque from chattering against each other")]
	public float angularGrip = 6f;

	[Tooltip("multiplier for the Snatcher Rigidbody weight pressed into PhysGrabObjects through each grounded hoof. one means mass times gravity divided evenly across four legs")]
	public float physObjectFootWeightMultiplier = 1f;

	[Tooltip("seconds the physical bob target takes to ease toward the blended gait waveform")]
	public float gaitBobTargetSmoothTime = 0.09f;

	[Tooltip("maximum meters per second the eased body-height target may travel")]
	public float gaitBobTargetMaxSpeed = 3f;

	[Tooltip("extra center-of-mass acceleration per meter of missed body bob, layered over the four leg springs")]
	public float gaitBobBodyStrength = 220f;

	[Tooltip("maximum extra center-of-mass acceleration used to make the whole body follow the gait bob")]
	public float gaitBobBodyMaxAcceleration = 20f;

	[Tooltip("seconds the physical gait pitch target takes to ease toward the blended waveform")]
	public float gaitPitchTargetSmoothTime = 0.08f;

	[Tooltip("maximum degrees per second the eased gait pitch target may travel")]
	public float gaitPitchTargetMaxSpeed = 60f;

	public float gallopSpringStrength = 1200f;

	public float gallopSpringDamping = 42f;

	public float gallopMaxAcceleration = 180f;

	public float gallopTargetSmoothTime = 0.012f;

	public float gallopTargetMaxSpeed = 12f;

	public float hoofLandingForceTime = 0.1f;

	[Range(0f, 1f)]
	public float hoofLandingForceAtPoint = 0.35f;

	[Tooltip("pull a corner of the Rigidbody toward ground that its matching leg cannot currently reach")]
	public bool footingRecovery = true;

	[Tooltip("extra meters below the normal suspension probe used only to look for unreachable footing... this does not extend the hoof grounding ray")]
	public float footingRecoverySearchDistance = 0.8f;

	[Tooltip("reach deficit ignored before the corner starts pulling, preventing tiny solver errors from chattering")]
	public float footingRecoveryDeadZone = 0.04f;

	[Tooltip("reach deficit where the recovery pull reaches full strength")]
	public float footingRecoveryFullForceShortfall = 0.3f;

	[Tooltip("maximum combined acceleration from every unreachable leg.. the budget is shared so four legs cannot multiply it into a slam")]
	public float footingRecoveryMaxAcceleration = 12f;

	[Tooltip("how quickly each corner eases its recovery force in and out")]
	public float footingRecoveryResponse = 8f;

	public float missingFootingMaxAcceleration = 6f;

	[Range(0f, 2f)]
	public float missingFootingHorizontalPull = 0.8f;

	private float missingFootingWeight;

	[Tooltip("torque that steers the body toward the terrain-fit pitch, so all legs sit at their proper lengths on stairs and slopes")]
	public float uprightTorque = 0.6f;

	[Tooltip("degrees of error where the upright torque reaches full strength. below this it fades out, so it can't bang-bang around zero like an unclamped PhysFollowRotation does")]
	public float uprightTorqueDamping = 3f;

	[Tooltip("max degrees the body is allowed to pitch to fit the terrain")]
	public float maxTerrainPitch = 30f;

	private EnemyRigidbody enemyRigidbody;

	private EnemySnatcherVisuals snatcherVisuals;

	private BotSystemSpringPoseAnimatorWalk walkSystem;

	private LayerMask groundMask;

	private int physGrabLayerMask;

	private readonly RaycastHit[] suspensionHits = new RaycastHit[64];

	private readonly Dictionary<Collider, SuspensionGroundCache> suspensionGroundValidity = new Dictionary<Collider, SuspensionGroundCache>();

	private float referencesFindTimer;

	private float[] restDistances;

	private bool[] pointIsFront;

	private float wheelbase;

	private float frontErrorAverage;

	private float hindErrorAverage;

	private float frontGroundAverage;

	private float hindGroundAverage;

	private int frontGroundHits;

	private float frontSupportTimer;

	private int hindGroundHits;

	private float hindSupportTimer;

	private float smoothedBodyBobTarget;

	private float bodyBobTargetVelocity;

	private float smoothedGaitPitchTarget;

	private float gaitPitchTargetVelocity;

	private float bodyHeightOverride;

	private float bodyHeightOverrideTimer;

	private float jumpBodyHeightOverrideTimer;

	private float jumpBodyHeightTargetSmoothTime;

	private float jumpBodyHeightTargetMaxSpeed;

	private float jumpBodyHeightSpringStrength;

	private float jumpBodyHeightSpringDamping;

	private float jumpBodyHeightMaxAcceleration;

	private float jumpBodyHeightDampingMultiplier;

	private float jumpBodyHeightNormalWeight;

	private float jumpBodyHeightBaseline;

	private float jumpBodyHeightResponse;

	private float jumpGroundVelocityY;

	private BodyPitchSupport bodyPitchSupport;

	private float rearingPitchOverride;

	private float rearingTorqueOverride;

	private float rearingOverrideTimer;

	private float rearingBasePitch;

	private float neutralSuspensionCompression;

	private bool neutralSuspensionCompressionReady;

	private float[] footingRecoveryWeights;

	private Vector3[] footingRecoveryDirections;

	private Vector3[] footingRecoveryForcePoints;

	private bool[] footingRecoveryCandidates;

	private float[] hoofLandingImpulses;

	private float[] hoofLandingImpulseTimers;

	private int[] chainForPoint;

	internal float bodyBobTarget;

	internal float gaitPitchTarget;

	internal float bodyBobResponse;

	internal int groundContactCount;

	internal bool FrontSupportActive
	{
		get
		{
			if (((Behaviour)this).isActiveAndEnabled)
			{
				return frontSupportTimer > 0f;
			}
			return false;
		}
	}

	internal bool HindSupportActive
	{
		get
		{
			if (((Behaviour)this).isActiveAndEnabled)
			{
				return hindSupportTimer > 0f;
			}
			return false;
		}
	}

	private void Awake()
	{
		//IL_0014: Unknown result type (might be due to invalid IL or missing references)
		//IL_0019: Unknown result type (might be due to invalid IL or missing references)
		//IL_0042: Unknown result type (might be due to invalid IL or missing references)
		//IL_0047: Unknown result type (might be due to invalid IL or missing references)
		//IL_0129: Unknown result type (might be due to invalid IL or missing references)
		//IL_0149: Unknown result type (might be due to invalid IL or missing references)
		//IL_0194: Unknown result type (might be due to invalid IL or missing references)
		//IL_0174: Unknown result type (might be due to invalid IL or missing references)
		enemyRigidbody = ((Component)this).GetComponent<EnemyRigidbody>();
		ReferencesFind(_force: true);
		LayerMask val = SemiFunc.LayerMaskGetPhysGrabObject();
		physGrabLayerMask = val.value;
		groundMask = LayerMask.op_Implicit(LayerMask.GetMask(new string[1] { "Default" }) | physGrabLayerMask);
		restDistances = new float[suspensionPoints.Count];
		pointIsFront = new bool[suspensionPoints.Count];
		footingRecoveryWeights = new float[suspensionPoints.Count];
		footingRecoveryDirections = new Vector3[suspensionPoints.Count];
		footingRecoveryForcePoints = new Vector3[suspensionPoints.Count];
		footingRecoveryCandidates = new bool[suspensionPoints.Count];
		hoofLandingImpulses = new float[suspensionPoints.Count];
		hoofLandingImpulseTimers = new float[suspensionPoints.Count];
		float num = 0f;
		float num2 = 0f;
		int num3 = 0;
		int num4 = 0;
		for (int i = 0; i < suspensionPoints.Count; i++)
		{
			restDistances[i] = suspensionPoints[i].localPosition.y;
			pointIsFront[i] = suspensionPoints[i].localPosition.z > 0f;
			if (pointIsFront[i])
			{
				num += suspensionPoints[i].localPosition.z;
				num3++;
			}
			else
			{
				num2 += suspensionPoints[i].localPosition.z;
				num4++;
			}
		}
		if (num3 > 0)
		{
			num /= (float)num3;
		}
		if (num4 > 0)
		{
			num2 /= (float)num4;
		}
		wheelbase = Mathf.Max(0.1f, num - num2);
	}

	private void OnDisable()
	{
		FullReset();
	}

	internal void FullReset()
	{
		SuspensionInactiveReset();
		JumpBodyHeightReset();
		neutralSuspensionCompression = 0f;
		neutralSuspensionCompressionReady = false;
		jumpBodyHeightBaseline = 0f;
		frontErrorAverage = 0f;
		hindErrorAverage = 0f;
		frontGroundAverage = 0f;
		hindGroundAverage = 0f;
		frontGroundHits = 0;
		hindGroundHits = 0;
		rearingPitchOverride = 0f;
		rearingTorqueOverride = 0f;
		rearingOverrideTimer = 0f;
		rearingBasePitch = 0f;
		bodyPitchSupport = BodyPitchSupport.Hind;
		ResetHoofLandingImpulses();
		suspensionGroundValidity.Clear();
	}

	private void FixedUpdate()
	{
		frontSupportTimer = Mathf.Max(0f, frontSupportTimer - Time.fixedDeltaTime);
		hindSupportTimer = Mathf.Max(0f, hindSupportTimer - Time.fixedDeltaTime);
		BodyHeightOverrideTick();
		ReferencesFindTick();
		JumpBodyHeightOverrideTick();
		RearingOverrideTick();
		if (!SemiFunc.IsMasterClientOrSingleplayer())
		{
			SuspensionInactiveReset();
			return;
		}
		if (Object.op_Implicit((Object)(object)walkSystem))
		{
			walkSystem.GameplaySimulationOverride();
			if (!walkSystem.CullingSimulationActive)
			{
				SuspensionInactiveReset();
				return;
			}
		}
		if (SuspensionBlocked())
		{
			SuspensionInactiveReset();
			return;
		}
		float num = 0f;
		if (jumpBodyHeightOverrideTimer <= 0f && Object.op_Implicit((Object)(object)snatcherVisuals))
		{
			num = snatcherVisuals.RigidbodyBobTarget();
		}
		bodyBobTarget = num + bodyHeightOverride;
		gaitPitchTarget = (Object.op_Implicit((Object)(object)snatcherVisuals) ? snatcherVisuals.RigidbodyPitchTarget() : 0f);
		GaitBobTargetTick();
		GaitPitchTargetTick();
		SuspensionForces();
		GaitBobBodyForce();
		ApplyPhysObjectFootWeight();
		TerrainAlignTorque();
		HoofLandingImpulseTick();
	}

	private void SuspensionInactiveReset()
	{
		frontSupportTimer = 0f;
		hindSupportTimer = 0f;
		bodyBobTarget = 0f;
		ResetGaitBob();
		ResetFootingRecovery();
		ResetPhysObjectFootWeight();
		ResetHoofLandingImpulses();
	}

	public void OverrideBodyHeight(float _height, float _time = 0.1f)
	{
		bodyHeightOverride = _height;
		bodyHeightOverrideTimer = Mathf.Max(bodyHeightOverrideTimer, _time);
	}

	internal void JumpBodyHeightBegin()
	{
		jumpBodyHeightOverrideTimer = 0f;
		jumpBodyHeightBaseline = (neutralSuspensionCompressionReady ? neutralSuspensionCompression : 0f);
		jumpBodyHeightResponse = 0f;
		jumpGroundVelocityY = 0f;
		jumpBodyHeightNormalWeight = 0f;
		smoothedBodyBobTarget = 0f;
		bodyBobTargetVelocity = 0f;
	}

	internal void OverrideJumpBodyHeight(float _height, float _springStrength, float _springDamping, float _maxAcceleration, float _dampingMultiplier, float _targetSmoothTime, float _targetMaxSpeed, float _time = 0.1f, float _normalSuspensionWeight = 0f)
	{
		if (jumpBodyHeightOverrideTimer <= 0f)
		{
			JumpBodyHeightBegin();
		}
		OverrideBodyHeight(_height, _time);
		jumpBodyHeightSpringStrength = Mathf.Max(0.1f, _springStrength);
		jumpBodyHeightSpringDamping = Mathf.Max(0f, _springDamping);
		jumpBodyHeightMaxAcceleration = Mathf.Max(0.1f, _maxAcceleration);
		jumpBodyHeightDampingMultiplier = Mathf.Clamp01(_dampingMultiplier);
		jumpBodyHeightNormalWeight = Mathf.Clamp01(_normalSuspensionWeight);
		jumpBodyHeightTargetSmoothTime = Mathf.Max(0.005f, _targetSmoothTime);
		jumpBodyHeightTargetMaxSpeed = Mathf.Max(0.1f, _targetMaxSpeed);
		jumpBodyHeightOverrideTimer = Mathf.Max(jumpBodyHeightOverrideTimer, _time);
	}

	internal void JumpBodyHeightReset()
	{
		jumpBodyHeightOverrideTimer = 0f;
		bodyHeightOverrideTimer = 0f;
		bodyHeightOverride = 0f;
		jumpBodyHeightResponse = 0f;
		jumpGroundVelocityY = 0f;
		jumpBodyHeightNormalWeight = 0f;
		smoothedBodyBobTarget = 0f;
		bodyBobTargetVelocity = 0f;
	}

	internal bool JumpBodyHeightSettled(float _heightTolerance, float _velocityTolerance)
	{
		//IL_0023: Unknown result type (might be due to invalid IL or missing references)
		if (jumpBodyHeightOverrideTimer <= 0f || groundContactCount <= 0)
		{
			return false;
		}
		float num = enemyRigidbody.rb.linearVelocity.y - jumpGroundVelocityY;
		_heightTolerance = Mathf.Max(0.001f, _heightTolerance);
		if (Mathf.Abs(smoothedBodyBobTarget) <= _heightTolerance && Mathf.Abs(jumpBodyHeightResponse) <= _heightTolerance)
		{
			return Mathf.Abs(num) <= Mathf.Max(0.01f, _velocityTolerance);
		}
		return false;
	}

	internal bool JumpLandingSupportConfigured()
	{
		if (suspensionPoints != null && suspensionPoints.Count > 0 && restDistances != null)
		{
			return restDistances.Length == suspensionPoints.Count;
		}
		return false;
	}

	internal bool JumpLandingSupport()
	{
		//IL_008e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0093: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a0: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a5: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b2: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d4: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d9: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ef: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f4: Unknown result type (might be due to invalid IL or missing references)
		//IL_012d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0132: Unknown result type (might be due to invalid IL or missing references)
		if (Object.op_Implicit((Object)(object)snatcherVisuals) && Object.op_Implicit((Object)(object)snatcherVisuals.enemySnatcher) && !snatcherVisuals.enemySnatcher.CeilingLandingAllowed)
		{
			return false;
		}
		if (!JumpLandingSupportConfigured())
		{
			return false;
		}
		for (int i = 0; i < suspensionPoints.Count; i++)
		{
			Transform val = suspensionPoints[i];
			if (!Object.op_Implicit((Object)(object)val))
			{
				continue;
			}
			float num = Mathf.Max(0.05f, restDistances[i]);
			float num2 = num + Mathf.Max(0.05f, extraDropDistance);
			float y = enemyRigidbody.rb.GetPointVelocity(val.position).y;
			int num3 = Physics.RaycastNonAlloc(val.position, Vector3.down, suspensionHits, num2, LayerMask.op_Implicit(groundMask), (QueryTriggerInteraction)1);
			for (int j = 0; j < num3; j++)
			{
				RaycastHit val2 = suspensionHits[j];
				if (!ValidSuspensionGround(val2.collider) || Vector3.Dot(val2.normal, Vector3.up) < 0.35f)
				{
					continue;
				}
				float num4 = (Object.op_Implicit((Object)(object)val2.collider.attachedRigidbody) ? val2.collider.attachedRigidbody.GetPointVelocity(val2.point).y : 0f);
				float num5 = y - num4;
				if (!(num5 > 0.1f))
				{
					float num6 = Mathf.Max(0f, (0f - num5) * Time.fixedDeltaTime);
					if (!(val2.distance > num + num6 + 0.05f))
					{
						return true;
					}
				}
			}
		}
		return false;
	}

	internal bool JumpLandingGroundPresent()
	{
		//IL_0081: Unknown result type (might be due to invalid IL or missing references)
		//IL_0086: Unknown result type (might be due to invalid IL or missing references)
		//IL_0093: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b1: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b6: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c9: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ce: Unknown result type (might be due to invalid IL or missing references)
		if (Object.op_Implicit((Object)(object)snatcherVisuals) && Object.op_Implicit((Object)(object)snatcherVisuals.enemySnatcher) && !snatcherVisuals.enemySnatcher.CeilingLandingAllowed)
		{
			return false;
		}
		if (!JumpLandingSupportConfigured())
		{
			return false;
		}
		for (int i = 0; i < suspensionPoints.Count; i++)
		{
			Transform val = suspensionPoints[i];
			if (!Object.op_Implicit((Object)(object)val))
			{
				continue;
			}
			float num = Mathf.Max(0.05f, restDistances[i]) + Mathf.Max(0.05f, extraDropDistance);
			int num2 = Physics.RaycastNonAlloc(val.position, Vector3.down, suspensionHits, num, LayerMask.op_Implicit(groundMask), (QueryTriggerInteraction)1);
			for (int j = 0; j < num2; j++)
			{
				RaycastHit val2 = suspensionHits[j];
				if (ValidSuspensionGround(val2.collider) && !(Vector3.Dot(val2.normal, Vector3.up) < 0.35f))
				{
					return true;
				}
			}
		}
		return false;
	}

	public void OverrideRearingPitch(float _pitch, float _torque, float _time = 0.1f)
	{
		OverrideBodyPitch(_pitch, _torque, BodyPitchSupport.Hind, _time);
	}

	public void OverrideBackKickPitch(float _pitch, float _torque, float _time = 0.1f)
	{
		OverrideBodyPitch(_pitch, _torque, BodyPitchSupport.Front, _time);
	}

	private void OverrideBodyPitch(float _pitch, float _torque, BodyPitchSupport _support, float _time)
	{
		//IL_0047: Unknown result type (might be due to invalid IL or missing references)
		//IL_004c: Unknown result type (might be due to invalid IL or missing references)
		//IL_004f: Unknown result type (might be due to invalid IL or missing references)
		if (Object.op_Implicit((Object)(object)enemyRigidbody) && Object.op_Implicit((Object)(object)enemyRigidbody.rb))
		{
			if (rearingOverrideTimer <= 0f || bodyPitchSupport != _support)
			{
				Quaternion rotation = enemyRigidbody.rb.rotation;
				rearingBasePitch = Mathf.Clamp(Mathf.DeltaAngle(0f, rotation.eulerAngles.x), 0f - maxTerrainPitch, maxTerrainPitch);
			}
			bodyPitchSupport = _support;
			rearingPitchOverride = _pitch;
			rearingTorqueOverride = Mathf.Max(0.01f, _torque);
			rearingOverrideTimer = Mathf.Max(rearingOverrideTimer, _time);
		}
	}

	private bool BodyPitchPointUnsupported(int _pointIndex)
	{
		if (rearingOverrideTimer <= 0f)
		{
			return false;
		}
		if (bodyPitchSupport != BodyPitchSupport.Front)
		{
			return pointIsFront[_pointIndex];
		}
		return !pointIsFront[_pointIndex];
	}

	internal bool RearingLandingReady(float _pitchOffset, float _pitchTolerance, float _angularSpeedTolerance)
	{
		//IL_0033: Unknown result type (might be due to invalid IL or missing references)
		//IL_0038: Unknown result type (might be due to invalid IL or missing references)
		//IL_003b: Unknown result type (might be due to invalid IL or missing references)
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_006a: Unknown result type (might be due to invalid IL or missing references)
		if (!Object.op_Implicit((Object)(object)enemyRigidbody) || !Object.op_Implicit((Object)(object)enemyRigidbody.rb))
		{
			return true;
		}
		Rigidbody rb = enemyRigidbody.rb;
		Quaternion rotation = rb.rotation;
		float num = Mathf.DeltaAngle(0f, rotation.eulerAngles.x);
		float num2 = rearingBasePitch + _pitchOffset;
		float num3 = Mathf.Abs(Mathf.DeltaAngle(num, num2));
		float num4 = Mathf.Abs(Vector3.Dot(rb.angularVelocity, ((Component)rb).transform.right)) * 57.29578f;
		if (num3 <= Mathf.Max(0.1f, _pitchTolerance))
		{
			return num4 <= Mathf.Max(0f, _angularSpeedTolerance);
		}
		return false;
	}

	internal void HoofLandingImpulse(int _chainIndex, float _velocity)
	{
		if (!SemiFunc.IsMasterClientOrSingleplayer() || _velocity <= 0f || !Object.op_Implicit((Object)(object)walkSystem) || walkSystem.chains == null || _chainIndex < 0 || _chainIndex >= walkSystem.chains.Count || hoofLandingImpulses == null || hoofLandingImpulseTimers == null || hoofLandingImpulses.Length != suspensionPoints.Count || hoofLandingImpulseTimers.Length != suspensionPoints.Count)
		{
			return;
		}
		for (int i = 0; i < suspensionPoints.Count; i++)
		{
			if (ChainIndexForPoint(i) == _chainIndex)
			{
				if (Object.op_Implicit((Object)(object)suspensionPoints[i]))
				{
					hoofLandingImpulses[i] = Mathf.Max(hoofLandingImpulses[i], _velocity);
					hoofLandingImpulseTimers[i] = Mathf.Max(hoofLandingImpulseTimers[i], Mathf.Max(0.02f, hoofLandingForceTime));
				}
				break;
			}
		}
	}

	private void HoofLandingImpulseTick()
	{
		//IL_0030: Unknown result type (might be due to invalid IL or missing references)
		//IL_0035: Unknown result type (might be due to invalid IL or missing references)
		//IL_004b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0050: Unknown result type (might be due to invalid IL or missing references)
		//IL_0053: Unknown result type (might be due to invalid IL or missing references)
		//IL_0044: Unknown result type (might be due to invalid IL or missing references)
		//IL_0058: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f9: Unknown result type (might be due to invalid IL or missing references)
		//IL_0112: Unknown result type (might be due to invalid IL or missing references)
		//IL_0117: Unknown result type (might be due to invalid IL or missing references)
		//IL_012c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0135: Unknown result type (might be due to invalid IL or missing references)
		//IL_0153: Unknown result type (might be due to invalid IL or missing references)
		//IL_0156: Unknown result type (might be due to invalid IL or missing references)
		//IL_0168: Unknown result type (might be due to invalid IL or missing references)
		if (hoofLandingImpulses == null || hoofLandingImpulseTimers == null || !Object.op_Implicit((Object)(object)enemyRigidbody) || !Object.op_Implicit((Object)(object)enemyRigidbody.rb))
		{
			return;
		}
		Vector3 gravity = Physics.gravity;
		Vector3 val;
		if (!(gravity.sqrMagnitude > 1E-06f))
		{
			val = Vector3.down;
		}
		else
		{
			gravity = Physics.gravity;
			val = gravity.normalized;
		}
		Vector3 val2 = val;
		float num = Mathf.Max(0.02f, hoofLandingForceTime);
		float num2 = Mathf.Clamp01(hoofLandingForceAtPoint);
		for (int i = 0; i < hoofLandingImpulses.Length; i++)
		{
			float num3 = hoofLandingImpulses[i];
			float num4 = hoofLandingImpulseTimers[i];
			if (num3 <= 0f || num4 <= 0f || !Object.op_Implicit((Object)(object)suspensionPoints[i]))
			{
				hoofLandingImpulses[i] = 0f;
				hoofLandingImpulseTimers[i] = 0f;
				continue;
			}
			float num5 = Mathf.Min(Time.fixedDeltaTime, num4) / Mathf.Max(0.0001f, Time.fixedDeltaTime);
			Vector3 val3 = val2 * (enemyRigidbody.rb.mass * num3 / num * num5);
			if (num2 < 1f)
			{
				enemyRigidbody.rb.AddForce(val3 * (1f - num2), (ForceMode)0);
			}
			if (num2 > 0f)
			{
				enemyRigidbody.rb.AddForceAtPosition(val3 * num2, suspensionPoints[i].position, (ForceMode)0);
			}
			hoofLandingImpulseTimers[i] = Mathf.Max(0f, num4 - Time.fixedDeltaTime);
			if (!(hoofLandingImpulseTimers[i] > 0f))
			{
				hoofLandingImpulses[i] = 0f;
			}
		}
	}

	private void ResetHoofLandingImpulses()
	{
		if (hoofLandingImpulses == null)
		{
			return;
		}
		for (int i = 0; i < hoofLandingImpulses.Length; i++)
		{
			hoofLandingImpulses[i] = 0f;
			if (hoofLandingImpulseTimers != null && i < hoofLandingImpulseTimers.Length)
			{
				hoofLandingImpulseTimers[i] = 0f;
			}
		}
	}

	private void BodyHeightOverrideTick()
	{
		if (bodyHeightOverrideTimer <= 0f)
		{
			bodyHeightOverride = 0f;
		}
		else
		{
			bodyHeightOverrideTimer -= Time.fixedDeltaTime;
		}
	}

	private void JumpBodyHeightOverrideTick()
	{
		if (!(jumpBodyHeightOverrideTimer <= 0f))
		{
			jumpBodyHeightOverrideTimer -= Time.fixedDeltaTime;
			if (!(jumpBodyHeightOverrideTimer > 0f))
			{
				jumpBodyHeightOverrideTimer = 0f;
				jumpBodyHeightResponse = 0f;
				jumpGroundVelocityY = 0f;
			}
		}
	}

	private void RearingOverrideTick()
	{
		if (rearingOverrideTimer <= 0f)
		{
			rearingPitchOverride = 0f;
			rearingTorqueOverride = 0f;
		}
		else
		{
			rearingOverrideTimer -= Time.fixedDeltaTime;
		}
	}

	private void ReferencesFindTick()
	{
		if (!Object.op_Implicit((Object)(object)snatcherVisuals) || !Object.op_Implicit((Object)(object)walkSystem))
		{
			if (referencesFindTimer <= 0f)
			{
				ReferencesFind();
			}
			if (referencesFindTimer > 0f)
			{
				referencesFindTimer -= Time.fixedDeltaTime;
			}
		}
	}

	private void ReferencesFind(bool _force = false)
	{
		if ((!Object.op_Implicit((Object)(object)snatcherVisuals) || !Object.op_Implicit((Object)(object)walkSystem)) && (_force || !(referencesFindTimer > 0f)))
		{
			referencesFindTimer = 1f;
			if (!Object.op_Implicit((Object)(object)snatcherVisuals))
			{
				snatcherVisuals = FindMatchingVisuals();
			}
			if (!Object.op_Implicit((Object)(object)walkSystem) && Object.op_Implicit((Object)(object)snatcherVisuals))
			{
				walkSystem = snatcherVisuals.walkSystem;
			}
		}
	}

	private EnemySnatcherVisuals FindMatchingVisuals()
	{
		Enemy enemy = (Object.op_Implicit((Object)(object)enemyRigidbody) ? enemyRigidbody.enemy : null);
		EnemySnatcherVisuals[] componentsInChildren;
		if (Object.op_Implicit((Object)(object)enemy))
		{
			componentsInChildren = ((Component)((Component)enemy).transform.root).GetComponentsInChildren<EnemySnatcherVisuals>(true);
			foreach (EnemySnatcherVisuals enemySnatcherVisuals in componentsInChildren)
			{
				if ((Object)(object)enemySnatcherVisuals.enemy == (Object)(object)enemy)
				{
					return enemySnatcherVisuals;
				}
			}
		}
		componentsInChildren = ((Component)((Component)this).transform.root).GetComponentsInChildren<EnemySnatcherVisuals>(true);
		foreach (EnemySnatcherVisuals enemySnatcherVisuals2 in componentsInChildren)
		{
			if (!Object.op_Implicit((Object)(object)enemy) || (Object)(object)enemySnatcherVisuals2.enemy == (Object)(object)enemy)
			{
				return enemySnatcherVisuals2;
			}
		}
		if (Object.op_Implicit((Object)(object)enemy))
		{
			componentsInChildren = Object.FindObjectsByType<EnemySnatcherVisuals>((FindObjectsInactive)1, (FindObjectsSortMode)0);
			foreach (EnemySnatcherVisuals enemySnatcherVisuals3 in componentsInChildren)
			{
				if ((Object)(object)enemySnatcherVisuals3.enemy == (Object)(object)enemy)
				{
					return enemySnatcherVisuals3;
				}
			}
		}
		return null;
	}

	private bool SuspensionBlocked()
	{
		if (Object.op_Implicit((Object)(object)snatcherVisuals) && Object.op_Implicit((Object)(object)snatcherVisuals.enemySnatcher) && snatcherVisuals.enemySnatcher.CeilingPhysicsActive)
		{
			return true;
		}
		if (Object.op_Implicit((Object)(object)snatcherVisuals) && Object.op_Implicit((Object)(object)snatcherVisuals.enemySnatcher) && snatcherVisuals.enemySnatcher.DeathActive)
		{
			return true;
		}
		if (enemyRigidbody.enemy.IsStunned())
		{
			return true;
		}
		if (enemyRigidbody.enemy.HasJump && enemyRigidbody.enemy.Jump.jumping)
		{
			return true;
		}
		if (enemyRigidbody.enemy.HasJump && enemyRigidbody.enemy.Jump.SnatcherLandingPending() && jumpBodyHeightOverrideTimer <= 0f)
		{
			return true;
		}
		if (enemyRigidbody.grabbed)
		{
			return true;
		}
		if (enemyRigidbody.frozen)
		{
			return true;
		}
		return false;
	}

	private void SuspensionForces()
	{
		//IL_00e2: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e7: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ee: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0073: Unknown result type (might be due to invalid IL or missing references)
		//IL_035f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0361: Unknown result type (might be due to invalid IL or missing references)
		//IL_010e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0118: Unknown result type (might be due to invalid IL or missing references)
		//IL_0136: Unknown result type (might be due to invalid IL or missing references)
		//IL_03b0: Unknown result type (might be due to invalid IL or missing references)
		//IL_03b7: Unknown result type (might be due to invalid IL or missing references)
		//IL_0199: Unknown result type (might be due to invalid IL or missing references)
		//IL_019e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0177: Unknown result type (might be due to invalid IL or missing references)
		//IL_0179: Unknown result type (might be due to invalid IL or missing references)
		//IL_0342: Unknown result type (might be due to invalid IL or missing references)
		//IL_0349: Unknown result type (might be due to invalid IL or missing references)
		//IL_0350: Unknown result type (might be due to invalid IL or missing references)
		float num = 0f;
		float num2 = 0f;
		int num3 = 0;
		int num4 = 0;
		float num5 = 0f;
		float num6 = 0f;
		int num7 = 0;
		float num8 = 0f;
		int num9 = 0;
		float num10 = 0f;
		frontGroundHits = 0;
		hindGroundHits = 0;
		groundContactCount = 0;
		for (int i = 0; i < suspensionPoints.Count; i++)
		{
			Transform val = suspensionPoints[i];
			if (BodyPitchPointUnsupported(i))
			{
				FootingRecoveryCandidateTick(i, val.position, _groundFound: false, Vector3.zero);
				continue;
			}
			float num11 = Mathf.Max(0.05f, restDistances[i]);
			float num12 = Mathf.Max(0.05f, num11 + smoothedBodyBobTarget);
			float rayDistance = Mathf.Max(num11, num12) + extraDropDistance;
			float num13 = 0f - extraDropDistance;
			_ = extraDropDistance;
			bool flag = false;
			float num14 = 0f;
			Collider _collider = null;
			float num15 = 0f;
			Vector3 _point = Vector3.zero;
			if (TryGetLegGround(i, val.position, rayDistance, out _point, out _collider, out var _, out var _))
			{
				num15 = Mathf.Max(0f, val.position.y - _point.y);
				num13 = num11 - num15;
				float num16 = num12 - num15;
				flag = true;
				num14 = _point.y;
				num7++;
				num8 += num13;
				num9++;
				float num17 = ((Object.op_Implicit((Object)(object)_collider) && Object.op_Implicit((Object)(object)_collider.attachedRigidbody)) ? _collider.attachedRigidbody.GetPointVelocity(_point).y : 0f);
				num10 += num17;
				float num18 = enemyRigidbody.rb.GetPointVelocity(val.position).y - num17;
				float num19 = springStrength;
				float num20 = springDamping;
				float num21 = springMaxAcceleration;
				float num22 = pullDownFraction;
				float num23 = GallopSuspensionWeight();
				int num24 = Mathf.Max(1, suspensionPoints.Count);
				num19 = Mathf.Lerp(num19, Mathf.Max(0f, gallopSpringStrength) / (float)num24, num23);
				num20 = Mathf.Lerp(num20, Mathf.Max(0f, gallopSpringDamping) / (float)num24, num23);
				num21 = Mathf.Lerp(num21, Mathf.Max(0f, gallopMaxAcceleration) / (float)num24, num23);
				num22 = Mathf.Lerp(num22, 1f, num23);
				if (jumpBodyHeightOverrideTimer > 0f)
				{
					int num25 = Mathf.Max(1, suspensionPoints.Count);
					num19 = Mathf.Lerp(jumpBodyHeightSpringStrength / (float)num25, springStrength, jumpBodyHeightNormalWeight);
					num20 = Mathf.Lerp(jumpBodyHeightSpringDamping * jumpBodyHeightDampingMultiplier / (float)num25, springDamping, jumpBodyHeightNormalWeight);
					num21 = Mathf.Lerp(jumpBodyHeightMaxAcceleration / (float)num25, springMaxAcceleration, jumpBodyHeightNormalWeight);
					num22 = Mathf.Lerp(1f, pullDownFraction, jumpBodyHeightNormalWeight);
				}
				float num26 = num16 * num19 - num18 * num20;
				num26 = Mathf.Clamp(num26, (0f - num21) * num22, num21);
				Mathf.Clamp(num13 * springStrength - num18 * springDamping, (0f - springMaxAcceleration) * pullDownFraction, springMaxAcceleration);
				enemyRigidbody.rb.AddForceAtPosition(Vector3.up * num26, val.position, (ForceMode)5);
			}
			bool flag2 = flag;
			Vector3 _point2 = _point;
			if (!flag2 && footingRecovery && footingRecoverySearchDistance > 0f)
			{
				flag2 = Object.op_Implicit((Object)(object)walkSystem) && walkSystem.TryFindFootingBeyondHoof(ChainIndexForPoint(i), footingRecoverySearchDistance, out _point2, out var _);
			}
			FootingRecoveryCandidateTick(i, val.position, flag2, _point2);
			if (pointIsFront[i])
			{
				num += num13;
				num3++;
				if (flag)
				{
					num5 += num14;
					frontGroundHits++;
				}
			}
			else
			{
				num2 += num13;
				num4++;
				if (flag)
				{
					num6 += num14;
					hindGroundHits++;
				}
			}
		}
		if (frontGroundHits > 0)
		{
			frontSupportTimer = 0.1f;
		}
		if (hindGroundHits > 0)
		{
			hindSupportTimer = 0.1f;
		}
		ApplyFootingRecoveryForces();
		frontErrorAverage = ((num3 > 0) ? (num / (float)num3) : 0f);
		hindErrorAverage = ((num4 > 0) ? (num2 / (float)num4) : 0f);
		frontGroundAverage = ((frontGroundHits > 0) ? (num5 / (float)frontGroundHits) : 0f);
		hindGroundAverage = ((hindGroundHits > 0) ? (num6 / (float)hindGroundHits) : 0f);
		groundContactCount = num7;
		jumpGroundVelocityY = ((num7 > 0) ? (num10 / (float)num7) : 0f);
		if (num9 > 0)
		{
			float num27 = num8 / (float)num9;
			if (!neutralSuspensionCompressionReady)
			{
				neutralSuspensionCompression = num27;
				neutralSuspensionCompressionReady = true;
				if (jumpBodyHeightOverrideTimer > 0f)
				{
					jumpBodyHeightBaseline = num27;
				}
			}
			else if (jumpBodyHeightOverrideTimer <= 0f)
			{
				float num28 = ((Mathf.Abs(smoothedBodyBobTarget) < 0.005f) ? 8f : 0.5f);
				float num29 = 1f - Mathf.Exp((0f - num28) * Time.fixedDeltaTime);
				neutralSuspensionCompression = Mathf.Lerp(neutralSuspensionCompression, num27, num29);
			}
			float num30 = ((jumpBodyHeightOverrideTimer > 0f) ? jumpBodyHeightBaseline : neutralSuspensionCompression);
			bodyBobResponse = num30 - num27;
			jumpBodyHeightResponse = bodyBobResponse;
		}
		else
		{
			bodyBobResponse = 0f;
			jumpBodyHeightResponse = 0f;
		}
		GroundGrip(num7);
	}

	private void FootingRecoveryCandidateTick(int _index, Vector3 _forcePoint, bool _groundFound, Vector3 _groundPoint)
	{
		//IL_0025: Unknown result type (might be due to invalid IL or missing references)
		//IL_0026: Unknown result type (might be due to invalid IL or missing references)
		//IL_0055: Unknown result type (might be due to invalid IL or missing references)
		//IL_0067: Unknown result type (might be due to invalid IL or missing references)
		//IL_0069: Unknown result type (might be due to invalid IL or missing references)
		//IL_006a: Unknown result type (might be due to invalid IL or missing references)
		//IL_006f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0138: Unknown result type (might be due to invalid IL or missing references)
		//IL_014a: Unknown result type (might be due to invalid IL or missing references)
		//IL_014f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0154: Unknown result type (might be due to invalid IL or missing references)
		//IL_0159: Unknown result type (might be due to invalid IL or missing references)
		//IL_015d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0162: Unknown result type (might be due to invalid IL or missing references)
		//IL_0081: Unknown result type (might be due to invalid IL or missing references)
		//IL_0086: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a0: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a5: Unknown result type (might be due to invalid IL or missing references)
		if (footingRecoveryWeights == null || _index < 0 || _index >= footingRecoveryWeights.Length)
		{
			return;
		}
		float num = 0f;
		footingRecoveryForcePoints[_index] = _forcePoint;
		if ((footingRecovery & _groundFound) && Object.op_Implicit((Object)(object)walkSystem) && walkSystem.TryGetLegReachShortfall(ChainIndexForPoint(_index), _groundPoint, out var _legOrigin, out var _, out var _shortfall))
		{
			Vector3 val = _groundPoint - _legOrigin;
			if (val.sqrMagnitude > 1E-06f && Vector3.Dot(val.normalized, Vector3.down) > 0.1f)
			{
				footingRecoveryDirections[_index] = val.normalized;
				float num2 = Mathf.Max(0f, footingRecoveryDeadZone);
				float num3 = ((footingRecoveryWeights[_index] > 0.001f) ? (num2 * 0.5f) : num2);
				if (_shortfall > num3)
				{
					num = Mathf.InverseLerp(num3, Mathf.Max(num3 + 0.001f, footingRecoveryFullForceShortfall), _shortfall);
				}
			}
		}
		if (footingRecovery && Object.op_Implicit((Object)(object)walkSystem))
		{
			float num4 = walkSystem.CompactFootingPull(ChainIndexForPoint(_index), out var _direction);
			if (num4 > 0f)
			{
				num = num4;
				Vector3[] array = footingRecoveryDirections;
				Vector3 val2 = _direction * Mathf.Max(0f, missingFootingHorizontalPull) + Vector3.down;
				array[_index] = val2.normalized;
			}
		}
		footingRecoveryWeights[_index] = Mathf.MoveTowards(footingRecoveryWeights[_index], num, Mathf.Max(0.01f, footingRecoveryResponse) * Time.fixedDeltaTime);
		footingRecoveryCandidates[_index] = footingRecoveryWeights[_index] > 0.001f && footingRecoveryDirections[_index].sqrMagnitude > 0.5f;
	}

	private void ApplyFootingRecoveryForces()
	{
		//IL_013d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0144: Unknown result type (might be due to invalid IL or missing references)
		//IL_0151: Unknown result type (might be due to invalid IL or missing references)
		missingFootingWeight = 0f;
		if (!footingRecovery || footingRecoveryWeights == null || !Object.op_Implicit((Object)(object)enemyRigidbody) || !Object.op_Implicit((Object)(object)enemyRigidbody.rb))
		{
			return;
		}
		float num = 0f;
		for (int i = 0; i < footingRecoveryWeights.Length; i++)
		{
			if (footingRecoveryCandidates[i] && !BodyPitchPointUnsupported(i))
			{
				num += footingRecoveryWeights[i];
			}
		}
		if (num <= 0.001f)
		{
			return;
		}
		float num2 = Mathf.Max(1f, num);
		float num3 = Mathf.Max(0f, footingRecoveryMaxAcceleration);
		for (int j = 0; j < footingRecoveryWeights.Length; j++)
		{
			if (footingRecoveryCandidates[j] && !BodyPitchPointUnsupported(j))
			{
				float num4 = (Object.op_Implicit((Object)(object)walkSystem) ? walkSystem.CompactFootingPull(ChainIndexForPoint(j), out var _) : 0f);
				missingFootingWeight = Mathf.Clamp01(missingFootingWeight + num4);
				float num5 = ((num4 > 0f) ? Mathf.Min(num3, Mathf.Max(0f, missingFootingMaxAcceleration)) : num3) * footingRecoveryWeights[j] / num2;
				enemyRigidbody.rb.AddForceAtPosition(footingRecoveryDirections[j] * num5, footingRecoveryForcePoints[j], (ForceMode)5);
			}
		}
		if (missingFootingWeight > 0.05f)
		{
			enemyRigidbody.DisableFollowPosition(0.1f, 3f);
			enemyRigidbody.WarpDisable(0.1f);
		}
	}

	private bool TryGetLegGround(int _index, Vector3 _origin, float _rayDistance, out Vector3 _point, out Collider _collider, out bool _usedLegSupport, out bool _usedDirectSupport)
	{
		//IL_0002: Unknown result type (might be due to invalid IL or missing references)
		//IL_0007: Unknown result type (might be due to invalid IL or missing references)
		//IL_00bf: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c4: Unknown result type (might be due to invalid IL or missing references)
		//IL_011b: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f0: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f6: Unknown result type (might be due to invalid IL or missing references)
		//IL_0177: Unknown result type (might be due to invalid IL or missing references)
		//IL_0178: Unknown result type (might be due to invalid IL or missing references)
		//IL_0160: Unknown result type (might be due to invalid IL or missing references)
		//IL_0162: Unknown result type (might be due to invalid IL or missing references)
		//IL_0137: Unknown result type (might be due to invalid IL or missing references)
		//IL_013d: Unknown result type (might be due to invalid IL or missing references)
		//IL_018d: Unknown result type (might be due to invalid IL or missing references)
		//IL_018f: Unknown result type (might be due to invalid IL or missing references)
		//IL_014e: Unknown result type (might be due to invalid IL or missing references)
		//IL_014f: Unknown result type (might be due to invalid IL or missing references)
		//IL_008e: Unknown result type (might be due to invalid IL or missing references)
		_point = Vector3.zero;
		_collider = null;
		_usedLegSupport = false;
		_usedDirectSupport = false;
		int num = ChainIndexForPoint(_index);
		Vector3 _normal;
		if (Object.op_Implicit((Object)(object)walkSystem) && num >= 0 && num < walkSystem.chains.Count)
		{
			BotSystemSpringPoseAnimatorWalk.WalkChain walkChain = walkSystem.chains[num];
			if (walkSystem.CompactFootingOwnsChain(walkChain))
			{
				if (walkChain.compactFootingState != BotSystemSpringPoseAnimatorWalk.CompactFootingState.Supported)
				{
					return false;
				}
				if (!walkSystem.TryGetStableGroundContact(num, out _point, out _normal, out _collider))
				{
					return false;
				}
				float num2 = _origin.y - _point.y;
				_usedLegSupport = num2 >= -0.05f && num2 <= _rayDistance + 0.1f;
				return _usedLegSupport;
			}
		}
		Vector3 _point2 = Vector3.zero;
		Collider _collider2 = null;
		bool flag = false;
		if (Object.op_Implicit((Object)(object)walkSystem) && walkSystem.TryGetStableGroundContact(ChainIndexForPoint(_index), out _point2, out _normal, out _collider2))
		{
			float num3 = _origin.y - _point2.y;
			flag = num3 >= -0.05f && num3 <= _rayDistance + 0.1f;
		}
		bool flag2 = TryGetDirectGround(_origin, _rayDistance, out var _point3, out var _collider3);
		if (flag & flag2)
		{
			if (IsPhysGrabGround(_collider2) && _point2.y > _point3.y + 0.005f)
			{
				_point = _point2;
				_collider = _collider2;
				_usedLegSupport = true;
			}
			else
			{
				_point = _point3;
				_collider = _collider3;
				_usedDirectSupport = true;
			}
			return true;
		}
		if (flag)
		{
			_point = _point2;
			_collider = _collider2;
			_usedLegSupport = true;
			return true;
		}
		if (flag2)
		{
			_point = _point3;
			_collider = _collider3;
			_usedDirectSupport = true;
			return true;
		}
		return false;
	}

	private bool TryGetDirectGround(Vector3 _origin, float _rayDistance, out Vector3 _point, out Collider _collider)
	{
		//IL_0001: Unknown result type (might be due to invalid IL or missing references)
		//IL_0006: Unknown result type (might be due to invalid IL or missing references)
		//IL_0015: Unknown result type (might be due to invalid IL or missing references)
		//IL_0016: Unknown result type (might be due to invalid IL or missing references)
		//IL_0023: Unknown result type (might be due to invalid IL or missing references)
		//IL_003f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0044: Unknown result type (might be due to invalid IL or missing references)
		//IL_0060: Unknown result type (might be due to invalid IL or missing references)
		//IL_0065: Unknown result type (might be due to invalid IL or missing references)
		//IL_0081: Unknown result type (might be due to invalid IL or missing references)
		//IL_0086: Unknown result type (might be due to invalid IL or missing references)
		_point = Vector3.zero;
		_collider = null;
		float num = float.MaxValue;
		int num2 = Physics.RaycastNonAlloc(_origin, Vector3.down, suspensionHits, _rayDistance, LayerMask.op_Implicit(groundMask), (QueryTriggerInteraction)1);
		for (int i = 0; i < num2; i++)
		{
			RaycastHit val = suspensionHits[i];
			if (!(val.distance >= num) && ValidSuspensionGround(val.collider) && !(Vector3.Dot(val.normal, Vector3.up) < 0.35f))
			{
				num = val.distance;
				_point = val.point;
				_collider = val.collider;
			}
		}
		return num < float.MaxValue;
	}

	private bool ValidSuspensionGround(Collider _collider)
	{
		if (!Object.op_Implicit((Object)(object)_collider) || !_collider.enabled || _collider.isTrigger || !((Component)_collider).gameObject.activeInHierarchy)
		{
			return false;
		}
		Transform root = ((Component)_collider).transform.root;
		Rigidbody attachedRigidbody = _collider.attachedRigidbody;
		if ((Object)(object)attachedRigidbody == (Object)(object)enemyRigidbody.rb)
		{
			return false;
		}
		if (suspensionGroundValidity.TryGetValue(_collider, out var value) && (Object)(object)value.root == (Object)(object)root && (Object)(object)value.attachedRigidbody == (Object)(object)attachedRigidbody)
		{
			return value.valid;
		}
		bool flag = !Object.op_Implicit((Object)(object)((Component)_collider).GetComponentInParent<EnemyRigidbody>());
		suspensionGroundValidity[_collider] = new SuspensionGroundCache
		{
			root = root,
			attachedRigidbody = attachedRigidbody,
			valid = flag
		};
		return flag;
	}

	private bool IsPhysGrabGround(Collider _collider)
	{
		if (!Object.op_Implicit((Object)(object)_collider))
		{
			return false;
		}
		return (physGrabLayerMask & (1 << ((Component)_collider).gameObject.layer)) != 0;
	}

	private int ChainIndexForPoint(int _pointIndex)
	{
		if (chainForPoint == null || chainForPoint.Length != suspensionPoints.Count)
		{
			BuildChainMap();
		}
		if (chainForPoint == null || _pointIndex < 0 || _pointIndex >= chainForPoint.Length)
		{
			return _pointIndex;
		}
		return chainForPoint[_pointIndex];
	}

	private void BuildChainMap()
	{
		//IL_00ff: Unknown result type (might be due to invalid IL or missing references)
		//IL_0110: Unknown result type (might be due to invalid IL or missing references)
		//IL_0115: Unknown result type (might be due to invalid IL or missing references)
		//IL_011a: Unknown result type (might be due to invalid IL or missing references)
		if (!Object.op_Implicit((Object)(object)walkSystem) || walkSystem.chains == null || walkSystem.chains.Count == 0)
		{
			return;
		}
		chainForPoint = new int[suspensionPoints.Count];
		bool[] array = new bool[walkSystem.chains.Count];
		for (int i = 0; i < suspensionPoints.Count; i++)
		{
			chainForPoint[i] = Mathf.Min(i, walkSystem.chains.Count - 1);
			if (!Object.op_Implicit((Object)(object)suspensionPoints[i]))
			{
				continue;
			}
			float num = float.MaxValue;
			int num2 = -1;
			for (int j = 0; j < walkSystem.chains.Count; j++)
			{
				if (array[j])
				{
					continue;
				}
				BotSystemSpringPoseAnimatorWalk.WalkChain walkChain = walkSystem.chains[j];
				if (walkChain != null && walkChain.bones != null && walkChain.bones.Count != 0 && Object.op_Implicit((Object)(object)walkChain.bones[0]))
				{
					Vector3 val = walkChain.bones[0].position - suspensionPoints[i].position;
					val.y = 0f;
					if (!(val.sqrMagnitude >= num))
					{
						num = val.sqrMagnitude;
						num2 = j;
					}
				}
			}
			if (num2 >= 0)
			{
				chainForPoint[i] = num2;
				array[num2] = true;
			}
		}
	}

	private void ApplyPhysObjectFootWeight()
	{
		//IL_0040: Unknown result type (might be due to invalid IL or missing references)
		//IL_0045: Unknown result type (might be due to invalid IL or missing references)
		//IL_007d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0082: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e0: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e8: Unknown result type (might be due to invalid IL or missing references)
		ResetPhysObjectFootWeight();
		if (!Object.op_Implicit((Object)(object)walkSystem) || !Object.op_Implicit((Object)(object)enemyRigidbody) || !Object.op_Implicit((Object)(object)enemyRigidbody.rb) || physObjectFootWeightMultiplier <= 0f)
		{
			return;
		}
		Vector3 gravity = Physics.gravity;
		if (gravity.sqrMagnitude <= 1E-06f)
		{
			return;
		}
		float num = enemyRigidbody.rb.mass * gravity.magnitude * physObjectFootWeightMultiplier / 4f;
		Vector3 normalized = gravity.normalized;
		PhysGrabObjectImpactDetector physGrabObjectImpactDetector = default;
		for (int i = 0; i < walkSystem.chains.Count; i++)
		{
			if (walkSystem.TryGetGroundedPhysGrabContact(i, out var _point, out var _rigidbody, out var _weight) && Object.op_Implicit((Object)(object)_rigidbody) && !_rigidbody.isKinematic && !((Object)(object)_rigidbody == (Object)(object)enemyRigidbody.rb))
			{
				if (((Component)_rigidbody).TryGetComponent<PhysGrabObjectImpactDetector>(ref physGrabObjectImpactDetector))
				{
					physGrabObjectImpactDetector.OverrideEnemyInvestigateDisable();
				}
				float num2 = num * _weight;
				_rigidbody.AddForceAtPosition(normalized * num2, _point, (ForceMode)0);
			}
		}
	}

	private void ResetPhysObjectFootWeight()
	{
	}

	private float GallopSuspensionWeight()
	{
		if (jumpBodyHeightOverrideTimer > 0f || !Object.op_Implicit((Object)(object)snatcherVisuals))
		{
			return 0f;
		}
		return snatcherVisuals.RigidbodyGallopStyleWeight();
	}

	private void GaitBobTargetTick()
	{
		float num = ((jumpBodyHeightOverrideTimer > 0f) ? jumpBodyHeightTargetSmoothTime : Mathf.Lerp(gaitBobTargetSmoothTime, gallopTargetSmoothTime, GallopSuspensionWeight()));
		float num2 = ((jumpBodyHeightOverrideTimer > 0f) ? jumpBodyHeightTargetMaxSpeed : Mathf.Lerp(gaitBobTargetMaxSpeed, gallopTargetMaxSpeed, GallopSuspensionWeight()));
		smoothedBodyBobTarget = Mathf.SmoothDamp(smoothedBodyBobTarget, bodyBobTarget, ref bodyBobTargetVelocity, Mathf.Max(0.005f, num), Mathf.Max(0.1f, num2), Time.fixedDeltaTime);
	}

	private void GaitBobBodyForce()
	{
		//IL_007a: Unknown result type (might be due to invalid IL or missing references)
		//IL_008d: Unknown result type (might be due to invalid IL or missing references)
		if (!(jumpBodyHeightOverrideTimer > 0f) && Object.op_Implicit((Object)(object)walkSystem) && !(walkSystem.walkWeight <= 0.001f) && groundContactCount > 0)
		{
			float num = smoothedBodyBobTarget - bodyBobResponse;
			float num2 = Mathf.Max(0f, gaitBobBodyMaxAcceleration);
			float num3 = Mathf.Clamp(num * Mathf.Max(0f, gaitBobBodyStrength), 0f - num2, num2);
			enemyRigidbody.rb.AddForce(Vector3.up * (num3 * (1f - GallopSuspensionWeight())), (ForceMode)5);
		}
	}

	private void GaitPitchTargetTick()
	{
		smoothedGaitPitchTarget = Mathf.SmoothDamp(smoothedGaitPitchTarget, gaitPitchTarget, ref gaitPitchTargetVelocity, Mathf.Max(0.01f, Mathf.Lerp(gaitPitchTargetSmoothTime, 0.035f, GallopSuspensionWeight())), Mathf.Max(1f, Mathf.Lerp(gaitPitchTargetMaxSpeed, 150f, GallopSuspensionWeight())), Time.fixedDeltaTime);
	}

	private void ResetGaitBob()
	{
		smoothedBodyBobTarget = 0f;
		bodyBobTargetVelocity = 0f;
		smoothedGaitPitchTarget = 0f;
		gaitPitchTargetVelocity = 0f;
		gaitPitchTarget = 0f;
		bodyBobResponse = 0f;
		groundContactCount = 0;
	}

	private void ResetFootingRecovery()
	{
		//IL_002c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0031: Unknown result type (might be due to invalid IL or missing references)
		//IL_003d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0042: Unknown result type (might be due to invalid IL or missing references)
		missingFootingWeight = 0f;
		if (footingRecoveryWeights != null)
		{
			for (int i = 0; i < footingRecoveryWeights.Length; i++)
			{
				footingRecoveryWeights[i] = 0f;
				footingRecoveryDirections[i] = Vector3.zero;
				footingRecoveryForcePoints[i] = Vector3.zero;
				footingRecoveryCandidates[i] = false;
			}
		}
	}

	private void GroundGrip(int _groundedCount)
	{
		//IL_0010: Unknown result type (might be due to invalid IL or missing references)
		//IL_0015: Unknown result type (might be due to invalid IL or missing references)
		//IL_002d: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0039: Unknown result type (might be due to invalid IL or missing references)
		//IL_0050: Unknown result type (might be due to invalid IL or missing references)
		//IL_0071: Unknown result type (might be due to invalid IL or missing references)
		//IL_0076: Unknown result type (might be due to invalid IL or missing references)
		//IL_0081: Unknown result type (might be due to invalid IL or missing references)
		//IL_0098: Unknown result type (might be due to invalid IL or missing references)
		if (_groundedCount > 0)
		{
			Vector3 linearVelocity = enemyRigidbody.rb.linearVelocity;
			linearVelocity.y = 0f;
			enemyRigidbody.rb.AddForce(-linearVelocity * groundGrip * (1f - missingFootingWeight * 0.5f), (ForceMode)5);
			enemyRigidbody.rb.AddTorque(-enemyRigidbody.rb.angularVelocity * angularGrip * (1f - missingFootingWeight * 0.5f), (ForceMode)5);
		}
	}

	private void TerrainAlignTorque()
	{
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0064: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0074: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c7: Unknown result type (might be due to invalid IL or missing references)
		//IL_00cc: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d0: Unknown result type (might be due to invalid IL or missing references)
		//IL_00df: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e4: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f0: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f5: Unknown result type (might be due to invalid IL or missing references)
		//IL_0163: Unknown result type (might be due to invalid IL or missing references)
		//IL_0170: Unknown result type (might be due to invalid IL or missing references)
		//IL_0175: Unknown result type (might be due to invalid IL or missing references)
		//IL_01d5: Unknown result type (might be due to invalid IL or missing references)
		//IL_01bc: Unknown result type (might be due to invalid IL or missing references)
		//IL_01be: Unknown result type (might be due to invalid IL or missing references)
		//IL_01c3: Unknown result type (might be due to invalid IL or missing references)
		//IL_01c8: Unknown result type (might be due to invalid IL or missing references)
		float num;
		Quaternion rotation;
		if (rearingOverrideTimer > 0f)
		{
			num = rearingBasePitch + rearingPitchOverride;
		}
		else
		{
			if (frontGroundHits > 0 && hindGroundHits > 0)
			{
				num = (0f - Mathf.Atan2(frontGroundAverage - hindGroundAverage, wheelbase)) * 57.29578f;
			}
			else
			{
				rotation = enemyRigidbody.rb.rotation;
				Vector3 eulerAngles = rotation.eulerAngles;
				num = Mathf.DeltaAngle(0f, eulerAngles.x) - Mathf.Atan2(frontErrorAverage - hindErrorAverage, wheelbase) * 57.29578f;
			}
			num = Mathf.Clamp(num + smoothedGaitPitchTarget, 0f - maxTerrainPitch, maxTerrainPitch);
		}
		float num2 = num;
		rotation = enemyRigidbody.rb.rotation;
		Quaternion val = Quaternion.Euler(num2, rotation.eulerAngles.y, 0f);
		float num3 = Quaternion.Angle(((Component)enemyRigidbody).transform.rotation, val);
		float num4 = ((rearingOverrideTimer > 0f) ? rearingTorqueOverride : uprightTorque) * Mathf.Clamp(num3 / Mathf.Max(0.1f, uprightTorqueDamping), 0f, 1f);
		num4 *= 1f - missingFootingWeight * 0.65f;
		if (!(num4 <= 0f))
		{
			Vector3 val2 = SemiFunc.PhysFollowRotation(((Component)enemyRigidbody).transform, val, enemyRigidbody.rb, num4);
			if (Object.op_Implicit((Object)(object)snatcherVisuals) && Object.op_Implicit((Object)(object)snatcherVisuals.enemySnatcher) && (snatcherVisuals.enemySnatcher.currentState == EnemySnatcher.State.BackKickTurn || snatcherVisuals.enemySnatcher.FrontPunchActive))
			{
				val2 = Vector3.ProjectOnPlane(val2, Vector3.up);
			}
			enemyRigidbody.rb.AddTorque(val2, (ForceMode)1);
		}
	}
}
