using UnityEngine;

public class SplashScreen : MonoBehaviour
{
	private enum State
	{
		Wait,
		Semiwork,
		Warning,
		Done
	}

	public static SplashScreen instance;

	private State state;

	private float stateTimer;

	private bool stateImpulse;

	[Space]
	public AnimationCurve semiworkCurveIntro;

	private float semiworkCurveLerp;

	[Space]
	public AnimationCurve warningCurveIntro;

	private float warningCurveLerp;

	[Space]
	public Sound warningSound;

	[RuntimeInitializeOnLoadMethod(/*Could not decode attribute arguments.*/)]
	private static void RuntimeInitializeOnLoad()
	{
		instance = null;
	}

	private void Awake()
	{
		instance = this;
	}

	private void Start()
	{
		StateSet(State.Wait);
	}

	private void Update()
	{
		switch (state)
		{
		case State.Wait:
			StateWait();
			break;
		case State.Semiwork:
			StateSemiwork();
			break;
		case State.Warning:
			StateWarning();
			break;
		case State.Done:
			StateDone();
			break;
		}
		SkipLogic();
		SemiworkAnimation();
		WarningAnimation();
	}

	private void StateWait()
	{
		VideoOverlay.Instance.Override(0.1f, 1f, 20f);
		if (GameDirector.instance.currentState == GameDirector.gameState.Main)
		{
			StateSet(State.Semiwork);
		}
	}

	private void StateSemiwork()
	{
		if (stateImpulse)
		{
			stateImpulse = false;
			stateTimer = 2f;
			((Component)SplashScreenUI.instance.semiworkTransform).gameObject.SetActive(true);
		}
		VideoOverlay.Instance.Override(0.1f, 0.02f, 2f);
		stateTimer -= Time.deltaTime;
		if (stateTimer <= 0f)
		{
			((Component)SplashScreenUI.instance.semiworkTransform).gameObject.SetActive(false);
			StateSet(State.Warning);
		}
	}

	private void StateWarning()
	{
		//IL_003b: Unknown result type (might be due to invalid IL or missing references)
		if (stateImpulse)
		{
			stateImpulse = false;
			stateTimer = 6f;
			((Component)SplashScreenUI.instance.warningTransform).gameObject.SetActive(true);
			warningSound.Play(((Component)this).transform.position);
		}
		VideoOverlay.Instance.Override(0.1f, 0.02f, 5f);
		stateTimer -= Time.deltaTime;
		if (stateTimer <= 0f)
		{
			StateSet(State.Done);
		}
	}

	private void StateDone()
	{
		if (stateImpulse)
		{
			stateImpulse = false;
			SemiFunc.SplashScreenCompleted();
			((Component)SplashScreenUI.instance).gameObject.SetActive(false);
			if (SteamLobbyManager.instance.lobbyIdToAutoJoin != 0L)
			{
				SteamLobbyManager.instance.StartAutoJoiningLobby();
				return;
			}
			RunManager.instance.skipLoadingUI = true;
			GameDirector.instance.OutroStart();
			ResultScreenUI.instance.Disable();
			NetworkManager.instance.leavePhotonRoom = true;
		}
	}

	private void StateSet(State _state)
	{
		if (state != _state)
		{
			state = _state;
			stateTimer = 0f;
			stateImpulse = true;
		}
	}

	private void SemiworkAnimation()
	{
		//IL_003d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0042: Unknown result type (might be due to invalid IL or missing references)
		//IL_004c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0062: Unknown result type (might be due to invalid IL or missing references)
		if (state == State.Semiwork)
		{
			semiworkCurveLerp += Time.deltaTime * 5f;
			semiworkCurveLerp = Mathf.Clamp01(semiworkCurveLerp);
			SplashScreenUI.instance.semiworkTransform.anchoredPosition = Vector2.LerpUnclamped(Vector2.zero, Vector2.up * 10f, semiworkCurveIntro.Evaluate(semiworkCurveLerp));
		}
	}

	private void WarningAnimation()
	{
		//IL_003d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0042: Unknown result type (might be due to invalid IL or missing references)
		//IL_004c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0062: Unknown result type (might be due to invalid IL or missing references)
		if (state == State.Warning)
		{
			warningCurveLerp += Time.deltaTime * 5f;
			warningCurveLerp = Mathf.Clamp01(warningCurveLerp);
			SplashScreenUI.instance.warningTransform.anchoredPosition = Vector2.LerpUnclamped(Vector2.zero, Vector2.up * 5f, warningCurveIntro.Evaluate(warningCurveLerp));
		}
	}

	private void SkipLogic()
	{
		if (state > State.Wait && DataDirector.instance.SettingValueFetch(DataDirector.Setting.SplashScreenCount) >= RunManager.instance.splashScreenLatestVersion && Input.anyKeyDown)
		{
			StateSet(State.Done);
		}
	}
}
