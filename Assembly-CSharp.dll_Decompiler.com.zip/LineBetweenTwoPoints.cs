using System;
using UnityEngine;
using UnityEngine.Rendering;

public class LineBetweenTwoPoints : MonoBehaviour
{
	public bool hasSpheres = true;

	public bool hasLights;

	public Light point1Light;

	public Light point2Light;

	public float lightRadius = 5f;

	public float lightIntensity = 1f;

	private float currentLightIntensity;

	private float hitFlashTimer;

	private float hitFlashIntensity;

	public bool hasParticles;

	public ParticleSystem point1Particles;

	private ParticleSystem point2Particles;

	private ParticleSystemRenderer[] particle1Renderers;

	private ParticleSystemRenderer[] particle2Renderers;

	private ParticleSystem[] particle1Systems;

	private ParticleSystem[] particle2Systems;

	private GameObject line;

	private GameObject sphere1;

	private GameObject sphere2;

	private Color lineColor = Color.white;

	private LineRenderer lineRenderer;

	private Vector3 pointA;

	private Vector3 pointB;

	private float lineRenderLifetime;

	private bool initialized;

	private int lineSegments = 10;

	public float baseWidth = 0.05f;

	public float baseWidthOscillation = 0.025f;

	private Vector3[] scrambleOffsets;

	private float introProgress;

	public float animationDuration = 0.1f;

	private Vector3 lastPoint1;

	private Vector3 lastPoint2;

	private bool wasDrawnLastFrame;

	private bool drawnThisFrame;

	public void SetColor(Color color)
	{
		//IL_0001: Unknown result type (might be due to invalid IL or missing references)
		//IL_0002: Unknown result type (might be due to invalid IL or missing references)
		lineColor = color;
		if (initialized)
		{
			ApplyColor();
		}
	}

	private void ApplyColor()
	{
		//IL_001f: Unknown result type (might be due to invalid IL or missing references)
		//IL_003a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0055: Unknown result type (might be due to invalid IL or missing references)
		//IL_0082: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a2: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c2: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ef: Unknown result type (might be due to invalid IL or missing references)
		//IL_010f: Unknown result type (might be due to invalid IL or missing references)
		//IL_012f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0155: Unknown result type (might be due to invalid IL or missing references)
		//IL_0173: Unknown result type (might be due to invalid IL or missing references)
		//IL_01be: Unknown result type (might be due to invalid IL or missing references)
		//IL_01d4: Unknown result type (might be due to invalid IL or missing references)
		//IL_01ea: Unknown result type (might be due to invalid IL or missing references)
		//IL_0331: Unknown result type (might be due to invalid IL or missing references)
		//IL_0336: Unknown result type (might be due to invalid IL or missing references)
		//IL_033b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0340: Unknown result type (might be due to invalid IL or missing references)
		//IL_034a: Unknown result type (might be due to invalid IL or missing references)
		//IL_034f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0286: Unknown result type (might be due to invalid IL or missing references)
		//IL_029c: Unknown result type (might be due to invalid IL or missing references)
		//IL_02b2: Unknown result type (might be due to invalid IL or missing references)
		//IL_020d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0223: Unknown result type (might be due to invalid IL or missing references)
		//IL_0239: Unknown result type (might be due to invalid IL or missing references)
		//IL_0390: Unknown result type (might be due to invalid IL or missing references)
		//IL_0395: Unknown result type (might be due to invalid IL or missing references)
		//IL_039a: Unknown result type (might be due to invalid IL or missing references)
		//IL_039f: Unknown result type (might be due to invalid IL or missing references)
		//IL_03a9: Unknown result type (might be due to invalid IL or missing references)
		//IL_03ae: Unknown result type (might be due to invalid IL or missing references)
		//IL_035d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0362: Unknown result type (might be due to invalid IL or missing references)
		//IL_02d5: Unknown result type (might be due to invalid IL or missing references)
		//IL_02eb: Unknown result type (might be due to invalid IL or missing references)
		//IL_0301: Unknown result type (might be due to invalid IL or missing references)
		//IL_03bc: Unknown result type (might be due to invalid IL or missing references)
		//IL_03c1: Unknown result type (might be due to invalid IL or missing references)
		if (!Object.op_Implicit((Object)(object)lineRenderer))
		{
			return;
		}
		((Renderer)lineRenderer).material.SetColor("_EmissionColor", lineColor);
		((Renderer)lineRenderer).material.SetColor("_Color", lineColor);
		((Renderer)lineRenderer).material.SetColor("_AlbedoColor", lineColor);
		if (Object.op_Implicit((Object)(object)sphere1))
		{
			((Renderer)sphere1.GetComponent<MeshRenderer>()).material.SetColor("_EmissionColor", lineColor);
			((Renderer)sphere1.GetComponent<MeshRenderer>()).material.SetColor("_Color", lineColor);
			((Renderer)sphere1.GetComponent<MeshRenderer>()).material.SetColor("_AlbedoColor", lineColor);
		}
		if (Object.op_Implicit((Object)(object)sphere2))
		{
			((Renderer)sphere2.GetComponent<MeshRenderer>()).material.SetColor("_EmissionColor", lineColor);
			((Renderer)sphere2.GetComponent<MeshRenderer>()).material.SetColor("_Color", lineColor);
			((Renderer)sphere2.GetComponent<MeshRenderer>()).material.SetColor("_AlbedoColor", lineColor);
		}
		if (hasLights)
		{
			if (Object.op_Implicit((Object)(object)point1Light))
			{
				point1Light.color = lineColor;
			}
			if (Object.op_Implicit((Object)(object)point2Light))
			{
				point2Light.color = lineColor;
			}
		}
		if (!hasParticles)
		{
			return;
		}
		if (particle1Renderers != null)
		{
			ParticleSystemRenderer[] array = particle1Renderers;
			foreach (ParticleSystemRenderer val in array)
			{
				if (Object.op_Implicit((Object)(object)((Renderer)val).material))
				{
					((Renderer)val).material.SetColor("_EmissionColor", lineColor);
					((Renderer)val).material.SetColor("_Color", lineColor);
					((Renderer)val).material.SetColor("_AlbedoColor", lineColor);
				}
				if (Object.op_Implicit((Object)(object)val.trailMaterial))
				{
					val.trailMaterial.SetColor("_EmissionColor", lineColor);
					val.trailMaterial.SetColor("_Color", lineColor);
					val.trailMaterial.SetColor("_AlbedoColor", lineColor);
				}
			}
		}
		if (particle2Renderers != null)
		{
			ParticleSystemRenderer[] array = particle2Renderers;
			foreach (ParticleSystemRenderer val2 in array)
			{
				if (Object.op_Implicit((Object)(object)((Renderer)val2).material))
				{
					((Renderer)val2).material.SetColor("_EmissionColor", lineColor);
					((Renderer)val2).material.SetColor("_Color", lineColor);
					((Renderer)val2).material.SetColor("_AlbedoColor", lineColor);
				}
				if (Object.op_Implicit((Object)(object)val2.trailMaterial))
				{
					val2.trailMaterial.SetColor("_EmissionColor", lineColor);
					val2.trailMaterial.SetColor("_Color", lineColor);
					val2.trailMaterial.SetColor("_AlbedoColor", lineColor);
				}
			}
		}
		ParticleSystem[] array2;
		if (particle1Systems != null)
		{
			array2 = particle1Systems;
			foreach (ParticleSystem obj in array2)
			{
				MainModule main = obj.main;
				main.startColor = MinMaxGradient.op_Implicit(lineColor);
				TrailModule trails = obj.trails;
				if (trails.enabled)
				{
					trails.colorOverTrail = MinMaxGradient.op_Implicit(lineColor);
				}
			}
		}
		if (particle2Systems == null)
		{
			return;
		}
		array2 = particle2Systems;
		foreach (ParticleSystem obj2 in array2)
		{
			MainModule main2 = obj2.main;
			main2.startColor = MinMaxGradient.op_Implicit(lineColor);
			TrailModule trails2 = obj2.trails;
			if (trails2.enabled)
			{
				trails2.colorOverTrail = MinMaxGradient.op_Implicit(lineColor);
			}
		}
	}

	private void Start()
	{
		Transform val = ((Component)this).transform.Find("Line");
		if (Object.op_Implicit((Object)(object)val))
		{
			line = ((Component)val).gameObject;
		}
		Transform val2 = ((Component)this).transform.Find("Sphere1");
		if (Object.op_Implicit((Object)(object)val2))
		{
			sphere1 = ((Component)val2).gameObject;
		}
		Transform val3 = ((Component)this).transform.Find("Sphere2");
		if (Object.op_Implicit((Object)(object)val3))
		{
			sphere2 = ((Component)val3).gameObject;
		}
		if (Object.op_Implicit((Object)(object)line))
		{
			lineRenderer = line.GetComponent<LineRenderer>();
			line.SetActive(false);
			lineRenderer.positionCount = lineSegments;
			((Renderer)lineRenderer).enabled = false;
		}
		scrambleOffsets = new Vector3[lineSegments];
		GenerateScrambleOffsets();
		if (Object.op_Implicit((Object)(object)sphere1))
		{
			((Renderer)sphere1.GetComponent<MeshRenderer>()).enabled = false;
		}
		if (Object.op_Implicit((Object)(object)sphere2))
		{
			((Renderer)sphere2.GetComponent<MeshRenderer>()).enabled = false;
		}
		if (hasLights)
		{
			if (Object.op_Implicit((Object)(object)point1Light))
			{
				point1Light.range = lightRadius;
				point1Light.intensity = 0f;
				((Behaviour)point1Light).enabled = false;
			}
			if (Object.op_Implicit((Object)(object)point2Light))
			{
				point2Light.range = lightRadius;
				point2Light.intensity = 0f;
				((Behaviour)point2Light).enabled = false;
			}
		}
		if (hasParticles && Object.op_Implicit((Object)(object)point1Particles))
		{
			particle1Renderers = ((Component)point1Particles).GetComponentsInChildren<ParticleSystemRenderer>(true);
			particle1Systems = ((Component)point1Particles).GetComponentsInChildren<ParticleSystem>(true);
			point1Particles.Stop(true);
			GameObject val4 = Object.Instantiate<GameObject>(((Component)point1Particles).gameObject, ((Component)this).transform);
			point2Particles = val4.GetComponent<ParticleSystem>();
			particle2Renderers = val4.GetComponentsInChildren<ParticleSystemRenderer>(true);
			particle2Systems = val4.GetComponentsInChildren<ParticleSystem>(true);
			point2Particles.Stop(true);
			InstantiateParticleMaterials(particle1Renderers);
			InstantiateParticleMaterials(particle2Renderers);
		}
		ApplyColor();
		if (!hasSpheres)
		{
			Object.Destroy((Object)(object)sphere1);
			Object.Destroy((Object)(object)sphere2);
		}
		initialized = true;
	}

	private void Update()
	{
		//IL_003d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0070: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a3: Unknown result type (might be due to invalid IL or missing references)
		if (Object.op_Implicit((Object)(object)lineRenderer) && ((Renderer)lineRenderer).enabled)
		{
			float num = 2f;
			((Renderer)lineRenderer).material.mainTextureOffset = new Vector2(Time.time * num, 0f);
			if (Object.op_Implicit((Object)(object)sphere1))
			{
				((Renderer)sphere1.GetComponent<MeshRenderer>()).material.mainTextureOffset = new Vector2(Time.time * num, 0f);
			}
			if (Object.op_Implicit((Object)(object)sphere2))
			{
				((Renderer)sphere2.GetComponent<MeshRenderer>()).material.mainTextureOffset = new Vector2(Time.time * num, 0f);
			}
			if (lineRenderLifetime <= 0f)
			{
				((Renderer)lineRenderer).enabled = false;
				((Component)lineRenderer).gameObject.SetActive(false);
				if (Object.op_Implicit((Object)(object)sphere1))
				{
					((Renderer)sphere1.GetComponent<MeshRenderer>()).enabled = false;
				}
				if (Object.op_Implicit((Object)(object)sphere2))
				{
					((Renderer)sphere2.GetComponent<MeshRenderer>()).enabled = false;
				}
				StopLightsAndParticles();
			}
			else
			{
				lineRenderLifetime -= Time.deltaTime;
			}
		}
		UpdateLightAnimation();
	}

	private void UpdateLightAnimation()
	{
		if (!hasLights)
		{
			return;
		}
		bool flag = drawnThisFrame || ((Renderer)lineRenderer).enabled;
		float num = (flag ? lightIntensity : 0f);
		currentLightIntensity = Mathf.Lerp(currentLightIntensity, num, Time.deltaTime * 10f);
		float intensity = currentLightIntensity * introProgress;
		if (Object.op_Implicit((Object)(object)point1Light))
		{
			((Behaviour)point1Light).enabled = flag || currentLightIntensity > 0.01f;
			point1Light.intensity = intensity;
		}
		if (Object.op_Implicit((Object)(object)point2Light))
		{
			((Behaviour)point2Light).enabled = flag || currentLightIntensity > 0.01f;
			point2Light.intensity = intensity;
		}
		if (hitFlashTimer > 0f)
		{
			if (Object.op_Implicit((Object)(object)point2Light))
			{
				((Behaviour)point2Light).enabled = true;
				point2Light.intensity = hitFlashIntensity;
			}
			hitFlashTimer -= Time.deltaTime;
		}
	}

	private void StartLightsAndParticles(Vector3 point1, Vector3 point2)
	{
		//IL_0020: Unknown result type (might be due to invalid IL or missing references)
		//IL_007f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0090: Unknown result type (might be due to invalid IL or missing references)
		//IL_004a: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c7: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d8: Unknown result type (might be due to invalid IL or missing references)
		if (hasLights)
		{
			if (Object.op_Implicit((Object)(object)point1Light))
			{
				((Component)point1Light).transform.position = point1;
				((Behaviour)point1Light).enabled = true;
			}
			if (Object.op_Implicit((Object)(object)point2Light))
			{
				((Component)point2Light).transform.position = point2;
				((Behaviour)point2Light).enabled = true;
			}
		}
		if (!hasParticles)
		{
			return;
		}
		if (Object.op_Implicit((Object)(object)point1Particles))
		{
			((Component)point1Particles).transform.position = point1;
			((Component)point1Particles).transform.LookAt(point2);
			if (!point1Particles.isPlaying)
			{
				point1Particles.Play(true);
			}
		}
		if (Object.op_Implicit((Object)(object)point2Particles))
		{
			((Component)point2Particles).transform.position = point2;
			((Component)point2Particles).transform.LookAt(point1);
			if (!point2Particles.isPlaying)
			{
				point2Particles.Play(true);
			}
		}
	}

	private void UpdateLightsAndParticlesPositions(Vector3 point1, Vector3 point2)
	{
		//IL_0020: Unknown result type (might be due to invalid IL or missing references)
		//IL_0064: Unknown result type (might be due to invalid IL or missing references)
		//IL_0075: Unknown result type (might be due to invalid IL or missing references)
		//IL_003e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0093: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a4: Unknown result type (might be due to invalid IL or missing references)
		if (hasLights)
		{
			if (Object.op_Implicit((Object)(object)point1Light))
			{
				((Component)point1Light).transform.position = point1;
			}
			if (Object.op_Implicit((Object)(object)point2Light))
			{
				((Component)point2Light).transform.position = point2;
			}
		}
		if (hasParticles)
		{
			if (Object.op_Implicit((Object)(object)point1Particles))
			{
				((Component)point1Particles).transform.position = point1;
				((Component)point1Particles).transform.LookAt(point2);
			}
			if (Object.op_Implicit((Object)(object)point2Particles))
			{
				((Component)point2Particles).transform.position = point2;
				((Component)point2Particles).transform.LookAt(point1);
			}
		}
	}

	private void InstantiateParticleMaterials(ParticleSystemRenderer[] renderers)
	{
		//IL_0022: Unknown result type (might be due to invalid IL or missing references)
		//IL_002c: Expected Obj, but got Unknown
		//IL_0040: Unknown result type (might be due to invalid IL or missing references)
		//IL_004a: Expected Obj, but got Unknown
		if (renderers == null)
		{
			return;
		}
		foreach (ParticleSystemRenderer val in renderers)
		{
			if (Object.op_Implicit((Object)(object)((Renderer)val).sharedMaterial))
			{
				((Renderer)val).material = new Material(((Renderer)val).sharedMaterial);
			}
			if (Object.op_Implicit((Object)(object)val.trailMaterial))
			{
				val.trailMaterial = new Material(val.trailMaterial);
			}
		}
	}

	private void StopLightsAndParticles()
	{
		if (hasParticles)
		{
			if (Object.op_Implicit((Object)(object)point1Particles) && point1Particles.isPlaying)
			{
				point1Particles.Stop();
			}
			if (Object.op_Implicit((Object)(object)point2Particles) && point2Particles.isPlaying)
			{
				point2Particles.Stop();
			}
		}
	}

	private void LateUpdate()
	{
		//IL_0011: Unknown result type (might be due to invalid IL or missing references)
		//IL_0016: Unknown result type (might be due to invalid IL or missing references)
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002a: Unknown result type (might be due to invalid IL or missing references)
		if (wasDrawnLastFrame && !drawnThisFrame && lastPoint1 != Vector3.zero)
		{
			CreateOutroCopy(lastPoint1, lastPoint2);
			StopLightsAndParticles();
		}
		wasDrawnLastFrame = drawnThisFrame;
		drawnThisFrame = false;
	}

	public void DrawLine(Vector3 point1, Vector3 point2)
	{
		//IL_0058: Unknown result type (might be due to invalid IL or missing references)
		//IL_0087: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d2: Unknown result type (might be due to invalid IL or missing references)
		//IL_012c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0139: Unknown result type (might be due to invalid IL or missing references)
		//IL_014b: Unknown result type (might be due to invalid IL or missing references)
		//IL_014c: Unknown result type (might be due to invalid IL or missing references)
		//IL_011b: Unknown result type (might be due to invalid IL or missing references)
		drawnThisFrame = true;
		introProgress = 1f;
		((Component)lineRenderer).gameObject.SetActive(true);
		((Renderer)lineRenderer).enabled = true;
		if (Object.op_Implicit((Object)(object)sphere1))
		{
			((Renderer)sphere1.GetComponent<MeshRenderer>()).enabled = true;
			sphere1.transform.position = point1;
		}
		if (Object.op_Implicit((Object)(object)sphere2))
		{
			((Renderer)sphere2.GetComponent<MeshRenderer>()).enabled = true;
			sphere2.transform.position = point2;
		}
		float num = 2f;
		if (Object.op_Implicit((Object)(object)sphere1))
		{
			sphere1.transform.localScale = new Vector3(lineRenderer.startWidth * num, lineRenderer.startWidth * num, lineRenderer.startWidth * num);
		}
		if (Object.op_Implicit((Object)(object)sphere2))
		{
			sphere2.transform.localScale = new Vector3(lineRenderer.endWidth * num, lineRenderer.endWidth * num, lineRenderer.endWidth * num);
		}
		lineRenderer.SetPosition(0, point1);
		lineRenderer.SetPosition(1, point2);
		lineRenderLifetime = 0.01f;
		StartLightsAndParticles(point1, point2);
	}

	private void GenerateScrambleOffsets()
	{
		//IL_0051: Unknown result type (might be due to invalid IL or missing references)
		//IL_0056: Unknown result type (might be due to invalid IL or missing references)
		if (scrambleOffsets == null)
		{
			scrambleOffsets = new Vector3[lineSegments];
		}
		for (int i = 0; i < lineSegments; i++)
		{
			scrambleOffsets[i] = new Vector3(Random.Range(-1f, 1f), Random.Range(-1f, 1f), Random.Range(-1f, 1f));
		}
	}

	public void DrawLineAnimated(Vector3 point1, Vector3 point2)
	{
		//IL_007f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0080: Unknown result type (might be due to invalid IL or missing references)
		//IL_0086: Unknown result type (might be due to invalid IL or missing references)
		//IL_0087: Unknown result type (might be due to invalid IL or missing references)
		//IL_0042: Unknown result type (might be due to invalid IL or missing references)
		//IL_0043: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b4: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b5: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b8: Unknown result type (might be due to invalid IL or missing references)
		//IL_00bd: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d6: Unknown result type (might be due to invalid IL or missing references)
		//IL_00dd: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ed: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f2: Unknown result type (might be due to invalid IL or missing references)
		//IL_00fc: Unknown result type (might be due to invalid IL or missing references)
		//IL_00fe: Unknown result type (might be due to invalid IL or missing references)
		//IL_0100: Unknown result type (might be due to invalid IL or missing references)
		//IL_0193: Unknown result type (might be due to invalid IL or missing references)
		//IL_01bd: Unknown result type (might be due to invalid IL or missing references)
		//IL_0225: Unknown result type (might be due to invalid IL or missing references)
		//IL_0226: Unknown result type (might be due to invalid IL or missing references)
		//IL_01f0: Unknown result type (might be due to invalid IL or missing references)
		//IL_021a: Unknown result type (might be due to invalid IL or missing references)
		if (!wasDrawnLastFrame && !drawnThisFrame)
		{
			introProgress = 0f;
			lineRenderer.startWidth = 0f;
			lineRenderer.endWidth = 0f;
			GenerateScrambleOffsets();
			StartLightsAndParticles(point1, point2);
		}
		drawnThisFrame = true;
		((Component)lineRenderer).gameObject.SetActive(true);
		((Renderer)lineRenderer).enabled = true;
		lineRenderer.positionCount = lineSegments;
		lastPoint1 = point1;
		lastPoint2 = point2;
		float num = 1f - introProgress;
		float num2 = introProgress;
		for (int i = 0; i < lineSegments; i++)
		{
			float num3 = (float)i / (float)(lineSegments - 1);
			Vector3 val = Vector3.Lerp(point1, point2, num3);
			float num4 = Mathf.Sin(num3 * MathF.PI);
			Vector3 val2 = scrambleOffsets[i] * num4 * num * 0.15f;
			lineRenderer.SetPosition(i, val + val2);
		}
		float num5 = baseWidth * num2;
		float num6 = baseWidthOscillation * num2;
		lineRenderer.startWidth = num5 + Mathf.Sin(Time.time * 5f) * num6;
		lineRenderer.endWidth = num5 + Mathf.Cos(Time.time * 5f) * num6;
		if (Object.op_Implicit((Object)(object)sphere1))
		{
			((Renderer)sphere1.GetComponent<MeshRenderer>()).enabled = true;
			sphere1.transform.position = point1;
			float num7 = lineRenderer.startWidth * 2f;
			sphere1.transform.localScale = new Vector3(num7, num7, num7);
		}
		if (Object.op_Implicit((Object)(object)sphere2))
		{
			((Renderer)sphere2.GetComponent<MeshRenderer>()).enabled = true;
			sphere2.transform.position = point2;
			float num8 = lineRenderer.endWidth * 2f;
			sphere2.transform.localScale = new Vector3(num8, num8, num8);
		}
		UpdateLightsAndParticlesPositions(point1, point2);
		lineRenderLifetime = 0.01f;
		if (introProgress < 1f)
		{
			introProgress += Time.deltaTime / animationDuration;
			if (introProgress > 1f)
			{
				introProgress = 1f;
			}
		}
	}

	public void DrawLineLightning(Vector3 _point1, Vector3 _point2, float _width, float _flashIntensity, float _seed)
	{
		//IL_0001: Unknown result type (might be due to invalid IL or missing references)
		//IL_0002: Unknown result type (might be due to invalid IL or missing references)
		//IL_003e: Unknown result type (might be due to invalid IL or missing references)
		//IL_004a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0088: Unknown result type (might be due to invalid IL or missing references)
		//IL_0089: Unknown result type (might be due to invalid IL or missing references)
		//IL_006c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0078: Unknown result type (might be due to invalid IL or missing references)
		DrawLineAnimated(_point1, _point2);
		lineRenderer.startWidth = _width;
		lineRenderer.endWidth = _width * 0.65f;
		if (Object.op_Implicit((Object)(object)sphere1))
		{
			sphere1.transform.localScale = Vector3.one * (_width * 2f);
		}
		if (Object.op_Implicit((Object)(object)sphere2))
		{
			sphere2.transform.localScale = Vector3.one * (_width * 1.3f);
		}
		DrawLightningArc(lineRenderer, _point1, _point2, _seed);
		hitFlashIntensity = _flashIntensity;
		hitFlashTimer = 0.1f;
	}

	public static void DrawLightningArc(LineRenderer _line, Vector3 _point1, Vector3 _point2, float _seed, float _amount = 1f)
	{
		//IL_0000: Unknown result type (might be due to invalid IL or missing references)
		//IL_0001: Unknown result type (might be due to invalid IL or missing references)
		//IL_0002: Unknown result type (might be due to invalid IL or missing references)
		//IL_0007: Unknown result type (might be due to invalid IL or missing references)
		//IL_000a: Unknown result type (might be due to invalid IL or missing references)
		//IL_000f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0010: Unknown result type (might be due to invalid IL or missing references)
		//IL_0011: Unknown result type (might be due to invalid IL or missing references)
		//IL_0016: Unknown result type (might be due to invalid IL or missing references)
		//IL_001b: Unknown result type (might be due to invalid IL or missing references)
		//IL_003d: Unknown result type (might be due to invalid IL or missing references)
		//IL_003e: Unknown result type (might be due to invalid IL or missing references)
		//IL_003f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0044: Unknown result type (might be due to invalid IL or missing references)
		//IL_0048: Unknown result type (might be due to invalid IL or missing references)
		//IL_004d: Unknown result type (might be due to invalid IL or missing references)
		//IL_002a: Unknown result type (might be due to invalid IL or missing references)
		//IL_002b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0030: Unknown result type (might be due to invalid IL or missing references)
		//IL_0035: Unknown result type (might be due to invalid IL or missing references)
		//IL_0104: Unknown result type (might be due to invalid IL or missing references)
		//IL_010a: Unknown result type (might be due to invalid IL or missing references)
		//IL_010f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0118: Unknown result type (might be due to invalid IL or missing references)
		//IL_011d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0124: Unknown result type (might be due to invalid IL or missing references)
		//IL_0129: Unknown result type (might be due to invalid IL or missing references)
		//IL_012e: Unknown result type (might be due to invalid IL or missing references)
		//IL_012f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0132: Unknown result type (might be due to invalid IL or missing references)
		//IL_0137: Unknown result type (might be due to invalid IL or missing references)
		//IL_013b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0140: Unknown result type (might be due to invalid IL or missing references)
		Vector3 val = _point2 - _point1;
		Vector3 normalized = val.normalized;
		Vector3 val2 = Vector3.Cross(normalized, Vector3.up);
		if (val2.sqrMagnitude < 0.001f)
		{
			val2 = Vector3.Cross(normalized, Vector3.right);
		}
		val2.Normalize();
		Vector3 val3 = Vector3.Cross(val2, normalized);
		Vector3 normalized2 = val3.normalized;
		float magnitude = val.magnitude;
		float num = Mathf.Min(magnitude * 0.2f, 0.65f);
		float num2 = Mathf.Min(magnitude * 0.12f, 0.28f);
		float num3 = Mathf.Floor(Time.time * 45f);
		for (int i = 0; i < _line.positionCount; i++)
		{
			float num4 = (float)i / (float)(_line.positionCount - 1);
			float num5 = Mathf.Sin(num4 * MathF.PI);
			float num6 = Mathf.PerlinNoise(_seed + (float)i * 13.7f, num3 * 1.73f) * 2f - 1f;
			float num7 = Mathf.PerlinNoise(_seed + (float)i * 7.3f + 91f, num3 * 2.17f) * 2f - 1f;
			Vector3 val4 = (val2 * (num6 * num2) + normalized2 * (num + num7 * num2)) * num5;
			_line.SetPosition(i, Vector3.Lerp(_point1, _point2, num4) + val4 * _amount);
		}
	}

	public void TriggerPointSwitch()
	{
		//IL_0001: Unknown result type (might be due to invalid IL or missing references)
		//IL_0006: Unknown result type (might be due to invalid IL or missing references)
		//IL_0014: Unknown result type (might be due to invalid IL or missing references)
		//IL_001a: Unknown result type (might be due to invalid IL or missing references)
		if (lastPoint1 != Vector3.zero)
		{
			CreateOutroCopy(lastPoint1, lastPoint2);
		}
		introProgress = 0f;
		GenerateScrambleOffsets();
	}

	private void CreateOutroCopy(Vector3 point1, Vector3 point2)
	{
		//IL_0005: Unknown result type (might be due to invalid IL or missing references)
		//IL_000b: Expected Obj, but got Unknown
		//IL_0011: Unknown result type (might be due to invalid IL or missing references)
		//IL_003a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0044: Expected Obj, but got Unknown
		//IL_008b: Unknown result type (might be due to invalid IL or missing references)
		//IL_008c: Unknown result type (might be due to invalid IL or missing references)
		//IL_008f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0276: Unknown result type (might be due to invalid IL or missing references)
		//IL_0277: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e5: Unknown result type (might be due to invalid IL or missing references)
		//IL_00fc: Unknown result type (might be due to invalid IL or missing references)
		//IL_011d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0127: Expected Obj, but got Unknown
		//IL_014c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0163: Unknown result type (might be due to invalid IL or missing references)
		//IL_0184: Unknown result type (might be due to invalid IL or missing references)
		//IL_018e: Expected Obj, but got Unknown
		//IL_01dc: Unknown result type (might be due to invalid IL or missing references)
		//IL_01e1: Unknown result type (might be due to invalid IL or missing references)
		//IL_01e7: Unknown result type (might be due to invalid IL or missing references)
		//IL_01f7: Unknown result type (might be due to invalid IL or missing references)
		//IL_0228: Unknown result type (might be due to invalid IL or missing references)
		//IL_022d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0233: Unknown result type (might be due to invalid IL or missing references)
		//IL_0243: Unknown result type (might be due to invalid IL or missing references)
		GameObject val = new GameObject("BeamOutroCopy");
		val.transform.position = Vector3.zero;
		LineRenderer val2 = val.AddComponent<LineRenderer>();
		val2.positionCount = lineSegments;
		((Renderer)val2).material = new Material(((Renderer)lineRenderer).material);
		val2.startWidth = lineRenderer.startWidth;
		val2.endWidth = lineRenderer.endWidth;
		((Renderer)val2).shadowCastingMode = (ShadowCastingMode)0;
		((Renderer)val2).receiveShadows = false;
		for (int i = 0; i < lineSegments; i++)
		{
			float num = (float)i / (float)(lineSegments - 1);
			val2.SetPosition(i, Vector3.Lerp(point1, point2, num));
		}
		GameObject val3 = null;
		GameObject val4 = null;
		if (hasSpheres && Object.op_Implicit((Object)(object)sphere1) && Object.op_Implicit((Object)(object)sphere2))
		{
			val3 = GameObject.CreatePrimitive((PrimitiveType)0);
			val3.transform.position = point1;
			val3.transform.localScale = sphere1.transform.localScale;
			MeshRenderer component = val3.GetComponent<MeshRenderer>();
			((Renderer)component).material = new Material(((Renderer)sphere1.GetComponent<MeshRenderer>()).material);
			((Renderer)component).shadowCastingMode = (ShadowCastingMode)0;
			((Renderer)component).receiveShadows = false;
			Object.Destroy((Object)(object)val3.GetComponent<Collider>());
			val4 = GameObject.CreatePrimitive((PrimitiveType)0);
			val4.transform.position = point2;
			val4.transform.localScale = sphere2.transform.localScale;
			MeshRenderer component2 = val4.GetComponent<MeshRenderer>();
			((Renderer)component2).material = new Material(((Renderer)sphere2.GetComponent<MeshRenderer>()).material);
			((Renderer)component2).shadowCastingMode = (ShadowCastingMode)0;
			((Renderer)component2).receiveShadows = false;
			Object.Destroy((Object)(object)val4.GetComponent<Collider>());
		}
		Light val5 = null;
		Light val6 = null;
		if (hasLights && Object.op_Implicit((Object)(object)point1Light) && Object.op_Implicit((Object)(object)point2Light))
		{
			GameObject val7 = new GameObject("OutroLight1");
			val7.transform.position = point1;
			val5 = val7.AddComponent<Light>();
			val5.color = lineColor;
			val5.range = lightRadius;
			val5.intensity = currentLightIntensity;
			val5.shadows = (LightShadows)0;
			GameObject val8 = new GameObject("OutroLight2");
			val8.transform.position = point2;
			val6 = val8.AddComponent<Light>();
			val6.color = lineColor;
			val6.range = lightRadius;
			val6.intensity = currentLightIntensity;
			val6.shadows = (LightShadows)0;
		}
		val.AddComponent<BeamOutroAnimator>().Initialize(val2, point1, point2, lineSegments, baseWidth, baseWidthOscillation, val3, val4, val5, val6, animationDuration);
	}

	public LineBetweenTwoPoints()
	{
		//IL_001e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0023: Unknown result type (might be due to invalid IL or missing references)
	}
}
