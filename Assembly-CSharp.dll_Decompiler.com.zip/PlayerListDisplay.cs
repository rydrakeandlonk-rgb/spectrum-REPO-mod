using Photon.Pun;
using TMPro;
using UnityEngine;

public class PlayerListDisplay : MonoBehaviourPunCallbacks
{
	public TextMeshProUGUI playerListText;

	public TextMeshProUGUI instructionText;

	public TextMeshProUGUI roomNameText;

	public GameObject loadingUI;

	private bool loading;

	public GameObject punVoiceClient;

	internal int playersCount;

	private bool voiceInitialized;

	public MenuPageMain menuPageMain;

	private void Start()
	{
	}

	private void Update()
	{
	}

	[PunRPC]
	private void StartLoadingRPC(PhotonMessageInfo _info = default(PhotonMessageInfo))
	{
		//IL_0000: Unknown result type (might be due to invalid IL or missing references)
		SemiFunc.MasterOnlyRPC(_info);
	}
}
