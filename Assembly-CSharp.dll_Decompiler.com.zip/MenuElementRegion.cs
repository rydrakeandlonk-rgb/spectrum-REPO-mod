using TMPro;
using UnityEngine;
using UnityEngine.UI;

public class MenuElementRegion : MonoBehaviour
{
	public Image fadePanel;

	public MenuPageRegions parentPage;

	private MenuElementHover menuElementHover;

	private float initialFadeAlpha;

	public TextMeshProUGUI textName;

	public TextMeshProUGUI textPing;

	[Space]
	public bool animationSkip;

	public RectTransform animationTransform;

	public AnimationCurve introCurve;

	private float introLerp;

	internal string regionCode = "";

	private void Start()
	{
		//IL_0013: Unknown result type (might be due to invalid IL or missing references)
		menuElementHover = ((Component)this).GetComponent<MenuElementHover>();
		initialFadeAlpha = ((Graphic)fadePanel).color.a;
		UpdateIntro();
	}

	private void Update()
	{
		//IL_0091: Unknown result type (might be due to invalid IL or missing references)
		//IL_0096: Unknown result type (might be due to invalid IL or missing references)
		//IL_0099: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c0: Unknown result type (might be due to invalid IL or missing references)
		//IL_0019: Unknown result type (might be due to invalid IL or missing references)
		//IL_001e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0021: Unknown result type (might be due to invalid IL or missing references)
		//IL_0047: Unknown result type (might be due to invalid IL or missing references)
		UpdateIntro();
		if (menuElementHover.isHovering)
		{
			Color color = ((Graphic)fadePanel).color;
			color.a = Mathf.Lerp(color.a, 0f, Time.deltaTime * 10f);
			((Graphic)fadePanel).color = color;
			if (!menuElementHover.JustBecameCurrentTarget && SemiFunc.InputUIClick())
			{
				parentPage.PickRegion(regionCode);
				MenuManager.instance.MenuEffectClick(MenuManager.MenuClickEffectType.Confirm);
			}
		}
		else
		{
			Color color2 = ((Graphic)fadePanel).color;
			color2.a = Mathf.Lerp(color2.a, initialFadeAlpha, Time.deltaTime * 10f);
			((Graphic)fadePanel).color = color2;
		}
	}

	private void UpdateIntro()
	{
		//IL_005c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0061: Unknown result type (might be due to invalid IL or missing references)
		if (!animationSkip)
		{
			introLerp += Time.deltaTime * 5f;
			if (introLerp > 1f)
			{
				animationSkip = true;
			}
			animationTransform.anchoredPosition = Vector2.op_Implicit(new Vector3((0f - introCurve.Evaluate(introLerp)) * 10f, 0f, 0f));
		}
	}
}
