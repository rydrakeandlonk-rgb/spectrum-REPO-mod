using System.Collections.Generic;
using System.IO;
using UnityEngine;
using UnityEngine.CrashReportHandler;

public class BuildManager : MonoBehaviour
{
	public static BuildManager instance;

	public Version version;

	[RuntimeInitializeOnLoadMethod(/*Could not decode attribute arguments.*/)]
	private static void RuntimeInitializeOnLoad()
	{
		instance = null;
	}

	private void Awake()
	{
		if (!Object.op_Implicit((Object)(object)instance))
		{
			instance = this;
			Object.DontDestroyOnLoad((Object)(object)((Component)this).gameObject);
			CrashReportHandler.SetUserMetadata("modded", ModdedCheck.GetModdedState(skipCache: true).ToString());
			if (!Object.op_Implicit((Object)(object)version))
			{
				return;
			}
			Debug.Log((object)("VERSION: " + version.title));
			string path = (Application.isEditor ? Path.Combine("Cache", "Editor") : "Cache");
			string text = Path.Combine(Application.persistentDataPath, path);
			if (!Directory.Exists(text))
			{
				Directory.CreateDirectory(text);
			}
			string path2 = Path.Combine(text, "version.txt");
			if (File.Exists(path2))
			{
				if (File.ReadAllText(path2) != version.title)
				{
					File.WriteAllText(path2, version.title);
					string path3 = Path.Combine(text, "Icons");
					if (Directory.Exists(path3))
					{
						List<int> list = SemiFunc.DeleteDirectoriesRecursive(path3);
						Debug.Log((object)$"Deleted {list[0]}/{list[1]} files and directories for 'Icons' cache");
					}
				}
			}
			else
			{
				File.WriteAllText(path2, version.title);
			}
		}
		else
		{
			Object.Destroy((Object)(object)((Component)this).gameObject);
		}
	}
}
