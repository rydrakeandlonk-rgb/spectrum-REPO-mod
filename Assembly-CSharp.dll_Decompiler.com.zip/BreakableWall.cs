using UnityEngine;

public class BreakableWall : MonoBehaviour
{
	public GameObject brokenBits;

	public GameObject crack1;

	public GameObject crack2;

	public GameObject crack3;

	public ParticleSystem crackingParticles;

	public Sound crackSound;

	private PhysGrabObject physGrabObject;

	private bool broken;

	private void Start()
	{
		physGrabObject = ((Component)this).GetComponent<PhysGrabObject>();
	}

	private void Update()
	{
		if (!broken)
		{
			physGrabObject.OverrideKinematic();
			physGrabObject.OverrideGrabDisable();
			physGrabObject.OverrideDroneTargetDisable();
		}
	}

	public void BreakWall()
	{
		//IL_0034: Unknown result type (might be due to invalid IL or missing references)
		//IL_0062: Unknown result type (might be due to invalid IL or missing references)
		if (!broken && !physGrabObject.dead)
		{
			GameDirector.instance.CameraShake.ShakeDistance(3f, 2f, 8f, ((Component)this).transform.position, 0.15f);
			GameDirector.instance.CameraImpact.ShakeDistance(5f, 2f, 8f, ((Component)this).transform.position, 0.08f);
		}
		SpawnBits();
		broken = true;
	}

	public void SpawnBits()
	{
		brokenBits.SetActive(true);
	}

	public void Crack()
	{
		//IL_0064: Unknown result type (might be due to invalid IL or missing references)
		if (crack1.activeSelf)
		{
			crack1.SetActive(false);
			crack2.SetActive(true);
		}
		else if (crack2.activeSelf)
		{
			crack2.SetActive(false);
			crack3.SetActive(true);
		}
		crackingParticles.Play(true);
		crackSound.Play(((Component)this).transform.position);
	}
}
