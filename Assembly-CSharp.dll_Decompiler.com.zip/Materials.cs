using System;
using System.Collections.Generic;
using UnityEngine;

public class Materials : MonoBehaviour
{
	public enum Type
	{
		None,
		Wood,
		Rug,
		Tile,
		Stone,
		Catwalk,
		Snow,
		Metal,
		Wetmetal,
		Gravel,
		Grass,
		Water,
		Vent,
		Beam,
		Garbage,
		Tarp,
		Rubble,
		Brokentiles,
		Sand,
		WoodDry,
		Glass,
		Slime,
		Ice
	}

	public enum SoundType
	{
		Light,
		Medium,
		Heavy
	}

	public enum HostType
	{
		LocalPlayer,
		OtherPlayer,
		Enemy
	}

	[Serializable]
	public class MaterialTrigger
	{
		internal MaterialPreset LastMaterial;

		internal Type LastMaterialType;

		internal MaterialSlidingLoop SlidingLoopObject;

		internal int LastMaterialResetCount;

		internal bool OverrideLayerMask;

		internal LayerMask LayerMask;
	}

	public static Materials Instance;

	public LayerMask LayerMask;

	[Space]
	public Transform ParticleParent;

	public List<GameObject> Particles = new List<GameObject>();

	public List<MaterialPreset> MaterialList;

	private MaterialPreset LastMaterial;

	[RuntimeInitializeOnLoadMethod(/*Could not decode attribute arguments.*/)]
	private static void RuntimeInitializeOnLoad()
	{
		Instance = null;
	}

	private void Awake()
	{
		Instance = this;
	}

	public void Impulse(Vector3 origin, Vector3 direction, SoundType soundType, bool footstep, bool footstepParticles, MaterialTrigger materialTrigger, HostType hostType)
	{
		//IL_0001: Unknown result type (might be due to invalid IL or missing references)
		//IL_0004: Unknown result type (might be due to invalid IL or missing references)
		//IL_0009: Unknown result type (might be due to invalid IL or missing references)
		//IL_01e7: Unknown result type (might be due to invalid IL or missing references)
		//IL_017c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0129: Unknown result type (might be due to invalid IL or missing references)
		//IL_00be: Unknown result type (might be due to invalid IL or missing references)
		//IL_036a: Unknown result type (might be due to invalid IL or missing references)
		//IL_02ff: Unknown result type (might be due to invalid IL or missing references)
		//IL_02ac: Unknown result type (might be due to invalid IL or missing references)
		//IL_0241: Unknown result type (might be due to invalid IL or missing references)
		//IL_04ed: Unknown result type (might be due to invalid IL or missing references)
		//IL_0482: Unknown result type (might be due to invalid IL or missing references)
		//IL_042f: Unknown result type (might be due to invalid IL or missing references)
		//IL_03c4: Unknown result type (might be due to invalid IL or missing references)
		//IL_052f: Unknown result type (might be due to invalid IL or missing references)
		//IL_053f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0583: Unknown result type (might be due to invalid IL or missing references)
		//IL_0584: Unknown result type (might be due to invalid IL or missing references)
		//IL_0585: Unknown result type (might be due to invalid IL or missing references)
		//IL_058a: Unknown result type (might be due to invalid IL or missing references)
		//IL_055f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0560: Unknown result type (might be due to invalid IL or missing references)
		//IL_0561: Unknown result type (might be due to invalid IL or missing references)
		//IL_0566: Unknown result type (might be due to invalid IL or missing references)
		Vector3 material = GetMaterial(origin, materialTrigger);
		if (!Object.op_Implicit((Object)(object)LastMaterial))
		{
			return;
		}
		float volumeMultiplier = 1f;
		float falloffMultiplier = 1f;
		float offscreenVolumeMultiplier = 1f;
		float offscreenFalloffMultiplier = 1f;
		switch (hostType)
		{
		case HostType.OtherPlayer:
			volumeMultiplier = 0.5f;
			break;
		case HostType.Enemy:
			volumeMultiplier = 0.5f;
			falloffMultiplier = 0.5f;
			offscreenVolumeMultiplier = 0.25f;
			offscreenFalloffMultiplier = 0.25f;
			break;
		}
		switch (soundType)
		{
		case SoundType.Light:
			if (footstep)
			{
				if (LastMaterial.RareFootstepLightMax > 0)
				{
					LastMaterial.RareFootstepLightCurrent--;
					if (LastMaterial.RareFootstepLightCurrent <= 0f)
					{
						LastMaterial.RareFootstepLight.Play(material, volumeMultiplier, falloffMultiplier, offscreenVolumeMultiplier, offscreenFalloffMultiplier);
						LastMaterial.RareFootstepLightCurrent = Random.Range(LastMaterial.RareFootstepLightMin, LastMaterial.RareFootstepLightMax);
					}
				}
				if (LastMaterial.FootstepLight.Sounds.Length == 0)
				{
					Debug.LogError((object)("Material - No light footstep sounds assigned to: " + LastMaterial.Name));
				}
				LastMaterial.FootstepLight.Play(material, volumeMultiplier, falloffMultiplier, offscreenVolumeMultiplier, offscreenFalloffMultiplier);
				break;
			}
			if (LastMaterial.RareImpactLightMax > 0)
			{
				LastMaterial.RareImpactLightCurrent--;
				if (LastMaterial.RareImpactLightCurrent <= 0f)
				{
					LastMaterial.RareImpactLight.Play(material, volumeMultiplier, falloffMultiplier, offscreenVolumeMultiplier, offscreenFalloffMultiplier);
					LastMaterial.RareImpactLightCurrent = Random.Range(LastMaterial.RareImpactLightMin, LastMaterial.RareImpactLightMax);
				}
			}
			if (LastMaterial.ImpactLight.Sounds.Length == 0)
			{
				Debug.LogError((object)("Material - No light impact sounds assigned to: " + LastMaterial.Name));
			}
			LastMaterial.ImpactLight.Play(material, volumeMultiplier, falloffMultiplier, offscreenVolumeMultiplier, offscreenFalloffMultiplier);
			break;
		case SoundType.Medium:
			if (footstep)
			{
				if (LastMaterial.RareFootstepMediumMax > 0)
				{
					LastMaterial.RareFootstepMediumCurrent--;
					if (LastMaterial.RareFootstepMediumCurrent <= 0f)
					{
						LastMaterial.RareFootstepMedium.Play(material, volumeMultiplier, falloffMultiplier, offscreenVolumeMultiplier, offscreenFalloffMultiplier);
						LastMaterial.RareFootstepMediumCurrent = Random.Range(LastMaterial.RareFootstepMediumMin, LastMaterial.RareFootstepMediumMax);
					}
				}
				if (LastMaterial.FootstepMedium.Sounds.Length == 0)
				{
					Debug.LogError((object)("Material - No medium footstep sounds assigned to: " + LastMaterial.Name));
				}
				LastMaterial.FootstepMedium.Play(material, volumeMultiplier, falloffMultiplier, offscreenVolumeMultiplier, offscreenFalloffMultiplier);
				break;
			}
			if (LastMaterial.RareImpactMediumMax > 0)
			{
				LastMaterial.RareImpactMediumCurrent--;
				if (LastMaterial.RareImpactMediumCurrent <= 0f)
				{
					LastMaterial.RareImpactMedium.Play(material, volumeMultiplier, falloffMultiplier, offscreenVolumeMultiplier, offscreenFalloffMultiplier);
					LastMaterial.RareImpactMediumCurrent = Random.Range(LastMaterial.RareImpactMediumMin, LastMaterial.RareImpactMediumMax);
				}
			}
			if (LastMaterial.ImpactMedium.Sounds.Length == 0)
			{
				Debug.LogError((object)("Material - No medium impact sounds assigned to: " + LastMaterial.Name));
			}
			LastMaterial.ImpactMedium.Play(material, volumeMultiplier, falloffMultiplier, offscreenVolumeMultiplier, offscreenFalloffMultiplier);
			break;
		case SoundType.Heavy:
			if (footstep)
			{
				if (LastMaterial.RareFootstepHeavyMax > 0)
				{
					LastMaterial.RareFootstepHeavyCurrent--;
					if (LastMaterial.RareFootstepHeavyCurrent <= 0f)
					{
						LastMaterial.RareFootstepHeavy.Play(material, volumeMultiplier, falloffMultiplier, offscreenVolumeMultiplier, offscreenFalloffMultiplier);
						LastMaterial.RareFootstepHeavyCurrent = Random.Range(LastMaterial.RareFootstepHeavyMin, LastMaterial.RareFootstepHeavyMax);
					}
				}
				if (LastMaterial.FootstepHeavy.Sounds.Length == 0)
				{
					Debug.LogError((object)("Material - No heavy footstep sounds assigned to: " + LastMaterial.Name));
				}
				LastMaterial.FootstepHeavy.Play(material, volumeMultiplier, falloffMultiplier, offscreenVolumeMultiplier, offscreenFalloffMultiplier);
				break;
			}
			if (LastMaterial.RareImpactHeavyMax > 0)
			{
				LastMaterial.RareImpactHeavyCurrent--;
				if (LastMaterial.RareImpactHeavyCurrent <= 0f)
				{
					LastMaterial.RareImpactHeavy.Play(material, volumeMultiplier, falloffMultiplier, offscreenVolumeMultiplier, offscreenFalloffMultiplier);
					LastMaterial.RareImpactHeavyCurrent = Random.Range(LastMaterial.RareImpactHeavyMin, LastMaterial.RareImpactHeavyMax);
				}
			}
			if (LastMaterial.ImpactHeavy.Sounds.Length == 0)
			{
				Debug.LogError((object)("Material - No heavy impact sounds assigned to: " + LastMaterial.Name));
			}
			LastMaterial.ImpactHeavy.Play(material, volumeMultiplier, falloffMultiplier, offscreenVolumeMultiplier, offscreenFalloffMultiplier);
			break;
		}
		if (Particles.Count < 25 && (Object.op_Implicit((Object)(object)LastMaterial.FootstepPrefab) || Object.op_Implicit((Object)(object)LastMaterial.ImpactPrefab)) && Vector3.Distance(material, ((Component)AssetManager.instance.mainCamera).transform.position) < 15f)
		{
			if (footstepParticles)
			{
				Object.Instantiate<GameObject>(LastMaterial.FootstepPrefab, material, Quaternion.LookRotation(-direction), ParticleParent);
			}
			else
			{
				Object.Instantiate<GameObject>(LastMaterial.ImpactPrefab, material, Quaternion.LookRotation(-direction), ParticleParent);
			}
		}
	}

	public void Slide(Vector3 origin, MaterialTrigger materialTrigger, float spatialBlend, bool isPlayer)
	{
		//IL_0011: Unknown result type (might be due to invalid IL or missing references)
		//IL_0013: Unknown result type (might be due to invalid IL or missing references)
		//IL_0018: Unknown result type (might be due to invalid IL or missing references)
		//IL_006f: Unknown result type (might be due to invalid IL or missing references)
		float volumeMultiplier = 1f;
		if (!isPlayer)
		{
			volumeMultiplier = 0.5f;
		}
		Vector3 material = GetMaterial(origin, materialTrigger);
		if (Object.op_Implicit((Object)(object)LastMaterial))
		{
			if (LastMaterial.SlideOneShot.Sounds.Length == 0)
			{
				Debug.LogError((object)("Material - No slide sound assigned to: " + LastMaterial.Name));
			}
			LastMaterial.SlideOneShot.SpatialBlend = spatialBlend;
			LastMaterial.SlideOneShot.Play(material, volumeMultiplier);
		}
	}

	public void SlideLoop(Vector3 origin, MaterialTrigger materialTrigger, float spatialBlend, float pitchMultiplier)
	{
		//IL_0000: Unknown result type (might be due to invalid IL or missing references)
		//IL_0001: Unknown result type (might be due to invalid IL or missing references)
		//IL_0025: Unknown result type (might be due to invalid IL or missing references)
		//IL_0027: Unknown result type (might be due to invalid IL or missing references)
		//IL_002c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0121: Unknown result type (might be due to invalid IL or missing references)
		//IL_0098: Unknown result type (might be due to invalid IL or missing references)
		//IL_0099: Unknown result type (might be due to invalid IL or missing references)
		Vector3 val = origin;
		bool flag = (Object)(object)materialTrigger.SlidingLoopObject != (Object)null;
		if (!flag || materialTrigger.SlidingLoopObject.getMaterialTimer <= 0f)
		{
			val = GetMaterial(origin, materialTrigger);
			if (flag)
			{
				materialTrigger.SlidingLoopObject.getMaterialTimer = 0.25f;
			}
		}
		if ((Object)(object)materialTrigger.LastMaterial != (Object)null && materialTrigger.LastMaterial.SlideLoop != null)
		{
			bool flag2 = false;
			if (!flag)
			{
				flag2 = true;
			}
			else if ((Object)(object)materialTrigger.SlidingLoopObject.material != (Object)(object)materialTrigger.LastMaterial)
			{
				materialTrigger.SlidingLoopObject = null;
				flag2 = true;
			}
			if (flag2)
			{
				GameObject val2 = Object.Instantiate<GameObject>(AudioManager.instance.AudioMaterialSlidingLoop, val, Quaternion.identity, AudioManager.instance.SoundsParent);
				materialTrigger.SlidingLoopObject = val2.GetComponent<MaterialSlidingLoop>();
				materialTrigger.SlidingLoopObject.material = materialTrigger.LastMaterial;
				Sound.CopySound(materialTrigger.SlidingLoopObject.material.SlideLoop, materialTrigger.SlidingLoopObject.sound);
				materialTrigger.SlidingLoopObject.sound.Source = materialTrigger.SlidingLoopObject.source;
			}
			materialTrigger.SlidingLoopObject.activeTimer = 0.1f;
			((Component)materialTrigger.SlidingLoopObject).transform.position = val;
			materialTrigger.SlidingLoopObject.pitchMultiplier = pitchMultiplier;
		}
	}

	private Vector3 GetMaterial(Vector3 origin, MaterialTrigger materialTrigger)
	{
		//IL_0008: Unknown result type (might be due to invalid IL or missing references)
		//IL_000e: Unknown result type (might be due to invalid IL or missing references)
		//IL_001a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0020: Unknown result type (might be due to invalid IL or missing references)
		//IL_0026: Unknown result type (might be due to invalid IL or missing references)
		//IL_002b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0049: Unknown result type (might be due to invalid IL or missing references)
		//IL_004a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0056: Unknown result type (might be due to invalid IL or missing references)
		//IL_0035: Unknown result type (might be due to invalid IL or missing references)
		//IL_003a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0111: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ab: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b0: Unknown result type (might be due to invalid IL or missing references)
		origin = new Vector3(origin.x, origin.y + 0.1f, origin.z);
		LayerMask layerMask = LayerMask;
		if (materialTrigger.OverrideLayerMask)
		{
			layerMask = materialTrigger.LayerMask;
		}
		Type _type = materialTrigger.LastMaterialType;
		bool flag = false;
		RaycastHit val = default;
		if (Physics.Raycast(origin, Vector3.down, ref val, 1f, LayerMask.op_Implicit(layerMask), (QueryTriggerInteraction)2))
		{
			MaterialSurface materialSurface = ((Component)val.collider).gameObject.GetComponent<MaterialSurface>();
			if (!Object.op_Implicit((Object)(object)materialSurface))
			{
				materialSurface = ((Component)val.collider).gameObject.GetComponentInParent<MaterialSurface>();
			}
			if (Object.op_Implicit((Object)(object)materialSurface))
			{
				_type = materialSurface.Type;
				origin = val.point;
				flag = true;
			}
		}
		if (!flag)
		{
			materialTrigger.LastMaterialResetCount++;
			if (materialTrigger.LastMaterialResetCount >= 2)
			{
				_type = Type.Wood;
				materialTrigger.LastMaterialResetCount = 0;
			}
		}
		LastMaterial = MaterialList.Find((MaterialPreset x) => x.Type == _type);
		materialTrigger.LastMaterialType = _type;
		materialTrigger.LastMaterial = LastMaterial;
		return origin;
	}
}
