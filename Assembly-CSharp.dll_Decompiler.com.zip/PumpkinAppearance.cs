using System;
using UnityEngine;

public class PumpkinAppearance : MonoBehaviour
{
	[Serializable]
	public class Variant
	{
		public Mesh mesh;

		public Material material;

		public Vector3 localPosition;

		public Quaternion localRotation = Quaternion.identity;

		public Vector3 localScale = Vector3.one;

		public Variant()
		{
			//IL_0001: Unknown result type (might be due to invalid IL or missing references)
			//IL_0006: Unknown result type (might be due to invalid IL or missing references)
			//IL_000c: Unknown result type (might be due to invalid IL or missing references)
			//IL_0011: Unknown result type (might be due to invalid IL or missing references)
		}
	}

	public MeshFilter meshFilter;

	public MeshRenderer meshRenderer;

	public Variant[] variants;

	private int currentVariant;

	private void Awake()
	{
		VariantSet(currentVariant);
	}

	public void VariantSet(int index)
	{
		//IL_009a: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ab: Unknown result type (might be due to invalid IL or missing references)
		//IL_00bc: Unknown result type (might be due to invalid IL or missing references)
		if (variants == null || index < 0 || index >= variants.Length)
		{
			return;
		}
		Variant variant = variants[index];
		if (variant != null && Object.op_Implicit((Object)(object)variant.mesh) && Object.op_Implicit((Object)(object)variant.material))
		{
			currentVariant = index;
			if (!Object.op_Implicit((Object)(object)meshFilter))
			{
				meshFilter = ((Component)this).GetComponent<MeshFilter>();
			}
			if (!Object.op_Implicit((Object)(object)meshRenderer))
			{
				meshRenderer = ((Component)this).GetComponent<MeshRenderer>();
			}
			if (Object.op_Implicit((Object)(object)meshFilter) && Object.op_Implicit((Object)(object)meshRenderer))
			{
				((Component)this).transform.localPosition = variant.localPosition;
				((Component)this).transform.localRotation = variant.localRotation;
				((Component)this).transform.localScale = variant.localScale;
				meshFilter.sharedMesh = variant.mesh;
				((Renderer)meshRenderer).sharedMaterial = variant.material;
			}
		}
	}
}
