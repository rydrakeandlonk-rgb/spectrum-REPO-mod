using TMPro;
using UnityEngine;

public class BuildName : MonoBehaviour
{
	private void Start()
	{
		TextMeshProUGUI component = ((Component)this).GetComponent<TextMeshProUGUI>();
		((TMP_Text)component).text = BuildManager.instance.version.title;
		if (ModdedCheck.IsModded())
		{
			((TMP_Text)component).text = ((TMP_Text)component).text + " [MODDED]";
		}
	}
}
