using UnityEngine;

[DefaultExecutionOrder(200)]
public class EnemySnatcherBackKickHurt : MonoBehaviour
{
	internal EnemySnatcher snatcher;

	private void LateUpdate()
	{
		if (Object.op_Implicit((Object)(object)snatcher))
		{
			snatcher.BackKickHurtTick();
			snatcher.FrontPunchHurtTick();
			snatcher.GallopHurtTick();
		}
	}
}
