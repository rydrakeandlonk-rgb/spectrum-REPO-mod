using System.Collections.Generic;
using System.Linq;
using UnityEngine;

public class EnemyDirector : MonoBehaviour
{
	public enum ExtractionsDoneState
	{
		StartRoom,
		PlayerRoom
	}

	internal ExtractionsDoneState extractionsDoneState;

	private float extractionDoneStateTimer;

	private bool extractionDoneStateImpulse = true;

	public static EnemyDirector instance;

	internal List<string> debugNoVision = new List<string>();

	internal EnemySetup[] debugEnemy;

	internal float debugEnemyEnableTime;

	internal float debugEnemyDisableTime;

	internal bool debugEasyGrab;

	internal bool debugSpawnClose;

	internal bool debugDespawnClose;

	internal bool debugInvestigate;

	internal bool debugShortActionTimer;

	internal bool debugNoSpawnedPause;

	internal bool debugNoSpawnIdlePause;

	internal bool debugNoGrabMaxTime;

	public List<EnemySetup> enemiesDifficulty1;

	public List<EnemySetup> enemiesDifficulty2;

	public List<EnemySetup> enemiesDifficulty3;

	[Space]
	public AnimationCurve spawnIdlePauseCurve;

	[Space]
	public AnimationCurve amountCurve1_1;

	public AnimationCurve amountCurve1_2;

	private int amountCurve1Value;

	[Space]
	public AnimationCurve amountCurve2_1;

	public AnimationCurve amountCurve2_2;

	private int amountCurve2Value;

	[Space]
	public AnimationCurve amountCurve3_1;

	public AnimationCurve amountCurve3_2;

	private int amountCurve3Value;

	internal int totalAmount;

	private List<EnemySetup> enemyList = new List<EnemySetup>();

	private List<EnemySetup> enemyListCurrent = new List<EnemySetup>();

	private int enemyListIndex;

	[Space]
	public AnimationCurve despawnTimeCurve_1;

	public AnimationCurve despawnTimeCurve_2;

	internal float despawnedTimeMultiplier = 1f;

	public float despawnedDecreaseMinutes;

	public float despawnedDecreasePercent;

	internal float despawnedDecreaseMultiplier = 1f;

	private float despawnedDecreaseTimer;

	private float investigatePointTimer;

	private float investigatePointTime = 3f;

	internal float enemyActionAmount;

	internal float spawnIdlePauseTimer;

	[Space]
	public List<EnemyParent> enemiesSpawned;

	internal List<EnemyValuable> enemyValuables = new List<EnemyValuable>();

	internal List<LevelPoint> enemyFirstSpawnPoints = new List<LevelPoint>();

	[RuntimeInitializeOnLoadMethod(/*Could not decode attribute arguments.*/)]
	private static void RuntimeInitializeOnLoad()
	{
		instance = null;
	}

	private void Awake()
	{
		instance = this;
		despawnedDecreaseTimer = 60f * despawnedDecreaseMinutes;
	}

	private void Start()
	{
		spawnIdlePauseTimer = 60f * Random.Range(2f, 3f) * spawnIdlePauseCurve.Evaluate(SemiFunc.RunGetDifficultyMultiplier1());
		if (Random.Range(0, 100) < 20)
		{
			spawnIdlePauseTimer *= Random.Range(0.1f, 0.25f);
		}
		spawnIdlePauseTimer = Mathf.Max(spawnIdlePauseTimer, 5f);
		if (!Object.op_Implicit((Object)(object)DebugCommandHandler.instance))
		{
			return;
		}
		if (SemiFunc.IsMainMenu())
		{
			DebugCommandHandler.instance.enemyNoVision.Clear();
			return;
		}
		foreach (string item in DebugCommandHandler.instance.enemyNoVision)
		{
			if (!debugNoVision.Contains(item))
			{
				debugNoVision.Add(item);
			}
		}
	}

	private void Update()
	{
		//IL_028d: Unknown result type (might be due to invalid IL or missing references)
		//IL_04bb: Unknown result type (might be due to invalid IL or missing references)
		//IL_022a: Unknown result type (might be due to invalid IL or missing references)
		//IL_04dd: Unknown result type (might be due to invalid IL or missing references)
		if (LevelGenerator.Instance.Generated && spawnIdlePauseTimer > 0f)
		{
			bool flag = true;
			foreach (EnemyParent item in enemiesSpawned)
			{
				if (Object.op_Implicit((Object)(object)item) && !item.firstSpawnPointUsed)
				{
					flag = false;
				}
			}
			if (flag)
			{
				spawnIdlePauseTimer -= Time.deltaTime;
			}
			if (debugNoSpawnIdlePause)
			{
				spawnIdlePauseTimer = 0f;
			}
		}
		despawnedDecreaseTimer -= Time.deltaTime;
		if (despawnedDecreaseTimer <= 0f)
		{
			despawnedDecreaseMultiplier -= despawnedDecreasePercent;
			if (despawnedDecreaseMultiplier < 0f)
			{
				despawnedDecreaseMultiplier = 0f;
			}
			despawnedDecreaseTimer = 60f * despawnedDecreaseMinutes;
		}
		if (RoundDirector.instance.allExtractionPointsCompleted)
		{
			foreach (EnemyParent item2 in enemiesSpawned)
			{
				if (Object.op_Implicit((Object)(object)item2) && item2.DespawnedTimer > 30f)
				{
					item2.DespawnedTimerSet(0f);
				}
			}
			if (investigatePointTimer <= 0f)
			{
				if (extractionsDoneState == ExtractionsDoneState.StartRoom)
				{
					enemyActionAmount = 0f;
					despawnedDecreaseMultiplier = 0f;
					if (extractionDoneStateImpulse)
					{
						extractionDoneStateTimer = 10f;
						extractionDoneStateImpulse = false;
						foreach (EnemyParent item3 in enemiesSpawned)
						{
							if (Object.op_Implicit((Object)(object)item3) && item3.Spawned && !item3.playerClose)
							{
								item3.SpawnedTimerPause(0f);
								item3.SpawnedTimerSet(0f);
							}
						}
					}
					investigatePointTimer = investigatePointTime;
					List<LevelPoint> list = SemiFunc.LevelPointsGetInStartRoom();
					if (list.Count > 0)
					{
						SemiFunc.EnemyInvestigate(((Component)list[Random.Range(0, list.Count)]).transform.position, 100f, pathfindOnly: true);
					}
					extractionDoneStateTimer -= investigatePointTime;
					if (extractionDoneStateTimer <= 0f)
					{
						extractionsDoneState = ExtractionsDoneState.PlayerRoom;
					}
				}
				else
				{
					List<LevelPoint> list2 = SemiFunc.LevelPointsGetInPlayerRooms();
					if (list2.Count > 0)
					{
						SemiFunc.EnemyInvestigate(((Component)list2[Random.Range(0, list2.Count)]).transform.position, 100f, pathfindOnly: true);
					}
					investigatePointTimer = investigatePointTime;
					investigatePointTime = Mathf.Min(investigatePointTime + 2f, 30f);
				}
			}
			else
			{
				investigatePointTimer -= Time.deltaTime;
			}
		}
		float num = 0f;
		foreach (EnemyParent item4 in enemiesSpawned)
		{
			if (!Object.op_Implicit((Object)(object)item4) || !item4.Spawned || !item4.playerClose || item4.forceLeave)
			{
				continue;
			}
			bool flag2 = false;
			foreach (PlayerAvatar item5 in SemiFunc.PlayerGetList())
			{
				foreach (RoomVolume currentRoom in item5.RoomVolumeCheck.CurrentRooms)
				{
					foreach (RoomVolume currentRoom2 in item4.currentRooms)
					{
						if ((Object)(object)currentRoom == (Object)(object)currentRoom2)
						{
							flag2 = true;
							break;
						}
					}
				}
			}
			if (flag2)
			{
				float num2 = 0f;
				if (item4.difficulty == EnemyParent.Difficulty.Difficulty3)
				{
					num2 += 2f;
				}
				else
				{
					num2 = ((item4.difficulty != EnemyParent.Difficulty.Difficulty2) ? (num2 + 0.5f) : (num2 + 1f));
				}
				num += num2 * item4.actionMultiplier;
			}
		}
		if (num > 0f)
		{
			enemyActionAmount += num * Time.deltaTime;
		}
		else
		{
			enemyActionAmount -= 0.1f * Time.deltaTime;
			enemyActionAmount = Mathf.Max(0f, enemyActionAmount);
		}
		float num3 = 120f;
		if (debugShortActionTimer)
		{
			num3 = 5f;
		}
		if (!(enemyActionAmount > num3))
		{
			return;
		}
		enemyActionAmount = 0f;
		LevelPoint levelPoint = SemiFunc.LevelPointGetFurthestFromPlayer(((Component)this).transform.position, 5f);
		if (Object.op_Implicit((Object)(object)levelPoint))
		{
			SetInvestigate(((Component)levelPoint).transform.position, float.MaxValue, pathfindOnly: true);
		}
		if (RoundDirector.instance.allExtractionPointsCompleted && extractionsDoneState == ExtractionsDoneState.PlayerRoom)
		{
			investigatePointTimer = 60f;
		}
		foreach (EnemyParent item6 in enemiesSpawned)
		{
			if (Object.op_Implicit((Object)(object)item6) && item6.Spawned)
			{
				item6.forceLeave = true;
			}
		}
	}

	public void AmountSetup()
	{
		if (SemiFunc.RunGetDifficultyMultiplier2() > 0f)
		{
			amountCurve3Value = (int)amountCurve3_2.Evaluate(SemiFunc.RunGetDifficultyMultiplier2());
			amountCurve2Value = (int)amountCurve2_2.Evaluate(SemiFunc.RunGetDifficultyMultiplier2());
			amountCurve1Value = (int)amountCurve1_2.Evaluate(SemiFunc.RunGetDifficultyMultiplier2());
		}
		else
		{
			amountCurve3Value = (int)amountCurve3_1.Evaluate(SemiFunc.RunGetDifficultyMultiplier1());
			amountCurve2Value = (int)amountCurve2_1.Evaluate(SemiFunc.RunGetDifficultyMultiplier1());
			amountCurve1Value = (int)amountCurve1_1.Evaluate(SemiFunc.RunGetDifficultyMultiplier1());
		}
		enemyListCurrent.Clear();
		for (int i = 0; i < amountCurve3Value; i++)
		{
			PickEnemies(enemiesDifficulty3);
		}
		for (int j = 0; j < amountCurve2Value; j++)
		{
			PickEnemies(enemiesDifficulty2);
		}
		for (int k = 0; k < amountCurve1Value; k++)
		{
			PickEnemies(enemiesDifficulty1);
		}
		if (SemiFunc.RunGetDifficultyMultiplier3() > 0f)
		{
			despawnedTimeMultiplier = despawnTimeCurve_2.Evaluate(SemiFunc.RunGetDifficultyMultiplier3());
		}
		else if (SemiFunc.RunGetDifficultyMultiplier2() > 0f)
		{
			despawnedTimeMultiplier = despawnTimeCurve_1.Evaluate(SemiFunc.RunGetDifficultyMultiplier2());
		}
		else
		{
			despawnedTimeMultiplier = 1f;
		}
		totalAmount = amountCurve1Value + amountCurve2Value + amountCurve3Value;
	}

	private void PickEnemies(List<EnemySetup> _enemiesList)
	{
		int _runsPlayed = DataDirector.instance.SettingValueFetch(DataDirector.Setting.RunsPlayed);
		_enemiesList.Shuffle();
		List<EnemySetup> list = new List<EnemySetup>();
		if (Object.op_Implicit((Object)(object)GameManager.instance) && GameManager.instance.IsWIPActive(DebugCommandHandler.WIPTypes.Enemy))
		{
			list = _enemiesList.Where((EnemySetup x) => x.status != EnemySetup.Status.Finalized && IsEligible(x)).ToList();
		}
		if (list.Count == 0)
		{
			list = _enemiesList;
		}
		EnemySetup item = null;
		float num = -1f;
		foreach (EnemySetup item2 in list)
		{
			if (!IsEligible(item2))
			{
				continue;
			}
			int num2 = 0;
			foreach (EnemySetup item3 in RunManager.instance.enemiesSpawned)
			{
				if ((Object)(object)item3 == (Object)(object)item2)
				{
					num2++;
				}
			}
			int num3 = 0;
			foreach (EnemySetup enemy in enemyList)
			{
				if ((Object)(object)enemy == (Object)(object)item2)
				{
					num3++;
				}
			}
			float num4 = 100f;
			if (Object.op_Implicit((Object)(object)item2.rarityPreset))
			{
				num4 = item2.rarityPreset.chance;
			}
			float num5 = Mathf.Max(1f, num4 - 30f * (float)num2 - 10f * (float)num3);
			float num6 = Random.Range(0f, num5);
			if (num6 > num)
			{
				item = item2;
				num = num6;
			}
		}
		enemyListCurrent.Add(item);
		enemyList.Add(item);
		bool IsEligible(EnemySetup _enemy)
		{
			if (_enemy.levelsCompletedCondition)
			{
				if (RunManager.instance.levelsCompleted < _enemy.levelsCompletedMin)
				{
					return false;
				}
				if (_enemy.levelsCompletedMax != 0 && RunManager.instance.levelsCompleted > _enemy.levelsCompletedMax)
				{
					return false;
				}
			}
			return _runsPlayed >= _enemy.runsPlayed;
		}
	}

	public EnemySetup GetEnemy()
	{
		EnemySetup enemySetup = enemyList[enemyListIndex];
		enemyListIndex++;
		int num = 0;
		foreach (EnemySetup item in RunManager.instance.enemiesSpawned)
		{
			if ((Object)(object)item == (Object)(object)enemySetup)
			{
				num++;
			}
		}
		int num2 = 2;
		while (num < 4 && num2 > 0)
		{
			RunManager.instance.enemiesSpawned.Add(enemySetup);
			num++;
			num2--;
		}
		return enemySetup;
	}

	public void FirstSpawnPointAdd(EnemyParent _enemyParent)
	{
		//IL_0050: Unknown result type (might be due to invalid IL or missing references)
		//IL_0064: Unknown result type (might be due to invalid IL or missing references)
		List<LevelPoint> list = (from x in SemiFunc.LevelPointsGetAll()
			where !x.Truck
			select x).ToList();
		float num = 0f;
		LevelPoint levelPoint = null;
		foreach (LevelPoint item in list)
		{
			float num2 = Vector3.Distance(((Component)item).transform.position, ((Component)LevelGenerator.Instance.LevelPathTruck).transform.position);
			foreach (LevelPoint enemyFirstSpawnPoint in enemyFirstSpawnPoints)
			{
				if ((Object)(object)enemyFirstSpawnPoint == (Object)(object)item)
				{
					num2 = 0f;
					break;
				}
			}
			if (num2 > num)
			{
				num = num2;
				levelPoint = item;
			}
		}
		if (Object.op_Implicit((Object)(object)levelPoint))
		{
			_enemyParent.firstSpawnPoint = levelPoint;
			enemyFirstSpawnPoints.Add(levelPoint);
		}
		if (enemyFirstSpawnPoints.Count >= list.Count)
		{
			enemyFirstSpawnPoints.Clear();
		}
	}

	public void DebugResult()
	{
	}

	public void SetInvestigate(Vector3 position, float radius, bool pathfindOnly = false)
	{
		//IL_0000: Unknown result type (might be due to invalid IL or missing references)
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_0025: Unknown result type (might be due to invalid IL or missing references)
		//IL_0082: Unknown result type (might be due to invalid IL or missing references)
		//IL_008e: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b7: Unknown result type (might be due to invalid IL or missing references)
		SemiEyes.Investigate(position, radius, pathfindOnly);
		if (!SemiFunc.IsMasterClientOrSingleplayer())
		{
			return;
		}
		if (debugInvestigate)
		{
			Object.Instantiate<GameObject>(AssetManager.instance.debugEnemyInvestigate, position, Quaternion.identity).GetComponent<DebugEnemyInvestigate>().radius = radius;
		}
		foreach (EnemyParent item in enemiesSpawned)
		{
			if (!Object.op_Implicit((Object)(object)item))
			{
				continue;
			}
			if (!item.Spawned)
			{
				if (radius >= 15f)
				{
					item.DisableDecrease(5f);
				}
			}
			else if (item.Enemy.HasStateInvestigate && Vector3.Distance(position, ((Component)item.Enemy).transform.position) / item.Enemy.StateInvestigate.rangeMultiplier < radius)
			{
				item.Enemy.StateInvestigate.Set(position, pathfindOnly);
			}
		}
	}

	public void AddEnemyValuable(EnemyValuable _newValuable)
	{
		List<EnemyValuable> list = new List<EnemyValuable>();
		foreach (EnemyValuable enemyValuable2 in enemyValuables)
		{
			if (!Object.op_Implicit((Object)(object)enemyValuable2))
			{
				list.Add(enemyValuable2);
			}
		}
		foreach (EnemyValuable item in list)
		{
			enemyValuables.Remove(item);
		}
		enemyValuables.Add(_newValuable);
		if (enemyValuables.Count > 10)
		{
			EnemyValuable enemyValuable = enemyValuables[0];
			enemyValuables.RemoveAt(0);
			enemyValuable.Destroy();
		}
	}
}
