using System.Collections.Generic;
using System.Linq;
using UnityEngine;

public class ShopManager : MonoBehaviour
{
	public static ShopManager instance;

	public Transform itemRotateHelper;

	public List<ItemVolume> itemVolumes;

	public List<Item> potentialItems = new List<Item>();

	public List<Item> potentialItemConsumables = new List<Item>();

	public List<Item> potentialItemUpgrades = new List<Item>();

	public List<Item> potentialItemHealthPacks = new List<Item>();

	public Dictionary<SemiFunc.itemSecretShopType, List<ItemVolume>> secretItemVolumes = new Dictionary<SemiFunc.itemSecretShopType, List<ItemVolume>>();

	public Dictionary<SemiFunc.itemSecretShopType, List<Item>> potentialSecretItems = new Dictionary<SemiFunc.itemSecretShopType, List<Item>>();

	public int itemSpawnTargetAmount = 8;

	public int itemConsumablesAmount = 6;

	public int itemUpgradesAmount = 3;

	public int itemHealthPacksAmount = 3;

	internal List<ItemAttributes> shoppingList = new List<ItemAttributes>();

	internal List<string> shoppingListItemNames = new List<string>();

	internal List<int> shoppingListItemValues = new List<int>();

	[HideInInspector]
	public int totalCost;

	[HideInInspector]
	public int totalCurrency;

	[HideInInspector]
	public bool isThief;

	[HideInInspector]
	public Transform extractionPoint;

	internal float itemValueMultiplier = 4f;

	internal float upgradeValueIncrease = 0.5f;

	internal float healthPackValueIncrease = 0.05f;

	internal float crystalValueIncrease = 0.2f;

	private bool shopTutorialCheck;

	[RuntimeInitializeOnLoadMethod(/*Could not decode attribute arguments.*/)]
	private static void RuntimeInitializeOnLoad()
	{
		instance = null;
	}

	private void Awake()
	{
		if (!Object.op_Implicit((Object)(object)instance))
		{
			instance = this;
			Object.DontDestroyOnLoad((Object)(object)((Component)this).gameObject);
		}
		else
		{
			Object.Destroy((Object)(object)((Component)this).gameObject);
		}
	}

	private void Update()
	{
		if (SemiFunc.RunIsShop() && GameDirector.instance.currentState == GameDirector.gameState.Main)
		{
			if (shopTutorialCheck)
			{
				if (TutorialDirector.instance.TutorialSettingCheck(DataDirector.Setting.TutorialShop, 1))
				{
					TutorialDirector.instance.ActivateTip("Shop", 2f, _interrupt: false);
				}
				else if (MetaManager.instance.cosmeticTokens.Count > 0 && TutorialDirector.instance.TutorialSettingCheck(DataDirector.Setting.TutorialCosmeticShopMachine, 1))
				{
					TutorialDirector.instance.ActivateTip("CosmeticShopMachine", 2f, _interrupt: false, 8f, _scaleDown: false);
				}
				shopTutorialCheck = false;
			}
		}
		else
		{
			shopTutorialCheck = true;
		}
	}

	public void ShopCheck()
	{
		totalCost = 0;
		List<ItemAttributes> list = new List<ItemAttributes>();
		foreach (ItemAttributes shopping in shoppingList)
		{
			if (Object.op_Implicit((Object)(object)shopping))
			{
				shopping.roomVolumeCheck.CheckSet();
				if (!shopping.roomVolumeCheck.inExtractionPoint)
				{
					list.Add(shopping);
				}
				else
				{
					totalCost += shopping.value;
				}
			}
			else
			{
				list.Add(shopping);
			}
		}
		foreach (ItemAttributes item in list)
		{
			shoppingList.Remove(item);
		}
	}

	public void ShoppingListItemAdd(ItemAttributes item)
	{
		shoppingList.Add(item);
		SemiFunc.ShopUpdateCost();
	}

	public void ShoppingListItemRemove(ItemAttributes item)
	{
		shoppingList.Remove(item);
		SemiFunc.ShopUpdateCost();
	}

	public void ShoppingListSet(string[] _itemNames, int[] _itemValues)
	{
		shoppingListItemNames.Clear();
		shoppingListItemValues.Clear();
		if (_itemNames != null && _itemValues != null)
		{
			int num = Mathf.Min(_itemNames.Length, _itemValues.Length);
			for (int i = 0; i < num; i++)
			{
				shoppingListItemNames.Add(_itemNames[i]);
				shoppingListItemValues.Add(_itemValues[i]);
			}
		}
	}

	public void ShopInitialize()
	{
		ShopInitialize(null);
	}

	internal void ShopInitialize(List<PunManager.ItemSpawn> _spawns)
	{
		if (SemiFunc.RunIsShop())
		{
			totalCurrency = SemiFunc.StatGetRunCurrency();
			totalCost = 0;
			shoppingList.Clear();
			ShoppingListSet(new string[0], new int[0]);
			GetAllItemsFromStatsManager();
			GetAllItemVolumesInScene();
			if (_spawns == null)
			{
				SemiFunc.ShopPopulateItemVolumes();
			}
			else
			{
				PunManager.instance.ShopPopulateItemVolumes(_spawns);
			}
		}
	}

	public float UpgradeValueGet(float _value, Item item)
	{
		int num = Mathf.Min(6, GameDirector.instance.PlayerList.Count);
		_value -= _value * 0.1f * (float)(num - 1);
		_value += _value * upgradeValueIncrease * (float)StatsManager.instance.GetItemsUpgradesPurchased(((Object)item).name);
		_value = Mathf.Ceil(_value);
		return _value;
	}

	public float HealthPackValueGet(float _value)
	{
		int num = Mathf.Min(6, GameDirector.instance.PlayerList.Count);
		int num2 = Mathf.Min(RunManager.instance.levelsCompleted, 15);
		_value -= _value * 0.1f * (float)(num - 1);
		_value += _value * healthPackValueIncrease * (float)num2;
		_value = Mathf.Ceil(_value);
		return _value;
	}

	public float CrystalValueGet(float _value)
	{
		int num = Mathf.Min(RunManager.instance.levelsCompleted, 15);
		_value += _value * crystalValueIncrease * (float)num;
		_value = Mathf.Ceil(_value);
		return _value;
	}

	private void GetAllItemVolumesInScene()
	{
		if (SemiFunc.IsNotMasterClient())
		{
			return;
		}
		itemVolumes.Clear();
		ItemVolume[] array = Object.FindObjectsByType<ItemVolume>((FindObjectsSortMode)0);
		foreach (ItemVolume itemVolume in array)
		{
			if (itemVolume.itemSecretShopType == SemiFunc.itemSecretShopType.none)
			{
				itemVolumes.Add(itemVolume);
				continue;
			}
			if (!secretItemVolumes.ContainsKey(itemVolume.itemSecretShopType))
			{
				secretItemVolumes.Add(itemVolume.itemSecretShopType, new List<ItemVolume>());
			}
			secretItemVolumes[itemVolume.itemSecretShopType].Add(itemVolume);
		}
		foreach (List<ItemVolume> value in secretItemVolumes.Values)
		{
			value.Shuffle();
		}
		itemVolumes.Shuffle();
	}

	private void GetAllItemsFromStatsManager()
	{
		if (SemiFunc.IsNotMasterClient())
		{
			return;
		}
		potentialItems.Clear();
		potentialItemConsumables.Clear();
		potentialItemUpgrades.Clear();
		potentialItemHealthPacks.Clear();
		potentialSecretItems.Clear();
		itemConsumablesAmount = Random.Range(4, 6);
		IEnumerable<Item> enumerable = StatsManager.instance.itemDictionary.Values;
		if (Object.op_Implicit((Object)(object)GameManager.instance) && GameManager.instance.IsWIPActive(DebugCommandHandler.WIPTypes.Item))
		{
			enumerable = (from x in enumerable
				group x by (itemVolume: x.itemVolume, itemSecretShopType: x.itemSecretShopType)).SelectMany((IGrouping<(SemiFunc.itemVolume itemVolume, SemiFunc.itemSecretShopType itemSecretShopType), Item> _group) =>
			{
				List<Item> list = _group.Where((Item x) => x.status == Item.Status.Finalized).ToList();
				return (list.Count <= 0) ? _group.ToList() : list;
			});
		}
		foreach (Item item in enumerable)
		{
			int num = SemiFunc.StatGetItemsPurchased(((Object)item).name);
			float num2 = item.value.valueMax / 1000f * itemValueMultiplier;
			if (item.itemType == SemiFunc.itemType.item_upgrade)
			{
				num2 = UpgradeValueGet(num2, item);
			}
			else if (item.itemType == SemiFunc.itemType.healthPack)
			{
				num2 = HealthPackValueGet(num2);
			}
			else if (item.itemType == SemiFunc.itemType.power_crystal)
			{
				num2 = CrystalValueGet(num2);
			}
			float num3 = Mathf.Clamp(num2, 1f, num2);
			bool flag = item.itemType == SemiFunc.itemType.power_crystal;
			bool flag2 = item.itemType == SemiFunc.itemType.item_upgrade;
			bool flag3 = item.itemType == SemiFunc.itemType.healthPack;
			int maxAmountInShop = item.maxAmountInShop;
			if (num >= maxAmountInShop || (item.maxPurchase && StatsManager.instance.GetItemsUpgradesPurchasedTotal(((Object)item).name) >= item.maxPurchaseAmount) || (item.minPlayerCount > 1 && GameDirector.instance.PlayerList.Count < item.minPlayerCount) || (!(num3 <= (float)totalCurrency) && Random.Range(0, 100) >= 25))
			{
				continue;
			}
			for (int num4 = 0; num4 < maxAmountInShop - num; num4++)
			{
				if (flag2)
				{
					potentialItemUpgrades.Add(item);
					continue;
				}
				if (flag3)
				{
					potentialItemHealthPacks.Add(item);
					continue;
				}
				if (flag)
				{
					potentialItemConsumables.Add(item);
					continue;
				}
				if (item.itemSecretShopType == SemiFunc.itemSecretShopType.none)
				{
					potentialItems.Add(item);
					continue;
				}
				if (!potentialSecretItems.ContainsKey(item.itemSecretShopType))
				{
					potentialSecretItems.Add(item.itemSecretShopType, new List<Item>());
				}
				potentialSecretItems[item.itemSecretShopType].Add(item);
			}
		}
		potentialItems.Shuffle();
		potentialItemConsumables.Shuffle();
		potentialItemUpgrades.Shuffle();
		potentialItemHealthPacks.Shuffle();
		foreach (List<Item> value in potentialSecretItems.Values)
		{
			value.Shuffle();
		}
	}
}
