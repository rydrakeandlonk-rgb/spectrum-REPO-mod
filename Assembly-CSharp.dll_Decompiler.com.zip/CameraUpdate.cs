using System.Collections.Generic;
using UnityEngine;

public class CameraUpdate : MonoBehaviour
{
	public float updateRate = 0.5f;

	private float updateTimer;

	public Color ambientLight = Color.black;

	public List<Camera> cams;

	private void Awake()
	{
		foreach (Camera cam in cams)
		{
			((Behaviour)cam).enabled = false;
		}
	}

	private void LateUpdate()
	{
		//IL_000f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0014: Unknown result type (might be due to invalid IL or missing references)
		//IL_0016: Unknown result type (might be due to invalid IL or missing references)
		//IL_0053: Unknown result type (might be due to invalid IL or missing references)
		if (updateTimer <= 0f - updateRate)
		{
			Color val = RenderSettings.ambientLight;
			RenderSettings.ambientLight = ambientLight;
			foreach (Camera cam in cams)
			{
				cam.Render();
			}
			RenderSettings.ambientLight = val;
			updateTimer += updateRate;
		}
		else
		{
			updateTimer -= Time.deltaTime;
		}
	}

	public CameraUpdate()
	{
		//IL_000c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0011: Unknown result type (might be due to invalid IL or missing references)
	}
}
